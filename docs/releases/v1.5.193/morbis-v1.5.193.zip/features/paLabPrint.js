"use strict";var __morbis_feature=(()=>{var tt="extensionConfig";function At(p,i,h){let g=i?.features?.[p];if(!g)return!0;if(g.enabled===!1)return!1;let y=h??i?.currentRole??"admin";if(y==="admin")return!0;let S=g.allowedRoles;return!Array.isArray(S)||S.length===0?!0:S.includes(y)}async function St(p){try{let i=(await chrome.storage.sync.get(tt))?.[tt]??null;return At(p,i)}catch{return!0}}function Et(p,i){St(p).then(h=>{if(h)try{i()}catch(g){console.error(`[featureGate:${p}] gagal jalan:`,g)}})}var et="ext-free-text-noop",Ct='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function Lt(p){try{let i=p.toUpper;if(typeof i=="function"&&i[et]===!0)return!0;let h=function(g){return g?.value??""};h[et]=!0;try{Object.defineProperty(p,"toUpper",{value:h,writable:!0,configurable:!0})}catch{p.toUpper=h}return!0}catch{return!1}}var G="ext-pa-typo",It=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi (termasuk Saran & Catatan)"},{key:"kesimpulan",label:"Kesimpulan"},{key:"icdo",label:"ICD-O"},{key:"ttd",label:"TTD"}],j={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},icdo:{fs:6,lh:1.2},catatan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},at=4,it=24,zt=.5,Tt=2.5;function nt(p,i,h,g){let y=typeof p=="number"?p:Number(p);return Number.isFinite(y)?Math.min(g,Math.max(h,y)):i}function A(p,i){let h=p??{};return{fs:nt(h.fs,i.fs,at,it),lh:nt(h.lh,i.lh,zt,Tt)}}function D(p){let i=p??{};return{kop:A(i.kop,j.kop),pasien:A(i.pasien,j.pasien),judul:A(i.judul,j.judul),isi:A(i.isi,j.isi),kesimpulan:A(i.kesimpulan,j.kesimpulan),icdo:A(i.icdo,j.icdo),catatan:A(i.catatan,j.catatan),ttd:A(i.ttd,j.ttd)}}function _(){return D(null)}function rt(p){try{if(!p)return _();let i=p.getItem(G);return i?D(JSON.parse(i)):_()}catch{return _()}}function Rt(p,i){try{return p?(p.setItem(G,JSON.stringify(D(i))),!0):!1}catch{return!1}}function qt(p){try{p?.removeItem(G)}catch{}}function ot(p){let i=D(p),h=g=>Math.min(it,Math.max(at,g));return{...i,alamatFs:h(i.kop.fs-8.5),judulLapFs:h(i.kop.fs-4)}}var b=p=>String(Math.round(p*100)/100);function Ft(p){let i=ot(p);return{"--pa-kop-fs":`${b(i.kop.fs)}pt`,"--pa-kop-lh":b(i.kop.lh),"--pa-alamat-fs":`${b(i.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(i.judulLapFs)}pt`,"--pa-pasien-fs":`${b(i.pasien.fs)}pt`,"--pa-pasien-lh":b(i.pasien.lh),"--pa-judul-fs":`${b(i.judul.fs)}pt`,"--pa-judul-lh":b(i.judul.lh),"--pa-isi-fs":`${b(i.isi.fs)}pt`,"--pa-isi-lh":b(i.isi.lh),"--pa-kesimpulan-fs":`${b(i.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(i.kesimpulan.lh),"--pa-icdo-fs":`${b(i.icdo.fs)}pt`,"--pa-icdo-lh":b(i.icdo.lh),"--pa-catatan-fs":`${b(i.catatan.fs)}pt`,"--pa-catatan-lh":b(i.catatan.lh),"--pa-ttd-fs":`${b(i.ttd.fs)}pt`,"--pa-ttd-lh":b(i.ttd.lh)}}function Pt(p,i){if(p)try{for(let[h,g]of Object.entries(Ft(i)))p.setProperty(h,g)}catch{}}var Dt=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function lt(p){let i=p??"",h=i.match(Dt);if(!h)return null;let g=i.slice(h[0].length).trim();return g===""?null:[h[1],g]}Et("paLabPrint",function(){"use strict";function p(){try{Lt(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let y=document.createElement("style");y.id="ext-free-text-style",y.textContent=Ct,document.head.appendChild(y)}}catch{}}if(p(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",p),window.setInterval(p,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function i(){let y="ext-pa-print-proc";if(document.documentElement.getAttribute(y))return;document.documentElement.setAttribute(y,"1");let S=()=>{try{return window.localStorage??null}catch{return null}},E=rt(S()),J=()=>{try{Pt(document.documentElement.style,E)}catch{}};J();let w=t=>M(t?.textContent||"");function st(t){return t.replace(/<[^>]+>/g," ")}function Mt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function M(t){return Mt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let pt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",H=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>w(t)).filter(Boolean);for(;H.length<3;)H.push("");let q=[],dt=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(dt){let t=document.createElement("div");t.innerHTML=dt.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),q=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let U=q.join(" "),ct=t=>{let e=U.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},ut=ct("telp"),mt=ct("fax"),$=(U.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],O=(U.match(/https?:\/\/[^\s;,]+/)||[""])[0],L=U.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");$&&(L=L.split($).join("")),O&&(L=L.split(O).join("")),L=L.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Ht=["Alamat: "+L,ut?"Telp: "+ut:"",mt?"Fax: "+mt:""].filter(Boolean).join(", "),Ut=[$?"Email: "+$:"",O?"Website: "+O:""].filter(Boolean).join(", ");q=[Ht,Ut].filter(Boolean);let Q=w(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",B=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let o=w(e[0]),s=w(e[2]),l=w(e[3]),r=w(e[5]);o&&B.push([o,s]),l&&B.push([l,r])}});let I=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],x=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),C=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",o=!1,s=t.querySelector(".section-title");if(s)e=w(s),o=!0;else{let c=m=>m.split(":")[0].trim();for(let m of Array.from(t.children).slice(0,3)){let f=w(m);if(f&&f.length<=24&&I.includes(x(c(f)))){e=c(f);break}}if(!e){let m=(t.textContent||"").split(`
`).map(f=>f.trim()).find(Boolean)||"";m&&I.includes(x(c(m)))&&(e=c(m))}if(!e)return}let l=document.createElement("div");l.innerHTML=t.innerHTML,l.querySelector(".section-title")?.remove();let r=l.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(c=>c.split(/<br\s*\/?>|\n/).map(m=>M(m.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(c=>c.length),u=[],n=[];r.forEach((c,m)=>{c.forEach((f,P)=>{m>0&&P===0&&u.length&&n.push(u.length),u.push(f)})});let a=u;if(!o&&a.length&&x(a[0])===x(e)){a.shift();for(let c=0;c<n.length;c++)n[c]-=1;for(;n.length&&n[0]<=0;)n.shift()}a.length>1&&!/^[IVXLC]+\.\s/.test(a[0])&&a.slice(1).some(c=>/^II\.\s/.test(c))&&(a[0]="I. "+a[0]),e&&C.push({title:e,items:a,para:n})});let $t=/^catatan\s*:?/i,Ot=/^icd[\s-]*o\b\s*:?/i,V=[];for(let t of C){let e=[{title:t.title,items:[],para:[]}],o=e[0],s=!1,l=(r,u)=>{o={title:r,items:[],para:[],bare:u},e.push(o),s=!0};if(t.items.forEach((r,u)=>{let n=r.match($t),a=n?null:r.match(Ot);if(n){x(o.title)!=="catatan"&&l("Catatan");let c=r.slice(n[0].length).trim();c&&(t.para.includes(u)&&o.para.push(o.items.length),o.items.push(c));return}if(a){x(o.title)!=="icdo"&&l("ICD-0",!0),t.para.includes(u)&&o.para.push(o.items.length),o.items.push(r);return}t.para.includes(u)&&o.para.push(o.items.length),o.items.push(r)}),s)for(let r of e)r.items.length&&V.push(r);else V.push(e[0])}C.length=0,C.push(...V),C.forEach((t,e)=>t._i=e),C.sort((t,e)=>{let o=t._i??0,s=e._i??0,l=I.indexOf(x(t.title)),r=I.indexOf(x(e.title)),u=l===-1?I.length:l,n=r===-1?I.length:r;return u!==n?u-n:o-s});function Bt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let o=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),s=t.getAttribute("placeholder")||"",l=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(o+" "+s+" "+l).slice(0,300)}}function Nt(t,e,o){let s=e.toLowerCase().split(/[^a-z0-9]+/).filter(n=>n.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(n));if(!s.length)return"";let l=s.sort((n,a)=>a.length-n.length)[0],r="",u=-1;return t.querySelectorAll("input, textarea, select").forEach(n=>{let{val:a,ctx:c}=Bt(n);if(!a||a===e||!a.toLowerCase().includes(l))return;let m=o.test(c)?2:0;m>u&&(u=m,r=a)}),r}function Kt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Gt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let o=n=>/ket\w*\s*klinis/i.test(n),s=n=>/^dokter/i.test(n)||/^rs\b/i.test(n),l=t.map(([n,a],c)=>({label:n,value:a,idx:c})).filter(n=>s(n.label)?!!n.value:o(n.label));if(!l.length)return;let r=new AbortController,u=window.setTimeout(()=>r.abort(),6e3);try{let n=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),a=await fetch(n.toString(),{credentials:"same-origin",signal:r.signal});if(!a.ok){window.console.info("[paPrint] override: fetch input status "+a.status);return}let c=await a.text(),m=new DOMParser().parseFromString(c,"text/html");window.console.info('[paPrint] override: input title="'+(m.title||"").slice(0,60)+'" len='+c.length+" fields="+m.querySelectorAll("input, textarea, select").length);for(let f of l){if(o(f.label)){let k=Kt(m,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),v=M(st(k));window.console.info("[paPrint] override: "+f.label+' cetak="'+f.value+'" input="'+v+'"'),v&&v!==f.value&&(t[f.idx][1]=v);continue}let P=/^dokter/i.test(f.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,Y=Nt(m,f.value,P),T=M(st(Y||""));window.console.info("[paPrint] override: "+f.label+' cetak="'+f.value+'" input="'+T+'"'),T&&T!==f.value&&(t[f.idx][1]=T)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(u)}}await Gt(B).catch(()=>{});let z=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>w(t)).filter(Boolean),ft=z[0]||"",ht=z[1]||"",N=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",gt=z.find(t=>/^\(.*\)$/.test(t))||z[2]||"",bt=z.find(t=>/^nip\.?/i.test(t))||z[3]||"",xt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",_t=Array.from(document.body.querySelectorAll("script")),Jt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),F=B.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let o=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,s=o.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||o,l=s.split(/\s+-\s*/);if(l.length>=3&&/rawat\s+inap/i.test(l[1])){let r=Jt(l[1].trim()),u=l.slice(2).join(" - ").trim(),n=u?r+" - "+u:r;if(n)return[t,n]}return[t,s]}),Qt=F.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),W=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),Vt=t=>/^catatan/i.test(t.trim()),X=t=>/^saran/i.test(t.trim()),yt=t=>Vt(t)||X(t),Wt=t=>X(t)?"Saran:":"Catatan:",Z=t=>t.replace(/^(catatan|saran)\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),Xt=F.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function kt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(o=>{if(!o.ok)throw new Error("img "+o.status);return o.blob()}).then(o=>new Promise((s,l)=>{let r=new FileReader;r.onload=()=>s(String(r.result)),r.onerror=()=>l(r.error),r.readAsDataURL(o)})).catch(()=>e)}async function Zt(){let t=ot(E),[e,o]=await Promise.all([kt(pt),N?kt(N):Promise.resolve("")]),s="";for(let a=0;a<F.length;a+=2){let c=F[a],m=F[a+1];s+="<tr><td>"+d(c[0])+"</td><td>:</td><td>"+d(c[1])+"</td>"+(m?"<td>"+d(m[0])+"</td><td>:</td><td>"+d(m[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let l="";for(let a of C){if(yt(a.title)){let k=a.items.length?a.items:["Tidak ada"],v=k.length>1,R=X(a.title)?"SARAN:":"CATATAN:";l+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+R+'</b></td><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';">'+k.map(K=>(v?"- ":"")+"<b>"+d(Z(K)||"Tidak ada")+"</b>").join("<br>")+"</td></tr></table>";continue}if(a.bare){a.items.forEach((k,v)=>{l+='<p style="margin:'+(v===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.icdo.fs+"pt;line-height:"+t.icdo.lh+';"><b>'+d(k.toUpperCase())+"</b></p>"});continue}let c=["makroskopik","mikroskopik","kesimpulan"].includes(x(a.title));l+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b>'+(c?"<u>":"")+d(a.title.toUpperCase())+(c?"</u>":"")+"</b></p>";let m=x(a.title)==="kesimpulan",f=x(a.title)==="icdo",P=m||f||x(a.title)==="saran",Y=m?t.kesimpulan.fs:f?t.icdo.fs:t.isi.fs,T=m?t.kesimpulan.lh:f?t.icdo.lh:t.isi.lh;a.items.forEach((k,v)=>{let R=lt(k),K=a.items.length===1&&R!==null&&/^[-•–—*]$/.test(R[0]),jt=K?Z(k)||R[1]:k,te=P?"<b>"+d(jt)+"</b>":W(jt),ee=R&&!K?"margin-left:18pt;text-indent:-18pt;":"";l+='<p style="margin:'+(a.para.includes(v)?"14pt":"0")+" 0 6pt 0;font-size:"+Y+"pt;line-height:"+T+";text-align:justify;"+ee+'">'+te+"</p>"})}let r='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(Q)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+H.slice(0,3).map(a=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(a)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+q.map(a=>d(a)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(Q.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+s+"</table>"+l+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(ft)+'</p><p style="margin:0 0 6pt 0;">'+d(ht)+"</p>"+(o?'<p style="margin:0 0 6pt 0;"><img src="'+o+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(gt)+'</b></p><p style="margin:0 0 6pt 0;">'+d(bt)+"</p></td></tr></table></body></html>",u=new Blob(["\uFEFF"+r],{type:"application/msword"}),n=document.createElement("a");n.href=URL.createObjectURL(u),n.download="Hasil-PA-"+Xt+".doc",document.body.appendChild(n),n.click(),window.setTimeout(()=>{URL.revokeObjectURL(n.href),n.remove()},4e3)}let Yt=C.map(t=>{if(yt(t.title)){let r=t.items.length?t.items:["Tidak ada"],u=r.length>1;return'<div class="section-catatan"><span class="catatan-label">'+Wt(t.title)+'</span><div class="catatan-list">'+r.map(n=>{let a="<span>"+d(Z(n)||"Tidak ada")+"</span>";return u?'<div class="catatan-item"><span class="catatan-dash">-</span>'+a+"</div>":'<div class="catatan-item">'+a+"</div>"}).join("")+"</div></div>"}let e=x(t.title)==="kesimpulan",o=x(t.title)==="icdo",s=e||o||x(t.title)==="saran",l='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+(o&&!t.bare?" section-icdo":"")+'">'+t.items.map((r,u)=>{let n=t.para.includes(u)?" item-para":"",a=lt(r);if(a&&!(t.items.length===1&&/^[-•–—*]$/.test(a[0]))){let c=s?"<strong>"+d(a[1])+"</strong>":W(a[1]);return'<div class="item-list has-marker'+n+'"><span class="item-marker">'+d(a[0])+"</span><span>"+c+"</span></div>"}return'<div class="item-list'+n+'">'+(s?"<strong>"+d(r)+"</strong>":W(r))+"</div>"}).join("")+"</div>";return t.bare?l:'<div class="section-judul'+(["makroskopik","mikroskopik","kesimpulan"].includes(x(t.title))?" u":"")+'">'+d(t.title)+"</div>"+l}).join("");document.body.innerHTML='<a href="'+d(xt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(pt)+'" alt="Logo"></div><div class="kop-text">'+H.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+q.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(Q)+'</div><div class="patient-info-container">'+Qt+'</div><div class="hasil-pa">'+Yt+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(ft)+"</p><p>"+d(ht)+"</p>"+(N?'<img src="'+d(N)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(gt)+'</p><p style="margin-top: 2px;">'+d(bt)+"</p></div></div></div>",_t.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),Zt().catch(()=>{window.location.href=xt})});let vt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(s,l,r,u,n,a,c,m)=>"<label>"+d(r)+'<input type="range" data-g="'+d(s)+'" data-f="'+l+'" min="'+u+'" max="'+n+'" step="'+a+'" value="'+c+'"><output data-o="'+d(s+"-"+l)+'">'+d(String(c)+m)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+It.map(s=>'<div class="t-typo-group"><strong>'+d(s.label)+'</strong><div class="t-typo-row">'+e(s.key,"fs","Font (pt)",4,20,.5,E[s.key].fs,"pt")+e(s.key,"lh","Spasi baris",.5,2.5,.05,E[s.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(s=>{let l=s;l.addEventListener("input",()=>{let r=l.dataset.g,u=l.dataset.f;if(!r||!u||!E[r])return;E[r][u]=Number(l.value),J();let n=t.querySelector(`output[data-o="${r}-${u}"]`);n&&(n.textContent=l.value+(u==="fs"?"pt":""))})});let o=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let s=Rt(S(),E);o&&(o.textContent=s?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(qt(S()),E=rt(S()),J(),vt(),o){let s=t.querySelector("[data-note]");s&&(s.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&vt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let wt="ext-pa-print-style";if(!document.getElementById(wt)){let t=document.createElement("style");t.id=wt,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-transform: uppercase;
        }

        /* Garis bawah hanya untuk header Makroskopik/Mikroskopik/Kesimpulan
           (permintaan user 2026-11-06). */
        .section-judul.u {
            text-decoration: underline;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Isi ICD-O yang dirender server DENGAN judul section sendiri:
           grup font & spasi sendiri, terpisah dari Isi, dan selalu bold.
           Varian tanpa judul memakai .section-isi-bare (grup ICD-O sama). */
        .section-icdo {
            font-size: var(--pa-icdo-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-icdo-lh, 1.2);
        }

        /* Hanging indent: baris bernomor/berpoin \u2014 penanda di kolom
           kiri tetap, teks lanjutan sejajar di bawah teks. */
        .item-list.has-marker {
            display: flex;
            gap: 6px;
        }

        .item-marker {
            flex-shrink: 0;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah), tapi ukuran font
           dan spasi baris punya grup sendiri (\u2699\uFE0F Gaya \u2192 ICD-O). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-icdo-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-icdo-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN & SARAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya).
           Header dan isi menyatu dalam satu baris, jadi keduanya memakai
           grup Isi yang sama (\u2699\uFE0F Gaya \u2192 Isi), sama besar dengan isi \u2014
           sesuai permintaan user 2026-11-06. Seluruh isinya bold. */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
            font-weight: bold;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let h=Date.now(),g=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(g),i().catch(()=>{})):Date.now()-h>5e3&&window.clearInterval(g)},200)})})();
