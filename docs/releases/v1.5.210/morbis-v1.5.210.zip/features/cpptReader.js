"use strict";var __morbis_feature=(()=>{var y="extensionConfig";function T(e,l,p){let u=l?.features?.[e];if(!u)return!0;if(u.enabled===!1)return!1;let m=p??l?.currentRole??"admin";if(m==="admin")return!0;let b=u.allowedRoles;return!Array.isArray(b)||b.length===0?!0:b.includes(m)}async function S(e){try{let l=(await chrome.storage.sync.get(y))?.[y]??null;return T(e,l)}catch{return!0}}function A(e,l){S(e).then(p=>{if(p)try{l()}catch(u){console.error(`[featureGate:${e}] gagal jalan:`,u)}})}var E='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',v=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${E};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,f=null;function P(){return f||(f=new CSSStyleSheet,f.replaceSync(v)),f}var k=!1;function z(){if(k||document.getElementById("ext-pjs-font"))return;k=!0;let e=document.createElement("link");e.id="ext-pjs-font",e.rel="stylesheet",e.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(e)}function L(e,l="open"){let p=e.attachShadow({mode:l});return p.adoptedStyleSheets=[P()],z(),p}var w=!1;function I(){if(w)return;w=!0;let e=document.createElement("style");e.id="ext-token-css",e.textContent=v.replace(":host",":root"),document.head.appendChild(e)}var R=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,B=class extends HTMLElement{constructor(){super();let e=L(this);e.innerHTML=`
      <style>${R}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=e.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",e=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){e.stopPropagation(),e.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(e){(e==="disabled"||e==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}},g=typeof window<"u"?window.customElements:null;if(g)try{g.get("ext-btn")||g.define("ext-btn",B)}catch(e){console.warn("[MORBIS Ext] gagal registrasi ext-btn:",e)}A("cpptReader",()=>{"use strict";let e=new URLSearchParams(location.search),l=e.get("visit")||e.get("id_visit")||document.querySelector("#id_visit")?.value?.trim()||"";if(!l)return;I();function p(s){let c=new DOMParser().parseFromString(s,"text/html"),d=Array.from(c.querySelectorAll("table")).find(i=>{let t=(i.querySelector("tr")?.textContent||"").toLowerCase();return t.includes("subyektif")||t.includes("assessment")||t.includes("instruksi")});if(!d)return[];let a=[];return d.querySelectorAll("tbody tr, tr").forEach(i=>{let t=Array.from(i.querySelectorAll("td"));if(t.length<6||t[0].tagName==="TH")return;let r=h=>(h?.textContent||"").replace(/\s+/g," ").trim(),n=t.map(r);if(/^no$/i.test(n[0]))return;let o={waktu:n[2]||n[1]||"",penginput:n[n.length-1]||"",subyektif:n[3]||"",obyektif:n[4]||"",assessment:n[5]||"",planning:n[6]||"",instruksi:n[7]||""};(o.waktu||o.subyektif||o.assessment)&&a.push(o)}),a}async function u(s){let c=s?"/admisi/detail-rawat-inap/cppt?idVisit="+encodeURIComponent(l):"/admisi/pelaksanaan_pelayanan/cppt?id_visit="+encodeURIComponent(l);try{let d=await fetch(c,{credentials:"include",cache:"no-store"});if(!d.ok)return[];let a=await d.text();return p(a)}catch{return[]}}function m(){let s=(document.body?.textContent||"").toUpperCase();return!!(/RIWAYAT\s+MUTASI\s+PASIEN[\s\S]*RAWAT\s+INAP/i.test(s)||/UNIT\s+ASAL[\s\S]*RAWAT\s+INAP/i.test(s))}function b(s,c){let d=document.getElementById("ext-cppt-reader-modal");d&&d.remove();let a=document.createElement("div");a.id="ext-cppt-reader-modal",a.style.cssText="position:fixed;inset:0;z-index:2147483600;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.55);backdrop-filter:blur(2px);padding:16px;";let i=document.createElement("div");i.style.cssText="width:900px;max-width:100%;max-height:90vh;background:#fff;border-radius:14px;box-shadow:0 20px 50px rgba(16,24,40,.18);overflow:hidden;display:flex;flex-direction:column;font-family:var(--ext-font-family,system-ui);";let t=document.createElement("div");t.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #d0d5dd;",t.innerHTML='<h3 style="margin:0;font-size:17px;font-weight:700;">Isian CPPT Pasien ('+c+')</h3><button type="button" id="ext-cppt-close" style="border:none;background:#f8fafc;width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:20px;">\xD7</button>';let r=document.createElement("div");r.style.cssText="padding:14px 18px;overflow:auto;flex:1;",s.length?r.innerHTML=s.map((o,h)=>'<div style="border:1px solid #d0d5dd;border-radius:8px;padding:10px;margin-bottom:10px;"><div style="font-weight:700;margin-bottom:6px;color:#00875a;">#'+(h+1)+" \u2014 "+x(o.waktu)+' <span style="font-weight:400;color:#667085;font-size:12px;">('+x(o.penginput)+")</span></div>"+(o.subyektif?'<div style="margin-bottom:4px;"><b>S:</b> '+x(o.subyektif)+"</div>":"")+(o.obyektif?'<div style="margin-bottom:4px;"><b>O:</b> '+x(o.obyektif)+"</div>":"")+(o.assessment?'<div style="margin-bottom:4px;"><b>A:</b> '+x(o.assessment)+"</div>":"")+(o.planning?'<div style="margin-bottom:4px;"><b>P:</b> '+x(o.planning)+"</div>":"")+(o.instruksi?'<div style="margin-bottom:4px;"><b>Instruksi:</b> '+x(o.instruksi)+"</div>":"")+"</div>").join(""):r.innerHTML='<p style="color:#667085;">Tidak ada data CPPT.</p>',i.appendChild(t),i.appendChild(r),a.appendChild(i),document.body.appendChild(a);let n=()=>a.remove();a.querySelector("#ext-cppt-close")?.addEventListener("click",n),a.addEventListener("click",o=>{o.target===a&&n()})}function x(s){return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function M(){if(document.getElementById("ext-cppt-btn"))return;let s=()=>{let a=Array.from(document.querySelectorAll('td[valign="top"]')).find(t=>t.querySelector('fieldset#perhatian, fieldset[id="perhatian"]'));if(a){let t=document.createElement("fieldset");t.id="ext-cppt-fieldset",t.style.cssText="margin-top:6px;",t.innerHTML="<legend>Baca CPPT</legend>";let r=document.createElement("div");r.id="ext-cppt-bar",r.style.cssText="display:flex;align-items:center;";let n=document.createElement("button");return n.id="ext-cppt-btn",n.className="btn",n.style.cssText="margin:2px 0;background:#2193cf;color:#fff;border-color:#2193cf;",n.textContent="Baca CPPT",n.addEventListener("click",d),r.appendChild(n),t.appendChild(r),a.appendChild(t),r}let i=document.querySelector("form");if(i){let t=document.createElement("div");t.id="ext-cppt-bar",t.style.cssText="display:flex;align-items:center;margin:6px 0;";let r=document.createElement("button");return r.id="ext-cppt-btn",r.type="button",r.className="btn",r.style.cssText="background:#2193cf;color:#fff;border-color:#2193cf;",r.textContent="Baca CPPT",r.addEventListener("click",d),t.appendChild(r),i.prepend(t),t}if(!document.getElementById("ext-cppt-bar")){let t=document.createElement("div");t.id="ext-cppt-fieldset",t.style.cssText="position:fixed;top:60px;right:12px;z-index:9999;background:#fff;border:1px solid #ccc;border-radius:8px;padding:8px;box-shadow:0 2px 8px rgba(0,0,0,.15);",t.innerHTML='<div id="ext-cppt-bar" style="display:flex;align-items:center;"></div>',document.body.appendChild(t);let r=t.querySelector("#ext-cppt-bar"),n=document.createElement("button");return n.id="ext-cppt-btn",n.type="button",n.className="btn",n.style.cssText="background:#2193cf;color:#fff;border-color:#2193cf;",n.textContent="Baca CPPT",n.addEventListener("click",d),r.appendChild(n),r}return null},c=()=>{let a=document.querySelector("#ext-cppt-bar")||s();if(!a||a.querySelector("#ext-cppt-btn"))return;let i=document.createElement("button");i.id="ext-cppt-btn",i.type="button",i.className="btn",i.style.cssText="background:#2193cf;color:#fff;border-color:#2193cf;",i.textContent="Baca CPPT",i.addEventListener("click",d),a.appendChild(i)};async function d(){let a=document.getElementById("ext-cppt-btn");a&&(a.disabled=!0,a.textContent="Memuat...");let i=m(),t=i?"Ranap":"Rajal",r=await u(i);!r.length&&!i&&(r=await u(!0)),a&&(a.disabled=!1,a.textContent="Baca CPPT"),b(r,t)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{window.setTimeout(c,500),window.setTimeout(c,2e3)},{once:!0}):(window.setTimeout(c,500),window.setTimeout(c,2e3))}let C=window.featureModules;C&&(C.cpptReader={id:"cpptReader",name:"Baca CPPT (Resep)",description:"Tombol baca isian CPPT pasien di halaman detail/edit resep",match:{oneOf:[{pathname:"/inventory/resep/penerimaan/detail"},{pathname:"/inventory/penjualan-resep-edit/detail"}]},enabledWhen:()=>!0,run:()=>M()})})})();
