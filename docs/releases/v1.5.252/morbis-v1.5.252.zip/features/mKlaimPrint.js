"use strict";var __morbis_feature=(()=>{function f(){return window}var c="RSUD H. Abdul Manap",p=f(),g=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],d=i=>document.getElementById(i)?.value?.trim()||"";function b(i){let e=t=>{let a=document.createElement("span");return a.className="fv",a.textContent=t,a};i.querySelectorAll("input").forEach(t=>{let a=(t.type||"text").toLowerCase();if(a==="hidden"){t.remove();return}if(a==="radio"||a==="checkbox"){if(!t.checked){t.remove();return}if(a==="radio"){t.replaceWith(e("\u2713"));return}let r=(t.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,o=>o.toUpperCase());t.replaceWith(e(r?"\u2713 "+r:"\u2713"));return}let n=(t.value||"").trim();n?t.replaceWith(e(n)):t.remove()}),i.querySelectorAll("textarea").forEach(t=>{let a=(t.value||"").trim();a?t.replaceWith(e(a)):t.remove()}),i.querySelectorAll("select").forEach(t=>{let a=(t.options[t.selectedIndex]?.textContent||t.value||"").trim();a?t.replaceWith(e(a)):t.remove()})}function m(i){let e=i.cloneNode(!0),t=Array.from(i.querySelectorAll("canvas")),a=Array.from(e.querySelectorAll("canvas"));return t.forEach((n,r)=>{let o=a[r];if(o)try{let l=document.createElement("img");l.src=n.toDataURL("image/png"),l.style.cssText="max-width:100%;height:auto;",o.replaceWith(l)}catch{let l=document.createElement("div");l.className="fv",l.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",o.replaceWith(l)}}),b(e),g.forEach(n=>e.querySelectorAll(n).forEach(r=>r.remove())),e.querySelectorAll("tr").forEach(n=>{let r=Array.from(n.cells);for(let o=r.length-1;o>=0;o--){let l=r[o];if(!(!(l.textContent||"").trim()&&!l.querySelector("img,table,input")))break;l.remove()}}),e.querySelectorAll("[style]").forEach(n=>{let r=((n.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");r?n.setAttribute("style",r):n.removeAttribute("style")}),e.removeAttribute("id"),e.removeAttribute("class"),e.removeAttribute("style"),e.querySelectorAll("div").forEach(n=>{!n.children.length&&!(n.textContent||"").trim()&&n.remove()}),e.innerHTML.trim()}function h(i,e){let t=(i.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return t=t.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),t||`Berkas ${String(e+1).padStart(2,"0")}`}function x(){let i=Array.from(document.querySelectorAll(".isidalam")),e=new Set,t=[];if(i.forEach((a,n)=>{let r=m(a);if(r.length<20)return;let o=h(a,n);e.has(o)||(e.add(o),t.push({title:o,html:r}))}),!t.length){let a=document.querySelector("#section-to-print");a&&t.push({title:"Detail Klaim",html:m(a)})}return t}var s=i=>i.replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function v(i){let e="/assets/images/logo/Kota Jambi.png",t=(r,o)=>`<div class="meta-item"><span class="meta-label">${s(r)}</span><span class="meta-value">${s(o||"\u2014")}</span></div>`,a=i.map((r,o)=>`<span class="toc-chip"><b>${String(o+1).padStart(2,"0")}</b> ${s(r.title)}</span>`).join(""),n=i.map((r,o)=>`
      <section class="doc">
        <div class="doc-head">
          <span class="doc-num">${String(o+1).padStart(2,"0")}</span>
          <h2>${s(r.title)}</h2>
          <span class="doc-rule"></span>
        </div>
        <div class="doc-body">${r.html}</div>
      </section>`).join("");return`<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<base href="${s(location.origin)}">
<title>Dossier Cetak M-KLAIM \u2014 ${s(c)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,500;8..60,700&display=swap" rel="stylesheet">
<style>
:root{
  --ink:#17212b; --muted:#5b6b78; --accent:#0f766e; --accent-soft:#e6f4f1;
  --paper:#fdfcf9; --rule:#d7dee2; --chip:#f1f5f4;
  --sans:'IBM Plex Sans','Segoe UI',sans-serif; --serif:'Source Serif 4',Georgia,serif;
}
@page{size:A4;margin:14mm 13mm;}
*{box-sizing:border-box;}
html,body{margin:0;padding:0;}
body{
  background:var(--paper); color:var(--ink); font-family:var(--sans);
  font-size:11px; line-height:1.55; padding:22px 26px;
  -webkit-print-color-adjust:exact; print-color-adjust:exact;
}
.cover{
  display:grid; grid-template-columns:64px 1fr; gap:16px; align-items:center;
  border-bottom:3px double var(--ink); padding-bottom:14px; margin-bottom:18px;
}
.cover img{width:64px;height:64px;object-fit:contain;}
.eyebrow{font-size:9px;letter-spacing:.22em;text-transform:uppercase;color:var(--accent);font-weight:700;}
.cover h1{font-family:var(--serif);font-size:22px;line-height:1.15;margin:3px 0 2px;font-weight:700;}
.cover .sub{font-size:10px;color:var(--muted);}
.meta{
  display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 16px;
  border-top:1px solid var(--ink);border-bottom:1px solid var(--rule);
  padding:10px 0;margin-bottom:12px;background:transparent;
}
.meta-item{display:flex;flex-direction:column;gap:2px;min-width:0;}
.meta-label{font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;}
.meta-value{font-weight:600;font-size:11px;overflow-wrap:anywhere;}
.toc{
  display:flex;flex-wrap:wrap;gap:2px 0;padding:0 0 10px;border-bottom:1px solid var(--rule);margin-bottom:18px;
}
.toc-chip{font-size:9px;color:var(--muted);padding:0;}
.toc-chip:not(:last-child)::after{content:' \xB7';color:var(--rule);margin-left:6px;}
.toc-chip b{color:var(--accent);font-weight:700;margin-right:3px;}
.doc{margin:0 0 24px;break-inside:avoid-page;}
.doc-head{display:flex;align-items:baseline;gap:10px;margin-bottom:8px;border-bottom:1px solid var(--ink);padding-bottom:5px;}
.doc-num{
  font-family:var(--serif);font-size:15px;color:var(--accent);font-weight:700;
  min-width:24px;
}
.doc-head h2{
  font-family:var(--serif);font-size:13px;margin:0;text-transform:uppercase;
  letter-spacing:.06em;
}
.doc-rule{display:none;}
.doc-body{background:transparent;border:0;border-radius:0;padding:2px 0 0;}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 10px;border:0!important;}
.doc-body th,.doc-body td{border:0!important;border-bottom:1px solid var(--rule)!important;padding:5px 7px;font-size:10px!important;text-align:left;vertical-align:top;overflow-wrap:anywhere;}
.doc-body th{background:transparent!important;font-weight:700;color:var(--ink);border-bottom:1px solid var(--ink)!important;letter-spacing:.04em;text-transform:uppercase;font-size:9px!important;}
.doc-body h1,.doc-body h2,.doc-body h3{font-family:var(--serif);font-size:13px;margin:6px 0;}
.doc-body p{margin:3px 0;}
.doc-body label{display:inline-block;min-width:112px;font-weight:600;color:var(--muted);font-size:9px;letter-spacing:.02em;text-transform:uppercase;}
.doc-body .fv{font-weight:500;color:var(--ink);}
.doc-body img{max-width:100%!important;height:auto!important;}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important;}
.screen-bar{
  position:sticky;top:0;z-index:9;display:flex;justify-content:flex-end;gap:8px;
  background:rgba(253,252,249,.94);backdrop-filter:blur(6px);
  padding:8px 0 12px;margin:-22px -26px 14px;padding-left:26px;padding-right:26px;
  border-bottom:1px solid var(--rule);
}
.screen-bar button{font:inherit;font-size:11px;font-weight:600;cursor:pointer;border-radius:5px;padding:7px 14px;}
.btn-print{background:var(--accent);color:#fff;border:1px solid var(--accent);}
.btn-close{background:#fff;color:var(--ink);border:1px solid var(--rule);}
.sign{display:flex;justify-content:flex-end;margin-top:26px;}
.sign-box{width:230px;text-align:center;font-size:10px;color:var(--muted);}
.sign-space{height:52px;}
@media print{
  .screen-bar{display:none!important;}
  body{padding:0;background:#fff;font-size:10px;}
  .doc{break-after:page;}
  .doc:last-child{break-after:auto;}
  .meta,.toc,.doc-body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}
}
@media screen and (max-width:900px){
  .meta{grid-template-columns:repeat(2,minmax(0,1fr));}
}
</style>
</head>
<body>
<div class="screen-bar">
  <button type="button" class="btn-close" id="close-view">Tutup</button>
  <button type="button" class="btn-print" id="print-view">\u{1F5A8} Cetak</button>
</div>
<header class="cover">
  <img src="${s(e)}" alt="Logo">
  <div>
    <div class="eyebrow">Dossier Cetak \xB7 Detail Klaim</div>
    <h1>${s(c)}</h1>
    <div class="sub">Laporan lengkap berkas klaim &bull; ${new Date().toLocaleString("id-ID")}</div>
  </div>
</header>
<div class="meta">
  ${t("No. RM",d("norm"))}
  ${t("Nama Pasien",d("nama"))}
  ${t("No. Registrasi",d("no_registrasi")||d("reg"))}
  ${t("ID Visit",d("id_visit"))}
  ${t("Tanggal Awal",d("tanggalAwal"))}
  ${t("Tanggal Akhir",d("tanggalAkhir"))}
  ${t("Status",d("status"))}
  ${t("Billing",d("billing"))}
</div>
<div class="toc">${a}</div>
<main>${n}</main>
<div class="sign"><div class="sign-box">
  <div>Petugas Verifikasi</div><div class="sign-space"></div>
  <div><strong>( .................................... )</strong></div>
</div></div>
<script>
(function(){
  function doPrint(){ window.focus(); window.print(); }
  document.getElementById('print-view').addEventListener('click', doPrint);
  document.getElementById('close-view').addEventListener('click', function(){
    if (window.confirm('Tutup halaman cetak ini?')) window.close();
  });
  window.addEventListener('load', function(){ setTimeout(doPrint, 500); });
  window.addEventListener('afterprint', function(){
    if (window.confirm('Apakah menu print ini akan ditutup?')) window.close();
  });
})();
<\/script>
</body>
</html>`}function y(){let i=x();if(!i.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let e=window.open("","_blank");if(!e){window.alert("Popup diblokir \u2014 izinkan popup untuk membuka dossier cetak M-KLAIM.");return}e.document.open(),e.document.write(v(i)),e.document.close()}function w(){let i=Array.from(document.querySelectorAll("button.btn-success")).find(e=>/^printDiv\s*\(/i.test(e.getAttribute("onclick")||""));return i?.parentElement?i.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(e=>e.querySelector("button"))||document.getElementById("SCETAK")||document.body}function u(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor")||document.getElementById("ext-mklaim-print-btn"))return;let i=w(),e=document.createElement("button");e.id="ext-mklaim-print-btn",e.type="button",e.className="btn btn-primary btn-sm",e.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",e.innerHTML="\u{1F5A8} Cetak Rapi M-KLAIM",e.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),y()}),i.appendChild(e)}typeof p.featureModules<"u"&&(p.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let i=()=>u();document.readyState==="complete"?window.setTimeout(i,500):window.addEventListener("load",()=>window.setTimeout(i,500));let e=()=>{let t=document.getElementById("ext-mklaim-print-btn");t?.parentElement&&t.parentElement.lastElementChild!==t&&t.parentElement.appendChild(t)};new MutationObserver(()=>{document.getElementById("ext-mklaim-print-btn")?e():u()}).observe(document.body,{childList:!0,subtree:!0}),window.setInterval(e,1500)}})})();
