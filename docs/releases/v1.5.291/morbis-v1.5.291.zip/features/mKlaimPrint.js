"use strict";var __morbis_feature=(()=>{var bt=Object.defineProperty,Xt=Object.getOwnPropertyDescriptor,Vt=Object.getOwnPropertyNames,Zt=Object.prototype.hasOwnProperty,ta=(e,L)=>{for(var a in L)bt(e,a,{get:L[a],enumerable:!0})},aa=(e,L,a,i)=>{if(L&&typeof L=="object"||typeof L=="function")for(let r of Vt(L))!Zt.call(e,r)&&r!==a&&bt(e,r,{get:()=>L[r],enumerable:!(i=Xt(L,r))||i.enumerable});return e},ea=e=>aa(bt({},"__esModule",{value:!0}),e),vt={};ta(vt,{buildAnestesiSection:()=>Bt,doctorFromQr:()=>xt,formFields:()=>et});function ia(){return window}var wt="RSUD H. Abdul Manap";function Ma(e){let L=e.document,a=i=>{if(i.dataset.tools||!i.naturalWidth||i.naturalWidth<260||i.closest("table"))return;i.dataset.tools="1";let r=L.createElement("span");r.className="img-wrap",i.parentNode?.insertBefore(r,i),r.appendChild(i);let u=L.createElement("span");u.className="img-tools";let s=(l,o)=>{let A=L.createElement("button");return A.type="button",A.dataset.act=o,A.textContent=l,A};u.appendChild(s("\u21BB Rotasi 90\xB0","rot")),u.appendChild(s("Hapus","del")),r.insertBefore(u,i),u.addEventListener("click",l=>{let o=l.target.closest("button")?.dataset.act;if(o==="del"){r.remove();return}if(o!=="rot")return;let A=i.naturalWidth,p=i.naturalHeight;if(!A||!p)return;let N=L.createElement("canvas");N.width=p,N.height=A;let D=N.getContext("2d");if(D){D.translate(p/2,A/2),D.rotate(Math.PI/2),D.drawImage(i,-A/2,-p/2);try{i.src=N.toDataURL("image/png")}catch{}}})};L.querySelectorAll(".dossier-wrapper img").forEach(i=>{i.complete?a(i):i.addEventListener("load",()=>a(i),{once:!0})})}function sa(e){let L=()=>{try{e.focus(),e.print()}catch{}},a=e.document;a.getElementById("btnPrintPdf")?.addEventListener("click",L);let i=Array.from(a.querySelectorAll(".rm-page")),r=a.getElementById("rmSectionSelect"),u=Array.from(a.querySelectorAll(".tab-btn")),s=x=>{r&&(r.value=x),u.forEach(f=>f.classList.toggle("active",f.dataset.target===x)),i.forEach(f=>{let w=x==="all"||f.id===x||f.id.startsWith(`${x}-`);f.classList.toggle("hidden-section",!w)}),e.scrollTo({top:0,behavior:"smooth"})};r?.addEventListener("change",x=>s(x.target.value)),u.forEach(x=>x.addEventListener("click",()=>s(x.dataset.target||"all")));let l=a.getElementById("checkCounter"),o=Array.from(a.querySelectorAll(".rm-checkbox, .vbox")),A=()=>{l&&(l.textContent=`${o.filter(x=>x.checked).length} / ${o.length}`)};o.forEach(x=>x.addEventListener("change",A)),a.getElementById("btnCheckAll")?.addEventListener("click",()=>{o.forEach(x=>x.checked=!0),A()}),a.getElementById("btnResetChecks")?.addEventListener("click",()=>{o.forEach(x=>x.checked=!1),A()}),A();let p=(x,f)=>{let w=a.createElement("button");return w.type="button",w.className="ext-scroll-btn no-print",w.textContent=x,w.addEventListener("click",f),w},N=p("\u2191",()=>e.scrollTo({top:0,behavior:"smooth"})),D=p("\u2193",()=>e.scrollTo({top:a.documentElement.scrollHeight,behavior:"smooth"})),k=a.createElement("style");k.textContent=".ext-scroll-btn{position:fixed;right:14px;width:34px;height:34px;border:1px solid #000;background:#fff;font-size:16px;font-weight:bold;cursor:pointer;z-index:9999;display:flex;align-items:center;justify-content:center}.ext-scroll-btn:first-of-type{bottom:56px}.ext-scroll-btn:last-of-type{bottom:14px}",a.head.appendChild(k),a.body.appendChild(N),a.body.appendChild(D),e.addEventListener("afterprint",()=>{e.confirm("Apakah menu print ini akan ditutup?")&&e.close()})}var Ot=ia(),La=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],St=e=>document.getElementById(e)?.value?.trim()||"",M=(...e)=>{for(let L of e){let a=St(L).replace(/^\s*:\s*/,"").trim();if(a)return a}return"-"};function ra(e){let L=a=>{let i=document.createElement("span");return i.className="fv",i.textContent=a,i};e.querySelectorAll("input").forEach(a=>{let i=(a.type||"text").toLowerCase();if(i==="hidden"){a.remove();return}if(i==="radio"||i==="checkbox"){if(!a.checked){a.remove();return}if(i==="radio"){a.replaceWith(L("\u2713"));return}let u=(a.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,s=>s.toUpperCase());a.replaceWith(L(u?"\u2713 "+u:"\u2713"));return}let r=(a.value||"").trim();r?a.replaceWith(L(r)):a.remove()}),e.querySelectorAll("textarea").forEach(a=>{let i=(a.value||"").trim();i?a.replaceWith(L(i)):a.remove()}),e.querySelectorAll("select").forEach(a=>{let i=(a.options[a.selectedIndex]?.textContent||a.value||"").trim();i?a.replaceWith(L(i)):a.remove()})}function ua(e){try{if(!e.width||!e.height)return!0;let L=64,a=document.createElement("canvas");a.width=L,a.height=L;let i=a.getContext("2d",{willReadFrequently:!0});if(!i)return!1;i.drawImage(e,0,0,L,L);let r=i.getImageData(0,0,L,L).data,u=0;for(let l=0;l<r.length;l+=4)u+=(r[l]+r[l+1]+r[l+2])/3;let s=u/(L*L);return s<8||s>250}catch{return!1}}function na(e){e.querySelectorAll("table").forEach(L=>{if(L.parentElement?.closest("table"))return;let a=Array.from(L.rows),i=a[0]?.cells.length||0;a.length<6||i<4||L.querySelector(".vcol")||a.forEach((r,u)=>{let s=Array.from(r.cells);if(!(!s.length||s.some(l=>l.colSpan>=3)))if(u===0){let l=document.createElement("th");l.className="vcol",l.textContent="Ver",r.appendChild(l)}else{let l=document.createElement("td");l.className="vcol";let o=document.createElement("input");o.type="checkbox",o.className="vbox",l.appendChild(o),r.appendChild(l)}})})}var la=/Rincian Biaya|Resume|Telaah|Laboratorium|Radiologi|SPRI|SBPK/i;function ja(e){e.querySelectorAll(".tabel-juduls").forEach(a=>a.remove()),e.querySelectorAll("h1,h2,td").forEach(a=>{let i=(a.textContent||"").replace(/\s+/g," ").trim();/^RSUD H\.? ABDUL MANAP$/i.test(i)&&a.remove()}),e.querySelectorAll("tr").forEach(a=>{let i=(a.textContent||"").replace(/\s+/g," ").trim();(/^(RSUD H\.? ABDUL MANAP|PEMERINTAH KOTA JAMBI|Jl\. Sk\. Rd\. Syahbudin)/i.test(i)||/^(RINCIAN\s+BIAYA|LAPORAN|FORMULIR)/i.test(i)&&a.querySelector("u,b,strong"))&&a.remove()});let L=e.querySelector("table");L&&Array.from(e.querySelectorAll("hr")).forEach(a=>{L.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_PRECEDING&&a.remove()})}function Pt(e,L=!1){let a=e.cloneNode(!0),i=Array.from(e.querySelectorAll("canvas")),r=Array.from(a.querySelectorAll("canvas"));return i.forEach((u,s)=>{let l=r[s];if(l){if(ua(u)){l.remove();return}try{let o=document.createElement("img");o.src=u.toDataURL("image/png"),o.style.cssText="max-width:100%;height:auto;",l.replaceWith(o)}catch{let o=document.createElement("div");o.className="fv",o.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",l.replaceWith(o)}}}),ra(a),La.forEach(u=>a.querySelectorAll(u).forEach(s=>s.remove())),a.querySelectorAll("tr").forEach(u=>{let s=Array.from(u.cells);for(let l=s.length-1;l>=0;l--){let o=s[l];if(!(!(o.textContent||"").trim()&&!o.querySelector("img,table,input")))break;o.remove()}}),a.querySelectorAll("[style]").forEach(u=>{let s=((u.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");s?u.setAttribute("style",s):u.removeAttribute("style")}),a.removeAttribute("id"),a.removeAttribute("class"),a.removeAttribute("style"),a.querySelectorAll("div").forEach(u=>{!u.children.length&&!(u.textContent||"").trim()&&u.remove()}),ja(a),L&&na(a),a.innerHTML.trim()}function oa(e,L){let a=(e.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return a=a.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),a||`Berkas ${String(L+1).padStart(2,"0")}`}var da=/^(Konsul|Radiologi)/i;function Ut(){let e=Array.from(document.querySelectorAll(".isidalam")),L=new Set,a=[],i=[];if(e.forEach((r,u)=>{let s=oa(r,u);if(!da.test(s)&&L.has(s))return;L.add(s);let l=Pt(r,la.test(s));if(l.length<20){i.push({title:s,docNo:null});return}a.push({title:s,html:l}),i.push({title:s,docNo:a.length})}),!a.length){let r=document.querySelector("#section-to-print");if(r){let u="Detail Klaim";a.push({title:u,html:Pt(r)}),i.push({title:u,docNo:1})}}return{sections:a,inventory:i}}var t=e=>At(e).replace(/[&<>"']/g,L=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[L]),K=e=>t(e).replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).replace(/\n/g,"<br/>"),kt=e=>(new DOMParser().parseFromString(e.replace(/src="data:[^"]*"/g,""),"text/html").body.textContent||"").replace(/\s+/g," ").trim(),Sa=e=>{let L=e.split(/[-/]/).map(u=>u.trim());if(L.length!==3)return e;let[a,i,r]=L;return a.length===4?`${a}-${i.padStart(2,"0")}-${r.padStart(2,"0")}`:`${r}-${i.padStart(2,"0")}-${a.padStart(2,"0")}`},Aa=/(?:Tgl|Tanggal)\.?\s*Masuk(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,ca=/(?:Tgl|Tanggal)\.?\s*(?:Keluar|Pulang)(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,Rt=/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]{8,})/gi;function ga(e,L){let a=[],i=e.map(N=>({t:N.title,x:kt(N.html)})),r=N=>{let D=[],k=new Set;return i.forEach(x=>{let f=new RegExp(N.source,N.flags),w;for(;w=f.exec(x.x);){let $=x.t+"|"+w[1];k.has($)||(k.add($),D.push({t:x.t,d:N===Rt?w[1]:Sa(w[1])}))}}),D},u=r(Aa);new Set(u.map(N=>N.d)).size>1&&a.push({level:"warn",title:"Tanggal masuk berbeda antar berkas",detail:u.map(N=>`${N.t} ${N.d}`).join(" \xB7 ")+" \u2014 samakan sebelum berkas dikirim ke verifikator."});let s=r(ca);if(u.length&&s.length){let N=u.map(k=>k.d).sort()[0],D=s.map(k=>k.d).sort().pop();D<N&&a.push({level:"warn",title:"Tanggal keluar lebih awal dari tanggal masuk",detail:`Masuk ${N} \xB7 Keluar ${D}.`})}let l=r(Rt);new Set(l.map(N=>N.d)).size>1&&a.push({level:"warn",title:"Nomor SEP berbeda antar lembar",detail:l.map(N=>`${N.t} ${N.d}`).join(" \xB7 ")});let o=[/^SEP$/i,/SBPK/i,/Resume/i,/Rincian Biaya/i],A=L.filter(N=>N.docNo===null&&o.some(D=>D.test(N.title)));A.length&&a.push({level:"warn",title:"Berkas inti belum terisi",detail:A.map(N=>N.title).join(", ")+"."});let p=i.find(N=>/Rincian Biaya/i.test(N.t));return p&&!/Total\s+(Biaya|Transaksi|Resep|Jasa)/i.test(p.x)&&a.push({level:"warn",title:"Rincian biaya tanpa baris total",detail:"Tidak ditemukan Total Biaya/Transaksi/Resep pada lembar Rincian Biaya."}),["Laboratorium","Radiologi"].forEach(N=>{let D=i.find(k=>new RegExp(N,"i").test(k.t));D&&D.x.length<60&&a.push({level:"info",title:`Lembar ${N} hanya lampiran gambar`,detail:"Tidak ada teks hasil yang bisa dicocokkan otomatis \u2014 cocokkan manual dengan Resume dan Rincian Biaya."})}),a}var Na="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAIAAAABc2X6AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAb0klEQVR4nOV7d3gUVdv+MzM72zebLdnNJtn03kgIJQQIHRN6AAEVBHn15QWliSIoiqIiIKDYX6VbEJCOdOkkhJJCIL1v+ibZXmZ3yu+PVX4ImLKU77uu7772n/Oc8zznvvfMmVMHYRgGHgaHwzFp/Jjeffo+NPd/M3Jzcg4c+f2fclkdeCb16vPeBx8+AUpPFqtWvttBLvrUePwvQUct7MK3BQd/K7/wFKg8Ot7pNX2oOqnjMp0LLtfXn63LvdeCAMLAw3v+/yxejh7VaZnOBT+Iwb49Kgz1tWatKznUNyFaFnSy5tr8HhO/KzgUKwvKCB64vfiEkyYnBA90lVl65btlSc/naEsPV2XdjfNs6CAUkN3l51f2eTFPW36oKvPtpOfNTtuR6qzFCc9uLzoxPWIEC8WaLG1rbu5anfLK1sJjpfo6l2+af+8TtdfdIO9OH54YknpXCQAkeIVlBA/8uN/LA1RxDDA/P/NekjJi/+iPUn3i/xUz+tX4iTOj0pQ88Yo+M+fEjrs3ziDfhCF+iWI2/70+s+bGjQeA5yNGLE6ckqyMnt9jUpin79z4CQny0PeTZw/0if137Fi1UHHXd0ni1AR5iBvku9HCCp54SeJULsaeGj5ET5hDxD7tduP63N0AECn1V/FlIw8uGeKXWNBa0XvPHM1Le3O15ZN/f++HYW/6bZ08KrBvub4u2TsGQxDq7wNhsnd0ub6ur3cMhiAAIMB5vRThesLsyv255HSkxN9OOlzJWGngcHUSiiCD/BLe6zPzYn1+m83wc9kf9D8Mrg+iGy3cYjP8XHJ6hH8vL54kzFOd6BW2teiYhSQAwEcgRxAkWKwSswUNllaKYVqsOg+2ABAAAECgvyruWFUWzTBRkoD7wvZXxR2vyXZQzhhpEABU6OvGBKWU6WpduZsGLeCy2K02vSt5p72aYqjVKf/GUVZGSOr44AFn63O7rrZ7ggHgVlvVkapMmqEBYGfxSY251WXXE6Yfi07MjEpvtRkDPbzZKOYj9GqzG+86pqhiZ0Slidj8/qpYABjkE//NoIVcDHfQZH9V7AsRI8UcoSurWFcbLPYtN/zZV4ftW5irLcsISXUlGYAvbx08U3vDlZx3fmO9pa1bErrdh5O9o4cfWPz8iVUj7hkAclrKfrhztJ8qtsrYECL2a/zXAQxBLzfccuXiCNbHO2pb0bErDQUuVXbK8e+48S9EjizV1fbxjtpedPxyw62/BNdUGuodNOXy3TNqVX+f+Pq/XpAAIMJ5ERL/UYfe/LHoxPjgAd3l3723NJ/FmXx8pdZmAIDMxtsu4+WGW42W1symwrcuf6MjzKMOvzkqsN+vpX8YnbYSneaTGz+J2PxV2ds/y/stVhYULwsGgOzm4rlnN3jxPfeUXxDivI15v8VIAxPkIefrcrOa7tSYmk0OW6Wx8d2sHzAEa7C07am4oBBIyw31ACDlivrtnddqNx6vvZ7kFdpdwUgHc+nVH656/8OPllz6emPe3kR5iIjN7270p4bbbdXthOmXke88FzFi1cp3O5gRd7WFvx78ej9VzGOi9/gx+vDSYzXXulKye490iZ5ss9NuUXpS8OajwR7dUNE9wdeaHQVtzm5SerJI9mZ3S/D/udWS+4JJu5UkbO75tpXlW7X1blf9KHBn8QAATotR/+18hs1DU59jaIqhaYahgWEYmmZoyvUDmmEY6q7lr1zaqCmz6Zrs+jZ5RE+Oh9TlDjTFMHd9GVwoDp+y+PFKdcFNwY72JtRTAQDIjaP3mBFAALHolZbmu8mHAwWQYnRzXn5+W4JKhiDIPSEAAOhmxnYYYeRqp8QP9Q7iShT/EKjbcFOwQB0uePnTh2Y5dC2GK3tFrdV/NzMAYGlt5Mu875UXLAss1lRGhEa4yvCMzYh3MGNsxXSNXhWXoQIAwEFRJpbAoQpzqCId6hi+fxSCYe7RBrcFdwC2RAFjXiUfsDstxspTv0Rl/OdeIw9AdCdbQ9hUPQcDQGt5Ln7xJ5LGHc8s5ub8jvI9vDU5bAyTMXZoKICGAubGXj2wzL6xMPFNDOe4Qe/xC/4nlJ/8OXz0rAftipi+JYc3y8IT2EJPTmgihCSwEWADAvGpAFBTliM6t0XxZx8BBAEJkJKGvDJNiSA43g0aT0lwe0WB2D+CMOm157apuVdkHA0gtJ7wrbEmS3pMCE2bXnp0e9TE/wAAIH/r97ywns7gHpXZh+XX9nowjrt2zNzuHpOnJLju6gm5hBggmTlhsZnLuTt7v02SJ4+fWvfbqRlcSV99dZFnYNSDvgiGcVMydPFDDOd2KEovclAE4P7/pet4GhOPloIsWduWL+dtnDbJ5FJLUiKSEgEAiwVjR9m+ff2HQPtX5ad+6SAILvTExi6sn7q60TOQpGlG5ucemSfewgzDMAWfbv6mmcdlKJrX1DxWp+9PUh4ACAszSCVXlIojfL5tzdLc2XOqdZXTJMEdLVG4fhHMS+srS28KfdzZ0IKn0MI15w/Mn3aJx2UcTmlZ2XKjoS+XY/QQVXqIKjgck16fUlb2jtPpiWGwYa2h6fKOrsQUhney+dwBnrhgr/avevV0AiDVNa8iCC4UaDzZ+TLjcZnudwlyVSjQoAhSXTsHAJHL6NTA/ZS709Uu4skKNjVUjR90BwAMxgSHQ8XhGoVIMTsnl7zEcV7i49mVHtYsNtdIEAEGUxwAPDPU0FLozm5z1/FkBetrS2OiSQAwmuIxFsFmm1n1lUSFj+2WyJYrslcoscpGNm7GWHaTKR4AoiJIc2P1E6X0ZF9aTqtFJKIBgKRECEqhqBPsFGNnUW0oYwVahTE2FAUCQWiS9AAAnM2gtOWJUnqyLcz18GxrQwEAx3UMjVEUjsg5LC8LO8LBiXXiSjuiQCjgMwwLx3UAYLUiwJbcF6ROm/uQ0O7iyQqWBMfm5eMA4OlxkyS5TgefUMSyE9oFCTX8nhpujzpHcJzDISKdXLH4BgDk5eOSkPuHpQuNOw3mx7Z4fjyPNEORDEOjLPY9JpomSZ5UcenmgAw4IxQUC/l3CLsfIIzTX4Kr2xGasqEygvAg7GKBoFDILwOA01fDpINj742MIIieaDISLWKh72Oh+hgEMxRpObguwFuu9U9B1X/S1R3eFCLltqqS2rwXZ169mJLs8FdvraxeaLH4OxxmFPMFAJrCnU4+l1Mb4P8DAJSUsUrwN/wAqW+/VabPJmnCTxQdqRhCMxQA1LblFOsuMwydoEhXiiPcZvsYHmnSakwID+w1cChLk++yMAydFOQdk5QsaS9Txvb75sy8xiYMw6yhIWuVin2AWK02pdWmAMSqVB4IDv4MQ20GI/rJz5P9+k+obsoq0WVSjLPBWnpUs2lX/iIOar5Q/dmeyg8Mpjqadv5esUGjy3ObrfstbG2uJW1mnkKNi6QWvtfPWaUUS4bmnfcMS8QFYtI7Ys+V2x4x/RlNmWrUu0u/t741eWtsNCmXnZPLzt0XqroG+2DrBNnozwGQQGVyXXVJpfEGQVowJ+IrvhPtQWBc86/F4hZS02puGOI3W4RJn65ghsHtej99cfaBHU6ng5IHOtOnK1pPOz19ay+fajywCWT+5mdeCGFbtBadMCwJAFTj1n1yfkDUmY8njqyIiiDvLnUqq1gHTvrcsL2pnjDdtQBq1BXqHU1x4iE1xjwexRNQRRRBoxiK0iiDIhyKc6l626zE/z5VwX5MexK3IVNbKZfLRqaPriwvKz21OSw8vLH2lpDPGztuXJtWW5q1u0XqI9CdsIm9eAp/APBNGWegRn2SlUkdyJZyNAhl0ZEhjKy3d1Kq+p69C6U4IoaxnKr9dpjPv260HHJgE49qj4fwElhc7VDv6fW24or2awjifk/snmAMAQCoQ2UOGsPEXoBgZ06e6D9wYEN9PY/PDw+PqKquzrpypV+/FIDiHgFKs9msuXmAHvkqirEAAMFYqsRUgFQOofFiSuu4wx6sAsVYpdpLUyM+ymv6PUI6gKCs7YCHcIMmBczL0uxKj3xTzY9m4dzHLxhBENfO270LbSH+51/bi2cUpvTFSDuLdko8JSPT0m4XFMTGxYeGhVVXV4s8RJOnTrt0/nz/gakRBJFvqDZI/3bMx2UM/nC1Dh4iGAAGB73C4XiEi/v5yOKKmv4AAItT5ynwS/aZAgAh3gPvLcx6YCfgn44HOxGM4zhBOABAzvMEAKPDDABS7p/R8xySUWL72PRnjEajSCRCUTQ4OMRVj1zuJRSJ2Gy22k9NEATGwjCCc+7vSyAT4hNLH8xk3n7oxgWH4wEAPrI4ABio7j0mYCGJhNfYQeJx/+0BAPBgIwCgI8wAoBLIAcBut7sjGP76q6KlAQBwq7XymYC+fBZyRuOa66L7q5GxXnYpm92kdZzRYmaK44E6+4usvnzMaqROtTjanJgI48pxyglU9f0zZO5imUZC5Ou4CR0QAACFSDorMuNCPVFT83AZCh5KMfTttkoAiJYGAkDHFyA6EiwUCU0mU6JXOABcbboDAFESvERHWElXSORSG+/vHpyzuvu2TjEAHAAA/kaXQ9t5SqeYbtBBJ4I7hb+IVdBabnLa/YVeCr6kVauVy+UdlO9IcGJiz9ycm6mDBquFXufr8ymG5rHQncMVbXbqEVmKW7dYQF6LD3rEOD4CTIgjZzU5AJCiigOAG9evJfXu3YFLR+/3vsn9rmZmAsBQv8R2wnSl4RYAqIWsNjv9iL9IOKmnlDQmeETB8TIcAI5UZwLAcHVPALiWfbXjG8AdtbDcy0urbQGA0YH9dhSf2l12LtU3QcZD381upx7t5iEhC1imPqkkMps5KW4HQRFIUuD1Zu2lhgIMQdIDkxmGMZlMQqGwA69OxuGAgMCqqsr0wGQhi/tr6R+fDpgbIuZa5wa5zdIFa+vLSOn30fSRZnBfcJwMF7PRr/NPUAw9yCfeRyC/lZ8XG9fJcUQngseOn3Bg/75Fry+ZGJq6s/jUj0Un58SNr9A7p55ocZsoALwm+nmmBBqROLcjIADD/DhOmvzu9mEAmBWVBgBHDh2aM+/Vjh07a+HAQE1tDUVR8+Im7Cw+9WnOr7NjRkdJ2cPUvAqDu3cfHKYpom8dFFbEmuTm8QFALwXbm49tKzymMWvlXI8p4cNsNpvJZOr4FQ1dmVqmpY86dvTI2PETUn3iLjYUbL59ZG58xsaBskYLSbt1v8XpFNAFXB5mDCWWNaCqjgsbLezz1R61JhvvnpGcwxKnBSyxU44Pr+0EgPnxE/kszs6ftk169tlOa+9c8LARIxfNf3X02HEf9J095MDi97K3PRs2VM4T//e2adV1XafuD8X7smnL1N/HMftaGWXHJU1WuGIFALhnMwXGBK0T4dgn13+pMjXJuKIFCZMdDkduzs0XZ73UadX/eDHtXpw8fsxqtWZMmjz+6NuHqzJnRAzfOXKFk2ZyWhyd+j4UgoZPw6zv1gmeI/ymd9dXxFGqPZLK9fU9ds22ksSmga8tSJi8dfMPsbFxfZKTO3Xv0mppZFr64gWvjUxL25Q6/2xdzo8lZ8YEpkwJH9pbyVl7U+/GPOQV+g8Ggf1tVx3mG91ylPNDZiXsJWlq1unVVpLo6RU6Lz6jrbW1tKR49suvdCVClwQjCPLagkWfb1j/znvvb+g/b875ja+cXR8vD4mUBvT15ryT1f6PdzkeBj/isr//BQAIlw1ni7y74QnQ1/dfHEy47Mp3V5rucDF82/DlLBTb8Onaha8v6WKELj3SLnz/3beRUVEDBw2aevz9veUXwsS+V5792ovnyQB0/QsIwlxBFgzE6UYAMKPB1/EELadLi1sOSzQ67GMBLvul5PT0Ux8zAN8MWjQ3fsLhgwftdtuUac91kUA3BNM0/cbihW8uWy6SSwb+9lpea0UfZeSpCRvEbMGxauuM0y1EZ/OvcCjc5LOsgfIyEtxJXiduOcXBbFsBLcrnyDp25LJE02K3+Iji/9DcGH1kOUE5X4ke9f2wpZUVFZu//2712odfr3kouiEYAPR63Yrly9at36hnbAP2vVZlbErxjj42bp2YI7zWTJToHP98UeluhQAMhDe93IO1u1S5EfEIcRAmDk/cgYeQrQgQ9wZAzmlyxh5dbiGJ9IA+h8asthrN7yxbum7jZ3x+N+bk3RMMAJWVFV9t+nzt+o0aq3bI/kW15pZEecjRcWt9BHKagUsNtjL9gzd47oe3ds0I1uoddj8th9dxSbW418TITUK21+HKy8+d/NBKEsP8Eg+P/QQlYenri5etWOHj070N+m4LBoA7twu2bdm8eu2nTYQu/dDSQl2NWijfN+rD3sooi5N+/VLbbxX/eCCG0s5e9JkFqi1D5TfzZStRcUc3vHGMG6eYgCCsTbl73rjyHcXQ44NSdqWtREhm+dI3Xp2/MDQsrLvkuyo48/wBX/+ogOBIV/LO7dubv//uo0/WOFjM1OPvn9bc5GL4+gFz58VPRABIGgCA9bClp9Nht2fJ2JgVAA45Q+u4ng+tTiGIGBmyQiGINDos/zm7flfZOQBYEJ+xYeBrNov1nWVL5y9cHBYeDgAkSZ469EXv1BleXl6PU/D1S7tl7S81sN/tO/wNHMcBoKa6+tM1q5eveM/b12fl1a1rbv5CMXS6f+//Dn1DLVLSDPyhsa3L0bc+MErHOg9OEv3qrWAKcTGFPfivoAnek5JU01EEO1+XM/vM2ipTs4DF/XrwoplRaRpN7ZqPP1q+4l0/PzUAVFcU1mXPRsm6fjM0SNfu9XRVsMloqjqmDvM13NQk+6fs8A8MB4DqqqovN302fsLE1MGDL9TnzT6zptLYJMJ5K/vMnN9jEhvDDQ568x1Tq51io39jwzB0qvKn+4w83DNOkcFliQCg2dq+PPP7HUUnaWB6KyJ2jng7Uhpw8cL5Qwf2L1j0ekBgIMMwWX98qzQv9ZNbcg2vJ4/e0BUV3RAMAFePzEuUfAsANVqRXvoV38PXdGsKov40r8hqMBgWLVlCosz72du+yN/voMkwsc+q5NnPhg3FEJRiIKvRvqXQlN1sd9WGIMwL/sPvRlYJ4xJVU2MV43CUa3JYvsjft+7mLqPTJsS5K/vMXJQwhSapLz7bwGZz4oPbmNYd/oPO1t54u5f3fjaL0ZlQc8it0PCufp7QJcHNzc31NSWakv1pQZtclsY2rKZFmBxlsDuQXO1ERDFv757dM16c1bdfv6L2mrcyvztSlQUAURL/NxKnPh85gouxAaBc7zxYaTlea7vebFsWM0oljAuTDomUp8n5wQDQYtV9W3Dwq1sHWu1GFEGeDx/2Scq//YSK3JycLT/8N33USLFpYy91JoLA0avCMcl/frqWXyVBQ7aLpOEhoSEsFv5IgimK2rfjbX/Obwp+ja/X37ri5QL2gDgHw0BBJR4f4ixu8HH6fZVb0FRdXf3qawt8fH2zGu+surb9ZO0NBhgvrvilqLRZ0elR0kCXO0kzJG12Pb00Q1+oy9tadOy38gt2yokiyLjAlPeTX+ohD21rbf3qy01SqTQxWiQ3vaEUG/kcBgBMVqSqkRUf8v8X5BY7UtkosuLJ3MC3+yR3tDfYSQvr9fo7WZskls9CvA13jXnleKgvKeQxDANz13uO6W9P62u3Eegd0yyfuLd2/fwjh8N9Zc5/pDJZnrZsY+6ePeXnCcqJACTIQyeHDhoX3D9GFkzS5JWGgkOVl/dVXNSYtQDAxfBpYUOX9JwaKwu2WMzbtmxubGiY+tzz7SVrE2S7a5sxsw2pbWZlpNoAoKASD/AmPfh/kqcZyNNEsQM/SkyegKId7Ux26ZFuaWkuyVwZjG+Ri0mdGa2oZ/WKcADAkStcXy/q8i2OB59OSya8pVRhvZoJ+EKq7LFl8/cCPn/GrJd8ff20Nt32whPbi44X/vVFoa9AZnJYjc4/zyOiJP4vRafPikr34nnq9bqfdu6oramZ+dK/HOYKpPbVKJ/6Q5e4UUHkN/sEFI3MzTBHB5Lw11MGAOVNMoP4/d6D57iGj47RjZdWaeF1bd5cFT+vphnzkVEBSmrPOd6NInZTG/ryOOvRy9xxqfaB8YTFjtxunxCcvAHB8J92bNfr9eMmZCT3SwEEclpKfi09+1v5hWpTMwD4C70mhw6aFj6slzISAaSkuHj3rl9I0vn8jBc9xR6ll1+P8dzLwWHfBa6TRAqrWBEBpLeUFvHp/nGO8npWaR0rNZ64rX8+etAGL0UnGwnuCAYAp9N59dQ6c9WaEJVNq8eiApwUhazfJRTwmMIq1svjLCeyuO/NNuEspr6V34QviEl5k8PlHjl0MPtqVkhI6LiMDLXanwHI15ZRDN1TEY4AYjDofz9y5Mb1a2Fh4VOmPcfl8fIufSGzrJGJTD8cFtgIJL2f/U4lfuIqZ2QfYkgS4a+grhayVTK6uEHp3+erxOQJXeffbcEuFORfL7nwSvSAD5srDvaQbKvXYtVN2NkbHMKJyD1pfwXVO9rBwSFIRZY2SE2ieSGJ85Teqory8sOHDtRpNJGRUSPT0j3E4j9On7qWnS0UCkaNHpvUu7fRaCy8tpXdtiHat37fOV5NM0bRSEaq7fhVbmMrOm6gPSXW0WZklZFvCensW+XYqBlblUqf7pJ3RzAAMDSNoCgA3Li8m988z1+uO5fDbjeitU2s4hqWxINeOdu0abdgepo1SEXVtnBbkTEsr6mhMcMkEklJcfGpkyeMRsOwYSN69+1LEERxwWVHy16BdW+4r+FSPvvyLY7Bgqhk9Mx069aj/PED7c06NCXWcbsuiBe1LbrHIJvNhuM4i+XOab6bgu9FY4Om9OKcnt4n9GbkZDY3XE0aLYjZimoN6MVcdnoKMWWIjcViAKC6kWOgIhBeBMJWACCMs52xlXPpO2G+FgyFAxd5PcMdJ65yWw0oAyDiM1IPOrUHoVZSJitaZJ6dMHy9WNzRQvIpCQYAhmGuXdjB1y4NV2kr6llqJfX5bkGoH1Vcy+KxmVfGWRZ87rnqZaPNjnhJaLGQdh22MwBaHeogkXotllnA5nEZnRGdm2HZtEdgsKCDE4mEMKe/ksrXhPLCv4lLGvHoPOFxCXahtVVbdGlFEHurzIO0E0hJLevwFe6ofkRFHXb6OjdcTY4ZYP9yj0CrRwNVFADgLCbYh2KzmSOXuNNG2KoaWMmxDg7O2AlELKQTwpy1Wn4z+42eQ97i8x/bl7yPU7AL5SX5TfkrwsXHPPj0nSr8+FUOGwcMZdoM6PxnLfM3irk4SDzoUD+yrI6llNBFNSyZBx0RQCIINLWiC6eYRXymRY/XOJ4L6v2Brzrw8dJ7/IJdKLqdrStd74MdUsmchBMx25BbFbhESNsdiNmGVDWwKAZ0RlTTjC2aaj6Xw5k6zMZlM1w2U9vC1aJTvWOXBodGPwliT0qwC3WamrrCnUzbr0GSYonoz4MZowWtbsRUcqrNgIb7k641YrsJrdbFIF4vBMa96O3dyfnLo+DJCnaBYZjKirL2uvOM+RpjKwJCA5QRgAHMA9h+CD8aEfaVqYcEh4RCtza43cL/A+p9uOR8npnAAAAAAElFTkSuQmCC",ma=[[/^Triage/i,{id:"triage",code:"TRIAGE",tab:"Triage IGD",option:"Triage \u2014 Pengkajian Awal IGD"}],[/PENGKAJIAN INSTALASI GAWAT DARURAT/i,{id:"pengkajian-igd",code:"PENGKAJIAN IGD",tab:"Pengkajian IGD",option:"Pengkajian IGD \u2014 Lembar Pengkajian Instalasi Gawat Darurat"}],[/^SEP$/i,{id:"rm-01",code:"RM. 01",tab:"RM. 01 SEP/CBG",option:"RM. 01 \u2014 SEP &amp; Berkas Klaim Individual (INA-CBG)"}],[/^Surat (?:Rencana )?Kontrol/i,{id:"surat-kontrol",code:"SURAT KONTROL",tab:"Surat Rencana Kontrol",option:"Surat Rencana Kontrol \u2014 BPJS VClaim"}],[/^SBPK$/i,{id:"rm-02",code:"RM. 02",tab:"RM. 02 SBPK",option:"RM. 02 \u2014 Surat Bukti Pelayanan Kesehatan (SBPK)"}],[/^SPRI$/i,{id:"rm-03",code:"RM. 03",tab:"RM. 03 SPRI",option:"RM. 03 \u2014 Surat Pengantar Rawat Inap (SPRI)"}],[/^Rincian Biaya/i,{id:"rm-05",code:"RM. 05",tab:"RM. 05 Billing",option:"RM. 05 \u2014 Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi"}],[/^Resume/i,{id:"rm-06",code:"RM. 06",tab:"RM. 06 Resume",option:"RM. 06 \u2014 Ringkasan Pulang (Discharge Summary)"}],[/^Telaah/i,{id:"rm-07",code:"RM. 07",tab:"RM. 07 Telaah",option:"RM. 07 \u2014 Formulir Telaah Resep, Obat &amp; Edukasi"}],[/^Radiologi/i,{id:"rm-08",code:"RM. 08",tab:"RM. 08 Radiologi",option:"RM. 08 \u2014 Hasil Pemeriksaan Radiologi"}],[/^Laboratorium/i,{id:"rm-09",code:"RM. 09",tab:"RM. 09 Lab",option:"RM. 09 \u2014 Hasil Pemeriksaan Laboratorium Patologi Klinik"}],[/Konsul/i,{id:"rm-10",code:"RM. 10",tab:"RM. 10 Konsul",option:"RM. 10 \u2014 Lembar Konsultasi Antar-Spesialis"}],[/^Persetujuan Tindakan/i,{id:"form-konsent",code:"RM. 19A",tab:"RM. 19A Persetujuan",option:"RM. 19A \u2014 Persetujuan Tindakan Kedokteran"}],[/^Anestesi/i,{id:"form-anestesi",code:"RM. 21",tab:"RM. 21 Anestesi",option:"RM. 21 \u2014 Laporan Anestesi"}],[/^Fisioterapi/i,{id:"form-fisioterapi",code:"FISIOTERAPI",tab:"Fisioterapi",option:"Fisioterapi \u2014 Assesmen &amp; Terapi"}],[/^Pengkajian Hemodialisa/i,{id:"form-hemodialisa",code:"HEMODIALISA",tab:"Hemodialisa",option:"Hemodialisa \u2014 Pengkajian &amp; Sesi"}],[/^Operasi/i,{id:"form-operasi",code:"RM. 20",tab:"RM. 20 Operasi",option:"RM. 20 \u2014 Laporan Pelaksanaan Operasi"}],[/^Surat Kematian/i,{id:"form-kematian",code:"KEMATIAN",tab:"Surat Kematian",option:"Surat Kematian \u2014 Surat Keterangan"}],[/^Permintaan Terapi/i,{id:"form-terapi",code:"TERAPI",tab:"Permintaan Terapi",option:"Permintaan Terapi \u2014 Rehabilitasi Medik"}],[/^Uji Fungsi/i,{id:"form-uji-fungsi",code:"UJI FUNGSI",tab:"Uji Fungsi",option:"Uji Fungsi \u2014 Lembar Uji Fungsi"}],[/^Partograf/i,{id:"form-partograf",code:"PARTOGRAF",tab:"Partograf",option:"Partograf \u2014 Pemantauan Persalinan"}],[/^Laporan Tindakan/i,{id:"form-laporan-tindakan",code:"LAPORAN TINDAKAN",tab:"Laporan Tindakan",option:"Laporan Tindakan \u2014 Pelaksanaan Tindakan"}],[/^Bon Makan/i,{id:"form-bon-makan",code:"BON MAKAN",tab:"Bon Makan",option:"Bon Makan \u2014 Pasien / Pendamping"}],[/^PEMERIKSAAN$/i,{id:"form-pemeriksaan",code:"PEMERIKSAAN",tab:"Pemeriksaan",option:"Pemeriksaan \u2014 Hasil Diagnostik"}]],wa=(e,L)=>ma.find(([a])=>a.test(e))?.[1]??{id:`doc-${L+1}`,code:"FORMULIR RM KLAIM JKN",tab:`RM. ${String(L+1).padStart(2,"0")} ${e}`,option:`RM. ${String(L+1).padStart(2,"0")} \u2014 ${e}`},W=e=>`<div class="kop-surat"><img class="kop-logo" src="${Na}" alt="Logo Kota Jambi"><div class="kop-text">
<div class="kop-line-1">PEMERINTAH KOTA JAMBI</div>
<div class="kop-line-2">DINAS KESEHATAN</div>
<div class="kop-line-3">RUMAH SAKIT UMUM DAERAH H. ABDUL MANAP</div>
<div class="kop-line-4">Alamat : Jl. Sk. Rd. Syahbuddin Kel. Mayang Mangurai Kec. Alam Barajo Kota Jambi 36129 &#9742; (0741) 670459</div>
<div class="kop-line-5">email : rsud_ham.jambi@yahoo.co.id, rsud@jambikota.go.id, website : rsud.jambikota.go.id</div>
</div></div><div class="kop-double-rule"></div>`,n=(e,L,a=!1)=>`<tr><td class="lbl">${e}</td><td class="col">:</td><td class="val">${a?`<strong>${K(L)}</strong>`:K(L)}</td></tr>`,Yt="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDEuNjMgMzEuMDIiPgogIDxkZWZzPgogICAgPHN0eWxlPgogICAgICAuY2xzLTEsIC5jbHMtMiB7CiAgICAgICAgZmlsbDogIzAwYTU1MTsKICAgICAgfQoKICAgICAgLmNscy0zLCAuY2xzLTQgewogICAgICAgIGZpbGw6ICMwMjNmODc7CiAgICAgIH0KCiAgICAgIC5jbHMtNSB7CiAgICAgICAgZmlsbDogI2ZmZjsKICAgICAgfQoKICAgICAgLmNscy01LCAuY2xzLTQsIC5jbHMtMiB7CiAgICAgICAgZmlsbC1ydWxlOiBldmVub2RkOwogICAgICB9CiAgICA8L3N0eWxlPgogIDwvZGVmcz4KICA8ZyBpZD0iTGF5ZXJfMS0yIiBkYXRhLW5hbWU9IkxheWVyIDEiPgogICAgPGc+CiAgICAgIDxnPgogICAgICAgIDxnPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTAyLjkxLDE1LjFjLS44Mi0yLjQtMS42NS00LjgtMi40Ny03LjJsLTEuODYsMi4zMnY0Ljg5YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjksMC0xMS4zNywwLTE3LjA2aC42NGMuMzEsMCwuNTcsMCwuODcuMDUsMS4wMi4xOSwxLjQ5LjksMS40OSwxLjl2NS4zMmw1LjMxLTYuMzlDMTA0LjY0LDAsMTA1LjA3LDAsMTA2LjI5LDBoLjQxYy0xLjQsMS44LTIuOCwzLjU5LTQuMiw1LjM5LDEuNDMsMy44OSwyLjg3LDcuNzgsNC4zLDExLjY3aC0uNDdjLS42OSwwLTEuMzUuMDMtMS45OC0uMjYtLjQzLS4yLS43OC0uNS0xLjA0LS44OC0uMTgtLjI2LS4yOS0uNTMtLjM5LS44MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTExNy45NCwxNC44NmMtLjc1LDEuNjItMi41MywyLjIzLTQuNDMsMi4yMy0yLjk0LDAtNC41NS0xLjYxLTUuMjctMy43Mi0uNS0xLjQ2LS42Ni0zLjI4LS4zOS00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjcxLTMuMTUtMy45OC0yLjgyLTQuNzQtLjAyLS4xNS41NS0uMjQsMS4yNC0uMjYsMi4wNWg1LjI3WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTIyLjkxLDE1LjAzYy41My4zNSwxLjE3LjUzLDEuOTEuNTNzMS4zNS0uMTgsMS43My0uNTVjLjM4LS4zNi41Ny0uODMuNTctMS40LDAtLjQtLjA2LS43My0uMTktMS0uMTMtLjI3LS4yOS0uNS0uNS0uNjktLjItLjE5LS40NC0uMzUtLjctLjQ3LS4yNy0uMTItLjUzLS4yNC0uODEtLjM0LS42MS0uMjItMS4xNy0uNDYtMS42OC0uNzEtLjUxLS4yNi0uOTUtLjU1LTEuMzItLjg3LS4zNy0uMzItLjY2LS42OS0uODctMS4xMS0uMjEtLjQyLS4zMS0uOS0uMzEtMS40NiwwLS42Ni4xMi0xLjI0LjM1LTEuNzMuMjMtLjUuNTYtLjkxLjk4LTEuMjQuNDItLjMzLjkxLS41OCwxLjQ5LS43NS41Ny0uMTcsMS4yLS4yNSwxLjg3LS4yNS44MiwwLDEuNTkuMTMsMi4zMS40MS43Mi4yNywxLjI0Ljc3LDEuNTgsMS41LS45Ny42OC0xLjYuMTktMi4yMS0uMDMtLjExLS4wNi0uMjMtLjExLS4zNS0uMTYtLjM0LS4xMi0uNzEtLjE4LTEuMTEtLjE4LS4zMiwwLS42My4wNC0uOTMuMTEtLjMuMDctLjU2LjE5LS43OS4zNC0uMjMuMTUtLjQuMzUtLjUzLjU4LS4xMy4yMy0uMTkuNTItLjE5Ljg1LDAsLjU1LjE3Ljk5LjUxLDEuMjkuMzQuMzEuNzYuNTYsMS4yNy43Ny41MS4yLDEuMDYuNCwxLjY0LjU4LjU5LjE4LDEuMTQuNDMsMS42NC43My41MS4zMS45My43MSwxLjI3LDEuMjEuMzQuNS41MSwxLjE3LjUxLDIuMDIsMCwuNjQtLjEzLDEuMjItLjM3LDEuNzMtLjI1LjUxLS41OS45NC0xLjAzLDEuMjktLjQzLjM1LS45NS42Mi0xLjU2LjgxLS42LjE5LTEuMjUuMjgtMS45NC4yOC0xLjE2LDAtMi4xNS0uMjEtMi45Ny0uNjQtLjgyLS40Mi0xLjQzLTEuMDctMS44MS0xLjk1LjMyLS4yLjgzLS41LDEuNDktLjI2LjQ0LjE2LjcuNDksMS4wNy43NFoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE1Mi43MSw2LjcyYzAtLjctLjE2LTEuMTctLjUtMS40My0uMzMtLjI1LS44NS0uMzgtMS41Ni0uMzgtLjU4LDAtMS4xMi4xMy0xLjYyLjM4LS41LjI1LS44Ni41My0xLjA5Ljg1djkuMDZjMCwuOTUtLjQ1LDEuNjItMS40MiwxLjgxLS4yOS4wNS0uNTMuMDUtLjgzLjA1aC0uNjFWMGguNjFjLjMsMCwuNTQsMCwuODMuMDUuOTcuMTgsMS40Mi44NSwxLjQyLDEuODF2MS4yNmgwdjEuNThjLjM3LS40NS45Mi0uODQsMS42NC0xLjE4LjczLS4zNCwxLjU3LS41MSwyLjU0LS41MSwxLjE2LDAsMi4wMi4yOSwyLjU5Ljg2LjU2LjU3Ljg1LDEuNDYuODUsMi42NnYxMC41NGgtLjYxYy0uMywwLS41NCwwLS44My0uMDUtLjk3LS4xOC0xLjQyLS44NS0xLjQyLTEuODFWNi43MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE2NC44Nyw5LjI5Yy0uMzIuMTYtLjcuMjktMS4xNC4zOC0uNDMuMDktLjg1LjItMS4yNi4zMi0uODEuMjMtMS4zOC41OS0xLjc0LDEuMDctLjM1LjQ4LS41MywxLjExLS41MywxLjg4LDAsLjg3LjE3LDEuNTEuNTIsMS45MS4zNS40Ljg5LjYsMS42My42LjU2LDAsMS4wNi0uMTMsMS41LS4zOS40My0uMjYuNzctLjYzLDEuMDEtMS4wOXYtNC42N2gwWm0uMjIsNS44N2MtLjMyLjYtLjgxLDEuMDYtMS40NSwxLjQxLS42NC4zNC0xLjQuNTEtMi4yNy41MS0xLjMyLDAtMi4zMS0uMzMtMi45Ni0uOTktLjY1LS42Ni0uOTgtMS41OC0uOTgtMi43NnMuMjYtMi4wOC43Ny0yLjcxYy41MS0uNjMsMS4zMS0xLjExLDIuMzktMS40NC4zNS0uMTIuNzMtLjIxLDEuMTItLjI3LjM5LS4wNy43OC0uMTMsMS4xNi0uMi4zOC0uMDYuNzQtLjE0LDEuMDktLjI0Ljc5LS4yMi44Ny0uNDIuODgtLjk4LDAtLjI2LDAtLjUyLDAtLjc3LDAtLjcxLS4xNi0xLjI1LS40OC0xLjYxLS4zMi0uMzYtLjkzLS41NS0xLjg0LS41NS0uNjgsMC0xLjI2LjEzLTEuNzUuNC0uOTUuNTItMS4zNy45NC0yLjYuMzQuNDctLjgxLDEuMTEtMS40LDEuOTItMS43Ni44MS0uMzYsMS42OS0uNTMsMi42NC0uNTMuNjgsMCwxLjMyLjA1LDEuOTIuMTQuNi4wOSwxLjEzLjI4LDEuNTcuNTQuNDQuMjcuNzkuNjUsMS4wNSwxLjEzLjI2LjQ5LjM5LDEuMTIuMzksMS45MXYxMC4zM2MtLjA3LDAtLjQ1LDAtLjc3LDAtMS4zNiwwLTEuNzgtLjcyLTEuODEtMS45MVoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE3Ny43OSwxNi4xNmMtLjQ1LjMzLS45MS41Ni0xLjM5LjctLjQ4LjE0LTEuMS4yMS0xLjg3LjIxLTEuMjIsMC0yLjE4LS4zNS0yLjg3LTEuMDQtLjY5LS42OS0xLjA0LTEuNjUtMS4wNC0yLjg4VjQuMzloLS40NmMtLjc5LS4wMi0xLjIxLS4xNS0xLjIxLTEuMzhoMS42N1YwaC42MWMuMywwLC41NCwwLC44My4wNS45Ny4xOCwxLjQyLjg1LDEuNDIsMS44MXYxLjE1aDEuNjdjLjc5LjAyLDEuMjEuMTUsMS4yMSwxLjM4aC0yLjl2OC43N2MwLC43Ni4xNywxLjM1LjUsMS43Ny4zMy40Mi44Ni42NCwxLjU4LjY0LjI2LDAsLjUtLjAyLjctLjA1Ljg0LS4xMywxLjI1LS4wMSwxLjU3LjY1WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTk4Ljc4LDYuNzJjMC0uNy0uMTctMS4xNy0uNS0xLjQzLS4zMy0uMjUtLjg1LS4zOC0xLjU2LS4zOC0uNTgsMC0xLjEyLjEzLTEuNjIuMzgtLjUuMjUtLjg2LjUzLTEuMDkuODV2OS4wNmMwLC45NS0uNDUsMS42Mi0xLjQyLDEuODEtLjI5LjA1LS41My4wNS0uODMuMDVoLS42MVYzaC42MWMuMywwLC41NCwwLC44My4wNS45MS4xNywxLjM2Ljc4LDEuNDEsMS42NGgwYy4zNy0uNDUuOTItLjg0LDEuNjQtMS4xOC43Mi0uMzQsMS41Ny0uNTEsMi41NC0uNTEsMS4xNiwwLDIuMDIuMjksMi41OS44Ni41Ni41Ny44NSwxLjQ2Ljg1LDIuNjZ2MTAuNTRoLS42MWMtLjMsMC0uNTQsMC0uODMtLjA1LS45Ny0uMTgtMS40Mi0uODUtMS40Mi0xLjgxVjYuNzJaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xNDIuMTEsMTQuODZjLS43NSwxLjYyLTIuNTMsMi4yMy00LjQzLDIuMjMtMi45NCwwLTQuNTUtMS42MS01LjI3LTMuNzItLjUtMS40Ni0uNjYtMy4yOC0uNC00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjctMy4xNS0zLjk4LTIuODItNC43NC0uMDItLjE1LjU1LS4yNCwxLjI0LS4yNiwyLjA1aDUuMjdaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xODYuMjYsOS4yOWMtLjMyLjE2LS43LjI5LTEuMTQuMzgtLjQzLjA5LS44NS4yLTEuMjYuMzItLjgxLjIzLTEuMzkuNTktMS43NCwxLjA3LS4zNS40OC0uNTMsMS4xMS0uNTMsMS44OCwwLC44Ny4xNywxLjUxLjUyLDEuOTEuMzUuNC44OS42LDEuNjMuNi41NiwwLDEuMDYtLjEzLDEuNS0uMzkuNDQtLjI2Ljc3LS42MywxLjAyLTEuMDl2LTQuNjdoMFptLjIyLDUuODdjLS4zMi42LS44MSwxLjA2LTEuNDUsMS40MS0uNjQuMzQtMS40LjUxLTIuMjcuNTEtMS4zMiwwLTIuMzEtLjMzLTIuOTYtLjk5LS42NS0uNjYtLjk4LTEuNTgtLjk4LTIuNzZzLjI2LTIuMDguNzctMi43MWMuNTItLjYzLDEuMzEtMS4xMSwyLjM5LTEuNDQuMzUtLjEyLjczLS4yMSwxLjEyLS4yNy4zOS0uMDcuNzgtLjEzLDEuMTYtLjIuMzgtLjA2Ljc0LS4xNCwxLjA5LS4yNC43OS0uMjIuODctLjQyLjg4LS45OCwwLS4yNiwwLS41MiwwLS43NywwLS43MS0uMTYtMS4yNS0uNDgtMS42MS0uMzItLjM2LS45My0uNTUtMS44NC0uNTUtLjY4LDAtMS4yNi4xMy0xLjc1LjQtLjk1LjUyLTEuMzcuOTQtMi42LjM0LjQ3LS44MSwxLjExLTEuNCwxLjkyLTEuNzYuODEtLjM2LDEuNjktLjUzLDIuNjQtLjUzLjY4LDAsMS4zMi4wNSwxLjkyLjE0LjYuMDksMS4xMy4yOCwxLjU3LjU0LjQ0LjI3Ljc5LjY1LDEuMDUsMS4xMy4yNi40OS4zOSwxLjEyLjM5LDEuOTF2MTAuMzNjLS4wNywwLS40NSwwLS43NywwLTEuMzYsMC0xLjc4LS43Mi0xLjgxLTEuOTFaIi8+CiAgICAgICAgPC9nPgogICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTUxLjczLDcuNzJjMS44OC0uMDYsMi40MS0xLjcsMi40MS0zLjA3LDAtMS40NC0uMTUtMy4wNy0yLjEtMy4wN2gtMi41MXY2LjE0aDIuMlptLS4wMyw3LjljLjkzLDAsMS42Mi0uMjYsMi4wNi0uNzguNDQtLjUyLjY2LTEuMzYuNjYtMi41MiwwLTEuNDctLjItMi45Ny0yLjIyLTMuMjdoLTIuNjh2Ni41N2gyLjE3Wm0tNS4xNywxLjQ3Vi4wNGg1Ljg2YzMuMzEsMCw0Ljc5LDIuMTIsNC40OSw0LjktLjE0LDEuMjgtLjYyLDIuNi0xLjkxLDMuMjksMy4xNi45NiwzLjE2LDUuNTgsMS4zLDcuNTgtLjguODUtMi4wNywxLjI4LTMuODMsMS4yOGgtNS45MVoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im02MC42Ni4wNGg1Ljc5Yy44NywwLDEuNjEuMDksMi4yMi4yNy42MS4xOCwxLjEuNDQsMS40Ny44LjM3LjM2LjY0LjgxLjgxLDEuMzUuMTcuNTQuMjUsMS4xOC4yNSwxLjksMCwxLjE2LS4wOSwyLjEzLS4yNywyLjktLjE4Ljc4LS40NywxLjQxLS44OSwxLjg4LS40Mi40Ny0uOTcuODItMS42NSwxLjAyLS42OC4yMS0xLjUzLjMxLTIuNTUuMzFoLTIuMnY0LjY2YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjgsMC0xMS4zNywwLTE3LjA1aDBabTQuODgsOC45M2MuNDgsMCwuODktLjA2LDEuMjItLjE5LjMzLS4xMy42LS4zNC44Mi0uNjMuMjItLjMuMzctLjY5LjQ3LTEuMTguMS0uNDkuMTQtMS4xLjE0LTEuODNzLS4wNC0xLjMtLjEyLTEuNzZjLS4wOC0uNDYtLjIxLS44Mi0uMzctMS4wOS0uMTctLjI3LS4zOS0uNDUtLjY2LS41Ni0uMjctLjEtLjYxLS4xNi0xLjAxLS4xNmgtMi4zN3Y3LjM5aDEuODhaIi8+CiAgICAgICAgPHBhdGggY2xhc3M9ImNscy0zIiBkPSJtNzQuNC4wNGguNjNjLjMxLDAsLjU2LDAsLjg2LjA1LDEuMDEuMTksMS40OC44OSwxLjQ4LDEuODh2MTAuODhjMCwyLjgzLTEuNjcsNC4yNS01LjAyLDQuMjUtLjE2LDAtLjMxLDAtLjQ2LDAtMS4wOS0uMDItMi4wNi0uMjctMi44OS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxLjMuMi42NC4zNSwxLjAyLjQ0LjgxLjIsMS45Ni4yMSwyLjc0LS4yMi43OS0uNDQuODYtMS4yNy44Ni0yLjA1Vi4wNFoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im04Mi41OSwxNC44NGMuNTUuMzcsMS4yMy41NiwyLjA1LjU2LjM5LDAsLjc2LS4wNiwxLjExLS4xOC4zNS0uMTIuNjYtLjI5LjkzLS41Mi4yNy0uMjIuNDgtLjQ5LjYzLS44Mi4xNS0uMzIuMjMtLjY4LjIzLTEuMDksMC0uMzYtLjA2LS42Ny0uMTctLjk1LS4xMS0uMjctLjI3LS41Mi0uNDYtLjczLS4xOS0uMjItLjQyLS40MS0uNjktLjU5LS4yNy0uMTgtLjU1LS4zNi0uODYtLjU1LS42OS0uNC0xLjMzLS43OS0xLjkyLTEuMTctLjU5LS4zOC0xLjEtLjc5LTEuNTMtMS4yMi0uNDMtLjQzLS43OC0uOTEtMS4wMy0xLjQzLS4yNS0uNTItLjM3LTEuMTQtLjM3LTEuODYsMC0uNjIuMTEtMS4xOC4zMy0xLjcuMjItLjUyLjU0LS45Ni45Ny0xLjM0LjQzLS4zOC45NS0uNjgsMS41Ni0uODkuNjEtLjIyLDEuMzEtLjMyLDIuMS0uMzIsMS4wMywwLDEuOTIuMjEsMi42Ni42My43NC40MiwxLjI0LDEuMDIsMS41LDEuNzgtLjg2LjM3LTEuNDkuMTctMi4xOS0uMzUtLjQ0LS4yOS0uOTctLjQ0LTEuNTgtLjQ0LS44NSwwLTEuNTIuMjEtMS45OS42Mi0uNDcuNDItLjcxLDEtLjcxLDEuNzYsMCwuNjMuMTgsMS4xNS41NCwxLjU3LjM2LjQyLjgxLjc5LDEuMzUsMS4xMy41NC4zNCwxLjEzLjY2LDEuNzYuOTcuNjQuMzEsMS4yMi42NywxLjc2LDEuMDguNTQuNDEuOTkuOSwxLjM1LDEuNDcuMzYuNTcuNTQsMS4yOS41NCwyLjE1LDAsLjY3LS4xMywxLjMtLjM5LDEuODctLjI2LjU3LS42MywxLjA3LTEuMTEsMS40OC0uNDguNDItMS4wNy43NC0xLjc3Ljk4LS43LjI0LTEuNDkuMzYtMi4zOC4zNi0xLjE0LDAtMi4xNC0uMjUtMy4wMS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxWiIvPgogICAgICA8L2c+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTExMy4wOCwyOS4xM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNy0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOVptLTUuNTYsMi4zOHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjE4LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjUtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTQuNy0yLjk1aC0xLjAxbC0xLjE2LDQuMTMtMS4xOC00LjEzaC0xLjA1bDEuNyw1LjMxLS4wOC4zNmMtLjAyLjExLS4wNS4yLS4xLjI5LS4wNS4wOS0uMTEuMTYtLjE4LjIxLS4wOC4wNS0uMTcuMDgtLjI5LjA4LS4xNCwwLS4yNi0uMDItLjM3LS4wNS0uMTEtLjAzLS4xOS0uMDYtLjI1LS4wOS0uMDYtLjAzLS4wOS0uMDUtLjA5LS4wNWwuMTEuODZzLjA0LjAyLjExLjA1Yy4wNy4wMy4xNy4wNi4zLjA5LjEzLjAzLjI4LjA0LjQ2LjA0LjIyLDAsLjQtLjA0LjU1LS4xMi4xNS0uMDguMjctLjE5LjM3LS4zMi4xLS4xNC4xOC0uMy4yNS0uNDguMDctLjE4LjEzLS4zOC4yLS41OWwxLjcyLTUuNThoMFptLTUuMDgsNS4zM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjEyLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTYuMzEtMi4zNWMwLC4yMy0uMDIuNDMtLjA3LjYtLjA1LjE2LS4xMi4zLS4yMi40Mi0uMDguMTEtLjE4LjE5LS4yNy4yNS0uMS4wNi0uMTkuMTEtLjI5LjEzLS4wOS4wMy0uMTguMDUtLjI1LjA1LS4wNywwLS4xMi4wMS0uMTUuMDFoLTEuMDl2LTIuOTZoMS4wOWMuMDgsMCwuMTcsMCwuMjcuMDIuMTEuMDIuMjIuMDUuMzMuMS4xMS4wNS4yMi4xMy4zMi4yNC4xLjExLjE4LjI2LjI0LjQ0LjA2LjE4LjA5LjQyLjA5LjdoMFptMS4yNCwwYzAtLjM5LS4wNS0uNzMtLjE0LTEuMDEtLjA5LS4yOC0uMjItLjUyLS4zOC0uNzEtLjE2LS4xOS0uMzUtLjM0LS41Ni0uNDUtLjIxLS4xMS0uNDUtLjE5LS42OS0uMjQtLjI1LS4wNS0uNS0uMDctLjc3LS4wN2gtMi4yM3Y3LjJoMS4ydi0yLjI5aDEuMDdjLjIxLDAsLjQyLS4wMS42NC0uMDQuMjEtLjAzLjQyLS4wOS42My0uMTguMjEtLjA5LjQxLS4yMy42LS40Mi4yLS4xOC4zNS0uNDMuNDYtLjczLjExLS4zLjE3LS42Ni4xNy0xLjA2aDBabTU1LjU0LDMuMTRjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xMy4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOS0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOC45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM4LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS00LjE3LTQuMjRsLS4xNS0uOTdjLS4wNS0uMDMtLjA5LS4wNi0uMTMtLjA4LS4wNC0uMDItLjA3LS4wNC0uMS0uMDUtLjAzLS4wMS0uMDctLjAzLS4xMi0uMDQtLjA2LS4wMS0uMTEtLjAyLS4xNS0uMDMtLjA0LDAtLjA5LDAtLjE0LDAtLjA5LDAtLjE3LDAtLjI1LjAxLS4wOC4wMS0uMTYuMDMtLjI0LjA3LS4wOC4wMy0uMTUuMDgtLjIyLjE1LS4wOC4wOC0uMTUuMTUtLjIuMjMtLjA1LjA4LS4wOS4xNS0uMTIuMjEtLjAzLjA2LS4wNS4xMS0uMDYuMTR2LS43MmgtMS4wNHY1LjMzaDEuMDR2LTMuMDNjMC0uMDksMC0uMTksMC0uMzEsMC0uMTEuMDItLjIzLjA0LS4zNS4wMy0uMTIuMDctLjI0LjEyLS4zNi4wNi0uMS4xMi0uMTguMjEtLjI2LjA4LS4wOC4xOC0uMTQuMjktLjE4LjExLS4wNC4yNC0uMDcuMzgtLjA3LjE3LDAsLjMzLjAzLjQ2LjA5LjEzLjA2LjI2LjEzLjM3LjIzaDBabS01LjE1LDIuNjVjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzgtLjQxdi4zMWMwLC4wNSwwLC4xLjAxLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjgzLjQ1YzAsLjEyLS4wMy4yMy0uMS4zMi0uMDcuMDktLjE2LjE2LS4yNy4yMi0uMTEuMDYtLjI0LjEtLjM3LjEzLS4xMy4wMy0uMjcuMDQtLjQuMDQtLjI2LDAtLjQ4LS4wMy0uNjctLjA5LS4xOS0uMDYtLjMzLS4xNS0uNDQtLjI1LS4xLS4xMS0uMTUtLjI0LS4xNS0uMzksMC0uMS4wMi0uMTkuMDUtLjI4LjAzLS4wOC4wNy0uMTUuMTItLjIxLjA1LS4wNi4wOS0uMS4xMi0uMTMuMDQtLjAzLjA1LS4wNS4wNi0uMDVoLjkxYy4yMywwLC40Mi4wMy41Ny4wNy4xNS4wNC4yNi4wOS4zNS4xNi4wOC4wNy4xNC4xNC4xOC4yMi4wMy4wOC4wNS4xNi4wNS4yNWgwWm0tLjEzLTQuMDNjMCwuMjQtLjA0LjQ0LS4xMi42MS0uMDguMTctLjIuMy0uMzYuMzktLjE2LjA5LS4zNi4xNC0uNi4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMTksMCwuMzYuMDQuNDkuMS4xMy4wNi4yNC4xNS4zMi4yNS4wOC4xLjE0LjIyLjE3LjM1LjA0LjEzLjA1LjI2LjA1LjM5aDBabTEuMTcsMy45OGMwLS41LS4xNy0uODYtLjUzLTEuMS0uMzYtLjI0LS44OS0uMzYtMS41OS0uMzUtLjA4LDAtLjE3LDAtLjI4LDAtLjExLDAtLjIyLDAtLjM0LDAtLjEyLDAtLjIyLS4wMi0uMzItLjA0LS4xLS4wMi0uMTgtLjA1LS4yNC0uMS0uMDYtLjA1LS4wOS0uMTEtLjEtLjE5LDAtLjA5LjAzLS4xNi4xLS4yMS4wNi0uMDUuMTUtLjA4LjI2LS4xLjExLS4wMi4yNC0uMDMuMzgtLjAzLjE0LDAsLjI5LDAsLjQ2LDAsLjQ0LDAsLjgyLS4wOCwxLjEzLS4yMy4zMS0uMTUuNTQtLjM2LjcxLS42NS4xNi0uMjguMjQtLjYyLjI0LTEuMDF2LTEuNzNoLS41M3MtLjA5LDAtLjEzLDBjLS4wNSwwLS4wOS4wMS0uMTQuMDMtLjA1LjAyLS4wOS4wNi0uMTMuMTEtLjA0LjA1LS4wNi4xMS0uMDcuMTcsMCwuMDYtLjAxLjExLDAsLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjM5LS4xNi0uMTYtLjA0LS4zNC0uMDYtLjU1LS4wNi0uMTQsMC0uMjguMDEtLjQzLjA1LS4xNS4wMy0uMy4wOS0uNDUuMTctLjE1LjA4LS4yOC4xOS0uNC4zMy0uMTIuMTQtLjIxLjMxLS4yOC41Mi0uMDcuMjEtLjEuNDYtLjEuNzYsMCwuMi4wMy4zOC4wOC41NC4wNS4xNi4xMi4yOS4xOS40LjA4LjExLjE1LjIuMjMuMjcuMDguMDcuMTQuMTMuMTkuMTYuMDUuMDMuMDguMDUuMDguMDUsMCwwLS4wNCwwLS4xLjAxLS4wNy4wMS0uMTUuMDMtLjI0LjA3LS4xLjAzLS4xOS4wOC0uMjkuMTUtLjEuMDctLjE4LjE2LS4yNC4yNy0uMDYuMTEtLjEuMjYtLjEuNDMsMCwuMTMsMCwuMjQuMDQuMzMuMDMuMDkuMDguMTcuMTQuMjMuMDYuMDYuMTIuMTEuMTkuMTQuMDcuMDQuMTMuMDYuMi4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA5LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjguMTcuMi40Mi4zNS43NC40Ny4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTYuMjUuMDVjMCwuMTItLjAzLjIzLS4xLjMyLS4wNy4wOS0uMTYuMTYtLjI3LjIyLS4xMS4wNi0uMjQuMS0uMzcuMTMtLjE0LjAzLS4yNy4wNC0uNC4wNC0uMjYsMC0uNDgtLjAzLS42Ny0uMDktLjE5LS4wNi0uMzMtLjE1LS40NC0uMjUtLjEtLjExLS4xNS0uMjQtLjE1LS4zOSwwLS4xLjAyLS4xOS4wNi0uMjguMDMtLjA4LjA3LS4xNS4xMi0uMjEuMDUtLjA2LjA5LS4xLjEyLS4xMy4wNC0uMDMuMDUtLjA1LjA1LS4wNWguOTFjLjIzLDAsLjQyLjAzLjU3LjA3LjE1LjA0LjI2LjA5LjM1LjE2LjA4LjA3LjE0LjE0LjE4LjIyLjAzLjA4LjA1LjE2LjA1LjI1aDBabS0uMTMtNC4wM2MwLC4yNC0uMDQuNDQtLjEyLjYxLS4wOC4xNy0uMi4zLS4zNi4zOS0uMTYuMDktLjM2LjE0LS41OS4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMiwwLC4zNi4wNC40OS4xLjEzLjA2LjI0LjE1LjMyLjI1LjA4LjEuMTQuMjIuMTcuMzUuMDQuMTMuMDUuMjYuMDUuMzloMFptMS4xNywzLjk4YzAtLjUtLjE3LS44Ni0uNTMtMS4xLS4zNi0uMjQtLjg5LS4zNi0xLjU5LS4zNS0uMDgsMC0uMTcsMC0uMjgsMC0uMTEsMC0uMjIsMC0uMzQsMC0uMTIsMC0uMjItLjAyLS4zMi0uMDQtLjEtLjAyLS4xOC0uMDUtLjI0LS4xLS4wNi0uMDUtLjA5LS4xMS0uMS0uMTksMC0uMDkuMDMtLjE2LjEtLjIxLjA2LS4wNS4xNS0uMDguMjYtLjEuMTEtLjAyLjI0LS4wMy4zOC0uMDMuMTQsMCwuMjksMCwuNDYsMCwuNDQsMCwuODItLjA4LDEuMTMtLjIzLjMxLS4xNS41NC0uMzYuNzEtLjY1LjE2LS4yOC4yNC0uNjIuMjQtMS4wMXYtMS43M2gtLjUzcy0uMDksMC0uMTMsMGMtLjA1LDAtLjA5LjAxLS4xNC4wMy0uMDUuMDItLjA5LjA2LS4xNC4xMS0uMDQuMDUtLjA2LjExLS4wNy4xNywwLC4wNi0uMDEuMTEtLjAxLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjQtLjE2LS4xNi0uMDQtLjM0LS4wNi0uNTUtLjA2LS4xNCwwLS4yOC4wMS0uNDMuMDUtLjE1LjAzLS4zLjA5LS40NS4xNy0uMTUuMDgtLjI4LjE5LS40LjMzLS4xMi4xNC0uMjEuMzEtLjI4LjUyLS4wNy4yMS0uMS40Ni0uMS43NiwwLC4yLjAzLjM4LjA4LjU0LjA1LjE2LjEyLjI5LjE5LjQuMDguMTEuMTUuMi4yMy4yNy4wOC4wNy4xNC4xMy4xOS4xNi4wNS4wMy4wOC4wNS4wOC4wNSwwLDAtLjA0LDAtLjEuMDEtLjA3LjAxLS4xNS4wMy0uMjQuMDctLjEuMDMtLjE5LjA4LS4yOS4xNS0uMS4wNy0uMTguMTYtLjI0LjI3LS4wNi4xMS0uMS4yNi0uMS40MywwLC4xMywwLC4yNC4wNC4zMy4wMy4wOS4wOC4xNy4xNC4yMy4wNi4wNi4xMi4xMS4xOS4xNC4wNy4wNC4xMy4wNi4xOS4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA4LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjhzLjQyLjM1Ljc0LjQ3Yy4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTQ2LjE4LS40di0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTIuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNy0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM2LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMjQtMS4yNmMtLjA1LjA2LS4xMS4xMy0uMTguMTgtLjA3LjA2LS4xNS4xMS0uMjQuMTYtLjExLjA1LS4yMi4wOS0uMzIuMTEtLjEuMDItLjIxLjAzLS4zMi4wMy0uMjEsMC0uMzktLjA1LS41NC0uMTUtLjE1LS4wOS0uMjYtLjIzLS4zNS0uNC0uMDktLjE3LS4xNS0uMzctLjItLjU5LS4wNC0uMjMtLjA2LS40Ny0uMDctLjc0LDAtLjE1LDAtLjMxLjAyLS40OS4wMS0uMTguMDQtLjM2LjA4LS41My4wNC0uMTguMS0uMzQuMTgtLjQ5LjA4LS4xNS4xOS0uMjcuMzMtLjM2LjE0LS4wOS4zMS0uMTQuNTItLjE0LjE5LDAsLjM0LjAzLjQ4LjA4LjEzLjA1LjI0LjEzLjMyLjIyLjA4LjA4LjEzLjE4LjE4LjI4LjA0LjEuMDcuMjEuMDguMzIuMDEuMTEuMDIuMjIuMDIuMzJ2Mi4xN2gwWm0xLjA0LDEuMjZ2LTcuMjNoLTEuMDR2Mi40cy0uMDEtLjAyLS4wNC0uMDZjLS4wMy0uMDQtLjA3LS4wOS0uMTItLjE1LS4wNi0uMDYtLjE0LS4xMi0uMjMtLjE4LS4xLS4wNi0uMjItLjExLS4zNi0uMTUtLjE0LS4wNC0uMzItLjA2LS41MS0uMDYtLjI4LDAtLjUyLjA1LS43My4xMy0uMjEuMDktLjM5LjIxLS41NC4zNi0uMTUuMTUtLjI4LjMyLS4zOC41MS0uMS4xOS0uMTguMzktLjI0LjYtLjA2LjIxLS4xLjQyLS4xMy42Mi0uMDMuMjEtLjA0LjQtLjA0LjU4LDAsLjI5LjAyLjU3LjA3Ljg0LjA1LjI3LjEyLjUyLjIxLjc1LjEuMjMuMjMuNDMuMzkuNi4xNi4xNy4zNS4zLjU3LjQuMjMuMDkuNDkuMTQuNzkuMTMuMTksMCwuMzYtLjAzLjUyLS4wOC4xNS0uMDUuMy0uMTIuNDMtLjIxLjEzLS4wOS4yNy0uMi4zOS0uMzJ2LjUzaC45OVptLTYuNDYtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDcuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMTQtMi4xNWMwLC4xOS0uMDIuMzYtLjA3LjQ5LS4wNS4xMy0uMTIuMjQtLjIxLjMzLS4xMS4xMS0uMjQuMTgtLjM4LjIyLS4xNC4wNC0uMjkuMDctLjQ0LjA3LS4xNSwwLS4yOSwwLS40MiwwaC0xLjAzdi0yLjIxaDEuMDNjLjE2LDAsLjMyLDAsLjQ4LjAyLjE2LjAxLjMuMDQuNDQuMDkuMTMuMDUuMjUuMTIuMzQuMjIuMDguMDkuMTUuMi4xOS4zMy4wNS4xMi4wNy4yNy4wNy40NGgwWm0tLjI2LTMuMDZjMCwuMi0uMDQuMzctLjEuNS0uMDcuMTMtLjE1LjIzLS4yNi4zLS4xLjA4LS4yMS4xMy0uMzMuMTYtLjExLjAzLS4yMi4wNS0uMzEuMDYtLjEsMC0uMTcuMDEtLjIyLDBoLTEuMDd2LTIuMDVoMS4wN3MuMSwwLC4xNywwYy4wNywwLC4xNS4wMS4yNC4wMi4wOC4wMS4xNy4wMy4yNS4wNi4wOC4wMy4xNS4wNy4yLjEyLjEyLjA5LjIxLjIuMjcuMzMuMDYuMTMuMDkuMjkuMDkuNDhoMFptMS41LDMuMDRjMC0uMTQtLjAxLS4yNy0uMDQtLjQxLS4wMy0uMTQtLjA4LS4yNy0uMTUtLjM5LS4wNy0uMTMtLjE2LS4yNC0uMjgtLjM1LS4xNC0uMTMtLjMtLjIzLS40Ny0uMjktLjE3LS4wNy0uMzUtLjExLS41Mi0uMTQuMTItLjA0LjIzLS4wOS4zNS0uMTUuMTItLjA2LjIyLS4xMy4zMi0uMi4xLS4wOC4xOC0uMTYuMjUtLjI2LjA4LS4xNC4xNS0uMjkuMi0uNDcuMDUtLjE4LjA4LS4zOC4wOC0uNjEsMC0uMjYtLjA0LS41LS4xMy0uNy0uMDgtLjItLjItLjM3LS4zNC0uNTEtLjE0LS4xNC0uMy0uMjQtLjQ4LS4zMi0uMjItLjEtLjQ2LS4xNy0uNy0uMi0uMjQtLjAzLS41MS0uMDUtLjc5LS4wNWgtMi4yN3Y3LjJoMi4yNWMuMTcsMCwuMzYsMCwuNTUtLjAxLjE5LS4wMS4zOC0uMDMuNTctLjA3LjE5LS4wNC4zNy0uMS41NS0uMTcuMTctLjA4LjMzLS4xOC40Ny0uMzEuMTUtLjE2LjI3LS4zMi4zNi0uNS4wOS0uMTguMTQtLjM2LjE4LS41NS4wMy0uMTkuMDUtLjM3LjA1LS41NmgwWm0xMTIuNDksMi4xN3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS01LjM3LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMxLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzQuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4zNCw2Ljd2LTMuNTZjMC0uMTIsMC0uMjYtLjAyLS40MS0uMDEtLjE1LS4wNC0uMy0uMDgtLjQ0LS4wNC0uMTUtLjExLS4yOS0uMTktLjQzLS4wOC0uMTQtLjItLjI1LS4zNC0uMzYtLjEzLS4wOS0uMjgtLjE2LS40NC0uMi0uMTYtLjA0LS4zMS0uMDYtLjQ3LS4wNi0uMjEsMC0uNC4wMy0uNTYuMDktLjE2LjA2LS4zLjEyLS40Mi4yMS0uMTIuMDgtLjIxLjE3LS4yOS4yNS0uMDguMDktLjEzLjE2LS4xNy4yMy0uMDQuMDctLjA2LjExLS4wNy4xMiwwLS4wMy0uMDItLjA4LS4wNS0uMTUtLjAzLS4wNy0uMDgtLjE1LS4xNS0uMjQtLjA2LS4wOS0uMTUtLjE3LS4yNi0uMjUtLjA5LS4wNi0uMTktLjExLS4zLS4xNS0uMTEtLjA0LS4yMS0uMDctLjMyLS4wOC0uMTEtLjAyLS4yMS0uMDItLjMtLjAyLS4yMiwwLS40Mi4wMy0uNTguMDktLjE3LjA2LS4zLjEzLS40Mi4yMi0uMTEuMDktLjIuMTgtLjI3LjI4LS4wNy4wOS0uMTEuMTgtLjEzLjI1di0uNzJoLTEuMDN2NS4zM2gxLjAzdi0zLjI3YzAtLjIyLjAyLS40LjA1LS41NS4wMy0uMTQuMDgtLjI2LjE0LS4zNS4wNS0uMDkuMTItLjE2LjE4LS4yMi4wOC0uMDguMTYtLjEzLjI2LS4xOC4xLS4wNC4yMS0uMDcuMzQtLjA3LjE2LDAsLjI5LjAyLjM4LjA2LjEuMDQuMTguMDguMjQuMTUuMDguMDcuMTQuMTUuMTkuMjUuMDUuMDkuMDguMjEuMS4zNC4wMi4xMy4wMy4yOS4wMy40N3YzLjM3aDEuMDF2LTMuMjdjMC0uMTIsMC0uMjUuMDEtLjM4LjAxLS4xMy4wNC0uMjYuMDktLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA4LS4wOC4xOC0uMTQuMjktLjE4LjEtLjA0LjIxLS4wNi4zMy0uMDYuMTMsMCwuMjQuMDEuMzUuMDQuMS4wMy4yLjA4LjI5LjE2LjA3LjA3LjEzLjE0LjE2LjIxLjA0LjA3LjA2LjEyLjA3LjE2LjAxLjA1LjAzLjExLjA0LjE4LjAxLjA3LjAyLjE2LjAzLjI0LDAsLjA5LjAxLjE4LjAxLjI3djMuMzdoMS4wMVptLTkuMTItMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE4Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wOC4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEuMDEuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTUuMDMtMi42MnYtNC41OGgtMS4ydjQuNThjMCwuMTYsMCwuMzMtLjAxLjUsMCwuMTctLjAzLjM0LS4wNy40OS0uMDMuMTYtLjA5LjMtLjE2LjQzLS4xLjE1LS4yMy4yNy0uMzkuMzUtLjE2LjA4LS4zNS4xMi0uNTYuMTItLjE2LDAtLjMxLS4wMi0uNDQtLjA1LS4xNC0uMDMtLjI2LS4wNy0uMzctLjExLS4xLS4wNC0uMTktLjA4LS4yNS0uMTEtLjA2LS4wMy0uMDktLjA1LS4xLS4wNmwuMjYsMS4wNHMuMDMuMDEuMDguMDRjLjA1LjAzLjEyLjA2LjIyLjA5LjEuMDMuMjIuMDcuMzUuMDkuMTQuMDMuMjkuMDQuNDcuMDQuMDcsMCwuMTYsMCwuMjgsMCwuMTIsMCwuMjUtLjAzLjM5LS4wNi4xNC0uMDMuMjgtLjA4LjQzLS4xNS4xNC0uMDcuMjctLjE2LjM5LS4yNy4xMi0uMTEuMjMtLjI0LjMxLS4zOC4wOS0uMTQuMTYtLjMuMjItLjQ5LjA2LS4xOC4xLS40LjEyLS42NS4wMy0uMjUuMDQtLjU0LjA0LS44N2gwWm0zMS4xNiwyLjYydi0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTEuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIyLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMS0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOC0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptMzIuNTEsMHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjM1LTEuNTljMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDYtLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMS0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzItLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDguMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjE1LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMyLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzMuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4xMiw1LjE5YzAtLjI2LS4wNi0uNDgtLjE3LS42Ny0uMTEtLjE5LS4yNi0uMzUtLjQ2LS40OC0uMTktLjEzLS40MS0uMjUtLjY1LS4zNS0uMTItLjA1LS4yNC0uMS0uMzctLjE2LS4xMi0uMDUtLjI0LS4xMi0uMzUtLjE5LS4xMS0uMDctLjE5LS4xNS0uMjYtLjI0LS4wNy0uMDktLjEtLjItLjEtLjMyLDAtLjIyLjA4LS4zOC4yMi0uNS4xNS0uMTEuMzUtLjE3LjYyLS4xNy4yMSwwLC40LjAyLjU2LjA1LjE2LjA0LjI5LjA5LjQuMTQuMTEuMDYuMTkuMS4yNC4xNS4wNS4wNC4wOC4wNi4wOC4wN2wtLjE1LS44OHMtLjAyLS4wMi0uMDctLjA2Yy0uMDUtLjA0LS4xMy0uMDgtLjIzLS4xMy0uMTEtLjA1LS4yNS0uMDktLjQyLS4xMi0uMTctLjAzLS4zOS0uMDUtLjY0LS4wNC0uMjMsMC0uNDUuMDMtLjY1LjA5LS4yLjA2LS4zOC4xNS0uNTMuMjgtLjE1LjEyLS4yNy4yNy0uMzYuNDUtLjA5LjE4LS4xMy4zOS0uMTMuNjIsMCwuMjQuMDUuNDUuMTMuNjIuMDguMTcuMTkuMzIuMzMuNDMuMTQuMTIuMjkuMjIuNDUuMzEuMTYuMDguMzMuMTYuNDkuMjMuMTYuMDcuMzIuMTUuNDUuMjIuMTQuMDguMjUuMTcuMzMuMjcuMDguMS4xMy4yMy4xMy4zOCwwLC4yNC0uMDguNDItLjIzLjU0LS4xNS4xMi0uMzguMTctLjcuMTctLjE5LDAtLjM3LS4wMy0uNTUtLjA4LS4xOC0uMDUtLjM0LS4xLS40OC0uMTctLjE0LS4wNi0uMjYtLjEyLS4zNC0uMTctLjA4LS4wNS0uMTMtLjA3LS4xMy0uMDhsLjE1LDEuMDFjLjA3LjA0LjE3LjA5LjI5LjE0LjEzLjA2LjMuMS41LjE0LjIuMDQuNDUuMDYuNzMuMDUuMjcsMCwuNTMtLjA0Ljc3LS4xMi4yNC0uMDguNDUtLjIuNjQtLjM2LjE0LS4xMi4yNi0uMjguMzQtLjQ2LjA4LS4xOS4xMy0uNDEuMTMtLjY2aDBabS01LjM3LTEuMTFjMCwuMzgtLjA0LjcxLS4xMi45OS0uMDguMjgtLjIxLjUtLjM3LjY2LS4xNy4xNi0uMzguMjQtLjY0LjI0LS4yOSwwLS41My0uMDctLjcxLS4yLS4xOC0uMTQtLjMyLS4zNC0uNC0uNjItLjA5LS4yOC0uMTMtLjY0LS4xMy0xLjA3LDAtLjI2LjAxLS41Mi4wNC0uNzYuMDMtLjI0LjA5LS40Ni4xOC0uNjUuMDktLjE5LjIxLS4zNC4zOC0uNDUuMTYtLjExLjM3LS4xNy42NC0uMTcuMjEsMCwuMzguMDUuNTIuMTMuMTQuMDguMjUuMTkuMzMuMzMuMDguMTQuMTQuMjkuMTguNDcuMDQuMTcuMDcuMzUuMDguNTQuMDEuMTkuMDIuMzguMDIuNTZoMFptMS4xLS4wMmMwLS4yOS0uMDItLjU4LS4wNy0uODUtLjA1LS4yNy0uMTItLjUzLS4yMy0uNzYtLjExLS4yMy0uMjQtLjQ0LS40Mi0uNjItLjE3LS4xOC0uMzktLjMyLS42NC0uNDItLjI1LS4xLS41NS0uMTUtLjktLjE2LS4zNCwwLS42NC4wNS0uOS4xNS0uMjYuMS0uNDguMjQtLjY2LjQxLS4xOC4xOC0uMzMuMzgtLjQ0LjYyLS4xMS4yNC0uMi40OS0uMjUuNzctLjA1LjI4LS4wOC41Ni0uMDguODYsMCwuNDEuMDQuNzguMTIsMS4xMS4wOC4zMy4yMS42Mi40Ljg2LjE4LjI0LjQyLjQyLjcyLjU1LjMuMTMuNjYuMTksMS4wOC4yLjM2LDAsLjY3LS4wNy45NS0uMjEuMjgtLjE0LjUyLS4zMy43MS0uNTguMTktLjI1LjM0LS41NC40NC0uODcuMS0uMzMuMTUtLjY4LjE1LTEuMDZoMFptLTUuMzIuNTZjMC0uMjMtLjA0LS40NC0uMS0uNjMtLjA3LS4xOS0uMTctLjM1LS4zLS41LS4xNC0uMTctLjI5LS4zMS0uNDctLjQzLS4xOC0uMTItLjM2LS4yMy0uNTUtLjMyLS4xOS0uMDktLjM4LS4xOC0uNTctLjI2LS4xOS0uMDgtLjM2LS4xNi0uNTItLjI1LS4xNi0uMDgtLjMtLjE4LS40MS0uMjgtLjA3LS4wNy0uMTItLjE0LS4xNi0uMi0uMDQtLjA2LS4wNy0uMTMtLjA4LS4yLS4wMi0uMDctLjAyLS4xNC0uMDItLjIyLDAtLjE0LjAzLS4yNy4wOS0uNC4wNi0uMTMuMTctLjI1LjMyLS4zNS4xLS4wNy4yMy0uMTIuNC0uMTUuMTYtLjAzLjM2LS4wNS42LS4wNS4xMiwwLC4yNCwwLC4zNi4wMy4xMi4wMi4yMy4wNC4zMy4wNi4xNS4wMy4yOC4wNy4zOC4xMS4xLjA0LjE4LjA3LjI0LjEuMDYuMDMuMDkuMDUuMTEuMDdsLS4yNC0xLjAzcy0uMDMtLjAyLS4wOS0uMDVjLS4wNi0uMDMtLjE1LS4wNi0uMjctLjEtLjEyLS4wMy0uMjgtLjA2LS40Ny0uMDktLjE5LS4wMy0uNDItLjA0LS42OS0uMDQtLjIxLDAtLjQxLjAyLS42Mi4wNS0uMi4wNC0uNC4xLS41OC4xOC0uMTkuMDgtLjM2LjItLjUyLjM0LS4xNC4xMi0uMjYuMjYtLjM0LjQtLjA5LjE0LS4xNS4yOS0uMTkuNDQtLjA0LjE1LS4wNi4zLS4wNi40NSwwLC4xNy4wMi4zNC4wNS41LjAzLjE2LjA5LjMxLjE3LjQ2LjEuMTYuMjEuMy4zNi40Mi4xNC4xMi4zMS4yMy40OC4zMi4xOC4wOS4zNi4xOS41NS4yNy4xOS4wOS4zOC4xOC41Ni4yOC4xOS4xLjM2LjIxLjUyLjM0LjEuMDguMTkuMTYuMjYuMjQuMDcuMDguMTIuMTcuMTYuMjcuMDMuMS4wNS4yMS4wNS4zNCwwLC4yLS4wNC4zNy0uMTIuNS0uMDguMTQtLjE5LjI2LS4zNS4zNi0uMDguMDYtLjE3LjEtLjI4LjEzLS4xMS4wMy0uMjIuMDYtLjMzLjA3LS4xMS4wMi0uMjEuMDItLjMuMDMtLjA5LDAtLjE1LDAtLjE4LDAtLjExLDAtLjIyLDAtLjMzLS4wMi0uMTEtLjAxLS4yMi0uMDMtLjMyLS4wNS0uMjItLjA0LS40MS0uMDktLjU2LS4xMy0uMTUtLjA0LS4yNy0uMDgtLjM0LS4xMS0uMDgtLjAzLS4xMi0uMDQtLjEzLS4wNWwuMjYsMS4wMXMuMDQuMDIuMS4wNWMuMDYuMDMuMTYuMDcuMjkuMTEuMTMuMDQuMy4wOC41MS4xMS4yMS4wMy40NS4wNS43NC4wNS4yMiwwLC40NS0uMDIuNjktLjA1LjI0LS4wNC40Ny0uMS43LS4xOS4yMy0uMDkuNDMtLjIyLjYxLS4zOS4xOC0uMTYuMzMtLjM3LjQ0LS42My4xMS0uMjUuMTYtLjU2LjE3LS45MloiLz4KICAgICAgPGc+CiAgICAgICAgPGc+CiAgICAgICAgICA8Zz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtMi41MiwxNS4wNGMuNDQtMy4wNSwzLjUtMy44OCwzLjc5LTYuNjYtMS4zOC42MS0zLjAzLjQyLTQuMjQtLjU4LTEuMzQsMi40MS0xLjQxLDQuNzguNDUsNy4yNFoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtOC40Myw2LjE5YzEuNTYtLjIzLDIuOS0xLjMzLDQuMTgtMi40MSwxLjc3LTEuNSw0LjI0LTMuMzUsNi41OS0zLjE3QzE1LS42OSwxMC40NS4yNCw3LjY4LDEuOTRjMS4wNywxLjE4LDEuMzEsMi44NC43NSw0LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC41LDE1Ljk5Yy0uNDQsMy4wNS0zLjUsMy44OC0zLjc5LDYuNjYsMS4zOC0uNjEsMy4wMy0uNDIsNC4yNC41OCwxLjM0LTIuNDEsMS40MS00Ljc4LS40NS03LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yMi41OSwyNC44NGMtMS41Ni4yMy0yLjksMS4zMy00LjE4LDIuNDEtMS43NywxLjUtNC4yNCwzLjM1LTYuNTksMy4xNyw0LjIsMS4zLDguNzQuMzcsMTEuNTEtMS4zMy0xLjA3LTEuMTgtMS4zMS0yLjg0LS43NS00LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0xNS45OSwyLjUyYzMuMDUuNDQsMy44NywzLjUsNi42NiwzLjc5LS42MS0xLjM4LS40Mi0zLjAzLjU4LTQuMjQtMi40MS0xLjM0LTQuNzgtMS40MS03LjI0LjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yNC44NCw4LjQzYy4yMywxLjU2LDEuMzMsMi45LDIuNDEsNC4xOCwxLjUsMS43NywzLjM1LDQuMjQsMy4xNyw2LjU5LDEuMy00LjIuMzctOC43NC0xLjMzLTExLjUxLTEuMTgsMS4wNy0yLjg0LDEuMzItNC4yNC43NVoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0yIiBkPSJtMTUuMDQsMjguNWMtMy4wNS0uNDQtMy44OC0zLjUtNi42Ni0zLjc5LjYxLDEuMzguNDIsMy4wMy0uNTgsNC4yNCwyLjQxLDEuMzQsNC43OCwxLjQxLDcuMjQtLjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02LjE5LDIyLjU5Yy0uMjMtMS41Ni0xLjMzLTIuOS0yLjQxLTQuMTgtMS41LTEuNzctMy4zNC00LjI0LTMuMTctNi41OS0xLjMsNC4yLS4zNyw4Ljc0LDEuMzMsMTEuNTEsMS4xOC0xLjA3LDIuODQtMS4zMSw0LjI0LS43NVoiLz4KICAgICAgICAgIDwvZz4KICAgICAgICAgIDxnPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yOC43NiwyLjI2YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02Ljk2LDI0LjA3YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC43NiwyOC43NmMtMS4zLDEuMy0zLjQsMS4zLTQuNywwLTEuMy0xLjMtMS4zLTMuNCwwLTQuNywxLjMtMS4zLDMuNC0xLjMsNC43LDBzMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im02Ljk2LDYuOTZjLTEuMywxLjMtMy40LDEuMy00LjcsMC0xLjMtMS4zLTEuMy0zLjQsMC00LjcsMS4zLTEuMywzLjQtMS4zLDQuNywwLDEuMywxLjMsMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgICAgICA8Zz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMiIgZD0ibTE0LjEsMTguMzF2MS4xN2gyLjgzdi0yLjU1bDIuNDMsMi4zNWMuMi4xOS4xOS4zLjE5LjQ5di44czAsLjAyLDAsLjA0aDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAyLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMiwwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMtLjAxLjA0aDBzMCwuMDMtLjAxLjAzaDBzMCwuMDIsMCwuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMtLjAxLjAzLS4wMi4wNGgwczAsLjAyLS4wMS4wM2gwczAsLjAyLS4wMS4wM2gwczAsLjAzLS4wMi4wM2gwczAsLjAyLS4wMS4wM2gwcy0uMDEuMDItLjAyLjAzYzAsMCwwLDAtLjAxLjAxLDAsMCwwLC4wMS0uMDEuMDJoMHMwLC4wMi0uMDEuMDJjMCwwLDAsMC0uMDEuMDEsMCwwLS4wMS4wMS0uMDIuMDIsMCwwLDAsMC0uMDEuMDEsMCwwLDAsMC0uMDEuMDFoLS4wMXMtLjAxLjAyLS4wMS4wMmMwLDAsMCwwLS4wMS4wMWgwcy0uMDEuMDEtLjAyLjAyaDBzMCwwLS4wMS4wMWMwLDAsMCwwLS4wMS4wMWgtLjAxcy0uMDEuMDItLjAxLjAyYzAsMC0uMDIuMDEtLjAyLjAyaC0uMDFzMCwuMDItLjAxLjAyaC0uMDFzMCwuMDItLjAxLjAyYzAsMCwwLDAtLjAxLDAsMCwwLS4wMi4wMS0uMDMuMDJoMHMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaC0uMDFzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaDBzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAyLjAxLS4wMi4wMWMwLDAsMCwwLS4wMSwwLS4yLjA5LS40MS4xNC0uNjQuMTRoLTMuOTF2MS4xN2wtMi41LTIuNDgsMi41LTIuNDhoMFptMi44My00LjIxaDIuNTV2Mi44M2gtMS4xN2wyLjQ4LDIuNSwyLjQ4LTIuNWgtMS4xN3YtMy45MWMwLS4yMy0uMDUtLjQ1LS4xNC0uNjQsMCwwLDAsMCwwLS4wMXYtLjAycy0uMDEtLjAxLS4wMS0uMDFjMC0uMDEtLjAxLS4wMi0uMDItLjAzaDBzMC0uMDIsMC0uMDJoMHMwLS4wMiwwLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRoMHMwLS4wMi0uMDEtLjAzaDBzMC0uMDItLjAxLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRjMCwwLDAsMCwwLS4wMSwwLDAsMCwwLS4wMS0uMDFoMHMwLS4wMi0uMDEtLjAzaDBzLS4wMS0uMDMtLjAyLS4wM2gtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMWgwcy0uMDEtLjAxLS4wMi0uMDJoMHMwLDAtLjAxLS4wMWgtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMSwwLDAtLjAxLS4wMS0uMDItLjAyLDAsMCwwLDAtLjAxLDAsMCwwLDAsMC0uMDEtLjAxaC0uMDFzLS4wMS0uMDItLjAyLS4wMmMwLDAsMCwwLS4wMS0uMDEsMCwwLS4wMS0uMDEtLjAyLS4wMWgtLjAxczAtLjAyLS4wMS0uMDJoLS4wMXMtLjAxLS4wMi0uMDItLjAyaC0uMDFzLS4wMS0uMDItLjAyLS4wMmgtLjAxcy0uMDEtLjAyLS4wMi0uMDJoLS4wMXMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDEtLjAxLS4wMi0uMDJoMHMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDItLjAxLS4wMi0uMDJoMHMtLjAyLS4wMS0uMDMtLjAyaDBzLS4wMSwwLS4wMi0uMDFoLS4wMXMtLjAyLS4wMS0uMDMtLjAxaDBzLS4wMiwwLS4wMy0uMDFoLS4wMXMtLjAxLDAtLjAyLS4wMWgwcy0uMDIsMC0uMDMtLjAxaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wNCwwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wNCwwaC0uOGMtLjE4LDAtLjI5LS4wMi0uNDkuMTlsLTIuMzUsMi40M2gwWm0tMi44MywyLjgzaC0yLjU1di0yLjgzaDEuMTdsLTIuNDgtMi41LTIuNDgsMi41aDEuMTd2My45MWMwLC4yMy4wNS40NS4xNC42NCwwLDAsMCwwLDAsLjAxdi4wMnMuMDEuMDEuMDEuMDFjMCwuMDEuMDEuMDIuMDIuMDNoMHMwLC4wMiwwLC4wMmgwczAsLjAyLDAsLjAzaDBzLjAxLjAzLjAyLjA0aDBzMCwuMDIuMDEuMDNoMHMwLC4wMi4wMS4wM2gwcy4wMS4wMy4wMi4wNGMwLDAsMCwwLDAsLjAxLDAsMCwwLDAsLjAxLjAxaDBzMCwuMDIuMDEuMDNoMHMuMDEuMDMuMDIuMDRoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMWgwcy4wMS4wMS4wMi4wMmgwczAsMCwuMDEuMDFoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMSwwLDAsLjAxLjAxLjAyLjAyLDAsMCwwLDAsLjAxLjAxLDAsMCwwLDAsLjAxLjAxaC4wMXMuMDEuMDIuMDIuMDJjMCwwLDAsMCwuMDEuMDEsMCwwLC4wMS4wMS4wMi4wMWguMDFzMCwuMDIuMDEuMDJoLjAxcy4wMS4wMi4wMi4wMmguMDFzLjAxLjAyLjAyLjAyaC4wMXMuMDEuMDIuMDIuMDJoLjAxcy4wMi4wMi4wMy4wMmgwcy4wMS4wMS4wMi4wMmguMDFzLjAxLjAxLjAyLjAyaDBzLjAyLjAyLjAzLjAyaDBzLjAxLjAxLjAyLjAyaDBzLjAyLjAxLjAyLjAyaDBzLjAyLjAxLjAzLjAyaDBzLjAxLjAxLjAyLjAxaC4wMXMuMDIuMDEuMDMuMDFoMHMuMDIsMCwuMDMuMDFoMHMuMDIsMCwuMDIuMDFoLjAxcy4wMiwwLC4wMy4wMWgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoMHMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaC4wMXMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoLjAxcy4wMiwwLC4wMywwaDBzLjAyLDAsLjA0LDBoMHMuMDIsMCwuMDMsMGguMDFzLjAyLDAsLjA0LDBoLjhjLjE4LDAsLjI5LjAyLjQ5LS4xOWwyLjM1LTIuNDNoMFptMC0yLjgzbC0yLjQzLTIuMzVjLS4yMS0uMi0uMTktLjMtLjE5LS40OXYtLjhzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA1aDBzMC0uMDIsMC0uMDRoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAyLjAxLS4wNGgwczAtLjAyLDAtLjAzaDBzMC0uMDMuMDEtLjA0aDBzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwcy4wMS0uMDMuMDItLjA0aDBzMC0uMDIuMDEtLjAzaDBzMC0uMDIuMDEtLjAzaDBzMC0uMDMuMDItLjAzaDBzMC0uMDIuMDEtLjAzaDBzLjAxLS4wMi4wMS0uMDNjMCwwLDAsMCwuMDEtLjAxLDAsMCwwLS4wMS4wMS0uMDJoMHMwLS4wMi4wMS0uMDJjMCwwLDAsMCwuMDEtLjAxLDAsMCwuMDEtLjAxLjAyLS4wMiwwLDAsMCwwLC4wMS0uMDEsMCwwLDAsMCwuMDEtLjAxaC4wMXMuMDEtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMS0uMDFoMHMuMDEtLjAxLjAyLS4wMmgwczAsMCwuMDEtLjAxYzAsMCwwLDAsLjAxLS4wMWguMDFzLjAxLS4wMi4wMS0uMDJjMCwwLC4wMi0uMDEuMDItLjAyaC4wMXMwLS4wMi4wMS0uMDJoLjAxczAtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMSwwLDAsMCwuMDItLjAxLjAzLS4wMmgwcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmguMDFzLjAyLS4wMi4wMy0uMDJoLjAxcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmgwcy4wMi0uMDIuMDMtLjAyaC4wMXMuMDItLjAxLjAyLS4wMWMwLDAsMCwwLC4wMSwwLC4yLS4wOS40MS0uMTQuNjQtLjE0aDMuOTF2LTEuMTdsMi41LDIuNDgtMi41LDIuNDh2LTEuMTdoLTIuODN2Mi41NVoiLz4KICAgICAgICAgIDxwb2x5Z29uIGNsYXNzPSJjbHMtNSIgcG9pbnRzPSIxNC4xMSAxOS40NSAxNC4xMSAxNi45MiAxMS41NyAxNi45MiAxMS41NyAxNC4xMSAxNC4xMSAxNC4xMSAxNC4xMSAxMS41NyAxNi45MiAxMS41NyAxNi45MiAxNC4xMSAxOS40NSAxNC4xMSAxOS40NSAxNi45MiAxNi45MiAxNi45MiAxNi45MiAxOS40NSAxNC4xMSAxOS40NSIvPgogICAgICAgIDwvZz4KICAgICAgPC9nPgogICAgPC9nPgogIDwvZz4KPC9zdmc+",Qt=e=>e.replace(/\s+/g," ").replace(/Telep\s+on/gi,"Telepon").replace(/Kunjunga\s+n/gi,"Kunjungan").replace(/Spes\s+ialis/gi,"Spesialis").trim();function pa(e){let L=e.find(y=>/^SEP$/i.test(y.title)),a=L?kt(L.html):"",i=L&&new DOMParser().parseFromString(L.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",r=y=>Qt(a.match(y)?.[1]||"")||"-",u=(y,z)=>r(new RegExp(`${y}\\s*:\\s*([\\s\\S]*?)(?=${z}|$)`,"i")),s=M("no_sep","sep")!=="-"?M("no_sep","sep"):r(/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]+)/i),l=r(/Tgl\.?\s*SEP\s*[:.]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})/i),o=M("no_hp","telepon")!=="-"?M("no_hp","telepon"):u("No\\.?\\s*Telepon","Sub\\/Spesialis"),A=M("kelas").replace(/^Kelas\s*/i,""),p=M("tgl_lahir","tglLahir").replace(/^:\s*/,"").split(/\s*\/\s*/)[0]?.trim()||"-",N=u("Kelamin","No\\.?\\s*Telepon"),D=M("dokter","dpjp"),k=M("kartu","no_kartu","noka"),x=M("norm","rekam_medis"),f=M("nama")||"-",w=k.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),$=w?`${t(w[1].trim())}<span class="sep-inline-mr">No.MR : ${t(w[2].trim())}</span>`:`${t(k)}${x!=="-"?`<span class="sep-inline-mr">No.MR : ${t(x)}</span>`:""}`,U=M("jenis_kunjungan")!=="-"?M("jenis_kunjungan"):r(/Jns\.?\s*Kunjungan\s*[:.]?\s*([\s\S]*?)(?:\s+Kls\.?\s*Hak|$)/i),F=U.replace(/^-\s*/,"").split(/\s+-\s+|\n/).map(y=>y.trim()).filter(Boolean),Q=F.length>1?'<ul class="sep-multiline-list">'+F.map(y=>`<li>${t(y)}</li>`).join("")+"</ul>":t(U),E=M("peserta","jenis_peserta")!=="-"?M("peserta","jenis_peserta"):u("(?<!Nama )Peserta","COB|Jns\\.?\\s*Rawat"),Y=M("penjamin")!=="-"?M("penjamin"):u("Penjamin","\\*Saya|CATATAN"),O=M("faskes_perujuk","faskes")!=="-"?M("faskes_perujuk","faskes"):u("Faskes\\s*Perujuk","Diagnosa\\s*Awal"),I=M("diagnosa_awal")!=="-"?M("diagnosa_awal"):u("Diagnosa\\s*Awal","Catatan|Peserta"),T=M("catatan_sep","catatan")!=="-"?M("catatan_sep","catatan"):u("Catatan","Peserta|COB"),S=M("sub_spesialis","spesialis")!=="-"?M("sub_spesialis","spesialis"):u("Sub\\/Spesialis","Dokter"),R=r(/Cetakan\s+ke\s*[:.]?\s*(\d+)/i),g=R!=="-"?`<div class="sep-print-meta">Cetakan ke ${t(R)}</div>`:"",c=(y,z,C="",j=!1)=>`<tr><td class="lbl${j?" right":""}">${y}</td><td class="sep">:</td><td class="val${C?" "+C:""}">${z}</td></tr>`,P='<tr><td colspan="3">&nbsp;</td></tr>',m=A!=="-"?`Kelas ${t(A)}`:"-";return`<section class="rm-page sep-page" id="rm-01">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${Yt}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT ELEGIBILITAS PESERTA</div>
     <div class="sep-hospital">${t(wt.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-columns">
   <div class="sep-col-left"><table class="sep-kv-table">
     ${c("No. SEP",`<span class="sep-no-value">${t(s)}</span>`)}
     ${c("Tgl. SEP",t(l))}
     ${c("No.Kartu",$)}
     ${c("Nama Peserta",`<strong>${t(f)}</strong>`)}
     ${c("Tgl.Lahir",`${t(p)} &nbsp;&nbsp; Kelamin : ${t(N)}`)}
     ${c("No.Telepon",t(o))}
     ${c("Sub/Spesialis",t(S))}
     ${c("Dokter",t(D))}
     ${c("Faskes Perujuk",t(O!=="-"?O:`${wt} - Kota Jambi`))}
     ${c("Diagnosa Awal",t(I))}
     ${c("Catatan",t(T))}
   </table></div>
   <div class="sep-col-right"><table class="sep-kv-table">
     ${P}${P}
     ${c("Peserta",t(E),"",!0)}
     ${c("COB","-","",!0)}
     ${c("Jns.Rawat",`<strong>${t(M("jenis"))}</strong>`,"",!0)}
     ${c("Jns.Kunjungan",Q,"",!0)}
     ${c("Kls.Hak",`<strong>${m}</strong>`,"",!0)}
     ${c("Kls.Rawat",`<strong>${m}</strong>`,"",!0)}
     ${c("Penjamin",t(Y),"",!0)}
   </table></div>
 </div>
 <div class="sep-disclaimer">
   *Saya Menyetujui BPJS Kesehatan menggunakan informasi Medis Pasien jika diperlukan.<br/>
   *SEP bukan sebagai bukti penjamin peserta
 </div>
 ${g}
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div class="sep-sig-role">Pasien/<br/>Keluarga Pasien</div>
     ${i?`<img class="sep-qr" src="${t(i)}" alt="QR SEP" width="100" height="100" />`:""}
     <div class="sep-sig-name">(${t(f)})</div>
   </div>
 </div>
 </section>
</section>`}function ya(e){let L=e.find(O=>/^SPRI$/i.test(O.title)),a=V(e,/^SPRI$/i)[0]??"",i=L?new DOMParser().parseFromString(L.html,"text/html"):null,r=O=>{if(!i)return"-";for(let I of Array.from(i.querySelectorAll("tr"))){let T=Array.from(I.cells);if(!T.length)continue;let S=(T[0].textContent||"").replace(/\s+/g," ").trim();if(!O.test(S))continue;if(T.length===1)return S;let R=T.slice(1).map(g=>(g.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()).filter(Boolean).join(`
`).trim();if(R)return R}return"-"},u=(O,I)=>I.match(O)?.[1]?.trim()||"-",s=r(/^Pemeriksaan Fisik$/i),l=u(/Keadaan Umum\s*:\s*(.*?)\s*(?:Tensi|$)/i,s),o=u(/Tensi\s*:\s*(.*?)\s*(?:Nadi|$)/i,s),A=u(/Nadi\s*:\s*(.*?)\s*(?:RR|$)/i,s),p=u(/RR\s*:\s*(.*?)\s*(?:Suhu|$)/i,s),N=u(/Suhu\s*:\s*(.*?)\s*(?:BB|$)/i,s),D=u(/BB\s*:\s*(.*?)\s*(?:TB|$)/i,s),k=u(/TB\s*:\s*(.*?)$/i,s),x=u(/Pemeriksaan Fisik\s*:\s*([\s\S]*)$/i,s),f=r(/^Catatan$/i),w=r(/^Diit$/i),$=r(/^Terapi$/i),U=r(/^Kota Jambi,.*Jam|^Waktu Pengantar/i),F=U.match(/^(Kota Jambi,.*?Jam\s*\d{1,2}:\d{2})/i)?.[1]||U,Q=M("dokter","dpjp"),E=M("tgl_lahir","tglLahir").split(/\s*\/\s*/),Y=E.length>1?`${E[1]} (${E[0]})`:E[0]||"-";return`<section class="rm-page" id="rm-03">
${W("RM. 03")}
<div class="rm-form-title">SURAT PENGANTAR RAWAT INAP (SPRI)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${n("Umur / Tgl. Lahir",Y)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Alamat",nt(e))}
    ${n("Dikirim Oleh",Q)}
    ${n("Waktu Pengantar",F)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr><th colspan="7">PEMERIKSAAN TANDA VITAL &amp; ANTROPOMETRI SAAT MASUK</th></tr>
    <tr>
      <th>KEADAAN UMUM</th><th>TEKANAN DARAH</th><th>NADI</th>
      <th>PERNAPASAN (RR)</th><th>SUHU</th><th>BERAT BADAN</th><th>TINGGI BADAN</th>
    </tr>
  </thead>
  <tbody><tr>
    <td class="center"><strong>${t(l)}</strong></td>
    <td class="center"><strong>${t(o)}</strong></td>
    <td class="center">${t(A)}</td>
    <td class="center">${t(p)}</td>
    <td class="center">${t(N)}</td>
    <td class="center">${t(D)}</td>
    <td class="center">${t(k)}</td>
  </tr></tbody>
</table>

<table class="rm-grid-table">
  <tbody>
    <tr><td style="width: 175px;"><strong>ANAMNESIS</strong></td><td>${K(r(/^Anamnesis$/i))}</td></tr>
    <tr><td><strong>RIWAYAT PENYAKIT KELUARGA</strong></td><td>${K(r(/^Riwayat Penyakit Keluarga$/i))}</td></tr>
    <tr><td><strong>RIWAYAT ALERGI</strong></td><td>${K(r(/^Riwayat Alergi$/i))}</td></tr>
    <tr><td><strong>PEMERIKSAAN FISIK / CATATAN</strong></td><td>${x!=="-"?`<strong>${K(x)}</strong>`:"-"}${f!=="-"?`<br/>${K(f)}`:""}</td></tr>
    <tr><td><strong>PEMERIKSAAN PENUNJANG AWAL</strong></td><td>${K(r(/^Pemeriksaan Penunjang$/i))}</td></tr>
    <tr><td><strong>DIAGNOSA KERJA</strong></td><td><strong>${K(r(/^Diagnosa Kerja$/i))}</strong></td></tr>
    <tr><td><strong>TERAPI &amp; DIIT AWAL</strong></td><td>${K($)}${w!=="-"?`<br/><strong>Diit :</strong> ${K(w)}`:""}</td></tr>
  </tbody>
</table>

<div class="rm-signature-block" style="justify-content:flex-end;">
  <div class="rm-sig-box">
    <div>${t(F)}</div>
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(Q)} )</div>
  </div>
</div>
</section>`}function Da(e){let L=e.find(T=>/^SBPK$/i.test(T.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=new Map,r=new Map,u=[],s="-";if(a){for(let R of Array.from(a.querySelectorAll("tr"))){let g=Array.from(R.cells);for(let c=0;c<g.length-2;c++){let P=(g[c].textContent||"").replace(/\s+/g," ").trim();if((g[c+1].textContent||"").trim()!==":")continue;let m=(g[c+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();P&&m&&!i.has(P)&&i.set(P,m)}g.length>=5&&/^[A-Z]\d{2}(?:\.\d+)?$/.test(g[2].textContent?.trim()??"")&&g[0].textContent?.trim()&&g[1].textContent?.trim()&&u.push({unit:(g[0].textContent||"").replace(/\s+/g," ").trim(),diag:(g[1].textContent||"").replace(/\s+/g," ").trim(),icd:(g[2].textContent||"").trim(),dokter:(g[4].textContent||"").replace(/\s+/g," ").trim()||"-"})}for(let R of Array.from(a.querySelectorAll("li"))){let g=(R.textContent||"").replace(/\s+/g," ").trim();if(!g||/\([A-Z]\d{2}(?:\.\d+)?\)$/i.test(g))continue;let c=g.toUpperCase();r.set(c,(r.get(c)||0)+1)}let T=Array.from(a.querySelectorAll("table")),S=(T[T.length-1]?.textContent||"").match(/\((dr\.[^)]+)\)/i);S&&(s=S[1].trim())}let l=T=>{for(let[S,R]of i)if(T.test(S))return R;return"-"},o=l(/^No Kartu BPJS$/i),A=M("norm","rekam_medis"),p=M("nama"),N=l(/^Tanggal lahir/i),D=l(/^Alamat$/i),k=M("no_sep","sep")!=="-"?M("no_sep","sep"):l(/^No SEP$/i),x=l(/^Jenis Kelamin$/i),f=/^L$/i.test(x)?"Laki-laki (L)":/^P$/i.test(x)?"Perempuan (P)":x,w=l(/^Tgl\.? Masuk RS$/i),$=l(/^Berat badan/i),U=u[0]?.unit||l(/^Unit Pelayanan|^Poliklinik/i),F=l(/^ANAMNESE$/i),Q=s!=="-"?s:M("dokter","dpjp"),E=V(e,/^SBPK/i)[0]??"",Y=V(e,/^SEP/i)[0]??V(e,/^Rincian Biaya/i)[0]??"",O=u.length?u.map(T=>`<tr><td>${t(T.unit)}</td><td>Diagnosa</td><td><strong>${t(T.diag)}</strong></td><td class="center">${t(T.icd)}</td><td>${t(T.dokter)}</td></tr>`).join(""):`<tr><td>${K(U)}</td><td>Diagnosa Utama</td><td><strong>${K(l(/^Diagnosa utama/i))}</strong></td><td class="center">-</td><td>${t(Q)}</td></tr>
       <tr><td>${K(U)}</td><td>Diagnosa Tambahan</td><td>${K(l(/^Diagnosa tambahan/i))}</td><td class="center">-</td><td>${t(Q)}</td></tr>`,I=Array.from(r.entries()).map(([T,S],R)=>`<tr><td class="center">${R+1}</td><td>${t(T)}</td><td>${t(Q)}</td><td class="center">${S}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi SBPK Item ${R+1}"></td></tr>`).join("");return`<section class="rm-page" id="rm-02">
${W("RM. 02")}
<div class="rm-form-title">SURAT BUKTI PELAYANAN KESEHATAN (SBPK)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("No. Kartu BPJS",o)}
    ${n("No. Rekam Medis",A)}
    ${n("Nama Pasien",p,!0)}
    ${n("Tgl. Lahir / Umur",N)}
    ${n("Alamat",D)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("No. SEP",k)}
    ${n("Jenis Kelamin",f)}
    ${n("Tgl. Masuk RS",`${w} (*)`,!0)}
    ${n("Berat Badan Bayi",$)}
    ${n("Unit Pelayanan",U)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    <tr>
      <td style="width: 170px;"><strong>Hasil anamnesa datang untuk</strong></td>
      <td>
        <span class="static-box">&nbsp;</span> Suspek &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&#10003;</span> <strong>Tegak Diagnosa</strong> &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Observasi &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Kontrol lanjutan &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Buka Balutan / Jahitan
      </td>
    </tr>
    <tr><td><strong>ANAMNESE</strong></td><td>${K(F)}</td></tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 150px;">POLIKLINIK / RUANG</th>
    <th style="width: 120px;">JENIS DIAGNOSA</th>
    <th>DIAGNOSA</th>
    <th style="width: 65px;">ICD X</th>
    <th style="width: 165px;">DOKTER / PETUGAS</th>
  </tr></thead>
  <tbody>${O}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>TINDAKAN / PEMERIKSAAN PENUNJANG / TERAPI (TERAGGREGASI)</th>
    <th style="width: 165px;">UNIT / DOKTER PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${I}</tbody>
</table>

<div class="footnote-rm">
  (*) Catatan Sistem: periksa kembali tanggal masuk pada SBPK dengan SEP &amp; Resume sebelum berkas dikirim.
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Pasien / Keluarga Pasien</div>
    ${Y?`<img class="rm-sig-qr" src="${t(Y)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${Y?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(p)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penanggung Jawab Pelayanan (DPJP)</div>
    ${E?`<img class="rm-sig-qr" src="${t(E)}" alt="QR persetujuan DPJP" width="80" height="80" />`:""}
    ${E?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(Q)} )</div>
  </div>
</div>
</section>`}var Kt=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];function Ct(e){let L=String(e??"").replace(/^\s*:\s*/,"").trim(),a=L.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/)||L.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(!a)return L||"-";let[i,r,u]=a.slice(1),s=i.length===4?i:u,l=Kt[Number(r)-1];return l?`${Number(i.length===4?u:i)} ${l} ${s}`:L}function xa(e){let L=e.find(O=>/^Surat (?:Rencana )?Kontrol/i.test(O.title)),a=L?kt(L.html):"",i=O=>Qt(a.match(O)?.[1]||"")||"-",r=(O,I)=>i(new RegExp(`${O}\\s*:\\s*([\\s\\S]*?)(?=${I}|$)`,"i")),u=(O,I)=>{for(let T of O){let S=M(T);if(S!=="-")return S}return i(I)},s=L&&new DOMParser().parseFromString(L.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||""||V(e,/^SEP/i)[0]||V(e,/^Resume/i)[0]||V(e,/^SBPK/i)[0]||V(e,/^Rincian Biaya/i)[0]||"",l=u(["no_surat_kontrol","no_surat"],/NO\.\s*([0-9A-Z]{10,})/i),o=i(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i)!=="-"?i(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i):M("dokter","dpjp"),A=M("dokter","dpjp")!=="-"?M("dokter","dpjp"):o,p=u(["kartu","no_kartu","noka"],/No\.?\s*Kartu\s*[:.]?\s*([\s\S]*?)(?=Nama\s*Peserta|$)/i),N=M("norm","rekam_medis"),D=p.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),k=D?`${t(D[1].trim())}<span class="sep-inline-mr">No.MR : ${t(D[2].trim())}</span>`:`${t(p)}${N!=="-"?`<span class="sep-inline-mr">No.MR : ${t(N)}</span>`:""}`,x=M("nama")!=="-"?M("nama"):r("Nama\\s*Peserta","Tanggal Lahir"),f=M("jenis_kelamin","jk"),w=/perempuan|^p$/i.test(f)?"Perempuan":/laki|^l$/i.test(f)?"Laki-laki":a.match(/Nama Peserta\s*:\s*[^()]*\((Perempuan|Laki-laki)\)/i)?.[1]||"",$=w&&!new RegExp(`\\(${w}\\)`,"i").test(x)?`${x} (${w})`:x,U=Ct(u(["tgl_lahir","tglLahir"],/Tanggal Lahir\s*[:.]?\s*([\s\S]*?)(?=Diagnosa|$)/i)),F=u(["diagnosa_awal","diagnosa"],/Diagnosa\s*[:.]?\s*([\s\S]*?)(?=Tanggal entri|$)/i),Q=Ct(u(["tanggalAwal","tgl_masuk","tgl"],/Tanggal entri\s*[:.]?\s*([\s\S]*?)(?=Demikian|$)/i)),E=(O,I)=>`<tr><td class="lbl">${O}</td><td class="sep">:</td><td class="val">${I}</td></tr>`,Y=O=>`<tr><td class="val" colspan="3" style="padding-top:6px;">${t(O)}</td></tr>`;return`<section class="rm-page sep-page" id="surat-kontrol">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${Yt}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT RENCANA KONTROL</div>
     <div class="sep-hospital">${t(wt.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-no-value" style="text-align:right;margin-bottom:10px;">NO. ${t(l)}</div>
 <div class="sep-columns">
   <div class="sep-col-left" style="flex:1 1 100%;"><table class="sep-kv-table">
     <tr><td class="lbl">Kepada Yth</td><td class="sep">:</td><td class="val"><strong>${t(o)}</strong></td></tr>
     ${Y("Mohon pemeriksaan dan penangan lebih lanjut :")}
     ${E("No.Kartu",k)}
     ${E("Nama Peserta",`<strong>${t($)}</strong>`)}
     ${E("Tanggal Lahir",t(U))}
     ${E("Diagnosa",t(F))}
     ${E("Tanggal entri",t(Q))}
     ${Y("Demikian atas bantuannya, diucapkan banyak terima kasih.")}
   </table></div>
 </div>
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div>Mengetahui,</div>
     ${s?`<img class="sep-qr" src="${t(s)}" alt="QR tanda tangan DPJP" width="100" height="100" />`:""}
     <div class="sep-sig-name">( ${t(A)} )</div>
   </div>
 </div>
 </section>
</section>`}function Ea(e){let L=e.find(m=>/^Rincian Biaya/i.test(m.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=new Map,r=new Map;if(a){let m=Array.from(a.querySelectorAll("table")),y=m.find(C=>/frek/i.test(C.rows[0]?.textContent||""));for(let C of Array.from(y?.rows??[])){let j=Array.from(C.cells).map(st=>(st.textContent||"").replace(/\s+/g," ").trim());if(j.length<6||!/^\d+\.?$/.test(j[0]))continue;let h=j[2]||"-",B=h.toUpperCase().replace(/\s+/g," ").trim(),_=parseInt(j[4],10)||1,Z=parseFloat((j[7]||"0").replace(/\./g,"").replace(",","."))||0,it=i.get(B);it?(it.frek+=_,it.jaminan+=Z):i.set(B,{name:h,petugas:j[3]||"-",frek:_,tarif:j[5]||"-",jaminan:Z})}let z=m.find(C=>/nama\s*obat/i.test(C.rows[0]?.textContent||""));for(let C of Array.from(z?.rows??[])){let j=Array.from(C.cells).map(st=>(st.textContent||"").replace(/\s+/g," ").trim());if(j.length<5||!/^\d+(\.\d+)?$/.test(j[2]))continue;let h=j[1].replace(/^\d+\s*/,"").trim()||"-",B=h.toUpperCase().replace(/\s+/g," ").trim(),_=parseFloat(j[2].replace(",","."))||0,Z=parseFloat((j[5]||"0").replace(/\./g,"").replace(",","."))||0,it=r.get(B);it?(it.qty+=_,it.jaminan+=Z):r.set(B,{name:h,qty:_,jaminan:Z})}}let u=m=>{if(!a)return 0;for(let y of Array.from(a.querySelectorAll("tr"))){let z=Array.from(y.cells).map(C=>(C.textContent||"").replace(/\s+/g," ").trim());if(z.some(C=>m.test(C)))for(let C of z.slice(1)){let j=parseFloat(C.replace(/\./g,"").replace(",","."));if(Number.isFinite(j)&&j!==0)return j}}return 0},s=u(/^Total Jasa Rp/i),l=u(/^Total Resep/i),o=u(/^Jasa Pelayanan/i),A=u(/^Biaya Administrasi/i),p=u(/^Biaya Materai/i),N=u(/^Diskon/i),D=u(/^Pembulatan/i),k=u(/^Total Biaya/i),x=s+l+o,f=Math.max(0,x-k),w=m=>m.toLocaleString("id-ID",{minimumFractionDigits:0,maximumFractionDigits:0}),$=(m,y,z=!1)=>`<div class="rm-sum-line"${z?' style="font-weight:bold;border-top:1px solid #000;"':""}><span>${t(m)}</span><span class="rm-sum-dots"></span><span>${t(y)}</span></div>`,U=Array.from(i.values()).map((m,y)=>`<tr><td class="center">${y+1}</td><td>${t(m.name)}</td><td>${t(m.petugas)}</td><td class="center">${m.frek}</td><td class="num">${t(m.tarif)}</td><td class="num">${w(m.jaminan)}</td></tr>`).join(""),F=Array.from(r.values()).map((m,y)=>`<tr><td class="center">${y+1}</td><td>${t(m.name)}</td><td class="center">${m.qty}</td><td class="num">${w(m.jaminan)}</td></tr>`).join(""),Q=M("norm","rekam_medis"),E=M("nama"),Y=M("dokter","dpjp"),O=nt(e),I=M("no_sep","sep"),T=[M("jenis"),M("kelas","ruang")].filter(m=>m!=="-").join(" / ")||"-",S=M("tanggalAwal","tgl_masuk","tgl"),R=M("tanggalAkhir","keluar","tgl_keluar"),g=V(e,/^Rincian Biaya/i),c=g.find(m=>/pasien/i.test(decodeURIComponent(m)))??g[0]??"",P=g.find(m=>/penerima/i.test(decodeURIComponent(m)))??g[1]??"";return`<section class="rm-page" id="rm-05">
${W("RM. 05")}
<div class="rm-form-title">RINCIAN BIAYA PELAYANAN RAWAT INAP &amp; FARMASI</div>

<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${n("No. Rekam Medis",Q)}
    ${n("Nama Pasien",E,!0)}
    ${n("Alamat Pasien",O)}
    ${n("Unit / Instalasi",T)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Golongan Pasien",`BPJS KESEHATAN (SEP: ${I})`)}
    ${n("Dokter DPJP",Y)}
    ${n("Periode Rawat",`${S} s/d ${R}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>URAIAN TINDAKAN / PELAYANAN</th>
    <th style="width: 155px;">DOKTER / PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="num" style="width: 88px;">TARIF (Rp)</th>
    <th class="num" style="width: 98px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${U}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>NAMA OBAT / ALKES</th>
    <th class="center" style="width: 52px;">QTY</th>
    <th class="num" style="width: 120px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${F}</tbody>
</table>

<div class="rm-summary">
  ${$("Sub Total Layanan Medis / Tindakan",w(s))}
  ${$("Sub Total Penjualan (Farmasi/Obat)",w(l))}
  ${$("Jasa Pelayanan (Jasa Medis/Paramudis)",w(o))}
  ${$("Jasa Sarana","0")}
  ${$("Biaya Administrasi",w(A))}
  ${$("Biaya Materai",w(p))}
  ${$("Diskon",w(N))}
  ${$("Pembulatan",w(D))}
  ${$("TOTAL TAGIHAN (KOTOR)",w(x),!0)}
  ${$("Ditanggung Jaminan / Klaim BPJS",w(k))}
  ${$("TANGGUNGAN PASIEN (Sisa yang harus dibayar)",w(f))}
  ${$("Uang Muka / Deposit","0")}
  ${$("Bayar (Tunai/Non-Tunai)",w(f))}
  ${$("Kembali","0")}
  ${$("Status",f===0?"Lunas":"-")}
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Yang Menyerahkan,</div>
    <div>Pasien / Keluarga Pasien</div>
    ${c?`<img class="rm-sig-qr" src="${t(c)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${c?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(E)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Yang Menerima</div>
    ${P?`<img class="rm-sig-qr" src="${t(P)}" alt="QR penerima" width="80" height="80" />`:""}
    ${P?"":'<div class="rm-sig-space"></div>'}
    <div>(Petugas Billing / Kasir)</div>
  </div>
</div>
</section>`}function Ia(e){let L=e.find(m=>/^Resume/i.test(m.title)),a=V(e,/^Resume/i)[0]??"",i=V(e,/^SEP/i)[0]??V(e,/^Rincian Biaya/i)[0]??"",r=L?new DOMParser().parseFromString(L.html,"text/html"):null,u=new Map;if(r)for(let m of Array.from(r.querySelectorAll("tr"))){let y=Array.from(m.cells);for(let z=0;z<y.length-2;z++){let C=(y[z].textContent||"").replace(/\s+/g," ").trim().replace(/^-\s*/,"").replace(/\s*:$/,"");if((y[z+1].textContent||"").trim()!==":")continue;let j=(y[z+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();C&&j&&!u.has(C)&&u.set(C,j)}}let s=(...m)=>{for(let[y,z]of u)if(m.some(C=>C.test(y)))return z;return"-"},l=m=>{for(let[y,z]of u)if(m.test(y))return z;return"-"},o=M("nama"),A=M("norm","rekam_medis"),p=M("tgl_lahir","tglLahir"),N=M("jenis_kelamin","jk"),D=s(/^Tanggal Masuk$/i),k=s(/^Tanggal Keluar$/i),x=s(/^Ruang Rawat$/i),f=s(/^Kelas$/i),w=M("dokter","dpjp"),$=s(/^Anemnesa|^Anamnesa/i),U=s(/^Pemeriksaan Fisik$/i),F=s(/^Hasil Pemeriksaan Diagnostik/i),Q=s(/^Diagnosa Utama$/i),E=s(/^Diagnosa Sekunder$/i),Y=s(/^Prosedur \/ Operasi|^Diagnosa Tindakan/i),O=s(/^Pengobatan$/i),I=s(/^Obat Pulang$/i),T=s(/^Kondisi Pulang$/i),S=s(/^Catatan Kondisi Pulang$/i),R=s(/^Jadwal Kontrol$/i),g=s(/^Pemeriksaan Lanjutan/i),c=[["TD",l(/^TD$/)],["HR",l(/^HR$/)],["RR",l(/^RR$/)],["S",l(/^S$/)],["SpO2",l(/^SPO2$/)],["GCS",l(/^GCS$/)]].filter(([,m])=>m!=="-").map(([m,y])=>`${m}: ${y}`).join(" | "),P=(m,y)=>`<tr><td style="width: 175px;"><strong>${m}</strong></td><td>${K(y)}</td></tr>`;return`<section class="rm-page" id="rm-06">
${W("RM. 06")}
<div class="rm-form-title">RINGKASAN PULANG (DISCHARGE SUMMARY)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",o,!0)}
    ${n("No. Rekam Medis",A,!0)}
    ${n("Tgl. Lahir / Kelamin",`${p} / ${N}`)}
    ${n("Jenis Kasus",s(/^Jenis Kasus$/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Masuk",D)}
    ${n("Tanggal Keluar",k)}
    ${n("Ruang / Kelas",`${x} / ${f}`)}
    ${n("DPJP / Rawat Bersama",w)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    ${P("ALASAN / INDIKASI RAWAT &amp; ANAMNESA",`${s(/^Alasan \/ Indikasi Rawat/i)}
${$}`.trim())}
    ${P("PEMERIKSAAN FISIK &amp; TANDA VITAL MASUK",`${U}${c?`
Vital Signs : ${c}`:""}`.trim())}
    ${P("HASIL PEMERIKSAAN DIAGNOSTIK",F)}
    ${P("DIAGNOSA UTAMA",Q)}
    ${P("DIAGNOSA SEKUNDER",E)}
    ${P("TINDAKAN / PROSEDUR (ICD-9-CM)",Y)}
    ${P("PENGOBATAN SELAMA RAWAT",O)}
    ${P("OBAT PULANG",I)}
    ${P("KONDISI &amp; CARA PULANG",`${T}
${S}`.trim())}
    ${P("INSTRUKSI &amp; JADWAL KONTROL",`${R}
${g}`.trim())}
    ${P("STATUS RUJUKAN &amp; PELAYANAN KB",s(/^Apakah pasien rujukan masuk/i))}
  </tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Mengetahui Pasien / Keluarga</div>
    ${i?`<img class="rm-sig-qr" src="${t(i)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${i?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(o)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Yang Membuat</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan DPJP" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(w)} )</div>
  </div>
</div>
</section>`}function Ta(e){let L=e.find(z=>/^Telaah/i.test(z.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=new Map,r=[],u=[],s=[];if(a){for(let C of Array.from(a.querySelectorAll("tr"))){let j=Array.from(C.cells).map(h=>(h.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let h=0;h<j.length-2;h++){let B=j[h].replace(/:$/,"").trim();j[h+1]===":"&&B&&j[h+2]&&!i.has(B)&&i.set(B,j[h+2])}for(let h of j){let B=h.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);B&&!i.has(B[1].trim())&&i.set(B[1].trim(),B[2].trim())}}for(let C of Array.from(a.querySelectorAll("tr"))){let j=Array.from(C.cells).map(B=>(B.textContent||"").replace(/\s+/g," ").trim());if(j.length<2||!/^R\/\d+$/i.test(j[0]))continue;let h=j[1].match(/^(.*?)\s*Jml:\s*(\S+)/i);r.push({no:j[0],name:h?h[1].trim():j[1],jml:h?h[2]:"-"})}for(let C of Array.from(a.querySelectorAll("table"))){let j=(C.rows[0]?.textContent||"").replace(/\s+/g," ").trim();if(!/^(Telaah Resep|Telaah Obat|Edukasi)/i.test(j))continue;let h=[];for(let B of Array.from(C.rows).slice(1)){let _=Array.from(B.cells).map(Z=>(Z.textContent||"").replace(/\s+/g," ").trim());_.length<2||!/^\d+$/.test(_[0])||h.push([_[0],_[1]])}h.length&&u.push({title:j.split(/\s{2,}/)[0]||j,rows:h})}let z=Array.from(a.querySelectorAll("table")).find(C=>/Hitung/i.test(C.rows[0]?.textContent||""));z&&s.push(...Array.from(z.rows[0].cells).map(C=>(C.textContent||"").replace(/\s+/g," ").trim()).filter(C=>/Hitung|Timbang|Kemas|Penyerahan/i.test(C)))}s.length||s.push("Hitung","Timbang","Kemas","Penyerahan");let l=(...z)=>{for(let[C,j]of i)if(z.some(h=>h.test(C)))return j;return"-"},o=z=>{for(let C of Array.from(document.querySelectorAll("td"))){let j=(C.textContent||"").replace(/\s+/g," ").trim(),h=j.match(z);if(!h)continue;let B=j.slice((h.index??0)+h[0].length).replace(/^\s*:\s*/,"").trim();if(B)return B;let _=(C.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim();if(_&&!/^:/.test(_))return _}return"-"},A=M("dokter","dpjp")!=="-"?M("dokter","dpjp"):l(/^Dokter/i),p=l(/^No Resep/i),N=o(/^Ruangan\/Poli/i)!=="-"?o(/^Ruangan\/Poli/i):l(/^Ruangan\/?Poli/i,/^Ruangan/i),D=o(/^Tanggal Periksa/i)!=="-"?o(/^Tanggal Periksa/i):l(/^Tanggal/i,/^Tanggal & Jam/i),k=o(/^Jam Datang/i)!=="-"?o(/^Jam Datang/i):l(/^Jam/i),x=l(/^SIP/i),f=M("nama")!=="-"?M("nama"):l(/^Nama Pasien/i),w=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):l(/^No\.? RM/i),$=nt(e),U=M("tgl_lahir","tglLahir").replace(/^:\s*/,"")||l(/^Tgl\.? Lahir/i),F=M("no_hp","telepon").replace(/^:\s*/,"")||l(/^No HP/i),Q=l(/^Penjamin/i),E=l(/alergi/i),Y=l(/berat|\bbb\b/i),O=M("jenis_kelamin","jk").replace(/^:\s*/,""),I=/perempuan|^p$/i.test(O)?"P":/laki|^l$/i.test(O)?"L":O,T=f+(I&&I!=="-"?` (${I})`:""),S=`${E!=="-"?E:"-"} / ${Y!=="-"?`BB ${Y}${/\bkg\b/i.test(Y)?"":" kg"}`:"- kg"}`,R=M("no_sep","sep")!=="-"?M("no_sep","sep"):M("kartu"),g='<table class="rm-grid-table"><thead><tr>'+s.map(z=>`<th class="center">${t(z)}</th>`).join("")+"</tr></thead><tbody><tr>"+s.map(()=>'<td style="height:30px">&nbsp;</td>').join("")+"</tr></tbody></table>",c=u.length?u.map(z=>`<table class="rm-grid-table"><thead><tr><th colspan="2">${t(z.title)}</th><th style="width:44px;">Y/T</th></tr></thead><tbody>`+z.rows.map(([C,j])=>`<tr><td class="center" style="width:28px;">${t(C)}</td><td>${t(j)}</td><td class="center">&nbsp;</td></tr>`).join("")+"</tbody></table>").join(""):"",P='<table class="rm-grid-table"><tbody><tr><th colspan="2">PERUBAHAN RESEP</th></tr><tr><th>Tertulis</th><th>Menjadi</th></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><td class="center">Apoteker</td><td class="center">Disetujui Dokter</td></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><th colspan="2">WAKTU TUNGGU</th></tr><tr><td>Masuk</td><td>&nbsp;</td></tr><tr><td>Diserahkan</td><td>&nbsp;</td></tr><tr><td>Paraf Pasien/Keluarga</td><td style="height:30px">&nbsp;</td></tr></tbody></table>',m=(z,C,j=!1)=>`<div class="tm-row${j?" long":""}"><span class="tm-label">${t(z)}:</span><span class="tm-val">${C&&C.trim()&&C!=="-"?t(C):"-"}</span></div>`,y=r.length?r.map(z=>`<div class="med"><span class="med-no">${t(z.no)}</span> <span class="med-name">${t(z.name)}</span>`+(z.jml&&z.jml!=="-"?`, <span class="med-jml">Jml: ${t(z.jml)}</span>`:"")+"</div>").join(""):'<div class="med">Tidak ada data obat pada halaman telaah.</div>';return`<section class="rm-page" id="rm-07">
${W("RM. 07")}
<div class="rm-form-title">FORMULIR TELAAH RESEP, TELAAH OBAT &amp; EDUKASI FARMASI</div>

<div class="t-main">
  <div class="t-left">
    <div class="tm-card tm-card--small tm-card--left"><div class="tm-col">
      ${m("Pasien",T)}
      ${m("No. RM",w)}
      ${m("Tgl. Lahir",U)}
      ${m("Alergi &amp; BB",S)}
      ${m("Alamat",$,!0)}
      ${m("No HP",F)}
    </div></div>
    <div class="t-meds">${y}</div>
    ${g}
    <table class="rm-grid-table t-lampiran"><thead><tr>
      <th>Srt. Rujuk Balik</th><th>Surat Iter</th><th>Hasil Lab</th>
    </tr></thead><tbody><tr>
      <td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td>
    </tr></tbody></table>
  </div>
  <div class="t-right">
    <div class="tm-card tm-card--right"><div class="tm-col">
      ${m("Dokter",A)}
      ${m("SIP Dokter",x)}
      ${m("No Resep",p)}
      ${m("No SEP",R)}
      ${m("Ruangan",N)}
      ${m("Tanggal",D)}
      ${m("Jam",k)}
      ${m("Penjamin",Q)}
    </div></div>
    ${c}
    ${P}
  </div>
</div>

<div class="footnote-rm">Obat tidak boleh diganti tanpa sepengetahuan Dokter.</div>
</section>`}var ba=/^(No\.?\s*(RONTGEN|RM)|Umur|Tanggal Periksa|Bed|Status|Nama Pasien|Jenis Kelamin|Alamat|dr\.?\s*(Pengirim|DPJP)|Dokter (Pengirim|DPJP)|Diagnosa (Klinis|ICD))/i,ka=/<div[^>]*class="[^"]*head-cetak-instansi[^"]*"[^>]*>\s*HASIL PEMERIKSAAN RADIOLOGI/i;function Ca(e,L,a="rm-08"){let i=L??e.find(r=>/^Radiologi/i.test(r.title));return Oa(i?.html??"",ka).map((r,u)=>{let s=V([{title:"Radiologi",html:r}],/Radiologi/i)[0]??"";return ha(e,r,s,u?`${a}-${u+1}`:a)}).join("")}function ha(e,L,a,i){let r=new DOMParser().parseFromString(L,"text/html"),u=Pa(r,ba),s=[],l="";for(let g of Array.from(r.querySelectorAll("tr"))){let c=Array.from(g.cells).map(ct);for(let P of c){let m=P.match(/^expertise\s*:\s*([\s\S]+)$/i);m&&!l&&(l=m[1].trim())}c.length>=4&&/^\d+$/.test(c[0])&&c[1]&&s.push({name:c[1],golongan:c[2],kontras:c[3]})}let o=(...g)=>{for(let[c,P]of u)if(g.some(m=>m.test(c)))return P;return"-"},A=o(/^No\.? RONTGEN/i),p=o(/^Tanggal Periksa/i),N=o(/^Umur/i),D=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):o(/^No\.? RM/i),k=M("nama")!=="-"?M("nama"):o(/^Nama Pasien/i),x=M("jenis_kelamin","jk").replace(/^:\s*/,"")||o(/^Jenis Kelamin/i),f=/perempuan|^p$/i.test(x)?"P":/laki|^l$/i.test(x)?"L":x,w=nt(e),$=o(/^Bed|^Ruang/i),U=o(/^Status/i),F=o(/^dr\.? Pengirim|^Dokter Pengirim/i),Q=o(/^dr\.? DPJP|^Dokter DPJP/i),E=(r.body.textContent||"").replace(/\s+/g," ").match(/\(\s*([^)]{3,80})\s*\)/)?.[1]?.trim()||"-",Y=Q!=="-"?Q:E!=="-"?E:xt(a),O=o(/^Diagnosa Klinis/i),I=o(/^Diagnosa ICD/i),T=s.length&&s[0].golongan||"-",S=s.length?s.map((g,c)=>`<tr><td class="center">${c+1}</td><td><strong>${t(g.name)}</strong></td><td class="center">${t(g.golongan||"-")}</td><td class="center">${t(g.kontras||"-")}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Radiologi ${c+1}"></td></tr>`).join(""):'<tr><td class="center">-</td><td>Tidak ada jenis pemeriksaan tercatat.</td><td class="center">-</td><td class="center">-</td><td class="center">-</td></tr>',R=l?l.replace(/^\s*\d+\.\s*/,"").replace(/^\n+|\n+$/g,"").split(`
`).map(g=>g.trim()).map(g=>g?`<div>${t(g)}</div>`:"<div>&nbsp;</div>").join(""):"<div>Tidak ada expertise tercatat pada halaman.</div>";return`<section class="rm-page" id="${t(i)}">
${W("RM. 08")}
<div class="rm-form-title">HASIL PEMERIKSAAN RADIOLOGI</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("No. Rontgen",A,!0)}
    ${n("Tanggal Periksa",p)}
    ${n("No. Rekam Medis",D)}
    ${n("Nama Pasien",k,!0)}
    ${n("Jenis Kelamin",f!=="-"?`Laki-laki / Perempuan (${f})`:"-")}
    ${n("Alamat",w)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Umur / Tgl. Lahir",N)}
    ${n("Ruang / Asal",$!=="-"&&U!=="-"?`${$} (Status: ${U})`:$)}
    ${n("Dokter Pengirim",F)}
    ${n("Dokter DPJP / Penilai",Y)}
    ${n("Diagnosa Klinis",O)}
    ${n("Diagnosa ICD",I)}
    ${n("Status Pasien",U)}
    ${n("Golongan / Jenis",`${T} \u2014 ${s[0]?.kontras||"-"}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>JENIS PEMERIKSAAN</th>
    <th style="width: 110px;">GOLONGAN</th>
    <th style="width: 110px;">KONTRAS</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${S}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr><th>URAIAN EXPERTISE &amp; KESAN PEMERIKSAAN</th></tr></thead>
  <tbody><tr><td style="padding: 8px 10px; line-height: 1.5;">${R}</td></tr></tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>No. Rontgen : ${t(A)}</div>
    <div>Jenis Pemeriksaan : ${t(T)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penilai</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan radiolog" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(Y)} )</div>
  </div>
</div>
</section>`}var za=e=>{for(let L of e){if(!/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(L.title))continue;let a=new DOMParser().parseFromString(L.html,"text/html");for(let i of Array.from(a.querySelectorAll("table"))){let r=Array.from(i.rows[0]?.cells||[]).map(u=>ct(u)).join(" ");if(/^Triase/i.test(r))return Array.from(i.rows).slice(1).map(u=>Array.from(u.cells).map(ct))}}return[]};function fa(e){let L=e.find(S=>/^Triage/i.test(S.title)),a=V(e,/^Triage/i)[0]??"",i=L?new DOMParser().parseFromString(L.html,"text/html"):null,r=new Map,u="-";if(i){for(let R of Array.from(i.querySelectorAll("tr"))){let g=Array.from(R.cells).map(c=>(c.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let c=0;c<g.length-2;c++){let P=g[c].replace(/:$/,"").trim();g[c+1]===":"&&P&&g[c+2]&&!r.has(P)&&r.set(P,g[c+2])}for(let c of g){let P=c.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);!P||P[2].includes(":")||P[2].length>120||r.has(P[1].trim())||r.set(P[1].trim(),P[2].trim())}}let S=(i.textContent||"").replace(/\s+/g," ").match(/Dokter yang memeriksa\s*\(([^)]+)\)/i);S&&(u=S[1].trim())}let s=(...S)=>{for(let[R,g]of r)if(S.some(c=>c.test(R)))return g;return"-"},l=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):s(/^No\.?\s*RM/i),o=M("nama")!=="-"?M("nama"):s(/^Nama$/i),A=s(/^Tanggal$/i),p=s(/^Jam Datang/i),N=s(/^Jam Registrasi/i),D=s(/^Cara Datang/i),k=s(/^Diantar Polisi/i),x=s(/^No\.?\s*ID/i),f=s(/^Pengantar Pasien/i),w=s(/^Riwayat Penyakit Dahulu/i),$=s(/^Keluhan Utama/i),U=s(/^Keadaan Umum/i),F=s(/^Suhu/i),Q=s(/^Nadi/i),E=s(/^RR$/i),Y=s(/^Tekanan Darah/i),O=s(/^Jam$/i),I=s(/^No\.?\s*Antrian/i),T=s(/^Status/i);return`<section class="rm-page" id="triage">
${W("TRIAGE")}
<div class="rm-form-title">TRIAGE TERINTEGRASI &amp; PENGKAJIAN AWAL IGD</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("No. Rekam Medis",l,!0)}
    ${n("Nama Pasien",o,!0)}
    ${n("Tanggal",A)}
    ${n("Jam Datang",p)}
    ${n("Jam Registrasi",N)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Cara Datang",D)}
    ${n("Diantar Polisi",k)}
    ${n("No. ID",x)}
    ${n("Pengantar Pasien",f)}
    ${n("Status Triage",T,!0)}
  </table></div>
</div>

<div class="sub-heading-rm">ANAMNESA &amp; RIWAYAT</div>
<table class="rm-grid-table"><tbody>
  ${n("Riwayat Penyakit Dahulu",w)}
  ${n("Keluhan Utama",$)}
</tbody></table>

<div class="sub-heading-rm">TANDA VITAL &amp; PEMERIKSAAN</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${n("Keadaan Umum",U)}
    ${n("Suhu (\xB0C)",F)}
    ${n("Nadi (x/menit)",Q)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("RR (x/menit)",E)}
    ${n("Tekanan Darah (mmHg)",Y)}
    ${n("Jam",O)}
    ${n("No. Antrian",I)}
  </table></div>
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Status Triage : ${t(T)}</div>
    <div>No. Antrian : ${t(I)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(u!=="-"?u:xt(a))} )</div>
  </div>
</div>
</section>`}function $a(e){let L=e.find(d=>/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(d.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=a?Array.from(a.querySelectorAll("table")):[],r=d=>(d.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim(),u=d=>d?Array.from(d.rows).map(v=>Array.from(v.cells).map(r)):[],s=d=>{let v=i.find(G=>d.test((G.rows[0]?.textContent||"").replace(/\s+/g," ").trim()));return u(v)},l=d=>{let v=i.find(G=>d.test(G.textContent||""));return u(v)},o=i.find(d=>/^Usia$/i.test((d.rows[1]?.cells[1]?.textContent||"").trim())),A=i.find(d=>/^Riwayat Jatuh$/i.test((d.rows[1]?.cells[1]?.textContent||"").trim())),p=d=>d.reduce((v,G)=>{let q=y(G),X=q==="-"?0:Number(q);return v+(Number.isFinite(X)?X:0)},0),N=(d,v)=>v?d>=45?"TINGGI":d>=25?"SEDANG":"RENDAH":d>=12?"TINGGI":d>=6?"SEDANG":"RENDAH",D=(d,v)=>{let G=p(d);return`${G} \u2014 ${N(G,v)}`},k=d=>d?Array.from(d.rows).map((v,G)=>{let q=Array.from(v.cells).map(X=>{let rt=ct(X),Nt=X.rowSpan>1?` rowspan="${X.rowSpan}"`:"",tt=X.colSpan>1?` colspan="${X.colSpan}"`:"",ft=/JUMLAH SKOR|Keterangan Hasil|Catatan/i.test(rt),$t=rt.includes("\u2713"),Tt=G===0?"th":"td";return`<${Tt}${Nt}${tt}${ft?' style="font-weight:bold;text-align:right;"':""}>${$t?`<strong>${t(rt)}</strong>`:t(rt||"-")}</${Tt}>`}).join("");return`<tr${G===0?' class="sec-hdr"':""}>${q}</tr>`}).join(""):'<tr><td colspan="5">-</td></tr>',x=s(/^Triase/i),f=s(/^Pengkajian\s*0\s*1\s*2\s*Nilai/i),w=l(/MORSE FALL SCALE/i),$=s(/^Objektif\s*Kelainan/i),U=s(/^Diagnosa Utama$/i),F=s(/^Diagnosa Banding$/i),Q=s(/^Tindakan$/i),E=s(/^Pukul\s*Nama Obat/i),Y=s(/^No\s*Nama Perawat IGD/i),O=(d,v)=>{let G=Array.isArray(v)?v.join(""):v;return'<table class="rm-grid-table"><thead><tr>'+d.map(q=>`<th>${t(q)}</th>`).join("")+"</tr></thead><tbody>"+(G||'<tr><td colspan="'+d.length+'">-</td></tr>')+"</tbody></table>"},I=f.slice(1).map(d=>{if(d.some(v=>/^TOTAL$/i.test((v||"").trim()))){let v=d[d.length-1]||"-";return`<tr style="font-weight:bold;"><td colspan="4" style="text-align:right;"><strong>TOTAL</strong></td><td class="center"><strong>${t(v)}</strong></td></tr>`}return"<tr>"+d.map((v,G)=>`<td${G===0?"":' class="center"'}>${t(v||"-")}</td>`).join("")+"</tr>"}).join(""),T=$.slice(1).map(d=>`<tr><td>${t(d[0]||"-")}</td><td>${t(d.slice(1).filter(Boolean).join(" ")||"-")}</td></tr>`).join(""),S=[["DIAGNOSA UTAMA",U.slice(1).flat().filter(Boolean).join(" ")||"-"],["DIAGNOSA BANDING",F.slice(1).flat().filter(Boolean).join(" ")||"-"]].map(([d,v])=>`<tr><td style="width:180px;"><strong>${d}</strong></td><td>${t(v)}</td></tr>`).join(""),R=Q.slice(1).flat().filter(Boolean).join(" ")||"-",g=E.slice(1).filter(d=>d.some(Boolean)).map(d=>"<tr>"+d.slice(0,4).map(v=>`<td>${t(v||"-")}</td>`).join("")+"</tr>").join(""),c=Y.slice(1).flat().filter(Boolean).join(" \xB7 "),P=za(e).find(d=>(d[0]||"").includes("\u2713"))?.slice(1)||[],m=d=>{let v=d.find(X=>/^JUMLAH SKOR/i.test(X[0]||"")),G=d.find(X=>/^Keterangan Hasil/i.test(X[0]||"")),q=v?.slice(1).filter(Boolean).join(" ")||"-";return G?`${q} \xB7 ${G.slice(1).filter(Boolean).join(" ")}`:q},y=d=>document.querySelector(`input[name="${d}"]:checked`)?.value||"-",z=d=>(Array.from(a?.querySelectorAll("label")||[]).find(v=>d.test((v.textContent||"").replace(/\s+/g," ").trim()))?.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim()||"-",C=(Array.from(a?.querySelectorAll("div")||[]).find(d=>/^Planning\s*:\s*Terapy/i.test((d.textContent||"").trim().slice(0,80)))?.nextElementSibling?.textContent||"").split(/TINDAK LANJUT/i)[0].split(/Kondisi Pasien Saat Pindah/i)[0].replace(/[ \t]+/g," ").trim()||"-",j=M("pengkajian_keperawatan"),[h,B,_]=(()=>{let d=j.split(/\n\s*RPD\s*:/i),v=d[0].replace(/^\s*Subjektif\s*:\s*/i,"").trim()||"-",G=(d[1]||"").split(/\n\s*RPO\s*:/i);return[v,G[0]?.trim()||"-",G[1]?.trim()||"-"]})(),Z=(d,v)=>y(d)==="ya"?M(v):y(d)==="tidak"?"Tidak":"-",it=d=>{let v=Array.from(document.querySelectorAll(`input[name="${d}"]:checked`)).map(G=>G.value).filter(Boolean);return v.length?v.join(", "):"-"},st=d=>({tanpa_bantuan:"Jalan Tanpa Bantuan",kursi_roda:"Kursi Roda",tempat_tidur:"Brankar",dengan_bantuan:"Dengan Bantuan",tidak_ada:"Tidak mengalami cedera",lantas:"KLL",lainnya:"Lainnya",tidak:"Tidak Terganggu",ya:"Ada Gangguan",Bpjs:"BPJS Kesehatan"})[d]||d||"-",Lt=(d,v)=>`<tr><td style="width:175px;"><strong>${d}</strong></td><td>${v}</td></tr>`,Et=(d,v)=>`<tr><td class="lbl">${d}</td><td class="col">:</td><td class="val">${v}</td></tr>`,It=Number(M("nutrisi_bb")),pt=Number(M("nutrisi_tb"))/100,gt=It>0&&pt>0?(It/(pt*pt)).toFixed(1).replace(".",","):"-";return`<section class="rm-page" id="pengkajian-igd">
${W("PENGKAJIAN IGD")}
<div class="rm-form-title">LEMBAR PENGKAJIAN INSTALASI GAWAT DARURAT</div>

<div class="igd-masthead">
  <div class="igd-masthead-label">Pasien \xB7 Instalasi Gawat Darurat</div>
  <div class="igd-masthead-name">${t(M("nama"))}</div>
</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${n("Tgl. Lahir / Umur",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?"Perempuan (P)":"Laki-laki (L)")}
    ${n("Agama / Suku",`${z(/^Agama/i)} / ${z(/^Suku/i)}`)}
    ${n("Pekerjaan",M("pekerjaan"))}
    ${n("No. Telp / HP",M("no_hp","telepon"))}
    ${n("Nama Orangtua / Pasangan",`${M("nama_orangtua")} / ${M("nama_pasangan")}`)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Masuk",M("tgl_masuk"))}
    ${n("Tiba di IGD / Diperiksa",`Pukul ${M("pukul_tiba_di_rs")} / Diperiksa Pukul ${M("pukul_diperiksa")}`)}
    ${n("Prosedur Masuk",st(y("kaji[prosedur_masuk]")))}
    ${n("Cara Masuk",st(y("kaji[cara_masuk]")))}
    ${n("Penyebab Cedera",st(y("kaji[penyebab_cedera]")))}
    ${n("Status Alergi",Z("kaji[status_alergi]","status_alergi_text"))}
    ${n("Gangguan Perilaku",st(y("kaji[gangguan_perilaku]")))}
    ${Et("Status Kehamilan",/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?t(M("status_kehamilan")):'<span class="filter-note">Tidak berlaku (Pasien Laki-laki \u2014 disaring otomatis)</span>')}
  </table></div>
</div>

<div class="igd-summary">
  <div><span>Triase</span><b>${t(P[0]||"-")} ${t(P[1]||"")}</b></div>
  <div><span>GCS / Kesadaran</span><b>${t(M("vital_gcs"))} \xB7 ${t(M("vital_kesadaran"))}</b></div>
  <div><span>SpO2 / Nadi</span><b>${t(M("vital_spo"))} \xB7 ${t(M("vital_nadi"))}</b></div>
  <div><span>Risiko Jatuh (Morse)</span><b>${t(m(w))}</b></div>
</div>

<div class="sub-heading-rm">KONDISI AWAL &amp; RIWAYAT</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${n("Prosedur Masuk",y("kaji[prosedur_masuk]"))}
    ${n("Cara Masuk",y("kaji[cara_masuk]"))}
    ${n("Status Alergi",Z("kaji[status_alergi]","status_alergi_text"))}
    ${n("Status Psikologi",y("kaji[status_psikologi]"))}
    ${n("Status Sosial",y("kaji[status_sosial]"))}
    ${n("Status Ekonomi",y("kaji[status_ekonomi]"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Nutrisi (BB/TB)",`${M("nutrisi_bb")} kg / ${M("nutrisi_tb")} cm`)}
    ${n("Kognitif",y("kaji[fungsi_kognitif]"))}
    ${n("Motorik",y("kaji[fungsi_motorik]"))}
    ${n("Hambatan Pembelajaran",Z("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text"))}
    ${n("Kebutuhan Edukasi",y("kaji[kebutuhan_edukasi]"))}
    ${n("Penerjemah",Z("kaji[dibutuhkan_penerjemah]","penerjemah_text"))}
  </table></div>
</div>

<div class="sub-heading-rm">TANDA VITAL SAAT MASUK</div>
${O(["TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","GCS (E/V/M)","KESADARAN"],["<tr>"+[ht(M("vital_td")),M("vital_nadi"),M("vital_nafas"),M("vital_suhu"),M("vital_spo"),M("vital_gcs")].map(d=>`<td class="center">${t(d)}</td>`).join("")+`<td class="center">${t([M("vital_e"),M("vital_m"),M("vital_v")].join("/"))}</td><td class="center">${t(M("vital_kesadaran"))}</td></tr>`])}

<div class="sub-heading-rm">KONDISI SAAT PINDAH / PULANG DARI IGD</div>
${O(["PUKUL","TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","KESADARAN"],["<tr>"+[M("waktu_pasien_pulang"),ht(M("kondisi_pasien_td")),M("kondisi_pasien_nadi"),M("kondisi_pasien_nafas"),M("kondisi_pasien_suhu"),M("kondisi_pasien_spo"),M("kondisi_pasien_gcs"),M("kondisi_pasien_kesadaran")].map(d=>`<td class="center">${t(d)}</td>`).join("")+"</tr>"])}

<div class="sub-heading-rm">TRIASE (DIISI OLEH DOKTER)</div>
<table class="rm-table">
  <thead>
    <tr><th style="width:34px;">PILIH</th><th style="width:95px;">SKALA TRIASE</th><th>KATEGORI &amp; KETERANGAN KLINIS</th><th style="width:105px;">RESPON TIME</th></tr>
  </thead>
  <tbody>${x.slice(1).map(d=>{let v=(d[0]||"").includes("\u2713"),G=d.length>=4?d.slice(1,4):d.slice(0,3);return`<tr${v?' style="font-weight:bold;"':""}><td class="center"><span class="chk-box">${v?"&#10003;":"&nbsp;"}</span></td>${G.map(q=>`<td>${t(q||"-")}</td>`).join("")}</tr>`}).join("")}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">II. PENGKAJIAN PSIKOSOSIAL, SPIRITUAL, EKONOMI, NUTRISI &amp; FUNGSIONAL</td></tr></thead>
  <tbody>
    ${Lt("Status Psikologi",y("kaji[status_psikologi]")||"-")}
    ${Lt("Status Sosial &amp; Spiritual",`Hubungan keluarga: ${y("kaji[status_sosial]")||"-"} | Kegiatan keagamaan: ${t(M("status_spiritual"))}`)}
    ${Lt("Status Pembiayaan",st(y("kaji[status_ekonomi]")))}
    ${Lt("Antropometri &amp; Nutrisi",`BB: <strong>${t(M("nutrisi_bb"))} Kg</strong> | TB: <strong>${t(M("nutrisi_tb"))} Cm</strong> | IMT: <strong>${gt} kg/m&sup2;</strong> | Konsul Gizi: ${y("kaji[nutrisi_konsul]")||"-"}`)}
    ${Lt("Status Fungsional",`Kognitif: ${y("kaji[fungsi_kognitif]")||"-"} | Motorik: ${y("kaji[fungsi_motorik]")||"-"}`)}
    ${Lt("Komunikasi &amp; Edukasi",`Hambatan: ${Z("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text")} | Penerjemah: ${Z("kaji[dibutuhkan_penerjemah]","penerjemah_text")} | Kebutuhan Edukasi: ${it("kaji[kebutuhan_edukasi]")}`)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">III. ASESMEN NYERI \u2014 WONG BAKER / NRS (PQRST)</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;"><strong>Skala Wong Baker</strong></td>
      <td><span class="filter-note">Skala nyeri Wong Baker (0\u20135) \u2014 lihat halaman asal; di dossier ini tidak ditampilkan sebagai gambar.</span></td>
    </tr>
    <tr><td><strong>(P) Faktor Pencetus</strong></td><td>${t(M("faktor_pencetus"))}</td></tr>
    <tr><td><strong>(Q) Kualitas Nyeri</strong></td><td>${y("kaji[qualitas]")||"-"}</td></tr>
    <tr><td><strong>(R) Lokasi &amp; Penjalaran</strong></td><td>${t(M("lokasi_nyeri"))} &nbsp;|&nbsp; <strong>Menjalar:</strong> ${y("kaji[nyeri_menjalar]")||"-"}</td></tr>
    <tr><td><strong>(S) Skala Nyeri (NRS 0\u201310)</strong></td><td>${t(M("skala_nyeri"))} &nbsp;|&nbsp; Wong Baker: ${t(M("emo_wong"))}</td></tr>
    <tr><td><strong>(T) Waktu &amp; Frekuensi</strong></td><td>${t(M("lamanya_nyeri"))} &nbsp;|&nbsp; ${y("kaji[nyeri_frekwensi]")||"-"}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="5">IV. PENGKAJIAN NYERI (FLACC)</td></tr>
    <tr><th>PENGKAJIAN</th><th>0</th><th>1</th><th>2</th><th>NILAI</th></tr>
  </thead>
  <tbody>${I||'<tr><td colspan="5">-</td></tr>'}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">V. ASESMEN AWAL RESIKO JATUH PADA ANAK (HUMPTY DUMPTY)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${D(["kaji[arja_usia]","kaji[arja_jenis_kelamin]","kaji[arja_diagnosis]","kaji[arja_gangguan_kognitif]","kaji[arja_faktor_lingkungan]","kaji[arja_respon_pembedahan]","kaji[arja_medikamentosa]"],!1)}</strong></td>
    </tr>
    ${k(o)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">VI. ASESMEN AWAL RESIKO JATUH PADA DEWASA (MORSE FALL SCALE)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${D(["kaji[arja_dewasa_jatuh]","kaji[arja_dewasa_diagnosa]","kaji[arja_dewasa_alat]","kaji[arja_dewasa_infus]","kaji[arja_dewasa_carajalan]","kaji[arja_dewasa_mental]"],!0)}</strong></td>
    </tr>
    ${k(A)}
  </tbody>
</table>

<div class="two-col-grid">
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0; height: 100%;">
      <thead>
        <tr class="sec-hdr"><td colspan="3">VI-A. PERBANDINGAN TANDA VITAL (OBJEKTIF)</td></tr>
        <tr><th>PARAMETER</th><th style="width: 108px;">AWAL IGD</th><th style="width: 108px;">PINDAH HCU</th></tr>
      </thead>
      <tbody>
        ${[["Tekanan Darah (TD)",M("vital_td"),M("kondisi_pasien_td")],["Nadi (HR)",M("vital_nadi"),M("kondisi_pasien_nadi")],["Pernapasan (RR)",M("vital_nafas"),M("kondisi_pasien_nafas")],["Suhu Aksila",M("vital_suhu"),M("kondisi_pasien_suhu")],["Saturasi Oksigen (SpO2)",M("vital_spo"),M("kondisi_pasien_spo")],["Kesadaran",M("vital_kesadaran"),M("kondisi_pasien_kesadaran")],["Skor GCS",M("vital_gcs"),M("kondisi_pasien_gcs")]].map(([d,v,G])=>`<tr><td><strong>${t(d)}</strong></td><td class="center">${t(v)}</td><td class="center">${t(G)}</td></tr>`).join("")}
      </tbody>
    </table>
  </div>
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0;">
      <thead>
        <tr class="sec-hdr"><td colspan="2">VI-B. PEMERIKSAAN FISIK LOKALIS &amp; PENUNJANG</td></tr>
        <tr><th>OBJEKTIF</th><th>KELAINAN</th></tr>
      </thead>
      <tbody>${T}</tbody>
    </table>
  </div>
</div>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">V. PENGKAJIAN MEDIS DOKTER IGD \u2014 ANAMNESIS (SUBJEKTIF)</td></tr></thead>
  <tbody>
    <tr><td style="width:155px;"><strong>(a) Keluhan Utama &amp; RPS</strong></td><td>${K(h)}</td></tr>
    <tr><td><strong>(b) Riwayat Penyakit Dahulu (RPD)</strong></td><td>${K(B)}</td></tr>
    <tr><td><strong>(c) Riwayat Penggunaan Obat (RPO)</strong></td><td>${K(_)}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">VI. DIAGNOSA &amp; TINDAKAN & PLANNING TERINTEGRASI</td></tr></thead>
  <tbody>
    ${S}
    <tr><td style="width:165px;"><strong>TINDAKAN</strong></td><td>${t(R)}</td></tr>
    <tr>
      <td><strong>PEMERIKSAAN PENUNJANG</strong></td>
      <td>EKG: ${t(z(/^EKG$/i))} &nbsp;|&nbsp; Radiologi: ${t(z(/^Radiologi$/i))} &nbsp;|&nbsp; Laboratorium: ${t(z(/^Laboratorium$/i))}</td>
    </tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">IX. PENGKAJIAN KEPERAWATAN &amp; MEDIS</td></tr></thead>
  <tbody><tr><td style="width:165px;"><strong>PENGKAJIAN KEPERAWATAN</strong></td><td>${K(M("pengkajian_keperawatan"))}</td></tr></tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">X. PLANNING / TERAPI TERINTEGRASI</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;vertical-align:top;"><strong>Tatalaksana Awal (A)</strong></td>
      <td>${K(C.split(/Konsul dr\./i)[0].trim()||"-")}</td>
    </tr>
    ${C.split(/(?=Konsul dr\.)/i).slice(1).map((d,v)=>{let G=d.match(/^Konsul (dr\.?[^:\n]+)/i)?.[1]?.trim()||"-",q=d.match(/Plan\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",X=d.match(/Terapi\s*:\s*([\s\S]*?)(?=Konsul dr\.|$)/i)?.[1]?.trim()||"-",rt=d.match(/Dx\s*:\s*([\s\S]*?)(?=Masalah\s*:|Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",Nt=d.match(/Masalah\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-";return`<tr>
          <td style="width:165px;vertical-align:top;"><strong>Advis ( ${String.fromCharCode(66+v)} ) \u2014 ${t(G)}</strong></td>
          <td>
            ${rt!=="-"?`<strong>Dx:</strong> ${K(rt)}<br/>`:""}
            ${Nt!=="-"?`<strong>Masalah:</strong> ${K(Nt)}<br/>`:""}
            ${q!=="-"?`<strong>Visite Plan:</strong> ${K(q)}<br/>`:""}
            ${X!=="-"?`<strong>Terapi:</strong> ${K(X)}`:""}
          </td>
        </tr>`}).join("")}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">XI. DISPOSISI TINDAK LANJUT</td></tr></thead>
  <tbody>
    <tr><td style="width:165px;"><strong>Tindak Lanjut</strong></td><td>${y("medis[tindak_lanjut]")||"-"}</td></tr>
    <tr><td><strong>Ruangan Rawat Inap</strong></td><td>${t(M("tindak_lanjut_ruangan_ranap"))} \u2014 Indikasi: ${t(M("tindak_lanjut_indikasi_ranap"))}</td></tr>
    <tr><td><strong>Pukul Pindah / Pulang</strong></td><td>${t(M("waktu_pasien_pulang"))}</td></tr>
    <tr><td><strong>Kondisi Pasien Saat Pindah</strong></td><td>TD ${t(ht(M("kondisi_pasien_td")))} | Nadi ${t(M("kondisi_pasien_nadi"))} | RR ${t(M("kondisi_pasien_nafas"))} | Suhu ${t(M("kondisi_pasien_suhu"))} | SpO2 ${t(M("kondisi_pasien_spo"))} | GCS ${t(M("kondisi_pasien_gcs"))} | Kesadaran ${t(M("kondisi_pasien_kesadaran"))}</td></tr>
  </tbody>
</table>

<div class="sub-heading-rm">OBAT / TERAPI IGD</div>
${O(["PUKUL","NAMA OBAT","DOSIS / RUTE","TANDA TANGAN"],g)}

<div class="sub-heading-rm">PERAWAT IGD</div>
<table class="rm-grid-table"><tbody><tr><td>${t(c||"-")}</td></tr></tbody></table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Ruangan : ${t(M("tindak_lanjut_ruangan_ranap"))}</div>
    <div>Perawat Ruangan : ${t(M("perawat_ruangan"))}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter IGD</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( ${t(M("dokter_igd","dokter"))} )</div>
  </div>
</div>
</section>`}function va(e,L){let a=[/^Telaah/i,/^SBPK/i,/^Radiologi/i],i=u=>{let s=a.findIndex(l=>l.test(u));return s<0?99:s},r=[...e].sort((u,s)=>i(u.title)-i(s.title));for(let u of r){let s=new DOMParser().parseFromString(u.html,"text/html");for(let l of Array.from(s.querySelectorAll("tr"))){let o=Array.from(l.cells).map(A=>(A.textContent||"").replace(/\s+/g," ").trim());for(let A=0;A<o.length-2;A++)if(L.test(o[A])&&o[A+1]===":"&&o[A+2])return o[A+2];for(let A of o){let p=A.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);if(p&&L.test(p[1].trim())&&p[2]&&!p[2].includes(":")&&p[2].length<=160)return p[2].trim()}}}return"-"}var nt=e=>St("alamat").replace(/^\s*:\s*/,"").trim()||va(e,/^Alamat/i),V=(e,L)=>{let a=e.find(r=>L.test(r.title));if(!a)return[];let i=new DOMParser().parseFromString(a.html,"text/html");return Array.from(i.querySelectorAll("img")).map(r=>r.getAttribute("src")||"").filter(r=>/qr|barcode/i.test(r))},xt=e=>{if(!e)return"-";try{let L=decodeURIComponent(e.replace(/\+/g," "));return(L.match(/oleh\s*:\s*([^&]+)/i)?.[1]||L.match(/approve\s*([\s\S]*?)\s+tgl\b/i)?.[1]||L.match(/(dr\.[^&]+)/i)?.[1]||"").split(/\s+(?:tgl|jam)\b/i)[0].replace(/\s+/g," ").trim()||"-"}catch{return"-"}},ht=e=>/\d/.test(e)?e:"-";function et(e,L){let a=e.find(u=>L.test(u.title)),i=a?new DOMParser().parseFromString(a.html,"text/html"):null,r=new Map;if(!i)return r;for(let u of Array.from(i.querySelectorAll("tr"))){let s=Array.from(u.cells).map(l=>(l.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let l=0;l<s.length-1;l++){let o=s[l].replace(/^[-:\s]+|[\s:]+$/g,"");!o||r.has(o)||(s[l+1]===":"&&s[l+2]?r.set(o,s[l+2]):s[l+1].startsWith(":")&&s[l+1].length>1&&r.set(o,s[l+1].replace(/^:\s*/,"").trim()))}for(let l of s)for(let o of l.split(/\n+/)){let A=o.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);A&&A[2].length<=120&&!r.has(A[1].trim())&&r.set(A[1].trim(),A[2].trim())}}return r}var At=e=>e.replace(/&gt;/gi,">").replace(/&lt;/gi,"<").replace(/&quot;/gi,'"').replace(/&#39;/g,"'").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&nbsp;/gi," ");function ct(e){return At((e.innerHTML||"").replace(/<!--[\s\S]*?-->/g,"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim())}function Oa(e,L){let a=new RegExp(L.source,L.flags.includes("g")?L.flags:L.flags+"g"),i=Array.from(e.matchAll(a)).map(r=>r.index??0);return i.length<2?[e]:i.map((r,u)=>e.slice(r,u+1<i.length?i[u+1]:e.length))}function Pa(e,L){let a=new Map;for(let i of Array.from(e.querySelectorAll("tr"))){let r=Array.from(i.cells).map(ct);for(let u=0;u<r.length-1;u++){let s=r[u].replace(/^[-:\s]+|[\s:]+$/g,"").trim();if(!L.test(s)||a.has(s))continue;let l=r[u+1].replace(/^:\s*/,"").trim();l&&a.set(s,l)}}return a}var Mt=(e,...L)=>{for(let[a,i]of e)if(L.some(r=>r.test(a)))return At(i);return"-"};function lt(e,L,a=30){let i=e.find(s=>L.test(s.title)),r=i?new DOMParser().parseFromString(i.html,"text/html"):null;if(!r)return[];let u=[];for(let s of Array.from(r.querySelectorAll("tr"))){let l=Array.from(s.cells).map(o=>(o.textContent||"").replace(/\s+/g," ").trim());if(l.length&&l.some(Boolean)&&u.push(l),u.length>=a)break}return u}var jt=e=>'<table class="rm-grid-table"><tbody>'+e.map(([L,a])=>`<tr><td style="width:175px;"><strong>${L}</strong></td><td>${K(a)}</td></tr>`).join("")+"</tbody></table>",ot=(e,L,a=!1)=>{let i=a?[...e,"VER (&#10003;)"]:e;return'<table class="rm-grid-table"><thead><tr>'+i.map(r=>`<th>${r}</th>`).join("")+"</tr></thead><tbody>"+(L.length?L.map(r=>"<tr>"+i.map((u,s)=>a&&s===i.length-1?'<td class="center"><input type="checkbox" class="rm-checkbox"></td>':`<td>${K(r[s]||"-")}</td>`).join("")+"</tr>").join(""):`<tr><td colspan="${i.length}">-</td></tr>`)+"</tbody></table>"},ut=(e,L)=>'<div class="rm-signature-block">'+[e,L].map((a,i)=>`<div class="rm-sig-box${i?"":" left-align"}">`+a.slice(0,-1).map(r=>`<div>${r}</div>`).join("")+`<div class="rm-sig-space"></div><div class="rm-sig-name">${a[a.length-1]}</div></div>`).join("")+"</div>";function Ua(e){let L=e.find(j=>/^Persetujuan Tindakan/i.test(j.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=a?Array.from(a.querySelectorAll("table")):[],r=j=>At((j.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()),u=j=>j?Array.from(j.rows).map(h=>Array.from(h.cells).map(r)):[],s=j=>j?.querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",l=j=>j.replace(/-->\s*/g,"").replace(/\btsb\b/gi,"tersebut").replace(/pembiuasan/gi,"pembiusan").replace(/\bizi Tuhan\b/gi,"izin Tuhan").replace(/\bresiko\b/gi,"risiko").replace(/\bAm\.?kep\b/gi,"A.Md.Kep").replace(/\s+/g," ").trim(),o=i.find(j=>/PEMBERIAN INFORMASI/i.test(j.rows[0]?.textContent||"")),A=i.find(j=>/JENIS INFORMASI/i.test(j.rows[0]?.textContent||"")),p=i.find(j=>/Dengan ini menyatakan bahwa saya dokter/i.test(j.rows[0]?.textContent||"")),N=i.find(j=>/PERSETUJUAN TINDAKAN KEDOKTERAN/i.test(j.rows[0]?.textContent||"")),D=u(o).slice(1).map(j=>[j[0]||"-",l((j[1]||j[2]||"-").replace(/^:\s*/,""))]).filter((j,h,B)=>B.findIndex(_=>_[0]===j[0])===h),k=u(A).slice(1).map((j,h)=>({no:/^\d+$/.test(j[0]||"")?j[0]:String(h+1),label:l(j[1]||"-"),isi:l(j[2]||"-"),centang:(j[3]||"").includes("\u2713")})),x=(p?Array.from(p.rows):[]).map(j=>({teks:l(r(j.cells[0])),ttd:l(j.cells[1]?r(j.cells[1]):""),qr:s(j.cells[1])})).filter((j,h,B)=>B.findIndex(_=>_.teks===j.teks)===h),f=u(N),w=l(f[2]?.join(" ")||"-"),$=l(f[3]?.join(" ")||"-"),U=(N?Array.from(N.rows[4]?.cells||[]):[]).map((j,h)=>({teks:l(r(j)),qr:h===2?s(j):""})),F=M("nama"),Q=j=>j.replace(/Jambi\s*,?\s*\d{1,2}\/\d{1,2}\/\d{4}\s*,?\s*Jam\s*[\d:.]+/gi,"").replace(/\s+/g," ").trim(),E=j=>j.match(/\(([^)]+)\)/)?.[1]?.trim()||Q(j)||"-",Y=Q(w),O=Q($),I=Y.match(/Nama\s*:\s*(.+?)(?=\s+Umur\s*:|$)/i)?.[1]?.trim()||"-",T=Y.match(/Umur\s*:\s*(.+?)(?=\s+Jenis Kelamin\s*:|$)/i)?.[1]?.trim()||"-",S=Y.match(/Jenis Kelamin\s*:\s*(.+?)(?=\s+Alamat\s*:|$)/i)?.[1]?.trim()||"-",R=Y.match(/Alamat\s*:\s*(.+)$/i)?.[1]?.trim()||"-",g=k.find(j=>j.no==="3")?.isi||"-",c=j=>O.match(j)?.[0]?.trim()||"",P=[c(/Saya memahami perlunya dan manfaat tindakan tersebut[\s\S]*?(?=Saya juga menyadari|$)/i),c(/Saya juga menyadari[\s\S]*?(?=Saya memahami perlunya tindakan pembiusan|Saya bertanggung jawab|$)/i),c(/Saya memahami perlunya tindakan pembiusan[\s\S]*?(?=Saya bertanggung jawab|$)/i),c(/Saya bertanggung jawab[\s\S]*$/i)].filter(Boolean),m=(j,h)=>{let B=Q(U[j]?.teks||"").replace(h,"");return E(B)},y=m(0,/Yang Menyatakan/i),z=m(1,/Saksi Keluarga/i),C=m(2,/Saksi Rumah Sakit/i);return`<section class="rm-page" id="form-konsent">
${W("RM. 19A")}
<div class="rm-form-title">PERSETUJUAN TINDAKAN KEDOKTERAN (RM 19 A)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",F,!0)}
    ${n("Umur",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
    ${n("Alamat",nt(e))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${D.map(([j,h])=>n(j,h,j==="Penerima Informasi / Pemberi Persetujuan")).join("")}
  </table></div>
</div>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="4">I. PEMBERIAN INFORMASI</td></tr>
    <tr><th style="width:28px;">NO</th><th>JENIS INFORMASI</th><th>ISI INFORMASI</th><th style="width:70px;">TANDA (&#10003;)</th></tr>
  </thead>
  <tbody>
    ${k.length?k.map(j=>`<tr><td class="center">${t(j.no)}</td><td>${t(j.label)}</td><td>${K(j.isi)}</td><td class="center">${j.centang?"&#10003;":"&nbsp;"}</td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="4">II. PERNYATAAN PEMBERI &amp; PENERIMA INFORMASI</td></tr></thead>
  <tbody>
    ${x.length?x.map((j,h)=>`<tr><td colspan="3">${K(Q(j.teks))}</td><td style="text-align:center;vertical-align:top;"><div>${h===0?"Tanda Tangan Dokter":"Tanda Tangan Penerima"}</div>`+(j.qr?`<img class="rm-sig-qr" src="${t(j.qr)}" alt="QR tanda tangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>')+`<div>( <strong>${t(E(j.ttd))}</strong> )</div></td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
    <tr><td colspan="4">* Bila pasien tidak kompeten atau tidak mau menerima informasi, maka penerima informasi adalah wali atau keluarga terdekat.</td></tr>
  </tbody>
</table>

<div style="border:1px solid #000000;margin-bottom:5px;">
  <div class="sec-hdr" style="border-bottom:1px solid #000000;padding:4px 6px;">III. PERSETUJUAN TINDAKAN KEDOKTERAN</div>
  <div style="padding:5px 8px;">
    <div>Yang bertanda tangan di bawah ini, saya:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:80px;">Nama</td><td style="width:10px;">:</td><td><strong>${t(I)}</strong></td><td style="width:80px;">Umur</td><td style="width:10px;">:</td><td>${t(T)}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td>${t(S)}</td><td>Alamat</td><td>:</td><td>${t(R)}</td></tr>
    </tbody></table>
    <div>Dengan ini menyatakan <strong>PERSETUJUAN</strong> untuk dilakukannya tindakan kedokteran (<strong>${t(g)}</strong>) terhadap: &nbsp; <span class="chk-box">&nbsp;</span> diri saya sendiri &nbsp; <span class="chk-box">&#10003;</span> <strong>Wali / Keluarga dari pasien</strong>:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:90px;">Nama Pasien</td><td style="width:10px;">:</td><td><strong>${t(F)}</strong></td><td style="width:70px;">Umur</td><td style="width:10px;">:</td><td>${t(M("tgl_lahir","tglLahir"))}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td><span class="chk-box">${/laki|^l$/i.test(M("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Laki-laki &nbsp; <span class="chk-box">${/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Perempuan</td><td>Alamat</td><td>:</td><td>${t(nt(e))}</td></tr>
    </tbody></table>
    ${P.map((j,h)=>`<div style="text-align:justify;margin:3px 0;">${h+1}. ${t(j)}</div>`).join("")}
    <table class="rm-table"><thead><tr>
      <th>Yang Menyatakan / Pemberi Persetujuan</th><th>Saksi Keluarga</th><th>Saksi Rumah Sakit</th>
    </tr></thead><tbody><tr>
      <td style="text-align:center;">
        ${U[0]?.qr?`<img class="rm-sig-qr" src="${t(U[0].qr)}" alt="QR penandatangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(y)}</strong> )
      </td>
      <td style="text-align:center;">
        ${U[1]?.qr?`<img class="rm-sig-qr" src="${t(U[1].qr)}" alt="QR saksi keluarga" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(z)}</strong> )
      </td>
      <td style="text-align:center;">
        ${U[2]?.qr?`<img class="rm-sig-qr" src="${t(U[2].qr)}" alt="QR saksi rumah sakit" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(C)}</strong> )
      </td>
    </tr></tbody></table>
  </div>
</div>
</section>`}function Bt(e){let L=e.find(b=>/^Anestesi/i.test(b.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=et(e,/^Anestesi/i),r=(...b)=>Mt(i,...b),u=(...b)=>{let J=At(r(...b)).replace(/\s+/g," ").trim();return J&&J!=="-"?J:"-"},s=a?(a.body.textContent||"").replace(/\s+/g," ").trim():"",l=a?Array.from(a.querySelectorAll("table")):[],o=b=>b?Array.from(b.rows).map(J=>Array.from(J.cells).map(at=>(at.textContent||"").replace(/\s+/g," ").trim())):[],A=b=>l.find(J=>b.test(Array.from(J.rows).flatMap(at=>Array.from(at.cells).filter(yt=>!yt.querySelector("table")).map(yt=>yt.textContent||"")).join(" "))),p=(b,J="after")=>{let at=b.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(J==="after"?`${at}\\s*\u2713`:`\u2713\\s*${at}`,"i").test(s)?"&#10003;":"&nbsp;"},N=(...b)=>{for(let J of e){let at=new DOMParser().parseFromString(J.html,"text/html");for(let yt of Array.from(at.querySelectorAll("tr"))){let Dt=Array.from(yt.cells).map(dt=>(dt.textContent||"").replace(/\s+/g," ").trim());for(let dt=0;dt<Dt.length-1;dt++){let se=Dt[dt].replace(/^[-:\s]+|[\s:]+$/g,"");if(!b.some(Le=>Le.test(se)))continue;let qt=Dt[dt+1]===":"?Dt[dt+2]||"":Dt[dt+1].replace(/^:\s*/,"").trim();if(qt)return qt}}}return"-"},D=M("nama")!=="-"?M("nama"):u(/^Nama Pasien/i),k=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):u(/^No\.? RM/i),x=M("tgl_lahir","tglLahir")!=="-"?M("tgl_lahir","tglLahir"):N(/^Tgl\.? Lahir|^Tanggal Lahir/i),f=M("umur")!=="-"?M("umur"):N(/^Umur/i),w=Number(f.match(/(\d{1,3})/)?.[1]||0),$=M("jenis_kelamin","jk")!=="-"?M("jenis_kelamin","jk"):N(/^Jenis Kelamin/i),U=/perempuan|^p$/i.test($)?"Perempuan (P)":/laki|^l$/i.test($)?"Laki-laki (L)":$,F=u(/^Dokter Anestesi/i),Q=u(/^Dokter Bedah/i)!=="-"?u(/^Dokter Bedah/i):M("dokter","dpjp"),E=u(/^Penata Anestesi/i),Y=u(/^Ruangan/i)!=="-"?u(/^Ruangan/i):M("jenis","kelas","ruang"),O=u(/^Tanggal/i)!=="-"?u(/^Tanggal/i):M("tgl","tanggalAwal","tgl_masuk"),I=u(/^Diagnosis Prabedah|^Diagnosa Pra/i),T=u(/^Diagnosis Pasca Bedah|^Diagnosa Pasca/i),S=u(/^Jenis pembedahan/i),R=u(/^Jenis operasi/i),g=u(/^Jam Mulai/i),c=b=>{let J=l.find(at=>b.test(at.rows[0]?.textContent||""));return J?o(J).slice(1).map(at=>at.slice(1).filter(Boolean).join(" ")).filter(Boolean).join(", "):"-"},P=c(/MEDIKASI/i),m=c(/PEMBERIAN CAIRAN/i),y=s.match(/kristaloid\s+(\d+)\s*ml/i)?.[1]??"-",z=s.match(/perdarahan\s*\(?EBL\)?\s*(\d+)\s*ml/i)?.[1]??"-",C=s.match(/diuresis\s*(\d+)\s*ml/i)?.[1]??"-",j=s.match(/Respirasi\s*:\s*([^,]+)/i)?.[1]?.trim()??"-",h=A(/Informed Consent/i),B=o(h).flat().filter(Boolean).map(b=>({label:b.replace(/^[\d\s✓]+/,"").trim(),on:/✓/.test(b)})).filter(b=>b.label&&b.label.length<60),_=B.length?B.map(b=>`<div><span class="chk-box">${b.on?"&#10003;":"&nbsp;"}</span> ${t(b.label)}</div>`).join(""):"<div>-</div>",Z=A(/PENYAKIT PENYERTA/i),it=o(Z).slice(1).filter(b=>b.length>=2&&/^(Sistem|lain-lain)/i.test(b[0])),st=it.length?it.map(b=>`<div><span class="chk-box">${/ya|ada|\+/i.test(b[1])?"&#10003;":"&nbsp;"}</span> ${t(b[0])}</div>`).join(""):"<div>-</div>",Lt=Array.from(a?.querySelectorAll("img")||[]).filter(b=>{if(!(b.getAttribute("src")||"").startsWith("data:image"))return!1;let J=`${b.id} ${b.getAttribute("class")||""} ${b.alt||""}`.toLowerCase();return!/logo|kars|qr|barcode/.test(J)}),Et=b=>b?`<div class="chart-frame">${b.outerHTML}</div>`:'<div class="chart-frame">Grafik tidak tersedia pada berkas ini.</div>',It=Et(Lt[0]),pt=Et(Lt[1]??Lt[0]),gt=V(e,/^Anestesi/i),d=[["Dokter Spesialis Anestesiologi",gt[0]||"",F],["Penata / Perawat Anestesi",gt[1]||"",E],["Perawat Ruangan",gt[2]||"",xt(gt[2])]].map(([b,J,at])=>'<div class="tte-box"><div>'+t(b)+'</div><div class="tte-qr">'+(J?`<img src="${t(J)}" alt="QR TTE" width="54" height="54" />`:"")+'</div><div class="tte-name">'+t(at)+"</div></div>").join(""),v=w>0&&w<18,G=p("Spinal","before")==="&#10003;"||p("Epidural","before")==="&#10003;"||p("Kaudal","before")==="&#10003;"||/subarachnoid/i.test(s),q=(...b)=>b.map(J=>M(J)).filter(J=>J!=="-").join(" / ")||"-",X=q("skorRR","skor15","skor30","skor1jam","skor2jam","skorkeluarRR"),rt=q("jampascaanestesi","jam15","jam30","jam45","1jam","2jam","3jam","4jam"),Nt=v?`<tr><td>Skor Steward</td><td colspan="3">Berlaku untuk pasien anak. Nilai: ${q("pergerakansteward","pernafasansteward","kesadaransteward")}</td></tr>`:`<tr><td>Aldrete Score</td><td colspan="3">Aktivitas \xB7 Pernapasan \xB7 Sirkulasi \xB7 Kesadaran \xB7 Warna \u2014 ${X!=="-"?`skor (RR/15'/30'/1j/2j/keluar): <strong>${t(X)}</strong>`:"skor diisi di halaman asal."}</td></tr>
       <tr><td>Bromage Score</td><td colspan="3">${G?`Gerakan penuh dari tungkai dan pergelangan kaki (blok motorik pulih) \u2014 ${rt!=="-"?`nilai: <strong>${t(rt)}</strong>`:"skor diisi di halaman asal."}`:"Tidak Berlaku (anestesi non-regional)."}</td></tr>
       <tr><td>Steward Score</td><td colspan="3"><em>Tidak Berlaku (khusus pasien anak \u2014 pasien dewasa).</em></td></tr>`,tt=(b,J="-")=>s.match(b)?.[1]?.trim()||J,ft=[`GCS ${tt(/GCS\s*:\s*(\d+)/i)}`,`TD ${tt(/Tekanan Darah\s*:\s*(\d+\s*\/\s*\d+)/i)} mmHg`,`Nadi ${tt(/Nadi\s*:\s*(\d+)/i)} x/mnt`,`RR ${tt(/RR\s*:\s*(\d+)/i)} x/mnt`,`BB ${tt(/BB\s*:\s*(\d+)/i)} kg`,`TB ${tt(/TB\s*:\s*(\d+)/i)} cm`].join(" \xB7 "),$t=[`Suntikan ${tt(/Suntikan Jam\s*:\s*([\d:]+)/i)}`,`Analgesia ${tt(/analgesia Jam\s*:\s*([\d:]+)/i)}`,`Operasi ${tt(/operasi Jam\s*:\s*([\d:]+)/i)}`].join(" \xB7 "),Tt=[`Masuk RR ${tt(/Masuk ruangan pemulihan jam\s*:\s*([\d:]+)/i)}`,`Keluar RR ${tt(/Jam keluar ruangan pemulihan\s*:\s*([\d:]+)/i)}`,`TD ${tt(/Tanda Vital[^:]*Tekanan Darah\s*:\s*(\d+\s*\/\s*\d+)/i)} mmHg`,`Nadi ${tt(/Nadi\s*:\s*(\d+)(?=\s*x\/mnt)/i)} x/mnt`].join(" \xB7 "),ie=A(/INSTRUKSI PASCA ANESTESI/i),_t=o(ie).flat().map(b=>b.replace(/^[\d\s]+/,"").trim()).filter(b=>b&&!/INSTRUKSI PASCA ANESTESI/i.test(b)&&b.length>3),Me=_t.length?'<ol class="an-instruksi">'+_t.map(b=>`<li>${t(b)}</li>`).join("")+"</ol>":"<div>-</div>",H=(b,J)=>`<tr><td class="k">${b}</td><td class="c">:</td><td class="v">${J}</td></tr>`,mt=b=>`<tr><th class="rm-sec-head" style="text-align:left;">${b}</th></tr>`;return`<section class="rm-page" id="form-anestesi">
<div class="an-meta"><span>Halaman 1 dari 2</span></div>
${W("RM. 21")}
<div class="rm-form-title">LAPORAN ANESTESI</div>
<div class="an-subtitle">REKAM PELAKSANAAN ANESTESI</div>

<table class="rm-grid-table"><tbody><tr>
  <td style="width:52%;"><table class="an-kv">
    ${H("Nama Pasien",`<strong>${t(D)}</strong>`)}
    ${H("No. Rekam Medis",`<strong>${t(k)}</strong>`)}
    ${H("Tgl. Lahir / Umur",`${t(x)} (${t(f)} / ${t(U)})`)}
    ${H("Diagnosa Pra Bedah",t(I))}
    ${H("Diagnosa Pasca Bedah",`<strong>${t(T)}</strong>`)}
  </table></td>
  <td><table class="an-kv">
    ${H("Tanggal Tindakan",`<strong>${t(O)}</strong>`)}
    ${H("Jenis Pembedahan",t(S))}
    ${H("Jenis Operasi",t(R))}
    ${H("Ruangan",t(Y))}
    ${H("Dokter Anestesi",`<strong>${t(F)}</strong>`)}
  </table></td>
</tr></tbody></table>

<table class="rm-grid-table"><tbody>${mt("A. JENIS PERSIAPAN ANESTESI")}
<tr><td><div class="an-grid-4">${_}</div></td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${mt("B. PENGKAJIAN PRA BEDAH &amp; RENCANA ANESTESI")}
<tr><td><table class="an-kv">
  ${H("Waktu Mulai",t(g))}
  ${H("Tanda Vital Awal",t(ft))}
  ${H("Dokter Operator",t(Q))}
  ${H("Asisten Bedah",t(u(/^Asisten Bedah|^Asisten/i)))}
  ${H("Instrumen Bedah",t(u(/^Instrumen Bedah|^Perawat Instrumen/i)))}
  ${H("Rencana Anestesi",`${p("Anestesi Umum","before")} Umum &nbsp; ${p("Spinal","before")} Spinal &nbsp; ${p("Epidural","before")} Epidural &nbsp; ${p("Kaudal","before")} Kaudal`)}
</table>
<div class="an-risk"><strong>Riwayat Penyakit &amp; Faktor Risiko:</strong><div class="an-grid-3">${st}</div></div>
</td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${mt("C. INDUKSI &amp; MONITORING ANESTESI")}
<tr><td><table class="an-kv">
  ${H("Teknik / Lokasi Tusukan",t(u(/^Lokasi Tusukan/i)))}
  ${H("Waktu Suntikan / Analgesia / Operasi",t($t))}
  ${H("Anestesi Lokal",t(u(/^Anestesi lokal/i)))}
  ${H("ASA",`${p(" I ")} I &nbsp; ${p(" II ")} II &nbsp; ${p(" III ")} III &nbsp; ${p(" IV ")} IV &nbsp; ${p(" V ")} V &nbsp; ${p(" E ")} E`)}
</table></td></tr>
<tr><td>${It}</td></tr></tbody></table>

<!-- ================= HALAMAN 2 ================= -->
<div class="an-page-break"></div>
<div class="an-running">
  <span><strong>LAPORAN ANESTESI (LANJUTAN)</strong> \u2014 ${t(wt)}</span>
  <span>Pasien: <strong>${t(D)}</strong> \u2022 RM: <strong>${t(k)}</strong></span>
  <span><strong>Halaman 2 dari 2</strong></span>
</div>

<table class="rm-grid-table"><tbody>${mt("D. MEDIKASI, CAIRAN &amp; JALAN NAPAS")}
<tr><td><table class="an-kv">
  ${H("Medikasi",t(P))}
  ${H("Pemberian Cairan",t(m))}
  ${H("Total Asupan Cairan",y==="-"?"-":`${y} ml`)}
  ${H("Total Keluaran Cairan",`Perdarahan ${z} ml \u2022 Diuresis ${C} ml`)}
  ${H("Pengelolaan Napas",t(j))}
</table></td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${mt("E. PEMANTAUAN RUANG PULIH SADAR")}
<tr><td><table class="an-kv">
  ${H("Kronologi & Tanda Vital RR",t(Tt))}
</table></td></tr>
<tr><td>${pt}</td></tr></tbody></table>

<table class="rm-grid-table"><tbody><tr><th class="rm-sec-head" colspan="2" style="text-align:left;">F. PENILAIAN KELAYAKAN PINDAH RUANGAN</th></tr>
${Nt}</tbody></table>

<table class="rm-grid-table"><tbody>${mt("G. INSTRUKSI PASCA ANESTESI")}
<tr><td>${Me}</td></tr></tbody></table>

<footer class="an-tte">${d}</footer>
</section>`}function Ra(e){let L=et(e,/^Fisioterapi/i),a=lt(e,/^Fisioterapi/i),i=(...r)=>Mt(L,...r);return`<section class="rm-page" id="form-fisioterapi">
${W("FISIOTERAPI")}
<div class="rm-form-title">LEMBAR ASSESMEN &amp; TERAPI FISIOTERAPI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal",i(/^Tanggal/i))}
    ${n("Diagnosa",i(/^Diagnosa/i))}
    ${n("Ruang / Asal",i(/^Ruang|^Unit/i))}
    ${n("Terapis",i(/^Terapis|^Fisioterapis/i))}
  </table></div>
</div>
${jt([["KELUHAN UTAMA (SUBJEKTIF)",i(/^Keluhan|^Subjektif/i)],["PEMERIKSAAN OBJEKTIF (ROM / MMT / FUNGSI)",i(/^Objektif|^Pemeriksaan/i)],["ASSESMEN FISIOTERAPI",i(/^Assesmen|^Diagnosa Fisio/i)],["RENCANA TERAPI &amp; TUJUAN",i(/^Rencana|^Terapi|^Tujuan/i)]])}
<div class="sub-heading-rm">PELAKSANAAN TERAPI</div>
${ot(["TANGGAL","MODALITAS / LATIHAN","FREKUENSI","RESPON PASIEN"],a,!0)}
${ut(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(i(/^Tanggal/i)),"Terapis / Fisioterapis",`( ${t(i(/^Terapis|^Fisioterapis/i))} )`])}
</section>`}function Ya(e){let L=et(e,/^Pengkajian Hemodialisa/i),a=lt(e,/^Pengkajian Hemodialisa/i),i=(...r)=>Mt(L,...r);return`<section class="rm-page" id="form-hemodialisa">
${W("HEMODIALISA")}
<div class="rm-form-title">LEMBAR PENGKAJIAN &amp; SESI HEMODIALISA</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Sesi",i(/^Tanggal/i))}
    ${n("Akses Vaskular",i(/^Akses/i))}
    ${n("Diagnosa",i(/^Diagnosa/i))}
    ${n("Perawat / Dokter",i(/^Perawat|^Dokter/i))}
  </table></div>
</div>
${ot(["PARAMETER","SEBELUM DIALISA","SESUDAH DIALISA","KETERANGAN"],[["Berat Badan",i(/^BB Sebelum|^Berat Sebelum/),i(/^BB Sesudah|^Berat Sesudah/),"-"],["Tekanan Darah",i(/^TD Sebelum|^Tekanan Sebelum/),i(/^TD Sesudah|^Tekanan Sesudah/),"-"],["Nadi",i(/^Nadi Sebelum/),i(/^Nadi Sesudah/),"-"],...a],!0)}
${jt([["BLOOD FLOW / DIALYSATE FLOW",i(/^Blood Flow|^Dialysate/i)],["ULTRAFILTRASI &amp; Heparinisasi",i(/^Ultrafiltrasi|^UF|^Heparin/i)],["ADEKUASI (Kt/V)",i(/^Kt\/V|^Adekuasi/i)],["KOMPLIKASI / CATATAN",i(/^Komplikasi|^Catatan/i)]])}
${ut(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(i(/^Tanggal/i)),"Perawat Hemodialisa",`( ${t(i(/^Perawat/i))} )`])}
</section>`}function Qa(e){let L=e.find(I=>/^Operasi/i.test(I.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=et(e,/^Operasi/i),r=(...I)=>Mt(i,...I),u=I=>At(I).replace(/\bantispetik\b/gi,"antiseptik").replace(/\bincisi\b/gi,"insisi").replace(/\bfacia\b/gi,"fasia").replace(/\bdaryantul\b/gi,"daryantulle").replace(/\bPendarahan\b/g,"Perdarahan").replace(/\bTranfusi\b/g,"Transfusi").replace(/\bEFEKTIF\b/g,"Elektif").replace(/\s+/g," ").trim(),s=(...I)=>{let T=u(r(...I));return T&&T!=="-"?T:"-"},l=(I,T)=>{for(let S of I){let R=M(S);if(R!=="-")return u(R)}return s(T)},o=(()=>{if(!a)return[];let I=Array.from(a.querySelectorAll("td")).find(T=>/^\s*Uraian Pembedahan\b/i.test(T.textContent||""))?.parentElement?.nextElementSibling?.querySelector("td")?.textContent||"";return I.trim()||(I=Array.from(a.querySelectorAll("td")).map(T=>(T.textContent||"").trim()).sort((T,S)=>S.length-T.length)[0]||""),I.split(/\n+/).map(T=>u(T)).filter(Boolean)})(),A=a?Array.from(a.querySelectorAll("td")).map(I=>(I.textContent||"").replace(/\s+/g," ").trim()).filter(I=>/^-?\s*(MAYOR|MINOR|EFEKTIF|ELEKTIF|EMERGENSI|CITO|SEDANG|KHUSUS)$/i.test(I)).join(" "):"",p=I=>I.test(A)?"&#10003;":"&nbsp;",N=s(/^Komplikasi/i),D=N==="-"?'<span class="chk-box">&#10003;</span> Tidak ada komplikasi &nbsp;&nbsp; <span class="chk-box">&nbsp;</span> Ada, sebutkan: ..............................':'<span class="chk-box">&nbsp;</span> Tidak ada komplikasi &nbsp;&nbsp; <span class="chk-box">&#10003;</span> Ada: <strong>'+t(N)+"</strong>",k=s(/^Penggunaan Implan/i),x=/^Ya/i.test(k)?`<span class="chk-box">&nbsp;</span> Tidak &nbsp; <span class="chk-box">&#10003;</span> Ya \u2014 Jenis: ${t(s(/^Jenis Implan/i))} | No. Seri: ${t(s(/^Nomor Implan/i))}`:'<span class="chk-box">&#10003;</span> Tidak &nbsp; <span class="chk-box">&nbsp;</span> Ya',f=s(/^Tanggal Bedah/i),w=l(["dokter_operator","operator"],/^Dokter Operator|^Operator/i),$=V(e,/^Operasi/i)[0]??"",U=M("jenis_kelamin","jk")||s(/^Jenis Kelamin/i),F=/perempuan|^p$/i.test(U)?"Perempuan (P)":/laki|^l$/i.test(U)?"Laki-laki (L)":U,Q=f!=="-"?Ct(f):"-",E=(I,T,S="")=>`<tr><td class="k${S}">${I}</td><td class="c">:</td><td class="v">${T}</td></tr>`,Y=(I,T=2)=>`<tr><th class="rm-sec-head" colspan="${T}" style="text-align:left;">${I}</th></tr>`,O=o.length?'<ol class="op-steps">'+o.map(I=>`<li>${t(I)}</li>`).join("")+"</ol>":"<div>-</div>";return`<section class="rm-page" id="form-operasi">
${W("RM. 20")}
<div class="rm-form-title">LAPORAN PELAKSANAAN OPERASI</div>

<div class="id-box-borderless">
  <div class="id-col"><table class="op-kv">
    ${E("Nama Pasien",`<strong>${t(l(["nama"],/^Nama Pasien|^Nama$/i))}</strong>`)}
    ${E("Tanggal Lahir / Umur",`${t(l(["tgl_lahir","tglLahir"],/^Tanggal Lahir|^Tgl Lahir/i))} (${t(M("umur")||s(/^Umur/i))})`)}
  </table></div>
  <div class="id-col"><table class="op-kv">
    ${E("No. Rekam Medis",`<strong>${t(l(["norm","rekam_medis"],/^No\.? RM/i))}</strong>`)}
    ${E("Jenis Kelamin",t(F))}
  </table></div>
</div>

<table class="rm-grid-table"><tbody>
  ${Y("I. TIM OPERASI &amp; WAKTU PEMBEDAHAN")}
  <tr>
    <td style="width:54%;">
      <table class="op-kv">
        ${E("Dokter Operator",`<strong>${t(w)}</strong>`)}
        ${E("Asisten / Dr. Anestesi",t(s(/^Asisten/i)))}
        ${E("Perawat Instrumen",t(s(/^Perawat Instrumen/i)))}
      </table>
    </td>
    <td>
      <table class="op-kv">
        ${E("Tanggal Bedah",`<strong>${t(f)}</strong>`)}
        ${E("Jam Mulai \u2013 Selesai",`${t(s(/^Jam Mulai/i))} \u2013 ${t(s(/^Jam Selesai/i))}`)}
        ${E("Lama Waktu Bedah",`<strong>${t(s(/^Waktu Bedah/i))}</strong>`)}
      </table>
    </td>
  </tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  ${Y("II. DIAGNOSIS, KLASIFIKASI &amp; TINDAKAN / ICD-9-CM")}
  <tr>
    <td style="width:54%;">
      <table class="op-kv">
        ${E("Diagnosis Pra Bedah",t(s(/^Diagnosis Pra Bedah|^Diagnosa Pra/i)))}
        ${E("Diagnosis Pasca Bedah",`<strong>${t(s(/^Diagnosis Pasca Bedah|^Diagnosa Pasca/i))}</strong>`)}
        ${E("Nama / Macam Operasi",`<strong>${t(s(/^Nama Macam Operasi|^Tindakan|^Prosedur/i))}</strong>`)}
      </table>
    </td>
    <td>
      <table class="op-kv">
        <tr><td class="k">Kategori Operasi</td><td class="c">:</td><td class="v"><span class="chk-box">${p(/MAYOR/i)}</span> Mayor &nbsp; <span class="chk-box">${p(/SEDANG|MINOR/i)}</span> Sedang &nbsp; <span class="chk-box">${p(/KHUSUS/i)}</span> Khusus</td></tr>
        <tr><td class="k">Sifat Operasi</td><td class="c">:</td><td class="v"><span class="chk-box">${p(/ELEKTIF|EFEKTIF/i)}</span> Elektif &nbsp; <span class="chk-box">${p(/CITO|EMERGENSI/i)}</span> Cito / Emergensi</td></tr>
        ${E("Jaringan Dieksisi",t(s(/^Jaringan yang Dieksisi|^Jaringan Dieksisi/i)))}
        <tr><td class="k">Penggunaan Implan</td><td class="c">:</td><td class="v">${x}</td></tr>
      </table>
    </td>
  </tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  ${Y("III. URAIAN PEMBEDAHAN")}
  <tr><td class="op-narrative">
    <div><strong>Langkah-Langkah Tindakan:</strong></div>
    ${O}
  </td></tr>
  <tr><td><strong>IV. Komplikasi Intraoperatif:</strong> &nbsp; ${D}</td></tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  <tr>
    <th class="rm-sec-head" style="width:50%;text-align:left;">V. PEMERIKSAAN PATOLOGI ANATOMI (PA)</th>
    <th class="rm-sec-head" style="text-align:left;">VI. PERDARAHAN, TRANSFUSI &amp; DRAINASE</th>
  </tr>
  <tr>
    <td><table class="op-kv">
      ${E("Jaringan ke PA",`<strong>${t(s(/^Jaringan ke Patologi/i))}</strong>`)}
      ${E("Dikirim Untuk",t(s(/^Dikirim Untuk/i)))}
      ${E("Jenis Jaringan",t(s(/^Jenis Jaringan/i)))}
      ${E("Tanggal Pengiriman",t(s(/^Tanggal Jaringan/i)))}
    </table></td>
    <td><table class="op-kv">
      ${E("Perkiraan Perdarahan",`<strong>${t(s(/^Perkiraan Pendarahan|^Perkiraan Perdarahan/i))}</strong>`)}
      ${E("Transfusi Darah",t(s(/^Tranfusi Darah|^Transfusi Darah/i)))}
      ${E("Pemakaian Drain",t(s(/^Pemakaian Drain/i)))}
    </table></td>
  </tr>
</tbody></table>

<div class="rm-signature-block" style="justify-content:flex-end;">
  <div class="rm-sig-box">
    <div>Jambi, ${t(Q)}</div>
    <div>Dokter Operator,</div>
    ${$?`<img class="rm-sig-qr" src="${t($)}" alt="QR TTE dokter operator" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(w)} )</div>
  </div>
</div>
</section>`}function Ka(e){let L=e.find(r=>/^Laboratorium/i.test(r.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,i=a?Array.from(a.querySelectorAll("img")).map(r=>r.outerHTML).filter(r=>!/logo/i.test(r)):[];return`<section class="rm-page" id="rm-09">
${W("RM. 09")}
<div class="rm-form-title">HASIL PEMERIKSAAN LABORATORIUM PATOLOGI KLINIK</div>
<div class="passthrough-separator"><span>LAMPIRAN HASIL LABORATORIUM (LIS)</span><span>FILE UPLOAD</span></div>
<div class="raw-upload-frame">
  ${i.length?i.join("<br/>"):"-"}
</div>
</section>`}function Ba(e){let L=et(e,/^Surat Kematian/i),a=(...i)=>Mt(L,...i);return`<section class="rm-page" id="form-kematian">
${W("KEMATIAN")}
<div class="rm-form-title">SURAT KETERANGAN KEMATIAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Tgl. Lahir / Umur",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
    ${n("Alamat",nt(e))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Kematian",a(/^Tanggal Kematian|^Tanggal/i))}
    ${n("Jam Kematian",a(/^Jam/i))}
    ${n("Tempat Kematian",a(/^Tempat/i))}
    ${n("Ruang / Kelas",[M("jenis"),M("kelas","ruang")].filter(i=>i!=="-").join(" / ")||"-")}
  </table></div>
</div>
${jt([["PENYEBAB KEMATIAN LANGSUNG (I)",a(/^Penyebab Langsung|^Penyebab I/i)],["PENYEBAB ANTARA (II)",a(/^Penyebab Antara|^Penyebab II/i)],["PENYAKIT / KONDISI LAIN",a(/^Penyakit Lain|^Kondisi Lain/i)],["KETERANGAN",a(/^Keterangan|^Catatan/i)]])}
${ut(["Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(a(/^Tanggal Kematian|^Tanggal/i)),"Dokter yang Menyatakan Meninggal",`( ${t(M("dokter","dpjp"))} )`])}
</section>`}function Fa(e){let L=et(e,/^Permintaan Terapi/i),a=lt(e,/^Permintaan Terapi/i),i=(...r)=>Mt(L,...r);return`<section class="rm-page" id="form-terapi">
${W("TERAPI")}
<div class="rm-form-title">PERMINTAAN TERAPI REHABILITASI MEDIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Permintaan",i(/^Tanggal/i))}
    ${n("Ruangan / Unit Asal",i(/^Ruang|^Unit/i))}
    ${n("Dokter Pengirim",i(/^Dokter Pengirim/i))}
    ${n("Diagnosa",i(/^Diagnosa/i))}
  </table></div>
</div>
${jt([["JENIS TERAPI YANG DIMINTA",i(/^Jenis Terapi|^Terapi/i)],["TUJUAN TERAPI",i(/^Tujuan/i)],["FREKUENSI / RENCANA",i(/^Frekuensi|^Rencana/i)],["CATATAN KLINIS",i(/^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN PERMINTAAN</div>
${ot(["NO","TERAPI / MODALITAS","FREKUENSI","KETERANGAN"],a,!0)}
${ut(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(i(/^Tanggal/i)),"Dokter Pengirim",`( ${t(i(/^Dokter Pengirim/i))} )`])}
</section>`}function Ga(e){let L=et(e,/^Uji Fungsi/i),a=lt(e,/^Uji Fungsi/i),i=(...r)=>Mt(L,...r);return`<section class="rm-page" id="form-uji-fungsi">
${W("UJI FUNGSI")}
<div class="rm-form-title">LEMBAR UJI FUNGSI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Pemeriksaan",i(/^Tanggal/i))}
    ${n("Diagnosa",i(/^Diagnosa/i))}
    ${n("Petugas Uji",i(/^Petugas|^Terapis/i))}
    ${n("Alat / Metode",i(/^Alat|^Metode/i))}
  </table></div>
</div>
${ot(["PARAMETER FUNGSI","NILAI / SKOR","SATUAN","KETERANGAN"],a,!0)}
${jt([["HASIL / INTERPRETASI",i(/^Hasil|^Interpretasi/i)],["KESIMPULAN",i(/^Kesimpulan/i)],["REKOMENDASI TERAPI",i(/^Rekomendasi|^Saran/i)]])}
${ut(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(i(/^Tanggal/i)),"Petugas Uji Fungsi",`( ${t(i(/^Petugas|^Terapis/i))} )`])}
</section>`}function Ja(e){let L=et(e,/^Partograf/i),a=lt(e,/^Partograf/i),i=(...r)=>Mt(L,...r);return`<section class="rm-page" id="form-partograf">
${W("PARTOGRAF")}
<div class="rm-form-title">PARTOGRAF \u2014 PEMANTAUAN KEMAJUAN PERSALINAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Umur",i(/^Umur/i))}
    ${n("Grafida / Paritas",i(/^Grafida|^Paritas|^G/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("HPHT",i(/^HPHT/i))}
    ${n("Taksiran Persalinan",i(/^Taksiran|^TP/i))}
    ${n("Tanggal Persalinan",i(/^Tanggal/i))}
    ${n("Petugas",i(/^Petugas|^Bidan/i))}
  </table></div>
</div>
<div class="sub-heading-rm">KEMAJUAN PERSALINAN &amp; OBSERVASI</div>
${ot(["JAM","PEMBUKAAN","TURUN","KONTRAKSI","DJJ","TD / NADI","SUHU","URINE","CATATAN"],a,!0)}
${jt([["KEADAAN IBU &amp; JANIN",i(/^Keadaan|^Kondisi/i)],["TINDAKAN / PENYIMPANGAN",i(/^Tindakan|^Penyimpangan/i)],["CATATAN",i(/^Catatan/i)]])}
${ut(["Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(i(/^Tanggal/i)),"Bidan / Petugas Persalinan",`( ${t(i(/^Petugas|^Bidan/i))} )`])}
</section>`}function Ha(e){let L=et(e,/^Laporan Tindakan/i),a=lt(e,/^Laporan Tindakan/i),i=(...r)=>Mt(L,...r);return`<section class="rm-page" id="form-laporan-tindakan">
${W("LAPORAN TINDAKAN")}
<div class="rm-form-title">LAPORAN PELAKSANAAN TINDAKAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Tindakan",i(/^Tanggal/i))}
    ${n("Jenis Tindakan",i(/^Jenis Tindakan|^Tindakan/i))}
    ${n("Ruang / Unit",i(/^Ruang|^Unit/i))}
    ${n("Pelaksana",i(/^Pelaksana|^Petugas|^Dokter/i))}
  </table></div>
</div>
${jt([["INDIKASI / DIAGNOSA",i(/^Indikasi|^Diagnosa/i)],["URAIAN TINDAKAN",i(/^Uraian|^Prosedur/i)],["HASIL TINDAKAN",i(/^Hasil/i)],["KOMPLIKASI / CATATAN",i(/^Komplikasi|^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN TINDAKAN</div>
${ot(["NO","TINDAKAN","WAKTU / JAM","PELAKSANA"],a,!0)}
${ut(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(i(/^Tanggal/i)),"Pelaksana Tindakan",`( ${t(i(/^Pelaksana|^Petugas|^Dokter/i))} )`])}
</section>`}var Ft=e=>e?Array.from(e.rows).map(L=>Array.from(L.cells).map(ct)):[],Gt=e=>[e.match(/(\d{1,2}\/\d{1,2}\/\d{4})/)?.[1]??"-",e.match(/Pukul\s*([\d:]+)/i)?.[1]??"-"],Jt=e=>e.match(/dr\.[^\n]+/i)?.[0]?.trim()??"-";function Wa(e){let L=Array.from(e.querySelectorAll("table")),a=L[0]??null,i=L.find(w=>/Jawaban Konsultasi/i.test(w.textContent||""))??null,r=Ft(a),u=Ft(i),s=r[0]??[],l=r[1]?.[0]||"",o=r.findIndex(w=>/^Penemuan Klinis/i.test(w[0]||"")),[A,p]=Gt(s[1]||""),[N,D]=Gt(u[1]?.[1]||""),k={};for(let w of u.slice(2))for(let $ of w){let U=$.match(/^(Subjektif|Objektif|Assesmen|Planning|Instruksi)\s*:\s*([\s\S]*)$/i);U&&(k[U[1].toLowerCase()]=U[2].trim()||"-")}let x=(s[0]||"").replace(/^\s*Konsul Ke\s*:\s*/i,"").replace(/\s+/g," ").trim(),f=Jt(u[u.length-1]?.[1]||"");return{konsulen:f!=="-"?f:x||"-",pengirim:Jt(r[r.length-1]?.[1]||""),tanggal:A,jam:p,jenis:l.match(/Mohon\s+Konsultasi\s+([^\s:]+)/i)?.[1]??"-",permintaan:l||"-",penemuan:(o>=0?r[o+1]?.[0]:"")||"-",dugaan:r.flat().find(w=>/^Dugaan\s*:/i.test(w))?.replace(/^Dugaan\s*:\s*/i,"").trim()||"-",subjektif:k.subjektif||"-",objektif:k.objektif||"-",asesmen:k.asesmen||"-",planning:k.planning||"-",instruksi:k.instruksi||"-",keputusan:u.flat().find(w=>/Konsultasi selesai tanggal/i.test(w))||"-",tglJawaban:N,jamJawaban:D,tglLahir:"-"}}function _a(e,L,a="rm-10"){let i=L??e.find(l=>/Konsul/i.test(l.title));if(!i)return"";let r=new DOMParser().parseFromString(i.html,"text/html"),u=Array.from(r.querySelectorAll("b")).filter(l=>/^\s*Konsul Ke\s*:/i.test(l.textContent||"")).map(l=>l.closest("table")?.parentElement).filter(l=>!!l),s=Array.from(r.querySelectorAll("tr")).map(l=>Array.from(l.cells).map(ct)).flatMap(l=>l.slice(0,-1).map((o,A)=>[o,l[A+1]])).find(([l])=>/^Tanggal Lahir$/i.test(l))?.[1]?.match(/\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{4}/)?.[0]??"-";return u.map((l,o)=>{let A=Wa(l);return A.tglLahir=s,qa(A,o?`${a}-${o+1}`:a)}).join("")}function qa(e,L){let a=e.konsulen!=="-"?e.konsulen:M("dokter_konsulen")!=="-"?M("dokter_konsulen"):"-",i=D=>At(D).replace(/\bPenilain\b/gi,"Penilaian").replace(/\bdijadwalkn\b/gi,"dijadwalkan").replace(/\bbtk\b/gi,"terima kasih").replace(/Terimakasih/gi,"Terima kasih").replace(/\s+/g," ").trim(),r=Array.from(i(e.permintaan).matchAll(/(?:^|\s)[1-3]\.\s*([^]*?)(?=\s[1-3]\.\s|$)/g)).map(D=>D[1].trim()).filter(Boolean),u=r.length?r.map(D=>`<div><span class="chk-box">&nbsp;</span> ${t(D)}</div>`).join(""):"-",s=/^0?0:00:00$/.test(e.jamJawaban)?"":e.jamJawaban,l=`${e.tglJawaban} ${s}`.trim(),o=e.dugaan!=="-"?e.dugaan:e.penemuan,A=[["S (SUBJEKTIF)",e.subjektif],["O (OBJEKTIF)",e.objektif],["A (ASSESMEN)",e.asesmen],["P (PLANNING)",e.planning],["INSTRUKSI",e.instruksi],["KEPUTUSAN KONSULTASI",e.keputusan]],p=D=>`<tr><th class="rm-sec-head" colspan="2" style="text-align:left;">${D}</th></tr>`,N=D=>`<table class="rm-grid-table"><tbody>${D}</tbody></table>`;return`<section class="rm-page" id="${t(L)}">
${W("RM. 10")}
<div class="rm-form-title">LEMBAR KONSULTASI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("Tanggal Lahir",e.tglLahir)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Jenis Kunjungan",[M("jenis"),M("kelas","ruang")].filter(D=>D!=="-").join(" / ")||"-")}
    ${n("Tanggal Permintaan",`${e.tanggal} ${e.jam}`.trim())}
    ${n("Tanggal Jawaban",l)}
  </table></div>
</div>
${N(p("BAGIAN I \u2014 PERMINTAAN KONSULTASI (DOKTER PEMOHON)")+`<tr><td style="width:175px;"><strong>Kepada Yth. Konsulen</strong></td><td>${t(a)}</td></tr><tr><td><strong>Jenis Permohonan</strong></td><td>${t(e.jenis)}</td></tr><tr><td><strong>Tujuan Konsultasi</strong></td><td>${u}</td></tr><tr><td><strong>Penemuan Klinis Terpenting</strong></td><td>${K(i(e.penemuan))}</td></tr><tr><td><strong>Dugaan Diagnosa</strong></td><td><strong>${t(i(o))}</strong></td></tr>`)}
${N(p("BAGIAN II \u2014 JAWABAN KONSULTASI (DOKTER KONSULEN)")+A.map(([D,k])=>`<tr><td style="width:175px;"><strong>${D}</strong></td><td>${K(i(k))}</td></tr>`).join(""))}
</section>`}function Xa(e){let L=et(e,/^Bon Makan/i),a=(...i)=>Mt(L,...i);return`<section class="rm-page" id="form-bon-makan">
${W("BON MAKAN")}
<div class="rm-form-title">BON MAKAN PASIEN / PENDAMPING</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Ruang / Kelas",[M("jenis"),M("kelas","ruang")].filter(i=>i!=="-").join(" / ")||"-")}
    ${n("Tanggal",a(/^Tanggal/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Nama Pendamping",a(/^Pendamping|^Keluarga/i))}
    ${n("Jumlah Porsi",a(/^Jumlah|^Porsi/i))}
    ${n("Waktu",a(/^Waktu|^Jam/i))}
    ${n("Petugas",a(/^Petugas/i))}
  </table></div>
</div>
${ot(["NO","NAMA","HUBUNGAN","JUMLAH","KETERANGAN"],lt(e,/^Bon Makan/i),!0)}
<div class="footnote-rm">Bon ini berlaku sesuai jadwal makan yang ditetapkan ruangan / instalasi gizi.</div>
${ut(["Pasien / Pendamping",`( ${t(a(/^Pendamping|^Keluarga/i))} )`],["Kota Jambi, "+t(a(/^Tanggal/i)),"Petugas Ruangan",`( ${t(a(/^Petugas/i))} )`])}
</section>`}function Va(e){let L=et(e,/^PEMERIKSAAN$/i),a=lt(e,/^PEMERIKSAAN$/i),i=(...r)=>Mt(L,...r);return`<section class="rm-page" id="form-pemeriksaan">
${W("PEMERIKSAAN")}
<div class="rm-form-title">HASIL PEMERIKSAAN / DIAGNOSTIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${n("Nama Pasien",M("nama"),!0)}
    ${n("No. Rekam Medis",M("norm","rekam_medis"))}
    ${n("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${n("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${n("Tanggal Pemeriksaan",i(/^Tanggal/i))}
    ${n("Jenis Pemeriksaan",i(/^Jenis Pemeriksaan|^Pemeriksaan/i))}
    ${n("Spesimen / Bahan",i(/^Spesimen|^Bahan/i))}
    ${n("Dokter Pengirim",i(/^Dokter Pengirim/i))}
  </table></div>
</div>
${ot(["PARAMETER","HASIL","SATUAN","NILAI RUJUKAN"],a,!0)}
${jt([["MAKROSKOPIK / TEMUAN",i(/^Makroskopik|^Temuan/i)],["MIKROSKOPIK",i(/^Mikroskopik/i)],["KESIMPULAN / DIAGNOSA",i(/^Kesimpulan|^Diagnosa/i)],["CATATAN",i(/^Catatan/i)]])}
${ut(["Petugas / Analis",`( ${t(i(/^Petugas|^Analis/i))} )`],["Kota Jambi, "+t(i(/^Tanggal/i)),"Dokter Penanggung Jawab",`( ${t(i(/^Dokter Penanggung Jawab|^Dokter/i))} )`])}
</section>`}function Za(e,L){let a=ga(e,L),i=M("no_sep","sep"),r=M("kartu","no_kartu","noka"),u=M("norm","rekam_medis"),s=M("nama"),l=[M("jenis"),M("kelas","ruang")].filter(S=>S!=="-").join(" / ")||"-",o=M("dokter","dpjp"),A=M("tanggalAwal","tgl_masuk","tgl"),p=M("tanggalAkhir","keluar","tgl_keluar"),N=M("tgl_lahir","tglLahir"),D=M("jenis_kelamin","jk"),k=nt(e),x=e.filter(S=>/resep/i.test(S.title)).length,f=Kt,w=new Date,$=`${w.getDate()} ${f[w.getMonth()]} ${w.getFullYear()}`,U=`<table class="rm-grid-table">
  <thead>
    <tr><th colspan="3">CATATAN KETIDAKSESUAIAN DATA LINTAS DOKUMEN (HASIL UJI SILANG OTOMATIS)</th></tr>
    <tr><th style="width: 32px;">NO</th><th style="width: 170px;">JENIS KETIDAKSESUAIAN</th><th>URAIAN TEMUAN VERIFIKASI</th></tr>
  </thead>
  <tbody>${a.map((S,R)=>`<tr><td class="center">${R+1}</td><td><strong>${t(S.title)}</strong></td><td>${t(S.detail)}</td></tr>`).join("")}</tbody>
</table>`,F=`<section class="rm-page" id="rm-00">
${W("RM. 00")}
<div class="rm-form-title">LEMBAR KENDALI KELENGKAPAN &amp; VERIFIKASI BERKAS KLAIM JKN</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NAMA PASIEN</td><td class="col">:</td><td class="val"><strong>${t(s)}</strong></td></tr>
    <tr><td class="lbl">NO. REKAM MEDIS</td><td class="col">:</td><td class="val"><strong>${t(u)}</strong></td></tr>
    <tr><td class="lbl">TGL. LAHIR / UMUR</td><td class="col">:</td><td class="val">${t(N)}</td></tr>
    <tr><td class="lbl">JENIS KELAMIN</td><td class="col">:</td><td class="val">${t(D)}</td></tr>
    <tr><td class="lbl">ALAMAT</td><td class="col">:</td><td class="val">${t(k)}</td></tr>
  </table></div>
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NO. KARTU BPJS</td><td class="col">:</td><td class="val"><strong>${t(r)}</strong></td></tr>
    <tr><td class="lbl">NO. SEP</td><td class="col">:</td><td class="val"><strong>${t(i)}</strong></td></tr>
    <tr><td class="lbl">TGL. MASUK / KELUAR</td><td class="col">:</td><td class="val">${t([A,p].filter(S=>S&&S!=="-").join(" s/d ")||"-")}</td></tr>
    <tr><td class="lbl">RUANG / KELAS</td><td class="col">:</td><td class="val">${t(l)}</td></tr>
    <tr><td class="lbl">DPJP UTAMA</td><td class="col">:</td><td class="val">${t(o)}</td></tr>
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 110px;">KODE INA-CBG</th>
      <th>DESKRIPSI GROUPING INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF RIIL RS</th>
      <th class="num" style="width: 115px;">SELISIH</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="center"><strong>${t(St("ina_cbg_code")||"-")}</strong></td>
      <td>${t(St("ina_cbg_desc")||"-")}</td>
      <td class="num"><strong>${t(St("tarif_ina_cbg")||"-")}</strong></td>
      <td class="num">${t(St("tarif_riil_rs")||"-")}</td>
      <td class="num">${t(St("selisih")||"-")}</td>
    </tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 32px;">NO</th>
      <th style="width: 58px;">KODE RM</th>
      <th>JENIS BERKAS / DOKUMEN KLAIM</th>
      <th style="width: 120px;">STATUS BERKAS</th>
      <th style="width: 68px;">TANDA (&#10003;)</th>
    </tr>
  </thead>
  <tbody>
    <tr><td class="center">1</td><td class="center">RM. 01</td><td>Surat Elegibilitas Peserta (SEP) \u2014 No. ${t(i)}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 01 SEP"></td></tr>
    <tr><td class="center">2</td><td class="center">RM. 01</td><td>Berkas Klaim Individual Pasien (INA-CBG E-Klaim 5.10.9)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi INA-CBG"></td></tr>
    <tr><td class="center">3</td><td class="center">RM. 02</td><td>Surat Bukti Pelayanan Kesehatan (SBPK) \u2014 ${t(l)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 02 SBPK"></td></tr>
    <tr><td class="center">4</td><td class="center">RM. 03</td><td>Surat Pengantar Rawat Inap (SPRI) \u2014 Tgl. ${t(A||"-")}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 03 SPRI"></td></tr>
    <tr><td class="center">5</td><td class="center">Seksi 04</td><td>File Upload Dokumen Pasien (Laporan Echo/Doppler &amp; Rekaman EKG)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Seksi 04 Upload"></td></tr>
    <tr><td class="center">6</td><td class="center">RM. 05</td><td>Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi (${x} Nota Resep)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 05 Billing"></td></tr>
    <tr><td class="center">7</td><td class="center">RM. 06</td><td>Ringkasan Pulang (Discharge Summary) \u2014 DPJP ${t(o)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 06 Resume"></td></tr>
    <tr><td class="center">8</td><td class="center">RM. 07</td><td>Formulir Telaah Resep, Telaah Obat &amp; Edukasi Farmasi (No. 230445)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 07 Telaah"></td></tr>
    <tr><td class="center">9</td><td class="center">RM. 08</td><td>Hasil Pemeriksaan Radiologi \u2014 Thorax AP/PA (No. Rontgen 5918)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 08 Radiologi"></td></tr>
    <tr><td class="center">10</td><td class="center">RM. 09</td><td>Hasil Pemeriksaan Laboratorium Patologi Klinik (Hematologi &amp; Urine)</td><td class="center"><strong>TIDAK LENGKAP *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 09 Lab"></td></tr>
    <tr><td class="center">11</td><td class="center">RM. 10</td><td>Lembar Konsultasi Antar-Spesialis (dr. M. Ryan Ramadhan, Sp.JP., FIHA)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 10 Konsul"></td></tr>
  </tbody>
</table>

${U}

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Kota Jambi, ${$}</div>
    <div>Petugas Casemix / Klaim JKN RS</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">RSUD H. Abdul Manap Kota Jambi</div>
  </div>
  <div class="rm-sig-box">
    <div>Diterima &amp; Diverifikasi Oleh,</div>
    <div>Verifikator BPJS Kesehatan</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">NPP. ............................................</div>
  </div>
</div>
</section>`,Q=e,E=new Map,Y=Q.map((S,R)=>{let g=wa(S.title,R),c=(E.get(g.id)??0)+1;return E.set(g.id,c),c===1?g:{...g,id:`${g.id}-${c}`,tab:`${g.tab} (${c})`,option:`${g.option} (${c})`}}),O=Q.map((S,R)=>{let g=Y[R];return/^SEP$/i.test(S.title)?pa(e):/^Surat (?:Rencana )?Kontrol/i.test(S.title)?xa(e):/^SPRI$/i.test(S.title)?ya(e):/^SBPK$/i.test(S.title)?Da(e):/^Rincian Biaya/i.test(S.title)?Ea(e):/^Resume/i.test(S.title)?Ia(e):/^Telaah/i.test(S.title)?Ta(e):/^Radiologi/i.test(S.title)?Ca(e,S,g.id):/^Triage/i.test(S.title)?fa(e):/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(S.title)?$a(e):/^Laboratorium/i.test(S.title)?Ka(e):/Konsul/i.test(S.title)?_a(e,S,g.id):/^Persetujuan Tindakan/i.test(S.title)?Ua(e):/^Anestesi/i.test(S.title)?Bt(e):/^Fisioterapi/i.test(S.title)?Ra(e):/^Pengkajian Hemodialisa/i.test(S.title)?Ya(e):/^Operasi/i.test(S.title)?Qa(e):/^Surat Kematian/i.test(S.title)?Ba(e):/^Permintaan Terapi/i.test(S.title)?Fa(e):/^Uji Fungsi/i.test(S.title)?Ga(e):/^Partograf/i.test(S.title)?Ja(e):/^Laporan Tindakan/i.test(S.title)?Ha(e):/^Bon Makan/i.test(S.title)?Xa(e):/^PEMERIKSAAN$/i.test(S.title)?Va(e):`<section class="rm-page" id="${g.id}">
${W(g.code)}
<div class="rm-form-title">${t(S.title)}</div>
<div class="doc-body">${S.html}</div>
</section>`}).join(""),I=['<button type="button" class="tab-btn active" data-target="all">Semua</button>','<button type="button" class="tab-btn" data-target="rm-00">RM. 00 Kendali</button>',...Q.map((S,R)=>{let g=Y[R];return`<button type="button" class="tab-btn" data-target="${g.id}">${g.tab}</button>`})].join(""),T=['<option value="all">Semua Formulir RM</option>','<option value="rm-00">RM. 00 \u2014 Lembar Kendali &amp; Verifikasi</option>',...Q.map((S,R)=>{let g=Y[R];return`<option value="${g.id}">${g.option}</option>`})].join("");return`<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<base href="${t(location.origin)}">
<title>Formulir Rekam Medis Baku \u2014 Dossier Klaim BPJS ${t(wt)}</title>
<style>
    /* ==========================================================================
       1. RESET & AUTHENTIC INDONESIAN HOSPITAL RM FORM TOKENS
       Pure Monochrome Black Ink (#000000) on White Paper (#FFFFFF).
       Zero SaaS colors, zero rounded pills/badges, zero drop shadows.
       ========================================================================== */
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      line-height: 1.35;
      color: #000000;
      background-color: #E5E5E5;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    /* ==========================================================================
       2. SCREEN-ONLY VERIFIER TOOLBAR (.no-print)
       ========================================================================== */
    .verifier-toolbar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background-color: #FFFFFF;
      border-bottom: 2px solid #000000;
      padding: 8px 16px;
      font-family: Arial, Helvetica, sans-serif;
    }

    .toolbar-row {
      max-width: 210mm;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }

    .toolbar-group {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
    }

    .toolbar-label {
      font-size: 9pt;
      font-weight: bold;
      text-transform: uppercase;
    }

    .toolbar-select {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 8px;
      cursor: pointer;
    }

    .toolbar-counter {
      font-size: 8.5pt;
      border: 1px solid #000000;
      padding: 3px 8px;
      background-color: #FFFFFF;
    }

    .toolbar-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 10px;
      cursor: pointer;
    }

    .toolbar-btn:hover {
      background-color: #F0F0F0;
    }

    .toolbar-btn-print {
      background-color: #000000;
      color: #FFFFFF;
    }

    .toolbar-btn-print:hover {
      background-color: #222222;
    }

    .toolbar-tabs {
      max-width: 210mm;
      margin: 6px auto 0 auto;
      padding-top: 6px;
      border-top: 1px solid #000000;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .tab-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 7.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 2px 6px;
      cursor: pointer;
    }

    .tab-btn.active {
      background-color: #000000;
      color: #FFFFFF;
      font-weight: bold;
    }

    /* ==========================================================================
       3. A4 PAPER SHEET CONTAINER (NO DROP SHADOWS)
       ========================================================================== */
    .dossier-wrapper {
      max-width: 210mm;
      margin: 16px auto 40px auto;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .rm-page {
      width: 100%;
      background-color: #FFFFFF;
      border: 1px solid #888888;
      padding: 12mm 14mm;
    }

    .rm-page.hidden-section {
      display: none;
    }

    /* ==========================================================================
       4. OFFICIAL RSUD H. ABDUL MANAP KOP SURAT (TIMES NEW ROMAN + DOUBLE RULE)
       ========================================================================== */
    .rm-code-top {
      text-align: right;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 9pt;
      font-weight: bold;
      margin-bottom: 2px;
      letter-spacing: 0.02em;
    }

    .kop-surat {
      display: flex;
      align-items: center;
      gap: 12px;
      padding-bottom: 5px;
    }

    .kop-logo {
      width: 52px;
      height: 60px;
      flex-shrink: 0;
    }

    .kop-text {
      flex: 1;
      text-align: center;
      font-family: "Times New Roman", Times, serif;
      color: #000000;
      line-height: 1.2;
    }

    .kop-line-1 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-2 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-3 {
      font-size: 12.5pt;
      font-weight: bold;
      letter-spacing: 0.02em;
      margin-top: 1px;
    }

    .kop-line-4 {
      font-size: 7.5pt;
      font-weight: normal;
      margin-top: 2px;
    }

    .kop-line-5 {
      font-size: 7.5pt;
      font-weight: normal;
    }

    .kop-double-rule {
      border-top: 2px solid #000000;
      height: 2px;
      border-bottom: 0.75px solid #000000;
      margin-bottom: 10px;
    }

    .rm-form-title {
      text-align: center;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 11pt;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 8px;
      letter-spacing: 0.02em;
    }

    /* ==========================================================================
       5. PATIENT IDENTITY BLOCKS (PATTERN A: BORDERED BOX / PATTERN B: BORDERLESS)
       Strict vertical colon ':' alignment (label | 10px ':' | value)
       ========================================================================== */
    .id-box-bordered {
      border: 1px solid #000000;
      padding: 6px 10px;
      margin-bottom: 9px;
      display: flex;
      gap: 16px;
    }

    .id-box-borderless {
      padding: 2px 0;
      margin-bottom: 8px;
      display: flex;
      gap: 16px;
    }

    .id-col {
      flex: 1;
      min-width: 0;
    }

    .id-table {
      width: 100%;
      border-collapse: collapse;
    }

    .id-table td {
      padding: 1.5px 0;
      vertical-align: top;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
      line-height: 1.3;
    }

    .id-table td.lbl {
      width: 118px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.lbl-wide {
      width: 138px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.col {
      width: 10px;
      text-align: center;
    }

    .id-table td.val {
      text-align: left;
    }

    /* ==========================================================================
       6. FULL-GRID RM TABLES (border: 1px solid #000 ON ALL TH & TD)
       ========================================================================== */
    .rm-grid-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 8px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-grid-table th,
    .rm-grid-table td {
      border: 1px solid #000000;
      padding: 4px 6px;
      vertical-align: top;
      color: #000000;
    }

    .rm-grid-table th {
      font-size: 8.5pt;
      font-weight: bold;
      text-align: center;
      vertical-align: middle;
      background-color: #FFFFFF;
    }

    .rm-grid-table td.center,
    .rm-grid-table th.center {
      text-align: center;
      vertical-align: middle;
    }

    .rm-grid-table td.num,
    .rm-grid-table th.num {
      text-align: right;
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
    }

    .rm-grid-table td.nowrap {
      white-space: nowrap;
    }

    .rm-grid-table tr.section-banner td {
      font-weight: bold;
      font-size: 8.5pt;
      text-transform: uppercase;
      padding: 4px 6px;
    }

    .rm-grid-table tr.sub-group td {
      font-weight: bold;
      text-decoration: underline;
      padding-top: 5px;
      padding-bottom: 4px;
    }

    .rm-grid-table tr.total-row td {
      font-weight: bold;
      padding: 5px 6px;
    }

    /* Square 11px x 11px Interactive Verification Checkbox */
    .rm-checkbox {
      appearance: none;
      -webkit-appearance: none;
      width: 11px;
      height: 11px;
      border: 1px solid #000000;
      border-radius: 0;
      background-color: #FFFFFF;
      display: inline-grid;
      place-content: center;
      vertical-align: middle;
      cursor: pointer;
    }

    .rm-checkbox::before {
      content: "\u2713";
      font-size: 9px;
      font-weight: bold;
      line-height: 1;
      color: #000000;
      transform: scale(0);
    }

    .rm-checkbox:checked::before {
      transform: scale(1);
    }

    /* Static printed checkbox symbol for clinical forms */
    .static-box {
      display: inline-block;
      width: 10px;
      height: 10px;
      border: 1px solid #000000;
      text-align: center;
      line-height: 9px;
      font-size: 8px;
      font-weight: bold;
      margin-right: 4px;
      vertical-align: middle;
    }

    .sub-heading-rm {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 7px 0 4px 0;
    }

    .footnote-rm {
      font-size: 7.5pt;
      margin-top: 4px;
      line-height: 1.35;
    }

    /* ==========================================================================
       7. ATOMIC SIGNATURE FOOTER (break-inside: avoid)
       ========================================================================== */
    .rm-signature-block {
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 20px;
      break-inside: avoid;
      page-break-inside: avoid;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-sig-box {
      width: 44%;
      text-align: center;
    }

    .rm-sig-box.left-align {
      text-align: left;
    }

    .rm-sig-space {
      height: 44px;
    }

    .rm-sig-name {
      font-weight: bold;
    }

    .rm-sig-sub {
      font-size: 7.5pt;
    }

    /* ==========================================================================
       8. SECTION 04 \u2014 FILE UPLOAD ORIGINAL PASSTHROUGH (NOT REDESIGNED)
       ========================================================================== */
    .passthrough-separator {
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      padding: 4px 6px;
      margin-bottom: 10px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .raw-upload-frame {
      border: 1px solid #000000;
      padding: 8px 10px;
      margin-bottom: 12px;
      font-family: "Times New Roman", Times, serif;
      font-size: 8.5pt;
      break-inside: avoid;
    }

    .raw-upload-table {
      width: 100%;
      border-collapse: collapse;
      margin: 6px 0;
      font-size: 8pt;
    }

    .raw-upload-table th,
    .raw-upload-table td {
      border: 1px solid #000000;
      padding: 2px 4px;
    }

    /* ==========================================================================
       9. PRINT MEDIA RULES (@media print \u2014 A4 PORTRAIT, 12MM MARGIN)
       ========================================================================== */
    @media print {
      @page {
        size: A4 portrait;
        margin: 12mm;
      }

      body {
        background-color: #FFFFFF !important;
        margin: 0;
        padding: 0;
      }

      .no-print,
      .verifier-toolbar,
      .img-tools {
        display: none !important;
      }

      .dossier-wrapper {
        max-width: 100%;
        margin: 0;
        gap: 0;
      }

      .rm-page {
        border: none !important;
        padding: 0 !important;
        margin: 0 !important;
        break-after: page;
        page-break-after: always;
      }

      .rm-page:last-child {
        break-after: auto;
        page-break-after: auto;
      }

      .rm-page.hidden-section {
        display: none !important;
      }

      thead {
        display: table-header-group;
      }

      tr,
      .rm-signature-block,
      .id-box-bordered {
        break-inside: avoid;
        page-break-inside: avoid;
      }
    }

    @media (max-width: 720px) {
      .rm-page {
        padding: 12px;
      }
      .id-box-bordered,
      .id-box-borderless {
        flex-direction: column;
        gap: 4px;
      }
      .rm-signature-block {
        flex-direction: column;
        gap: 14px;
      }
      .rm-sig-box {
        width: 100%;
      }
    }

/* \u2500\u2500 Tambahan generator: komponen hasil scrape & fokus keyboard \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.kop-logo{object-fit:contain;object-position:center}
/* SEP BPJS \u2014 cetakan VClaim (sheet menggantikan kop RSUD) */
.rm-page.sep-page{padding:0}
.bpjs-sep-sheet{width:210mm;max-width:100%;margin:0 auto;padding:10mm 14mm;background:#fff;color:#000;font:9.5pt/1.38 Arial,Helvetica,sans-serif;box-sizing:border-box;break-inside:avoid;page-break-inside:avoid}
.sep-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;position:relative}
.sep-logo{flex:0 0 215px;width:215px;height:33px;object-fit:contain;object-position:left center}
.sep-title-wrap{flex:0 0 auto;text-align:right;padding-right:0}
.sep-title{font-size:10.5pt;font-weight:400;letter-spacing:.3px;text-transform:uppercase}
.sep-hospital{font-size:10.5pt;text-transform:uppercase}
.sep-columns{display:flex;justify-content:space-between;gap:18px}
.sep-col-left{flex:0 0 56%}
.sep-col-right{flex:0 0 42%;display:flex;flex-direction:column;justify-content:space-between}
.sep-kv-table{width:100%;border-collapse:collapse}
.sep-kv-table td{padding:1.8px 0;vertical-align:top;border:none}
.sep-kv-table td.lbl{width:102px;white-space:nowrap}
.sep-col-right .sep-kv-table td.lbl{width:92px}
.sep-kv-table td.sep{width:12px;text-align:center}
.sep-kv-table td.val{word-break:break-word}
.sep-no-value{font-size:9.5pt;letter-spacing:.2px}
.sep-inline-mr{margin-left:14px;white-space:nowrap}
.sep-multiline-list{margin:0;padding:0;list-style:none}
.sep-disclaimer{margin-top:10px;font-size:7.5pt;font-style:italic}
.sep-print-meta{font-size:9.5pt;font-style:normal}
/* Isi/body SEP seragam 9.5pt \u2014 kecuali disclaimer (7.5pt italic). */
.sep-signatures{display:flex;justify-content:flex-end;gap:16px;margin-top:18px}
.sep-sig-box{flex:0 0 44%;font-size:9.5pt;line-height:1.25;text-align:center}
.sep-sig-role{min-height:24px}
.sep-sig-name{margin-top:2px;font-weight:bold}
.sep-qr{display:block;margin:2px auto;width:100px;height:100px;object-fit:contain}
.rm-sig-qr{display:block;width:80px;height:80px;margin:0 auto 4px;object-fit:contain}
/* @page A4 portrait 12mm ditetapkan sekali di blok print utama \u2014 jangan
   ditimpa di sini supaya margin semua halaman dossier konsisten. */
@media print{body{background:#fff;padding:0}.bpjs-sep-sheet{width:100%;padding:0}}
@media screen{body{background:#e5e7eb;padding:20px}.bpjs-sep-sheet{box-shadow:0 1px 4px rgba(0,0,0,.15)}}
/* Telaah (RM.07) \u2014 grid 2 kolom ala telaahResepPrint.ts */
.t-main{display:grid;grid-template-columns:62% 38%;gap:8px;align-items:start}
.t-left,.t-right{display:flex;flex-direction:column;gap:5px;min-width:0}
.tm-card{padding:2px 0 4px;margin-bottom:4px;border-bottom:.5pt solid #333}
.tm-col{display:flex;flex-direction:column;gap:2px}
.tm-row{display:grid;grid-template-columns:30% 70%;column-gap:4px;align-items:start}
.tm-row.long{display:grid}
.tm-label{font-size:7.5pt;line-height:1.25;color:#333}
.tm-val{font-size:8pt;line-height:1.25;overflow-wrap:anywhere}
.t-meds{font-size:8pt;margin-bottom:6px}
.med{margin-bottom:3px;line-height:1.3}
.med-no{font-weight:400}
.med-name{font-weight:700}
.med-jml{font-weight:700;white-space:nowrap}
.t-lampiran th{font-size:7.5pt}
.rm-summary{margin:8px 0 10px;font-size:8.5pt}
.rm-sum-line{display:flex;align-items:baseline;gap:6px;padding:1px 0}
.rm-sum-line .rm-sum-dots{flex:1;border-bottom:1px dotted #000;transform:translateY(-3px)}
.rm-checkbox:focus-visible,.vbox:focus-visible,.toolbar-btn:focus-visible,.toolbar-select:focus-visible,.tab-btn:focus-visible{outline:2px solid #000000;outline-offset:2px}
.vbox{appearance:none;-webkit-appearance:none;width:11px;height:11px;margin:0;border:1px solid #000000;border-radius:0;background-color:#FFFFFF;display:inline-grid;place-content:center;vertical-align:middle;cursor:pointer}
.vbox::before{content:"\u2713";font-size:9px;font-weight:bold;line-height:1;color:#000000;transform:scale(0)}
.vbox:checked::before{transform:scale(1)}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 8px!important;font-size:8.2pt!important}
.doc-body th,.doc-body td{border:1px solid #000000!important;padding:3px 5px!important;vertical-align:top;color:#000000!important;overflow-wrap:anywhere}
.doc-body th{background-color:#FFFFFF!important;font-weight:bold;text-align:center}
.doc-body h1,.doc-body h2,.doc-body h3{font-size:9.5pt;margin:6px 0}
.doc-body p{margin:2px 0}
.doc-body label{min-width:100px;font-weight:600;color:#333333}
.doc-body .fv{font-weight:500}
.doc-body img{max-width:100%!important;height:auto!important}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important}
.doc-body .vcol{width:16px!important;text-align:center!important}
.telaah-layout{display:flex;gap:8px;align-items:stretch;margin:0 0 6px}
.telaah-layout table{flex:1;margin-bottom:0}
.img-wrap{display:inline-block;max-width:100%}
.img-tools{display:flex;gap:6px;justify-content:flex-end;margin:0 0 5px}
.img-tools button{font-family:inherit;font-size:10px;padding:3px 9px;border:1px solid #000000;background-color:#FFFFFF;cursor:pointer}
</style></head><body>
<style>
    /* IGD: gambar asal MORBIS (skala nyeri Wong Baker & gambar objektif)
       ikut tercetak, dirapikan sebagai figure + keterangan. */
    .rm-figure { margin: 0 0 8px; break-inside: avoid; text-align: center; }
    .rm-figure img { max-width: 100%; height: auto; border: 1px solid #000000; }
    .rm-figure figcaption { margin-top: 3px; font-size: 7pt; text-transform: uppercase; letter-spacing: 0.04em; }
    .rm-figure-row { display: flex; gap: 10px; align-items: flex-start; break-inside: avoid; }
    .rm-figure-row .rm-figure { flex: 0 0 46%; margin: 0; }
    .rm-figure-row .rm-grid-table { flex: 1; min-width: 0; }
    .rm-note { border: 1px solid #000000; padding: 6px 8px; margin-bottom: 8px; font-size: 8.2pt; line-height: 1.4; break-inside: avoid; }

    /* Bahasa visual RM baku: banner bagian bernomor, tabel full-grid, kotak
       centang statis \u2014 mengikuti prototipe referensi RM.02/IGD. */
    .rm-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-family: Arial, Helvetica, sans-serif; font-size: 8pt; line-height: 1.28; }
    .rm-table th, .rm-table td { border: 1px solid #000000; padding: 3px 5px; vertical-align: top; }
    .rm-table th { font-weight: bold; text-align: center; vertical-align: middle; }
    .rm-table tr.sec-hdr td { font-weight: bold; font-size: 8.5pt; text-transform: uppercase; padding: 4px 5px; letter-spacing: 0.01em; }
    .chk-box { display: inline-block; width: 9.5px; height: 9.5px; border: 1px solid #000000; text-align: center; line-height: 8.5px; font-size: 7.5pt; font-weight: bold; margin-right: 3px; vertical-align: middle; }
    .opt-item { display: inline-block; margin-right: 10px; white-space: nowrap; }
    .filter-note { font-size: 7.3pt; font-style: italic; }
    .two-col-grid { display: flex; gap: 6px; margin-bottom: 8px; align-items: stretch; }
    .two-col-grid > .col-half { flex: 1; min-width: 0; }
    .rm-top-meta { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px; font-size: 8.5pt; font-weight: bold; }
    .running-header-box { border: 1px solid #000000; padding: 4px 8px; margin-bottom: 6px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; font-size: 7.8pt; }

    /* Editorial clinical: nomor urut otomatis, kepala pasien, dan ringkasan
       data kritis \u2014 tetap tinta hitam di atas kertas A4. */
    #pengkajian-igd { counter-reset: igdsec; }
    #pengkajian-igd .sub-heading-rm {
      counter-increment: igdsec;
      position: relative;
      padding: 3px 0 3px 30px;
      border-bottom: 1px solid #000000;
    }
    #pengkajian-igd .sub-heading-rm::before {
      content: counter(igdsec, decimal-leading-zero);
      position: absolute;
      left: 0;
      top: 3px;
      font-size: 7pt;
      font-weight: normal;
      letter-spacing: 0.08em;
    }
    .igd-masthead { margin-bottom: 9px; }
    .igd-masthead-label { font-size: 7pt; letter-spacing: 0.14em; text-transform: uppercase; }
    .igd-masthead-name {
      font-size: 17pt;
      font-weight: bold;
      line-height: 1.15;
      margin: 2px 0 6px;
      letter-spacing: -0.02em;
    }
    .igd-summary {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1.4fr;
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      margin: 0 0 9px;
    }
    .igd-summary > div { padding: 5px 8px; border-left: 1px solid #000000; }
    .igd-summary > div:first-child { border-left: 0; padding-left: 0; }
    .igd-summary span { display: block; font-size: 6.5pt; letter-spacing: 0.1em; text-transform: uppercase; }
    .igd-summary b { display: block; font-size: 11pt; line-height: 1.25; margin-top: 2px; }
    .igd-band-value { font-size: 11pt !important; font-weight: bold; }

    /* Laporan Operasi (RM.20) \u2014 tabel label:nilai tanpa garis di dalam kotak,
       narasi pembedahan dipecah jadi langkah bernomor. */
    #form-operasi .op-kv { width: 100%; border-collapse: collapse; }
    #form-operasi .op-kv td { border: none; padding: 1.5px 0; vertical-align: top; font-size: 8.2pt; line-height: 1.3; }
    #form-operasi .op-kv td.k { width: 132px; white-space: nowrap; }
    #form-operasi .op-kv td.c { width: 10px; text-align: center; }
    #form-operasi .op-kv td.v { overflow-wrap: anywhere; }
    #form-operasi .op-narrative { padding: 6px 8px; line-height: 1.45; }
    #form-operasi .op-preface { margin-bottom: 5px; padding-bottom: 5px; border-bottom: 1px dashed #666666; }
    #form-operasi .op-steps { margin: 3px 0 0; padding-left: 18px; }
    #form-operasi .op-steps li { margin-bottom: 2px; }

    /* Laporan Anestesi (RM.21) \u2014 2 halaman A4, grafik terkunci, 3 TTE sejajar. */
    #form-anestesi .an-meta { display: flex; justify-content: space-between; font-size: 8pt; font-weight: bold; margin-bottom: 2px; }
    #form-anestesi .an-subtitle { text-align: center; font-size: 8.5pt; letter-spacing: 0.08em; margin: -4px 0 6px; }
    #form-anestesi .an-kv { width: 100%; border-collapse: collapse; }
    #form-anestesi .an-kv td { border: none; padding: 1.5px 0; vertical-align: top; font-size: 8.2pt; line-height: 1.3; }
    #form-anestesi .an-kv td.k { width: 112px; white-space: nowrap; }
    #form-anestesi .an-kv td.c { width: 10px; text-align: center; }
    #form-anestesi .an-kv td.v { overflow-wrap: anywhere; }
    #form-anestesi .an-grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 2px 6px; font-size: 8pt; }
    #form-anestesi .an-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px 8px; font-size: 7.8pt; margin-top: 2px; }
    #form-anestesi .an-risk { margin-top: 4px; padding-top: 4px; border-top: 1px dashed #666666; }
    #form-anestesi .chart-frame { padding: 4px; text-align: center; border: 1px solid #000000; break-inside: avoid; page-break-inside: avoid; }
    #form-anestesi .chart-frame img { max-width: 100%; height: auto; }
    #form-anestesi .an-page-break { page-break-before: always; break-before: page; }
    #form-anestesi { break-after: auto; page-break-after: auto; }
    #form-anestesi + .rm-page { break-before: page; page-break-before: always; }
    #form-anestesi .an-tte .tte-qr img { width: 100%; height: auto; max-width: 48px; }
    #form-anestesi .an-running { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; border-bottom: 1.5px solid #000000; padding-bottom: 4px; margin: 0 0 7px; font-size: 8pt; }
    #form-anestesi .an-instruksi { margin: 0; padding-left: 18px; line-height: 1.4; font-size: 8.2pt; }
    #form-anestesi .an-tte-note { font-size: 7.6pt; margin-top: 4px; }
    #form-anestesi .an-tte { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 8px; break-inside: avoid; page-break-inside: avoid; }
    #form-anestesi .an-tte .tte-box { padding: 5px 4px; text-align: center; font-size: 8pt; }
    #form-anestesi .an-tte .tte-qr { width: 54px; height: 54px; margin: 4px auto; border: 1px solid #000000; padding: 2px; display: flex; align-items: center; justify-content: center; }
    #form-anestesi .an-tte .tte-name { font-weight: bold; }
</style>
<header class="verifier-toolbar no-print"><div class="toolbar-row">
<div class="toolbar-group"><span class="toolbar-label">Formulir RM Klaim BPJS:</span><select id="rmSectionSelect" class="toolbar-select" aria-label="Pilih Formulir RM">${T}</select></div>
<div class="toolbar-group"><span class="toolbar-counter">Tanda Verifikator (&#10003;): <strong id="checkCounter">0 / 0</strong></span>
<button type="button" class="toolbar-btn" id="btnCheckAll">Centang Semua</button>
<button type="button" class="toolbar-btn" id="btnResetChecks">Reset</button>
<button type="button" class="toolbar-btn toolbar-btn-print" id="btnPrintPdf">Cetak / Simpan PDF (A4)</button></div>
</div><nav id="rmTabs" class="toolbar-tabs" aria-label="Navigasi Formulir RM">${I}</nav></header>
<main class="dossier-wrapper">${F}${O}</main>
</body></html>`}async function te(){let e=a=>{let i=getComputedStyle(a);return i.display!=="none"&&i.visibility!=="hidden"&&Number(i.opacity)>0},L=Date.now()+3e3;for(;Date.now()<L&&[".swal2-container",".swal-overlay--active",".sweet-alert"].flatMap(a=>Array.from(document.querySelectorAll(a))).some(e);)await new Promise(a=>window.setTimeout(a,150));await new Promise(a=>window.setTimeout(a,50))}function ae(e){let L=window.open("","_blank");if(!L)return!1;try{return L.document.open(),L.document.write(e),L.document.close(),Ma(L),sa(L),!0}catch{return!1}}async function Ht(){let e=document.getElementById("ext-mklaim-print-btn"),L=e?.textContent||"Cetak Rapi M-KLAIM";e&&(e.disabled=!0,e.textContent="Memproses\u2026",e.style.opacity="0.7");try{await te();let{sections:a,inventory:i}=Ut();if(a.length<3&&(await new Promise(l=>window.setTimeout(l,800)),{sections:a,inventory:i}=Ut()),!a.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let r=Za(a,i);if(ae(r))return;let u;for(let l of[0,300,600]){l&&await new Promise(o=>window.setTimeout(o,l));try{if(!(await chrome.runtime.sendMessage({type:"OPEN_PRINT_DOSSIER",html:r}))?.success)throw new Error("background menolak membuka tab");return}catch(o){u=o;let A=o instanceof Error?o.message:String(o);if(!/Receiving end does not exist|Extension context invalidated/i.test(A))break}}let s=u instanceof Error?u.message:String(u||"");chrome.runtime?.id?window.alert(`Gagal membuka dossier: ${s||"tidak diketahui"}. Refresh halaman M-KLAIM (Ctrl+Shift+R) lalu coba lagi.`):window.alert("Ekstensi diperbarui, refresh halaman M-KLAIM (Ctrl+Shift+R) lalu klik lagi Cetak Rapi.")}finally{e&&(e.disabled=!1,e.textContent=L,e.style.opacity="1")}}function ee(){let e=Array.from(document.querySelectorAll("button.btn-success")).find(L=>/^printDiv\s*\(/i.test(L.getAttribute("onclick")||""));return e?.parentElement?e.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(L=>L.querySelector("button"))||document.getElementById("SCETAK")||document.body}var zt="v2";function Wt(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor"))return;let e=document.getElementById("ext-mklaim-print-btn");if(e?.dataset.extBuild===zt)return;e?.remove();let L=ee(),a=document.createElement("button");a.id="ext-mklaim-print-btn",a.dataset.extBuild=zt,a.type="button",a.className="btn btn-primary btn-sm",a.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",a.textContent="Cetak Rapi M-KLAIM",a.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),Ht()}),L.appendChild(a)}return window.extMklaimPrintNow=Ht,typeof Ot.featureModules<"u"&&(Ot.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let e=()=>Wt();document.readyState==="complete"?window.setTimeout(e,500):window.addEventListener("load",()=>window.setTimeout(e,500));let L=()=>{let a=document.getElementById("ext-mklaim-print-btn");if(a?.dataset.extBuild!==zt){Wt();return}a.parentElement&&a.parentElement.lastElementChild!==a&&a.parentElement.appendChild(a)};new MutationObserver(()=>L()).observe(document.body,{childList:!0,subtree:!0}),window.setInterval(L,1500)}}),ea(vt)})();
