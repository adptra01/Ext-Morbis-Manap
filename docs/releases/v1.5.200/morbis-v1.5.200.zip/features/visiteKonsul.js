"use strict";var __morbis_feature=(()=>{var K="http://dev.rsudkotajambi.id/rs",B="ext-farmasi-app-base",q=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],H=".rsudkotajambi.id";function O(t){try{let e=new URL(t);if(e.protocol!=="http:"&&e.protocol!=="https:")return!1;let a=e.hostname.toLowerCase();return q.includes(a)?!0:a.endsWith(H)}catch{return!1}}function U(){try{let t=localStorage.getItem(B);if(t&&O(t))return t.replace(/\/+$/,"")}catch{}return K}function V(){return U()}function G(t,e=8e3){try{let a=window.requestIdleCallback;if(typeof a=="function"){a.call(window,t,{timeout:e});return}}catch{}window.setTimeout(t,Math.min(e,1500))}function J(){return window}var W='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',j=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${W};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,w=null;function Y(){return w||(w=new CSSStyleSheet,w.replaceSync(j)),w}var T=!1;function F(){if(T||document.getElementById("ext-pjs-font"))return;T=!0;let t=document.createElement("link");t.id="ext-pjs-font",t.rel="stylesheet",t.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(t)}function L(t,e="open"){let a=t.attachShadow({mode:e});return a.adoptedStyleSheets=[Y()],F(),a}var I=!1;function Q(){if(I)return;I=!0;let t=document.createElement("style");t.id="ext-token-css",t.textContent=j.replace(":host",":root"),document.head.appendChild(t)}var X=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,Z=class extends HTMLElement{constructor(){super();let t=L(this);t.innerHTML=`
      <style>${X}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=t.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",t=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){t.stopPropagation(),t.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(t){(t==="disabled"||t==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}},z=typeof window<"u"?window.customElements:null;if(z)try{z.get("ext-btn")||z.define("ext-btn",Z)}catch(t){console.warn("[MORBIS Ext] gagal registrasi ext-btn:",t)}var tt=`
  :host { display: block; }
  input {
    width: 100%;
    box-sizing: border-box;
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text);
    background: var(--ext-surface);
    border: 1px solid var(--ext-border);
    border-radius: var(--ext-radius-md);
    padding: 9px 12px;
    min-height: 42px;
    transition: border-color var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
  }
  input::placeholder { color: var(--ext-text-muted); }
  input:focus { outline: none; border-color: var(--ext-primary); box-shadow: var(--ext-ring); }
  input:disabled { background: var(--ext-surface-2); color: var(--ext-text-muted); cursor: not-allowed; }
  :host([invalid]) input { border-color: var(--ext-danger); }

  :host([size='sm']) input {
    font-size: var(--ext-font-size-sm);
    padding: 6px 10px;
    min-height: 32px;
    border-radius: var(--ext-radius-sm);
  }
  :host([size='lg']) input {
    font-size: var(--ext-font-size-lg);
    padding: 12px 14px;
    min-height: 50px;
  }
`,et=class extends HTMLElement{constructor(){super();let t=L(this);t.innerHTML=`<style>${tt}</style><input />`,this.input=t.querySelector("input");for(let e of["change","focus","blur"])this.input.addEventListener(e,()=>this.dispatchEvent(new Event(e)))}static get observedAttributes(){return["type","placeholder","value","disabled","invalid"]}connectedCallback(){this.sync()}attributeChangedCallback(){this.sync()}sync(){let{input:t}=this;if(!t)return;t.type=this.getAttribute("type")||"text",t.placeholder=this.getAttribute("placeholder")||"",t.disabled=this.hasAttribute("disabled"),t.setAttribute("aria-invalid",this.hasAttribute("invalid")?"true":"false");let e=this.getAttribute("value");e!==null&&t.value!==e&&(t.value=e)}get value(){return this.input.value}set value(t){this.input.value=t??""}focus(){this.input.focus()}},_=typeof window<"u"?window.customElements:null;if(_)try{_.get("ext-input")||_.define("ext-input",et)}catch(t){console.warn("[MORBIS Ext] gagal registrasi ext-input:",t)}var k="[MORBIS Ext] visiteKonsul",C=J();function M(){try{let t=new URLSearchParams(location.search).get("id_visit");return t&&t.trim()?t.trim():null}catch{return null}}var at=V(),E=at+"/api/visite-konsul";function $(t,e){return t?.message||(e?`HTTP ${e.status}`:"gagal menghubungi server")}async function nt(t){let e=await fetch(`${E}/list?id_visit=${encodeURIComponent(t)}`,{credentials:"omit"}),a=await e.json().catch(()=>null);return a?.ok?{rows:(a.data||[]).map(n=>({id:n.id,jenis:n.jenis,nama_dokter:n.nama_dokter,id_dokter:n.id_dokter,saving:!1}))}:{rows:[],error:$(a,e)}}async function rt(t,e,a){let n=await(await fetch(`${E}/save`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"omit",body:JSON.stringify({id:e.id,id_visit:Number(t),jenis:e.jenis,id_dokter:e.id_dokter,nama_dokter:e.nama_dokter,user:a})})).json();return n?.ok?{id:n.data.id,jenis:n.data.jenis,nama_dokter:n.data.nama_dokter,id_dokter:n.data.id_dokter,saving:!1}:null}async function it(t,e){return!!(await(await fetch(`${E}/delete`,{method:"DELETE",headers:{"Content-Type":"application/json"},credentials:"omit",body:JSON.stringify({id:t,id_visit:Number(e)})})).json())?.ok}async function ot(t){let e=await fetch(`${E}/dokter?q=${encodeURIComponent(t)}`,{credentials:"omit"}),a=await e.json().catch(()=>null);return a?.ok?{items:a.data||[]}:{items:[],error:$(a,e)}}function A(t,e,a){if((typeof window<"u"?window.customElements:null)?.get?.("ext-btn")){let x=document.createElement("ext-btn");return x.setAttribute("variant",t),x.setAttribute("size",e),x.textContent=a,x}let n=document.createElement("button");return n.type="button",n.textContent=a,n.className=`ext-vk-btn ext-vk-btn--${t} ext-vk-btn--${e}`,n}function st(){try{let t=document.querySelector('input[name="id_user"], #id_user');if(t?.value?.trim())return t.value.trim()}catch{}return"petugas"}function dt(){let t=document.createElement("style");t.textContent=`
    .ext-vk-card { margin: 12px 0; padding: 12px; border: 1px solid var(--ext-border); border-radius: var(--ext-radius-md); background: var(--ext-surface); font-family: var(--ext-font-family); }
    .ext-vk-card h2, .ext-vk-card h3 { margin: 0 0 8px; font-size: var(--ext-font-size-md); font-weight: 700; color: var(--ext-text); }
    .ext-vk-card > ext-btn, .ext-vk-card > .ext-vk-btn { margin-right: 6px; }
    .ext-vk-btn { display: inline-flex; align-items: center; justify-content: center; font-family: var(--ext-font-family); font-weight: 600; border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); cursor: pointer; margin-right: 6px; }
    .ext-vk-btn--sm { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; }
    .ext-vk-btn--primary { background: var(--ext-primary); color: var(--ext-text-on-primary); border-color: var(--ext-primary); }
    .ext-vk-btn--secondary { background: var(--ext-surface); color: var(--ext-text); }
    .ext-vk-btn--danger { background: var(--ext-danger); color: var(--ext-text-on-primary); border-color: var(--ext-danger); }
    .ext-vk-btn:disabled { opacity: 0.55; cursor: not-allowed; }
    .ext-vk-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
    .ext-vk-table th, .ext-vk-table td { border: 1px solid var(--ext-border); padding: 4px 6px; font-size: var(--ext-font-size-sm); color: var(--ext-text); }
    .ext-vk-table th { background: var(--ext-surface-2); }
    .ext-vk-autocomplete { position: relative; }
    .ext-vk-input { width: 100%; box-sizing: border-box; padding: 6px 10px; font-size: var(--ext-font-size-sm); border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); font-family: var(--ext-font-family); color: var(--ext-text); background: var(--ext-surface); }
    .ext-vk-suggest { position: absolute; top: 100%; left: 0; right: 0; background: var(--ext-surface); border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); max-height: 160px; overflow-y: auto; z-index: 9999; box-shadow: var(--ext-shadow-md); }
    .ext-vk-suggest div { padding: 6px 8px; font-size: var(--ext-font-size-sm); color: var(--ext-text); cursor: pointer; }
    .ext-vk-suggest div:hover { background: var(--ext-surface-2); }
    .ext-vk-status { font-size: var(--ext-font-size-xs); color: var(--ext-text-muted); margin-left: 6px; }
    .ext-vk-warn { margin: 0 0 8px; padding: 8px 10px; font-size: var(--ext-font-size-sm); border-radius: var(--ext-radius-sm); background: var(--ext-danger-soft); border: 1px solid #f3c1be; color: var(--ext-danger); }
  `,document.head.appendChild(t)}function lt(t,e,a){let n=()=>{let s=t.value;return typeof s=="string"?s:t.getAttribute("value")??""},x=s=>{let h=t;try{h.value=s}catch{}t.setAttribute("value",s)},f=t.parentElement,i=null,p=null;function d(){i&&(i.remove(),i=null)}t.addEventListener("input",()=>{p&&window.clearTimeout(p),p=window.setTimeout(async()=>{let s=n().trim();if(s.length<2){d();return}let{items:h,error:g}=await ot(s);if(d(),!(!h.length&&!g)){if(i=document.createElement("div"),i.className="ext-vk-suggest",g&&!h.length){let o=document.createElement("div");o.textContent=`Pencarian dokter gagal: ${g}`,o.style.color="var(--ext-danger)",i.appendChild(o),f.appendChild(i);return}for(let o of h){let l=document.createElement("div");l.textContent=o.nama,l.addEventListener("mousedown",y=>{y.preventDefault(),x(o.nama),a(o.id,o.nama),d()}),i.appendChild(l)}f.appendChild(i)}},250)}),t.addEventListener("blur",()=>window.setTimeout(d,150))}function N(t,e,a,n,x,f){let i=document.createElement("div");i.className="ext-vk-card";let p=document.createElement("h3");p.textContent=t,i.appendChild(p);let d=document.createElement("table");d.className="ext-vk-table";let s=document.createElement("thead");s.innerHTML='<tr><th style="width:40px">No</th><th>Dokter</th><th style="width:60px">Aksi</th></tr>',d.appendChild(s);let h=document.createElement("tbody");d.appendChild(h),i.appendChild(d);let g=A("secondary","sm","+ Tambah");i.appendChild(g);let o=A("primary","sm","Simpan");i.appendChild(o);let l=document.createElement("span");l.className="ext-vk-status",i.appendChild(l);function y(){h.innerHTML="",a.filter(r=>r.jenis===e).forEach((r,v)=>{let m=document.createElement("tr"),b=document.createElement("td");b.textContent=String(v+1),m.appendChild(b);let D=document.createElement("td"),S=document.createElement("div");S.className="ext-vk-autocomplete";let c;if(window.customElements?.get?.("ext-input")){c=document.createElement("ext-input"),c.setAttribute("type","text"),c.setAttribute("size","sm"),c.setAttribute("placeholder","Ketik nama dokter...");try{c.value=r.nama_dokter}catch{}c.setAttribute("value",r.nama_dokter)}else{let u=document.createElement("input");u.type="text",u.placeholder="Ketik nama dokter...",u.value=r.nama_dokter,u.className="ext-vk-input",c=u}S.appendChild(c),D.appendChild(S),lt(c,r,(u,mt)=>{r.id_dokter=u,r.nama_dokter=mt,l.textContent="Belum disimpan"}),c.addEventListener("change",()=>{let u=c.value;r.nama_dokter=(typeof u=="string"?u:c.getAttribute("value")??"").trim(),l.textContent="Belum disimpan"}),m.appendChild(D);let R=document.createElement("td"),P=A("danger","sm","Hapus");P.addEventListener("click",async()=>{if(r.id&&!await it(r.id,n)){l.textContent="Gagal hapus";return}let u=a.indexOf(r);u>=0&&a.splice(u,1),y(),l.textContent="Dihapus"}),R.appendChild(P),m.appendChild(R),h.appendChild(m)})}async function pt(r){if(!r.nama_dokter.trim()||r.saving)return!1;r.saving=!0;let v=await rt(n,r,x);return r.saving=!1,v?(r.id=v.id,r.id_dokter=v.id_dokter,r.nama_dokter=v.nama_dokter,!0):!1}o.addEventListener("click",async()=>{let r=a.filter(b=>b.jenis===e&&b.nama_dokter.trim());if(!r.length){l.textContent="Belum ada data";return}let v=!!window.customElements?.get?.("ext-btn");v?o.setAttribute("loading",""):(o.disabled=!0,o.textContent="Menyimpan..."),l.textContent="Menyimpan...";let m=0;for(let b of r)await pt(b)&&m++;v?o.removeAttribute("loading"):(o.disabled=!1,o.textContent="Simpan"),l.textContent=m===r.length?"Tersimpan":`Tersimpan ${m}/${r.length}`,m!==r.length&&console.warn(k,"gagal simpan",e,m,"/",r.length)}),g.addEventListener("click",()=>{a.push({id:null,jenis:e,nama_dokter:"",id_dokter:null,saving:!1}),y()}),y(),f.appendChild(i)}function ut(){return Array.from(document.querySelectorAll("h2.judul")).find(e=>/halaman\s+utama/i.test(e.textContent||""))||Array.from(document.querySelectorAll("h1, h2, h3")).find(e=>/halaman\s+utama/i.test(e.textContent||""))||null}async function ct(t=5e3){let e=Date.now()+t;for(;;){let a=ut();if(a||Date.now()>e)return a;await new Promise(n=>setTimeout(n,250))}}async function xt(){let t=M();if(!t||C.__extVisiteKonsul)return;C.__extVisiteKonsul=!0,Q(),dt();let e=st(),a=document.querySelector("#main-content, .content, main, #content");a||(a=document.body);let n=document.createElement("div");n.className="ext-vk-card";let x=document.createElement("h2");x.textContent="Visite & Konsul Dokter Spesialis IGD (input manual)",n.appendChild(x);let f=await ct();f?f.insertAdjacentElement("afterend",n):a.insertBefore(n,a.firstChild);let{rows:i,error:p}=await nt(t);if(p){let s=document.createElement("div");s.className="ext-vk-warn",s.textContent=`API visite-konsul tidak aktif (${p}). Pencarian & simpan dokter akan gagal sampai admin Reports mengaktifkan grup API ini.`,n.appendChild(s),console.warn(k,"api list gagal:",p)}let d=i;N("VISITE","visite",d,t,e,n),N("KONSUL","konsul",d,t,e,n),console.log(k,"loaded",d.length,"rows for visit",t)}typeof C.featureModules<"u"?C.featureModules.visiteKonsul={id:"visiteKonsul",name:"Visite & Konsul Dokter (IGD)",description:"Input manual visite & konsul dokter spesialis IGD di halaman utama pelayanan (data di Reports SIMRS)",match:{pathname:"/admisi/pelaksanaan_pelayanan/halaman-utama"},enabledWhen:()=>!!M(),run:()=>G(()=>{xt().catch(t=>console.error(k,t))},500)}:console.warn(k,"featureModules not defined, registration skipped")})();
