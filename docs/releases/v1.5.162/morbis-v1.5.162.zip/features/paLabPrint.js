"use strict";var __morbis_feature=(()=>{var X="extensionConfig";function kt(p,a,m){let g=a?.features?.[p];if(!g)return!0;if(g.enabled===!1)return!1;let y=m??a?.currentRole??"admin";if(y==="admin")return!0;let A=g.allowedRoles;return!Array.isArray(A)||A.length===0?!0:A.includes(y)}async function vt(p){try{let a=(await chrome.storage.sync.get(X))?.[X]??null;return kt(p,a)}catch{return!0}}function wt(p,a){vt(p).then(m=>{if(m)try{a()}catch(g){console.error(`[featureGate:${p}] gagal jalan:`,g)}})}var Q="ext-free-text-noop",jt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function At(p){try{let a=p.toUpper;if(typeof a=="function"&&a[Q]===!0)return!0;let m=function(g){return g?.value??""};m[Q]=!0;try{Object.defineProperty(p,"toUpper",{value:m,writable:!0,configurable:!0})}catch{p.toUpper=m}return!0}catch{return!1}}var N="ext-pa-typo",St=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi"},{key:"kesimpulan",label:"Kesimpulan"},{key:"icdo",label:"ICD-O"},{key:"catatan",label:"Catatan"},{key:"ttd",label:"TTD"}],w={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},icdo:{fs:6,lh:1.2},catatan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},Z=4,Y=24,Et=.5,Ct=2.5;function tt(p,a,m,g){let y=typeof p=="number"?p:Number(p);return Number.isFinite(y)?Math.min(g,Math.max(m,y)):a}function j(p,a){let m=p??{};return{fs:tt(m.fs,a.fs,Z,Y),lh:tt(m.lh,a.lh,Et,Ct)}}function P(p){let a=p??{};return{kop:j(a.kop,w.kop),pasien:j(a.pasien,w.pasien),judul:j(a.judul,w.judul),isi:j(a.isi,w.isi),kesimpulan:j(a.kesimpulan,w.kesimpulan),icdo:j(a.icdo,w.icdo),catatan:j(a.catatan,w.catatan),ttd:j(a.ttd,w.ttd)}}function K(){return P(null)}function et(p){try{if(!p)return K();let a=p.getItem(N);return a?P(JSON.parse(a)):K()}catch{return K()}}function Lt(p,a){try{return p?(p.setItem(N,JSON.stringify(P(a))),!0):!1}catch{return!1}}function zt(p){try{p?.removeItem(N)}catch{}}function at(p){let a=P(p),m=g=>Math.min(Y,Math.max(Z,g));return{...a,alamatFs:m(a.kop.fs-8.5),judulLapFs:m(a.kop.fs-4)}}var b=p=>String(Math.round(p*100)/100);function It(p){let a=at(p);return{"--pa-kop-fs":`${b(a.kop.fs)}pt`,"--pa-kop-lh":b(a.kop.lh),"--pa-alamat-fs":`${b(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(a.judulLapFs)}pt`,"--pa-pasien-fs":`${b(a.pasien.fs)}pt`,"--pa-pasien-lh":b(a.pasien.lh),"--pa-judul-fs":`${b(a.judul.fs)}pt`,"--pa-judul-lh":b(a.judul.lh),"--pa-isi-fs":`${b(a.isi.fs)}pt`,"--pa-isi-lh":b(a.isi.lh),"--pa-kesimpulan-fs":`${b(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(a.kesimpulan.lh),"--pa-icdo-fs":`${b(a.icdo.fs)}pt`,"--pa-icdo-lh":b(a.icdo.lh),"--pa-catatan-fs":`${b(a.catatan.fs)}pt`,"--pa-catatan-lh":b(a.catatan.lh),"--pa-ttd-fs":`${b(a.ttd.fs)}pt`,"--pa-ttd-lh":b(a.ttd.lh)}}function Rt(p,a){if(p)try{for(let[m,g]of Object.entries(It(a)))p.setProperty(m,g)}catch{}}var Tt=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function it(p){let a=p??"",m=a.match(Tt);if(!m)return null;let g=a.slice(m[0].length).trim();return g===""?null:[m[1],g]}wt("paLabPrint",function(){"use strict";function p(){try{At(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let y=document.createElement("style");y.id="ext-free-text-style",y.textContent=jt,document.head.appendChild(y)}}catch{}}if(p(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",p),window.setInterval(p,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let y="ext-pa-print-proc";if(document.documentElement.getAttribute(y))return;document.documentElement.setAttribute(y,"1");let A=()=>{try{return window.localStorage??null}catch{return null}},S=et(A()),_=()=>{try{Rt(document.documentElement.style,S)}catch{}};_();let v=t=>D(t?.textContent||"");function nt(t){return t.replace(/<[^>]+>/g," ")}function qt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function D(t){return qt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let rt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",M=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>v(t)).filter(Boolean);for(;M.length<3;)M.push("");let T=[],ot=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(ot){let t=document.createElement("div");t.innerHTML=ot.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),T=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let U=T.join(" "),lt=t=>{let e=U.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},st=lt("telp"),pt=lt("fax"),H=(U.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],B=(U.match(/https?:\/\/[^\s;,]+/)||[""])[0],C=U.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");H&&(C=C.split(H).join("")),B&&(C=C.split(B).join("")),C=C.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Ft=["Alamat: "+C,st?"Telp: "+st:"",pt?"Fax: "+pt:""].filter(Boolean).join(", "),Pt=[H?"Email: "+H:"",B?"Website: "+B:""].filter(Boolean).join(", ");T=[Ft,Pt].filter(Boolean);let G=v(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",O=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let o=v(e[0]),s=v(e[2]),l=v(e[3]),r=v(e[5]);o&&O.push([o,s]),l&&O.push([l,r])}});let z=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],x=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),E=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",o=!1,s=t.querySelector(".section-title");if(s)e=v(s),o=!0;else{let c=f=>f.split(":")[0].trim();for(let f of Array.from(t.children).slice(0,3)){let h=v(f);if(h&&h.length<=24&&z.includes(x(c(h)))){e=c(h);break}}if(!e){let f=(t.textContent||"").split(`
`).map(h=>h.trim()).find(Boolean)||"";f&&z.includes(x(c(f)))&&(e=c(f))}if(!e)return}let l=document.createElement("div");l.innerHTML=t.innerHTML,l.querySelector(".section-title")?.remove();let r=l.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(c=>c.split(/<br\s*\/?>|\n/).map(f=>D(f.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(c=>c.length),u=[],i=[];r.forEach((c,f)=>{c.forEach((h,F)=>{f>0&&F===0&&u.length&&i.push(u.length),u.push(h)})});let n=u;if(!o&&n.length&&x(n[0])===x(e)){n.shift();for(let c=0;c<i.length;c++)i[c]-=1;for(;i.length&&i[0]<=0;)i.shift()}n.length>1&&!/^[IVXLC]+\.\s/.test(n[0])&&n.slice(1).some(c=>/^II\.\s/.test(c))&&(n[0]="I. "+n[0]),e&&E.push({title:e,items:n,para:i})});let Dt=/^catatan\s*:?/i,Mt=/^icd[\s-]*o\b\s*:?/i,J=[];for(let t of E){let e=[{title:t.title,items:[],para:[]}],o=e[0],s=!1,l=(r,u)=>{o={title:r,items:[],para:[],bare:u},e.push(o),s=!0};if(t.items.forEach((r,u)=>{let i=r.match(Dt),n=i?null:r.match(Mt);if(i){x(o.title)!=="catatan"&&l("Catatan");let c=r.slice(i[0].length).trim();c&&(t.para.includes(u)&&o.para.push(o.items.length),o.items.push(c));return}if(n){x(o.title)!=="icdo"&&l("ICD-0",!0),t.para.includes(u)&&o.para.push(o.items.length),o.items.push(r);return}t.para.includes(u)&&o.para.push(o.items.length),o.items.push(r)}),s)for(let r of e)r.items.length&&J.push(r);else J.push(e[0])}E.length=0,E.push(...J),E.forEach((t,e)=>t._i=e),E.sort((t,e)=>{let o=t._i??0,s=e._i??0,l=z.indexOf(x(t.title)),r=z.indexOf(x(e.title)),u=l===-1?z.length:l,i=r===-1?z.length:r;return u!==i?u-i:o-s});function Ut(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let o=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),s=t.getAttribute("placeholder")||"",l=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(o+" "+s+" "+l).slice(0,300)}}function Ht(t,e,o){let s=e.toLowerCase().split(/[^a-z0-9]+/).filter(i=>i.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(i));if(!s.length)return"";let l=s.sort((i,n)=>n.length-i.length)[0],r="",u=-1;return t.querySelectorAll("input, textarea, select").forEach(i=>{let{val:n,ctx:c}=Ut(i);if(!n||n===e||!n.toLowerCase().includes(l))return;let f=o.test(c)?2:0;f>u&&(u=f,r=n)}),r}function Bt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Ot(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let o=i=>/ket\w*\s*klinis/i.test(i),s=i=>/^dokter/i.test(i)||/^rs\b/i.test(i),l=t.map(([i,n],c)=>({label:i,value:n,idx:c})).filter(i=>s(i.label)?!!i.value:o(i.label));if(!l.length)return;let r=new AbortController,u=window.setTimeout(()=>r.abort(),6e3);try{let i=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),n=await fetch(i.toString(),{credentials:"same-origin",signal:r.signal});if(!n.ok){window.console.info("[paPrint] override: fetch input status "+n.status);return}let c=await n.text(),f=new DOMParser().parseFromString(c,"text/html");window.console.info('[paPrint] override: input title="'+(f.title||"").slice(0,60)+'" len='+c.length+" fields="+f.querySelectorAll("input, textarea, select").length);for(let h of l){if(o(h.label)){let L=Bt(f,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),R=D(nt(L));window.console.info("[paPrint] override: "+h.label+' cetak="'+h.value+'" input="'+R+'"'),R&&R!==h.value&&(t[h.idx][1]=R);continue}let F=/^dokter/i.test(h.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,W=Ht(f,h.value,F),k=D(nt(W||""));window.console.info("[paPrint] override: "+h.label+' cetak="'+h.value+'" input="'+k+'"'),k&&k!==h.value&&(t[h.idx][1]=k)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(u)}}await Ot(O).catch(()=>{});let I=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>v(t)).filter(Boolean),dt=I[0]||"",ct=I[1]||"",$=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",ut=I.find(t=>/^\(.*\)$/.test(t))||I[2]||"",ft=I.find(t=>/^nip\.?/i.test(t))||I[3]||"",mt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",$t=Array.from(document.body.querySelectorAll("script")),Nt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),q=O.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let o=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,s=o.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||o,l=s.split(/\s+-\s*/);if(l.length>=3&&/rawat\s+inap/i.test(l[1])){let r=Nt(l[1].trim()),u=l.slice(2).join(" - ").trim(),i=u?r+" - "+u:r;if(i)return[t,i]}return[t,s]}),Kt=q.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),V=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),ht=t=>/^catatan/i.test(t.trim()),gt=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),_t=q.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function bt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(o=>{if(!o.ok)throw new Error("img "+o.status);return o.blob()}).then(o=>new Promise((s,l)=>{let r=new FileReader;r.onload=()=>s(String(r.result)),r.onerror=()=>l(r.error),r.readAsDataURL(o)})).catch(()=>e)}async function Gt(){let t=at(S),[e,o]=await Promise.all([bt(rt),$?bt($):Promise.resolve("")]),s="";for(let n=0;n<q.length;n+=2){let c=q[n],f=q[n+1];s+="<tr><td>"+d(c[0])+"</td><td>:</td><td>"+d(c[1])+"</td>"+(f?"<td>"+d(f[0])+"</td><td>:</td><td>"+d(f[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let l="";for(let n of E){if(ht(n.title)){let k=n.items.length?n.items:["Tidak ada"];l+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.judul.fs+'pt"><b><u>CATATAN:</u></b></td><td valign="top" style="font-size:'+t.catatan.fs+"pt;line-height:"+t.catatan.lh+';">'+k.map(L=>"- <b>"+d(gt(L)||"Tidak ada")+"</b>").join("<br>")+"</td></tr></table>";continue}if(n.bare){n.items.forEach((k,L)=>{l+='<p style="margin:'+(L===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.icdo.fs+"pt;line-height:"+t.icdo.lh+';"><b>'+d(k.toUpperCase())+"</b></p>"});continue}l+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b><u>'+d(n.title.toUpperCase())+"</u></b></p>";let c=x(n.title)==="kesimpulan",f=x(n.title)==="icdo",h=c||x(n.title)==="saran",F=c?t.kesimpulan.fs:f?t.icdo.fs:t.isi.fs,W=c?t.kesimpulan.lh:f?t.icdo.lh:t.isi.lh;n.items.forEach((k,L)=>{let R=h?"<b>"+d(k)+"</b>":V(k),Vt=it(k)?"margin-left:18pt;text-indent:-18pt;":"";l+='<p style="margin:'+(n.para.includes(L)?"14pt":"0")+" 0 6pt 0;font-size:"+F+"pt;line-height:"+W+";text-align:justify;"+Vt+'">'+R+"</p>"})}let r='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(G)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+M.slice(0,3).map(n=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(n)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+T.map(n=>d(n)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(G.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+s+"</table>"+l+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(dt)+'</p><p style="margin:0 0 6pt 0;">'+d(ct)+"</p>"+(o?'<p style="margin:0 0 6pt 0;"><img src="'+o+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(ut)+'</b></p><p style="margin:0 0 6pt 0;">'+d(ft)+"</p></td></tr></table></body></html>",u=new Blob(["\uFEFF"+r],{type:"application/msword"}),i=document.createElement("a");i.href=URL.createObjectURL(u),i.download="Hasil-PA-"+_t+".doc",document.body.appendChild(i),i.click(),window.setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},4e3)}let Jt=E.map(t=>{if(ht(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(r=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+d(gt(r)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=x(t.title)==="kesimpulan",o=x(t.title)==="icdo",s=e||x(t.title)==="saran",l='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+(o&&!t.bare?" section-icdo":"")+'">'+t.items.map((r,u)=>{let i=t.para.includes(u)?" item-para":"",n=it(r);if(n){let c=s?"<strong>"+d(n[1])+"</strong>":V(n[1]);return'<div class="item-list has-marker'+i+'"><span class="item-marker">'+d(n[0])+"</span><span>"+c+"</span></div>"}return'<div class="item-list'+i+'">'+(s?"<strong>"+d(r)+"</strong>":V(r))+"</div>"}).join("")+"</div>";return t.bare?l:'<div class="section-judul">'+d(t.title)+"</div>"+l}).join("");document.body.innerHTML='<a href="'+d(mt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(rt)+'" alt="Logo"></div><div class="kop-text">'+M.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+T.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(G)+'</div><div class="patient-info-container">'+Kt+'</div><div class="hasil-pa">'+Jt+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(dt)+"</p><p>"+d(ct)+"</p>"+($?'<img src="'+d($)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(ut)+'</p><p style="margin-top: 2px;">'+d(ft)+"</p></div></div></div>",$t.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),Gt().catch(()=>{window.location.href=mt})});let xt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(s,l,r,u,i,n,c,f)=>"<label>"+d(r)+'<input type="range" data-g="'+d(s)+'" data-f="'+l+'" min="'+u+'" max="'+i+'" step="'+n+'" value="'+c+'"><output data-o="'+d(s+"-"+l)+'">'+d(String(c)+f)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+St.map(s=>'<div class="t-typo-group"><strong>'+d(s.label)+'</strong><div class="t-typo-row">'+e(s.key,"fs","Font (pt)",4,20,.5,S[s.key].fs,"pt")+e(s.key,"lh","Spasi baris",.5,2.5,.05,S[s.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(s=>{let l=s;l.addEventListener("input",()=>{let r=l.dataset.g,u=l.dataset.f;if(!r||!u||!S[r])return;S[r][u]=Number(l.value),_();let i=t.querySelector(`output[data-o="${r}-${u}"]`);i&&(i.textContent=l.value+(u==="fs"?"pt":""))})});let o=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let s=Lt(A(),S);o&&(o.textContent=s?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(zt(A()),S=et(A()),_(),xt(),o){let s=t.querySelector("[data-note]");s&&(s.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&xt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let yt="ext-pa-print-style";if(!document.getElementById(yt)){let t=document.createElement("style");t.id=yt,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Isi ICD-O yang dirender server DENGAN judul section sendiri:
           grup font & spasi sendiri, terpisah dari Isi. Varian tanpa
           judul memakai .section-isi-bare (grup ICD-O yang sama). */
        .section-icdo {
            font-size: var(--pa-icdo-fs, 6pt);
            line-height: var(--pa-icdo-lh, 1.2);
        }

        /* Hanging indent: baris bernomor/berpoin \u2014 penanda di kolom
           kiri tetap, teks lanjutan sejajar di bawah teks. */
        .item-list.has-marker {
            display: flex;
            gap: 6px;
        }

        .item-marker {
            flex-shrink: 0;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah), tapi ukuran font
           dan spasi baris punya grup sendiri (\u2699\uFE0F Gaya \u2192 ICD-O). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-icdo-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-icdo-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya).
           Label tetap grup Judul Bagian Isi (heading); isi Catatan punya
           grup font & spasi baris sendiri (\u2699\uFE0F Gaya \u2192 Catatan). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-catatan-fs, 5pt);
            line-height: var(--pa-catatan-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
            font-weight: bold;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let m=Date.now(),g=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(g),a().catch(()=>{})):Date.now()-m>5e3&&window.clearInterval(g)},200)})})();
