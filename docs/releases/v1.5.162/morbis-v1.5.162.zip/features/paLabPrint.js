"use strict";var __morbis_feature=(()=>{var at="extensionConfig";function Et(p,a,h){let b=a?.features?.[p];if(!b)return!0;if(b.enabled===!1)return!1;let v=h??a?.currentRole??"admin";if(v==="admin")return!0;let L=b.allowedRoles;return!Array.isArray(L)||L.length===0?!0:L.includes(v)}async function Lt(p){try{let a=(await chrome.storage.sync.get(at))?.[at]??null;return Et(p,a)}catch{return!0}}function Ct(p,a){Lt(p).then(h=>{if(h)try{a()}catch(b){console.error(`[featureGate:${p}] gagal jalan:`,b)}})}var it="ext-free-text-noop",zt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function Tt(p){try{let a=p.toUpper;if(typeof a=="function"&&a[it]===!0)return!0;let h=function(b){return b?.value??""};h[it]=!0;try{Object.defineProperty(p,"toUpper",{value:h,writable:!0,configurable:!0})}catch{p.toUpper=h}return!0}catch{return!1}}var J="ext-pa-typo",It=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],T={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},nt=4,rt=24,Rt=.5,qt=2.5;function ot(p,a,h,b){let v=typeof p=="number"?p:Number(p);return Number.isFinite(v)?Math.min(b,Math.max(h,v)):a}function I(p,a){let h=p??{};return{fs:ot(h.fs,a.fs,nt,rt),lh:ot(h.lh,a.lh,Rt,qt)}}function B(p){let a=p??{};return{kop:I(a.kop,T.kop),pasien:I(a.pasien,T.pasien),judul:I(a.judul,T.judul),isi:I(a.isi,T.isi),kesimpulan:I(a.kesimpulan,T.kesimpulan),ttd:I(a.ttd,T.ttd)}}function Q(){return B(null)}function lt(p){try{if(!p)return Q();let a=p.getItem(J);return a?B(JSON.parse(a)):Q()}catch{return Q()}}function Ft(p,a){try{return p?(p.setItem(J,JSON.stringify(B(a))),!0):!1}catch{return!1}}function Mt(p){try{p?.removeItem(J)}catch{}}function st(p){let a=B(p),h=b=>Math.min(rt,Math.max(nt,b));return{...a,alamatFs:h(a.kop.fs-8.5),judulLapFs:h(a.kop.fs-4)}}var y=p=>String(Math.round(p*100)/100);function Pt(p){let a=st(p);return{"--pa-kop-fs":`${y(a.kop.fs)}pt`,"--pa-kop-lh":y(a.kop.lh),"--pa-alamat-fs":`${y(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${y(a.judulLapFs)}pt`,"--pa-pasien-fs":`${y(a.pasien.fs)}pt`,"--pa-pasien-lh":y(a.pasien.lh),"--pa-judul-fs":`${y(a.judul.fs)}pt`,"--pa-judul-lh":y(a.judul.lh),"--pa-isi-fs":`${y(a.isi.fs)}pt`,"--pa-isi-lh":y(a.isi.lh),"--pa-kesimpulan-fs":`${y(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":y(a.kesimpulan.lh),"--pa-ttd-fs":`${y(a.ttd.fs)}pt`,"--pa-ttd-lh":y(a.ttd.lh)}}function Ht(p,a){if(p)try{for(let[h,b]of Object.entries(Pt(a)))p.setProperty(h,b)}catch{}}var Ut=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function V(p){let a=p??"",h=a.match(Ut);if(!h)return null;let b=a.slice(h[0].length).trim();return b===""?null:[h[1],b]}var Bt=p=>Math.round(p*10)/10;function Nt(p,a){let h=Number.isFinite(a)&&a>0?a:11,b=(p??"").length;return b===0?0:Bt(b*.55*h+.35*h)}Ct("paLabPrint",function(){"use strict";function p(){try{Tt(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let v=document.createElement("style");v.id="ext-free-text-style",v.textContent=zt,document.head.appendChild(v)}}catch{}}if(p(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",p),window.setInterval(p,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let v="ext-pa-print-proc";if(document.documentElement.getAttribute(v))return;document.documentElement.setAttribute(v,"1");let L=()=>{try{return window.localStorage??null}catch{return null}},C=lt(L()),X=()=>{try{Ht(document.documentElement.style,C)}catch{}};X();let S=t=>N(t?.textContent||"");function pt(t){return t.replace(/<[^>]+>/g," ")}function Dt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function N(t){return Dt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let dt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",D=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>S(t)).filter(Boolean);for(;D.length<3;)D.push("");let F=[],ct=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(ct){let t=document.createElement("div");t.innerHTML=ct.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),F=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let O=F.join(" "),ut=t=>{let e=O.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},mt=ut("telp"),ft=ut("fax"),$=(O.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],K=(O.match(/https?:\/\/[^\s;,]+/)||[""])[0],z=O.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");$&&(z=z.split($).join("")),K&&(z=z.split(K).join("")),z=z.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Ot=["Alamat: "+z,mt?"Telp: "+mt:"",ft?"Fax: "+ft:""].filter(Boolean).join(", "),$t=[$?"Email: "+$:"",K?"Website: "+K:""].filter(Boolean).join(", ");F=[Ot,$t].filter(Boolean);let Z=S(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",_=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let r=S(e[0]),o=S(e[2]),s=S(e[3]),n=S(e[5]);r&&_.push([r,o]),s&&_.push([s,n])}});let R=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],A=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),E=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",r=!1,o=t.querySelector(".section-title");if(o)e=S(o),r=!0;else{let i=u=>u.split(":")[0].trim();for(let u of Array.from(t.children).slice(0,3)){let m=S(u);if(m&&m.length<=24&&R.includes(A(i(m)))){e=i(m);break}}if(!e){let u=(t.textContent||"").split(`
`).map(m=>m.trim()).find(Boolean)||"";u&&R.includes(A(i(u)))&&(e=i(u))}if(!e)return}let s=document.createElement("div");s.innerHTML=t.innerHTML,s.querySelector(".section-title")?.remove();let n=s.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(i=>i.split(/<br\s*\/?>|\n/).map(u=>N(u.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(i=>i.length),c=[],l=[];n.forEach((i,u)=>{i.forEach((m,w)=>{u>0&&w===0&&c.length&&l.push(c.length),c.push(m)})});let f=c;if(!r&&f.length&&A(f[0])===A(e)){f.shift();for(let i=0;i<l.length;i++)l[i]-=1;for(;l.length&&l[0]<=0;)l.shift()}f.length>1&&!/^[IVXLC]+\.\s/.test(f[0])&&f.slice(1).some(i=>/^II\.\s/.test(i))&&(f[0]="I. "+f[0]),e&&E.push({title:e,items:f,para:l})});let Kt=/^catatan\s*:?/i,_t=/^icd[\s-]*o\b\s*:?/i,Y=[];for(let t of E){let e=[{title:t.title,items:[],para:[]}],r=e[0],o=!1,s=(n,c)=>{r={title:n,items:[],para:[],bare:c},e.push(r),o=!0};if(t.items.forEach((n,c)=>{let l=n.match(Kt),f=l?null:n.match(_t);if(l){A(r.title)!=="catatan"&&s("Catatan");let i=n.slice(l[0].length).trim();i&&(t.para.includes(c)&&r.para.push(r.items.length),r.items.push(i));return}if(f){A(r.title)!=="icdo"&&s("ICD-0",!0),t.para.includes(c)&&r.para.push(r.items.length),r.items.push(n);return}t.para.includes(c)&&r.para.push(r.items.length),r.items.push(n)}),o)for(let n of e)n.items.length&&Y.push(n);else Y.push(e[0])}E.length=0,E.push(...Y),E.forEach((t,e)=>t._i=e),E.sort((t,e)=>{let r=t._i??0,o=e._i??0,s=R.indexOf(A(t.title)),n=R.indexOf(A(e.title)),c=s===-1?R.length:s,l=n===-1?R.length:n;return c!==l?c-l:r-o});function Wt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let r=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),o=t.getAttribute("placeholder")||"",s=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(r+" "+o+" "+s).slice(0,300)}}function Gt(t,e,r){let o=e.toLowerCase().split(/[^a-z0-9]+/).filter(l=>l.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(l));if(!o.length)return"";let s=o.sort((l,f)=>f.length-l.length)[0],n="",c=-1;return t.querySelectorAll("input, textarea, select").forEach(l=>{let{val:f,ctx:i}=Wt(l);if(!f||f===e||!f.toLowerCase().includes(s))return;let u=r.test(i)?2:0;u>c&&(c=u,n=f)}),n}function Jt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Qt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let r=l=>/ket\w*\s*klinis/i.test(l),o=l=>/^dokter/i.test(l)||/^rs\b/i.test(l),s=t.map(([l,f],i)=>({label:l,value:f,idx:i})).filter(l=>o(l.label)?!!l.value:r(l.label));if(!s.length)return;let n=new AbortController,c=window.setTimeout(()=>n.abort(),6e3);try{let l=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),f=await fetch(l.toString(),{credentials:"same-origin",signal:n.signal});if(!f.ok){window.console.info("[paPrint] override: fetch input status "+f.status);return}let i=await f.text(),u=new DOMParser().parseFromString(i,"text/html");window.console.info('[paPrint] override: input title="'+(u.title||"").slice(0,60)+'" len='+i.length+" fields="+u.querySelectorAll("input, textarea, select").length);for(let m of s){if(r(m.label)){let k=Jt(u,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),j=N(pt(k));window.console.info("[paPrint] override: "+m.label+' cetak="'+m.value+'" input="'+j+'"'),j&&j!==m.value&&(t[m.idx][1]=j);continue}let w=/^dokter/i.test(m.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,x=Gt(u,m.value,w),g=N(pt(x||""));window.console.info("[paPrint] override: "+m.label+' cetak="'+m.value+'" input="'+g+'"'),g&&g!==m.value&&(t[m.idx][1]=g)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(c)}}await Qt(_).catch(()=>{});let q=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>S(t)).filter(Boolean),ht=q[0]||"",gt=q[1]||"",W=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",bt=q.find(t=>/^\(.*\)$/.test(t))||q[2]||"",xt=q.find(t=>/^nip\.?/i.test(t))||q[3]||"",yt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Vt=Array.from(document.body.querySelectorAll("script")),Xt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),M=_.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let r=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,o=r.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||r,s=o.split(/\s+-\s*/);if(s.length>=3&&/rawat\s+inap/i.test(s[1])){let n=Xt(s[1].trim()),c=s.slice(2).join(" - ").trim(),l=c?n+" - "+c:n;if(l)return[t,l]}return[t,o]}),Zt=M.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),tt=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),et=t=>/^catatan/i.test(t.trim()),kt=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),Yt=M.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function wt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(r=>{if(!r.ok)throw new Error("img "+r.status);return r.blob()}).then(r=>new Promise((o,s)=>{let n=new FileReader;n.onload=()=>o(String(n.result)),n.onerror=()=>s(n.error),n.readAsDataURL(r)})).catch(()=>e)}async function te(){let t=st(C),[e,r]=await Promise.all([wt(dt),W?wt(W):Promise.resolve("")]),o="";for(let i=0;i<M.length;i+=2){let u=M[i],m=M[i+1];o+="<tr><td>"+d(u[0])+"</td><td>:</td><td>"+d(u[1])+"</td>"+(m?"<td>"+d(m[0])+"</td><td>:</td><td>"+d(m[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let s=Math.max(0,...E.map(i=>i.bare||et(i.title)?0:Math.max(0,...i.items.map(u=>{let m=V(u),w=A(i.title)==="kesimpulan"?t.kesimpulan.fs:t.isi.fs;return m?Nt(m[0],w):0})))),n="";for(let i of E){if(et(i.title)){let x=i.items.length?i.items:["Tidak ada"];n+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.judul.fs+'pt"><b><u>CATATAN:</u></b></td><td>'+x.map(g=>"- "+d(kt(g)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(i.bare){i.items.forEach((x,g)=>{n+='<p style="margin:'+(g===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.judul.fs+'pt;"><b>'+d(x.toUpperCase())+"</b></p>"});continue}n+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b><u>'+d(i.title.toUpperCase())+"</u></b></p>";let u=A(i.title)==="kesimpulan",m=u?t.kesimpulan.fs:t.isi.fs,w=u?t.kesimpulan.lh:t.isi.lh;i.items.forEach((x,g)=>{let k=u?"<b>"+d(x)+"</b>":tt(x),j=V(x),P=m*1.8,H=(s>0?Math.max(P,s):P).toFixed(1),U="margin-left:"+H+"pt;"+(j?"text-indent:-"+H+"pt;":"");n+='<p style="margin:'+(i.para.includes(g)?"14pt":"0")+" 0 6pt 0;font-size:"+m+"pt;line-height:"+w+";text-align:justify;"+U+'">'+k+"</p>"})}let c='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(Z)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+D.slice(0,3).map(i=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(i)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+F.map(i=>d(i)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(Z.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+o+"</table>"+n+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(ht)+'</p><p style="margin:0 0 6pt 0;">'+d(gt)+"</p>"+(r?'<p style="margin:0 0 6pt 0;"><img src="'+r+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(bt)+'</b></p><p style="margin:0 0 6pt 0;">'+d(xt)+"</p></td></tr></table></body></html>",l=new Blob(["\uFEFF"+c],{type:"application/msword"}),f=document.createElement("a");f.href=URL.createObjectURL(l),f.download="Hasil-PA-"+Yt+".doc",document.body.appendChild(f),f.click(),window.setTimeout(()=>{URL.revokeObjectURL(f.href),f.remove()},4e3)}let ee=E.map(t=>{if(et(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(o=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+d(kt(o)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=A(t.title)==="kesimpulan",r='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+'">'+t.items.map((o,s)=>{let n=t.para.includes(s)?" item-para":"",c=V(o);if(c){let l=e?"<strong>"+d(c[1])+"</strong>":tt(c[1]);return'<div class="item-list has-marker'+n+'"><span class="item-marker">'+d(c[0])+"</span> <span>"+l+"</span></div>"}return'<div class="item-list'+n+'">'+(e?"<strong>"+d(o)+"</strong>":tt(o))+"</div>"}).join("")+"</div>";return t.bare?r:'<div class="section-judul">'+d(t.title)+"</div>"+r}).join("");function G(t=document){let e;try{e=Array.from(t.querySelectorAll(".section-isi:not(.section-isi-bare)"))}catch{return}if(!e.length)return;let r=[],o=12,s=0;for(let u of e){let m;try{m=Array.from(u.querySelectorAll(":scope > .item-list"))}catch{m=Array.from(u.children).filter(g=>g.classList.contains("item-list"))}let w=12;try{let g=parseFloat(getComputedStyle(u).fontSize);Number.isFinite(g)&&g>0&&(w=g)}catch{}w>o&&(o=w);let x=new Map;for(let g of m){if(!g.classList.contains("has-marker"))continue;let k=g.querySelector(".item-marker");if(!k||!k.textContent)continue;let j=0;try{let P=document.createRange();P.selectNodeContents(k);let H=Array.from(P.getClientRects()).filter(U=>U.width>.5);H.length&&(j=Math.max(...H.map(U=>U.width)))}catch{}j>0&&(x.set(g,j),j>s&&(s=j))}r.push({block:u,items:m,widths:x})}let n=o*1.8,c=s>0?Math.max(n,s):n,l=c.toFixed(1)+"px",f=(-c).toFixed(1)+"px",i=s>0?s.toFixed(1)+"px":"";for(let{block:u,items:m,widths:w}of r)try{u.style.paddingLeft=l;for(let x of m){let g=x;g.style.paddingLeft="0px";let k=g.querySelector(".item-marker");w.has(x)?(g.style.textIndent=f,k&&(k.style.display="inline-block",k.style.minWidth=i)):(g.style.textIndent="0px",k&&(k.style.display="",k.style.minWidth=""))}}catch{}}let vt;function jt(){try{window.clearTimeout(vt)}catch{}vt=window.setTimeout(()=>{G()},250)}document.body.innerHTML='<a href="'+d(yt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(dt)+'" alt="Logo"></div><div class="kop-text">'+D.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+F.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(Z)+'</div><div class="patient-info-container">'+Zt+'</div><div class="hasil-pa">'+ee+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(ht)+"</p><p>"+d(gt)+"</p>"+(W?'<img src="'+d(W)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(bt)+'</p><p style="margin-top: 2px;">'+d(xt)+"</p></div></div></div>",Vt.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),te().catch(()=>{window.location.href=yt})});let At=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(o,s,n,c,l,f,i,u)=>"<label>"+d(n)+'<input type="range" data-g="'+d(o)+'" data-f="'+s+'" min="'+c+'" max="'+l+'" step="'+f+'" value="'+i+'"><output data-o="'+d(o+"-"+s)+'">'+d(String(i)+u)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+It.map(o=>'<div class="t-typo-group"><strong>'+d(o.label)+'</strong><div class="t-typo-row">'+e(o.key,"fs","Font (pt)",4,20,.5,C[o.key].fs,"pt")+e(o.key,"lh","Spasi baris",.5,2.5,.05,C[o.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(o=>{let s=o;s.addEventListener("input",()=>{let n=s.dataset.g,c=s.dataset.f;if(!n||!c||!C[n])return;C[n][c]=Number(s.value),X(),jt();let l=t.querySelector(`output[data-o="${n}-${c}"]`);l&&(l.textContent=s.value+(c==="fs"?"pt":""))})});let r=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let o=Ft(L(),C);r&&(r.textContent=o?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Mt(L()),C=lt(L()),X(),At(),r){let o=t.querySelector("[data-note]");o&&(o.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&At(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let St="ext-pa-print-style";if(!document.getElementById(St)){let t=document.createElement("style");t.id=St,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        /* Base gutter di CONTAINER (.section-isi): semua item (polos maupun
           ber-marker, baris pertama maupun lanjutan) berbagi kolom teks
           yang sama; hanya marker yang menggantung di gutter. */
        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            padding-left: 1.8em;
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Hanya marker yang menggantung \u2014 padding sudah disediakan container. */
        .item-list.has-marker {
            text-indent: -1.8em;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-judul-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}G();try{document.fonts?.ready&&document.fonts.ready.then(()=>{G()})}catch{}window.addEventListener("resize",jt),window.addEventListener("beforeprint",()=>{G()})}let h=Date.now(),b=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(b),a().catch(()=>{})):Date.now()-h>5e3&&window.clearInterval(b)},200)})})();
