"use strict";var __morbis_feature=(()=>{var M=Object.defineProperty;var Q=Object.getOwnPropertyDescriptor;var W=Object.getOwnPropertyNames;var X=Object.prototype.hasOwnProperty;var Y=(e,t)=>{for(var n in t)M(e,n,{get:t[n],enumerable:!0})},Z=(e,t,n,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let i of W(t))!X.call(e,i)&&i!==n&&M(e,i,{get:()=>t[i],enumerable:!(r=Q(t,i))||r.enumerable});return e};var ee=e=>Z(M({},"__esModule",{value:!0}),e);var xe={};Y(xe,{applySelectAll:()=>q,clearSelection:()=>k,getSelected:()=>R,initMKlaimBulkVerifFeature:()=>N,isEligible:()=>F,parseIdVisit:()=>te,pruneSelection:()=>z});function $(){return window}var H="ext-batch-shared-style";function S(){if(document.getElementById(H))return;let e=document.createElement("style");e.id=H,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function A(e,t,n=2){let r=i=>fetch(e,t).catch(o=>{if(i<=0)throw o;return new Promise(s=>setTimeout(s,1e3*(3-i))).then(()=>r(i-1))});return r(n)}function v(e){return new Promise(t=>{S();let n=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",r=document.createElement("div");r.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",r.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${n}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,r.querySelector("h3").textContent=e.title;let i=r.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((d,c)=>{c>0&&i.appendChild(document.createElement("br")),i.appendChild(document.createTextNode(d))});let o=d=>{r.remove(),document.removeEventListener("keydown",s),t(d)},s=d=>{d.key==="Escape"&&o(!1)};r.querySelector(".ext-modal-close").addEventListener("click",()=>o(!1)),r.addEventListener("click",d=>{d.target===r&&o(!1)}),r.querySelector("[data-ext-ok]").addEventListener("click",()=>o(!0));let l=r.querySelector("[data-ext-cancel]");l&&l.addEventListener("click",()=>o(!1)),document.addEventListener("keydown",s),document.body.appendChild(r)})}var P=$(),a={endpointVerif:"/v2/m-klaim/control/verif",endpointBatal:"/v2/m-klaim/control/batal-verif",delayMs:600,barId:"ext-bulk-verif-bar",cssId:"ext-bulk-verif-style",readyTimeoutMs:15e3,readyPollMs:250,warnIfMoreThan:100,UJI_SAJA:!0},b=[{sel:"#data-table",kind:"main",nama:"Klaim",aksi:"Verif",endpoint:a.endpointVerif,danger:!1},{sel:"#data-table-verif",kind:"verif",nama:"Sudah Terverifikasi",aksi:"Batal Verif",endpoint:a.endpointBatal,danger:!0}],p={main:new Set,verif:new Set},f=!1;function q(e,t,n){let r=0;return t.forEach(i=>{!i.id||!i.eligible||(n?p[e].add(i.id):p[e].delete(i.id),r+=1)}),r}function z(e,t){let n=new Set;t.forEach(i=>{i.id&&i.eligible&&n.add(i.id)});let r=0;return Array.from(p[e]).forEach(i=>{n.has(i)||(p[e].delete(i),r+=1)}),r}function R(e){return Array.from(p[e])}function k(e){p[e].clear()}function te(e){let t=e.match(/\d+/);return t?t[0]:null}function F(e,t,n){return t?e==="main"?!0:n:!1}function ne(){if(document.getElementById(a.cssId))return;let e=document.createElement("style");e.id=a.cssId,e.textContent=`
    #${a.barId} {
      position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
      z-index: 2147482000; display: none; align-items: center; gap: 14px;
      background: #0f172a; color: #f8fafc; border-radius: 12px;
      padding: 10px 16px; font-family: 'Inter', system-ui, sans-serif;
      font-size: 13px; box-shadow: 0 8px 28px rgba(15,23,42,.35);
    }
    #${a.barId} .bv-item { display: flex; align-items: center; gap: 8px; }
    #${a.barId} .bv-label { color: #cbd5e1; }
    #${a.barId} .bv-count { color: #f8fafc; font-weight: 700; }
    #${a.barId} button {
      border: none; border-radius: 8px; cursor: pointer; padding: 7px 14px;
      font-size: 12.5px; font-weight: 700; font-family: inherit;
    }
    #${a.barId} .bv-aksi { background: #2563eb; color: #fff; }
    #${a.barId} .bv-aksi:hover { background: #1d4ed8; }
    #${a.barId} .bv-aksi-danger { background: #dc2626; color: #fff; }
    #${a.barId} .bv-aksi-danger:hover { background: #b91c1c; }
    #${a.barId} .bv-reset { background: #334155; color: #e2e8f0; }
    #${a.barId} .bv-reset:hover { background: #475569; }
    #${a.barId} button:disabled { opacity: .55; cursor: not-allowed; }

    .bv-check {
      display: inline-flex; align-items: center; justify-content: center;
      margin-right: 6px; vertical-align: middle; cursor: pointer;
    }
    /* Kolom khusus checkbox: <th> sendiri di posisi 0 + <td> sejajar di tiap
       baris. <th> HANYA ditambahkan setelah DataTables aktif (lihat
       renderHeaderCheckbox) supaya jumlah kolom yang dibaca saat init tetap
       16 dan pemetaan data ajax tidak bergeser. */
    th.bv-sel-th {
      width: 30px; min-width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
    }
    th.bv-sel-th input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    th.bv-sel-th input:disabled { cursor: not-allowed; }
    td.bv-sel {
      width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
    }
    td.bv-sel input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    td.bv-sel input:disabled { cursor: not-allowed; }
    /* Penanda fitur aktif - memudahkan diagnosis di console */
    html[data-ext-bulk-verif='1'] td.bv-sel { background: #eff6ff; }
  `,document.head.appendChild(e),S()}function u(e){return document.querySelector(e.sel)}function U(e){let t=window.jQuery;if(!t)return null;try{return t(e.sel).DataTable()??null}catch{return null}}function K(e){return(Array.isArray(e)?e:[e]).filter(t=>t instanceof HTMLElement)}function L(e){let t=e.querySelector('[onclick*="detail("]');if(t){let r=(t.getAttribute("onclick")||"").match(/\d+/);if(r)return r[0]}let n=e.querySelector('[onclick*="BatalVerif("]');if(n){let r=(n.getAttribute("onclick")||"").match(/\d+/);if(r)return r[0]}return null}function C(e,t){return F(e.kind,!!t.querySelector('button[onclick*="detail("]'),!!t.querySelector('button[onclick*="BatalVerif("]'))}function V(e,t){return{id:L(t),eligible:C(e,t)}}function J(e){let t=u(e);if(!t)return[];let n=U(e);if(n)try{return K(n.rows({search:"applied"}).nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(r=>!r.classList.contains("dataTables_empty"))}function re(e){let t=u(e);if(!t)return[];let n=U(e);if(n)try{return K(n.rows().nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(r=>!r.classList.contains("dataTables_empty"))}function ie(e,t){let n=L(t);if(!n){let s=document.createElement("td");s.className="bv-sel",s.dataset.extBvUnid="1";let l=document.createElement("input");l.type="checkbox",l.disabled=!0,l.title="id_visit tidak terbaca dari markup baris ini",s.appendChild(l),t.insertBefore(s,t.firstChild);return}let r=C(e,t),i=document.createElement("td");i.className="bv-sel";let o=document.createElement("input");o.type="checkbox",o.dataset.extBvId=n,o.checked=p[e.kind].has(n),a.UJI_SAJA?(o.disabled=!0,o.title="Mode uji - belum bisa dipilih"):(o.disabled=!r,o.title=r?"Pilih baris ini":"Baris tidak memenuhi syarat aksi ini",o.addEventListener("change",()=>{o.checked?p[e.kind].add(n):p[e.kind].delete(n),m(),h(e)})),i.appendChild(o),t.insertBefore(i,t.firstChild)}function oe(e){e.querySelectorAll("tbody td.bv-sel").forEach(t=>t.remove())}function _(e){let t=u(e);t&&(oe(t),t.querySelectorAll("tbody tr").forEach(n=>ie(e,n)),h(e))}function h(e){let n=u(e)?.querySelector("thead input[data-ext-bv-header]");if(!n)return;let r=J(e).filter(s=>C(e,s)),i=r.length,o=r.filter(s=>{let l=L(s);return!!l&&p[e.kind].has(l)}).length;n.disabled=a.UJI_SAJA||f||i===0,n.checked=i>0&&o===i,n.indeterminate=o>0&&o<i}function ae(e){if(!e)return!1;try{if(window.jQuery?.fn?.DataTable?.isDataTable?.(e))return!0}catch{}return e.classList.contains("dataTable")}function D(e){let t=u(e);if(!ae(t))return;let n=t?.querySelector("thead tr");if(!n)return;if(n.querySelector('th[data-ext-bv-header="1"]')){h(e);return}let i=document.createElement("th");i.className="bv-sel-th",i.dataset.extBvHeader="1",i.title="Pilih / batal pilih semua baris yang cocok dengan pencarian";let o=document.createElement("input");o.type="checkbox",o.dataset.extBvHeader="1",o.disabled=!0,a.UJI_SAJA?o.title="Mode uji - belum bisa dipilih":(o.title="Pilih semua hasil pencarian",o.addEventListener("change",()=>{let s=J(e).map(l=>V(e,l));q(e.kind,s,o.checked),_(e),m()})),i.appendChild(o),n.insertBefore(i,n.firstChild),a.UJI_SAJA?o.disabled=!0:h(e)}function y(){b.forEach(E),m()}function B(){return document.getElementById(a.barId)}function m(){let e=B();if(!e)return;let t=b.map(r=>[r,p[r.kind].size]).filter(([,r])=>r>0);if(a.UJI_SAJA||t.length===0||f){e.style.display="none";return}e.innerHTML="",t.forEach(([r,i])=>{let o=document.createElement("div");o.className="bv-item";let s=document.createElement("span");s.className="bv-label",s.textContent=`${r.nama}: `;let l=document.createElement("span");l.className="bv-count",l.textContent=`${i} dipilih`;let d=document.createElement("button");d.className=r.danger?"bv-aksi bv-aksi-danger":"bv-aksi",d.textContent=r.aksi,d.addEventListener("click",()=>{ce(r)}),o.append(s,l,d),e.appendChild(o)});let n=document.createElement("button");n.className="bv-reset",n.textContent="Batal Pilih",n.addEventListener("click",()=>{b.forEach(r=>k(r.kind)),y()}),e.appendChild(n),e.style.display="flex"}function se(){if(B())return;let e=document.createElement("div");e.id=a.barId,e.style.display="none",document.body.appendChild(e)}async function le(e,t){try{let n=new URLSearchParams({id_visit:t}),r=await A(e,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:n.toString(),credentials:"same-origin"});if(!r.ok)return{id:t,ok:!1,pesan:`HTTP ${r.status}`};let i=await r.json(),o=String(i.kode)==="200";return{id:t,ok:o,pesan:i.message??(o?"Sukses":"Gagal")}}catch(n){return{id:t,ok:!1,pesan:n.message||"Gagal koneksi"}}}function de(e){let t=re(e).map(r=>V(e,r)),n=z(e.kind,t);return{valid:R(e.kind),gugur:n}}async function ce(e){if(f)return;let{valid:t,gugur:n}=de(e);if(t.length===0){k(e.kind),y(),await v({title:"Tidak ada baris yang bisa diproses",message:"Pilihan tidak lagi cocok dengan data di tabel. Silakan pilih ulang.",okLabel:"Mengerti",hideCancel:!0});return}let r=Math.ceil(t.length*a.delayMs/1e3),i=[`${e.nama}: ${t.length} baris akan diproses.`];if(n>0&&i.push(`${n} pilihan diabaikan (data berubah/tidak memenuhi syarat).`),i.push(e.danger?"Verifikasi yang dibatalkan kembali ke daftar belum terverifikasi.":"Data yang tidak memenuhi syarat akan ditolak server."),t.length>a.warnIfMoreThan&&i.push(`PERINGATAN: jumlah besar, proses \xB1${r} detik. Jangan tutup halaman.`),i.push("Lanjutkan?"),!await v({title:`${e.aksi} ${t.length} data?`,message:i.join(`
`),variant:e.danger?"danger":"primary",okLabel:`Ya, ${e.aksi}`,cancelLabel:"Batal"}))return;f=!0,b.forEach(c=>h(c)),m();let s=[],l=0;for(let c=0;c<t.length;c+=1){let I=await le(e.endpoint,t[c]);I.ok?l+=1:s.push(I);let j=B()?.querySelector(".bv-label");j&&(j.textContent=`${e.nama} (${c+1}/${t.length}): `),c<t.length-1&&await new Promise(G=>setTimeout(G,a.delayMs))}f=!1,k(e.kind),y();let d=[`${e.aksi} selesai.`,`Berhasil: ${l} dari ${t.length}`];s.length>0&&(d.push("",`Gagal: ${s.length}`),s.slice(0,10).forEach(c=>d.push(`#${c.id} - ${c.pesan}`)),s.length>10&&d.push(`... dan ${s.length-10} lainnya`)),await v({title:"Hasil",message:d.join(`
`),okLabel:"Muat ulang tabel",hideCancel:!0}),window.location.reload()}function ue(){return new Promise(e=>{let t=Date.now(),n=()=>{if(b.some(i=>u(i))||Date.now()-t>a.readyTimeoutMs){e();return}setTimeout(n,a.readyPollMs)};n()})}var g=!1,w=[],T=new Map;function pe(){w.forEach(e=>e.disconnect()),w.length=0,T.clear()}function x(e){if(!g){g=!0;try{D(e),_(e),m()}finally{g=!1}}}function O(e){let t=e.querySelectorAll("tbody tr").length;return t===0||e.querySelectorAll("tbody td.bv-sel").length===t}function be(e,t){let n=new MutationObserver(()=>{if(g)return;let i=u(e);if(i){if(i!==t){E(e);return}O(i)||x(e)}});n.observe(t,{childList:!0,subtree:!0}),w.push(n);let r=t.parentElement;if(r){let i=new MutationObserver(()=>{let o=u(e);o&&o!==t&&E(e)});i.observe(r,{childList:!0}),w.push(i)}}function E(e){let t=u(e);if(t){if(D(e),T.get(e.sel)===t){x(e);return}T.set(e.sel,t),x(e),be(e,t)}}function fe(){setInterval(()=>{g||b.forEach(e=>{let t=T.get(e.sel),n=u(e);n&&(!t||!document.contains(t)||n!==t)?E(e):(n&&!O(n)||n&&!n.querySelector('thead th[data-ext-bv-header="1"]'))&&x(e)})},Math.max(1e3,a.readyPollMs*4))}function ge(){let e=window.jQuery;e&&b.forEach(t=>{let n=u(t);if(!(!n||n.dataset.extBvBound==="1")){n.dataset.extBvBound="1";try{e(t.sel).off("draw.dt.extBv").on("draw.dt.extBv",()=>{f||g||x(t)})}catch{}}})}function N(){try{ne(),ue().then(()=>{pe(),se(),y(),ge(),fe(),document.documentElement.setAttribute("data-ext-bulk-verif","1");let e=b.map(t=>{let n=u(t),r=n?n.querySelectorAll("tbody tr:not(.dataTables_empty)").length:0,i=n?n.querySelectorAll("tbody td.bv-sel").length:0,o=n?n.querySelectorAll("tbody td.bv-sel[data-ext-bv-unid]").length:0,s=n?!!n.querySelector('thead th[data-ext-bv-header="1"]'):!1;return`${t.sel}: kolom=${i}/${r}${o?` (${o} tanpa id)`:""} ${s?"header=ok":"header=BELUM"}`});console.log("[BulkVerif] Init complete -",e.join(" | "),a.UJI_SAJA?"(MODE UJI: checkbox nonaktif)":"")})}catch(e){console.error("[BulkVerif] Init error:",e)}}typeof P.featureModules<"u"&&(P.featureModules.mKlaimBulkVerif={id:"mKlaimBulkVerif",name:"Bulk Verif / Batal Verif",description:"Verifikasi atau batalkan verifikasi banyak klaim sekaligus",match:{regex:/^\/v2\/m-klaim\/?$/},run:N});return ee(xe);})();
