"use strict";var __morbis_feature=(()=>{var h=Object.defineProperty,C=Object.getOwnPropertyDescriptor,M=Object.getOwnPropertyNames,A=Object.prototype.hasOwnProperty,E=(t,e)=>{for(var a in e)h(t,a,{get:e[a],enumerable:!0})},q=(t,e,a,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let i of M(e))!A.call(t,i)&&i!==a&&h(t,i,{get:()=>e[i],enumerable:!(r=C(e,i))||r.enumerable});return t},H=t=>q(h({},"__esModule",{value:!0}),t),b={};E(b,{fitToSinglePage:()=>S,isRealContentText:()=>v,sectionHasContent:()=>w});function T(){return window}var g=new Set;function d(t,e){if(g.has(t)){let r=document.getElementById(t);if(r)return r}let a=document.createElement("style");return a.id=t,a.textContent=e,document.head.appendChild(a),g.add(t),a}d("ext-shared-animations",`
  @keyframes fadeSlideIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
`);var x=T(),y=96/25.4,j=194,B=281,k=Math.round(j*y),p=Math.round(B*y),z=p-6,$=.7,I=/^(-+|—+|-?|n\/?a|null|undefined|tbd|\?)$/i,W="input,button,select,textarea,label,script,style,hr,.panel-heading,.pdf-viewer,canvas,.watermark";function v(t){let e=(t??"").trim();return e.length>2&&!I.test(e)}function w(t){return!!((t.tableRows??[]).some(v)||(t.textWithoutUi??"").trim().length>30||(t.renderedFiles??0)>0&&(t.renderedSizePx??0)>0)}function S(t,e=p,a=$){if(!(t>0)||!(e>0))return{scale:1,boxHeightPx:0,fitsOnePage:!0};if(t<=e)return{scale:1,boxHeightPx:0,fitsOnePage:!0};let r=e/t,i=Math.max(a,Math.min(1,r)),o=t*i<=e+.5;return{scale:i,boxHeightPx:o?t*i:0,fitsOnePage:o}}var l="ext-print-doc",m="ext-print-doc-last",c="ext-print-fit",s="ext-print-empty",u="data-ext-print-box",n="ext-print-measuring";function _(){d("ext-print-measure",`html.${n},html.${n} body{
      width:${k}px!important;max-width:${k}px!important;background:#fff!important;}
    html.${n} .navbar,html.${n} .main-sidebar,
    html.${n} .sidebar,html.${n} .footer,
    html.${n} .breadcrumb,html.${n} .panel-heading,
    html.${n} hr,html.${n} input,
    html.${n} .pdf-viewer,html.${n} .watermark{
      display:none!important;}
    html.${n} .wrapper,html.${n} .container,
    html.${n} .container-fluid,html.${n} .row,
    html.${n} [class*=col-md],html.${n} [class*=col-sm],
    html.${n} .content,html.${n} .content-wrapper,
    html.${n} .panel,html.${n} .panel-body,
    html.${n} .box-body{
      margin:0!important;padding:0!important;width:100%!important;
      max-width:none!important;float:none!important;border:0!important;
      box-shadow:none!important;background:#fff!important;}
    html.${n} table{
      border-collapse:collapse!important;font-size:9pt!important;line-height:1.25!important;}
    html.${n} th,html.${n} td{
      padding:1.5px 3px!important;vertical-align:top!important;}
    html.${n} thead{display:table-header-group!important;}
    html.${n} h1,html.${n} h2,html.${n} h3,
    html.${n} h4,html.${n} h5{margin:0 0 2mm!important;}
    /* saat pengukuran, tiap dokumen diukur pada lebar penuh tanpa transform */
    html.${n} .${l}{height:auto!important;overflow:visible!important;}
    html.${n} .${c}{transform:none!important;width:auto!important;}
  `)}function F(){d("ext-print-sections",`@media print{
      @page{size:A4;margin:8mm;}
      html,body{background:#fff!important;width:auto!important;}
      /* section kosong (cuma tombol "Cetak X") tak pernah ikut cetak */
      .${s}{display:none!important;}
      /* satu dokumen = satu halaman, seperti berkas cetak manual */
      .${l}{page-break-after:always;break-after:page;}
      .${m}{page-break-after:auto;break-after:auto;}
      /* kotak halaman mengunci tinggi hasil penskalaan supaya tepat 1 lembar.
         Tinggi & skala dikirim lewat custom property dari JS, bukan inline
         style langsung: inline style berlaku juga di layar, sedangkan
         penskalaan hanya boleh berlaku saat print. */
      .${l}[${u}="1"]{
        height:var(--ext-print-box-h,auto)!important;
        overflow:hidden!important;
      }
      .${c}{
        transform:scale(var(--ext-print-scale,1));
        width:calc(100% / var(--ext-print-scale,1));
      }
      /* halaman file ter-render: satu file = satu lembar penuh */
      .${l}[data-ext-print-file]{page-break-after:always;break-after:page;
        page-break-inside:avoid;break-inside:avoid;}
      .${l}[data-ext-print-file][${m}]{page-break-after:auto;break-after:auto;}
      /* rapikan kerangka Bootstrap */
      .navbar,.navbar-default,.main-sidebar,.sidebar,.footer,.breadcrumb,
      .panel-heading,hr,input[type=checkbox],.no-print{display:none!important;}
      .wrapper,.container,.container-fluid,.row,[class*=col-md],[class*=col-sm],
      .content,.content-wrapper,.panel,.panel-body,.box-body{
        margin:0!important;padding:0!important;width:100%!important;
        max-width:none!important;float:none!important;border:0!important;
        box-shadow:none!important;background:#fff!important;}
      /* tabel rapat: padding kecil, header berulang, baris tak terpotong */
      table{border-collapse:collapse!important;font-size:9pt;line-height:1.25;}
      th,td{padding:1.5px 3px!important;vertical-align:top;}
      thead{display:table-header-group;}
      tfoot{display:table-footer-group;}
      tr,td,th{page-break-inside:avoid;break-inside:avoid;}
      h1,h2,h3,h4,h5{margin:0 0 2mm!important;page-break-after:avoid;break-after:avoid;}
      img{max-width:100%!important;height:auto!important;}
    }`)}function N(){return[...document.querySelectorAll("div.isidalam")].filter(t=>!t.classList.contains(l)&&!t.classList.contains(s))}function D(t){let e=[];for(let o of t.querySelectorAll("tr"))e.push((o.innerText??"").trim());let a=t.cloneNode(!0);a.querySelectorAll(W).forEach(o=>o.remove());let r=0,i=0;for(let o of t.querySelectorAll("canvas")){let L=o.clientWidth||o.width,O=o.clientHeight||o.height;L>20&&O>20&&(r++,i=Math.max(i,L*O))}return w({tableRows:e,textWithoutUi:(a.innerText??"").trim(),renderedFiles:r,renderedSizePx:i})}function R(t){let e=t.querySelector(`:scope > .${c}`);if(!e){for(e=document.createElement("div"),e.className=c;t.firstChild;)e.appendChild(t.firstChild);t.appendChild(e)}return e}function U(t){if(t.length===0)return;let e=document.documentElement;e.classList.add(n);try{for(let a of t){let r=R(a),i=r.scrollHeight,o=S(i,z);o.scale<1&&o.fitsOnePage?(a.style.setProperty("--ext-print-box-h",`${Math.round(o.boxHeightPx)}px`),r.style.setProperty("--ext-print-scale",o.scale.toFixed(4)),a.setAttribute(u,"1")):(a.removeAttribute(u),a.style.removeProperty("--ext-print-box-h"),r.style.removeProperty("--ext-print-scale")),o.scale<1&&!o.fitsOnePage&&console.info(`[PrintSections] "${a.id}": butuh skala ${o.scale.toFixed(2)} < batas ${$} -> dicetak natural (${Math.ceil(i/p)} halaman) demi keterbacaan`)}}finally{e.classList.remove(n)}}function Y(t){let e=[...t.querySelectorAll("canvas")].filter(a=>(a.clientWidth||a.width)>20&&(a.clientHeight||a.height)>20);if(e.length===0)return!1;for(let a of e){let r=document.createElement("div");r.className=l,r.setAttribute("data-ext-print-file",t.id||"file"),a.style.maxHeight=`${p}px`,a.style.width="auto",a.style.maxWidth="100%",r.appendChild(a),t.parentElement?.insertBefore(r,t)}return t.classList.add(s),!0}function P(){let t=N(),e=[];for(let r of t)if(!r.classList.contains(s)){if(!D(r)){r.classList.add(s);continue}r.classList.remove(s),!Y(r)&&(r.classList.remove("no-print"),r.classList.add(l),e.push(r))}let a=[...document.querySelectorAll(`.${l}`)];for(let r of a)r.classList.remove(m);a[a.length-1]?.classList.add(m);for(let r of e){let i=document.querySelector(`input[type=checkbox][onclick*="${CSS.escape(r.id||"")}"]`);i&&(i.checked=!0,i.disabled=!1)}for(let r of t)if(r.classList.contains(s)){let i=document.querySelector(`input[type=checkbox][onclick*="${CSS.escape(r.id||"")}"]`);i&&(i.checked=!1,i.disabled=!0)}U(e)}function f(){document.getElementById("ext-print-sections")===null&&F(),document.getElementById("ext-print-measure")===null&&_(),d("ext-print-sections-ui",`.${s} > .panel-heading{opacity:.45;}
     input[type=checkbox][disabled]{cursor:not-allowed;}`),window.addEventListener("beforeprint",()=>{try{P()}catch(a){console.error("[PrintSections] gagal applied:",a)}},{passive:!0});let t=()=>{try{P()}catch(a){console.error("[PrintSections] gagal applied:",a)}};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",t,{once:!0}):t();let e=0;new MutationObserver(()=>{window.clearTimeout(e),e=window.setTimeout(t,800)}).observe(document.body,{childList:!0,subtree:!0})}return typeof x.featureModules<"u"&&(x.featureModules.printSections={id:"printSections",name:"Cetak Otomatis Berkas (M-KLAIM)",description:"Cetak hanya berkas yang ada isinya, tiap dokumen pas 1 lembar A4 (tanpa perlu centang checkbox)",match:{oneOf:[{prefix:"/v2/m-klaim/detail"}]},run:f}),(window.location?.pathname??"").includes("/v2/m-klaim/detail")&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",f):f()),H(b)})();
