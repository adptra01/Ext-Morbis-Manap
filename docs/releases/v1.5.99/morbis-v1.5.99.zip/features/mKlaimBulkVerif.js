"use strict";var __morbis_feature=(()=>{var k=Object.defineProperty;var V=Object.getOwnPropertyDescriptor;var _=Object.getOwnPropertyNames;var J=Object.prototype.hasOwnProperty;var N=(e,t)=>{for(var n in t)k(e,n,{get:t[n],enumerable:!0})},D=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let i of _(t))!J.call(e,i)&&i!==n&&k(e,i,{get:()=>t[i],enumerable:!(o=V(t,i))||o.enumerable});return e};var G=e=>D(k({},"__esModule",{value:!0}),e);var ae={};N(ae,{applySelectAll:()=>j,clearSelection:()=>m,getSelected:()=>A,initMKlaimBulkVerifFeature:()=>K,isEligible:()=>P,parseIdVisit:()=>O,pruneSelection:()=>H});function M(){return window}var I="ext-batch-shared-style";function y(){if(document.getElementById(I))return;let e=document.createElement("style");e.id=I,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function B(e,t,n=2){let o=i=>fetch(e,t).catch(r=>{if(i<=0)throw r;return new Promise(s=>setTimeout(s,1e3*(3-i))).then(()=>o(i-1))});return o(n)}function x(e){return new Promise(t=>{y();let n=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",o=document.createElement("div");o.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",o.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${n}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,o.querySelector("h3").textContent=e.title;let i=o.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((d,c)=>{c>0&&i.appendChild(document.createElement("br")),i.appendChild(document.createTextNode(d))});let r=d=>{o.remove(),document.removeEventListener("keydown",s),t(d)},s=d=>{d.key==="Escape"&&r(!1)};o.querySelector(".ext-modal-close").addEventListener("click",()=>r(!1)),o.addEventListener("click",d=>{d.target===o&&r(!1)}),o.querySelector("[data-ext-ok]").addEventListener("click",()=>r(!0));let l=o.querySelector("[data-ext-cancel]");l&&l.addEventListener("click",()=>r(!1)),document.addEventListener("keydown",s),document.body.appendChild(o)})}var $=M(),a={endpointVerif:"/v2/m-klaim/control/verif",endpointBatal:"/v2/m-klaim/control/batal-verif",delayMs:600,barId:"ext-bulk-verif-bar",cssId:"ext-bulk-verif-style",readyTimeoutMs:15e3,readyPollMs:250,warnIfMoreThan:100,UJI_SAJA:!0},b=[{sel:"#data-table",kind:"main",nama:"Klaim",aksi:"Verif",endpoint:a.endpointVerif,danger:!1},{sel:"#data-table-verif",kind:"verif",nama:"Sudah Terverifikasi",aksi:"Batal Verif",endpoint:a.endpointBatal,danger:!0}],u={main:new Set,verif:new Set},f=!1;function j(e,t,n){let o=0;return t.forEach(i=>{!i.id||!i.eligible||(n?u[e].add(i.id):u[e].delete(i.id),o+=1)}),o}function H(e,t){let n=new Set;t.forEach(i=>{i.id&&i.eligible&&n.add(i.id)});let o=0;return Array.from(u[e]).forEach(i=>{n.has(i)||(u[e].delete(i),o+=1)}),o}function A(e){return Array.from(u[e])}function m(e){u[e].clear()}function O(e){let t=e.match(/\d+/);return t?t[0]:null}function P(e,t,n){return t?e==="main"?!0:n:!1}function W(){if(document.getElementById(a.cssId))return;let e=document.createElement("style");e.id=a.cssId,e.textContent=`
    #${a.barId} {
      position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
      z-index: 2147482000; display: none; align-items: center; gap: 14px;
      background: #0f172a; color: #f8fafc; border-radius: 12px;
      padding: 10px 16px; font-family: 'Inter', system-ui, sans-serif;
      font-size: 13px; box-shadow: 0 8px 28px rgba(15,23,42,.35);
    }
    #${a.barId} .bv-item { display: flex; align-items: center; gap: 8px; }
    #${a.barId} .bv-label { color: #cbd5e1; }
    #${a.barId} .bv-count { color: #f8fafc; font-weight: 700; }
    #${a.barId} button {
      border: none; border-radius: 8px; cursor: pointer; padding: 7px 14px;
      font-size: 12.5px; font-weight: 700; font-family: inherit;
    }
    #${a.barId} .bv-aksi { background: #2563eb; color: #fff; }
    #${a.barId} .bv-aksi:hover { background: #1d4ed8; }
    #${a.barId} .bv-aksi-danger { background: #dc2626; color: #fff; }
    #${a.barId} .bv-aksi-danger:hover { background: #b91c1c; }
    #${a.barId} .bv-reset { background: #334155; color: #e2e8f0; }
    #${a.barId} .bv-reset:hover { background: #475569; }
    #${a.barId} button:disabled { opacity: .55; cursor: not-allowed; }

    .bv-check {
      display: inline-flex; align-items: center; justify-content: center;
      margin-right: 6px; vertical-align: middle; cursor: pointer;
    }
    .bv-check input { width: 14px; height: 14px; cursor: pointer; margin: 0; }
    .bv-check input:disabled { cursor: not-allowed; }
    th.bv-th-head { width: 26px; }
    /* Kolom khusus checkbox - sel tersendiri di awal baris. Header native
       TIDAK disentuh supaya indeks sorting bawaan tidak bergeser. */
    td.bv-sel {
      width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
    }
    td.bv-sel input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    td.bv-sel input:disabled { cursor: not-allowed; }
    /* Penanda fitur aktif - memudahkan diagnosis di console */
    html[data-ext-bulk-verif='1'] td.bv-sel { background: #eff6ff; }
  `,document.head.appendChild(e),y()}function p(e){return document.querySelector(e.sel)}function z(e){let t=window.jQuery;if(!t)return null;try{return t(e.sel).DataTable()??null}catch{return null}}function R(e){return(Array.isArray(e)?e:[e]).filter(t=>t instanceof HTMLElement)}function w(e){let t=e.querySelector('[onclick*="detail("]');if(t){let o=(t.getAttribute("onclick")||"").match(/\d+/);if(o)return o[0]}let n=e.querySelector('[onclick*="BatalVerif("]');if(n){let o=(n.getAttribute("onclick")||"").match(/\d+/);if(o)return o[0]}return null}function T(e,t){return P(e.kind,!!t.querySelector('button[onclick*="detail("]'),!!t.querySelector('button[onclick*="BatalVerif("]'))}function q(e,t){return{id:w(t),eligible:T(e,t)}}function F(e){let t=p(e);if(!t)return[];let n=z(e);if(n)try{return R(n.rows({search:"applied"}).nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(o=>!o.classList.contains("dataTables_empty"))}function Q(e){let t=p(e);if(!t)return[];let n=z(e);if(n)try{return R(n.rows().nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(o=>!o.classList.contains("dataTables_empty"))}function X(e,t){let n=w(t);if(!n){let s=document.createElement("td");s.className="bv-sel",s.dataset.extBvUnid="1";let l=document.createElement("input");l.type="checkbox",l.disabled=!0,l.title="id_visit tidak terbaca dari markup baris ini",s.appendChild(l),t.insertBefore(s,t.firstChild);return}let o=T(e,t),i=document.createElement("td");i.className="bv-sel";let r=document.createElement("input");r.type="checkbox",r.dataset.extBvId=n,r.checked=u[e.kind].has(n),a.UJI_SAJA?(r.disabled=!0,r.title="Mode uji - belum bisa dipilih"):(r.disabled=!o,r.title=o?"Pilih baris ini":"Baris tidak memenuhi syarat aksi ini",r.addEventListener("change",()=>{r.checked?u[e.kind].add(n):u[e.kind].delete(n),g(),v(e)})),i.appendChild(r),t.insertBefore(i,t.firstChild)}function Y(e){e.querySelectorAll("tbody td.bv-sel").forEach(t=>t.remove())}function E(e){let t=p(e);t&&(Y(t),t.querySelectorAll("tbody tr").forEach(n=>X(e,n)),v(e))}function v(e){let n=p(e)?.querySelector("thead input[data-ext-bv-header]");if(!n)return;let o=F(e).filter(s=>T(e,s)),i=o.length,r=o.filter(s=>{let l=w(s);return!!l&&u[e.kind].has(l)}).length;n.disabled=a.UJI_SAJA||f||i===0,n.checked=i>0&&r===i,n.indeterminate=r>0&&r<i}function Z(e){let n=p(e)?.querySelector("thead th");if(!n)return;if(n.dataset.extBvHeader==="1"){v(e);return}n.classList.add("bv-th-head");let o=document.createElement("span");o.className="bv-check",o.title="Pilih / batal pilih semua baris yang cocok dengan pencarian";let i=document.createElement("input");if(i.type="checkbox",i.dataset.extBvHeader="1",a.UJI_SAJA){i.disabled=!0,i.title="Mode uji - belum bisa dipilih",o.appendChild(i),n.insertBefore(o,n.firstChild),n.dataset.extBvHeader="1";return}i.addEventListener("change",()=>{let r=F(e).map(s=>q(e,s));j(e.kind,r,i.checked),E(e),g()}),o.appendChild(i),n.insertBefore(o,n.firstChild),n.dataset.extBvHeader="1"}function h(){b.forEach(e=>{p(e)&&(Z(e),E(e))}),g()}function S(){return document.getElementById(a.barId)}function g(){let e=S();if(!e)return;let t=b.map(o=>[o,u[o.kind].size]).filter(([,o])=>o>0);if(a.UJI_SAJA||t.length===0||f){e.style.display="none";return}e.innerHTML="",t.forEach(([o,i])=>{let r=document.createElement("div");r.className="bv-item";let s=document.createElement("span");s.className="bv-label",s.textContent=`${o.nama}: `;let l=document.createElement("span");l.className="bv-count",l.textContent=`${i} dipilih`;let d=document.createElement("button");d.className=o.danger?"bv-aksi bv-aksi-danger":"bv-aksi",d.textContent=o.aksi,d.addEventListener("click",()=>{oe(o)}),r.append(s,l,d),e.appendChild(r)});let n=document.createElement("button");n.className="bv-reset",n.textContent="Batal Pilih",n.addEventListener("click",()=>{b.forEach(o=>m(o.kind)),h()}),e.appendChild(n),e.style.display="flex"}function ee(){if(S())return;let e=document.createElement("div");e.id=a.barId,e.style.display="none",document.body.appendChild(e)}async function te(e,t){try{let n=new URLSearchParams({id_visit:t}),o=await B(e,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:n.toString(),credentials:"same-origin"});if(!o.ok)return{id:t,ok:!1,pesan:`HTTP ${o.status}`};let i=await o.json(),r=String(i.kode)==="200";return{id:t,ok:r,pesan:i.message??(r?"Sukses":"Gagal")}}catch(n){return{id:t,ok:!1,pesan:n.message||"Gagal koneksi"}}}function ne(e){let t=Q(e).map(o=>q(e,o)),n=H(e.kind,t);return{valid:A(e.kind),gugur:n}}async function oe(e){if(f)return;let{valid:t,gugur:n}=ne(e);if(t.length===0){m(e.kind),h(),await x({title:"Tidak ada baris yang bisa diproses",message:"Pilihan tidak lagi cocok dengan data di tabel. Silakan pilih ulang.",okLabel:"Mengerti",hideCancel:!0});return}let o=Math.ceil(t.length*a.delayMs/1e3),i=[`${e.nama}: ${t.length} baris akan diproses.`];if(n>0&&i.push(`${n} pilihan diabaikan (data berubah/tidak memenuhi syarat).`),i.push(e.danger?"Verifikasi yang dibatalkan kembali ke daftar belum terverifikasi.":"Data yang tidak memenuhi syarat akan ditolak server."),t.length>a.warnIfMoreThan&&i.push(`PERINGATAN: jumlah besar, proses \xB1${o} detik. Jangan tutup halaman.`),i.push("Lanjutkan?"),!await x({title:`${e.aksi} ${t.length} data?`,message:i.join(`
`),variant:e.danger?"danger":"primary",okLabel:`Ya, ${e.aksi}`,cancelLabel:"Batal"}))return;f=!0,b.forEach(c=>v(c)),g();let s=[],l=0;for(let c=0;c<t.length;c+=1){let L=await te(e.endpoint,t[c]);L.ok?l+=1:s.push(L);let C=S()?.querySelector(".bv-label");C&&(C.textContent=`${e.nama} (${c+1}/${t.length}): `),c<t.length-1&&await new Promise(U=>setTimeout(U,a.delayMs))}f=!1,m(e.kind),h();let d=[`${e.aksi} selesai.`,`Berhasil: ${l} dari ${t.length}`];s.length>0&&(d.push("",`Gagal: ${s.length}`),s.slice(0,10).forEach(c=>d.push(`#${c.id} - ${c.pesan}`)),s.length>10&&d.push(`... dan ${s.length-10} lainnya`)),await x({title:"Hasil",message:d.join(`
`),okLabel:"Muat ulang tabel",hideCancel:!0}),window.location.reload()}function ie(){return new Promise(e=>{let t=Date.now(),n=()=>{if(b.some(i=>p(i))||Date.now()-t>a.readyTimeoutMs){e();return}setTimeout(n,a.readyPollMs)};n()})}function re(){let e=window.jQuery;e&&b.forEach(t=>{if(p(t))try{e(t.sel).off("draw.dt.extBv").on("draw.dt.extBv",()=>{f||(E(t),g())})}catch{}})}function K(){try{W(),ie().then(()=>{ee(),h(),re(),document.documentElement.setAttribute("data-ext-bulk-verif","1");let e=b.map(t=>{let n=p(t),o=n?n.querySelectorAll("tbody tr:not(.dataTables_empty)").length:0,i=n?n.querySelectorAll("tbody td.bv-sel").length:0,r=n?n.querySelectorAll("tbody td.bv-sel[data-ext-bv-unid]").length:0;return`${t.sel}: kolom=${i}/${o}${r?` (${r} tanpa id)`:""}`});console.log("[BulkVerif] Init complete -",e.join(" | "),a.UJI_SAJA?"(MODE UJI: checkbox nonaktif)":"")})}catch(e){console.error("[BulkVerif] Init error:",e)}}typeof $.featureModules<"u"&&($.featureModules.mKlaimBulkVerif={id:"mKlaimBulkVerif",name:"Bulk Verif / Batal Verif",description:"Verifikasi atau batalkan verifikasi banyak klaim sekaligus",match:{regex:/^\/v2\/m-klaim\/?$/},run:K});return G(ae);})();
