"use strict";var __morbis_feature=(()=>{var J="extensionConfig";function kt(p,a,f){let h=a?.features?.[p];if(!h)return!0;if(h.enabled===!1)return!1;let x=f??a?.currentRole??"admin";if(x==="admin")return!0;let w=h.allowedRoles;return!Array.isArray(w)||w.length===0?!0:w.includes(x)}async function vt(p){try{let a=(await chrome.storage.sync.get(J))?.[J]??null;return kt(p,a)}catch{return!0}}function wt(p,a){vt(p).then(f=>{if(f)try{a()}catch(h){console.error(`[featureGate:${p}] gagal jalan:`,h)}})}var Q="ext-free-text-noop",jt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function At(p){try{let a=p.toUpper;if(typeof a=="function"&&a[Q]===!0)return!0;let f=function(h){return h?.value??""};f[Q]=!0;try{Object.defineProperty(p,"toUpper",{value:f,writable:!0,configurable:!0})}catch{p.toUpper=f}return!0}catch{return!1}}var $="ext-pa-typo",St=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],L={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},X=4,Z=24,Et=.5,Ct=2.5;function Y(p,a,f,h){let x=typeof p=="number"?p:Number(p);return Number.isFinite(x)?Math.min(h,Math.max(f,x)):a}function z(p,a){let f=p??{};return{fs:Y(f.fs,a.fs,X,Z),lh:Y(f.lh,a.lh,Et,Ct)}}function F(p){let a=p??{};return{kop:z(a.kop,L.kop),pasien:z(a.pasien,L.pasien),judul:z(a.judul,L.judul),isi:z(a.isi,L.isi),kesimpulan:z(a.kesimpulan,L.kesimpulan),ttd:z(a.ttd,L.ttd)}}function K(){return F(null)}function tt(p){try{if(!p)return K();let a=p.getItem($);return a?F(JSON.parse(a)):K()}catch{return K()}}function Lt(p,a){try{return p?(p.setItem($,JSON.stringify(F(a))),!0):!1}catch{return!1}}function zt(p){try{p?.removeItem($)}catch{}}function et(p){let a=F(p),f=h=>Math.min(Z,Math.max(X,h));return{...a,alamatFs:f(a.kop.fs-8.5),judulLapFs:f(a.kop.fs-4)}}var b=p=>String(Math.round(p*100)/100);function Tt(p){let a=et(p);return{"--pa-kop-fs":`${b(a.kop.fs)}pt`,"--pa-kop-lh":b(a.kop.lh),"--pa-alamat-fs":`${b(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(a.judulLapFs)}pt`,"--pa-pasien-fs":`${b(a.pasien.fs)}pt`,"--pa-pasien-lh":b(a.pasien.lh),"--pa-judul-fs":`${b(a.judul.fs)}pt`,"--pa-judul-lh":b(a.judul.lh),"--pa-isi-fs":`${b(a.isi.fs)}pt`,"--pa-isi-lh":b(a.isi.lh),"--pa-kesimpulan-fs":`${b(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(a.kesimpulan.lh),"--pa-ttd-fs":`${b(a.ttd.fs)}pt`,"--pa-ttd-lh":b(a.ttd.lh)}}function It(p,a){if(p)try{for(let[f,h]of Object.entries(Tt(a)))p.setProperty(f,h)}catch{}}var Rt=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function at(p){let a=p??"",f=a.match(Rt);if(!f)return null;let h=a.slice(f[0].length).trim();return h===""?null:[f[1],h]}wt("paLabPrint",function(){"use strict";function p(){try{At(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let x=document.createElement("style");x.id="ext-free-text-style",x.textContent=jt,document.head.appendChild(x)}}catch{}}if(p(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",p),window.setInterval(p,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let x="ext-pa-print-proc";if(document.documentElement.getAttribute(x))return;document.documentElement.setAttribute(x,"1");let w=()=>{try{return window.localStorage??null}catch{return null}},j=tt(w()),_=()=>{try{It(document.documentElement.style,j)}catch{}};_();let v=t=>M(t?.textContent||"");function it(t){return t.replace(/<[^>]+>/g," ")}function qt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function M(t){return qt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let nt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",U=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>v(t)).filter(Boolean);for(;U.length<3;)U.push("");let q=[],rt=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(rt){let t=document.createElement("div");t.innerHTML=rt.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),q=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let D=q.join(" "),ot=t=>{let e=D.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},lt=ot("telp"),st=ot("fax"),H=(D.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],B=(D.match(/https?:\/\/[^\s;,]+/)||[""])[0],S=D.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");H&&(S=S.split(H).join("")),B&&(S=S.split(B).join("")),S=S.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Pt=["Alamat: "+S,lt?"Telp: "+lt:"",st?"Fax: "+st:""].filter(Boolean).join(", "),Ft=[H?"Email: "+H:"",B?"Website: "+B:""].filter(Boolean).join(", ");q=[Pt,Ft].filter(Boolean);let G=v(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",N=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let n=v(e[0]),r=v(e[2]),l=v(e[3]),s=v(e[5]);n&&N.push([n,r]),l&&N.push([l,s])}});let T=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],k=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),A=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",n=!1,r=t.querySelector(".section-title");if(r)e=v(r),n=!0;else{let c=m=>m.split(":")[0].trim();for(let m of Array.from(t.children).slice(0,3)){let g=v(m);if(g&&g.length<=24&&T.includes(k(c(g)))){e=c(g);break}}if(!e){let m=(t.textContent||"").split(`
`).map(g=>g.trim()).find(Boolean)||"";m&&T.includes(k(c(m)))&&(e=c(m))}if(!e)return}let l=document.createElement("div");l.innerHTML=t.innerHTML,l.querySelector(".section-title")?.remove();let s=l.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(c=>c.split(/<br\s*\/?>|\n/).map(m=>M(m.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(c=>c.length),u=[],i=[];s.forEach((c,m)=>{c.forEach((g,y)=>{m>0&&y===0&&u.length&&i.push(u.length),u.push(g)})});let o=u;if(!n&&o.length&&k(o[0])===k(e)){o.shift();for(let c=0;c<i.length;c++)i[c]-=1;for(;i.length&&i[0]<=0;)i.shift()}o.length>1&&!/^[IVXLC]+\.\s/.test(o[0])&&o.slice(1).some(c=>/^II\.\s/.test(c))&&(o[0]="I. "+o[0]),e&&A.push({title:e,items:o,para:i})});let Mt=/^catatan\s*:?/i,Ut=/^icd[\s-]*o\b\s*:?/i,V=[];for(let t of A){let e=[{title:t.title,items:[],para:[]}],n=e[0],r=!1,l=(s,u)=>{n={title:s,items:[],para:[],bare:u},e.push(n),r=!0};if(t.items.forEach((s,u)=>{let i=s.match(Mt),o=i?null:s.match(Ut);if(i){k(n.title)!=="catatan"&&l("Catatan");let c=s.slice(i[0].length).trim();c&&(t.para.includes(u)&&n.para.push(n.items.length),n.items.push(c));return}if(o){k(n.title)!=="icdo"&&l("ICD-0",!0),t.para.includes(u)&&n.para.push(n.items.length),n.items.push(s);return}t.para.includes(u)&&n.para.push(n.items.length),n.items.push(s)}),r)for(let s of e)s.items.length&&V.push(s);else V.push(e[0])}A.length=0,A.push(...V),A.forEach((t,e)=>t._i=e),A.sort((t,e)=>{let n=t._i??0,r=e._i??0,l=T.indexOf(k(t.title)),s=T.indexOf(k(e.title)),u=l===-1?T.length:l,i=s===-1?T.length:s;return u!==i?u-i:n-r});function Dt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let n=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),r=t.getAttribute("placeholder")||"",l=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(n+" "+r+" "+l).slice(0,300)}}function Ht(t,e,n){let r=e.toLowerCase().split(/[^a-z0-9]+/).filter(i=>i.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(i));if(!r.length)return"";let l=r.sort((i,o)=>o.length-i.length)[0],s="",u=-1;return t.querySelectorAll("input, textarea, select").forEach(i=>{let{val:o,ctx:c}=Dt(i);if(!o||o===e||!o.toLowerCase().includes(l))return;let m=n.test(c)?2:0;m>u&&(u=m,s=o)}),s}function Bt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Nt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let n=i=>/ket\w*\s*klinis/i.test(i),r=i=>/^dokter/i.test(i)||/^rs\b/i.test(i),l=t.map(([i,o],c)=>({label:i,value:o,idx:c})).filter(i=>r(i.label)?!!i.value:n(i.label));if(!l.length)return;let s=new AbortController,u=window.setTimeout(()=>s.abort(),6e3);try{let i=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),o=await fetch(i.toString(),{credentials:"same-origin",signal:s.signal});if(!o.ok){window.console.info("[paPrint] override: fetch input status "+o.status);return}let c=await o.text(),m=new DOMParser().parseFromString(c,"text/html");window.console.info('[paPrint] override: input title="'+(m.title||"").slice(0,60)+'" len='+c.length+" fields="+m.querySelectorAll("input, textarea, select").length);for(let g of l){if(n(g.label)){let W=Bt(m,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),C=M(it(W));window.console.info("[paPrint] override: "+g.label+' cetak="'+g.value+'" input="'+C+'"'),C&&C!==g.value&&(t[g.idx][1]=C);continue}let y=/^dokter/i.test(g.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,E=Ht(m,g.value,y),R=M(it(E||""));window.console.info("[paPrint] override: "+g.label+' cetak="'+g.value+'" input="'+R+'"'),R&&R!==g.value&&(t[g.idx][1]=R)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(u)}}await Nt(N).catch(()=>{});let I=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>v(t)).filter(Boolean),pt=I[0]||"",dt=I[1]||"",O=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",ct=I.find(t=>/^\(.*\)$/.test(t))||I[2]||"",ut=I.find(t=>/^nip\.?/i.test(t))||I[3]||"",mt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Ot=Array.from(document.body.querySelectorAll("script")),$t=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),P=N.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let n=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,r=n.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||n,l=r.split(/\s+-\s*/);if(l.length>=3&&/rawat\s+inap/i.test(l[1])){let s=$t(l[1].trim()),u=l.slice(2).join(" - ").trim(),i=u?s+" - "+u:s;if(i)return[t,i]}return[t,r]}),Kt=P.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),ft=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),gt=t=>/^catatan/i.test(t.trim()),ht=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),_t=P.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function bt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(n=>{if(!n.ok)throw new Error("img "+n.status);return n.blob()}).then(n=>new Promise((r,l)=>{let s=new FileReader;s.onload=()=>r(String(s.result)),s.onerror=()=>l(s.error),s.readAsDataURL(n)})).catch(()=>e)}async function Gt(){let t=et(j),[e,n]=await Promise.all([bt(nt),O?bt(O):Promise.resolve("")]),r="";for(let o=0;o<P.length;o+=2){let c=P[o],m=P[o+1];r+="<tr><td>"+d(c[0])+"</td><td>:</td><td>"+d(c[1])+"</td>"+(m?"<td>"+d(m[0])+"</td><td>:</td><td>"+d(m[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let l="";for(let o of A){if(gt(o.title)){let y=o.items.length?o.items:["Tidak ada"];l+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.judul.fs+'pt"><b><u>CATATAN:</u></b></td><td>'+y.map(E=>"- "+d(ht(E)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(o.bare){o.items.forEach((y,E)=>{l+='<p style="margin:'+(E===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.judul.fs+'pt;"><b>'+d(y.toUpperCase())+"</b></p>"});continue}l+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b><u>'+d(o.title.toUpperCase())+"</u></b></p>";let c=k(o.title)==="kesimpulan",m=c?t.kesimpulan.fs:t.isi.fs,g=c?t.kesimpulan.lh:t.isi.lh;o.items.forEach((y,E)=>{let R=c?"<b>"+d(y)+"</b>":ft(y),W=at(y),C=(m*1.8).toFixed(1),Wt="margin-left:"+C+"pt;"+(W?"text-indent:-"+C+"pt;":"");l+='<p style="margin:'+(o.para.includes(E)?"14pt":"0")+" 0 6pt 0;font-size:"+m+"pt;line-height:"+g+";text-align:justify;"+Wt+'">'+R+"</p>"})}let s='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(G)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+U.slice(0,3).map(o=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(o)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+q.map(o=>d(o)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(G.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+r+"</table>"+l+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(pt)+'</p><p style="margin:0 0 6pt 0;">'+d(dt)+"</p>"+(n?'<p style="margin:0 0 6pt 0;"><img src="'+n+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(ct)+'</b></p><p style="margin:0 0 6pt 0;">'+d(ut)+"</p></td></tr></table></body></html>",u=new Blob(["\uFEFF"+s],{type:"application/msword"}),i=document.createElement("a");i.href=URL.createObjectURL(u),i.download="Hasil-PA-"+_t+".doc",document.body.appendChild(i),i.click(),window.setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},4e3)}let Vt=A.map(t=>{if(gt(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(r=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+d(ht(r)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=k(t.title)==="kesimpulan",n='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+'">'+t.items.map((r,l)=>{let s=t.para.includes(l)?" item-para":"",u=at(r)?" has-marker":"";return'<div class="item-list'+s+u+'">'+(e?"<strong>"+d(r)+"</strong>":ft(r))+"</div>"}).join("")+"</div>";return t.bare?n:'<div class="section-judul">'+d(t.title)+"</div>"+n}).join("");document.body.innerHTML='<a href="'+d(mt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(nt)+'" alt="Logo"></div><div class="kop-text">'+U.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+q.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(G)+'</div><div class="patient-info-container">'+Kt+'</div><div class="hasil-pa">'+Vt+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(pt)+"</p><p>"+d(dt)+"</p>"+(O?'<img src="'+d(O)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(ct)+'</p><p style="margin-top: 2px;">'+d(ut)+"</p></div></div></div>",Ot.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),Gt().catch(()=>{window.location.href=mt})});let xt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(r,l,s,u,i,o,c,m)=>"<label>"+d(s)+'<input type="range" data-g="'+d(r)+'" data-f="'+l+'" min="'+u+'" max="'+i+'" step="'+o+'" value="'+c+'"><output data-o="'+d(r+"-"+l)+'">'+d(String(c)+m)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+St.map(r=>'<div class="t-typo-group"><strong>'+d(r.label)+'</strong><div class="t-typo-row">'+e(r.key,"fs","Font (pt)",4,20,.5,j[r.key].fs,"pt")+e(r.key,"lh","Spasi baris",.5,2.5,.05,j[r.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(r=>{let l=r;l.addEventListener("input",()=>{let s=l.dataset.g,u=l.dataset.f;if(!s||!u||!j[s])return;j[s][u]=Number(l.value),_();let i=t.querySelector(`output[data-o="${s}-${u}"]`);i&&(i.textContent=l.value+(u==="fs"?"pt":""))})});let n=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let r=Lt(w(),j);n&&(n.textContent=r?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(zt(w()),j=tt(w()),_(),xt(),n){let r=t.querySelector("[data-note]");r&&(r.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&xt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let yt="ext-pa-print-style";if(!document.getElementById(yt)){let t=document.createElement("style");t.id=yt,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        /* Gutter marker di CONTAINER (.section-isi), bukan di item:
           semua teks (polos maupun lanjutan) mulai di kolom yang sama;
           hanya baris pertama item ber-marker yang ditarik ke gutter.
           Tanpa ini, baris lanjutan selalu tergeser ke kanan dibanding
           item polos. */
        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            padding-left: 1.8em;
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Item ber-marker: hanya baris pertama (marker) yang ditarik
           ke gutter; teks + baris lanjutan tetap di kolom container. */
        .item-list.has-marker {
            text-indent: -1.8em;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-judul-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let f=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),a().catch(()=>{})):Date.now()-f>5e3&&window.clearInterval(h)},200)})})();
