"use strict";var __morbis_feature=(()=>{function f(){return window}var s="RSUD H. Abdul Manap",p=f(),g=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],d=r=>document.getElementById(r)?.value?.trim()||"";function b(r){let t=e=>{let i=document.createElement("span");return i.className="fv",i.textContent=e,i};r.querySelectorAll("input").forEach(e=>{let i=(e.type||"text").toLowerCase();if(i==="hidden"){e.remove();return}if(i==="radio"||i==="checkbox"){if(!e.checked){e.remove();return}if(i==="radio"){e.replaceWith(t("\u2713"));return}let a=(e.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,n=>n.toUpperCase());e.replaceWith(t(a?"\u2713 "+a:"\u2713"));return}let o=(e.value||"").trim();o?e.replaceWith(t(o)):e.remove()}),r.querySelectorAll("textarea").forEach(e=>{let i=(e.value||"").trim();i?e.replaceWith(t(i)):e.remove()}),r.querySelectorAll("select").forEach(e=>{let i=(e.options[e.selectedIndex]?.textContent||e.value||"").trim();i?e.replaceWith(t(i)):e.remove()})}function m(r){let t=r.cloneNode(!0),e=Array.from(r.querySelectorAll("canvas")),i=Array.from(t.querySelectorAll("canvas"));return e.forEach((o,a)=>{let n=i[a];if(n)try{let l=document.createElement("img");l.src=o.toDataURL("image/png"),l.style.cssText="max-width:100%;height:auto;",n.replaceWith(l)}catch{let l=document.createElement("div");l.className="fv",l.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",n.replaceWith(l)}}),b(t),g.forEach(o=>t.querySelectorAll(o).forEach(a=>a.remove())),t.querySelectorAll("tr").forEach(o=>{let a=Array.from(o.cells);for(let n=a.length-1;n>=0;n--){let l=a[n];if(!(!(l.textContent||"").trim()&&!l.querySelector("img,table,input")))break;l.remove()}}),t.querySelectorAll("[style]").forEach(o=>{let a=((o.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");a?o.setAttribute("style",a):o.removeAttribute("style")}),t.removeAttribute("id"),t.removeAttribute("class"),t.removeAttribute("style"),t.querySelectorAll("div").forEach(o=>{!o.children.length&&!(o.textContent||"").trim()&&o.remove()}),t.innerHTML.trim()}function h(r,t){let e=(r.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return e=e.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),e||`Berkas ${String(t+1).padStart(2,"0")}`}function x(){let r=Array.from(document.querySelectorAll(".isidalam")),t=new Set,e=[];if(r.forEach((i,o)=>{let a=m(i);if(a.length<20)return;let n=h(i,o);t.has(n)||(t.add(n),e.push({title:n,html:a}))}),!e.length){let i=document.querySelector("#section-to-print");i&&e.push({title:"Detail Klaim",html:m(i)})}return e}var c=r=>r.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]);function v(r){let t="/assets/images/logo/Kota Jambi.png",e=(a,n)=>`<div class="meta-item"><span class="meta-label">${c(a)}</span><span class="meta-value">${c(n||"\u2014")}</span></div>`,i=r.map((a,n)=>`<span class="toc-chip"><b>${String(n+1).padStart(2,"0")}</b> ${c(a.title)}</span>`).join(""),o=r.map((a,n)=>`
      <section class="doc">
        <div class="doc-head">
          <span class="doc-num">${String(n+1).padStart(2,"0")}</span>
          <h2>${c(a.title)}</h2>
          <span class="doc-rule"></span>
        </div>
        <div class="doc-body">${a.html}</div>
      </section>`).join("");return`<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<base href="${c(location.origin)}">
<title>Dossier Cetak M-KLAIM \u2014 ${c(s)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,500;8..60,700&display=swap" rel="stylesheet">
<style>
:root{
  --ink:#17212b; --muted:#5b6b78; --accent:#0f766e; --accent-soft:#e6f4f1;
  --paper:#fdfcf9; --rule:#d7dee2; --chip:#f1f5f4;
  --sans:'IBM Plex Sans','Segoe UI',sans-serif; --serif:'Source Serif 4',Georgia,serif;
}
@page{size:A4;margin:14mm 13mm;}
*{box-sizing:border-box;}
html,body{margin:0;padding:0;}
body{
  background:var(--paper); color:var(--ink); font-family:var(--sans);
  font-size:11px; line-height:1.55; padding:22px 26px;
  -webkit-print-color-adjust:exact; print-color-adjust:exact;
}
.cover{
  display:grid; grid-template-columns:64px 1fr; gap:16px; align-items:center;
  border-bottom:3px double var(--ink); padding-bottom:14px; margin-bottom:18px;
}
.cover img{width:64px;height:64px;object-fit:contain;}
.eyebrow{font-size:9px;letter-spacing:.22em;text-transform:uppercase;color:var(--accent);font-weight:700;}
.cover h1{font-family:var(--serif);font-size:22px;line-height:1.15;margin:3px 0 2px;font-weight:700;}
.cover .sub{font-size:10px;color:var(--muted);}
.meta{
  display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 16px;
  background:var(--accent-soft);border-left:3px solid var(--accent);
  padding:11px 14px;margin-bottom:14px;
}
.meta-item{display:flex;flex-direction:column;gap:2px;min-width:0;}
.meta-label{font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;}
.meta-value{font-weight:600;font-size:11px;overflow-wrap:anywhere;}
.toc{
  display:flex;flex-wrap:wrap;gap:5px;padding:9px 0 13px;border-bottom:1px solid var(--rule);margin-bottom:16px;
}
.toc-chip{background:var(--chip);border:1px solid var(--rule);border-radius:999px;padding:3px 9px;font-size:9px;color:var(--muted);}
.toc-chip b{color:var(--accent);font-weight:700;margin-right:3px;}
.doc{margin:0 0 22px;break-inside:avoid-page;}
.doc-head{display:flex;align-items:center;gap:10px;margin-bottom:9px;}
.doc-num{
  font-family:var(--serif);font-size:18px;color:var(--accent);font-weight:700;
  min-width:26px;border-right:1px solid var(--rule);padding-right:9px;
}
.doc-head h2{
  font-family:var(--serif);font-size:14px;margin:0;text-transform:uppercase;
  letter-spacing:.04em;white-space:nowrap;
}
.doc-rule{flex:1;height:1px;background:linear-gradient(90deg,var(--rule),transparent);}
.doc-body{background:#fff;border:1px solid var(--rule);border-radius:3px;padding:12px 14px;}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 10px;}
.doc-body th,.doc-body td{border:1px solid var(--rule)!important;padding:5px 7px;font-size:10px!important;text-align:left;vertical-align:top;overflow-wrap:anywhere;}
.doc-body th{background:var(--chip)!important;font-weight:600;color:var(--ink);}
.doc-body h1,.doc-body h2,.doc-body h3{font-family:var(--serif);font-size:13px;margin:6px 0;}
.doc-body p{margin:3px 0;}
.doc-body label{display:inline-block;min-width:112px;font-weight:600;color:var(--muted);font-size:9px;letter-spacing:.02em;text-transform:uppercase;}
.doc-body .fv{font-weight:500;color:var(--ink);}
.doc-body img{max-width:100%!important;height:auto!important;}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important;}
.screen-bar{
  position:sticky;top:0;z-index:9;display:flex;justify-content:flex-end;gap:8px;
  background:rgba(253,252,249,.94);backdrop-filter:blur(6px);
  padding:8px 0 12px;margin:-22px -26px 14px;padding-left:26px;padding-right:26px;
  border-bottom:1px solid var(--rule);
}
.screen-bar button{font:inherit;font-size:11px;font-weight:600;cursor:pointer;border-radius:5px;padding:7px 14px;}
.btn-print{background:var(--accent);color:#fff;border:1px solid var(--accent);}
.btn-close{background:#fff;color:var(--ink);border:1px solid var(--rule);}
.sign{display:flex;justify-content:flex-end;margin-top:26px;}
.sign-box{width:230px;text-align:center;font-size:10px;color:var(--muted);}
.sign-space{height:52px;}
@media print{
  .screen-bar{display:none!important;}
  body{padding:0;background:#fff;font-size:10px;}
  .doc{break-after:page;}
  .doc:last-child{break-after:auto;}
  .meta,.toc,.doc-body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}
}
@media screen and (max-width:900px){
  .meta{grid-template-columns:repeat(2,minmax(0,1fr));}
}
</style>
</head>
<body>
<div class="screen-bar">
  <button type="button" class="btn-close" id="close-view">Tutup</button>
  <button type="button" class="btn-print" id="print-view">\u{1F5A8} Cetak</button>
</div>
<header class="cover">
  <img src="${c(t)}" alt="Logo">
  <div>
    <div class="eyebrow">Dossier Cetak \xB7 Detail Klaim</div>
    <h1>${c(s)}</h1>
    <div class="sub">Laporan lengkap berkas klaim &bull; ${new Date().toLocaleString("id-ID")}</div>
  </div>
</header>
<div class="meta">
  ${e("No. RM",d("norm"))}
  ${e("Nama Pasien",d("nama"))}
  ${e("No. Registrasi",d("no_registrasi")||d("reg"))}
  ${e("ID Visit",d("id_visit"))}
  ${e("Tanggal Awal",d("tanggalAwal"))}
  ${e("Tanggal Akhir",d("tanggalAkhir"))}
  ${e("Status",d("status"))}
  ${e("Billing",d("billing"))}
</div>
<div class="toc">${i}</div>
<main>${o}</main>
<div class="sign"><div class="sign-box">
  <div>Petugas Verifikasi</div><div class="sign-space"></div>
  <div><strong>( .................................... )</strong></div>
</div></div>
<script>
(function(){
  function doPrint(){ window.focus(); window.print(); }
  document.getElementById('print-view').addEventListener('click', doPrint);
  document.getElementById('close-view').addEventListener('click', function(){
    if (window.confirm('Tutup halaman cetak ini?')) window.close();
  });
  window.addEventListener('load', function(){ setTimeout(doPrint, 500); });
  window.addEventListener('afterprint', function(){
    if (window.confirm('Apakah menu print ini akan ditutup?')) window.close();
  });
})();
<\/script>
</body>
</html>`}function y(){let r=x();if(!r.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let t=window.open("","_blank");if(!t){window.alert("Popup diblokir \u2014 izinkan popup untuk membuka dossier cetak M-KLAIM.");return}t.document.open(),t.document.write(v(r)),t.document.close()}function w(){let r=Array.from(document.querySelectorAll("button.btn-success")).find(t=>/^printDiv\s*\(/i.test(t.getAttribute("onclick")||""));return r?.parentElement?r.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(t=>t.querySelector("button"))||document.getElementById("SCETAK")||document.body}function u(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor")||document.getElementById("ext-mklaim-print-btn"))return;let r=w(),t=document.createElement("button");t.id="ext-mklaim-print-btn",t.type="button",t.className="btn btn-primary btn-sm",t.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",t.innerHTML="\u{1F5A8} Cetak Rapi M-KLAIM",t.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),y()});let e=Array.from(r.querySelectorAll("button.btn-success")).find(i=>/^printDiv\s*\(/i.test(i.getAttribute("onclick")||""));e?r.insertBefore(t,e):r.appendChild(t)}typeof p.featureModules<"u"&&(p.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let r=()=>u();document.readyState==="complete"?window.setTimeout(r,500):window.addEventListener("load",()=>window.setTimeout(r,500)),new MutationObserver(()=>{document.getElementById("ext-mklaim-print-btn")||u()}).observe(document.body,{childList:!0,subtree:!0})}})})();
