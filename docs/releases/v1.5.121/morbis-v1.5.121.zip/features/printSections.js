"use strict";var __morbis_feature=(()=>{var u=Object.defineProperty,M=Object.getOwnPropertyDescriptor,A=Object.getOwnPropertyNames,E=Object.prototype.hasOwnProperty,q=(t,e)=>{for(var a in e)u(t,a,{get:e[a],enumerable:!0})},H=(t,e,a,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let i of A(e))!E.call(t,i)&&i!==a&&u(t,i,{get:()=>e[i],enumerable:!(n=M(e,i))||n.enumerable});return t},j=t=>H(u({},"__esModule",{value:!0}),t),b={};q(b,{fitToSinglePage:()=>P,isRealContentText:()=>w,sectionHasContent:()=>S});function T(){return window}var g=new Set;function s(t,e){if(g.has(t)){let n=document.getElementById(t);if(n)return n}let a=document.createElement("style");return a.id=t,a.textContent=e,document.head.appendChild(a),g.add(t),a}s("ext-shared-animations",`
  @keyframes fadeSlideIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
`);var y="extensionConfig";function B(t,e,a){let n=e?.features?.[t];if(!n)return!0;if(n.enabled===!1)return!1;let i=a??e?.currentRole??"admin";if(i==="admin")return!0;let o=n.allowedRoles;return!Array.isArray(o)||o.length===0?!0:o.includes(i)}async function z(t){try{let e=(await chrome.storage.sync.get(y))?.[y]??null;return B(t,e)}catch{return!0}}function I(t,e){z(t).then(a=>{if(a)try{e()}catch(n){console.error(`[featureGate:${t}] gagal jalan:`,n)}})}var x=T(),k=96/25.4,R=194,W=281,$=Math.round(R*k),p=Math.round(W*k),_=p-6,v=.7,F=/^(-+|—+|-?|n\/?a|null|undefined|tbd|\?)$/i,N="input,button,select,textarea,label,script,style,hr,.panel-heading,.pdf-viewer,canvas,.watermark";function w(t){let e=(t??"").trim();return e.length>2&&!F.test(e)}function S(t){return!!((t.tableRows??[]).some(w)||(t.textWithoutUi??"").trim().length>30||(t.renderedFiles??0)>0&&(t.renderedSizePx??0)>0)}function P(t,e=p,a=v){if(!(t>0)||!(e>0))return{scale:1,boxHeightPx:0,fitsOnePage:!0,needed:1};if(t<=e)return{scale:1,boxHeightPx:0,fitsOnePage:!0,needed:1};let n=e/t,i=Math.max(a,Math.min(1,n)),o=t*i<=e+.5;return{scale:i,boxHeightPx:o?t*i:0,fitsOnePage:o,needed:n}}var l="ext-print-doc",c="ext-print-doc-last",m="ext-print-fit",d="ext-print-empty",h="data-ext-print-box",r="ext-print-measuring";function D(){s("ext-print-measure",`html.${r},html.${r} body{
      width:${$}px!important;max-width:${$}px!important;background:#fff!important;}
    html.${r} .navbar,html.${r} .main-sidebar,
    html.${r} .sidebar,html.${r} .footer,
    html.${r} .breadcrumb,html.${r} .panel-heading,
    html.${r} hr,html.${r} input,
    html.${r} .pdf-viewer,html.${r} .watermark{
      display:none!important;}
    html.${r} .wrapper,html.${r} .container,
    html.${r} .container-fluid,html.${r} .row,
    html.${r} [class*=col-md],html.${r} [class*=col-sm],
    html.${r} .content,html.${r} .content-wrapper,
    html.${r} .panel,html.${r} .panel-body,
    html.${r} .box-body{
      margin:0!important;padding:0!important;width:100%!important;
      max-width:none!important;float:none!important;border:0!important;
      box-shadow:none!important;background:#fff!important;}
    html.${r} table{
      border-collapse:collapse!important;font-size:9pt!important;line-height:1.25!important;}
    html.${r} th,html.${r} td{
      padding:1.5px 3px!important;vertical-align:top!important;}
    html.${r} thead{display:table-header-group!important;}
    html.${r} h1,html.${r} h2,html.${r} h3,
    html.${r} h4,html.${r} h5{margin:0 0 2mm!important;}
    /* saat pengukuran, tiap dokumen diukur pada lebar penuh tanpa transform */
    html.${r} .${l}{height:auto!important;overflow:visible!important;}
    html.${r} .${m}{transform:none!important;width:auto!important;}
  `)}function U(){s("ext-print-sections",`@media print{
      @page{size:A4;margin:8mm;}
      html,body{background:#fff!important;width:auto!important;}
      /* section kosong (cuma tombol "Cetak X") tak pernah ikut cetak */
      .${d}{display:none!important;}
      /* satu dokumen = satu halaman, seperti berkas cetak manual */
      .${l}{page-break-after:always;break-after:page;}
      .${c}{page-break-after:auto;break-after:auto;}
      /* kotak halaman mengunci tinggi hasil penskalaan supaya tepat 1 lembar.
         Tinggi & skala dikirim lewat custom property dari JS, bukan inline
         style langsung: inline style berlaku juga di layar, sedangkan
         penskalaan hanya boleh berlaku saat print. */
      .${l}[${h}="1"]{
        height:var(--ext-print-box-h,auto)!important;
        overflow:hidden!important;
      }
      .${m}{
        transform:scale(var(--ext-print-scale,1));
        width:calc(100% / var(--ext-print-scale,1));
      }
      /* halaman file ter-render: satu file = satu lembar penuh */
      .${l}[data-ext-print-file]{page-break-after:always;break-after:page;
        page-break-inside:avoid;break-inside:avoid;}
      .${l}[data-ext-print-file][${c}]{page-break-after:auto;break-after:auto;}
      /* rapikan kerangka Bootstrap */
      .navbar,.navbar-default,.main-sidebar,.sidebar,.footer,.breadcrumb,
      .panel-heading,hr,input[type=checkbox],.no-print{display:none!important;}
      .wrapper,.container,.container-fluid,.row,[class*=col-md],[class*=col-sm],
      .content,.content-wrapper,.panel,.panel-body,.box-body{
        margin:0!important;padding:0!important;width:100%!important;
        max-width:none!important;float:none!important;border:0!important;
        box-shadow:none!important;background:#fff!important;}
      /* tabel rapat: padding kecil, header berulang, baris tak terpotong */
      table{border-collapse:collapse!important;font-size:9pt;line-height:1.25;}
      th,td{padding:1.5px 3px!important;vertical-align:top;}
      thead{display:table-header-group;}
      tfoot{display:table-footer-group;}
      tr,td,th{page-break-inside:avoid;break-inside:avoid;}
      h1,h2,h3,h4,h5{margin:0 0 2mm!important;page-break-after:avoid;break-after:avoid;}
      img{max-width:100%!important;height:auto!important;}
    }`)}function Y(){return[...document.querySelectorAll("div.isidalam")].filter(t=>!t.classList.contains(l)&&!t.classList.contains(d))}function G(t){let e=[];for(let o of t.querySelectorAll("tr"))e.push((o.innerText??"").trim());let a=t.cloneNode(!0);a.querySelectorAll(N).forEach(o=>o.remove());let n=0,i=0;for(let o of t.querySelectorAll("canvas")){let C=o.clientWidth||o.width,O=o.clientHeight||o.height;C>20&&O>20&&(n++,i=Math.max(i,C*O))}return S({tableRows:e,textWithoutUi:(a.innerText??"").trim(),renderedFiles:n,renderedSizePx:i})}function K(t){let e=t.querySelector(`:scope > .${m}`);if(!e){for(e=document.createElement("div"),e.className=m;t.firstChild;)e.appendChild(t.firstChild);t.appendChild(e)}return e}function X(t){if(t.length===0)return;let e=document.documentElement;e.classList.add(r);try{for(let a of t){let n=K(a),i=n.scrollHeight,o=P(i,_);o.scale<1&&o.fitsOnePage?(a.style.setProperty("--ext-print-box-h",`${Math.round(o.boxHeightPx)}px`),n.style.setProperty("--ext-print-scale",o.scale.toFixed(4)),a.setAttribute(h,"1")):(a.removeAttribute(h),a.style.removeProperty("--ext-print-box-h"),n.style.removeProperty("--ext-print-scale")),o.scale<1&&!o.fitsOnePage&&console.info(`[PrintSections] "${a.id}": butuh skala ${o.needed.toFixed(2)} < batas ${v} -> dicetak natural (${Math.ceil(i/p)} halaman) demi keterbacaan`)}}finally{e.classList.remove(r)}}function J(t){let e=[...t.querySelectorAll("canvas")].filter(a=>(a.clientWidth||a.width)>20&&(a.clientHeight||a.height)>20);if(e.length===0)return!1;for(let a of e){let n=document.createElement("div");n.className=l,n.setAttribute("data-ext-print-file",t.id||"file"),a.style.maxHeight=`${p}px`,a.style.width="auto",a.style.maxWidth="100%",n.appendChild(a),t.parentElement?.insertBefore(n,t)}return t.classList.add(d),!0}function L(){let t=Y(),e=[];for(let n of t)if(!n.classList.contains(d)){if(!G(n)){n.classList.add(d);continue}n.classList.remove(d),!J(n)&&(n.classList.remove("no-print"),n.classList.add(l),e.push(n))}let a=[...document.querySelectorAll(`.${l}`)];for(let n of a)n.classList.remove(c);a[a.length-1]?.classList.add(c);for(let n of e){let i=document.querySelector(`input[type=checkbox][onclick*="${CSS.escape(n.id||"")}"]`);i&&(i.checked=!0,i.disabled=!1)}for(let n of t)if(n.classList.contains(d)){let i=document.querySelector(`input[type=checkbox][onclick*="${CSS.escape(n.id||"")}"]`);i&&(i.checked=!1,i.disabled=!0)}X(e)}function f(){document.getElementById("ext-print-sections")===null&&U(),document.getElementById("ext-print-measure")===null&&D(),s("ext-print-sections-ui",`.${d} > .panel-heading{opacity:.45;}
     input[type=checkbox][disabled]{cursor:not-allowed;}`),window.addEventListener("beforeprint",()=>{try{L()}catch(a){console.error("[PrintSections] gagal applied:",a)}},{passive:!0});let t=()=>{try{L()}catch(a){console.error("[PrintSections] gagal applied:",a)}};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",t,{once:!0}):t();let e=0;new MutationObserver(()=>{window.clearTimeout(e),e=window.setTimeout(t,800)}).observe(document.body,{childList:!0,subtree:!0})}return typeof x.featureModules<"u"&&(x.featureModules.printSections={id:"printSections",name:"Cetak Otomatis Berkas (M-KLAIM)",description:"Cetak hanya berkas yang ada isinya, tiap dokumen pas 1 lembar A4 (tanpa perlu centang checkbox)",match:{oneOf:[{prefix:"/v2/m-klaim/detail"}]},run:f}),I("printSections",()=>{(window.location?.pathname??"").includes("/v2/m-klaim/detail")&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",f):f())}),j(b)})();
