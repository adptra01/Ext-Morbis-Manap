"use strict";var __morbis_feature=(()=>{var at="extensionConfig";function it(r,a,g){if(a?.extensionEnabled===!1)return!1;let h=a?.features?.[r];if(!h)return!0;if(h.enabled===!1)return!1;let k=g??a?.currentRole??"admin";if(k==="admin")return!0;let S=h.allowedRoles;return!Array.isArray(S)||S.length===0?!0:S.includes(k)}async function It(r){try{let a=await chrome.runtime.sendMessage({type:"GET_CONFIG"});if(a?.config)return it(r,a.config)}catch{}try{let a=(await chrome.storage.local.get(at))?.[at]??null;return it(r,a)}catch{return!0}}function Lt(r,a){It(r).then(g=>{if(g)try{a()}catch(h){console.error(`[featureGate:${r}] gagal jalan:`,h)}}).catch(g=>console.error(`[featureGate:${r}] gagal baca config:`,g))}var nt="ext-free-text-noop",zt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function qt(r){try{let a=r.toUpper;if(typeof a=="function"&&a[nt]===!0)return!0;let g=function(h){return h?.value??""};g[nt]=!0;try{Object.defineProperty(r,"toUpper",{value:g,writable:!0,configurable:!0})}catch{r.toUpper=g}return!0}catch{return!1}}var _="ext-pa-typo",Tt=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi (termasuk ICD-O, Saran & Catatan)"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],j={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},icdo:{fs:6,lh:1.2},catatan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},rt=4,ot=24,Rt=.5,Bt=2.5;function lt(r,a,g,h){let k=typeof r=="number"?r:Number(r);return Number.isFinite(k)?Math.min(h,Math.max(g,k)):a}function A(r,a){let g=r??{};return{fs:lt(g.fs,a.fs,rt,ot),lh:lt(g.lh,a.lh,Rt,Bt)}}function M(r){let a=r??{};return{kop:A(a.kop,j.kop),pasien:A(a.pasien,j.pasien),judul:A(a.judul,j.judul),isi:A(a.isi,j.isi),kesimpulan:A(a.kesimpulan,j.kesimpulan),icdo:A(a.icdo,j.icdo),catatan:A(a.catatan,j.catatan),ttd:A(a.ttd,j.ttd)}}function J(){return M(null)}function st(r){try{if(!r)return J();let a=r.getItem(_);return a?M(JSON.parse(a)):J()}catch{return J()}}function Ft(r,a){try{return r?(r.setItem(_,JSON.stringify(M(a))),!0):!1}catch{return!1}}function Pt(r){try{r?.removeItem(_)}catch{}}function pt(r){let a=M(r),g=h=>Math.min(ot,Math.max(rt,h));return{...a,alamatFs:g(a.kop.fs-8.5),judulLapFs:g(a.kop.fs-4)}}var b=r=>String(Math.round(r*100)/100);function Dt(r){let a=pt(r);return{"--pa-kop-fs":`${b(a.kop.fs)}pt`,"--pa-kop-lh":b(a.kop.lh),"--pa-alamat-fs":`${b(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(a.judulLapFs)}pt`,"--pa-pasien-fs":`${b(a.pasien.fs)}pt`,"--pa-pasien-lh":b(a.pasien.lh),"--pa-judul-fs":`${b(a.judul.fs)}pt`,"--pa-judul-lh":b(a.judul.lh),"--pa-isi-fs":`${b(a.isi.fs)}pt`,"--pa-isi-lh":b(a.isi.lh),"--pa-kesimpulan-fs":`${b(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(a.kesimpulan.lh),"--pa-icdo-fs":`${b(a.icdo.fs)}pt`,"--pa-icdo-lh":b(a.icdo.lh),"--pa-catatan-fs":`${b(a.catatan.fs)}pt`,"--pa-catatan-lh":b(a.catatan.lh),"--pa-ttd-fs":`${b(a.ttd.fs)}pt`,"--pa-ttd-lh":b(a.ttd.lh)}}function Mt(r,a){if(r)try{for(let[g,h]of Object.entries(Dt(a)))r.setProperty(g,h)}catch{}}var $t=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function V(r){let a=r??"",g=a.match($t);if(!g)return null;let h=a.slice(g[0].length).trim();return h===""?null:[g[1],h]}var Ht={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" ",plusmn:"\xB1",pm:"\xB1",equals:"=",ge:"\u2265",geq:"\u2265",le:"\u2264",leq:"\u2264",ne:"\u2260",neq:"\u2260",times:"\xD7",divide:"\xF7",deg:"\xB0",micro:"\xB5",hellip:"\u2026",ndash:"\u2013",mdash:"\u2014",bull:"\u2022",middot:"\xB7",ldquo:"\u201C",rdquo:"\u201D",lsquo:"\u2018",rsquo:"\u2019",laquo:"\xAB",raquo:"\xBB",trade:"\u2122",reg:"\xAE",copy:"\xA9"},Ut=/&(#x[0-9a-f]+|#\d+|[a-z][a-z0-9]*);/gi;function Nt(r){if(!Number.isFinite(r)||r<32||r>1114111)return" ";try{return String.fromCodePoint(r)}catch{return" "}}function dt(r){return String(r??"").replace(Ut,(a,g)=>{if(g[0]==="#"){let h=/^#x([0-9a-f]+)$/i.exec(g);return Nt(h?parseInt(h[1],16):parseInt(g.slice(1),10))}return Ht[g.toLowerCase()]??a})}Lt("paLabPrint",function(){"use strict";function r(){try{qt(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let k=document.createElement("style");k.id="ext-free-text-style",k.textContent=zt,document.head.appendChild(k)}}catch{}}if(r(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",r),window.setInterval(r,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let k="ext-pa-print-proc";if(document.documentElement.getAttribute(k))return;document.documentElement.setAttribute(k,"1");let S=()=>{try{return window.localStorage??null}catch{return null}},C=st(S()),W=()=>{try{Mt(document.documentElement.style,C)}catch{}};W();let w=t=>$(t?.textContent||"");function ut(t){return t.replace(/<[^>]+>/g," ")}function Ot(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function $(t){let e=Ot(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ");return dt(dt(e)).replace(/\s+/g," ").trim()}function u(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let ct=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",H=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>w(t)).filter(Boolean);for(;H.length<3;)H.push("");let R=[],mt=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(mt){let t=document.createElement("div");t.innerHTML=mt.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),R=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let U=R.join(" "),ft=t=>{let e=U.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},gt=ft("telp"),ht=ft("fax"),N=(U.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],O=(U.match(/https?:\/\/[^\s;,]+/)||[""])[0],L=U.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");N&&(L=L.split(N).join("")),O&&(L=L.split(O).join("")),L=L.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Gt=["Alamat: "+L,gt?"Telp: "+gt:"",ht?"Fax: "+ht:""].filter(Boolean).join(", "),Kt=[N?"Email: "+N:"",O?"Website: "+O:""].filter(Boolean).join(", ");R=[Gt,Kt].filter(Boolean);let Q=w(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",G=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let o=w(e[0]),l=w(e[2]),s=w(e[3]),p=w(e[5]);o&&G.push([o,l]),s&&G.push([s,p])}});let z=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],x=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),E=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",o=!1,l=t.querySelector(".section-title");if(l)e=w(l),o=!0;else{let d=f=>f.split(":")[0].trim();for(let f of Array.from(t.children).slice(0,3)){let c=w(f);if(c&&c.length<=24&&z.includes(x(d(c)))){e=d(c);break}}if(!e){let f=(t.textContent||"").split(`
`).map(c=>c.trim()).find(Boolean)||"";f&&z.includes(x(d(f)))&&(e=d(f))}if(!e)return}let s=document.createElement("div");s.innerHTML=t.innerHTML,s.querySelector(".section-title")?.remove();let p=s.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(d=>d.split(/<br\s*\/?>|\n/).map(f=>$(f.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(d=>d.length),m=[],n=[];p.forEach((d,f)=>{d.forEach((c,y)=>{f>0&&y===0&&m.length&&n.push(m.length),m.push(c)})});let i=m;if(!o&&i.length&&x(i[0])===x(e)){i.shift();for(let d=0;d<n.length;d++)n[d]-=1;for(;n.length&&n[0]<=0;)n.shift()}i.length>1&&!/^[IVXLC]+\.\s/.test(i[0])&&!/:\s*$/.test(i[0])&&i.slice(1).some(d=>/^II\.\s/.test(d))&&(i[0]="I. "+i[0]),e&&E.push({title:e,items:i,para:n})});let _t=/^catatan\s*:?/i,Jt=/^icd[\s-]*o\b\s*:?/i,X=[];for(let t of E){let e=[{title:t.title,items:[],para:[]}],o=e[0],l=!1,s=(p,m)=>{o={title:p,items:[],para:[],bare:m},e.push(o),l=!0};if(t.items.forEach((p,m)=>{let n=p.match(_t),i=n?null:p.match(Jt);if(n){x(o.title)!=="catatan"&&s("Catatan");let d=p.slice(n[0].length).trim();d&&(t.para.includes(m)&&o.para.push(o.items.length),o.items.push(d));return}if(i){x(o.title)!=="icdo"&&s("ICD-0",!0),t.para.includes(m)&&o.para.push(o.items.length),o.items.push(p);return}t.para.includes(m)&&o.para.push(o.items.length),o.items.push(p)}),l)for(let p of e)p.items.length&&X.push(p);else X.push(e[0])}E.length=0,E.push(...X),E.forEach((t,e)=>t._i=e),E.sort((t,e)=>{let o=t._i??0,l=e._i??0,s=z.indexOf(x(t.title)),p=z.indexOf(x(e.title)),m=s===-1?z.length:s,n=p===-1?z.length:p;return m!==n?m-n:o-l});function Vt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let o=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),l=t.getAttribute("placeholder")||"",s=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(o+" "+l+" "+s).slice(0,300)}}function Wt(t,e,o){let l=e.toLowerCase().split(/[^a-z0-9]+/).filter(n=>n.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(n));if(!l.length)return"";let s=l.sort((n,i)=>i.length-n.length)[0],p="",m=-1;return t.querySelectorAll("input, textarea, select").forEach(n=>{let{val:i,ctx:d}=Vt(n);if(!i||i===e||!i.toLowerCase().includes(s))return;let f=o.test(d)?2:0;f>m&&(m=f,p=i)}),p}function Qt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Xt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let o=n=>/ket\w*\s*klinis/i.test(n),l=n=>/^dokter/i.test(n)||/^rs\b/i.test(n),s=t.map(([n,i],d)=>({label:n,value:i,idx:d})).filter(n=>l(n.label)?!!n.value:o(n.label));if(!s.length)return;let p=new AbortController,m=window.setTimeout(()=>p.abort(),6e3);try{let n=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),i=await fetch(n.toString(),{credentials:"same-origin",signal:p.signal});if(!i.ok){window.console.info("[paPrint] override: fetch input status "+i.status);return}let d=await i.text(),f=new DOMParser().parseFromString(d,"text/html");window.console.info('[paPrint] override: input title="'+(f.title||"").slice(0,60)+'" len='+d.length+" fields="+f.querySelectorAll("input, textarea, select").length);for(let c of s){if(o(c.label)){let et=Qt(f,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),v=$(ut(et));window.console.info("[paPrint] override: "+c.label+' cetak="'+c.value+'" input="'+v+'"'),v&&v!==c.value&&(t[c.idx][1]=v);continue}let y=/^dokter/i.test(c.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,F=Wt(f,c.value,y),I=$(ut(F||""));window.console.info("[paPrint] override: "+c.label+' cetak="'+c.value+'" input="'+I+'"'),I&&I!==c.value&&(t[c.idx][1]=I)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(m)}}await Xt(G).catch(()=>{});let q=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>w(t)).filter(Boolean),bt=q[0]||"",xt=q[1]||"",K=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",yt=q.find(t=>/^\(.*\)$/.test(t))||q[2]||"",kt=q.find(t=>/^nip\.?/i.test(t))||q[3]||"",vt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Zt=Array.from(document.body.querySelectorAll("script")),Yt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),B=G.map(([t,e])=>{if(/^(cara|care)\s+peroleh(an)?$/i.test(t.trim()))return["Cara Perolehan",e];if(!/^ruang/i.test(t))return[t,e];let o=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,l=o.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||o,s=l.split(/\s+-\s*/);if(s.length>=3&&/rawat\s+inap/i.test(s[1])){let p=Yt(s[1].trim()),m=s.slice(2).join(" - ").trim(),n=m?p+" - "+m:p;if(n)return[t,n]}return[t,l]}),te=B.map(([t,e])=>'<div class="info-item"><div class="info-label">'+u(t)+'</div><div class="info-colon">:</div><div class="info-value">'+u(e)+"</div></div>").join(""),Z=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+u(t)+"</strong>":u(t),ee=t=>/^catatan/i.test(t.trim()),Y=t=>/^saran/i.test(t.trim()),wt=t=>ee(t)||Y(t),ae=t=>Y(t)?"Saran:":"Catatan:",tt=t=>t.replace(/^(catatan|saran)\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),ie=B.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function jt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(o=>{if(!o.ok)throw new Error("img "+o.status);return o.blob()}).then(o=>new Promise((l,s)=>{let p=new FileReader;p.onload=()=>l(String(p.result)),p.onerror=()=>s(p.error),p.readAsDataURL(o)})).catch(()=>e)}async function ne(){let t=pt(C),[e,o]=await Promise.all([jt(ct),K?jt(K):Promise.resolve("")]),l="";for(let i=0;i<B.length;i+=2){let d=B[i],f=B[i+1];l+="<tr><td>"+u(d[0])+"</td><td>:</td><td>"+u(d[1])+"</td>"+(f?"<td>"+u(f[0])+"</td><td>:</td><td>"+u(f[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let s="";for(let i of E){if(wt(i.title)){let v=i.items.length?i.items:["Tidak ada"],P=v.length>1,D=Y(i.title)?"SARAN:":"CATATAN:";s+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+D+'</b></td><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';">'+v.map(T=>(P?"- ":"")+"<b>"+u(tt(T)||"Tidak ada")+"</b>").join("<br>")+"</td></tr></table>";continue}if(i.bare){i.items.forEach((v,P)=>{s+='<p style="margin:'+(P===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+u(v.toUpperCase())+"</b></p>"});continue}let d=["makroskopik","mikroskopik","kesimpulan"].includes(x(i.title)),f=x(i.title)==="icdo";s+='<p style="margin:12pt 0 0 0;font-size:'+(f?t.isi.fs:t.judul.fs)+'pt;"><b>'+(d?"<u>":"")+u(i.title.toUpperCase())+(d?"</u>":"")+"</b></p>";let c=x(i.title)==="kesimpulan",y=x(i.title)==="icdo",F=c||y||x(i.title)==="saran",I=c?t.kesimpulan.fs:t.isi.fs,et=c?t.kesimpulan.lh:t.isi.lh;i.items.forEach((v,P)=>{let D=c?v.trimStart():v,T=c?null:V(D),Ct=i.items.length===1&&T!==null&&/^[-•–—*]$/.test(T[0]),Et=Ct?tt(D)||T[1]:D,oe=F?"<b>"+u(Et)+"</b>":Z(Et),le=T&&!Ct?"margin-left:18pt;text-indent:-18pt;":"";s+='<p style="margin:'+(i.para.includes(P)?"4pt":"0")+" 0 6pt 0;font-size:"+I+"pt;line-height:"+et+";text-align:justify;"+le+'">'+oe+"</p>"})}let p='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+u(Q)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+H.slice(0,3).map(i=>'<b style="font-size:'+t.kop.fs+'pt;">'+u(i)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+R.map(i=>u(i)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+u(Q.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+l+"</table>"+s+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+u(bt)+'</p><p style="margin:0 0 6pt 0;">'+u(xt)+"</p>"+(o?'<p style="margin:0 0 6pt 0;"><img src="'+o+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+u(yt)+'</b></p><p style="margin:0 0 6pt 0;">'+u(kt)+"</p></td></tr></table></body></html>",m=new Blob(["\uFEFF"+p],{type:"application/msword"}),n=document.createElement("a");n.href=URL.createObjectURL(m),n.download="Hasil-PA-"+ie+".doc",document.body.appendChild(n),n.click(),window.setTimeout(()=>{URL.revokeObjectURL(n.href),n.remove()},4e3)}let re=E.map(t=>{if(wt(t.title)){let i=t.items.length?t.items:["Tidak ada"],d=i.length>1;return'<div class="section-catatan"><span class="catatan-label">'+ae(t.title)+'</span><div class="catatan-list">'+i.map(f=>{let c="<span>"+u(tt(f)||"Tidak ada")+"</span>";return d?'<div class="catatan-item"><span class="catatan-dash">-</span>'+c+"</div>":'<div class="catatan-item">'+c+"</div>"}).join("")+"</div></div>"}let e=x(t.title)==="kesimpulan",o=x(t.title)==="icdo",l=e||o||x(t.title)==="saran",s='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+(o&&!t.bare?" section-icdo":"")+'">'+t.items.map((i,d)=>{let f=t.para.includes(d)?" item-para":"",c=e?i.trimStart():i,y=e?null:V(c),F=!e&&!y&&/:\s*$/.test(c)&&d+1<t.items.length&&!!V(t.items[d+1])&&t.para.includes(d+1);if(y&&!(t.items.length===1&&/^[-•–—*]$/.test(y[0]))){let I=l?"<strong>"+u(y[1])+"</strong>":Z(y[1]);return'<div class="item-list has-marker'+f+'"><span class="item-marker">'+(l?"<strong>"+u(y[0])+"</strong>":u(y[0]))+"</span><span>"+I+"</span></div>"}return'<div class="item-list'+f+(F?" item-intro":"")+'">'+(l?"<strong>"+u(c)+"</strong>":Z(c))+"</div>"}).join("")+"</div>";if(t.bare)return s;let p=x(t.title),m=["makroskopik","mikroskopik","kesimpulan"].includes(p)?" u":"",n=p==="icdo"?" i":"";return'<div class="section-judul'+m+n+'">'+u(t.title)+"</div>"+s}).join("");document.body.innerHTML='<a href="'+u(vt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+u(ct)+'" alt="Logo"></div><div class="kop-text">'+H.slice(0,3).map(t=>'<h1 class="kop-atas">'+u(t)+"</h1>").join("")+'<div class="kop-alamat">'+R.map(t=>u(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+u(Q)+'</div><div class="patient-info-container">'+te+'</div><div class="hasil-pa">'+re+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+u(bt)+"</p><p>"+u(xt)+"</p>"+(K?'<img src="'+u(K)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+u(yt)+'</p><p style="margin-top: 2px;">'+u(kt)+"</p></div></div></div>",Zt.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),ne().catch(()=>{window.location.href=vt})});let At=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(l,s,p,m,n,i,d,f)=>"<label>"+u(p)+'<input type="range" data-g="'+u(l)+'" data-f="'+s+'" min="'+m+'" max="'+n+'" step="'+i+'" value="'+d+'"><output data-o="'+u(l+"-"+s)+'">'+u(String(d)+f)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+Tt.map(l=>'<div class="t-typo-group"><strong>'+u(l.label)+'</strong><div class="t-typo-row">'+e(l.key,"fs","Font (pt)",4,20,.5,C[l.key].fs,"pt")+e(l.key,"lh","Spasi baris",.5,2.5,.05,C[l.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(l=>{let s=l;s.addEventListener("input",()=>{let p=s.dataset.g,m=s.dataset.f;if(!p||!m||!C[p])return;C[p][m]=Number(s.value),W();let n=t.querySelector(`output[data-o="${p}-${m}"]`);n&&(n.textContent=s.value+(m==="fs"?"pt":""))})});let o=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let l=Ft(S(),C);o&&(o.textContent=l?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Pt(S()),C=st(S()),W(),At(),o){let l=t.querySelector("[data-note]");l&&(l.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&At(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let St="ext-pa-print-style";if(!document.getElementById(St)){let t=document.createElement("style");t.id=St,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-transform: uppercase;
        }

        /* Garis bawah hanya untuk header Makroskopik/Mikroskopik/Kesimpulan
           (permintaan user 2026-11-06). */
        .section-judul.u {
            text-decoration: underline;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Isi ICD-O yang dirender server DENGAN judul section sendiri:
           menyatu dengan Catatan/Saran \u2192 ikut grup Isi yang sama
           (user 2026-11-06), selalu bold.
           Varian tanpa judul memakai .section-isi-bare (grup Isi sama). */
        .section-icdo {
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Header ICD-O berjudul menyatu dengan isinya \u2192 grup Isi
           (bukan Judul), supaya header+isi sama besar. */
        .section-judul.i {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Hanging indent: baris bernomor/berpoin \u2014 penanda di kolom
           kiri tetap, teks lanjutan sejajar di bawah teks. */
        /* Hanging indent: penanda (I., II., VII., ...) di kolom kiri tetap
           (posisi absolut), teks paragraf mulai di indent tetap sehingga
           baris lanjutan & antar item sejajar meski lebar penanda beda. */
        .item-list.has-marker {
            position: relative;
            padding-left: 2ch;
        }

        .item-marker {
            position: absolute;
            left: 0;
            top: 0;
            white-space: nowrap;
        }

        /* Item tanpa penomoran dalam section yang punya penomoran (mis.
           "Diterima 2 buah jaringan..." di Makroskopik) ikut terindent
           agar sejajar dengan teks setelah Romawi. */
        .section-isi:has(.item-list.has-marker) .item-list:not(.has-marker) {
            padding-left: 2ch;
        }

        /* Baris pengantar yang dipisah baris kosong \u2192 rata kiri. */
        .section-isi:has(.item-list.has-marker) .item-list.item-intro {
            padding-left: 0;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap rapat. */
        .item-list.item-para {
            margin-top: 4px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah), dan memakai grup
           Isi yang sama dengan Catatan/Saran (user 2026-11-06). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN & SARAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya).
           Header dan isi menyatu dalam satu baris, jadi keduanya memakai
           grup Isi yang sama (\u2699\uFE0F Gaya \u2192 Isi), sama besar dengan isi \u2014
           sesuai permintaan user 2026-11-06. Seluruh isinya bold. */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
            font-weight: bold;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let g=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),a().catch(()=>{})):Date.now()-g>5e3&&window.clearInterval(h)},200)})})();
