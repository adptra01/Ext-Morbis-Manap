"use strict";var __morbis_feature=(()=>{var c=Object.defineProperty,h=Object.getOwnPropertyDescriptor,y=Object.getOwnPropertyNames,k=Object.prototype.hasOwnProperty,w=(e,t)=>{for(var r in t)c(e,r,{get:t[r],enumerable:!0})},v=(e,t,r,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of y(t))!k.call(e,o)&&o!==r&&c(e,o,{get:()=>t[o],enumerable:!(a=h(t,o))||a.enumerable});return e},L=e=>v(c({},"__esModule",{value:!0}),e),u={};w(u,{isStatusListPage:()=>f,saveEndpointFor:()=>x});var b="ext-batch-shared-style";function C(){if(document.getElementById(b))return;let e=document.createElement("style");e.id=b,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }
    .ext-status-badge[data-status="warning"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function l(e){return new Promise(t=>{C();let r=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",a=document.createElement("div");a.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",a.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${r}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,a.querySelector("h3").textContent=e.title;let o=a.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((s,p)=>{p>0&&o.appendChild(document.createElement("br")),o.appendChild(document.createTextNode(s))});let n=s=>{a.remove(),document.removeEventListener("keydown",i),t(s)},i=s=>{s.key==="Escape"&&n(!1)};a.querySelector(".ext-modal-close").addEventListener("click",()=>n(!1)),a.addEventListener("click",s=>{s.target===a&&n(!1)}),a.querySelector("[data-ext-ok]").addEventListener("click",()=>n(!0));let d=a.querySelector("[data-ext-cancel]");d&&d.addEventListener("click",()=>n(!1)),document.addEventListener("keydown",i),document.body.appendChild(a)})}function S(e,t,r){if(t?.extensionEnabled===!1)return!1;let a=t?.features?.[e];if(!a)return!0;if(a.enabled===!1)return!1;let o=r??t?.currentRole??"admin";if(o==="admin")return!0;let n=a.allowedRoles;return!Array.isArray(n)||n.length===0?!0:n.includes(o)}function x(e){let t=e.toLowerCase();return/\/endoskopi\/detail_operasi/.test(t)?"/admisi/pelaksanaan-operasi/endoskopi/control":/\/cathlab\/detail_operasi/.test(t)?"/admisi/pelaksanaan-operasi/cathlab/control":"/admisi/pelaksanaan_pelayanan/control/pengajuan-operasi?opsi=simpan"}function E(){let e=document.querySelector("#form-data");if(!e){l({title:"Error",message:"Form #form-data tidak ditemukan",variant:"warning",okLabel:"OK",hideCancel:!0});return}let t=prompt("Masukkan ID Visit tujuan:");if(!t||!/^\d+$/.test(t))return;let r=prompt("Masukkan ID Kunjungan tujuan (opsional):")||"",a=new FormData(e),o=new URLSearchParams;for(let[i,d]of Array.from(a.entries()))i!=="id_pengajuan"&&o.append(i,d);o.set("id_visit",t),r&&o.set("id_kunjungan",r);let n=document.querySelector("#simpan-pindah");n&&(n.disabled=!0,n.value="Memproses..."),fetch(x(location.pathname),{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded","X-Requested-With":"XMLHttpRequest"},body:o.toString()}).then(i=>i.json()).then(i=>{i.status==="200"||i.status===200?(l({title:"Berhasil",message:"Operasi dipindahkan ke Visit "+t,variant:"success",okLabel:"OK",hideCancel:!0}),location.reload()):l({title:"Gagal",message:i.message||"Respon tidak dikenal",variant:"danger",okLabel:"OK",hideCancel:!0})}).catch(i=>{l({title:"Error",message:i.message,variant:"danger",okLabel:"OK",hideCancel:!0})}).finally(()=>{n&&(n.disabled=!1,n.value="Pindahkan Operasi")})}function f(e){let t=e.toLowerCase();return t.includes("/pelaksanaan-operasi/endoskopi")||t.includes("/pelaksanaan-operasi/cathlab")}function j(){let e=document.querySelector("#tselesai");if(!e)return;let t=0;for(let r of Array.from(e.querySelectorAll("tr"))){let a=r.cells?.[1];if(!a||a.querySelector(".ext-pindah-status"))continue;let o=r.innerHTML.match(/(?:detail_info|serahTerima|detail)\((\d+)\)/);if(!o)continue;let n=o[1],i=r.cells?.[4]?.textContent?.trim()??"-",d=document.createElement("button");d.type="button",d.className="btn btn-danger ext-pindah-status",d.textContent="Update Status";let s=`/admisi/pelaksanaan-operasi/batal-operasi?sub=update-status&type=ajax&id=${n}`,p=`Apakah Anda yakin mengembalikan operasi pasien ${i} ke status Belum Dilaksanakan?`;d.addEventListener("click",()=>{showConfirmDialog(p,s,n,()=>location.reload())}),a.appendChild(d),t++}t&&console.log(`[PindahOperasi] Update Status buttons added: ${t}`)}async function m(){try{let e=(await chrome.storage.local.get("extensionConfig")).extensionConfig;return!e||e.extensionEnabled!==!0?!1:S("pindahOperasi",e)}catch{return!1}}function g(){if(["/login","/auth","/signin","/masuk","/keluar","/logout"].some(r=>location.pathname.toLowerCase().includes(r))||document.querySelectorAll('input[type="password"]').length>0)return;if(f(location.pathname)){j();return}if(document.getElementById("simpan-pindah"))return;let e=document.querySelector('#simpan, #save, input[type="submit"], button[type="submit"]');if(!e||!e.parentNode)return;let t=document.createElement("input");t.type="button",t.className="btn btn-warning",t.id="simpan-pindah",t.value="Pindahkan Operasi",t.onclick=E,e.parentNode.insertBefore(t,e.nextSibling),console.log("[PindahOperasi] Button added")}return document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{m().then(e=>{e&&g()})}):m().then(e=>{e&&g()}),L(u)})();
