"use strict";var __morbis_feature=(()=>{var j='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',q=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${j};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,y=null;function H(){return y||(y=new CSSStyleSheet,y.replaceSync(q)),y}var A=!1;function R(){if(A||document.getElementById("ext-pjs-font"))return;A=!0;let r=document.createElement("link");r.id="ext-pjs-font",r.rel="stylesheet",r.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(r)}function F(r,l="open"){let f=r.attachShadow({mode:l});return f.adoptedStyleSheets=[H()],R(),f}var M=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,K=class extends HTMLElement{constructor(){super();let r=F(this);r.innerHTML=`
      <style>${M}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=r.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",r=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){r.stopPropagation(),r.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(r){(r==="disabled"||r==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}},S=typeof window<"u"?window.customElements:null;if(S)try{S.get("ext-btn")||S.define("ext-btn",K)}catch(r){console.warn("[MORBIS Ext] gagal registrasi ext-btn:",r)}var T="extensionConfig";function z(r,l,f){if(l?.extensionEnabled===!1)return!1;let h=l?.features?.[r];if(!h)return!0;if(h.enabled===!1)return!1;let v=f??l?.currentRole??"admin";if(v==="admin")return!0;let b=h.allowedRoles;return!Array.isArray(b)||b.length===0?!0:b.includes(v)}async function U(r){try{let l=await chrome.runtime.sendMessage({type:"GET_CONFIG"});if(l?.config)return z(r,l.config)}catch{}try{let l=(await chrome.storage.local.get(T))?.[T]??null;return z(r,l)}catch{return!0}}function I(r,l){U(r).then(f=>{if(f)try{l()}catch(h){console.error(`[featureGate:${r}] gagal jalan:`,h)}}).catch(f=>console.error(`[featureGate:${r}] gagal baca config:`,f))}I("labHistory",function(){let r=t=>document.querySelector(t),l=t=>r(t)?.value?.trim()||"",f=null;function h(){return{idLab:new URLSearchParams(window.location.search).get("id_lab")||l('input[name="id_lab"]'),idVisit:l('input[name="id_visit"]'),idHasilLab:l('input[name="hasil[1][id]"]')}}async function v(t,a){try{let e=((await(await fetch(`/admisi/pelaksanaan_pelayanan/laboratorium-data?id_visit=${a}`,{credentials:"same-origin"})).text()).match(/<tr[^>]*>[\s\S]*?<\/tr>/gi)||[]).find(i=>new RegExp(`nolab\\s*=\\s*['"]?${t}['"]?`,"i").test(i));if(!e)return null;let o=e.match(/cetakFormPermintaanLab\(\s*(\d+)/)?.[1]||null,d=e.match(/edit_tanggal\(\s*\d+\s*,\s*\d+\s*,\s*"([^"]+)"/)?.[1]||null;return o?{id:o,tgl:d}:null}catch{return null}}function b(t){window.open(t,"_blank")}let w=["dok_luar","nama_rs"],m={},k=null;function E(t){return t.toLowerCase().split(" ").map(a=>a&&a.charAt(0).toUpperCase()+a.slice(1)).join(" ")}function P(t){return document.querySelector(`[name="${t}"]`)}function $(t,a){let e=m[t];return e===void 0?(a&&(m[t]=a),!1):a===e?!1:a.toLowerCase()!==e.toLowerCase()?(m[t]=a,!1):a===E(e)?!0:(m[t]=a,!1)}function C(){try{for(let t of w){let a=P(t);a&&$(t,(a.value??"").trim())}}catch{}}function B(){try{for(let t of w){let a=P(t);a&&$(t,(a.value??"").trim())&&(a.value=m[t],window.console.info("[paKeepCase] "+t+" dikembalikan ke ejaan asli"))}}catch{}}function D(){let t=window.XMLHttpRequest.prototype;if(t.__extKeepPatched)return;t.__extKeepPatched=!0;let a=t.open,e=t.send;t.open=function(...o){try{let d=o[1];this.__extUrl=typeof d=="string"?d:String(d)}catch{}return a.apply(this,o)},t.send=function(...o){try{let d=this,i=o[0],u=d.__extUrl;if(Object.keys(m).length&&typeof u=="string"&&u.includes("pemeriksaan-pa")&&typeof i=="string"&&i.includes("dok_luar=")){let s=new URLSearchParams(i),c=!1;for(let n of w){let p=m[n],x=s.get(n);p&&x!==null&&x!==p&&x===E(p)&&(s.set(n,p),c=!0)}if(c)return window.console.info("[paKeepCase] payload dok_luar/nama_rs dikembalikan ke ejaan asli"),e.call(this,s.toString())}else if(Object.keys(m).length&&typeof u=="string"&&u.includes("pemeriksaan-pa")&&typeof FormData<"u"&&i instanceof FormData&&(i.has("dok_luar")||i.has("nama_rs")))for(let s of w){let c=m[s],n=i.get(s);c&&typeof n=="string"&&n!==c&&n===E(c)&&(window.console.info("[paKeepCase] payload FormData "+s+" dikembalikan"),i.set(s,c))}}catch{}return e.apply(this,o)}}function G(){let t=window;t.__paKeepCase||(t.__paKeepCase=!0,C(),document.addEventListener("input",a=>{let e=a.target;e&&typeof e.matches=="function"&&e.matches("input, textarea, select")&&C()},!0),document.addEventListener("focusout",()=>C(),!0),document.addEventListener("submit",()=>C(),!0),D(),k=window.setInterval(B,300),window.console.info("[paKeepCase] aktif di input-hasil-pa"))}function O(t,a){let e=document.createElement("div");e.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:999999;display:flex;align-items:center;justify-content:center;";let o=document.createElement("div");o.style.cssText="background:#fff;border-radius:8px;padding:16px 18px;min-width:340px;box-shadow:0 8px 30px rgba(0,0,0,.25);font-family:Arial,sans-serif;";let d=document.createElement("div");d.textContent="Edit Tanggal Pengajuan",d.style.cssText="font-weight:700;font-size:14px;margin-bottom:10px;color:#1e293b;";let i=document.createElement("input");i.type="date",i.style.cssText="width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:6px;font-size:13px;padding:10px;";let u=f?.match(/^(\d{2})\/(\d{2})\/(\d{4})/);u&&(i.value=`${u[3]}-${u[2]}-${u[1]}`);let s=document.createElement("div");s.textContent="Server menerima dd/mm/yyyy hh:mm:ss \u2014 waktu diset otomatis ke 00:00:00.",s.style.cssText="font-size:11px;color:#64748b;margin:4px 0 12px;";let c=document.createElement("div");c.style.cssText="display:flex;justify-content:flex-end;";let n=document.createElement("button");n.type="button",n.textContent="Edit Tanggal",n.style.cssText="margin:18px;padding:15px;border:none;border-radius:6px;font-size:12px;font-weight:600;color:#fff;background:#2563eb;cursor:pointer;";let p=document.createElement("button");p.type="button",p.textContent="Batal",p.style.cssText="margin:18px;padding:15px;border:none;border-radius:6px;font-size:12px;font-weight:600;color:#fff;background:#dc2626;cursor:pointer;",n.addEventListener("click",async()=>{let x=i.value.trim();if(!x){alert("Isi tanggal pengajuan baru dulu.");return}let[g,N,W]=x.split("-"),Q=`${W}/${N}/${g} 00:00:00`;n.disabled=!0,n.textContent="Menyimpan\u2026";let _;try{_=(await(await fetch("/laboratorium/control/edit_tanggal",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:new URLSearchParams({lab:t,id_visit:a,date:Q,action:"edit"}).toString()})).json()).status==1}catch{_=!1}e.remove(),alert(_?"Edit Tanggal Pengajuan berhasil diubah.":"Gagal menyimpan tanggal baru."),_&&window.location.reload()}),p.addEventListener("click",()=>e.remove()),e.addEventListener("click",x=>{x.target===e&&e.remove()}),c.append(n,p),o.append(d,i,s,c),e.appendChild(o),document.body.appendChild(e),i.focus()}function V(){let t=Array.from(document.querySelectorAll("fieldset")).find(n=>n.textContent?.includes("Data Pasien"));if(!t)return;let a=document.querySelector("[data-ext-lab-actions]");a&&a.remove();let{idLab:e,idVisit:o,idHasilLab:d}=h();if(!e||!o||!d){console.warn("[inputHasilPa] Missing ids",{idLab:e,idVisit:o,idHasilLab:d});return}let i=document.createElement("div");i.setAttribute("data-ext-lab-actions","true"),i.style.cssText="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0;";let u=(n,p,x)=>{let g=document.createElement("ext-btn");return g.setAttribute("variant",p),g.setAttribute("size","sm"),g.textContent=n,g.addEventListener("click",x),g},s=d;v(e,o).then(n=>{n?(s=n.id,f=n.tgl,console.log("[inputHasilPa] permintaan data",{idLab:e,idVisit:o,id:n.id,tgl:n.tgl})):console.info(`[inputHasilPa] Baris lab ${e} tidak ada di daftar; pakai id hasil[1][id]=${s}.`)}),i.append(u("Edit Tanggal Pengajuan","primary",()=>O(e,o)),u("Cetak","info",()=>b(`/laboratorium/print/hasil-lab?id=${e}&nolab=${e}`)),u("Cetak Form Permintaan Lab","secondary",()=>b(`/admisi/formulir-permintaan-labor/cetak?id=${s}&id_visit=${o}&jenis=cetak`)),u("Edit Form Permintaan Lab","secondary",()=>b(`/admisi/formulir-permintaan-labor/form?id=${s}&id_visit=undefined&jenis=edit`)),u("Halaman Asli Pengajuan Lab","ghost",()=>b(`/admisi/pelaksanaan_pelayanan/laboratorium-data?id_visit=${o}`)));let c=Array.from(document.querySelectorAll("fieldset")).find(n=>n.textContent?.includes("Tanggal Hasil"));if(c)c.after(i);else{let n=document.querySelector("form");n?n.appendChild(i):t.after(i)}}function X(){try{let t=Array.from(document.querySelectorAll("label"));for(let a of t){let e=(a.textContent||"").trim();/^(cara|care)\s+peroleh(an)?$/i.test(e)&&(a.textContent="Cara Perolehan")}if(!t.some(a=>(a.textContent||"").trim()==="Cara Perolehan")){let a=document.querySelector('#cara_peroleh, textarea[name="cara_peroleh"]');if(a){let e=a.parentElement?.querySelectorAll("span, div");if(e){for(let o of Array.from(e))if(/^(cara|care)\s+peroleh(an)?$/i.test((o.textContent||"").trim())){o.textContent="Cara Perolehan";break}}}}}catch{}}function L(){document.documentElement.getAttribute("data-ext-lab-history")&&(G(),X(),V())}let J=performance.now();(function t(){document.documentElement.getAttribute("data-ext-lab-history")?L():performance.now()-J<5e3&&setTimeout(t,200)})();let Y=history.pushState;history.pushState=function(...t){Y.apply(this,t),setTimeout(L,100)},window.addEventListener("popstate",()=>setTimeout(L,100)),window.addEventListener("pagehide",()=>{k!==null&&(clearInterval(k),k=null)})})})();
