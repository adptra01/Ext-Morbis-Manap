"use strict";var __morbis_feature=(()=>{var Z="extensionConfig";function Et(o,a,g){let h=a?.features?.[o];if(!h)return!0;if(h.enabled===!1)return!1;let y=g??a?.currentRole??"admin";if(y==="admin")return!0;let w=h.allowedRoles;return!Array.isArray(w)||w.length===0?!0:w.includes(y)}async function Ct(o){try{let a=(await chrome.storage.sync.get(Z))?.[Z]??null;return Et(o,a)}catch{return!0}}function Lt(o,a){Ct(o).then(g=>{if(g)try{a()}catch(h){console.error(`[featureGate:${o}] gagal jalan:`,h)}})}var Y="ext-free-text-noop",zt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function It(o){try{let a=o.toUpper;if(typeof a=="function"&&a[Y]===!0)return!0;let g=function(h){return h?.value??""};g[Y]=!0;try{Object.defineProperty(o,"toUpper",{value:g,writable:!0,configurable:!0})}catch{o.toUpper=g}return!0}catch{return!1}}var _="ext-pa-typo",Tt=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],z={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},tt=4,et=24,Rt=.5,qt=2.5;function at(o,a,g,h){let y=typeof o=="number"?o:Number(o);return Number.isFinite(y)?Math.min(h,Math.max(g,y)):a}function I(o,a){let g=o??{};return{fs:at(g.fs,a.fs,tt,et),lh:at(g.lh,a.lh,Rt,qt)}}function M(o){let a=o??{};return{kop:I(a.kop,z.kop),pasien:I(a.pasien,z.pasien),judul:I(a.judul,z.judul),isi:I(a.isi,z.isi),kesimpulan:I(a.kesimpulan,z.kesimpulan),ttd:I(a.ttd,z.ttd)}}function G(){return M(null)}function it(o){try{if(!o)return G();let a=o.getItem(_);return a?M(JSON.parse(a)):G()}catch{return G()}}function Ft(o,a){try{return o?(o.setItem(_,JSON.stringify(M(a))),!0):!1}catch{return!1}}function Pt(o){try{o?.removeItem(_)}catch{}}function nt(o){let a=M(o),g=h=>Math.min(et,Math.max(tt,h));return{...a,alamatFs:g(a.kop.fs-8.5),judulLapFs:g(a.kop.fs-4)}}var x=o=>String(Math.round(o*100)/100);function Mt(o){let a=nt(o);return{"--pa-kop-fs":`${x(a.kop.fs)}pt`,"--pa-kop-lh":x(a.kop.lh),"--pa-alamat-fs":`${x(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${x(a.judulLapFs)}pt`,"--pa-pasien-fs":`${x(a.pasien.fs)}pt`,"--pa-pasien-lh":x(a.pasien.lh),"--pa-judul-fs":`${x(a.judul.fs)}pt`,"--pa-judul-lh":x(a.judul.lh),"--pa-isi-fs":`${x(a.isi.fs)}pt`,"--pa-isi-lh":x(a.isi.lh),"--pa-kesimpulan-fs":`${x(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":x(a.kesimpulan.lh),"--pa-ttd-fs":`${x(a.ttd.fs)}pt`,"--pa-ttd-lh":x(a.ttd.lh)}}function Ut(o,a){if(o)try{for(let[g,h]of Object.entries(Mt(a)))o.setProperty(g,h)}catch{}}var Ht=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function J(o){let a=o??"",g=a.match(Ht);if(!g)return null;let h=a.slice(g[0].length).trim();return h===""?null:[g[1],h]}var rt=o=>Math.round(o*10)/10;function Nt(o,a,g=.35){let h=Number.isFinite(o)&&o>0?o:0,y=Number.isFinite(a)&&a>0?a:12,w=rt(h+g*y);return{padPx:w,indentPx:-w}}function Bt(o,a){let g=Number.isFinite(a)&&a>0?a:11,h=(o??"").length;return h===0?0:rt(h*.55*g+.35*g)}Lt("paLabPrint",function(){"use strict";function o(){try{It(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let y=document.createElement("style");y.id="ext-free-text-style",y.textContent=zt,document.head.appendChild(y)}}catch{}}if(o(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",o),window.setInterval(o,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let y="ext-pa-print-proc";if(document.documentElement.getAttribute(y))return;document.documentElement.setAttribute(y,"1");let w=()=>{try{return window.localStorage??null}catch{return null}},E=it(w()),W=()=>{try{Ut(document.documentElement.style,E)}catch{}};W();let A=t=>U(t?.textContent||"");function ot(t){return t.replace(/<[^>]+>/g," ")}function Dt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function U(t){return Dt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let lt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",H=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>A(t)).filter(Boolean);for(;H.length<3;)H.push("");let F=[],st=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(st){let t=document.createElement("div");t.innerHTML=st.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),F=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let N=F.join(" "),pt=t=>{let e=N.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},dt=pt("telp"),ct=pt("fax"),B=(N.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],D=(N.match(/https?:\/\/[^\s;,]+/)||[""])[0],L=N.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");B&&(L=L.split(B).join("")),D&&(L=L.split(D).join("")),L=L.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Ot=["Alamat: "+L,dt?"Telp: "+dt:"",ct?"Fax: "+ct:""].filter(Boolean).join(", "),$t=[B?"Email: "+B:"",D?"Website: "+D:""].filter(Boolean).join(", ");F=[Ot,$t].filter(Boolean);let V=A(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",O=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let n=A(e[0]),r=A(e[2]),p=A(e[3]),s=A(e[5]);n&&O.push([n,r]),p&&O.push([p,s])}});let T=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],j=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),C=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",n=!1,r=t.querySelector(".section-title");if(r)e=A(r),n=!0;else{let u=f=>f.split(":")[0].trim();for(let f of Array.from(t.children).slice(0,3)){let m=A(f);if(m&&m.length<=24&&T.includes(j(u(m)))){e=u(m);break}}if(!e){let f=(t.textContent||"").split(`
`).map(m=>m.trim()).find(Boolean)||"";f&&T.includes(j(u(f)))&&(e=u(f))}if(!e)return}let p=document.createElement("div");p.innerHTML=t.innerHTML,p.querySelector(".section-title")?.remove();let s=p.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(u=>u.split(/<br\s*\/?>|\n/).map(f=>U(f.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(u=>u.length),c=[],i=[];s.forEach((u,f)=>{u.forEach((m,b)=>{f>0&&b===0&&c.length&&i.push(c.length),c.push(m)})});let l=c;if(!n&&l.length&&j(l[0])===j(e)){l.shift();for(let u=0;u<i.length;u++)i[u]-=1;for(;i.length&&i[0]<=0;)i.shift()}l.length>1&&!/^[IVXLC]+\.\s/.test(l[0])&&l.slice(1).some(u=>/^II\.\s/.test(u))&&(l[0]="I. "+l[0]),e&&C.push({title:e,items:l,para:i})});let Kt=/^catatan\s*:?/i,_t=/^icd[\s-]*o\b\s*:?/i,X=[];for(let t of C){let e=[{title:t.title,items:[],para:[]}],n=e[0],r=!1,p=(s,c)=>{n={title:s,items:[],para:[],bare:c},e.push(n),r=!0};if(t.items.forEach((s,c)=>{let i=s.match(Kt),l=i?null:s.match(_t);if(i){j(n.title)!=="catatan"&&p("Catatan");let u=s.slice(i[0].length).trim();u&&(t.para.includes(c)&&n.para.push(n.items.length),n.items.push(u));return}if(l){j(n.title)!=="icdo"&&p("ICD-0",!0),t.para.includes(c)&&n.para.push(n.items.length),n.items.push(s);return}t.para.includes(c)&&n.para.push(n.items.length),n.items.push(s)}),r)for(let s of e)s.items.length&&X.push(s);else X.push(e[0])}C.length=0,C.push(...X),C.forEach((t,e)=>t._i=e),C.sort((t,e)=>{let n=t._i??0,r=e._i??0,p=T.indexOf(j(t.title)),s=T.indexOf(j(e.title)),c=p===-1?T.length:p,i=s===-1?T.length:s;return c!==i?c-i:n-r});function Gt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let n=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),r=t.getAttribute("placeholder")||"",p=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(n+" "+r+" "+p).slice(0,300)}}function Jt(t,e,n){let r=e.toLowerCase().split(/[^a-z0-9]+/).filter(i=>i.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(i));if(!r.length)return"";let p=r.sort((i,l)=>l.length-i.length)[0],s="",c=-1;return t.querySelectorAll("input, textarea, select").forEach(i=>{let{val:l,ctx:u}=Gt(i);if(!l||l===e||!l.toLowerCase().includes(p))return;let f=n.test(u)?2:0;f>c&&(c=f,s=l)}),s}function Wt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Vt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let n=i=>/ket\w*\s*klinis/i.test(i),r=i=>/^dokter/i.test(i)||/^rs\b/i.test(i),p=t.map(([i,l],u)=>({label:i,value:l,idx:u})).filter(i=>r(i.label)?!!i.value:n(i.label));if(!p.length)return;let s=new AbortController,c=window.setTimeout(()=>s.abort(),6e3);try{let i=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),l=await fetch(i.toString(),{credentials:"same-origin",signal:s.signal});if(!l.ok){window.console.info("[paPrint] override: fetch input status "+l.status);return}let u=await l.text(),f=new DOMParser().parseFromString(u,"text/html");window.console.info('[paPrint] override: input title="'+(f.title||"").slice(0,60)+'" len='+u.length+" fields="+f.querySelectorAll("input, textarea, select").length);for(let m of p){if(n(m.label)){let q=Wt(f,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),v=U(ot(q));window.console.info("[paPrint] override: "+m.label+' cetak="'+m.value+'" input="'+v+'"'),v&&v!==m.value&&(t[m.idx][1]=v);continue}let b=/^dokter/i.test(m.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,k=Jt(f,m.value,b),S=U(ot(k||""));window.console.info("[paPrint] override: "+m.label+' cetak="'+m.value+'" input="'+S+'"'),S&&S!==m.value&&(t[m.idx][1]=S)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(c)}}await Vt(O).catch(()=>{});let R=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>A(t)).filter(Boolean),ut=R[0]||"",mt=R[1]||"",$=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",ft=R.find(t=>/^\(.*\)$/.test(t))||R[2]||"",gt=R.find(t=>/^nip\.?/i.test(t))||R[3]||"",ht=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Xt=Array.from(document.body.querySelectorAll("script")),Qt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),P=O.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let n=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,r=n.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||n,p=r.split(/\s+-\s*/);if(p.length>=3&&/rawat\s+inap/i.test(p[1])){let s=Qt(p[1].trim()),c=p.slice(2).join(" - ").trim(),i=c?s+" - "+c:s;if(i)return[t,i]}return[t,r]}),Zt=P.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),Q=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),bt=t=>/^catatan/i.test(t.trim()),xt=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),Yt=P.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function yt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(n=>{if(!n.ok)throw new Error("img "+n.status);return n.blob()}).then(n=>new Promise((r,p)=>{let s=new FileReader;s.onload=()=>r(String(s.result)),s.onerror=()=>p(s.error),s.readAsDataURL(n)})).catch(()=>e)}async function te(){let t=nt(E),[e,n]=await Promise.all([yt(lt),$?yt($):Promise.resolve("")]),r="";for(let l=0;l<P.length;l+=2){let u=P[l],f=P[l+1];r+="<tr><td>"+d(u[0])+"</td><td>:</td><td>"+d(u[1])+"</td>"+(f?"<td>"+d(f[0])+"</td><td>:</td><td>"+d(f[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let p="";for(let l of C){if(bt(l.title)){let b=l.items.length?l.items:["Tidak ada"];p+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.judul.fs+'pt"><b><u>CATATAN:</u></b></td><td>'+b.map(k=>"- "+d(xt(k)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(l.bare){l.items.forEach((b,k)=>{p+='<p style="margin:'+(k===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.judul.fs+'pt;"><b>'+d(b.toUpperCase())+"</b></p>"});continue}p+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b><u>'+d(l.title.toUpperCase())+"</u></b></p>";let u=j(l.title)==="kesimpulan",f=u?t.kesimpulan.fs:t.isi.fs,m=u?t.kesimpulan.lh:t.isi.lh;l.items.forEach((b,k)=>{let S=u?"<b>"+d(b)+"</b>":Q(b),q=J(b),v=Math.max(0,...l.items.map(ie=>{let St=J(ie);return St?Bt(St[0],f):0})),At=v>0?v.toFixed(1):"0",ae="margin-left:"+At+"pt;"+(q&&v>0?"text-indent:-"+At+"pt;":"");p+='<p style="margin:'+(l.para.includes(k)?"14pt":"0")+" 0 6pt 0;font-size:"+f+"pt;line-height:"+m+";text-align:justify;"+ae+'">'+S+"</p>"})}let s='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(V)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+H.slice(0,3).map(l=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(l)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+F.map(l=>d(l)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(V.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+r+"</table>"+p+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(ut)+'</p><p style="margin:0 0 6pt 0;">'+d(mt)+"</p>"+(n?'<p style="margin:0 0 6pt 0;"><img src="'+n+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(ft)+'</b></p><p style="margin:0 0 6pt 0;">'+d(gt)+"</p></td></tr></table></body></html>",c=new Blob(["\uFEFF"+s],{type:"application/msword"}),i=document.createElement("a");i.href=URL.createObjectURL(c),i.download="Hasil-PA-"+Yt+".doc",document.body.appendChild(i),i.click(),window.setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},4e3)}let ee=C.map(t=>{if(bt(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(r=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+d(xt(r)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=j(t.title)==="kesimpulan",n='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+'">'+t.items.map((r,p)=>{let s=t.para.includes(p)?" item-para":"",c=J(r);if(c){let i=e?"<strong>"+d(c[1])+"</strong>":Q(c[1]);return'<div class="item-list has-marker'+s+'"><span class="item-marker">'+d(c[0])+"</span> <span>"+i+"</span></div>"}return'<div class="item-list'+s+'">'+(e?"<strong>"+d(r)+"</strong>":Q(r))+"</div>"}).join("")+"</div>";return t.bare?n:'<div class="section-judul">'+d(t.title)+"</div>"+n}).join("");function K(t=document){let e;try{e=Array.from(t.querySelectorAll(".section-isi"))}catch{return}for(let n of e){let r;try{r=Array.from(n.querySelectorAll(":scope > .item-list"))}catch{r=Array.from(n.children).filter(m=>m.classList.contains("item-list"))}let p=r.filter(m=>m.classList.contains("has-marker"));if(!p.length)continue;let s=12;try{let m=parseFloat(getComputedStyle(n).fontSize);Number.isFinite(m)&&m>0&&(s=m)}catch{}let c=0,i=new Map;for(let m of p){let b=m.querySelector(".item-marker");if(!b||!b.textContent)continue;let k=0;try{let S=document.createRange();S.selectNodeContents(b);let q=Array.from(S.getClientRects()).filter(v=>v.width>.5);q.length&&(k=Math.max(...q.map(v=>v.width)))}catch{}k>0&&(i.set(m,k),k>c&&(c=k))}if(c<=0)continue;let{padPx:l}=Nt(c,s),u=l.toFixed(1)+"px",f=(-l).toFixed(1)+"px";for(let m of r)try{let b=m;b.style.paddingLeft=u,b.style.textIndent=i.has(m)?f:"0px"}catch{}}}let kt;function vt(){try{window.clearTimeout(kt)}catch{}kt=window.setTimeout(()=>{K()},250)}document.body.innerHTML='<a href="'+d(ht)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(lt)+'" alt="Logo"></div><div class="kop-text">'+H.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+F.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(V)+'</div><div class="patient-info-container">'+Zt+'</div><div class="hasil-pa">'+ee+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(ut)+"</p><p>"+d(mt)+"</p>"+($?'<img src="'+d($)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(ft)+'</p><p style="margin-top: 2px;">'+d(gt)+"</p></div></div></div>",Xt.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),te().catch(()=>{window.location.href=ht})});let wt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(r,p,s,c,i,l,u,f)=>"<label>"+d(s)+'<input type="range" data-g="'+d(r)+'" data-f="'+p+'" min="'+c+'" max="'+i+'" step="'+l+'" value="'+u+'"><output data-o="'+d(r+"-"+p)+'">'+d(String(u)+f)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+Tt.map(r=>'<div class="t-typo-group"><strong>'+d(r.label)+'</strong><div class="t-typo-row">'+e(r.key,"fs","Font (pt)",4,20,.5,E[r.key].fs,"pt")+e(r.key,"lh","Spasi baris",.5,2.5,.05,E[r.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(r=>{let p=r;p.addEventListener("input",()=>{let s=p.dataset.g,c=p.dataset.f;if(!s||!c||!E[s])return;E[s][c]=Number(p.value),W(),vt();let i=t.querySelector(`output[data-o="${s}-${c}"]`);i&&(i.textContent=p.value+(c==="fs"?"pt":""))})});let n=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let r=Ft(w(),E);n&&(n.textContent=r?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Pt(w()),E=it(w()),W(),wt(),n){let r=t.querySelector("[data-note]");r&&(r.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&wt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let jt="ext-pa-print-style";if(!document.getElementById(jt)){let t=document.createElement("style");t.id=jt,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        /* Gutter hanging indent dihitung PER SECTION via JS terukur
           (alignHanging -> inline style), BUKAN fix 1.8em: marker
           sepanjang apa pun ("1." s/d "XIII.") sejajar sempurna.
           Aturan di bawah hanya fallback bila pengukuran belum jalan. */
        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Fallback pra-pengukuran: gutter fix 1.8em (ditimpa inline
           presisi oleh alignHanging segera setelah render). */
        .item-list.has-marker {
            padding-left: 1.8em;
            text-indent: -1.8em;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-judul-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}K();try{document.fonts?.ready&&document.fonts.ready.then(()=>{K()})}catch{}window.addEventListener("resize",vt),window.addEventListener("beforeprint",()=>{K()})}let g=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),a().catch(()=>{})):Date.now()-g>5e3&&window.clearInterval(h)},200)})})();
