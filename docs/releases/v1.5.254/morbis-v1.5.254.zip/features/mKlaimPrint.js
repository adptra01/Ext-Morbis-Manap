"use strict";var __morbis_feature=(()=>{function b(){return window}var p="RSUD H. Abdul Manap",m=b(),f=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],s=r=>document.getElementById(r)?.value?.trim()||"";function h(r){let e=t=>{let a=document.createElement("span");return a.className="fv",a.textContent=t,a};r.querySelectorAll("input").forEach(t=>{let a=(t.type||"text").toLowerCase();if(a==="hidden"){t.remove();return}if(a==="radio"||a==="checkbox"){if(!t.checked){t.remove();return}if(a==="radio"){t.replaceWith(e("\u2713"));return}let n=(t.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,l=>l.toUpperCase());t.replaceWith(e(n?"\u2713 "+n:"\u2713"));return}let o=(t.value||"").trim();o?t.replaceWith(e(o)):t.remove()}),r.querySelectorAll("textarea").forEach(t=>{let a=(t.value||"").trim();a?t.replaceWith(e(a)):t.remove()}),r.querySelectorAll("select").forEach(t=>{let a=(t.options[t.selectedIndex]?.textContent||t.value||"").trim();a?t.replaceWith(e(a)):t.remove()})}function x(r){try{let e=r.getContext("2d");if(!e||!r.width||!r.height)return!0;let t=e.getImageData(0,0,r.width,r.height).data,a=388,o=0,n=0;for(let i=0;i<t.length;i+=a)o+=(t[i]+t[i+1]+t[i+2])/3,n++;let l=o/Math.max(n,1);return l<8||l>250}catch{return!1}}function u(r){let e=r.cloneNode(!0),t=Array.from(r.querySelectorAll("canvas")),a=Array.from(e.querySelectorAll("canvas"));return t.forEach((o,n)=>{let l=a[n];if(l){if(x(o)){l.remove();return}try{let i=document.createElement("img");i.src=o.toDataURL("image/png"),i.style.cssText="max-width:100%;height:auto;",l.replaceWith(i)}catch{let i=document.createElement("div");i.className="fv",i.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",l.replaceWith(i)}}}),h(e),f.forEach(o=>e.querySelectorAll(o).forEach(n=>n.remove())),e.querySelectorAll("tr").forEach(o=>{let n=Array.from(o.cells);for(let l=n.length-1;l>=0;l--){let i=n[l];if(!(!(i.textContent||"").trim()&&!i.querySelector("img,table,input")))break;i.remove()}}),e.querySelectorAll("[style]").forEach(o=>{let n=((o.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");n?o.setAttribute("style",n):o.removeAttribute("style")}),e.removeAttribute("id"),e.removeAttribute("class"),e.removeAttribute("style"),e.querySelectorAll("div").forEach(o=>{!o.children.length&&!(o.textContent||"").trim()&&o.remove()}),e.innerHTML.trim()}function v(r,e){let t=(r.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return t=t.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),t||`Berkas ${String(e+1).padStart(2,"0")}`}function y(){let r=Array.from(document.querySelectorAll(".isidalam")),e=new Set,t=[],a=[];if(r.forEach((o,n)=>{let l=v(o,n);if(e.has(l))return;e.add(l);let i=u(o);if(i.length<20){a.push({title:l,docNo:null});return}t.push({title:l,html:i}),a.push({title:l,docNo:t.length})}),!t.length){let o=document.querySelector("#section-to-print");if(o){let n="Detail Klaim";t.push({title:n,html:u(o)}),a.push({title:n,docNo:1})}}return{sections:t,inventory:a}}var d=r=>r.replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function k(r,e){let t="/assets/images/logo/Kota Jambi.png",a=(i,c)=>`<div class="meta-item"><span class="meta-label">${d(i)}</span><span class="meta-value">${d(c||"\u2014")}</span></div>`,o=e.filter(i=>i.docNo!==null).length,n=e.map(i=>{let c=i.docNo!==null;return`<tr>
        <td class="c-no">${c?String(i.docNo).padStart(2,"0"):"\u2014"}</td>
        <td>${d(i.title)}</td>
        <td class="c-stat">${c?"Ada":'<span class="st-empty">Tidak terisi</span>'}</td>
        <td class="c-ver"><span class="box"></span></td>
      </tr>`}).join(""),l=r.map((i,c)=>`
      <section class="doc">
        <div class="doc-head">
          <span class="doc-num">${String(c+1).padStart(2,"0")}</span>
          <h2>${d(i.title)}</h2>
          <span class="doc-rule"></span>
        </div>
        <div class="doc-body">${i.html}</div>
      </section>`).join("");return`<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<base href="${d(location.origin)}">
<title>Dossier Cetak M-KLAIM \u2014 ${d(p)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,500;8..60,700&display=swap" rel="stylesheet">
<style>
:root{
  --ink:#17212b; --muted:#5b6b78; --accent:#0f766e; --accent-soft:#e6f4f1;
  --paper:#fdfcf9; --rule:#d7dee2; --chip:#f1f5f4;
  --sans:'IBM Plex Sans','Segoe UI',sans-serif; --serif:'Source Serif 4',Georgia,serif;
}
@page{size:A4;margin:14mm 13mm;}
*{box-sizing:border-box;}
html,body{margin:0;padding:0;}
body{
  background:var(--paper); color:var(--ink); font-family:var(--sans);
  font-size:11px; line-height:1.55; padding:22px 26px;
  -webkit-print-color-adjust:exact; print-color-adjust:exact;
}
.cover{
  display:grid; grid-template-columns:64px 1fr; gap:16px; align-items:center;
  border-bottom:3px double var(--ink); padding-bottom:14px; margin-bottom:18px;
}
.cover img{width:64px;height:64px;object-fit:contain;}
.eyebrow{font-size:9px;letter-spacing:.22em;text-transform:uppercase;color:var(--accent);font-weight:700;}
.cover h1{font-family:var(--serif);font-size:22px;line-height:1.15;margin:3px 0 2px;font-weight:700;}
.cover .sub{font-size:10px;color:var(--muted);}
.meta{
  display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 16px;
  border-top:1px solid var(--ink);border-bottom:1px solid var(--rule);
  padding:10px 0;margin-bottom:12px;background:transparent;
}
.meta-item{display:flex;flex-direction:column;gap:2px;min-width:0;}
.meta-label{font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;}
.meta-value{font-weight:600;font-size:11px;overflow-wrap:anywhere;}
/* Lembar Kendali \u2014 inventaris berkas (halaman 1) */
.control{margin:0 0 10px;}
.control h2{
  font-family:var(--serif);font-size:13px;margin:0 0 2px;text-transform:uppercase;
  letter-spacing:.06em;
}
.control .note{font-size:9px;color:var(--muted);margin:0 0 8px;}
.ctl{width:100%;border-collapse:collapse;font-size:9.5px;}
.ctl th{
  border-bottom:1px solid var(--ink);text-align:left;padding:3px 6px;
  font-size:8px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);font-weight:700;
}
.ctl td{border-bottom:1px solid var(--rule);padding:3px 6px;vertical-align:middle;}
.ctl tr:last-child td{border-bottom:1px solid var(--ink);}
.ctl .c-no{width:26px;color:var(--muted);font-variant-numeric:tabular-nums;}
.ctl .c-stat{width:92px;}
.ctl .c-ver{width:74px;text-align:center;}
.st-empty{color:var(--muted);font-style:italic;}
.box{display:inline-block;width:11px;height:11px;border:1px solid var(--ink);vertical-align:-2px;}
.ctl-sum{margin:6px 0 0;font-size:9px;color:var(--muted);}
.doc{margin:0 0 24px;break-inside:avoid-page;}
.doc-head{display:flex;align-items:baseline;gap:10px;margin-bottom:8px;border-bottom:1px solid var(--ink);padding-bottom:5px;}
.doc-num{
  font-family:var(--serif);font-size:15px;color:var(--accent);font-weight:700;
  min-width:24px;
}
.doc-head h2{
  font-family:var(--serif);font-size:13px;margin:0;text-transform:uppercase;
  letter-spacing:.06em;
}
.doc-rule{display:none;}
.doc-body{background:transparent;border:0;border-radius:0;padding:2px 0 0;}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 10px;border:0!important;}
.doc-body th,.doc-body td{border:0!important;border-bottom:1px solid var(--rule)!important;padding:5px 7px;font-size:10px!important;text-align:left;vertical-align:top;overflow-wrap:anywhere;}
.doc-body th{background:transparent!important;font-weight:700;color:var(--ink);border-bottom:1px solid var(--ink)!important;letter-spacing:.04em;text-transform:uppercase;font-size:9px!important;}
.doc-body h1,.doc-body h2,.doc-body h3{font-family:var(--serif);font-size:13px;margin:6px 0;}
.doc-body p{margin:3px 0;}
.doc-body label{display:inline-block;min-width:112px;font-weight:600;color:var(--muted);font-size:9px;letter-spacing:.02em;text-transform:uppercase;}
.doc-body .fv{font-weight:500;color:var(--ink);}
.doc-body img{max-width:100%!important;height:auto!important;}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important;}
.screen-bar{
  position:sticky;top:0;z-index:9;display:flex;justify-content:flex-end;gap:8px;
  background:rgba(253,252,249,.94);backdrop-filter:blur(6px);
  padding:8px 0 12px;margin:-22px -26px 14px;padding-left:26px;padding-right:26px;
  border-bottom:1px solid var(--rule);
}
.screen-bar button{font:inherit;font-size:11px;font-weight:600;cursor:pointer;border-radius:5px;padding:7px 14px;}
.btn-print{background:var(--accent);color:#fff;border:1px solid var(--accent);}
.btn-close{background:#fff;color:var(--ink);border:1px solid var(--rule);}
.sign{display:flex;justify-content:flex-end;margin-top:26px;}
.sign-box{width:230px;text-align:center;font-size:10px;color:var(--muted);}
.sign-space{height:52px;}
@media print{
  .screen-bar{display:none!important;}
  body{padding:0;background:#fff;font-size:10px;}
  .control{break-after:page;}
  .doc{break-after:page;}
  .doc:last-child{break-after:auto;}
  /* Header tabel diulang tiap halaman + baris tidak terpotong di batas kertas */
  .doc-body thead{display:table-header-group;}
  .doc-body tr,.sign-box{break-inside:avoid;page-break-inside:avoid;}
  .meta,.doc-body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}
}
@media screen and (max-width:900px){
  .meta{grid-template-columns:repeat(2,minmax(0,1fr));}
}
</style>
</head>
<body>
<div class="screen-bar">
  <button type="button" class="btn-close" id="close-view">Tutup</button>
  <button type="button" class="btn-print" id="print-view">\u{1F5A8} Cetak</button>
</div>
<header class="cover">
  <img src="${d(t)}" alt="Logo">
  <div>
    <div class="eyebrow">Dossier Cetak \xB7 Detail Klaim</div>
    <h1>${d(p)}</h1>
    <div class="sub">Laporan lengkap berkas klaim &bull; ${new Date().toLocaleString("id-ID")}</div>
  </div>
</header>
<div class="meta">
  ${a("No. RM",s("norm"))}
  ${a("Nama Pasien",s("nama"))}
  ${a("No. Registrasi",s("no_registrasi")||s("reg"))}
  ${a("ID Visit",s("id_visit"))}
  ${a("Tanggal Awal",s("tanggalAwal"))}
  ${a("Tanggal Akhir",s("tanggalAkhir"))}
  ${a("Status",s("status"))}
  ${a("Billing",s("billing"))}
</div>
<section class="control">
  <h2>Lembar Kendali Berkas Klaim</h2>
  <p class="note">Nomor mengacu pada nomor berkas di dossier. Centang kolom Verifikasi setelah berkas diperiksa.</p>
  <table class="ctl">
    <thead><tr><th class="c-no">No</th><th>Nama Berkas</th><th class="c-stat">Status</th><th class="c-ver">Verifikasi</th></tr></thead>
    <tbody>${n}</tbody>
  </table>
  <p class="ctl-sum">${e.length} berkas terdaftar &middot; ${o} berisi &middot; ${e.length-o} tidak terisi</p>
</section>
<main>${l}</main>
<div class="sign"><div class="sign-box">
  <div>Petugas Verifikasi</div><div class="sign-space"></div>
  <div><strong>( .................................... )</strong></div>
</div></div>
</body>
</html>`}function w(){let{sections:r,inventory:e}=y();if(!r.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let t=window.open("","_blank");if(!t){window.alert("Popup diblokir \u2014 izinkan popup untuk membuka dossier cetak M-KLAIM.");return}t.document.open(),t.document.write(k(r,e)),t.document.close();let a=()=>{try{t.focus(),t.print()}catch{}};t.document.getElementById("print-view")?.addEventListener("click",a),t.document.getElementById("close-view")?.addEventListener("click",()=>{t.confirm("Tutup halaman cetak ini?")&&t.close()}),t.addEventListener("afterprint",()=>{t.confirm("Apakah menu print ini akan ditutup?")&&t.close()}),t.setTimeout(a,600)}function A(){let r=Array.from(document.querySelectorAll("button.btn-success")).find(e=>/^printDiv\s*\(/i.test(e.getAttribute("onclick")||""));return r?.parentElement?r.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(e=>e.querySelector("button"))||document.getElementById("SCETAK")||document.body}function g(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor")||document.getElementById("ext-mklaim-print-btn"))return;let r=A(),e=document.createElement("button");e.id="ext-mklaim-print-btn",e.type="button",e.className="btn btn-primary btn-sm",e.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",e.innerHTML="\u{1F5A8} Cetak Rapi M-KLAIM",e.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),w()}),r.appendChild(e)}typeof m.featureModules<"u"&&(m.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let r=()=>g();document.readyState==="complete"?window.setTimeout(r,500):window.addEventListener("load",()=>window.setTimeout(r,500));let e=()=>{let t=document.getElementById("ext-mklaim-print-btn");t?.parentElement&&t.parentElement.lastElementChild!==t&&t.parentElement.appendChild(t)};new MutationObserver(()=>{document.getElementById("ext-mklaim-print-btn")?e():g()}).observe(document.body,{childList:!0,subtree:!0}),window.setInterval(e,1500)}})})();
