"use strict";var __morbis_feature=(()=>{function ft(){return window}var jt="RSUD H. Abdul Manap";function Ot(i){let s=()=>{try{i.focus(),i.print()}catch{}},a=i.document;a.getElementById("btnPrintPdf")?.addEventListener("click",s);let t=Array.from(a.querySelectorAll(".rm-page")),u=a.getElementById("rmSectionSelect"),n=Array.from(a.querySelectorAll(".tab-btn")),r=y=>{u&&(u.value=y),n.forEach(b=>b.classList.toggle("active",b.dataset.target===y)),t.forEach(b=>{let g=y==="all"||b.id===y||b.id.startsWith(`${y}-`);b.classList.toggle("hidden-section",!g)}),i.scrollTo({top:0,behavior:"smooth"})};u?.addEventListener("change",y=>r(y.target.value)),n.forEach(y=>y.addEventListener("click",()=>r(y.dataset.target||"all")));let j=a.getElementById("checkCounter"),o=Array.from(a.querySelectorAll(".rm-checkbox, .vbox")),x=()=>{j&&(j.textContent=`${o.filter(y=>y.checked).length} / ${o.length}`)};o.forEach(y=>y.addEventListener("change",x)),a.getElementById("btnCheckAll")?.addEventListener("click",()=>{o.forEach(y=>y.checked=!0),x()}),a.getElementById("btnResetChecks")?.addEventListener("click",()=>{o.forEach(y=>y.checked=!1),x()}),x();let h=(y,b)=>{let g=a.createElement("button");return g.type="button",g.className="ext-scroll-btn no-print",g.textContent=y,g.addEventListener("click",b),g},D=h("\u2191",()=>i.scrollTo({top:0,behavior:"smooth"})),v=h("\u2193",()=>i.scrollTo({top:a.documentElement.scrollHeight,behavior:"smooth"})),I=a.createElement("style");I.textContent=".ext-scroll-btn{position:fixed;right:14px;width:34px;height:34px;border:1px solid #000;background:#fff;font-size:16px;font-weight:bold;cursor:pointer;z-index:9999;display:flex;align-items:center;justify-content:center}.ext-scroll-btn:first-of-type{bottom:56px}.ext-scroll-btn:last-of-type{bottom:14px}",a.head.appendChild(I),a.body.appendChild(D),a.body.appendChild(v),i.addEventListener("afterprint",()=>{i.confirm("Apakah menu print ini akan ditutup?")&&i.close()})}var gt=ft(),vt=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],st=i=>document.getElementById(i)?.value?.trim()||"",e=(...i)=>{for(let s of i){let a=st(s).replace(/^\s*:\s*/,"").trim();if(a)return a}return"-"};function $t(i){let s=a=>{let t=document.createElement("span");return t.className="fv",t.textContent=a,t};i.querySelectorAll("input").forEach(a=>{let t=(a.type||"text").toLowerCase();if(t==="hidden"){a.remove();return}if(t==="radio"||t==="checkbox"){if(!a.checked){a.remove();return}if(t==="radio"){a.replaceWith(s("\u2713"));return}let n=(a.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,r=>r.toUpperCase());a.replaceWith(s(n?"\u2713 "+n:"\u2713"));return}let u=(a.value||"").trim();u?a.replaceWith(s(u)):a.remove()}),i.querySelectorAll("textarea").forEach(a=>{let t=(a.value||"").trim();t?a.replaceWith(s(t)):a.remove()}),i.querySelectorAll("select").forEach(a=>{let t=(a.options[a.selectedIndex]?.textContent||a.value||"").trim();t?a.replaceWith(s(t)):a.remove()})}function Pt(i){try{if(!i.width||!i.height)return!0;let s=64,a=document.createElement("canvas");a.width=s,a.height=s;let t=a.getContext("2d",{willReadFrequently:!0});if(!t)return!1;t.drawImage(i,0,0,s,s);let u=t.getImageData(0,0,s,s).data,n=0;for(let j=0;j<u.length;j+=4)n+=(u[j]+u[j+1]+u[j+2])/3;let r=n/(s*s);return r<8||r>250}catch{return!1}}function Ut(i){i.querySelectorAll("table").forEach(s=>{if(s.parentElement?.closest("table"))return;let a=Array.from(s.rows),t=a[0]?.cells.length||0;a.length<6||t<4||s.querySelector(".vcol")||a.forEach((u,n)=>{let r=Array.from(u.cells);if(!(!r.length||r.some(j=>j.colSpan>=3)))if(n===0){let j=document.createElement("th");j.className="vcol",j.textContent="Ver",u.appendChild(j)}else{let j=document.createElement("td");j.className="vcol";let o=document.createElement("input");o.type="checkbox",o.className="vbox",j.appendChild(o),u.appendChild(j)}})})}var Rt=/Rincian Biaya|Resume|Telaah|Laboratorium|Radiologi|SPRI|SBPK/i;function Qt(i){i.querySelectorAll(".tabel-juduls").forEach(a=>a.remove()),i.querySelectorAll("h1,h2,td").forEach(a=>{let t=(a.textContent||"").replace(/\s+/g," ").trim();/^RSUD H\.? ABDUL MANAP$/i.test(t)&&a.remove()}),i.querySelectorAll("tr").forEach(a=>{let t=(a.textContent||"").replace(/\s+/g," ").trim();(/^(RSUD H\.? ABDUL MANAP|PEMERINTAH KOTA JAMBI|Jl\. Sk\. Rd\. Syahbudin)/i.test(t)||/^(RINCIAN\s+BIAYA|LAPORAN|FORMULIR)/i.test(t)&&a.querySelector("u,b,strong"))&&a.remove()});let s=i.querySelector("table");s&&Array.from(i.querySelectorAll("hr")).forEach(a=>{s.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_PRECEDING&&a.remove()})}function wt(i,s=!1){let a=i.cloneNode(!0),t=Array.from(i.querySelectorAll("canvas")),u=Array.from(a.querySelectorAll("canvas"));return t.forEach((n,r)=>{let j=u[r];if(j){if(Pt(n)){j.remove();return}try{let o=document.createElement("img");o.src=n.toDataURL("image/png"),o.style.cssText="max-width:100%;height:auto;",j.replaceWith(o)}catch{let o=document.createElement("div");o.className="fv",o.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",j.replaceWith(o)}}}),$t(a),vt.forEach(n=>a.querySelectorAll(n).forEach(r=>r.remove())),a.querySelectorAll("tr").forEach(n=>{let r=Array.from(n.cells);for(let j=r.length-1;j>=0;j--){let o=r[j];if(!(!(o.textContent||"").trim()&&!o.querySelector("img,table,input")))break;o.remove()}}),a.querySelectorAll("[style]").forEach(n=>{let r=((n.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");r?n.setAttribute("style",r):n.removeAttribute("style")}),a.removeAttribute("id"),a.removeAttribute("class"),a.removeAttribute("style"),a.querySelectorAll("div").forEach(n=>{!n.children.length&&!(n.textContent||"").trim()&&n.remove()}),Qt(a),s&&Ut(a),a.innerHTML.trim()}function Yt(i,s){let a=(i.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return a=a.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),a||`Berkas ${String(s+1).padStart(2,"0")}`}var Kt=/^(Konsul|Radiologi)/i;function Dt(){let i=Array.from(document.querySelectorAll(".isidalam")),s=new Set,a=[],t=[];if(i.forEach((u,n)=>{let r=Yt(u,n);if(!Kt.test(r)&&s.has(r))return;s.add(r);let j=wt(u,Rt.test(r));if(j.length<20){t.push({title:r,docNo:null});return}a.push({title:r,html:j}),t.push({title:r,docNo:a.length})}),!a.length){let u=document.querySelector("#section-to-print");if(u){let n="Detail Klaim";a.push({title:n,html:wt(u)}),t.push({title:n,docNo:1})}}return{sections:a,inventory:t}}var M=i=>lt(i).replace(/[&<>"']/g,s=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[s]),Q=i=>M(i).replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).replace(/\n/g,"<br/>"),St=i=>(new DOMParser().parseFromString(i.replace(/src="data:[^"]*"/g,""),"text/html").body.textContent||"").replace(/\s+/g," ").trim(),Bt=i=>{let s=i.split(/[-/]/).map(n=>n.trim());if(s.length!==3)return i;let[a,t,u]=s;return a.length===4?`${a}-${t.padStart(2,"0")}-${u.padStart(2,"0")}`:`${u}-${t.padStart(2,"0")}-${a.padStart(2,"0")}`},Ft=/(?:Tgl|Tanggal)\.?\s*Masuk(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,Gt=/(?:Tgl|Tanggal)\.?\s*(?:Keluar|Pulang)(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,yt=/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]{8,})/gi;function Jt(i,s){let a=[],t=i.map(D=>({t:D.title,x:St(D.html)})),u=D=>{let v=[],I=new Set;return t.forEach(y=>{let b=new RegExp(D.source,D.flags),g;for(;g=b.exec(y.x);){let C=y.t+"|"+g[1];I.has(C)||(I.add(C),v.push({t:y.t,d:D===yt?g[1]:Bt(g[1])}))}}),v},n=u(Ft);new Set(n.map(D=>D.d)).size>1&&a.push({level:"warn",title:"Tanggal masuk berbeda antar berkas",detail:n.map(D=>`${D.t} ${D.d}`).join(" \xB7 ")+" \u2014 samakan sebelum berkas dikirim ke verifikator."});let r=u(Gt);if(n.length&&r.length){let D=n.map(I=>I.d).sort()[0],v=r.map(I=>I.d).sort().pop();v<D&&a.push({level:"warn",title:"Tanggal keluar lebih awal dari tanggal masuk",detail:`Masuk ${D} \xB7 Keluar ${v}.`})}let j=u(yt);new Set(j.map(D=>D.d)).size>1&&a.push({level:"warn",title:"Nomor SEP berbeda antar lembar",detail:j.map(D=>`${D.t} ${D.d}`).join(" \xB7 ")});let o=[/^SEP$/i,/SBPK/i,/Resume/i,/Rincian Biaya/i],x=s.filter(D=>D.docNo===null&&o.some(v=>v.test(D.title)));x.length&&a.push({level:"warn",title:"Berkas inti belum terisi",detail:x.map(D=>D.title).join(", ")+"."});let h=t.find(D=>/Rincian Biaya/i.test(D.t));return h&&!/Total\s+(Biaya|Transaksi|Resep|Jasa)/i.test(h.x)&&a.push({level:"warn",title:"Rincian biaya tanpa baris total",detail:"Tidak ditemukan Total Biaya/Transaksi/Resep pada lembar Rincian Biaya."}),["Laboratorium","Radiologi"].forEach(D=>{let v=t.find(I=>new RegExp(D,"i").test(I.t));v&&v.x.length<60&&a.push({level:"info",title:`Lembar ${D} hanya lampiran gambar`,detail:"Tidak ada teks hasil yang bisa dicocokkan otomatis \u2014 cocokkan manual dengan Resume dan Rincian Biaya."})}),a}var Ht="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAIAAAABc2X6AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAb0klEQVR4nOV7d3gUVdv+MzM72zebLdnNJtn03kgIJQQIHRN6AAEVBHn15QWliSIoiqIiIKDYX6VbEJCOdOkkhJJCIL1v+ibZXmZ3yu+PVX4ImLKU77uu7772n/Oc8zznvvfMmVMHYRgGHgaHwzFp/Jjeffo+NPd/M3Jzcg4c+f2fclkdeCb16vPeBx8+AUpPFqtWvttBLvrUePwvQUct7MK3BQd/K7/wFKg8Ot7pNX2oOqnjMp0LLtfXn63LvdeCAMLAw3v+/yxejh7VaZnOBT+Iwb49Kgz1tWatKznUNyFaFnSy5tr8HhO/KzgUKwvKCB64vfiEkyYnBA90lVl65btlSc/naEsPV2XdjfNs6CAUkN3l51f2eTFPW36oKvPtpOfNTtuR6qzFCc9uLzoxPWIEC8WaLG1rbu5anfLK1sJjpfo6l2+af+8TtdfdIO9OH54YknpXCQAkeIVlBA/8uN/LA1RxDDA/P/NekjJi/+iPUn3i/xUz+tX4iTOj0pQ88Yo+M+fEjrs3ziDfhCF+iWI2/70+s+bGjQeA5yNGLE6ckqyMnt9jUpin79z4CQny0PeTZw/0if137Fi1UHHXd0ni1AR5iBvku9HCCp54SeJULsaeGj5ET5hDxD7tduP63N0AECn1V/FlIw8uGeKXWNBa0XvPHM1Le3O15ZN/f++HYW/6bZ08KrBvub4u2TsGQxDq7wNhsnd0ub6ur3cMhiAAIMB5vRThesLsyv255HSkxN9OOlzJWGngcHUSiiCD/BLe6zPzYn1+m83wc9kf9D8Mrg+iGy3cYjP8XHJ6hH8vL54kzFOd6BW2teiYhSQAwEcgRxAkWKwSswUNllaKYVqsOg+2ABAAAECgvyruWFUWzTBRkoD7wvZXxR2vyXZQzhhpEABU6OvGBKWU6WpduZsGLeCy2K02vSt5p72aYqjVKf/GUVZGSOr44AFn63O7rrZ7ggHgVlvVkapMmqEBYGfxSY251WXXE6Yfi07MjEpvtRkDPbzZKOYj9GqzG+86pqhiZ0Slidj8/qpYABjkE//NoIVcDHfQZH9V7AsRI8UcoSurWFcbLPYtN/zZV4ftW5irLcsISXUlGYAvbx08U3vDlZx3fmO9pa1bErrdh5O9o4cfWPz8iVUj7hkAclrKfrhztJ8qtsrYECL2a/zXAQxBLzfccuXiCNbHO2pb0bErDQUuVXbK8e+48S9EjizV1fbxjtpedPxyw62/BNdUGuodNOXy3TNqVX+f+Pq/XpAAIMJ5ERL/UYfe/LHoxPjgAd3l3723NJ/FmXx8pdZmAIDMxtsu4+WGW42W1symwrcuf6MjzKMOvzkqsN+vpX8YnbYSneaTGz+J2PxV2ds/y/stVhYULwsGgOzm4rlnN3jxPfeUXxDivI15v8VIAxPkIefrcrOa7tSYmk0OW6Wx8d2sHzAEa7C07am4oBBIyw31ACDlivrtnddqNx6vvZ7kFdpdwUgHc+nVH656/8OPllz6emPe3kR5iIjN7270p4bbbdXthOmXke88FzFi1cp3O5gRd7WFvx78ej9VzGOi9/gx+vDSYzXXulKye490iZ5ss9NuUXpS8OajwR7dUNE9wdeaHQVtzm5SerJI9mZ3S/D/udWS+4JJu5UkbO75tpXlW7X1blf9KHBn8QAATotR/+18hs1DU59jaIqhaYahgWEYmmZoyvUDmmEY6q7lr1zaqCmz6Zrs+jZ5RE+Oh9TlDjTFMHd9GVwoDp+y+PFKdcFNwY72JtRTAQDIjaP3mBFAALHolZbmu8mHAwWQYnRzXn5+W4JKhiDIPSEAAOhmxnYYYeRqp8QP9Q7iShT/EKjbcFOwQB0uePnTh2Y5dC2GK3tFrdV/NzMAYGlt5Mu875UXLAss1lRGhEa4yvCMzYh3MGNsxXSNXhWXoQIAwEFRJpbAoQpzqCId6hi+fxSCYe7RBrcFdwC2RAFjXiUfsDstxspTv0Rl/OdeIw9AdCdbQ9hUPQcDQGt5Ln7xJ5LGHc8s5ub8jvI9vDU5bAyTMXZoKICGAubGXj2wzL6xMPFNDOe4Qe/xC/4nlJ/8OXz0rAftipi+JYc3y8IT2EJPTmgihCSwEWADAvGpAFBTliM6t0XxZx8BBAEJkJKGvDJNiSA43g0aT0lwe0WB2D+CMOm157apuVdkHA0gtJ7wrbEmS3pMCE2bXnp0e9TE/wAAIH/r97ywns7gHpXZh+XX9nowjrt2zNzuHpOnJLju6gm5hBggmTlhsZnLuTt7v02SJ4+fWvfbqRlcSV99dZFnYNSDvgiGcVMydPFDDOd2KEovclAE4P7/pet4GhOPloIsWduWL+dtnDbJ5FJLUiKSEgEAiwVjR9m+ff2HQPtX5ad+6SAILvTExi6sn7q60TOQpGlG5ucemSfewgzDMAWfbv6mmcdlKJrX1DxWp+9PUh4ACAszSCVXlIojfL5tzdLc2XOqdZXTJMEdLVG4fhHMS+srS28KfdzZ0IKn0MI15w/Mn3aJx2UcTmlZ2XKjoS+XY/QQVXqIKjgck16fUlb2jtPpiWGwYa2h6fKOrsQUhney+dwBnrhgr/avevV0AiDVNa8iCC4UaDzZ+TLjcZnudwlyVSjQoAhSXTsHAJHL6NTA/ZS709Uu4skKNjVUjR90BwAMxgSHQ8XhGoVIMTsnl7zEcV7i49mVHtYsNtdIEAEGUxwAPDPU0FLozm5z1/FkBetrS2OiSQAwmuIxFsFmm1n1lUSFj+2WyJYrslcoscpGNm7GWHaTKR4AoiJIc2P1E6X0ZF9aTqtFJKIBgKRECEqhqBPsFGNnUW0oYwVahTE2FAUCQWiS9AAAnM2gtOWJUnqyLcz18GxrQwEAx3UMjVEUjsg5LC8LO8LBiXXiSjuiQCjgMwwLx3UAYLUiwJbcF6ROm/uQ0O7iyQqWBMfm5eMA4OlxkyS5TgefUMSyE9oFCTX8nhpujzpHcJzDISKdXLH4BgDk5eOSkPuHpQuNOw3mx7Z4fjyPNEORDEOjLPY9JpomSZ5UcenmgAw4IxQUC/l3CLsfIIzTX4Kr2xGasqEygvAg7GKBoFDILwOA01fDpINj742MIIieaDISLWKh72Oh+hgEMxRpObguwFuu9U9B1X/S1R3eFCLltqqS2rwXZ169mJLs8FdvraxeaLH4OxxmFPMFAJrCnU4+l1Mb4P8DAJSUsUrwN/wAqW+/VabPJmnCTxQdqRhCMxQA1LblFOsuMwydoEhXiiPcZvsYHmnSakwID+w1cChLk++yMAydFOQdk5QsaS9Txvb75sy8xiYMw6yhIWuVin2AWK02pdWmAMSqVB4IDv4MQ20GI/rJz5P9+k+obsoq0WVSjLPBWnpUs2lX/iIOar5Q/dmeyg8Mpjqadv5esUGjy3ObrfstbG2uJW1mnkKNi6QWvtfPWaUUS4bmnfcMS8QFYtI7Ys+V2x4x/RlNmWrUu0u/t741eWtsNCmXnZPLzt0XqroG+2DrBNnozwGQQGVyXXVJpfEGQVowJ+IrvhPtQWBc86/F4hZS02puGOI3W4RJn65ghsHtej99cfaBHU6ng5IHOtOnK1pPOz19ay+fajywCWT+5mdeCGFbtBadMCwJAFTj1n1yfkDUmY8njqyIiiDvLnUqq1gHTvrcsL2pnjDdtQBq1BXqHU1x4iE1xjwexRNQRRRBoxiK0iiDIhyKc6l626zE/z5VwX5MexK3IVNbKZfLRqaPriwvKz21OSw8vLH2lpDPGztuXJtWW5q1u0XqI9CdsIm9eAp/APBNGWegRn2SlUkdyJZyNAhl0ZEhjKy3d1Kq+p69C6U4IoaxnKr9dpjPv260HHJgE49qj4fwElhc7VDv6fW24or2awjifk/snmAMAQCoQ2UOGsPEXoBgZ06e6D9wYEN9PY/PDw+PqKquzrpypV+/FIDiHgFKs9msuXmAHvkqirEAAMFYqsRUgFQOofFiSuu4wx6sAsVYpdpLUyM+ymv6PUI6gKCs7YCHcIMmBczL0uxKj3xTzY9m4dzHLxhBENfO270LbSH+51/bi2cUpvTFSDuLdko8JSPT0m4XFMTGxYeGhVVXV4s8RJOnTrt0/nz/gakRBJFvqDZI/3bMx2UM/nC1Dh4iGAAGB73C4XiEi/v5yOKKmv4AAItT5ynwS/aZAgAh3gPvLcx6YCfgn44HOxGM4zhBOABAzvMEAKPDDABS7p/R8xySUWL72PRnjEajSCRCUTQ4OMRVj1zuJRSJ2Gy22k9NEATGwjCCc+7vSyAT4hNLH8xk3n7oxgWH4wEAPrI4ABio7j0mYCGJhNfYQeJx/+0BAPBgIwCgI8wAoBLIAcBut7sjGP76q6KlAQBwq7XymYC+fBZyRuOa66L7q5GxXnYpm92kdZzRYmaK44E6+4usvnzMaqROtTjanJgI48pxyglU9f0zZO5imUZC5Ou4CR0QAACFSDorMuNCPVFT83AZCh5KMfTttkoAiJYGAkDHFyA6EiwUCU0mU6JXOABcbboDAFESvERHWElXSORSG+/vHpyzuvu2TjEAHAAA/kaXQ9t5SqeYbtBBJ4I7hb+IVdBabnLa/YVeCr6kVauVy+UdlO9IcGJiz9ycm6mDBquFXufr8ymG5rHQncMVbXbqEVmKW7dYQF6LD3rEOD4CTIgjZzU5AJCiigOAG9evJfXu3YFLR+/3vsn9rmZmAsBQv8R2wnSl4RYAqIWsNjv9iL9IOKmnlDQmeETB8TIcAI5UZwLAcHVPALiWfbXjG8AdtbDcy0urbQGA0YH9dhSf2l12LtU3QcZD381upx7t5iEhC1imPqkkMps5KW4HQRFIUuD1Zu2lhgIMQdIDkxmGMZlMQqGwA69OxuGAgMCqqsr0wGQhi/tr6R+fDpgbIuZa5wa5zdIFa+vLSOn30fSRZnBfcJwMF7PRr/NPUAw9yCfeRyC/lZ8XG9fJcUQngseOn3Bg/75Fry+ZGJq6s/jUj0Un58SNr9A7p55ocZsoALwm+nmmBBqROLcjIADD/DhOmvzu9mEAmBWVBgBHDh2aM+/Vjh07a+HAQE1tDUVR8+Im7Cw+9WnOr7NjRkdJ2cPUvAqDu3cfHKYpom8dFFbEmuTm8QFALwXbm49tKzymMWvlXI8p4cNsNpvJZOr4FQ1dmVqmpY86dvTI2PETUn3iLjYUbL59ZG58xsaBskYLSbt1v8XpFNAFXB5mDCWWNaCqjgsbLezz1R61JhvvnpGcwxKnBSyxU44Pr+0EgPnxE/kszs6ftk169tlOa+9c8LARIxfNf3X02HEf9J095MDi97K3PRs2VM4T//e2adV1XafuD8X7smnL1N/HMftaGWXHJU1WuGIFALhnMwXGBK0T4dgn13+pMjXJuKIFCZMdDkduzs0XZ73UadX/eDHtXpw8fsxqtWZMmjz+6NuHqzJnRAzfOXKFk2ZyWhyd+j4UgoZPw6zv1gmeI/ymd9dXxFGqPZLK9fU9ds22ksSmga8tSJi8dfMPsbFxfZKTO3Xv0mppZFr64gWvjUxL25Q6/2xdzo8lZ8YEpkwJH9pbyVl7U+/GPOQV+g8Ggf1tVx3mG91ylPNDZiXsJWlq1unVVpLo6RU6Lz6jrbW1tKR49suvdCVClwQjCPLagkWfb1j/znvvb+g/b875ja+cXR8vD4mUBvT15ryT1f6PdzkeBj/isr//BQAIlw1ni7y74QnQ1/dfHEy47Mp3V5rucDF82/DlLBTb8Onaha8v6WKELj3SLnz/3beRUVEDBw2aevz9veUXwsS+V5792ovnyQB0/QsIwlxBFgzE6UYAMKPB1/EELadLi1sOSzQ67GMBLvul5PT0Ux8zAN8MWjQ3fsLhgwftdtuUac91kUA3BNM0/cbihW8uWy6SSwb+9lpea0UfZeSpCRvEbMGxauuM0y1EZ/OvcCjc5LOsgfIyEtxJXiduOcXBbFsBLcrnyDp25LJE02K3+Iji/9DcGH1kOUE5X4ke9f2wpZUVFZu//2712odfr3kouiEYAPR63Yrly9at36hnbAP2vVZlbErxjj42bp2YI7zWTJToHP98UeluhQAMhDe93IO1u1S5EfEIcRAmDk/cgYeQrQgQ9wZAzmlyxh5dbiGJ9IA+h8asthrN7yxbum7jZ3x+N+bk3RMMAJWVFV9t+nzt+o0aq3bI/kW15pZEecjRcWt9BHKagUsNtjL9gzd47oe3ds0I1uoddj8th9dxSbW418TITUK21+HKy8+d/NBKEsP8Eg+P/QQlYenri5etWOHj070N+m4LBoA7twu2bdm8eu2nTYQu/dDSQl2NWijfN+rD3sooi5N+/VLbbxX/eCCG0s5e9JkFqi1D5TfzZStRcUc3vHGMG6eYgCCsTbl73rjyHcXQ44NSdqWtREhm+dI3Xp2/MDQsrLvkuyo48/wBX/+ogOBIV/LO7dubv//uo0/WOFjM1OPvn9bc5GL4+gFz58VPRABIGgCA9bClp9Nht2fJ2JgVAA45Q+u4ng+tTiGIGBmyQiGINDos/zm7flfZOQBYEJ+xYeBrNov1nWVL5y9cHBYeDgAkSZ469EXv1BleXl6PU/D1S7tl7S81sN/tO/wNHMcBoKa6+tM1q5eveM/b12fl1a1rbv5CMXS6f+//Dn1DLVLSDPyhsa3L0bc+MErHOg9OEv3qrWAKcTGFPfivoAnek5JU01EEO1+XM/vM2ipTs4DF/XrwoplRaRpN7ZqPP1q+4l0/PzUAVFcU1mXPRsm6fjM0SNfu9XRVsMloqjqmDvM13NQk+6fs8A8MB4DqqqovN302fsLE1MGDL9TnzT6zptLYJMJ5K/vMnN9jEhvDDQ568x1Tq51io39jwzB0qvKn+4w83DNOkcFliQCg2dq+PPP7HUUnaWB6KyJ2jng7Uhpw8cL5Qwf2L1j0ekBgIMMwWX98qzQv9ZNbcg2vJ4/e0BUV3RAMAFePzEuUfAsANVqRXvoV38PXdGsKov40r8hqMBgWLVlCosz72du+yN/voMkwsc+q5NnPhg3FEJRiIKvRvqXQlN1sd9WGIMwL/sPvRlYJ4xJVU2MV43CUa3JYvsjft+7mLqPTJsS5K/vMXJQwhSapLz7bwGZz4oPbmNYd/oPO1t54u5f3fjaL0ZlQc8it0PCufp7QJcHNzc31NSWakv1pQZtclsY2rKZFmBxlsDuQXO1ERDFv757dM16c1bdfv6L2mrcyvztSlQUAURL/NxKnPh85gouxAaBc7zxYaTlea7vebFsWM0oljAuTDomUp8n5wQDQYtV9W3Dwq1sHWu1GFEGeDx/2Scq//YSK3JycLT/8N33USLFpYy91JoLA0avCMcl/frqWXyVBQ7aLpOEhoSEsFv5IgimK2rfjbX/Obwp+ja/X37ri5QL2gDgHw0BBJR4f4ixu8HH6fZVb0FRdXf3qawt8fH2zGu+surb9ZO0NBhgvrvilqLRZ0elR0kCXO0kzJG12Pb00Q1+oy9tadOy38gt2yokiyLjAlPeTX+ohD21rbf3qy01SqTQxWiQ3vaEUG/kcBgBMVqSqkRUf8v8X5BY7UtkosuLJ3MC3+yR3tDfYSQvr9fo7WZskls9CvA13jXnleKgvKeQxDANz13uO6W9P62u3Eegd0yyfuLd2/fwjh8N9Zc5/pDJZnrZsY+6ePeXnCcqJACTIQyeHDhoX3D9GFkzS5JWGgkOVl/dVXNSYtQDAxfBpYUOX9JwaKwu2WMzbtmxubGiY+tzz7SVrE2S7a5sxsw2pbWZlpNoAoKASD/AmPfh/kqcZyNNEsQM/SkyegKId7Ux26ZFuaWkuyVwZjG+Ri0mdGa2oZ/WKcADAkStcXy/q8i2OB59OSya8pVRhvZoJ+EKq7LFl8/cCPn/GrJd8ff20Nt32whPbi44X/vVFoa9AZnJYjc4/zyOiJP4vRafPikr34nnq9bqfdu6oramZ+dK/HOYKpPbVKJ/6Q5e4UUHkN/sEFI3MzTBHB5Lw11MGAOVNMoP4/d6D57iGj47RjZdWaeF1bd5cFT+vphnzkVEBSmrPOd6NInZTG/ryOOvRy9xxqfaB8YTFjtxunxCcvAHB8J92bNfr9eMmZCT3SwEEclpKfi09+1v5hWpTMwD4C70mhw6aFj6slzISAaSkuHj3rl9I0vn8jBc9xR6ll1+P8dzLwWHfBa6TRAqrWBEBpLeUFvHp/nGO8npWaR0rNZ64rX8+etAGL0UnGwnuCAYAp9N59dQ6c9WaEJVNq8eiApwUhazfJRTwmMIq1svjLCeyuO/NNuEspr6V34QviEl5k8PlHjl0MPtqVkhI6LiMDLXanwHI15ZRDN1TEY4AYjDofz9y5Mb1a2Fh4VOmPcfl8fIufSGzrJGJTD8cFtgIJL2f/U4lfuIqZ2QfYkgS4a+grhayVTK6uEHp3+erxOQJXeffbcEuFORfL7nwSvSAD5srDvaQbKvXYtVN2NkbHMKJyD1pfwXVO9rBwSFIRZY2SE2ieSGJ85Teqory8sOHDtRpNJGRUSPT0j3E4j9On7qWnS0UCkaNHpvUu7fRaCy8tpXdtiHat37fOV5NM0bRSEaq7fhVbmMrOm6gPSXW0WZklZFvCensW+XYqBlblUqf7pJ3RzAAMDSNoCgA3Li8m988z1+uO5fDbjeitU2s4hqWxINeOdu0abdgepo1SEXVtnBbkTEsr6mhMcMkEklJcfGpkyeMRsOwYSN69+1LEERxwWVHy16BdW+4r+FSPvvyLY7Bgqhk9Mx069aj/PED7c06NCXWcbsuiBe1LbrHIJvNhuM4i+XOab6bgu9FY4Om9OKcnt4n9GbkZDY3XE0aLYjZimoN6MVcdnoKMWWIjcViAKC6kWOgIhBeBMJWACCMs52xlXPpO2G+FgyFAxd5PcMdJ65yWw0oAyDiM1IPOrUHoVZSJitaZJ6dMHy9WNzRQvIpCQYAhmGuXdjB1y4NV2kr6llqJfX5bkGoH1Vcy+KxmVfGWRZ87rnqZaPNjnhJaLGQdh22MwBaHeogkXotllnA5nEZnRGdm2HZtEdgsKCDE4mEMKe/ksrXhPLCv4lLGvHoPOFxCXahtVVbdGlFEHurzIO0E0hJLevwFe6ofkRFHXb6OjdcTY4ZYP9yj0CrRwNVFADgLCbYh2KzmSOXuNNG2KoaWMmxDg7O2AlELKQTwpy1Wn4z+42eQ97i8x/bl7yPU7AL5SX5TfkrwsXHPPj0nSr8+FUOGwcMZdoM6PxnLfM3irk4SDzoUD+yrI6llNBFNSyZBx0RQCIINLWiC6eYRXymRY/XOJ4L6v2Brzrw8dJ7/IJdKLqdrStd74MdUsmchBMx25BbFbhESNsdiNmGVDWwKAZ0RlTTjC2aaj6Xw5k6zMZlM1w2U9vC1aJTvWOXBodGPwliT0qwC3WamrrCnUzbr0GSYonoz4MZowWtbsRUcqrNgIb7k641YrsJrdbFIF4vBMa96O3dyfnLo+DJCnaBYZjKirL2uvOM+RpjKwJCA5QRgAHMA9h+CD8aEfaVqYcEh4RCtza43cL/A+p9uOR8npnAAAAAAElFTkSuQmCC",Wt=[[/^Triage/i,{id:"triage",code:"TRIAGE",tab:"Triage IGD",option:"Triage \u2014 Pengkajian Awal IGD"}],[/PENGKAJIAN INSTALASI GAWAT DARURAT/i,{id:"pengkajian-igd",code:"PENGKAJIAN IGD",tab:"Pengkajian IGD",option:"Pengkajian IGD \u2014 Lembar Pengkajian Instalasi Gawat Darurat"}],[/^SEP$/i,{id:"rm-01",code:"RM. 01",tab:"RM. 01 SEP/CBG",option:"RM. 01 \u2014 SEP &amp; Berkas Klaim Individual (INA-CBG)"}],[/^Surat (?:Rencana )?Kontrol/i,{id:"surat-kontrol",code:"SURAT KONTROL",tab:"Surat Rencana Kontrol",option:"Surat Rencana Kontrol \u2014 BPJS VClaim"}],[/^SBPK$/i,{id:"rm-02",code:"RM. 02",tab:"RM. 02 SBPK",option:"RM. 02 \u2014 Surat Bukti Pelayanan Kesehatan (SBPK)"}],[/^SPRI$/i,{id:"rm-03",code:"RM. 03",tab:"RM. 03 SPRI",option:"RM. 03 \u2014 Surat Pengantar Rawat Inap (SPRI)"}],[/^Rincian Biaya/i,{id:"rm-05",code:"RM. 05",tab:"RM. 05 Billing",option:"RM. 05 \u2014 Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi"}],[/^Resume/i,{id:"rm-06",code:"RM. 06",tab:"RM. 06 Resume",option:"RM. 06 \u2014 Ringkasan Pulang (Discharge Summary)"}],[/^Telaah/i,{id:"rm-07",code:"RM. 07",tab:"RM. 07 Telaah",option:"RM. 07 \u2014 Formulir Telaah Resep, Obat &amp; Edukasi"}],[/^Radiologi/i,{id:"rm-08",code:"RM. 08",tab:"RM. 08 Radiologi",option:"RM. 08 \u2014 Hasil Pemeriksaan Radiologi"}],[/^Laboratorium/i,{id:"rm-09",code:"RM. 09",tab:"RM. 09 Lab",option:"RM. 09 \u2014 Hasil Pemeriksaan Laboratorium Patologi Klinik"}],[/Konsul/i,{id:"rm-10",code:"RM. 10",tab:"RM. 10 Konsul",option:"RM. 10 \u2014 Lembar Konsultasi Antar-Spesialis"}],[/^Persetujuan Tindakan/i,{id:"form-konsent",code:"RM. 19A",tab:"RM. 19A Persetujuan",option:"RM. 19A \u2014 Persetujuan Tindakan Kedokteran"}],[/^Anestesi/i,{id:"form-anestesi",code:"ANESTESI",tab:"Anestesi",option:"Anestesi \u2014 Rekam Pelaksanaan Anestesi"}],[/^Fisioterapi/i,{id:"form-fisioterapi",code:"FISIOTERAPI",tab:"Fisioterapi",option:"Fisioterapi \u2014 Assesmen &amp; Terapi"}],[/^Pengkajian Hemodialisa/i,{id:"form-hemodialisa",code:"HEMODIALISA",tab:"Hemodialisa",option:"Hemodialisa \u2014 Pengkajian &amp; Sesi"}],[/^Operasi/i,{id:"form-operasi",code:"OPERASI",tab:"Operasi",option:"Operasi \u2014 Laporan Pelaksanaan"}],[/^Surat Kematian/i,{id:"form-kematian",code:"KEMATIAN",tab:"Surat Kematian",option:"Surat Kematian \u2014 Surat Keterangan"}],[/^Permintaan Terapi/i,{id:"form-terapi",code:"TERAPI",tab:"Permintaan Terapi",option:"Permintaan Terapi \u2014 Rehabilitasi Medik"}],[/^Uji Fungsi/i,{id:"form-uji-fungsi",code:"UJI FUNGSI",tab:"Uji Fungsi",option:"Uji Fungsi \u2014 Lembar Uji Fungsi"}],[/^Partograf/i,{id:"form-partograf",code:"PARTOGRAF",tab:"Partograf",option:"Partograf \u2014 Pemantauan Persalinan"}],[/^Laporan Tindakan/i,{id:"form-laporan-tindakan",code:"LAPORAN TINDAKAN",tab:"Laporan Tindakan",option:"Laporan Tindakan \u2014 Pelaksanaan Tindakan"}],[/^Bon Makan/i,{id:"form-bon-makan",code:"BON MAKAN",tab:"Bon Makan",option:"Bon Makan \u2014 Pasien / Pendamping"}],[/^PEMERIKSAAN$/i,{id:"form-pemeriksaan",code:"PEMERIKSAAN",tab:"Pemeriksaan",option:"Pemeriksaan \u2014 Hasil Diagnostik"}]],_t=(i,s)=>Wt.find(([a])=>a.test(i))?.[1]??{id:`doc-${s+1}`,code:"FORMULIR RM KLAIM JKN",tab:`RM. ${String(s+1).padStart(2,"0")} ${i}`,option:`RM. ${String(s+1).padStart(2,"0")} \u2014 ${i}`},G=i=>`<div class="rm-code-top">${i}</div>
<div class="kop-surat"><img class="kop-logo" src="${Ht}" alt="Logo Kota Jambi"><div class="kop-text">
<div class="kop-line-1">PEMERINTAH KOTA JAMBI</div>
<div class="kop-line-2">DINAS KESEHATAN</div>
<div class="kop-line-3">RUMAH SAKIT UMUM DAERAH H. ABDUL MANAP</div>
<div class="kop-line-4">Alamat : Jl. Sk. Rd. Syahbuddin Kel. Mayang Mangurai Kec. Alam Barajo Kota Jambi 36129 &#9742; (0741) 670459</div>
<div class="kop-line-5">email : rsud_ham.jambi@yahoo.co.id, rsud@jambikota.go.id, website : rsud.jambikota.go.id</div>
</div></div><div class="kop-double-rule"></div>`,L=(i,s,a=!1)=>`<tr><td class="lbl">${i}</td><td class="col">:</td><td class="val">${a?`<strong>${Q(s)}</strong>`:Q(s)}</td></tr>`,mt="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDEuNjMgMzEuMDIiPgogIDxkZWZzPgogICAgPHN0eWxlPgogICAgICAuY2xzLTEsIC5jbHMtMiB7CiAgICAgICAgZmlsbDogIzAwYTU1MTsKICAgICAgfQoKICAgICAgLmNscy0zLCAuY2xzLTQgewogICAgICAgIGZpbGw6ICMwMjNmODc7CiAgICAgIH0KCiAgICAgIC5jbHMtNSB7CiAgICAgICAgZmlsbDogI2ZmZjsKICAgICAgfQoKICAgICAgLmNscy01LCAuY2xzLTQsIC5jbHMtMiB7CiAgICAgICAgZmlsbC1ydWxlOiBldmVub2RkOwogICAgICB9CiAgICA8L3N0eWxlPgogIDwvZGVmcz4KICA8ZyBpZD0iTGF5ZXJfMS0yIiBkYXRhLW5hbWU9IkxheWVyIDEiPgogICAgPGc+CiAgICAgIDxnPgogICAgICAgIDxnPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTAyLjkxLDE1LjFjLS44Mi0yLjQtMS42NS00LjgtMi40Ny03LjJsLTEuODYsMi4zMnY0Ljg5YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjksMC0xMS4zNywwLTE3LjA2aC42NGMuMzEsMCwuNTcsMCwuODcuMDUsMS4wMi4xOSwxLjQ5LjksMS40OSwxLjl2NS4zMmw1LjMxLTYuMzlDMTA0LjY0LDAsMTA1LjA3LDAsMTA2LjI5LDBoLjQxYy0xLjQsMS44LTIuOCwzLjU5LTQuMiw1LjM5LDEuNDMsMy44OSwyLjg3LDcuNzgsNC4zLDExLjY3aC0uNDdjLS42OSwwLTEuMzUuMDMtMS45OC0uMjYtLjQzLS4yLS43OC0uNS0xLjA0LS44OC0uMTgtLjI2LS4yOS0uNTMtLjM5LS44MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTExNy45NCwxNC44NmMtLjc1LDEuNjItMi41MywyLjIzLTQuNDMsMi4yMy0yLjk0LDAtNC41NS0xLjYxLTUuMjctMy43Mi0uNS0xLjQ2LS42Ni0zLjI4LS4zOS00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjcxLTMuMTUtMy45OC0yLjgyLTQuNzQtLjAyLS4xNS41NS0uMjQsMS4yNC0uMjYsMi4wNWg1LjI3WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTIyLjkxLDE1LjAzYy41My4zNSwxLjE3LjUzLDEuOTEuNTNzMS4zNS0uMTgsMS43My0uNTVjLjM4LS4zNi41Ny0uODMuNTctMS40LDAtLjQtLjA2LS43My0uMTktMS0uMTMtLjI3LS4yOS0uNS0uNS0uNjktLjItLjE5LS40NC0uMzUtLjctLjQ3LS4yNy0uMTItLjUzLS4yNC0uODEtLjM0LS42MS0uMjItMS4xNy0uNDYtMS42OC0uNzEtLjUxLS4yNi0uOTUtLjU1LTEuMzItLjg3LS4zNy0uMzItLjY2LS42OS0uODctMS4xMS0uMjEtLjQyLS4zMS0uOS0uMzEtMS40NiwwLS42Ni4xMi0xLjI0LjM1LTEuNzMuMjMtLjUuNTYtLjkxLjk4LTEuMjQuNDItLjMzLjkxLS41OCwxLjQ5LS43NS41Ny0uMTcsMS4yLS4yNSwxLjg3LS4yNS44MiwwLDEuNTkuMTMsMi4zMS40MS43Mi4yNywxLjI0Ljc3LDEuNTgsMS41LS45Ny42OC0xLjYuMTktMi4yMS0uMDMtLjExLS4wNi0uMjMtLjExLS4zNS0uMTYtLjM0LS4xMi0uNzEtLjE4LTEuMTEtLjE4LS4zMiwwLS42My4wNC0uOTMuMTEtLjMuMDctLjU2LjE5LS43OS4zNC0uMjMuMTUtLjQuMzUtLjUzLjU4LS4xMy4yMy0uMTkuNTItLjE5Ljg1LDAsLjU1LjE3Ljk5LjUxLDEuMjkuMzQuMzEuNzYuNTYsMS4yNy43Ny41MS4yLDEuMDYuNCwxLjY0LjU4LjU5LjE4LDEuMTQuNDMsMS42NC43My41MS4zMS45My43MSwxLjI3LDEuMjEuMzQuNS41MSwxLjE3LjUxLDIuMDIsMCwuNjQtLjEzLDEuMjItLjM3LDEuNzMtLjI1LjUxLS41OS45NC0xLjAzLDEuMjktLjQzLjM1LS45NS42Mi0xLjU2LjgxLS42LjE5LTEuMjUuMjgtMS45NC4yOC0xLjE2LDAtMi4xNS0uMjEtMi45Ny0uNjQtLjgyLS40Mi0xLjQzLTEuMDctMS44MS0xLjk1LjMyLS4yLjgzLS41LDEuNDktLjI2LjQ0LjE2LjcuNDksMS4wNy43NFoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE1Mi43MSw2LjcyYzAtLjctLjE2LTEuMTctLjUtMS40My0uMzMtLjI1LS44NS0uMzgtMS41Ni0uMzgtLjU4LDAtMS4xMi4xMy0xLjYyLjM4LS41LjI1LS44Ni41My0xLjA5Ljg1djkuMDZjMCwuOTUtLjQ1LDEuNjItMS40MiwxLjgxLS4yOS4wNS0uNTMuMDUtLjgzLjA1aC0uNjFWMGguNjFjLjMsMCwuNTQsMCwuODMuMDUuOTcuMTgsMS40Mi44NSwxLjQyLDEuODF2MS4yNmgwdjEuNThjLjM3LS40NS45Mi0uODQsMS42NC0xLjE4LjczLS4zNCwxLjU3LS41MSwyLjU0LS41MSwxLjE2LDAsMi4wMi4yOSwyLjU5Ljg2LjU2LjU3Ljg1LDEuNDYuODUsMi42NnYxMC41NGgtLjYxYy0uMywwLS41NCwwLS44My0uMDUtLjk3LS4xOC0xLjQyLS44NS0xLjQyLTEuODFWNi43MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE2NC44Nyw5LjI5Yy0uMzIuMTYtLjcuMjktMS4xNC4zOC0uNDMuMDktLjg1LjItMS4yNi4zMi0uODEuMjMtMS4zOC41OS0xLjc0LDEuMDctLjM1LjQ4LS41MywxLjExLS41MywxLjg4LDAsLjg3LjE3LDEuNTEuNTIsMS45MS4zNS40Ljg5LjYsMS42My42LjU2LDAsMS4wNi0uMTMsMS41LS4zOS40My0uMjYuNzctLjYzLDEuMDEtMS4wOXYtNC42N2gwWm0uMjIsNS44N2MtLjMyLjYtLjgxLDEuMDYtMS40NSwxLjQxLS42NC4zNC0xLjQuNTEtMi4yNy41MS0xLjMyLDAtMi4zMS0uMzMtMi45Ni0uOTktLjY1LS42Ni0uOTgtMS41OC0uOTgtMi43NnMuMjYtMi4wOC43Ny0yLjcxYy41MS0uNjMsMS4zMS0xLjExLDIuMzktMS40NC4zNS0uMTIuNzMtLjIxLDEuMTItLjI3LjM5LS4wNy43OC0uMTMsMS4xNi0uMi4zOC0uMDYuNzQtLjE0LDEuMDktLjI0Ljc5LS4yMi44Ny0uNDIuODgtLjk4LDAtLjI2LDAtLjUyLDAtLjc3LDAtLjcxLS4xNi0xLjI1LS40OC0xLjYxLS4zMi0uMzYtLjkzLS41NS0xLjg0LS41NS0uNjgsMC0xLjI2LjEzLTEuNzUuNC0uOTUuNTItMS4zNy45NC0yLjYuMzQuNDctLjgxLDEuMTEtMS40LDEuOTItMS43Ni44MS0uMzYsMS42OS0uNTMsMi42NC0uNTMuNjgsMCwxLjMyLjA1LDEuOTIuMTQuNi4wOSwxLjEzLjI4LDEuNTcuNTQuNDQuMjcuNzkuNjUsMS4wNSwxLjEzLjI2LjQ5LjM5LDEuMTIuMzksMS45MXYxMC4zM2MtLjA3LDAtLjQ1LDAtLjc3LDAtMS4zNiwwLTEuNzgtLjcyLTEuODEtMS45MVoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE3Ny43OSwxNi4xNmMtLjQ1LjMzLS45MS41Ni0xLjM5LjctLjQ4LjE0LTEuMS4yMS0xLjg3LjIxLTEuMjIsMC0yLjE4LS4zNS0yLjg3LTEuMDQtLjY5LS42OS0xLjA0LTEuNjUtMS4wNC0yLjg4VjQuMzloLS40NmMtLjc5LS4wMi0xLjIxLS4xNS0xLjIxLTEuMzhoMS42N1YwaC42MWMuMywwLC41NCwwLC44My4wNS45Ny4xOCwxLjQyLjg1LDEuNDIsMS44MXYxLjE1aDEuNjdjLjc5LjAyLDEuMjEuMTUsMS4yMSwxLjM4aC0yLjl2OC43N2MwLC43Ni4xNywxLjM1LjUsMS43Ny4zMy40Mi44Ni42NCwxLjU4LjY0LjI2LDAsLjUtLjAyLjctLjA1Ljg0LS4xMywxLjI1LS4wMSwxLjU3LjY1WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTk4Ljc4LDYuNzJjMC0uNy0uMTctMS4xNy0uNS0xLjQzLS4zMy0uMjUtLjg1LS4zOC0xLjU2LS4zOC0uNTgsMC0xLjEyLjEzLTEuNjIuMzgtLjUuMjUtLjg2LjUzLTEuMDkuODV2OS4wNmMwLC45NS0uNDUsMS42Mi0xLjQyLDEuODEtLjI5LjA1LS41My4wNS0uODMuMDVoLS42MVYzaC42MWMuMywwLC41NCwwLC44My4wNS45MS4xNywxLjM2Ljc4LDEuNDEsMS42NGgwYy4zNy0uNDUuOTItLjg0LDEuNjQtMS4xOC43Mi0uMzQsMS41Ny0uNTEsMi41NC0uNTEsMS4xNiwwLDIuMDIuMjksMi41OS44Ni41Ni41Ny44NSwxLjQ2Ljg1LDIuNjZ2MTAuNTRoLS42MWMtLjMsMC0uNTQsMC0uODMtLjA1LS45Ny0uMTgtMS40Mi0uODUtMS40Mi0xLjgxVjYuNzJaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xNDIuMTEsMTQuODZjLS43NSwxLjYyLTIuNTMsMi4yMy00LjQzLDIuMjMtMi45NCwwLTQuNTUtMS42MS01LjI3LTMuNzItLjUtMS40Ni0uNjYtMy4yOC0uNC00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjctMy4xNS0zLjk4LTIuODItNC43NC0uMDItLjE1LjU1LS4yNCwxLjI0LS4yNiwyLjA1aDUuMjdaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xODYuMjYsOS4yOWMtLjMyLjE2LS43LjI5LTEuMTQuMzgtLjQzLjA5LS44NS4yLTEuMjYuMzItLjgxLjIzLTEuMzkuNTktMS43NCwxLjA3LS4zNS40OC0uNTMsMS4xMS0uNTMsMS44OCwwLC44Ny4xNywxLjUxLjUyLDEuOTEuMzUuNC44OS42LDEuNjMuNi41NiwwLDEuMDYtLjEzLDEuNS0uMzkuNDQtLjI2Ljc3LS42MywxLjAyLTEuMDl2LTQuNjdoMFptLjIyLDUuODdjLS4zMi42LS44MSwxLjA2LTEuNDUsMS40MS0uNjQuMzQtMS40LjUxLTIuMjcuNTEtMS4zMiwwLTIuMzEtLjMzLTIuOTYtLjk5LS42NS0uNjYtLjk4LTEuNTgtLjk4LTIuNzZzLjI2LTIuMDguNzctMi43MWMuNTItLjYzLDEuMzEtMS4xMSwyLjM5LTEuNDQuMzUtLjEyLjczLS4yMSwxLjEyLS4yNy4zOS0uMDcuNzgtLjEzLDEuMTYtLjIuMzgtLjA2Ljc0LS4xNCwxLjA5LS4yNC43OS0uMjIuODctLjQyLjg4LS45OCwwLS4yNiwwLS41MiwwLS43NywwLS43MS0uMTYtMS4yNS0uNDgtMS42MS0uMzItLjM2LS45My0uNTUtMS44NC0uNTUtLjY4LDAtMS4yNi4xMy0xLjc1LjQtLjk1LjUyLTEuMzcuOTQtMi42LjM0LjQ3LS44MSwxLjExLTEuNCwxLjkyLTEuNzYuODEtLjM2LDEuNjktLjUzLDIuNjQtLjUzLjY4LDAsMS4zMi4wNSwxLjkyLjE0LjYuMDksMS4xMy4yOCwxLjU3LjU0LjQ0LjI3Ljc5LjY1LDEuMDUsMS4xMy4yNi40OS4zOSwxLjEyLjM5LDEuOTF2MTAuMzNjLS4wNywwLS40NSwwLS43NywwLTEuMzYsMC0xLjc4LS43Mi0xLjgxLTEuOTFaIi8+CiAgICAgICAgPC9nPgogICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTUxLjczLDcuNzJjMS44OC0uMDYsMi40MS0xLjcsMi40MS0zLjA3LDAtMS40NC0uMTUtMy4wNy0yLjEtMy4wN2gtMi41MXY2LjE0aDIuMlptLS4wMyw3LjljLjkzLDAsMS42Mi0uMjYsMi4wNi0uNzguNDQtLjUyLjY2LTEuMzYuNjYtMi41MiwwLTEuNDctLjItMi45Ny0yLjIyLTMuMjdoLTIuNjh2Ni41N2gyLjE3Wm0tNS4xNywxLjQ3Vi4wNGg1Ljg2YzMuMzEsMCw0Ljc5LDIuMTIsNC40OSw0LjktLjE0LDEuMjgtLjYyLDIuNi0xLjkxLDMuMjksMy4xNi45NiwzLjE2LDUuNTgsMS4zLDcuNTgtLjguODUtMi4wNywxLjI4LTMuODMsMS4yOGgtNS45MVoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im02MC42Ni4wNGg1Ljc5Yy44NywwLDEuNjEuMDksMi4yMi4yNy42MS4xOCwxLjEuNDQsMS40Ny44LjM3LjM2LjY0LjgxLjgxLDEuMzUuMTcuNTQuMjUsMS4xOC4yNSwxLjksMCwxLjE2LS4wOSwyLjEzLS4yNywyLjktLjE4Ljc4LS40NywxLjQxLS44OSwxLjg4LS40Mi40Ny0uOTcuODItMS42NSwxLjAyLS42OC4yMS0xLjUzLjMxLTIuNTUuMzFoLTIuMnY0LjY2YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjgsMC0xMS4zNywwLTE3LjA1aDBabTQuODgsOC45M2MuNDgsMCwuODktLjA2LDEuMjItLjE5LjMzLS4xMy42LS4zNC44Mi0uNjMuMjItLjMuMzctLjY5LjQ3LTEuMTguMS0uNDkuMTQtMS4xLjE0LTEuODNzLS4wNC0xLjMtLjEyLTEuNzZjLS4wOC0uNDYtLjIxLS44Mi0uMzctMS4wOS0uMTctLjI3LS4zOS0uNDUtLjY2LS41Ni0uMjctLjEtLjYxLS4xNi0xLjAxLS4xNmgtMi4zN3Y3LjM5aDEuODhaIi8+CiAgICAgICAgPHBhdGggY2xhc3M9ImNscy0zIiBkPSJtNzQuNC4wNGguNjNjLjMxLDAsLjU2LDAsLjg2LjA1LDEuMDEuMTksMS40OC44OSwxLjQ4LDEuODh2MTAuODhjMCwyLjgzLTEuNjcsNC4yNS01LjAyLDQuMjUtLjE2LDAtLjMxLDAtLjQ2LDAtMS4wOS0uMDItMi4wNi0uMjctMi44OS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxLjMuMi42NC4zNSwxLjAyLjQ0LjgxLjIsMS45Ni4yMSwyLjc0LS4yMi43OS0uNDQuODYtMS4yNy44Ni0yLjA1Vi4wNFoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im04Mi41OSwxNC44NGMuNTUuMzcsMS4yMy41NiwyLjA1LjU2LjM5LDAsLjc2LS4wNiwxLjExLS4xOC4zNS0uMTIuNjYtLjI5LjkzLS41Mi4yNy0uMjIuNDgtLjQ5LjYzLS44Mi4xNS0uMzIuMjMtLjY4LjIzLTEuMDksMC0uMzYtLjA2LS42Ny0uMTctLjk1LS4xMS0uMjctLjI3LS41Mi0uNDYtLjczLS4xOS0uMjItLjQyLS40MS0uNjktLjU5LS4yNy0uMTgtLjU1LS4zNi0uODYtLjU1LS42OS0uNC0xLjMzLS43OS0xLjkyLTEuMTctLjU5LS4zOC0xLjEtLjc5LTEuNTMtMS4yMi0uNDMtLjQzLS43OC0uOTEtMS4wMy0xLjQzLS4yNS0uNTItLjM3LTEuMTQtLjM3LTEuODYsMC0uNjIuMTEtMS4xOC4zMy0xLjcuMjItLjUyLjU0LS45Ni45Ny0xLjM0LjQzLS4zOC45NS0uNjgsMS41Ni0uODkuNjEtLjIyLDEuMzEtLjMyLDIuMS0uMzIsMS4wMywwLDEuOTIuMjEsMi42Ni42My43NC40MiwxLjI0LDEuMDIsMS41LDEuNzgtLjg2LjM3LTEuNDkuMTctMi4xOS0uMzUtLjQ0LS4yOS0uOTctLjQ0LTEuNTgtLjQ0LS44NSwwLTEuNTIuMjEtMS45OS42Mi0uNDcuNDItLjcxLDEtLjcxLDEuNzYsMCwuNjMuMTgsMS4xNS41NCwxLjU3LjM2LjQyLjgxLjc5LDEuMzUsMS4xMy41NC4zNCwxLjEzLjY2LDEuNzYuOTcuNjQuMzEsMS4yMi42NywxLjc2LDEuMDguNTQuNDEuOTkuOSwxLjM1LDEuNDcuMzYuNTcuNTQsMS4yOS41NCwyLjE1LDAsLjY3LS4xMywxLjMtLjM5LDEuODctLjI2LjU3LS42MywxLjA3LTEuMTEsMS40OC0uNDguNDItMS4wNy43NC0xLjc3Ljk4LS43LjI0LTEuNDkuMzYtMi4zOC4zNi0xLjE0LDAtMi4xNC0uMjUtMy4wMS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxWiIvPgogICAgICA8L2c+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTExMy4wOCwyOS4xM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNy0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOVptLTUuNTYsMi4zOHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjE4LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjUtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTQuNy0yLjk1aC0xLjAxbC0xLjE2LDQuMTMtMS4xOC00LjEzaC0xLjA1bDEuNyw1LjMxLS4wOC4zNmMtLjAyLjExLS4wNS4yLS4xLjI5LS4wNS4wOS0uMTEuMTYtLjE4LjIxLS4wOC4wNS0uMTcuMDgtLjI5LjA4LS4xNCwwLS4yNi0uMDItLjM3LS4wNS0uMTEtLjAzLS4xOS0uMDYtLjI1LS4wOS0uMDYtLjAzLS4wOS0uMDUtLjA5LS4wNWwuMTEuODZzLjA0LjAyLjExLjA1Yy4wNy4wMy4xNy4wNi4zLjA5LjEzLjAzLjI4LjA0LjQ2LjA0LjIyLDAsLjQtLjA0LjU1LS4xMi4xNS0uMDguMjctLjE5LjM3LS4zMi4xLS4xNC4xOC0uMy4yNS0uNDguMDctLjE4LjEzLS4zOC4yLS41OWwxLjcyLTUuNThoMFptLTUuMDgsNS4zM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjEyLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTYuMzEtMi4zNWMwLC4yMy0uMDIuNDMtLjA3LjYtLjA1LjE2LS4xMi4zLS4yMi40Mi0uMDguMTEtLjE4LjE5LS4yNy4yNS0uMS4wNi0uMTkuMTEtLjI5LjEzLS4wOS4wMy0uMTguMDUtLjI1LjA1LS4wNywwLS4xMi4wMS0uMTUuMDFoLTEuMDl2LTIuOTZoMS4wOWMuMDgsMCwuMTcsMCwuMjcuMDIuMTEuMDIuMjIuMDUuMzMuMS4xMS4wNS4yMi4xMy4zMi4yNC4xLjExLjE4LjI2LjI0LjQ0LjA2LjE4LjA5LjQyLjA5LjdoMFptMS4yNCwwYzAtLjM5LS4wNS0uNzMtLjE0LTEuMDEtLjA5LS4yOC0uMjItLjUyLS4zOC0uNzEtLjE2LS4xOS0uMzUtLjM0LS41Ni0uNDUtLjIxLS4xMS0uNDUtLjE5LS42OS0uMjQtLjI1LS4wNS0uNS0uMDctLjc3LS4wN2gtMi4yM3Y3LjJoMS4ydi0yLjI5aDEuMDdjLjIxLDAsLjQyLS4wMS42NC0uMDQuMjEtLjAzLjQyLS4wOS42My0uMTguMjEtLjA5LjQxLS4yMy42LS40Mi4yLS4xOC4zNS0uNDMuNDYtLjczLjExLS4zLjE3LS42Ni4xNy0xLjA2aDBabTU1LjU0LDMuMTRjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xMy4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOS0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOC45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM4LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS00LjE3LTQuMjRsLS4xNS0uOTdjLS4wNS0uMDMtLjA5LS4wNi0uMTMtLjA4LS4wNC0uMDItLjA3LS4wNC0uMS0uMDUtLjAzLS4wMS0uMDctLjAzLS4xMi0uMDQtLjA2LS4wMS0uMTEtLjAyLS4xNS0uMDMtLjA0LDAtLjA5LDAtLjE0LDAtLjA5LDAtLjE3LDAtLjI1LjAxLS4wOC4wMS0uMTYuMDMtLjI0LjA3LS4wOC4wMy0uMTUuMDgtLjIyLjE1LS4wOC4wOC0uMTUuMTUtLjIuMjMtLjA1LjA4LS4wOS4xNS0uMTIuMjEtLjAzLjA2LS4wNS4xMS0uMDYuMTR2LS43MmgtMS4wNHY1LjMzaDEuMDR2LTMuMDNjMC0uMDksMC0uMTksMC0uMzEsMC0uMTEuMDItLjIzLjA0LS4zNS4wMy0uMTIuMDctLjI0LjEyLS4zNi4wNi0uMS4xMi0uMTguMjEtLjI2LjA4LS4wOC4xOC0uMTQuMjktLjE4LjExLS4wNC4yNC0uMDcuMzgtLjA3LjE3LDAsLjMzLjAzLjQ2LjA5LjEzLjA2LjI2LjEzLjM3LjIzaDBabS01LjE1LDIuNjVjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzgtLjQxdi4zMWMwLC4wNSwwLC4xLjAxLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjgzLjQ1YzAsLjEyLS4wMy4yMy0uMS4zMi0uMDcuMDktLjE2LjE2LS4yNy4yMi0uMTEuMDYtLjI0LjEtLjM3LjEzLS4xMy4wMy0uMjcuMDQtLjQuMDQtLjI2LDAtLjQ4LS4wMy0uNjctLjA5LS4xOS0uMDYtLjMzLS4xNS0uNDQtLjI1LS4xLS4xMS0uMTUtLjI0LS4xNS0uMzksMC0uMS4wMi0uMTkuMDUtLjI4LjAzLS4wOC4wNy0uMTUuMTItLjIxLjA1LS4wNi4wOS0uMS4xMi0uMTMuMDQtLjAzLjA1LS4wNS4wNi0uMDVoLjkxYy4yMywwLC40Mi4wMy41Ny4wNy4xNS4wNC4yNi4wOS4zNS4xNi4wOC4wNy4xNC4xNC4xOC4yMi4wMy4wOC4wNS4xNi4wNS4yNWgwWm0tLjEzLTQuMDNjMCwuMjQtLjA0LjQ0LS4xMi42MS0uMDguMTctLjIuMy0uMzYuMzktLjE2LjA5LS4zNi4xNC0uNi4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMTksMCwuMzYuMDQuNDkuMS4xMy4wNi4yNC4xNS4zMi4yNS4wOC4xLjE0LjIyLjE3LjM1LjA0LjEzLjA1LjI2LjA1LjM5aDBabTEuMTcsMy45OGMwLS41LS4xNy0uODYtLjUzLTEuMS0uMzYtLjI0LS44OS0uMzYtMS41OS0uMzUtLjA4LDAtLjE3LDAtLjI4LDAtLjExLDAtLjIyLDAtLjM0LDAtLjEyLDAtLjIyLS4wMi0uMzItLjA0LS4xLS4wMi0uMTgtLjA1LS4yNC0uMS0uMDYtLjA1LS4wOS0uMTEtLjEtLjE5LDAtLjA5LjAzLS4xNi4xLS4yMS4wNi0uMDUuMTUtLjA4LjI2LS4xLjExLS4wMi4yNC0uMDMuMzgtLjAzLjE0LDAsLjI5LDAsLjQ2LDAsLjQ0LDAsLjgyLS4wOCwxLjEzLS4yMy4zMS0uMTUuNTQtLjM2LjcxLS42NS4xNi0uMjguMjQtLjYyLjI0LTEuMDF2LTEuNzNoLS41M3MtLjA5LDAtLjEzLDBjLS4wNSwwLS4wOS4wMS0uMTQuMDMtLjA1LjAyLS4wOS4wNi0uMTMuMTEtLjA0LjA1LS4wNi4xMS0uMDcuMTcsMCwuMDYtLjAxLjExLDAsLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjM5LS4xNi0uMTYtLjA0LS4zNC0uMDYtLjU1LS4wNi0uMTQsMC0uMjguMDEtLjQzLjA1LS4xNS4wMy0uMy4wOS0uNDUuMTctLjE1LjA4LS4yOC4xOS0uNC4zMy0uMTIuMTQtLjIxLjMxLS4yOC41Mi0uMDcuMjEtLjEuNDYtLjEuNzYsMCwuMi4wMy4zOC4wOC41NC4wNS4xNi4xMi4yOS4xOS40LjA4LjExLjE1LjIuMjMuMjcuMDguMDcuMTQuMTMuMTkuMTYuMDUuMDMuMDguMDUuMDguMDUsMCwwLS4wNCwwLS4xLjAxLS4wNy4wMS0uMTUuMDMtLjI0LjA3LS4xLjAzLS4xOS4wOC0uMjkuMTUtLjEuMDctLjE4LjE2LS4yNC4yNy0uMDYuMTEtLjEuMjYtLjEuNDMsMCwuMTMsMCwuMjQuMDQuMzMuMDMuMDkuMDguMTcuMTQuMjMuMDYuMDYuMTIuMTEuMTkuMTQuMDcuMDQuMTMuMDYuMi4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA5LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjguMTcuMi40Mi4zNS43NC40Ny4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTYuMjUuMDVjMCwuMTItLjAzLjIzLS4xLjMyLS4wNy4wOS0uMTYuMTYtLjI3LjIyLS4xMS4wNi0uMjQuMS0uMzcuMTMtLjE0LjAzLS4yNy4wNC0uNC4wNC0uMjYsMC0uNDgtLjAzLS42Ny0uMDktLjE5LS4wNi0uMzMtLjE1LS40NC0uMjUtLjEtLjExLS4xNS0uMjQtLjE1LS4zOSwwLS4xLjAyLS4xOS4wNi0uMjguMDMtLjA4LjA3LS4xNS4xMi0uMjEuMDUtLjA2LjA5LS4xLjEyLS4xMy4wNC0uMDMuMDUtLjA1LjA1LS4wNWguOTFjLjIzLDAsLjQyLjAzLjU3LjA3LjE1LjA0LjI2LjA5LjM1LjE2LjA4LjA3LjE0LjE0LjE4LjIyLjAzLjA4LjA1LjE2LjA1LjI1aDBabS0uMTMtNC4wM2MwLC4yNC0uMDQuNDQtLjEyLjYxLS4wOC4xNy0uMi4zLS4zNi4zOS0uMTYuMDktLjM2LjE0LS41OS4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMiwwLC4zNi4wNC40OS4xLjEzLjA2LjI0LjE1LjMyLjI1LjA4LjEuMTQuMjIuMTcuMzUuMDQuMTMuMDUuMjYuMDUuMzloMFptMS4xNywzLjk4YzAtLjUtLjE3LS44Ni0uNTMtMS4xLS4zNi0uMjQtLjg5LS4zNi0xLjU5LS4zNS0uMDgsMC0uMTcsMC0uMjgsMC0uMTEsMC0uMjIsMC0uMzQsMC0uMTIsMC0uMjItLjAyLS4zMi0uMDQtLjEtLjAyLS4xOC0uMDUtLjI0LS4xLS4wNi0uMDUtLjA5LS4xMS0uMS0uMTksMC0uMDkuMDMtLjE2LjEtLjIxLjA2LS4wNS4xNS0uMDguMjYtLjEuMTEtLjAyLjI0LS4wMy4zOC0uMDMuMTQsMCwuMjksMCwuNDYsMCwuNDQsMCwuODItLjA4LDEuMTMtLjIzLjMxLS4xNS41NC0uMzYuNzEtLjY1LjE2LS4yOC4yNC0uNjIuMjQtMS4wMXYtMS43M2gtLjUzcy0uMDksMC0uMTMsMGMtLjA1LDAtLjA5LjAxLS4xNC4wMy0uMDUuMDItLjA5LjA2LS4xNC4xMS0uMDQuMDUtLjA2LjExLS4wNy4xNywwLC4wNi0uMDEuMTEtLjAxLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjQtLjE2LS4xNi0uMDQtLjM0LS4wNi0uNTUtLjA2LS4xNCwwLS4yOC4wMS0uNDMuMDUtLjE1LjAzLS4zLjA5LS40NS4xNy0uMTUuMDgtLjI4LjE5LS40LjMzLS4xMi4xNC0uMjEuMzEtLjI4LjUyLS4wNy4yMS0uMS40Ni0uMS43NiwwLC4yLjAzLjM4LjA4LjU0LjA1LjE2LjEyLjI5LjE5LjQuMDguMTEuMTUuMi4yMy4yNy4wOC4wNy4xNC4xMy4xOS4xNi4wNS4wMy4wOC4wNS4wOC4wNSwwLDAtLjA0LDAtLjEuMDEtLjA3LjAxLS4xNS4wMy0uMjQuMDctLjEuMDMtLjE5LjA4LS4yOS4xNS0uMS4wNy0uMTguMTYtLjI0LjI3LS4wNi4xMS0uMS4yNi0uMS40MywwLC4xMywwLC4yNC4wNC4zMy4wMy4wOS4wOC4xNy4xNC4yMy4wNi4wNi4xMi4xMS4xOS4xNC4wNy4wNC4xMy4wNi4xOS4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA4LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjhzLjQyLjM1Ljc0LjQ3Yy4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTQ2LjE4LS40di0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTIuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNy0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM2LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMjQtMS4yNmMtLjA1LjA2LS4xMS4xMy0uMTguMTgtLjA3LjA2LS4xNS4xMS0uMjQuMTYtLjExLjA1LS4yMi4wOS0uMzIuMTEtLjEuMDItLjIxLjAzLS4zMi4wMy0uMjEsMC0uMzktLjA1LS41NC0uMTUtLjE1LS4wOS0uMjYtLjIzLS4zNS0uNC0uMDktLjE3LS4xNS0uMzctLjItLjU5LS4wNC0uMjMtLjA2LS40Ny0uMDctLjc0LDAtLjE1LDAtLjMxLjAyLS40OS4wMS0uMTguMDQtLjM2LjA4LS41My4wNC0uMTguMS0uMzQuMTgtLjQ5LjA4LS4xNS4xOS0uMjcuMzMtLjM2LjE0LS4wOS4zMS0uMTQuNTItLjE0LjE5LDAsLjM0LjAzLjQ4LjA4LjEzLjA1LjI0LjEzLjMyLjIyLjA4LjA4LjEzLjE4LjE4LjI4LjA0LjEuMDcuMjEuMDguMzIuMDEuMTEuMDIuMjIuMDIuMzJ2Mi4xN2gwWm0xLjA0LDEuMjZ2LTcuMjNoLTEuMDR2Mi40cy0uMDEtLjAyLS4wNC0uMDZjLS4wMy0uMDQtLjA3LS4wOS0uMTItLjE1LS4wNi0uMDYtLjE0LS4xMi0uMjMtLjE4LS4xLS4wNi0uMjItLjExLS4zNi0uMTUtLjE0LS4wNC0uMzItLjA2LS41MS0uMDYtLjI4LDAtLjUyLjA1LS43My4xMy0uMjEuMDktLjM5LjIxLS41NC4zNi0uMTUuMTUtLjI4LjMyLS4zOC41MS0uMS4xOS0uMTguMzktLjI0LjYtLjA2LjIxLS4xLjQyLS4xMy42Mi0uMDMuMjEtLjA0LjQtLjA0LjU4LDAsLjI5LjAyLjU3LjA3Ljg0LjA1LjI3LjEyLjUyLjIxLjc1LjEuMjMuMjMuNDMuMzkuNi4xNi4xNy4zNS4zLjU3LjQuMjMuMDkuNDkuMTQuNzkuMTMuMTksMCwuMzYtLjAzLjUyLS4wOC4xNS0uMDUuMy0uMTIuNDMtLjIxLjEzLS4wOS4yNy0uMi4zOS0uMzJ2LjUzaC45OVptLTYuNDYtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDcuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMTQtMi4xNWMwLC4xOS0uMDIuMzYtLjA3LjQ5LS4wNS4xMy0uMTIuMjQtLjIxLjMzLS4xMS4xMS0uMjQuMTgtLjM4LjIyLS4xNC4wNC0uMjkuMDctLjQ0LjA3LS4xNSwwLS4yOSwwLS40MiwwaC0xLjAzdi0yLjIxaDEuMDNjLjE2LDAsLjMyLDAsLjQ4LjAyLjE2LjAxLjMuMDQuNDQuMDkuMTMuMDUuMjUuMTIuMzQuMjIuMDguMDkuMTUuMi4xOS4zMy4wNS4xMi4wNy4yNy4wNy40NGgwWm0tLjI2LTMuMDZjMCwuMi0uMDQuMzctLjEuNS0uMDcuMTMtLjE1LjIzLS4yNi4zLS4xLjA4LS4yMS4xMy0uMzMuMTYtLjExLjAzLS4yMi4wNS0uMzEuMDYtLjEsMC0uMTcuMDEtLjIyLDBoLTEuMDd2LTIuMDVoMS4wN3MuMSwwLC4xNywwYy4wNywwLC4xNS4wMS4yNC4wMi4wOC4wMS4xNy4wMy4yNS4wNi4wOC4wMy4xNS4wNy4yLjEyLjEyLjA5LjIxLjIuMjcuMzMuMDYuMTMuMDkuMjkuMDkuNDhoMFptMS41LDMuMDRjMC0uMTQtLjAxLS4yNy0uMDQtLjQxLS4wMy0uMTQtLjA4LS4yNy0uMTUtLjM5LS4wNy0uMTMtLjE2LS4yNC0uMjgtLjM1LS4xNC0uMTMtLjMtLjIzLS40Ny0uMjktLjE3LS4wNy0uMzUtLjExLS41Mi0uMTQuMTItLjA0LjIzLS4wOS4zNS0uMTUuMTItLjA2LjIyLS4xMy4zMi0uMi4xLS4wOC4xOC0uMTYuMjUtLjI2LjA4LS4xNC4xNS0uMjkuMi0uNDcuMDUtLjE4LjA4LS4zOC4wOC0uNjEsMC0uMjYtLjA0LS41LS4xMy0uNy0uMDgtLjItLjItLjM3LS4zNC0uNTEtLjE0LS4xNC0uMy0uMjQtLjQ4LS4zMi0uMjItLjEtLjQ2LS4xNy0uNy0uMi0uMjQtLjAzLS41MS0uMDUtLjc5LS4wNWgtMi4yN3Y3LjJoMi4yNWMuMTcsMCwuMzYsMCwuNTUtLjAxLjE5LS4wMS4zOC0uMDMuNTctLjA3LjE5LS4wNC4zNy0uMS41NS0uMTcuMTctLjA4LjMzLS4xOC40Ny0uMzEuMTUtLjE2LjI3LS4zMi4zNi0uNS4wOS0uMTguMTQtLjM2LjE4LS41NS4wMy0uMTkuMDUtLjM3LjA1LS41NmgwWm0xMTIuNDksMi4xN3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS01LjM3LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMxLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzQuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4zNCw2Ljd2LTMuNTZjMC0uMTIsMC0uMjYtLjAyLS40MS0uMDEtLjE1LS4wNC0uMy0uMDgtLjQ0LS4wNC0uMTUtLjExLS4yOS0uMTktLjQzLS4wOC0uMTQtLjItLjI1LS4zNC0uMzYtLjEzLS4wOS0uMjgtLjE2LS40NC0uMi0uMTYtLjA0LS4zMS0uMDYtLjQ3LS4wNi0uMjEsMC0uNC4wMy0uNTYuMDktLjE2LjA2LS4zLjEyLS40Mi4yMS0uMTIuMDgtLjIxLjE3LS4yOS4yNS0uMDguMDktLjEzLjE2LS4xNy4yMy0uMDQuMDctLjA2LjExLS4wNy4xMiwwLS4wMy0uMDItLjA4LS4wNS0uMTUtLjAzLS4wNy0uMDgtLjE1LS4xNS0uMjQtLjA2LS4wOS0uMTUtLjE3LS4yNi0uMjUtLjA5LS4wNi0uMTktLjExLS4zLS4xNS0uMTEtLjA0LS4yMS0uMDctLjMyLS4wOC0uMTEtLjAyLS4yMS0uMDItLjMtLjAyLS4yMiwwLS40Mi4wMy0uNTguMDktLjE3LjA2LS4zLjEzLS40Mi4yMi0uMTEuMDktLjIuMTgtLjI3LjI4LS4wNy4wOS0uMTEuMTgtLjEzLjI1di0uNzJoLTEuMDN2NS4zM2gxLjAzdi0zLjI3YzAtLjIyLjAyLS40LjA1LS41NS4wMy0uMTQuMDgtLjI2LjE0LS4zNS4wNS0uMDkuMTItLjE2LjE4LS4yMi4wOC0uMDguMTYtLjEzLjI2LS4xOC4xLS4wNC4yMS0uMDcuMzQtLjA3LjE2LDAsLjI5LjAyLjM4LjA2LjEuMDQuMTguMDguMjQuMTUuMDguMDcuMTQuMTUuMTkuMjUuMDUuMDkuMDguMjEuMS4zNC4wMi4xMy4wMy4yOS4wMy40N3YzLjM3aDEuMDF2LTMuMjdjMC0uMTIsMC0uMjUuMDEtLjM4LjAxLS4xMy4wNC0uMjYuMDktLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA4LS4wOC4xOC0uMTQuMjktLjE4LjEtLjA0LjIxLS4wNi4zMy0uMDYuMTMsMCwuMjQuMDEuMzUuMDQuMS4wMy4yLjA4LjI5LjE2LjA3LjA3LjEzLjE0LjE2LjIxLjA0LjA3LjA2LjEyLjA3LjE2LjAxLjA1LjAzLjExLjA0LjE4LjAxLjA3LjAyLjE2LjAzLjI0LDAsLjA5LjAxLjE4LjAxLjI3djMuMzdoMS4wMVptLTkuMTItMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE4Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wOC4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEuMDEuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTUuMDMtMi42MnYtNC41OGgtMS4ydjQuNThjMCwuMTYsMCwuMzMtLjAxLjUsMCwuMTctLjAzLjM0LS4wNy40OS0uMDMuMTYtLjA5LjMtLjE2LjQzLS4xLjE1LS4yMy4yNy0uMzkuMzUtLjE2LjA4LS4zNS4xMi0uNTYuMTItLjE2LDAtLjMxLS4wMi0uNDQtLjA1LS4xNC0uMDMtLjI2LS4wNy0uMzctLjExLS4xLS4wNC0uMTktLjA4LS4yNS0uMTEtLjA2LS4wMy0uMDktLjA1LS4xLS4wNmwuMjYsMS4wNHMuMDMuMDEuMDguMDRjLjA1LjAzLjEyLjA2LjIyLjA5LjEuMDMuMjIuMDcuMzUuMDkuMTQuMDMuMjkuMDQuNDcuMDQuMDcsMCwuMTYsMCwuMjgsMCwuMTIsMCwuMjUtLjAzLjM5LS4wNi4xNC0uMDMuMjgtLjA4LjQzLS4xNS4xNC0uMDcuMjctLjE2LjM5LS4yNy4xMi0uMTEuMjMtLjI0LjMxLS4zOC4wOS0uMTQuMTYtLjMuMjItLjQ5LjA2LS4xOC4xLS40LjEyLS42NS4wMy0uMjUuMDQtLjU0LjA0LS44N2gwWm0zMS4xNiwyLjYydi0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTEuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIyLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMS0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOC0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptMzIuNTEsMHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjM1LTEuNTljMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDYtLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMS0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzItLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDguMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjE1LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMyLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzMuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4xMiw1LjE5YzAtLjI2LS4wNi0uNDgtLjE3LS42Ny0uMTEtLjE5LS4yNi0uMzUtLjQ2LS40OC0uMTktLjEzLS40MS0uMjUtLjY1LS4zNS0uMTItLjA1LS4yNC0uMS0uMzctLjE2LS4xMi0uMDUtLjI0LS4xMi0uMzUtLjE5LS4xMS0uMDctLjE5LS4xNS0uMjYtLjI0LS4wNy0uMDktLjEtLjItLjEtLjMyLDAtLjIyLjA4LS4zOC4yMi0uNS4xNS0uMTEuMzUtLjE3LjYyLS4xNy4yMSwwLC40LjAyLjU2LjA1LjE2LjA0LjI5LjA5LjQuMTQuMTEuMDYuMTkuMS4yNC4xNS4wNS4wNC4wOC4wNi4wOC4wN2wtLjE1LS44OHMtLjAyLS4wMi0uMDctLjA2Yy0uMDUtLjA0LS4xMy0uMDgtLjIzLS4xMy0uMTEtLjA1LS4yNS0uMDktLjQyLS4xMi0uMTctLjAzLS4zOS0uMDUtLjY0LS4wNC0uMjMsMC0uNDUuMDMtLjY1LjA5LS4yLjA2LS4zOC4xNS0uNTMuMjgtLjE1LjEyLS4yNy4yNy0uMzYuNDUtLjA5LjE4LS4xMy4zOS0uMTMuNjIsMCwuMjQuMDUuNDUuMTMuNjIuMDguMTcuMTkuMzIuMzMuNDMuMTQuMTIuMjkuMjIuNDUuMzEuMTYuMDguMzMuMTYuNDkuMjMuMTYuMDcuMzIuMTUuNDUuMjIuMTQuMDguMjUuMTcuMzMuMjcuMDguMS4xMy4yMy4xMy4zOCwwLC4yNC0uMDguNDItLjIzLjU0LS4xNS4xMi0uMzguMTctLjcuMTctLjE5LDAtLjM3LS4wMy0uNTUtLjA4LS4xOC0uMDUtLjM0LS4xLS40OC0uMTctLjE0LS4wNi0uMjYtLjEyLS4zNC0uMTctLjA4LS4wNS0uMTMtLjA3LS4xMy0uMDhsLjE1LDEuMDFjLjA3LjA0LjE3LjA5LjI5LjE0LjEzLjA2LjMuMS41LjE0LjIuMDQuNDUuMDYuNzMuMDUuMjcsMCwuNTMtLjA0Ljc3LS4xMi4yNC0uMDguNDUtLjIuNjQtLjM2LjE0LS4xMi4yNi0uMjguMzQtLjQ2LjA4LS4xOS4xMy0uNDEuMTMtLjY2aDBabS01LjM3LTEuMTFjMCwuMzgtLjA0LjcxLS4xMi45OS0uMDguMjgtLjIxLjUtLjM3LjY2LS4xNy4xNi0uMzguMjQtLjY0LjI0LS4yOSwwLS41My0uMDctLjcxLS4yLS4xOC0uMTQtLjMyLS4zNC0uNC0uNjItLjA5LS4yOC0uMTMtLjY0LS4xMy0xLjA3LDAtLjI2LjAxLS41Mi4wNC0uNzYuMDMtLjI0LjA5LS40Ni4xOC0uNjUuMDktLjE5LjIxLS4zNC4zOC0uNDUuMTYtLjExLjM3LS4xNy42NC0uMTcuMjEsMCwuMzguMDUuNTIuMTMuMTQuMDguMjUuMTkuMzMuMzMuMDguMTQuMTQuMjkuMTguNDcuMDQuMTcuMDcuMzUuMDguNTQuMDEuMTkuMDIuMzguMDIuNTZoMFptMS4xLS4wMmMwLS4yOS0uMDItLjU4LS4wNy0uODUtLjA1LS4yNy0uMTItLjUzLS4yMy0uNzYtLjExLS4yMy0uMjQtLjQ0LS40Mi0uNjItLjE3LS4xOC0uMzktLjMyLS42NC0uNDItLjI1LS4xLS41NS0uMTUtLjktLjE2LS4zNCwwLS42NC4wNS0uOS4xNS0uMjYuMS0uNDguMjQtLjY2LjQxLS4xOC4xOC0uMzMuMzgtLjQ0LjYyLS4xMS4yNC0uMi40OS0uMjUuNzctLjA1LjI4LS4wOC41Ni0uMDguODYsMCwuNDEuMDQuNzguMTIsMS4xMS4wOC4zMy4yMS42Mi40Ljg2LjE4LjI0LjQyLjQyLjcyLjU1LjMuMTMuNjYuMTksMS4wOC4yLjM2LDAsLjY3LS4wNy45NS0uMjEuMjgtLjE0LjUyLS4zMy43MS0uNTguMTktLjI1LjM0LS41NC40NC0uODcuMS0uMzMuMTUtLjY4LjE1LTEuMDZoMFptLTUuMzIuNTZjMC0uMjMtLjA0LS40NC0uMS0uNjMtLjA3LS4xOS0uMTctLjM1LS4zLS41LS4xNC0uMTctLjI5LS4zMS0uNDctLjQzLS4xOC0uMTItLjM2LS4yMy0uNTUtLjMyLS4xOS0uMDktLjM4LS4xOC0uNTctLjI2LS4xOS0uMDgtLjM2LS4xNi0uNTItLjI1LS4xNi0uMDgtLjMtLjE4LS40MS0uMjgtLjA3LS4wNy0uMTItLjE0LS4xNi0uMi0uMDQtLjA2LS4wNy0uMTMtLjA4LS4yLS4wMi0uMDctLjAyLS4xNC0uMDItLjIyLDAtLjE0LjAzLS4yNy4wOS0uNC4wNi0uMTMuMTctLjI1LjMyLS4zNS4xLS4wNy4yMy0uMTIuNC0uMTUuMTYtLjAzLjM2LS4wNS42LS4wNS4xMiwwLC4yNCwwLC4zNi4wMy4xMi4wMi4yMy4wNC4zMy4wNi4xNS4wMy4yOC4wNy4zOC4xMS4xLjA0LjE4LjA3LjI0LjEuMDYuMDMuMDkuMDUuMTEuMDdsLS4yNC0xLjAzcy0uMDMtLjAyLS4wOS0uMDVjLS4wNi0uMDMtLjE1LS4wNi0uMjctLjEtLjEyLS4wMy0uMjgtLjA2LS40Ny0uMDktLjE5LS4wMy0uNDItLjA0LS42OS0uMDQtLjIxLDAtLjQxLjAyLS42Mi4wNS0uMi4wNC0uNC4xLS41OC4xOC0uMTkuMDgtLjM2LjItLjUyLjM0LS4xNC4xMi0uMjYuMjYtLjM0LjQtLjA5LjE0LS4xNS4yOS0uMTkuNDQtLjA0LjE1LS4wNi4zLS4wNi40NSwwLC4xNy4wMi4zNC4wNS41LjAzLjE2LjA5LjMxLjE3LjQ2LjEuMTYuMjEuMy4zNi40Mi4xNC4xMi4zMS4yMy40OC4zMi4xOC4wOS4zNi4xOS41NS4yNy4xOS4wOS4zOC4xOC41Ni4yOC4xOS4xLjM2LjIxLjUyLjM0LjEuMDguMTkuMTYuMjYuMjQuMDcuMDguMTIuMTcuMTYuMjcuMDMuMS4wNS4yMS4wNS4zNCwwLC4yLS4wNC4zNy0uMTIuNS0uMDguMTQtLjE5LjI2LS4zNS4zNi0uMDguMDYtLjE3LjEtLjI4LjEzLS4xMS4wMy0uMjIuMDYtLjMzLjA3LS4xMS4wMi0uMjEuMDItLjMuMDMtLjA5LDAtLjE1LDAtLjE4LDAtLjExLDAtLjIyLDAtLjMzLS4wMi0uMTEtLjAxLS4yMi0uMDMtLjMyLS4wNS0uMjItLjA0LS40MS0uMDktLjU2LS4xMy0uMTUtLjA0LS4yNy0uMDgtLjM0LS4xMS0uMDgtLjAzLS4xMi0uMDQtLjEzLS4wNWwuMjYsMS4wMXMuMDQuMDIuMS4wNWMuMDYuMDMuMTYuMDcuMjkuMTEuMTMuMDQuMy4wOC41MS4xMS4yMS4wMy40NS4wNS43NC4wNS4yMiwwLC40NS0uMDIuNjktLjA1LjI0LS4wNC40Ny0uMS43LS4xOS4yMy0uMDkuNDMtLjIyLjYxLS4zOS4xOC0uMTYuMzMtLjM3LjQ0LS42My4xMS0uMjUuMTYtLjU2LjE3LS45MloiLz4KICAgICAgPGc+CiAgICAgICAgPGc+CiAgICAgICAgICA8Zz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtMi41MiwxNS4wNGMuNDQtMy4wNSwzLjUtMy44OCwzLjc5LTYuNjYtMS4zOC42MS0zLjAzLjQyLTQuMjQtLjU4LTEuMzQsMi40MS0xLjQxLDQuNzguNDUsNy4yNFoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtOC40Myw2LjE5YzEuNTYtLjIzLDIuOS0xLjMzLDQuMTgtMi40MSwxLjc3LTEuNSw0LjI0LTMuMzUsNi41OS0zLjE3QzE1LS42OSwxMC40NS4yNCw3LjY4LDEuOTRjMS4wNywxLjE4LDEuMzEsMi44NC43NSw0LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC41LDE1Ljk5Yy0uNDQsMy4wNS0zLjUsMy44OC0zLjc5LDYuNjYsMS4zOC0uNjEsMy4wMy0uNDIsNC4yNC41OCwxLjM0LTIuNDEsMS40MS00Ljc4LS40NS03LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yMi41OSwyNC44NGMtMS41Ni4yMy0yLjksMS4zMy00LjE4LDIuNDEtMS43NywxLjUtNC4yNCwzLjM1LTYuNTksMy4xNyw0LjIsMS4zLDguNzQuMzcsMTEuNTEtMS4zMy0xLjA3LTEuMTgtMS4zMS0yLjg0LS43NS00LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0xNS45OSwyLjUyYzMuMDUuNDQsMy44NywzLjUsNi42NiwzLjc5LS42MS0xLjM4LS40Mi0zLjAzLjU4LTQuMjQtMi40MS0xLjM0LTQuNzgtMS40MS03LjI0LjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yNC44NCw4LjQzYy4yMywxLjU2LDEuMzMsMi45LDIuNDEsNC4xOCwxLjUsMS43NywzLjM1LDQuMjQsMy4xNyw2LjU5LDEuMy00LjIuMzctOC43NC0xLjMzLTExLjUxLTEuMTgsMS4wNy0yLjg0LDEuMzItNC4yNC43NVoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0yIiBkPSJtMTUuMDQsMjguNWMtMy4wNS0uNDQtMy44OC0zLjUtNi42Ni0zLjc5LjYxLDEuMzguNDIsMy4wMy0uNTgsNC4yNCwyLjQxLDEuMzQsNC43OCwxLjQxLDcuMjQtLjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02LjE5LDIyLjU5Yy0uMjMtMS41Ni0xLjMzLTIuOS0yLjQxLTQuMTgtMS41LTEuNzctMy4zNC00LjI0LTMuMTctNi41OS0xLjMsNC4yLS4zNyw4Ljc0LDEuMzMsMTEuNTEsMS4xOC0xLjA3LDIuODQtMS4zMSw0LjI0LS43NVoiLz4KICAgICAgICAgIDwvZz4KICAgICAgICAgIDxnPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yOC43NiwyLjI2YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02Ljk2LDI0LjA3YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC43NiwyOC43NmMtMS4zLDEuMy0zLjQsMS4zLTQuNywwLTEuMy0xLjMtMS4zLTMuNCwwLTQuNywxLjMtMS4zLDMuNC0xLjMsNC43LDBzMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im02Ljk2LDYuOTZjLTEuMywxLjMtMy40LDEuMy00LjcsMC0xLjMtMS4zLTEuMy0zLjQsMC00LjcsMS4zLTEuMywzLjQtMS4zLDQuNywwLDEuMywxLjMsMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgICAgICA8Zz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMiIgZD0ibTE0LjEsMTguMzF2MS4xN2gyLjgzdi0yLjU1bDIuNDMsMi4zNWMuMi4xOS4xOS4zLjE5LjQ5di44czAsLjAyLDAsLjA0aDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAyLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMiwwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMtLjAxLjA0aDBzMCwuMDMtLjAxLjAzaDBzMCwuMDIsMCwuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMtLjAxLjAzLS4wMi4wNGgwczAsLjAyLS4wMS4wM2gwczAsLjAyLS4wMS4wM2gwczAsLjAzLS4wMi4wM2gwczAsLjAyLS4wMS4wM2gwcy0uMDEuMDItLjAyLjAzYzAsMCwwLDAtLjAxLjAxLDAsMCwwLC4wMS0uMDEuMDJoMHMwLC4wMi0uMDEuMDJjMCwwLDAsMC0uMDEuMDEsMCwwLS4wMS4wMS0uMDIuMDIsMCwwLDAsMC0uMDEuMDEsMCwwLDAsMC0uMDEuMDFoLS4wMXMtLjAxLjAyLS4wMS4wMmMwLDAsMCwwLS4wMS4wMWgwcy0uMDEuMDEtLjAyLjAyaDBzMCwwLS4wMS4wMWMwLDAsMCwwLS4wMS4wMWgtLjAxcy0uMDEuMDItLjAxLjAyYzAsMC0uMDIuMDEtLjAyLjAyaC0uMDFzMCwuMDItLjAxLjAyaC0uMDFzMCwuMDItLjAxLjAyYzAsMCwwLDAtLjAxLDAsMCwwLS4wMi4wMS0uMDMuMDJoMHMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaC0uMDFzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaDBzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAyLjAxLS4wMi4wMWMwLDAsMCwwLS4wMSwwLS4yLjA5LS40MS4xNC0uNjQuMTRoLTMuOTF2MS4xN2wtMi41LTIuNDgsMi41LTIuNDhoMFptMi44My00LjIxaDIuNTV2Mi44M2gtMS4xN2wyLjQ4LDIuNSwyLjQ4LTIuNWgtMS4xN3YtMy45MWMwLS4yMy0uMDUtLjQ1LS4xNC0uNjQsMCwwLDAsMCwwLS4wMXYtLjAycy0uMDEtLjAxLS4wMS0uMDFjMC0uMDEtLjAxLS4wMi0uMDItLjAzaDBzMC0uMDIsMC0uMDJoMHMwLS4wMiwwLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRoMHMwLS4wMi0uMDEtLjAzaDBzMC0uMDItLjAxLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRjMCwwLDAsMCwwLS4wMSwwLDAsMCwwLS4wMS0uMDFoMHMwLS4wMi0uMDEtLjAzaDBzLS4wMS0uMDMtLjAyLS4wM2gtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMWgwcy0uMDEtLjAxLS4wMi0uMDJoMHMwLDAtLjAxLS4wMWgtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMSwwLDAtLjAxLS4wMS0uMDItLjAyLDAsMCwwLDAtLjAxLDAsMCwwLDAsMC0uMDEtLjAxaC0uMDFzLS4wMS0uMDItLjAyLS4wMmMwLDAsMCwwLS4wMS0uMDEsMCwwLS4wMS0uMDEtLjAyLS4wMWgtLjAxczAtLjAyLS4wMS0uMDJoLS4wMXMtLjAxLS4wMi0uMDItLjAyaC0uMDFzLS4wMS0uMDItLjAyLS4wMmgtLjAxcy0uMDEtLjAyLS4wMi0uMDJoLS4wMXMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDEtLjAxLS4wMi0uMDJoMHMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDItLjAxLS4wMi0uMDJoMHMtLjAyLS4wMS0uMDMtLjAyaDBzLS4wMSwwLS4wMi0uMDFoLS4wMXMtLjAyLS4wMS0uMDMtLjAxaDBzLS4wMiwwLS4wMy0uMDFoLS4wMXMtLjAxLDAtLjAyLS4wMWgwcy0uMDIsMC0uMDMtLjAxaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wNCwwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wNCwwaC0uOGMtLjE4LDAtLjI5LS4wMi0uNDkuMTlsLTIuMzUsMi40M2gwWm0tMi44MywyLjgzaC0yLjU1di0yLjgzaDEuMTdsLTIuNDgtMi41LTIuNDgsMi41aDEuMTd2My45MWMwLC4yMy4wNS40NS4xNC42NCwwLDAsMCwwLDAsLjAxdi4wMnMuMDEuMDEuMDEuMDFjMCwuMDEuMDEuMDIuMDIuMDNoMHMwLC4wMiwwLC4wMmgwczAsLjAyLDAsLjAzaDBzLjAxLjAzLjAyLjA0aDBzMCwuMDIuMDEuMDNoMHMwLC4wMi4wMS4wM2gwcy4wMS4wMy4wMi4wNGMwLDAsMCwwLDAsLjAxLDAsMCwwLDAsLjAxLjAxaDBzMCwuMDIuMDEuMDNoMHMuMDEuMDMuMDIuMDRoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMWgwcy4wMS4wMS4wMi4wMmgwczAsMCwuMDEuMDFoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMSwwLDAsLjAxLjAxLjAyLjAyLDAsMCwwLDAsLjAxLjAxLDAsMCwwLDAsLjAxLjAxaC4wMXMuMDEuMDIuMDIuMDJjMCwwLDAsMCwuMDEuMDEsMCwwLC4wMS4wMS4wMi4wMWguMDFzMCwuMDIuMDEuMDJoLjAxcy4wMS4wMi4wMi4wMmguMDFzLjAxLjAyLjAyLjAyaC4wMXMuMDEuMDIuMDIuMDJoLjAxcy4wMi4wMi4wMy4wMmgwcy4wMS4wMS4wMi4wMmguMDFzLjAxLjAxLjAyLjAyaDBzLjAyLjAyLjAzLjAyaDBzLjAxLjAxLjAyLjAyaDBzLjAyLjAxLjAyLjAyaDBzLjAyLjAxLjAzLjAyaDBzLjAxLjAxLjAyLjAxaC4wMXMuMDIuMDEuMDMuMDFoMHMuMDIsMCwuMDMuMDFoMHMuMDIsMCwuMDIuMDFoLjAxcy4wMiwwLC4wMy4wMWgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoMHMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaC4wMXMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoLjAxcy4wMiwwLC4wMywwaDBzLjAyLDAsLjA0LDBoMHMuMDIsMCwuMDMsMGguMDFzLjAyLDAsLjA0LDBoLjhjLjE4LDAsLjI5LjAyLjQ5LS4xOWwyLjM1LTIuNDNoMFptMC0yLjgzbC0yLjQzLTIuMzVjLS4yMS0uMi0uMTktLjMtLjE5LS40OXYtLjhzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA1aDBzMC0uMDIsMC0uMDRoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAyLjAxLS4wNGgwczAtLjAyLDAtLjAzaDBzMC0uMDMuMDEtLjA0aDBzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwcy4wMS0uMDMuMDItLjA0aDBzMC0uMDIuMDEtLjAzaDBzMC0uMDIuMDEtLjAzaDBzMC0uMDMuMDItLjAzaDBzMC0uMDIuMDEtLjAzaDBzLjAxLS4wMi4wMS0uMDNjMCwwLDAsMCwuMDEtLjAxLDAsMCwwLS4wMS4wMS0uMDJoMHMwLS4wMi4wMS0uMDJjMCwwLDAsMCwuMDEtLjAxLDAsMCwuMDEtLjAxLjAyLS4wMiwwLDAsMCwwLC4wMS0uMDEsMCwwLDAsMCwuMDEtLjAxaC4wMXMuMDEtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMS0uMDFoMHMuMDEtLjAxLjAyLS4wMmgwczAsMCwuMDEtLjAxYzAsMCwwLDAsLjAxLS4wMWguMDFzLjAxLS4wMi4wMS0uMDJjMCwwLC4wMi0uMDEuMDItLjAyaC4wMXMwLS4wMi4wMS0uMDJoLjAxczAtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMSwwLDAsMCwuMDItLjAxLjAzLS4wMmgwcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmguMDFzLjAyLS4wMi4wMy0uMDJoLjAxcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmgwcy4wMi0uMDIuMDMtLjAyaC4wMXMuMDItLjAxLjAyLS4wMWMwLDAsMCwwLC4wMSwwLC4yLS4wOS40MS0uMTQuNjQtLjE0aDMuOTF2LTEuMTdsMi41LDIuNDgtMi41LDIuNDh2LTEuMTdoLTIuODN2Mi41NVoiLz4KICAgICAgICAgIDxwb2x5Z29uIGNsYXNzPSJjbHMtNSIgcG9pbnRzPSIxNC4xMSAxOS40NSAxNC4xMSAxNi45MiAxMS41NyAxNi45MiAxMS41NyAxNC4xMSAxNC4xMSAxNC4xMSAxNC4xMSAxMS41NyAxNi45MiAxMS41NyAxNi45MiAxNC4xMSAxOS40NSAxNC4xMSAxOS40NSAxNi45MiAxNi45MiAxNi45MiAxNi45MiAxOS40NSAxNC4xMSAxOS40NSIvPgogICAgICAgIDwvZz4KICAgICAgPC9nPgogICAgPC9nPgogIDwvZz4KPC9zdmc+",pt=i=>i.replace(/\s+/g," ").replace(/Telep\s+on/gi,"Telepon").replace(/Kunjunga\s+n/gi,"Kunjungan").replace(/Spes\s+ialis/gi,"Spesialis").trim();function qt(i){let s=i.find(w=>/^SEP$/i.test(w.title)),a=s?St(s.html):"",t=s&&new DOMParser().parseFromString(s.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",u=w=>pt(a.match(w)?.[1]||"")||"-",n=(w,E)=>u(new RegExp(`${w}\\s*:\\s*([\\s\\S]*?)(?=${E}|$)`,"i")),r=e("no_sep","sep")!=="-"?e("no_sep","sep"):u(/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]+)/i),j=u(/Tgl\.?\s*SEP\s*[:.]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})/i),o=e("no_hp","telepon")!=="-"?e("no_hp","telepon"):n("No\\.?\\s*Telepon","Sub\\/Spesialis"),x=e("kelas").replace(/^Kelas\s*/i,""),h=e("tgl_lahir","tglLahir").replace(/^:\s*/,"").split(/\s*\/\s*/)[0]?.trim()||"-",D=n("Kelamin","No\\.?\\s*Telepon"),v=e("dokter","dpjp"),I=e("kartu","no_kartu","noka"),y=e("norm","rekam_medis"),b=e("nama")||"-",g=I.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),C=g?`${M(g[1].trim())}<span class="sep-inline-mr">No.MR : ${M(g[2].trim())}</span>`:`${M(I)}${y!=="-"?`<span class="sep-inline-mr">No.MR : ${M(y)}</span>`:""}`,$=e("jenis_kunjungan")!=="-"?e("jenis_kunjungan"):u(/Jns\.?\s*Kunjungan\s*[:.]?\s*([\s\S]*?)(?:\s+Kls\.?\s*Hak|$)/i),F=$.replace(/^-\s*/,"").split(/\s+-\s+|\n/).map(w=>w.trim()).filter(Boolean),P=F.length>1?'<ul class="sep-multiline-list">'+F.map(w=>`<li>${M(w)}</li>`).join("")+"</ul>":M($),R=e("peserta","jenis_peserta")!=="-"?e("peserta","jenis_peserta"):n("(?<!Nama )Peserta","COB|Jns\\.?\\s*Rawat"),k=e("penjamin")!=="-"?e("penjamin"):n("Penjamin","\\*Saya|CATATAN"),U=e("faskes_perujuk","faskes")!=="-"?e("faskes_perujuk","faskes"):n("Faskes\\s*Perujuk","Diagnosa\\s*Awal"),B=e("diagnosa_awal")!=="-"?e("diagnosa_awal"):n("Diagnosa\\s*Awal","Catatan|Peserta"),f=e("catatan_sep","catatan")!=="-"?e("catatan_sep","catatan"):n("Catatan","Peserta|COB"),N=e("sub_spesialis","spesialis")!=="-"?e("sub_spesialis","spesialis"):n("Sub\\/Spesialis","Dokter"),O=u(/Cetakan\s+ke\s*[:.]?\s*(\d+)/i),A=O!=="-"?`<div class="sep-print-meta">Cetakan ke ${M(O)}</div>`:"",d=(w,E,m="",l=!1)=>`<tr><td class="lbl${l?" right":""}">${w}</td><td class="sep">:</td><td class="val${m?" "+m:""}">${E}</td></tr>`,z='<tr><td colspan="3">&nbsp;</td></tr>',c=x!=="-"?`Kelas ${M(x)}`:"-";return`<section class="rm-page sep-page" id="rm-01">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${mt}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT ELEGIBILITAS PESERTA</div>
     <div class="sep-hospital">${M(jt.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-columns">
   <div class="sep-col-left"><table class="sep-kv-table">
     ${d("No. SEP",`<span class="sep-no-value">${M(r)}</span>`)}
     ${d("Tgl. SEP",M(j))}
     ${d("No.Kartu",C)}
     ${d("Nama Peserta",`<strong>${M(b)}</strong>`)}
     ${d("Tgl.Lahir",`${M(h)} &nbsp;&nbsp; Kelamin : ${M(D)}`)}
     ${d("No.Telepon",M(o))}
     ${d("Sub/Spesialis",M(N))}
     ${d("Dokter",M(v))}
     ${d("Faskes Perujuk",M(U!=="-"?U:`${jt} - Kota Jambi`))}
     ${d("Diagnosa Awal",M(B))}
     ${d("Catatan",M(f))}
   </table></div>
   <div class="sep-col-right"><table class="sep-kv-table">
     ${z}${z}
     ${d("Peserta",M(R),"",!0)}
     ${d("COB","-","",!0)}
     ${d("Jns.Rawat",`<strong>${M(e("jenis"))}</strong>`,"",!0)}
     ${d("Jns.Kunjungan",P,"",!0)}
     ${d("Kls.Hak",`<strong>${c}</strong>`,"",!0)}
     ${d("Kls.Rawat",`<strong>${c}</strong>`,"",!0)}
     ${d("Penjamin",M(k),"",!0)}
   </table></div>
 </div>
 <div class="sep-disclaimer">
   *Saya Menyetujui BPJS Kesehatan menggunakan informasi Medis Pasien jika diperlukan.<br/>
   *SEP bukan sebagai bukti penjamin peserta
 </div>
 ${A}
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div class="sep-sig-role">Pasien/<br/>Keluarga Pasien</div>
     ${t?`<img class="sep-qr" src="${M(t)}" alt="QR SEP" width="100" height="100" />`:""}
     <div class="sep-sig-name">(${M(b)})</div>
   </div>
 </div>
 </section>
</section>`}function Xt(i){let s=i.find(U=>/^SPRI$/i.test(U.title)),a=V(i,/^SPRI$/i)[0]??"",t=s?new DOMParser().parseFromString(s.html,"text/html"):null,u=U=>{if(!t)return"-";for(let B of Array.from(t.querySelectorAll("tr"))){let f=Array.from(B.cells);if(!f.length)continue;let N=(f[0].textContent||"").replace(/\s+/g," ").trim();if(!U.test(N))continue;if(f.length===1)return N;let O=f.slice(1).map(A=>(A.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()).filter(Boolean).join(`
`).trim();if(O)return O}return"-"},n=(U,B)=>B.match(U)?.[1]?.trim()||"-",r=u(/^Pemeriksaan Fisik$/i),j=n(/Keadaan Umum\s*:\s*(.*?)\s*(?:Tensi|$)/i,r),o=n(/Tensi\s*:\s*(.*?)\s*(?:Nadi|$)/i,r),x=n(/Nadi\s*:\s*(.*?)\s*(?:RR|$)/i,r),h=n(/RR\s*:\s*(.*?)\s*(?:Suhu|$)/i,r),D=n(/Suhu\s*:\s*(.*?)\s*(?:BB|$)/i,r),v=n(/BB\s*:\s*(.*?)\s*(?:TB|$)/i,r),I=n(/TB\s*:\s*(.*?)$/i,r),y=n(/Pemeriksaan Fisik\s*:\s*([\s\S]*)$/i,r),b=u(/^Catatan$/i),g=u(/^Diit$/i),C=u(/^Terapi$/i),$=u(/^Kota Jambi,.*Jam|^Waktu Pengantar/i),F=$.match(/^(Kota Jambi,.*?Jam\s*\d{1,2}:\d{2})/i)?.[1]||$,P=e("dokter","dpjp"),R=e("tgl_lahir","tglLahir").split(/\s*\/\s*/),k=R.length>1?`${R[1]} (${R[0]})`:R[0]||"-";return`<section class="rm-page" id="rm-03">
${G("RM. 03")}
<div class="rm-form-title">SURAT PENGANTAR RAWAT INAP (SPRI)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"),!0)}
    ${L("Umur / Tgl. Lahir",k)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Alamat",Lt(i))}
    ${L("Dikirim Oleh",P)}
    ${L("Waktu Pengantar",F)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr><th colspan="7">PEMERIKSAAN TANDA VITAL &amp; ANTROPOMETRI SAAT MASUK</th></tr>
    <tr>
      <th>KEADAAN UMUM</th><th>TEKANAN DARAH</th><th>NADI</th>
      <th>PERNAPASAN (RR)</th><th>SUHU</th><th>BERAT BADAN</th><th>TINGGI BADAN</th>
    </tr>
  </thead>
  <tbody><tr>
    <td class="center"><strong>${M(j)}</strong></td>
    <td class="center"><strong>${M(o)}</strong></td>
    <td class="center">${M(x)}</td>
    <td class="center">${M(h)}</td>
    <td class="center">${M(D)}</td>
    <td class="center">${M(v)}</td>
    <td class="center">${M(I)}</td>
  </tr></tbody>
</table>

<table class="rm-grid-table">
  <tbody>
    <tr><td style="width: 175px;"><strong>ANAMNESIS</strong></td><td>${Q(u(/^Anamnesis$/i))}</td></tr>
    <tr><td><strong>RIWAYAT PENYAKIT KELUARGA</strong></td><td>${Q(u(/^Riwayat Penyakit Keluarga$/i))}</td></tr>
    <tr><td><strong>RIWAYAT ALERGI</strong></td><td>${Q(u(/^Riwayat Alergi$/i))}</td></tr>
    <tr><td><strong>PEMERIKSAAN FISIK / CATATAN</strong></td><td>${y!=="-"?`<strong>${Q(y)}</strong>`:"-"}${b!=="-"?`<br/>${Q(b)}`:""}</td></tr>
    <tr><td><strong>PEMERIKSAAN PENUNJANG AWAL</strong></td><td>${Q(u(/^Pemeriksaan Penunjang$/i))}</td></tr>
    <tr><td><strong>DIAGNOSA KERJA</strong></td><td><strong>${Q(u(/^Diagnosa Kerja$/i))}</strong></td></tr>
    <tr><td><strong>TERAPI &amp; DIIT AWAL</strong></td><td>${Q(C)}${g!=="-"?`<br/><strong>Diit :</strong> ${Q(g)}`:""}</td></tr>
  </tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>${M(F)}</div>
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${M(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(P)} )</div>
  </div>
</div>
</section>`}function Vt(i){let s=i.find(f=>/^SBPK$/i.test(f.title)),a=s?new DOMParser().parseFromString(s.html,"text/html"):null,t=new Map,u=new Map,n=[],r="-";if(a){for(let O of Array.from(a.querySelectorAll("tr"))){let A=Array.from(O.cells);for(let d=0;d<A.length-2;d++){let z=(A[d].textContent||"").replace(/\s+/g," ").trim();if((A[d+1].textContent||"").trim()!==":")continue;let c=(A[d+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();z&&c&&!t.has(z)&&t.set(z,c)}A.length>=5&&/^[A-Z]\d{2}(?:\.\d+)?$/.test(A[2].textContent?.trim()??"")&&A[0].textContent?.trim()&&A[1].textContent?.trim()&&n.push({unit:(A[0].textContent||"").replace(/\s+/g," ").trim(),diag:(A[1].textContent||"").replace(/\s+/g," ").trim(),icd:(A[2].textContent||"").trim(),dokter:(A[4].textContent||"").replace(/\s+/g," ").trim()||"-"})}for(let O of Array.from(a.querySelectorAll("li"))){let A=(O.textContent||"").replace(/\s+/g," ").trim();if(!A||/\([A-Z]\d{2}(?:\.\d+)?\)$/i.test(A))continue;let d=A.toUpperCase();u.set(d,(u.get(d)||0)+1)}let f=Array.from(a.querySelectorAll("table")),N=(f[f.length-1]?.textContent||"").match(/\((dr\.[^)]+)\)/i);N&&(r=N[1].trim())}let j=f=>{for(let[N,O]of t)if(f.test(N))return O;return"-"},o=j(/^No Kartu BPJS$/i),x=e("norm","rekam_medis"),h=e("nama"),D=j(/^Tanggal lahir/i),v=j(/^Alamat$/i),I=e("no_sep","sep")!=="-"?e("no_sep","sep"):j(/^No SEP$/i),y=j(/^Jenis Kelamin$/i),b=/^L$/i.test(y)?"Laki-laki (L)":/^P$/i.test(y)?"Perempuan (P)":y,g=j(/^Tgl\.? Masuk RS$/i),C=j(/^Berat badan/i),$=n[0]?.unit||j(/^Unit Pelayanan|^Poliklinik/i),F=j(/^ANAMNESE$/i),P=r!=="-"?r:e("dokter","dpjp"),R=V(i,/^SBPK/i)[0]??"",k=V(i,/^SEP/i)[0]??V(i,/^Rincian Biaya/i)[0]??"",U=n.length?n.map(f=>`<tr><td>${M(f.unit)}</td><td>Diagnosa</td><td><strong>${M(f.diag)}</strong></td><td class="center">${M(f.icd)}</td><td>${M(f.dokter)}</td></tr>`).join(""):`<tr><td>${Q($)}</td><td>Diagnosa Utama</td><td><strong>${Q(j(/^Diagnosa utama/i))}</strong></td><td class="center">-</td><td>${M(P)}</td></tr>
       <tr><td>${Q($)}</td><td>Diagnosa Tambahan</td><td>${Q(j(/^Diagnosa tambahan/i))}</td><td class="center">-</td><td>${M(P)}</td></tr>`,B=Array.from(u.entries()).map(([f,N],O)=>`<tr><td class="center">${O+1}</td><td>${M(f)}</td><td>${M(P)}</td><td class="center">${N}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi SBPK Item ${O+1}"></td></tr>`).join("");return`<section class="rm-page" id="rm-02">
${G("RM. 02")}
<div class="rm-form-title">SURAT BUKTI PELAYANAN KESEHATAN (SBPK)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("No. Kartu BPJS",o)}
    ${L("No. Rekam Medis",x)}
    ${L("Nama Pasien",h,!0)}
    ${L("Tgl. Lahir / Umur",D)}
    ${L("Alamat",v)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("No. SEP",I)}
    ${L("Jenis Kelamin",b)}
    ${L("Tgl. Masuk RS",`${g} (*)`,!0)}
    ${L("Berat Badan Bayi",C)}
    ${L("Unit Pelayanan",$)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    <tr>
      <td style="width: 170px;"><strong>Hasil anamnesa datang untuk</strong></td>
      <td>
        <span class="static-box">&nbsp;</span> Suspek &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&#10003;</span> <strong>Tegak Diagnosa</strong> &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Observasi &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Kontrol lanjutan &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Buka Balutan / Jahitan
      </td>
    </tr>
    <tr><td><strong>ANAMNESE</strong></td><td>${Q(F)}</td></tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 150px;">POLIKLINIK / RUANG</th>
    <th style="width: 120px;">JENIS DIAGNOSA</th>
    <th>DIAGNOSA</th>
    <th style="width: 65px;">ICD X</th>
    <th style="width: 165px;">DOKTER / PETUGAS</th>
  </tr></thead>
  <tbody>${U}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>TINDAKAN / PEMERIKSAAN PENUNJANG / TERAPI (TERAGGREGASI)</th>
    <th style="width: 165px;">UNIT / DOKTER PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${B}</tbody>
</table>

<div class="footnote-rm">
  (*) Catatan Sistem: periksa kembali tanggal masuk pada SBPK dengan SEP &amp; Resume sebelum berkas dikirim.
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Pasien / Keluarga Pasien</div>
    ${k?`<img class="rm-sig-qr" src="${M(k)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${k?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(h)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penanggung Jawab Pelayanan (DPJP)</div>
    ${R?`<img class="rm-sig-qr" src="${M(R)}" alt="QR persetujuan DPJP" width="80" height="80" />`:""}
    ${R?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(P)} )</div>
  </div>
</div>
</section>`}var xt=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];function Et(i){let s=String(i??"").replace(/^\s*:\s*/,"").trim(),a=s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/)||s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(!a)return s||"-";let[t,u,n]=a.slice(1),r=t.length===4?t:n,j=xt[Number(u)-1];return j?`${Number(t.length===4?n:t)} ${j} ${r}`:s}function Zt(i){let s=i.find(k=>/^Surat (?:Rencana )?Kontrol/i.test(k.title)),a=s?St(s.html):"",t=k=>pt(a.match(k)?.[1]||"")||"-",u=(k,U)=>t(new RegExp(`${k}\\s*:\\s*([\\s\\S]*?)(?=${U}|$)`,"i")),n=(k,U)=>{for(let B of k){let f=e(B);if(f!=="-")return f}return t(U)},r=s&&new DOMParser().parseFromString(s.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",j=n(["no_surat_kontrol","no_surat"],/NO\.\s*([0-9A-Z]{10,})/i),o=t(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i)!=="-"?t(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i):e("dokter","dpjp"),x=n(["kartu","no_kartu","noka"],/No\.?\s*Kartu\s*[:.]?\s*([\s\S]*?)(?=Nama\s*Peserta|$)/i),h=e("norm","rekam_medis"),D=x.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),v=D?`${M(D[1].trim())}<span class="sep-inline-mr">No.MR : ${M(D[2].trim())}</span>`:`${M(x)}${h!=="-"?`<span class="sep-inline-mr">No.MR : ${M(h)}</span>`:""}`,I=e("nama")!=="-"?e("nama"):u("Nama\\s*Peserta","Tanggal Lahir"),y=e("jenis_kelamin","jk"),b=/perempuan|^p$/i.test(y)?"Perempuan":/laki|^l$/i.test(y)?"Laki-laki":a.match(/Nama Peserta\s*:\s*[^()]*\((Perempuan|Laki-laki)\)/i)?.[1]||"",g=b&&!new RegExp(`\\(${b}\\)`,"i").test(I)?`${I} (${b})`:I,C=Et(n(["tgl_lahir","tglLahir"],/Tanggal Lahir\s*[:.]?\s*([\s\S]*?)(?=Diagnosa|$)/i)),$=n(["diagnosa_awal","diagnosa"],/Diagnosa\s*[:.]?\s*([\s\S]*?)(?=Tanggal entri|$)/i),F=Et(n(["tanggalAwal","tgl_masuk","tgl"],/Tanggal entri\s*[:.]?\s*([\s\S]*?)(?=Demikian|$)/i)),P=(k,U)=>`<tr><td class="lbl">${k}</td><td class="sep">:</td><td class="val">${U}</td></tr>`,R=k=>`<tr><td class="val" colspan="3" style="padding-top:6px;">${M(k)}</td></tr>`;return`<section class="rm-page sep-page" id="surat-kontrol">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${mt}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT RENCANA KONTROL</div>
     <div class="sep-hospital">${M(jt.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-no-value" style="text-align:right;margin-bottom:10px;">NO. ${M(j)}</div>
 <div class="sep-columns">
   <div class="sep-col-left" style="flex:1 1 100%;"><table class="sep-kv-table">
     <tr><td class="lbl">Kepada Yth</td><td class="sep">:</td><td class="val"><strong>${M(o)}</strong></td></tr>
     ${R("Mohon pemeriksaan dan penangan lebih lanjut :")}
     ${P("No.Kartu",v)}
     ${P("Nama Peserta",`<strong>${M(g)}</strong>`)}
     ${P("Tanggal Lahir",M(C))}
     ${P("Diagnosa",M($))}
     ${P("Tanggal entri",M(F))}
     ${R("Demikian atas bantuannya, diucapkan banyak terima kasih.")}
   </table></div>
 </div>
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div>Mengetahui,</div>
     ${r?`<img class="sep-qr" src="${M(r)}" alt="QR Surat Rencana Kontrol" width="100" height="100" />`:""}
   </div>
 </div>
 </section>
</section>`}function ta(i){let s=i.find(c=>/^Rincian Biaya/i.test(c.title)),a=s?new DOMParser().parseFromString(s.html,"text/html"):null,t=new Map,u=new Map;if(a){let c=Array.from(a.querySelectorAll("table")),w=c.find(m=>/frek/i.test(m.rows[0]?.textContent||""));for(let m of Array.from(w?.rows??[])){let l=Array.from(m.cells).map(Mt=>(Mt.textContent||"").replace(/\s+/g," ").trim());if(l.length<6||!/^\d+\.?$/.test(l[0]))continue;let p=l[2]||"-",Y=p.toUpperCase().replace(/\s+/g," ").trim(),J=parseInt(l[4],10)||1,W=parseFloat((l[7]||"0").replace(/\./g,"").replace(",","."))||0,et=t.get(Y);et?(et.frek+=J,et.jaminan+=W):t.set(Y,{name:p,petugas:l[3]||"-",frek:J,tarif:l[5]||"-",jaminan:W})}let E=c.find(m=>/nama\s*obat/i.test(m.rows[0]?.textContent||""));for(let m of Array.from(E?.rows??[])){let l=Array.from(m.cells).map(Mt=>(Mt.textContent||"").replace(/\s+/g," ").trim());if(l.length<5||!/^\d+(\.\d+)?$/.test(l[2]))continue;let p=l[1].replace(/^\d+\s*/,"").trim()||"-",Y=p.toUpperCase().replace(/\s+/g," ").trim(),J=parseFloat(l[2].replace(",","."))||0,W=parseFloat((l[5]||"0").replace(/\./g,"").replace(",","."))||0,et=u.get(Y);et?(et.qty+=J,et.jaminan+=W):u.set(Y,{name:p,qty:J,jaminan:W})}}let n=c=>{if(!a)return 0;for(let w of Array.from(a.querySelectorAll("tr"))){let E=Array.from(w.cells).map(m=>(m.textContent||"").replace(/\s+/g," ").trim());if(E.some(m=>c.test(m)))for(let m of E.slice(1)){let l=parseFloat(m.replace(/\./g,"").replace(",","."));if(Number.isFinite(l)&&l!==0)return l}}return 0},r=n(/^Total Jasa Rp/i),j=n(/^Total Resep/i),o=n(/^Jasa Pelayanan/i),x=n(/^Biaya Administrasi/i),h=n(/^Biaya Materai/i),D=n(/^Diskon/i),v=n(/^Pembulatan/i),I=n(/^Total Biaya/i),y=r+j+o,b=Math.max(0,y-I),g=c=>c.toLocaleString("id-ID",{minimumFractionDigits:0,maximumFractionDigits:0}),C=(c,w,E=!1)=>`<div class="rm-sum-line"${E?' style="font-weight:bold;border-top:1px solid #000;"':""}><span>${M(c)}</span><span class="rm-sum-dots"></span><span>${M(w)}</span></div>`,$=Array.from(t.values()).map((c,w)=>`<tr><td class="center">${w+1}</td><td>${M(c.name)}</td><td>${M(c.petugas)}</td><td class="center">${c.frek}</td><td class="num">${M(c.tarif)}</td><td class="num">${g(c.jaminan)}</td></tr>`).join(""),F=Array.from(u.values()).map((c,w)=>`<tr><td class="center">${w+1}</td><td>${M(c.name)}</td><td class="center">${c.qty}</td><td class="num">${g(c.jaminan)}</td></tr>`).join(""),P=e("norm","rekam_medis"),R=e("nama"),k=e("dokter","dpjp"),U=Lt(i),B=e("no_sep","sep"),f=[e("jenis"),e("kelas","ruang")].filter(c=>c!=="-").join(" / ")||"-",N=e("tanggalAwal","tgl_masuk","tgl"),O=e("tanggalAkhir","keluar","tgl_keluar"),A=V(i,/^Rincian Biaya/i),d=A.find(c=>/pasien/i.test(decodeURIComponent(c)))??A[0]??"",z=A.find(c=>/penerima/i.test(decodeURIComponent(c)))??A[1]??"";return`<section class="rm-page" id="rm-05">
${G("RM. 05")}
<div class="rm-form-title">RINCIAN BIAYA PELAYANAN RAWAT INAP &amp; FARMASI</div>

<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${L("No. Rekam Medis",P)}
    ${L("Nama Pasien",R,!0)}
    ${L("Alamat Pasien",U)}
    ${L("Unit / Instalasi",f)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Golongan Pasien",`BPJS KESEHATAN (SEP: ${B})`)}
    ${L("Dokter DPJP",k)}
    ${L("Periode Rawat",`${N} s/d ${O}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>URAIAN TINDAKAN / PELAYANAN</th>
    <th style="width: 155px;">DOKTER / PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="num" style="width: 88px;">TARIF (Rp)</th>
    <th class="num" style="width: 98px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${$}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>NAMA OBAT / ALKES</th>
    <th class="center" style="width: 52px;">QTY</th>
    <th class="num" style="width: 120px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${F}</tbody>
</table>

<div class="rm-summary">
  ${C("Sub Total Layanan Medis / Tindakan",g(r))}
  ${C("Sub Total Penjualan (Farmasi/Obat)",g(j))}
  ${C("Jasa Pelayanan (Jasa Medis/Paramudis)",g(o))}
  ${C("Jasa Sarana","0")}
  ${C("Biaya Administrasi",g(x))}
  ${C("Biaya Materai",g(h))}
  ${C("Diskon",g(D))}
  ${C("Pembulatan",g(v))}
  ${C("TOTAL TAGIHAN (KOTOR)",g(y),!0)}
  ${C("Ditanggung Jaminan / Klaim BPJS",g(I))}
  ${C("TANGGUNGAN PASIEN (Sisa yang harus dibayar)",g(b))}
  ${C("Uang Muka / Deposit","0")}
  ${C("Bayar (Tunai/Non-Tunai)",g(b))}
  ${C("Kembali","0")}
  ${C("Status",b===0?"Lunas":"-")}
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    ${d?`<img class="rm-sig-qr" src="${M(d)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    <div>Yang Menyerahkan,</div>
    <div>Pasien / Keluarga Pasien</div>
    ${d?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(R)} )</div>
  </div>
  <div class="rm-sig-box">
    ${z?`<img class="rm-sig-qr" src="${M(z)}" alt="QR penerima" width="80" height="80" />`:""}
    <div>Yang Menerima (Petugas Billing / Kasir)</div>
    ${z?"":'<div class="rm-sig-space"></div>'}
  </div>
</div>
</section>`}function aa(i){let s=i.find(c=>/^Resume/i.test(c.title)),a=V(i,/^Resume/i)[0]??"",t=V(i,/^SEP/i)[0]??V(i,/^Rincian Biaya/i)[0]??"",u=s?new DOMParser().parseFromString(s.html,"text/html"):null,n=new Map;if(u)for(let c of Array.from(u.querySelectorAll("tr"))){let w=Array.from(c.cells);for(let E=0;E<w.length-2;E++){let m=(w[E].textContent||"").replace(/\s+/g," ").trim().replace(/^-\s*/,"").replace(/\s*:$/,"");if((w[E+1].textContent||"").trim()!==":")continue;let l=(w[E+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();m&&l&&!n.has(m)&&n.set(m,l)}}let r=(...c)=>{for(let[w,E]of n)if(c.some(m=>m.test(w)))return E;return"-"},j=c=>{for(let[w,E]of n)if(c.test(w))return E;return"-"},o=e("nama"),x=e("norm","rekam_medis"),h=e("tgl_lahir","tglLahir"),D=e("jenis_kelamin","jk"),v=r(/^Tanggal Masuk$/i),I=r(/^Tanggal Keluar$/i),y=r(/^Ruang Rawat$/i),b=r(/^Kelas$/i),g=e("dokter","dpjp"),C=r(/^Anemnesa|^Anamnesa/i),$=r(/^Pemeriksaan Fisik$/i),F=r(/^Hasil Pemeriksaan Diagnostik/i),P=r(/^Diagnosa Utama$/i),R=r(/^Diagnosa Sekunder$/i),k=r(/^Prosedur \/ Operasi|^Diagnosa Tindakan/i),U=r(/^Pengobatan$/i),B=r(/^Obat Pulang$/i),f=r(/^Kondisi Pulang$/i),N=r(/^Catatan Kondisi Pulang$/i),O=r(/^Jadwal Kontrol$/i),A=r(/^Pemeriksaan Lanjutan/i),d=[["TD",j(/^TD$/)],["HR",j(/^HR$/)],["RR",j(/^RR$/)],["S",j(/^S$/)],["SpO2",j(/^SPO2$/)],["GCS",j(/^GCS$/)]].filter(([,c])=>c!=="-").map(([c,w])=>`${c}: ${w}`).join(" | "),z=(c,w)=>`<tr><td style="width: 175px;"><strong>${c}</strong></td><td>${Q(w)}</td></tr>`;return`<section class="rm-page" id="rm-06">
${G("RM. 06")}
<div class="rm-form-title">RINGKASAN PULANG (DISCHARGE SUMMARY)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",o,!0)}
    ${L("No. Rekam Medis",x,!0)}
    ${L("Tgl. Lahir / Kelamin",`${h} / ${D}`)}
    ${L("Jenis Kasus",r(/^Jenis Kasus$/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Masuk",v)}
    ${L("Tanggal Keluar",I)}
    ${L("Ruang / Kelas",`${y} / ${b}`)}
    ${L("DPJP / Rawat Bersama",g)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    ${z("ALASAN / INDIKASI RAWAT &amp; ANAMNESA",`${r(/^Alasan \/ Indikasi Rawat/i)}
${C}`.trim())}
    ${z("PEMERIKSAAN FISIK &amp; TANDA VITAL MASUK",`${$}${d?`
Vital Signs : ${d}`:""}`.trim())}
    ${z("HASIL PEMERIKSAAN DIAGNOSTIK",F)}
    ${z("DIAGNOSA UTAMA",P)}
    ${z("DIAGNOSA SEKUNDER",R)}
    ${z("TINDAKAN / PROSEDUR (ICD-9-CM)",k)}
    ${z("PENGOBATAN SELAMA RAWAT",U)}
    ${z("OBAT PULANG",B)}
    ${z("KONDISI &amp; CARA PULANG",`${f}
${N}`.trim())}
    ${z("INSTRUKSI &amp; JADWAL KONTROL",`${O}
${A}`.trim())}
    ${z("STATUS RUJUKAN &amp; PELAYANAN KB",r(/^Apakah pasien rujukan masuk/i))}
  </tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Mengetahui Pasien / Keluarga</div>
    ${t?`<img class="rm-sig-qr" src="${M(t)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${t?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(o)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Yang Membuat</div>
    ${a?`<img class="rm-sig-qr" src="${M(a)}" alt="QR tanda tangan DPJP" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(g)} )</div>
  </div>
</div>
</section>`}function ia(i){let s=i.find(E=>/^Telaah/i.test(E.title)),a=s?new DOMParser().parseFromString(s.html,"text/html"):null,t=new Map,u=[],n=[],r=[];if(a){for(let m of Array.from(a.querySelectorAll("tr"))){let l=Array.from(m.cells).map(p=>(p.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let p=0;p<l.length-2;p++){let Y=l[p].replace(/:$/,"").trim();l[p+1]===":"&&Y&&l[p+2]&&!t.has(Y)&&t.set(Y,l[p+2])}for(let p of l){let Y=p.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);Y&&!t.has(Y[1].trim())&&t.set(Y[1].trim(),Y[2].trim())}}for(let m of Array.from(a.querySelectorAll("tr"))){let l=Array.from(m.cells).map(Y=>(Y.textContent||"").replace(/\s+/g," ").trim());if(l.length<2||!/^R\/\d+$/i.test(l[0]))continue;let p=l[1].match(/^(.*?)\s*Jml:\s*(\S+)/i);u.push({no:l[0],name:p?p[1].trim():l[1],jml:p?p[2]:"-"})}for(let m of Array.from(a.querySelectorAll("table"))){let l=(m.rows[0]?.textContent||"").replace(/\s+/g," ").trim();if(!/^(Telaah Resep|Telaah Obat|Edukasi)/i.test(l))continue;let p=[];for(let Y of Array.from(m.rows).slice(1)){let J=Array.from(Y.cells).map(W=>(W.textContent||"").replace(/\s+/g," ").trim());J.length<2||!/^\d+$/.test(J[0])||p.push([J[0],J[1]])}p.length&&n.push({title:l.split(/\s{2,}/)[0]||l,rows:p})}let E=Array.from(a.querySelectorAll("table")).find(m=>/Hitung/i.test(m.rows[0]?.textContent||""));E&&r.push(...Array.from(E.rows[0].cells).map(m=>(m.textContent||"").replace(/\s+/g," ").trim()).filter(m=>/Hitung|Timbang|Kemas|Penyerahan/i.test(m)))}r.length||r.push("Hitung","Timbang","Kemas","Penyerahan");let j=(...E)=>{for(let[m,l]of t)if(E.some(p=>p.test(m)))return l;return"-"},o=E=>{for(let m of Array.from(document.querySelectorAll("td"))){let l=(m.textContent||"").replace(/\s+/g," ").trim(),p=l.match(E);if(!p)continue;let Y=l.slice((p.index??0)+p[0].length).replace(/^\s*:\s*/,"").trim();if(Y)return Y;let J=(m.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim();if(J&&!/^:/.test(J))return J}return"-"},x=e("dokter","dpjp")!=="-"?e("dokter","dpjp"):j(/^Dokter/i),h=j(/^No Resep/i),D=o(/^Ruangan\/Poli/i)!=="-"?o(/^Ruangan\/Poli/i):j(/^Ruangan\/?Poli/i,/^Ruangan/i),v=o(/^Tanggal Periksa/i)!=="-"?o(/^Tanggal Periksa/i):j(/^Tanggal/i,/^Tanggal & Jam/i),I=o(/^Jam Datang/i)!=="-"?o(/^Jam Datang/i):j(/^Jam/i),y=j(/^SIP/i),b=e("nama")!=="-"?e("nama"):j(/^Nama Pasien/i),g=e("norm","rekam_medis")!=="-"?e("norm","rekam_medis"):j(/^No\.? RM/i),C=Lt(i),$=e("tgl_lahir","tglLahir").replace(/^:\s*/,"")||j(/^Tgl\.? Lahir/i),F=e("no_hp","telepon").replace(/^:\s*/,"")||j(/^No HP/i),P=j(/^Penjamin/i),R=j(/alergi/i),k=j(/berat|\bbb\b/i),U=e("jenis_kelamin","jk").replace(/^:\s*/,""),B=/perempuan|^p$/i.test(U)?"P":/laki|^l$/i.test(U)?"L":U,f=b+(B&&B!=="-"?` (${B})`:""),N=`${R!=="-"?R:"-"} / ${k!=="-"?`BB ${k}${/\bkg\b/i.test(k)?"":" kg"}`:"- kg"}`,O=e("no_sep","sep")!=="-"?e("no_sep","sep"):e("kartu"),A='<table class="rm-grid-table"><thead><tr>'+r.map(E=>`<th class="center">${M(E)}</th>`).join("")+"</tr></thead><tbody><tr>"+r.map(()=>'<td style="height:30px">&nbsp;</td>').join("")+"</tr></tbody></table>",d=n.length?n.map(E=>`<table class="rm-grid-table"><thead><tr><th colspan="2">${M(E.title)}</th><th style="width:44px;">Y/T</th></tr></thead><tbody>`+E.rows.map(([m,l])=>`<tr><td class="center" style="width:28px;">${M(m)}</td><td>${M(l)}</td><td class="center">&nbsp;</td></tr>`).join("")+"</tbody></table>").join(""):"",z='<table class="rm-grid-table"><tbody><tr><th colspan="2">PERUBAHAN RESEP</th></tr><tr><th>Tertulis</th><th>Menjadi</th></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><td class="center">Apoteker</td><td class="center">Disetujui Dokter</td></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><th colspan="2">WAKTU TUNGGU</th></tr><tr><td>Masuk</td><td>&nbsp;</td></tr><tr><td>Diserahkan</td><td>&nbsp;</td></tr><tr><td>Paraf Pasien/Keluarga</td><td style="height:30px">&nbsp;</td></tr></tbody></table>',c=(E,m,l=!1)=>`<div class="tm-row${l?" long":""}"><span class="tm-label">${M(E)}:</span><span class="tm-val">${m&&m.trim()&&m!=="-"?M(m):"-"}</span></div>`,w=u.length?u.map(E=>`<div class="med"><span class="med-no">${M(E.no)}</span> <span class="med-name">${M(E.name)}</span>`+(E.jml&&E.jml!=="-"?`, <span class="med-jml">Jml: ${M(E.jml)}</span>`:"")+"</div>").join(""):'<div class="med">Tidak ada data obat pada halaman telaah.</div>';return`<section class="rm-page" id="rm-07">
${G("RM. 07")}
<div class="rm-form-title">FORMULIR TELAAH RESEP, TELAAH OBAT &amp; EDUKASI FARMASI</div>

<div class="t-main">
  <div class="t-left">
    <div class="tm-card tm-card--small tm-card--left"><div class="tm-col">
      ${c("Pasien",f)}
      ${c("No. RM",g)}
      ${c("Tgl. Lahir",$)}
      ${c("Alergi &amp; BB",N)}
      ${c("Alamat",C,!0)}
      ${c("No HP",F)}
    </div></div>
    <div class="t-meds">${w}</div>
    ${A}
    <table class="rm-grid-table t-lampiran"><thead><tr>
      <th>Srt. Rujuk Balik</th><th>Surat Iter</th><th>Hasil Lab</th>
    </tr></thead><tbody><tr>
      <td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td>
    </tr></tbody></table>
  </div>
  <div class="t-right">
    <div class="tm-card tm-card--right"><div class="tm-col">
      ${c("Dokter",x)}
      ${c("SIP Dokter",y)}
      ${c("No Resep",h)}
      ${c("No SEP",O)}
      ${c("Ruangan",D)}
      ${c("Tanggal",v)}
      ${c("Jam",I)}
      ${c("Penjamin",P)}
    </div></div>
    ${d}
    ${z}
  </div>
</div>

<div class="footnote-rm">Obat tidak boleh diganti tanpa sepengetahuan Dokter.</div>
</section>`}var ea=/^(No\.?\s*(RONTGEN|RM)|Umur|Tanggal Periksa|Bed|Status|Nama Pasien|Jenis Kelamin|Alamat|dr\.?\s*(Pengirim|DPJP)|Dokter (Pengirim|DPJP)|Diagnosa (Klinis|ICD))/i,Ma=/<div[^>]*class="[^"]*head-cetak-instansi[^"]*"[^>]*>\s*HASIL PEMERIKSAAN RADIOLOGI/i;function La(i,s,a="rm-08"){let t=s??i.find(u=>/^Radiologi/i.test(u.title));return la(t?.html??"",Ma).map((u,n)=>{let r=V([{title:"Radiologi",html:u}],/Radiologi/i)[0]??"";return sa(i,u,r,n?`${a}-${n+1}`:a)}).join("")}function sa(i,s,a,t){let u=new DOMParser().parseFromString(s,"text/html"),n=oa(u,ea),r=[],j="";for(let A of Array.from(u.querySelectorAll("tr"))){let d=Array.from(A.cells).map(rt);for(let z of d){let c=z.match(/^expertise\s*:\s*([\s\S]+)$/i);c&&!j&&(j=c[1].trim())}d.length>=4&&/^\d+$/.test(d[0])&&d[1]&&r.push({name:d[1],golongan:d[2],kontras:d[3]})}let o=(...A)=>{for(let[d,z]of n)if(A.some(c=>c.test(d)))return z;return"-"},x=o(/^No\.? RONTGEN/i),h=o(/^Tanggal Periksa/i),D=o(/^Umur/i),v=e("norm","rekam_medis")!=="-"?e("norm","rekam_medis"):o(/^No\.? RM/i),I=e("nama")!=="-"?e("nama"):o(/^Nama Pasien/i),y=e("jenis_kelamin","jk").replace(/^:\s*/,"")||o(/^Jenis Kelamin/i),b=/perempuan|^p$/i.test(y)?"P":/laki|^l$/i.test(y)?"L":y,g=Lt(i),C=o(/^Bed|^Ruang/i),$=o(/^Status/i),F=o(/^dr\.? Pengirim|^Dokter Pengirim/i),P=o(/^dr\.? DPJP|^Dokter DPJP/i),R=(u.body.textContent||"").replace(/\s+/g," ").match(/\(\s*([^)]{3,80})\s*\)/)?.[1]?.trim()||"-",k=P!=="-"?P:R!=="-"?R:dt(a),U=o(/^Diagnosa Klinis/i),B=o(/^Diagnosa ICD/i),f=r.length&&r[0].golongan||"-",N=r.length?r.map((A,d)=>`<tr><td class="center">${d+1}</td><td><strong>${M(A.name)}</strong></td><td class="center">${M(A.golongan||"-")}</td><td class="center">${M(A.kontras||"-")}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Radiologi ${d+1}"></td></tr>`).join(""):'<tr><td class="center">-</td><td>Tidak ada jenis pemeriksaan tercatat.</td><td class="center">-</td><td class="center">-</td><td class="center">-</td></tr>',O=j?j.replace(/^\s*\d+\.\s*/,"").replace(/^\n+|\n+$/g,"").split(`
`).map(A=>A.trim()).map(A=>A?`<div>${M(A)}</div>`:"<div>&nbsp;</div>").join(""):"<div>Tidak ada expertise tercatat pada halaman.</div>";return`<section class="rm-page" id="${M(t)}">
${G("RM. 08")}
<div class="rm-form-title">HASIL PEMERIKSAAN RADIOLOGI</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("No. Rontgen",x,!0)}
    ${L("Tanggal Periksa",h)}
    ${L("No. Rekam Medis",v)}
    ${L("Nama Pasien",I,!0)}
    ${L("Jenis Kelamin",b!=="-"?`Laki-laki / Perempuan (${b})`:"-")}
    ${L("Alamat",g)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Umur / Tgl. Lahir",D)}
    ${L("Ruang / Asal",C!=="-"&&$!=="-"?`${C} (Status: ${$})`:C)}
    ${L("Dokter Pengirim",F)}
    ${L("Dokter DPJP / Penilai",k)}
    ${L("Diagnosa Klinis",U)}
    ${L("Diagnosa ICD",B)}
    ${L("Status Pasien",$)}
    ${L("Golongan / Jenis",`${f} \u2014 ${r[0]?.kontras||"-"}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>JENIS PEMERIKSAAN</th>
    <th style="width: 110px;">GOLONGAN</th>
    <th style="width: 110px;">KONTRAS</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${N}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr><th>URAIAN EXPERTISE &amp; KESAN PEMERIKSAAN</th></tr></thead>
  <tbody><tr><td style="padding: 8px 10px; line-height: 1.5;">${O}</td></tr></tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>No. Rontgen : ${M(x)}</div>
    <div>Jenis Pemeriksaan : ${M(f)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penilai</div>
    ${a?`<img class="rm-sig-qr" src="${M(a)}" alt="QR tanda tangan radiolog" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(k)} )</div>
  </div>
</div>
</section>`}var ua=i=>{for(let s of i){if(!/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(s.title))continue;let a=new DOMParser().parseFromString(s.html,"text/html");for(let t of Array.from(a.querySelectorAll("table"))){let u=Array.from(t.rows[0]?.cells||[]).map(n=>rt(n)).join(" ");if(/^Triase/i.test(u))return Array.from(t.rows).slice(1).map(n=>Array.from(n.cells).map(rt))}}return[]};function ra(i){let s=i.find(N=>/^Triage/i.test(N.title)),a=V(i,/^Triage/i)[0]??"",t=s?new DOMParser().parseFromString(s.html,"text/html"):null,u=new Map,n="-";if(t){for(let O of Array.from(t.querySelectorAll("tr"))){let A=Array.from(O.cells).map(d=>(d.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let d=0;d<A.length-2;d++){let z=A[d].replace(/:$/,"").trim();A[d+1]===":"&&z&&A[d+2]&&!u.has(z)&&u.set(z,A[d+2])}for(let d of A){let z=d.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);!z||z[2].includes(":")||z[2].length>120||u.has(z[1].trim())||u.set(z[1].trim(),z[2].trim())}}let N=(t.textContent||"").replace(/\s+/g," ").match(/Dokter yang memeriksa\s*\(([^)]+)\)/i);N&&(n=N[1].trim())}let r=(...N)=>{for(let[O,A]of u)if(N.some(d=>d.test(O)))return A;return"-"},j=e("norm","rekam_medis")!=="-"?e("norm","rekam_medis"):r(/^No\.?\s*RM/i),o=e("nama")!=="-"?e("nama"):r(/^Nama$/i),x=r(/^Tanggal$/i),h=r(/^Jam Datang/i),D=r(/^Jam Registrasi/i),v=r(/^Cara Datang/i),I=r(/^Diantar Polisi/i),y=r(/^No\.?\s*ID/i),b=r(/^Pengantar Pasien/i),g=r(/^Riwayat Penyakit Dahulu/i),C=r(/^Keluhan Utama/i),$=r(/^Keadaan Umum/i),F=r(/^Suhu/i),P=r(/^Nadi/i),R=r(/^RR$/i),k=r(/^Tekanan Darah/i),U=r(/^Jam$/i),B=r(/^No\.?\s*Antrian/i),f=r(/^Status/i);return`<section class="rm-page" id="triage">
${G("TRIAGE")}
<div class="rm-form-title">TRIAGE TERINTEGRASI &amp; PENGKAJIAN AWAL IGD</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("No. Rekam Medis",j,!0)}
    ${L("Nama Pasien",o,!0)}
    ${L("Tanggal",x)}
    ${L("Jam Datang",h)}
    ${L("Jam Registrasi",D)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Cara Datang",v)}
    ${L("Diantar Polisi",I)}
    ${L("No. ID",y)}
    ${L("Pengantar Pasien",b)}
    ${L("Status Triage",f,!0)}
  </table></div>
</div>

<div class="sub-heading-rm">ANAMNESA &amp; RIWAYAT</div>
<table class="rm-grid-table"><tbody>
  ${L("Riwayat Penyakit Dahulu",g)}
  ${L("Keluhan Utama",C)}
</tbody></table>

<div class="sub-heading-rm">TANDA VITAL &amp; PEMERIKSAAN</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${L("Keadaan Umum",$)}
    ${L("Suhu (\xB0C)",F)}
    ${L("Nadi (x/menit)",P)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("RR (x/menit)",R)}
    ${L("Tekanan Darah (mmHg)",k)}
    ${L("Jam",U)}
    ${L("No. Antrian",B)}
  </table></div>
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Status Triage : ${M(f)}</div>
    <div>No. Antrian : ${M(B)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${M(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${M(n!=="-"?n:dt(a))} )</div>
  </div>
</div>
</section>`}function na(i){let s=i.find(S=>/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(S.title)),a=s?new DOMParser().parseFromString(s.html,"text/html"):null,t=a?Array.from(a.querySelectorAll("table")):[],u=S=>(S.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim(),n=S=>S?Array.from(S.rows).map(T=>Array.from(T.cells).map(u)):[],r=S=>{let T=t.find(K=>S.test((K.rows[0]?.textContent||"").replace(/\s+/g," ").trim()));return n(T)},j=S=>{let T=t.find(K=>S.test(K.textContent||""));return n(T)},o=t.find(S=>/^Usia$/i.test((S.rows[1]?.cells[1]?.textContent||"").trim())),x=t.find(S=>/^Riwayat Jatuh$/i.test((S.rows[1]?.cells[1]?.textContent||"").trim())),h=S=>S.reduce((T,K)=>{let _=w(K),H=_==="-"?0:Number(_);return T+(Number.isFinite(H)?H:0)},0),D=(S,T)=>T?S>=45?"TINGGI":S>=25?"SEDANG":"RENDAH":S>=12?"TINGGI":S>=6?"SEDANG":"RENDAH",v=(S,T)=>{let K=h(S);return`${K} \u2014 ${D(K,T)}`},I=S=>S?Array.from(S.rows).map((T,K)=>{let _=Array.from(T.cells).map(H=>{let ut=rt(H),ot=H.rowSpan>1?` rowspan="${H.rowSpan}"`:"",va=H.colSpan>1?` colspan="${H.colSpan}"`:"",$a=/JUMLAH SKOR|Keterangan Hasil|Catatan/i.test(ut),Pa=ut.includes("\u2713"),ht=K===0?"th":"td";return`<${ht}${ot}${va}${$a?' style="font-weight:bold;text-align:right;"':""}>${Pa?`<strong>${M(ut)}</strong>`:M(ut||"-")}</${ht}>`}).join("");return`<tr${K===0?' class="sec-hdr"':""}>${_}</tr>`}).join(""):'<tr><td colspan="5">-</td></tr>',y=r(/^Triase/i),b=r(/^Pengkajian\s*0\s*1\s*2\s*Nilai/i),g=j(/MORSE FALL SCALE/i),C=r(/^Objektif\s*Kelainan/i),$=r(/^Diagnosa Utama$/i),F=r(/^Diagnosa Banding$/i),P=r(/^Tindakan$/i),R=r(/^Pukul\s*Nama Obat/i),k=r(/^No\s*Nama Perawat IGD/i),U=(S,T)=>{let K=Array.isArray(T)?T.join(""):T;return'<table class="rm-grid-table"><thead><tr>'+S.map(_=>`<th>${M(_)}</th>`).join("")+"</tr></thead><tbody>"+(K||'<tr><td colspan="'+S.length+'">-</td></tr>')+"</tbody></table>"},B=b.slice(1).map(S=>{if(S.some(T=>/^TOTAL$/i.test((T||"").trim()))){let T=S[S.length-1]||"-";return`<tr style="font-weight:bold;"><td colspan="4" style="text-align:right;"><strong>TOTAL</strong></td><td class="center"><strong>${M(T)}</strong></td></tr>`}return"<tr>"+S.map((T,K)=>`<td${K===0?"":' class="center"'}>${M(T||"-")}</td>`).join("")+"</tr>"}).join(""),f=C.slice(1).map(S=>`<tr><td>${M(S[0]||"-")}</td><td>${M(S.slice(1).filter(Boolean).join(" ")||"-")}</td></tr>`).join(""),N=[["DIAGNOSA UTAMA",$.slice(1).flat().filter(Boolean).join(" ")||"-"],["DIAGNOSA BANDING",F.slice(1).flat().filter(Boolean).join(" ")||"-"]].map(([S,T])=>`<tr><td style="width:180px;"><strong>${S}</strong></td><td>${M(T)}</td></tr>`).join(""),O=P.slice(1).flat().filter(Boolean).join(" ")||"-",A=R.slice(1).filter(S=>S.some(Boolean)).map(S=>"<tr>"+S.slice(0,4).map(T=>`<td>${M(T||"-")}</td>`).join("")+"</tr>").join(""),d=k.slice(1).flat().filter(Boolean).join(" \xB7 "),z=ua(i).find(S=>(S[0]||"").includes("\u2713"))?.slice(1)||[],c=S=>{let T=S.find(H=>/^JUMLAH SKOR/i.test(H[0]||"")),K=S.find(H=>/^Keterangan Hasil/i.test(H[0]||"")),_=T?.slice(1).filter(Boolean).join(" ")||"-";return K?`${_} \xB7 ${K.slice(1).filter(Boolean).join(" ")}`:_},w=S=>document.querySelector(`input[name="${S}"]:checked`)?.value||"-",E=S=>(Array.from(a?.querySelectorAll("label")||[]).find(T=>S.test((T.textContent||"").replace(/\s+/g," ").trim()))?.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim()||"-",m=(Array.from(a?.querySelectorAll("div")||[]).find(S=>/^Planning\s*:\s*Terapy/i.test((S.textContent||"").trim().slice(0,80)))?.nextElementSibling?.textContent||"").split(/TINDAK LANJUT/i)[0].split(/Kondisi Pasien Saat Pindah/i)[0].replace(/[ \t]+/g," ").trim()||"-",l=e("pengkajian_keperawatan"),[p,Y,J]=(()=>{let S=l.split(/\n\s*RPD\s*:/i),T=S[0].replace(/^\s*Subjektif\s*:\s*/i,"").trim()||"-",K=(S[1]||"").split(/\n\s*RPO\s*:/i);return[T,K[0]?.trim()||"-",K[1]?.trim()||"-"]})(),W=(S,T)=>w(S)==="ya"?e(T):w(S)==="tidak"?"Tidak":"-",et=S=>{let T=Array.from(document.querySelectorAll(`input[name="${S}"]:checked`)).map(K=>K.value).filter(Boolean);return T.length?T.join(", "):"-"},Mt=S=>({tanpa_bantuan:"Jalan Tanpa Bantuan",kursi_roda:"Kursi Roda",tempat_tidur:"Brankar",dengan_bantuan:"Dengan Bantuan",tidak_ada:"Tidak mengalami cedera",lantas:"KLL",lainnya:"Lainnya",tidak:"Tidak Terganggu",ya:"Ada Gangguan",Bpjs:"BPJS Kesehatan"})[S]||S||"-",nt=(S,T)=>`<tr><td style="width:175px;"><strong>${S}</strong></td><td>${T}</td></tr>`,fa=(S,T)=>`<tr><td class="lbl">${S}</td><td class="col">:</td><td class="val">${T}</td></tr>`,kt=Number(e("nutrisi_bb")),ct=Number(e("nutrisi_tb"))/100,Oa=kt>0&&ct>0?(kt/(ct*ct)).toFixed(1).replace(".",","):"-";return`<section class="rm-page" id="pengkajian-igd">
${G("PENGKAJIAN IGD")}
<div class="rm-form-title">LEMBAR PENGKAJIAN INSTALASI GAWAT DARURAT</div>

<div class="igd-masthead">
  <div class="igd-masthead-label">Pasien \xB7 Instalasi Gawat Darurat</div>
  <div class="igd-masthead-name">${M(e("nama"))}</div>
</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"),!0)}
    ${L("Tgl. Lahir / Umur",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",/perempuan|^p$/i.test(e("jenis_kelamin","jk"))?"Perempuan (P)":"Laki-laki (L)")}
    ${L("Agama / Suku",`${E(/^Agama/i)} / ${E(/^Suku/i)}`)}
    ${L("Pekerjaan",e("pekerjaan"))}
    ${L("No. Telp / HP",e("no_hp","telepon"))}
    ${L("Nama Orangtua / Pasangan",`${e("nama_orangtua")} / ${e("nama_pasangan")}`)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Masuk",e("tgl_masuk"))}
    ${L("Tiba di IGD / Diperiksa",`Pukul ${e("pukul_tiba_di_rs")} / Diperiksa Pukul ${e("pukul_diperiksa")}`)}
    ${L("Prosedur Masuk",Mt(w("kaji[prosedur_masuk]")))}
    ${L("Cara Masuk",Mt(w("kaji[cara_masuk]")))}
    ${L("Penyebab Cedera",Mt(w("kaji[penyebab_cedera]")))}
    ${L("Status Alergi",W("kaji[status_alergi]","status_alergi_text"))}
    ${L("Gangguan Perilaku",Mt(w("kaji[gangguan_perilaku]")))}
    ${fa("Status Kehamilan",/perempuan|^p$/i.test(e("jenis_kelamin","jk"))?M(e("status_kehamilan")):'<span class="filter-note">Tidak berlaku (Pasien Laki-laki \u2014 disaring otomatis)</span>')}
  </table></div>
</div>

<div class="igd-summary">
  <div><span>Triase</span><b>${M(z[0]||"-")} ${M(z[1]||"")}</b></div>
  <div><span>GCS / Kesadaran</span><b>${M(e("vital_gcs"))} \xB7 ${M(e("vital_kesadaran"))}</b></div>
  <div><span>SpO2 / Nadi</span><b>${M(e("vital_spo"))} \xB7 ${M(e("vital_nadi"))}</b></div>
  <div><span>Risiko Jatuh (Morse)</span><b>${M(c(g))}</b></div>
</div>

<div class="sub-heading-rm">KONDISI AWAL &amp; RIWAYAT</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${L("Prosedur Masuk",w("kaji[prosedur_masuk]"))}
    ${L("Cara Masuk",w("kaji[cara_masuk]"))}
    ${L("Status Alergi",W("kaji[status_alergi]","status_alergi_text"))}
    ${L("Status Psikologi",w("kaji[status_psikologi]"))}
    ${L("Status Sosial",w("kaji[status_sosial]"))}
    ${L("Status Ekonomi",w("kaji[status_ekonomi]"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Nutrisi (BB/TB)",`${e("nutrisi_bb")} kg / ${e("nutrisi_tb")} cm`)}
    ${L("Kognitif",w("kaji[fungsi_kognitif]"))}
    ${L("Motorik",w("kaji[fungsi_motorik]"))}
    ${L("Hambatan Pembelajaran",W("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text"))}
    ${L("Kebutuhan Edukasi",w("kaji[kebutuhan_edukasi]"))}
    ${L("Penerjemah",W("kaji[dibutuhkan_penerjemah]","penerjemah_text"))}
  </table></div>
</div>

<div class="sub-heading-rm">TANDA VITAL SAAT MASUK</div>
${U(["TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","GCS (E/V/M)","KESADARAN"],["<tr>"+[At(e("vital_td")),e("vital_nadi"),e("vital_nafas"),e("vital_suhu"),e("vital_spo"),e("vital_gcs")].map(S=>`<td class="center">${M(S)}</td>`).join("")+`<td class="center">${M([e("vital_e"),e("vital_m"),e("vital_v")].join("/"))}</td><td class="center">${M(e("vital_kesadaran"))}</td></tr>`])}

<div class="sub-heading-rm">KONDISI SAAT PINDAH / PULANG DARI IGD</div>
${U(["PUKUL","TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","KESADARAN"],["<tr>"+[e("waktu_pasien_pulang"),At(e("kondisi_pasien_td")),e("kondisi_pasien_nadi"),e("kondisi_pasien_nafas"),e("kondisi_pasien_suhu"),e("kondisi_pasien_spo"),e("kondisi_pasien_gcs"),e("kondisi_pasien_kesadaran")].map(S=>`<td class="center">${M(S)}</td>`).join("")+"</tr>"])}

<div class="sub-heading-rm">TRIASE (DIISI OLEH DOKTER)</div>
<table class="rm-table">
  <thead>
    <tr><th style="width:34px;">PILIH</th><th style="width:95px;">SKALA TRIASE</th><th>KATEGORI &amp; KETERANGAN KLINIS</th><th style="width:105px;">RESPON TIME</th></tr>
  </thead>
  <tbody>${y.slice(1).map(S=>{let T=(S[0]||"").includes("\u2713"),K=S.length>=4?S.slice(1,4):S.slice(0,3);return`<tr${T?' style="font-weight:bold;"':""}><td class="center"><span class="chk-box">${T?"&#10003;":"&nbsp;"}</span></td>${K.map(_=>`<td>${M(_||"-")}</td>`).join("")}</tr>`}).join("")}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">II. PENGKAJIAN PSIKOSOSIAL, SPIRITUAL, EKONOMI, NUTRISI &amp; FUNGSIONAL</td></tr></thead>
  <tbody>
    ${nt("Status Psikologi",w("kaji[status_psikologi]")||"-")}
    ${nt("Status Sosial &amp; Spiritual",`Hubungan keluarga: ${w("kaji[status_sosial]")||"-"} | Kegiatan keagamaan: ${M(e("status_spiritual"))}`)}
    ${nt("Status Pembiayaan",Mt(w("kaji[status_ekonomi]")))}
    ${nt("Antropometri &amp; Nutrisi",`BB: <strong>${M(e("nutrisi_bb"))} Kg</strong> | TB: <strong>${M(e("nutrisi_tb"))} Cm</strong> | IMT: <strong>${Oa} kg/m&sup2;</strong> | Konsul Gizi: ${w("kaji[nutrisi_konsul]")||"-"}`)}
    ${nt("Status Fungsional",`Kognitif: ${w("kaji[fungsi_kognitif]")||"-"} | Motorik: ${w("kaji[fungsi_motorik]")||"-"}`)}
    ${nt("Komunikasi &amp; Edukasi",`Hambatan: ${W("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text")} | Penerjemah: ${W("kaji[dibutuhkan_penerjemah]","penerjemah_text")} | Kebutuhan Edukasi: ${et("kaji[kebutuhan_edukasi]")}`)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">III. ASESMEN NYERI \u2014 WONG BAKER / NRS (PQRST)</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;"><strong>Skala Wong Baker</strong></td>
      <td><span class="filter-note">Skala nyeri Wong Baker (0\u20135) \u2014 lihat halaman asal; di dossier ini tidak ditampilkan sebagai gambar.</span></td>
    </tr>
    <tr><td><strong>(P) Faktor Pencetus</strong></td><td>${M(e("faktor_pencetus"))}</td></tr>
    <tr><td><strong>(Q) Kualitas Nyeri</strong></td><td>${w("kaji[qualitas]")||"-"}</td></tr>
    <tr><td><strong>(R) Lokasi &amp; Penjalaran</strong></td><td>${M(e("lokasi_nyeri"))} &nbsp;|&nbsp; <strong>Menjalar:</strong> ${w("kaji[nyeri_menjalar]")||"-"}</td></tr>
    <tr><td><strong>(S) Skala Nyeri (NRS 0\u201310)</strong></td><td>${M(e("skala_nyeri"))} &nbsp;|&nbsp; Wong Baker: ${M(e("emo_wong"))}</td></tr>
    <tr><td><strong>(T) Waktu &amp; Frekuensi</strong></td><td>${M(e("lamanya_nyeri"))} &nbsp;|&nbsp; ${w("kaji[nyeri_frekwensi]")||"-"}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="5">IV. PENGKAJIAN NYERI (FLACC)</td></tr>
    <tr><th>PENGKAJIAN</th><th>0</th><th>1</th><th>2</th><th>NILAI</th></tr>
  </thead>
  <tbody>${B||'<tr><td colspan="5">-</td></tr>'}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">V. ASESMEN AWAL RESIKO JATUH PADA ANAK (HUMPTY DUMPTY)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${v(["kaji[arja_usia]","kaji[arja_jenis_kelamin]","kaji[arja_diagnosis]","kaji[arja_gangguan_kognitif]","kaji[arja_faktor_lingkungan]","kaji[arja_respon_pembedahan]","kaji[arja_medikamentosa]"],!1)}</strong></td>
    </tr>
    ${I(o)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">VI. ASESMEN AWAL RESIKO JATUH PADA DEWASA (MORSE FALL SCALE)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${v(["kaji[arja_dewasa_jatuh]","kaji[arja_dewasa_diagnosa]","kaji[arja_dewasa_alat]","kaji[arja_dewasa_infus]","kaji[arja_dewasa_carajalan]","kaji[arja_dewasa_mental]"],!0)}</strong></td>
    </tr>
    ${I(x)}
  </tbody>
</table>

<div class="two-col-grid">
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0; height: 100%;">
      <thead>
        <tr class="sec-hdr"><td colspan="3">VI-A. PERBANDINGAN TANDA VITAL (OBJEKTIF)</td></tr>
        <tr><th>PARAMETER</th><th style="width: 108px;">AWAL IGD</th><th style="width: 108px;">PINDAH HCU</th></tr>
      </thead>
      <tbody>
        ${[["Tekanan Darah (TD)",e("vital_td"),e("kondisi_pasien_td")],["Nadi (HR)",e("vital_nadi"),e("kondisi_pasien_nadi")],["Pernapasan (RR)",e("vital_nafas"),e("kondisi_pasien_nafas")],["Suhu Aksila",e("vital_suhu"),e("kondisi_pasien_suhu")],["Saturasi Oksigen (SpO2)",e("vital_spo"),e("kondisi_pasien_spo")],["Kesadaran",e("vital_kesadaran"),e("kondisi_pasien_kesadaran")],["Skor GCS",e("vital_gcs"),e("kondisi_pasien_gcs")]].map(([S,T,K])=>`<tr><td><strong>${M(S)}</strong></td><td class="center">${M(T)}</td><td class="center">${M(K)}</td></tr>`).join("")}
      </tbody>
    </table>
  </div>
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0;">
      <thead>
        <tr class="sec-hdr"><td colspan="2">VI-B. PEMERIKSAAN FISIK LOKALIS &amp; PENUNJANG</td></tr>
        <tr><th>OBJEKTIF</th><th>KELAINAN</th></tr>
      </thead>
      <tbody>${f}</tbody>
    </table>
  </div>
</div>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">V. PENGKAJIAN MEDIS DOKTER IGD \u2014 ANAMNESIS (SUBJEKTIF)</td></tr></thead>
  <tbody>
    <tr><td style="width:155px;"><strong>(a) Keluhan Utama &amp; RPS</strong></td><td>${Q(p)}</td></tr>
    <tr><td><strong>(b) Riwayat Penyakit Dahulu (RPD)</strong></td><td>${Q(Y)}</td></tr>
    <tr><td><strong>(c) Riwayat Penggunaan Obat (RPO)</strong></td><td>${Q(J)}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">VI. DIAGNOSA &amp; TINDAKAN & PLANNING TERINTEGRASI</td></tr></thead>
  <tbody>
    ${N}
    <tr><td style="width:165px;"><strong>TINDAKAN</strong></td><td>${M(O)}</td></tr>
    <tr>
      <td><strong>PEMERIKSAAN PENUNJANG</strong></td>
      <td>EKG: ${M(E(/^EKG$/i))} &nbsp;|&nbsp; Radiologi: ${M(E(/^Radiologi$/i))} &nbsp;|&nbsp; Laboratorium: ${M(E(/^Laboratorium$/i))}</td>
    </tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">IX. PENGKAJIAN KEPERAWATAN &amp; MEDIS</td></tr></thead>
  <tbody><tr><td style="width:165px;"><strong>PENGKAJIAN KEPERAWATAN</strong></td><td>${Q(e("pengkajian_keperawatan"))}</td></tr></tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">X. PLANNING / TERAPI TERINTEGRASI</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;vertical-align:top;"><strong>Tatalaksana Awal (A)</strong></td>
      <td>${Q(m.split(/Konsul dr\./i)[0].trim()||"-")}</td>
    </tr>
    ${m.split(/(?=Konsul dr\.)/i).slice(1).map((S,T)=>{let K=S.match(/^Konsul (dr\.?[^:\n]+)/i)?.[1]?.trim()||"-",_=S.match(/Plan\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",H=S.match(/Terapi\s*:\s*([\s\S]*?)(?=Konsul dr\.|$)/i)?.[1]?.trim()||"-",ut=S.match(/Dx\s*:\s*([\s\S]*?)(?=Masalah\s*:|Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",ot=S.match(/Masalah\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-";return`<tr>
          <td style="width:165px;vertical-align:top;"><strong>Advis ( ${String.fromCharCode(66+T)} ) \u2014 ${M(K)}</strong></td>
          <td>
            ${ut!=="-"?`<strong>Dx:</strong> ${Q(ut)}<br/>`:""}
            ${ot!=="-"?`<strong>Masalah:</strong> ${Q(ot)}<br/>`:""}
            ${_!=="-"?`<strong>Visite Plan:</strong> ${Q(_)}<br/>`:""}
            ${H!=="-"?`<strong>Terapi:</strong> ${Q(H)}`:""}
          </td>
        </tr>`}).join("")}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">XI. DISPOSISI TINDAK LANJUT</td></tr></thead>
  <tbody>
    <tr><td style="width:165px;"><strong>Tindak Lanjut</strong></td><td>${w("medis[tindak_lanjut]")||"-"}</td></tr>
    <tr><td><strong>Ruangan Rawat Inap</strong></td><td>${M(e("tindak_lanjut_ruangan_ranap"))} \u2014 Indikasi: ${M(e("tindak_lanjut_indikasi_ranap"))}</td></tr>
    <tr><td><strong>Pukul Pindah / Pulang</strong></td><td>${M(e("waktu_pasien_pulang"))}</td></tr>
    <tr><td><strong>Kondisi Pasien Saat Pindah</strong></td><td>TD ${M(At(e("kondisi_pasien_td")))} | Nadi ${M(e("kondisi_pasien_nadi"))} | RR ${M(e("kondisi_pasien_nafas"))} | Suhu ${M(e("kondisi_pasien_suhu"))} | SpO2 ${M(e("kondisi_pasien_spo"))} | GCS ${M(e("kondisi_pasien_gcs"))} | Kesadaran ${M(e("kondisi_pasien_kesadaran"))}</td></tr>
  </tbody>
</table>

<div class="sub-heading-rm">OBAT / TERAPI IGD</div>
${U(["PUKUL","NAMA OBAT","DOSIS / RUTE","TANDA TANGAN"],A)}

<div class="sub-heading-rm">PERAWAT IGD</div>
<table class="rm-grid-table"><tbody><tr><td>${M(d||"-")}</td></tr></tbody></table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Ruangan : ${M(e("tindak_lanjut_ruangan_ranap"))}</div>
    <div>Perawat Ruangan : ${M(e("perawat_ruangan"))}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter IGD</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( ${M(e("dokter_igd","dokter"))} )</div>
  </div>
</div>
</section>`}function ja(i,s){let a=[/^Telaah/i,/^SBPK/i,/^Radiologi/i],t=n=>{let r=a.findIndex(j=>j.test(n));return r<0?99:r},u=[...i].sort((n,r)=>t(n.title)-t(r.title));for(let n of u){let r=new DOMParser().parseFromString(n.html,"text/html");for(let j of Array.from(r.querySelectorAll("tr"))){let o=Array.from(j.cells).map(x=>(x.textContent||"").replace(/\s+/g," ").trim());for(let x=0;x<o.length-2;x++)if(s.test(o[x])&&o[x+1]===":"&&o[x+2])return o[x+2];for(let x of o){let h=x.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);if(h&&s.test(h[1].trim())&&h[2]&&!h[2].includes(":")&&h[2].length<=160)return h[2].trim()}}}return"-"}var Lt=i=>st("alamat").replace(/^\s*:\s*/,"").trim()||ja(i,/^Alamat/i),V=(i,s)=>{let a=i.find(u=>s.test(u.title));if(!a)return[];let t=new DOMParser().parseFromString(a.html,"text/html");return Array.from(t.querySelectorAll("img")).map(u=>u.getAttribute("src")||"").filter(u=>/qr|barcode/i.test(u))},dt=i=>{if(!i)return"-";try{let s=decodeURIComponent(i.replace(/\+/g," "));return(s.match(/approve\s*([\s\S]*?)\s+tgl\b/i)?.[1]||s.match(/(dr\.[^&]+)/i)?.[1]||"").split(/\s+(?:tgl|jam)\b/i)[0].replace(/\s+/g," ").trim()||"-"}catch{return"-"}},At=i=>/\d/.test(i)?i:"-";function Z(i,s){let a=i.find(n=>s.test(n.title)),t=a?new DOMParser().parseFromString(a.html,"text/html"):null,u=new Map;if(!t)return u;for(let n of Array.from(t.querySelectorAll("tr"))){let r=Array.from(n.cells).map(j=>(j.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let j=0;j<r.length-2;j++){let o=r[j].replace(/^[-:\s]+|[\s:]+$/g,"");!o||r[j+1]!==":"||!r[j+2]||u.has(o)||u.set(o,r[j+2])}for(let j of r){let o=j.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);o&&!o[2].includes(":")&&o[2].length<=120&&!u.has(o[1].trim())&&u.set(o[1].trim(),o[2].trim())}}return u}var lt=i=>i.replace(/&gt;/gi,">").replace(/&lt;/gi,"<").replace(/&quot;/gi,'"').replace(/&#39;/g,"'").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&nbsp;/gi," ");function rt(i){return lt((i.innerHTML||"").replace(/<!--[\s\S]*?-->/g,"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim())}function la(i,s){let a=new RegExp(s.source,s.flags.includes("g")?s.flags:s.flags+"g"),t=Array.from(i.matchAll(a)).map(u=>u.index??0);return t.length<2?[i]:t.map((u,n)=>i.slice(u,n+1<t.length?t[n+1]:i.length))}function oa(i,s){let a=new Map;for(let t of Array.from(i.querySelectorAll("tr"))){let u=Array.from(t.cells).map(rt);for(let n=0;n<u.length-1;n++){let r=u[n].replace(/^[-:\s]+|[\s:]+$/g,"").trim();if(!s.test(r)||a.has(r))continue;let j=u[n+1].replace(/^:\s*/,"").trim();j&&a.set(r,j)}}return a}var tt=(i,...s)=>{for(let[a,t]of i)if(s.some(u=>u.test(a)))return lt(t);return"-"};function at(i,s,a=30){let t=i.find(r=>s.test(r.title)),u=t?new DOMParser().parseFromString(t.html,"text/html"):null;if(!u)return[];let n=[];for(let r of Array.from(u.querySelectorAll("tr"))){let j=Array.from(r.cells).map(o=>(o.textContent||"").replace(/\s+/g," ").trim());if(j.length&&j.some(Boolean)&&n.push(j),n.length>=a)break}return n}var q=i=>'<table class="rm-grid-table"><tbody>'+i.map(([s,a])=>`<tr><td style="width:175px;"><strong>${s}</strong></td><td>${Q(a)}</td></tr>`).join("")+"</tbody></table>",it=(i,s,a=!1)=>{let t=a?[...i,"VER (&#10003;)"]:i;return'<table class="rm-grid-table"><thead><tr>'+t.map(u=>`<th>${u}</th>`).join("")+"</tr></thead><tbody>"+(s.length?s.map(u=>"<tr>"+t.map((n,r)=>a&&r===t.length-1?'<td class="center"><input type="checkbox" class="rm-checkbox"></td>':`<td>${Q(u[r]||"-")}</td>`).join("")+"</tr>").join(""):`<tr><td colspan="${t.length}">-</td></tr>`)+"</tbody></table>"},X=(i,s)=>'<div class="rm-signature-block">'+[i,s].map((a,t)=>`<div class="rm-sig-box${t?"":" left-align"}">`+a.slice(0,-1).map(u=>`<div>${u}</div>`).join("")+`<div class="rm-sig-space"></div><div class="rm-sig-name">${a[a.length-1]}</div></div>`).join("")+"</div>";function Sa(i){let s=i.find(l=>/^Persetujuan Tindakan/i.test(l.title)),a=s?new DOMParser().parseFromString(s.html,"text/html"):null,t=a?Array.from(a.querySelectorAll("table")):[],u=l=>lt((l.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()),n=l=>l?Array.from(l.rows).map(p=>Array.from(p.cells).map(u)):[],r=l=>l?.querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",j=l=>l.replace(/-->\s*/g,"").replace(/\btsb\b/gi,"tersebut").replace(/pembiuasan/gi,"pembiusan").replace(/\bizi Tuhan\b/gi,"izin Tuhan").replace(/\bresiko\b/gi,"risiko").replace(/\bAm\.?kep\b/gi,"A.Md.Kep").replace(/\s+/g," ").trim(),o=t.find(l=>/PEMBERIAN INFORMASI/i.test(l.rows[0]?.textContent||"")),x=t.find(l=>/JENIS INFORMASI/i.test(l.rows[0]?.textContent||"")),h=t.find(l=>/Dengan ini menyatakan bahwa saya dokter/i.test(l.rows[0]?.textContent||"")),D=t.find(l=>/PERSETUJUAN TINDAKAN KEDOKTERAN/i.test(l.rows[0]?.textContent||"")),v=n(o).slice(1).map(l=>[l[0]||"-",j((l[1]||l[2]||"-").replace(/^:\s*/,""))]).filter((l,p,Y)=>Y.findIndex(J=>J[0]===l[0])===p),I=n(x).slice(1).map((l,p)=>({no:/^\d+$/.test(l[0]||"")?l[0]:String(p+1),label:j(l[1]||"-"),isi:j(l[2]||"-"),centang:(l[3]||"").includes("\u2713")})),y=(h?Array.from(h.rows):[]).map(l=>({teks:j(u(l.cells[0])),ttd:j(l.cells[1]?u(l.cells[1]):""),qr:r(l.cells[1])})).filter((l,p,Y)=>Y.findIndex(J=>J.teks===l.teks)===p),b=n(D),g=j(b[2]?.join(" ")||"-"),C=j(b[3]?.join(" ")||"-"),$=(D?Array.from(D.rows[4]?.cells||[]):[]).map((l,p)=>({teks:j(u(l)),qr:p===2?r(l):""})),F=e("nama"),P=l=>l.replace(/Jambi\s*,?\s*\d{1,2}\/\d{1,2}\/\d{4}\s*,?\s*Jam\s*[\d:.]+/gi,"").replace(/\s+/g," ").trim(),R=l=>l.match(/\(([^)]+)\)/)?.[1]?.trim()||P(l)||"-",k=P(g),U=P(C),B=k.match(/Nama\s*:\s*(.+?)(?=\s+Umur\s*:|$)/i)?.[1]?.trim()||"-",f=k.match(/Umur\s*:\s*(.+?)(?=\s+Jenis Kelamin\s*:|$)/i)?.[1]?.trim()||"-",N=k.match(/Jenis Kelamin\s*:\s*(.+?)(?=\s+Alamat\s*:|$)/i)?.[1]?.trim()||"-",O=k.match(/Alamat\s*:\s*(.+)$/i)?.[1]?.trim()||"-",A=I.find(l=>l.no==="3")?.isi||"-",d=l=>U.match(l)?.[0]?.trim()||"",z=[d(/Saya memahami perlunya dan manfaat tindakan tersebut[\s\S]*?(?=Saya juga menyadari|$)/i),d(/Saya juga menyadari[\s\S]*?(?=Saya memahami perlunya tindakan pembiusan|Saya bertanggung jawab|$)/i),d(/Saya memahami perlunya tindakan pembiusan[\s\S]*?(?=Saya bertanggung jawab|$)/i),d(/Saya bertanggung jawab[\s\S]*$/i)].filter(Boolean),c=(l,p)=>{let Y=P($[l]?.teks||"").replace(p,"");return R(Y)},w=c(0,/Yang Menyatakan/i),E=c(1,/Saksi Keluarga/i),m=c(2,/Saksi Rumah Sakit/i);return`<section class="rm-page" id="form-konsent">
${G("RM. 19A")}
<div class="rm-form-title">PERSETUJUAN TINDAKAN KEDOKTERAN (RM 19 A)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",F,!0)}
    ${L("Umur",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
    ${L("Alamat",Lt(i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${v.map(([l,p])=>L(l,p,l==="Penerima Informasi / Pemberi Persetujuan")).join("")}
  </table></div>
</div>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="4">I. PEMBERIAN INFORMASI</td></tr>
    <tr><th style="width:28px;">NO</th><th>JENIS INFORMASI</th><th>ISI INFORMASI</th><th style="width:70px;">TANDA (&#10003;)</th></tr>
  </thead>
  <tbody>
    ${I.length?I.map(l=>`<tr><td class="center">${M(l.no)}</td><td>${M(l.label)}</td><td>${Q(l.isi)}</td><td class="center">${l.centang?"&#10003;":"&nbsp;"}</td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="4">II. PERNYATAAN PEMBERI &amp; PENERIMA INFORMASI</td></tr></thead>
  <tbody>
    ${y.length?y.map((l,p)=>`<tr><td colspan="3">${Q(P(l.teks))}</td><td style="text-align:center;vertical-align:top;"><div>${p===0?"Tanda Tangan Dokter":"Tanda Tangan Penerima"}</div>`+(l.qr?`<img class="rm-sig-qr" src="${M(l.qr)}" alt="QR tanda tangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>')+`<div>( <strong>${M(R(l.ttd))}</strong> )</div></td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
    <tr><td colspan="4">* Bila pasien tidak kompeten atau tidak mau menerima informasi, maka penerima informasi adalah wali atau keluarga terdekat.</td></tr>
  </tbody>
</table>

<div style="border:1px solid #000000;margin-bottom:5px;">
  <div class="sec-hdr" style="border-bottom:1px solid #000000;padding:4px 6px;">III. PERSETUJUAN TINDAKAN KEDOKTERAN</div>
  <div style="padding:5px 8px;">
    <div>Yang bertanda tangan di bawah ini, saya:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:80px;">Nama</td><td style="width:10px;">:</td><td><strong>${M(B)}</strong></td><td style="width:80px;">Umur</td><td style="width:10px;">:</td><td>${M(f)}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td>${M(N)}</td><td>Alamat</td><td>:</td><td>${M(O)}</td></tr>
    </tbody></table>
    <div>Dengan ini menyatakan <strong>PERSETUJUAN</strong> untuk dilakukannya tindakan kedokteran (<strong>${M(A)}</strong>) terhadap: &nbsp; <span class="chk-box">&nbsp;</span> diri saya sendiri &nbsp; <span class="chk-box">&#10003;</span> <strong>Wali / Keluarga dari pasien</strong>:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:90px;">Nama Pasien</td><td style="width:10px;">:</td><td><strong>${M(F)}</strong></td><td style="width:70px;">Umur</td><td style="width:10px;">:</td><td>${M(e("tgl_lahir","tglLahir"))}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td><span class="chk-box">${/laki|^l$/i.test(e("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Laki-laki &nbsp; <span class="chk-box">${/perempuan|^p$/i.test(e("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Perempuan</td><td>Alamat</td><td>:</td><td>${M(Lt(i))}</td></tr>
    </tbody></table>
    ${z.map((l,p)=>`<div style="text-align:justify;margin:3px 0;">${p+1}. ${M(l)}</div>`).join("")}
    <table class="rm-table"><thead><tr>
      <th>Yang Menyatakan / Pemberi Persetujuan</th><th>Saksi Keluarga</th><th>Saksi Rumah Sakit</th>
    </tr></thead><tbody><tr>
      <td style="text-align:center;">
        ${$[0]?.qr?`<img class="rm-sig-qr" src="${M($[0].qr)}" alt="QR penandatangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${M(w)}</strong> )
      </td>
      <td style="text-align:center;">
        ${$[1]?.qr?`<img class="rm-sig-qr" src="${M($[1].qr)}" alt="QR saksi keluarga" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${M(E)}</strong> )
      </td>
      <td style="text-align:center;">
        ${$[2]?.qr?`<img class="rm-sig-qr" src="${M($[2].qr)}" alt="QR saksi rumah sakit" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${M(m)}</strong> )
      </td>
    </tr></tbody></table>
  </div>
</div>
</section>`}function da(i){let s=Z(i,/^Anestesi/i),a=at(i,/^Anestesi/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-anestesi">
${G("ANESTESI")}
<div class="rm-form-title">REKAM PELAKSANAAN ANESTESI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal",t(/^Tanggal/i))}
    ${L("Jenis Anestesi",t(/^Jenis Anestesi|^Anestesi/i))}
    ${L("ASA",t(/^ASA/i))}
    ${L("Dokter Anestesi",t(/^Dokter Anestesi|^Anestesiologi/i))}
  </table></div>
</div>
${q([["DIAGNOSA / TINDAKAN",t(/^Diagnosa|^Tindakan/i)],["PEMERIKSAAN PRA ANESTESI",t(/^Pra Anestesi|^Pemeriksaan/i)],["OBAT &amp; TEKNIK ANESTESI",t(/^Obat|^Teknik/i)],["KOMPLIKASI / CATATAN",t(/^Komplikasi|^Catatan/i)]])}
<div class="sub-heading-rm">MONITORING ANESTESI</div>
${it(["JAM","TEKANAN DARAH","NADI","RR","SpO2","CATATAN"],a,!0)}
${X(["Petugas Anestesi",`( ${M(t(/^Dokter Anestesi|^Anestesiologi/i))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Dokter Operator",`( ${M(e("dokter","dpjp"))} )`])}
</section>`}function Aa(i){let s=Z(i,/^Fisioterapi/i),a=at(i,/^Fisioterapi/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-fisioterapi">
${G("FISIOTERAPI")}
<div class="rm-form-title">LEMBAR ASSESMEN &amp; TERAPI FISIOTERAPI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal",t(/^Tanggal/i))}
    ${L("Diagnosa",t(/^Diagnosa/i))}
    ${L("Ruang / Asal",t(/^Ruang|^Unit/i))}
    ${L("Terapis",t(/^Terapis|^Fisioterapis/i))}
  </table></div>
</div>
${q([["KELUHAN UTAMA (SUBJEKTIF)",t(/^Keluhan|^Subjektif/i)],["PEMERIKSAAN OBJEKTIF (ROM / MMT / FUNGSI)",t(/^Objektif|^Pemeriksaan/i)],["ASSESMEN FISIOTERAPI",t(/^Assesmen|^Diagnosa Fisio/i)],["RENCANA TERAPI &amp; TUJUAN",t(/^Rencana|^Terapi|^Tujuan/i)]])}
<div class="sub-heading-rm">PELAKSANAAN TERAPI</div>
${it(["TANGGAL","MODALITAS / LATIHAN","FREKUENSI","RESPON PASIEN"],a,!0)}
${X(["Pasien / Keluarga Pasien",`( ${M(e("nama"))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Terapis / Fisioterapis",`( ${M(t(/^Terapis|^Fisioterapis/i))} )`])}
</section>`}function Na(i){let s=Z(i,/^Pengkajian Hemodialisa/i),a=at(i,/^Pengkajian Hemodialisa/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-hemodialisa">
${G("HEMODIALISA")}
<div class="rm-form-title">LEMBAR PENGKAJIAN &amp; SESI HEMODIALISA</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Sesi",t(/^Tanggal/i))}
    ${L("Akses Vaskular",t(/^Akses/i))}
    ${L("Diagnosa",t(/^Diagnosa/i))}
    ${L("Perawat / Dokter",t(/^Perawat|^Dokter/i))}
  </table></div>
</div>
${it(["PARAMETER","SEBELUM DIALISA","SESUDAH DIALISA","KETERANGAN"],[["Berat Badan",t(/^BB Sebelum|^Berat Sebelum/),t(/^BB Sesudah|^Berat Sesudah/),"-"],["Tekanan Darah",t(/^TD Sebelum|^Tekanan Sebelum/),t(/^TD Sesudah|^Tekanan Sesudah/),"-"],["Nadi",t(/^Nadi Sebelum/),t(/^Nadi Sesudah/),"-"],...a],!0)}
${q([["BLOOD FLOW / DIALYSATE FLOW",t(/^Blood Flow|^Dialysate/i)],["ULTRAFILTRASI &amp; Heparinisasi",t(/^Ultrafiltrasi|^UF|^Heparin/i)],["ADEKUASI (Kt/V)",t(/^Kt\/V|^Adekuasi/i)],["KOMPLIKASI / CATATAN",t(/^Komplikasi|^Catatan/i)]])}
${X(["Pasien / Keluarga Pasien",`( ${M(e("nama"))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Perawat Hemodialisa",`( ${M(t(/^Perawat/i))} )`])}
</section>`}function ca(i){let s=Z(i,/^Operasi/i),a=at(i,/^Operasi/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-operasi">
${G("OPERASI")}
<div class="rm-form-title">LAPORAN PELAKSANAAN OPERASI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Operasi",t(/^Tanggal/i))}
    ${L("Diagnosa Pra Operasi",t(/^Diagnosa Pra|^Diagnosa Awal/i))}
    ${L("Diagnosa Pasca Operasi",t(/^Diagnosa Pasca|^Diagnosa Akhir/i))}
    ${L("Tindakan / ICD-9-CM",t(/^Tindakan|^Prosedur/i))}
  </table></div>
</div>
${q([["JENIS ANESTESI &amp; ASA",t(/^Anestesi|^ASA/i)],["TIM OPERASI (OPERATOR / ASISTEN / ANASTESI)",t(/^Operator|^Asisten|^Tim Operasi/i)],["ALAT / BAHAN &amp; IMPLAN",t(/^Alat|^Bahan|^Implan/i)],["URAIAN PROSEDUR &amp; TEMUAN",t(/^Uraian|^Prosedur|^Temuan/i)],["KOMPLIKASI INTRA OPERASI",t(/^Komplikasi/i)],["KEADAAN PASIEN SELESAI OPERASI",t(/^Keadaan|^Kondisi/i)]])}
<div class="sub-heading-rm">RINCIAN TINDAKAN</div>
${it(["NO","TINDAKAN / PROSEDUR","WAKTU","PELAKSANA"],a,!0)}
${X(["Asisten Operasi","-"],["Kota Jambi, "+M(t(/^Tanggal/i)),"Dokter Operator",`( ${M(t(/^Operator/i))} )`])}
</section>`}function ga(i){let s=i.find(u=>/^Laboratorium/i.test(u.title)),a=s?new DOMParser().parseFromString(s.html,"text/html"):null,t=a?Array.from(a.querySelectorAll("img")).map(u=>u.outerHTML).filter(u=>!/logo/i.test(u)):[];return`<section class="rm-page" id="rm-09">
${G("RM. 09")}
<div class="rm-form-title">HASIL PEMERIKSAAN LABORATORIUM PATOLOGI KLINIK</div>
<div class="passthrough-separator"><span>LAMPIRAN HASIL LABORATORIUM (LIS)</span><span>FILE UPLOAD</span></div>
<div class="raw-upload-frame">
  ${t.length?t.join("<br/>"):"-"}
</div>
</section>`}function wa(i){let s=Z(i,/^Surat Kematian/i),a=(...t)=>tt(s,...t);return`<section class="rm-page" id="form-kematian">
${G("KEMATIAN")}
<div class="rm-form-title">SURAT KETERANGAN KEMATIAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir / Umur",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
    ${L("Alamat",Lt(i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Kematian",a(/^Tanggal Kematian|^Tanggal/i))}
    ${L("Jam Kematian",a(/^Jam/i))}
    ${L("Tempat Kematian",a(/^Tempat/i))}
    ${L("Ruang / Kelas",[e("jenis"),e("kelas","ruang")].filter(t=>t!=="-").join(" / ")||"-")}
  </table></div>
</div>
${q([["PENYEBAB KEMATIAN LANGSUNG (I)",a(/^Penyebab Langsung|^Penyebab I/i)],["PENYEBAB ANTARA (II)",a(/^Penyebab Antara|^Penyebab II/i)],["PENYAKIT / KONDISI LAIN",a(/^Penyakit Lain|^Kondisi Lain/i)],["KETERANGAN",a(/^Keterangan|^Catatan/i)]])}
${X(["Keluarga Pasien",`( ${M(e("nama"))} )`],["Kota Jambi, "+M(a(/^Tanggal Kematian|^Tanggal/i)),"Dokter yang Menyatakan Meninggal",`( ${M(e("dokter","dpjp"))} )`])}
</section>`}function Da(i){let s=Z(i,/^Permintaan Terapi/i),a=at(i,/^Permintaan Terapi/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-terapi">
${G("TERAPI")}
<div class="rm-form-title">PERMINTAAN TERAPI REHABILITASI MEDIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Permintaan",t(/^Tanggal/i))}
    ${L("Ruangan / Unit Asal",t(/^Ruang|^Unit/i))}
    ${L("Dokter Pengirim",t(/^Dokter Pengirim/i))}
    ${L("Diagnosa",t(/^Diagnosa/i))}
  </table></div>
</div>
${q([["JENIS TERAPI YANG DIMINTA",t(/^Jenis Terapi|^Terapi/i)],["TUJUAN TERAPI",t(/^Tujuan/i)],["FREKUENSI / RENCANA",t(/^Frekuensi|^Rencana/i)],["CATATAN KLINIS",t(/^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN PERMINTAAN</div>
${it(["NO","TERAPI / MODALITAS","FREKUENSI","KETERANGAN"],a,!0)}
${X(["Pasien / Keluarga Pasien",`( ${M(e("nama"))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Dokter Pengirim",`( ${M(t(/^Dokter Pengirim/i))} )`])}
</section>`}function ya(i){let s=Z(i,/^Uji Fungsi/i),a=at(i,/^Uji Fungsi/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-uji-fungsi">
${G("UJI FUNGSI")}
<div class="rm-form-title">LEMBAR UJI FUNGSI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Pemeriksaan",t(/^Tanggal/i))}
    ${L("Diagnosa",t(/^Diagnosa/i))}
    ${L("Petugas Uji",t(/^Petugas|^Terapis/i))}
    ${L("Alat / Metode",t(/^Alat|^Metode/i))}
  </table></div>
</div>
${it(["PARAMETER FUNGSI","NILAI / SKOR","SATUAN","KETERANGAN"],a,!0)}
${q([["HASIL / INTERPRETASI",t(/^Hasil|^Interpretasi/i)],["KESIMPULAN",t(/^Kesimpulan/i)],["REKOMENDASI TERAPI",t(/^Rekomendasi|^Saran/i)]])}
${X(["Pasien / Keluarga Pasien",`( ${M(e("nama"))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Petugas Uji Fungsi",`( ${M(t(/^Petugas|^Terapis/i))} )`])}
</section>`}function ma(i){let s=Z(i,/^Partograf/i),a=at(i,/^Partograf/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-partograf">
${G("PARTOGRAF")}
<div class="rm-form-title">PARTOGRAF \u2014 PEMANTAUAN KEMAJUAN PERSALINAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Umur",t(/^Umur/i))}
    ${L("Grafida / Paritas",t(/^Grafida|^Paritas|^G/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("HPHT",t(/^HPHT/i))}
    ${L("Taksiran Persalinan",t(/^Taksiran|^TP/i))}
    ${L("Tanggal Persalinan",t(/^Tanggal/i))}
    ${L("Petugas",t(/^Petugas|^Bidan/i))}
  </table></div>
</div>
<div class="sub-heading-rm">KEMAJUAN PERSALINAN &amp; OBSERVASI</div>
${it(["JAM","PEMBUKAAN","TURUN","KONTRAKSI","DJJ","TD / NADI","SUHU","URINE","CATATAN"],a,!0)}
${q([["KEADAAN IBU &amp; JANIN",t(/^Keadaan|^Kondisi/i)],["TINDAKAN / PENYIMPANGAN",t(/^Tindakan|^Penyimpangan/i)],["CATATAN",t(/^Catatan/i)]])}
${X(["Keluarga Pasien",`( ${M(e("nama"))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Bidan / Petugas Persalinan",`( ${M(t(/^Petugas|^Bidan/i))} )`])}
</section>`}function pa(i){let s=Z(i,/^Laporan Tindakan/i),a=at(i,/^Laporan Tindakan/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-laporan-tindakan">
${G("LAPORAN TINDAKAN")}
<div class="rm-form-title">LAPORAN PELAKSANAAN TINDAKAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Tindakan",t(/^Tanggal/i))}
    ${L("Jenis Tindakan",t(/^Jenis Tindakan|^Tindakan/i))}
    ${L("Ruang / Unit",t(/^Ruang|^Unit/i))}
    ${L("Pelaksana",t(/^Pelaksana|^Petugas|^Dokter/i))}
  </table></div>
</div>
${q([["INDIKASI / DIAGNOSA",t(/^Indikasi|^Diagnosa/i)],["URAIAN TINDAKAN",t(/^Uraian|^Prosedur/i)],["HASIL TINDAKAN",t(/^Hasil/i)],["KOMPLIKASI / CATATAN",t(/^Komplikasi|^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN TINDAKAN</div>
${it(["NO","TINDAKAN","WAKTU / JAM","PELAKSANA"],a,!0)}
${X(["Pasien / Keluarga Pasien",`( ${M(e("nama"))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Pelaksana Tindakan",`( ${M(t(/^Pelaksana|^Petugas|^Dokter/i))} )`])}
</section>`}var It=i=>i?Array.from(i.rows).map(s=>Array.from(s.cells).map(rt)):[],Tt=i=>[i.match(/(\d{1,2}\/\d{1,2}\/\d{4})/)?.[1]??"-",i.match(/Pukul\s*([\d:]+)/i)?.[1]??"-"],bt=i=>i.match(/dr\.[^\n]+/i)?.[0]?.trim()??"-";function xa(i){let s=Array.from(i.querySelectorAll("table")),a=s[0]??null,t=s.find(g=>/Jawaban Konsultasi/i.test(g.textContent||""))??null,u=It(a),n=It(t),r=u[0]??[],j=u[1]?.[0]||"",o=u.findIndex(g=>/^Penemuan Klinis/i.test(g[0]||"")),[x,h]=Tt(r[1]||""),[D,v]=Tt(n[1]?.[1]||""),I={};for(let g of n.slice(2))for(let C of g){let $=C.match(/^(Subjektif|Objektif|Assesmen|Planning|Instruksi)\s*:\s*([\s\S]*)$/i);$&&(I[$[1].toLowerCase()]=$[2].trim()||"-")}let y=(r[0]||"").replace(/^\s*Konsul Ke\s*:\s*/i,"").replace(/\s+/g," ").trim(),b=bt(n[n.length-1]?.[1]||"");return{konsulen:b!=="-"?b:y||"-",pengirim:bt(u[u.length-1]?.[1]||""),tanggal:x,jam:h,jenis:j.match(/Mohon\s+Konsultasi\s+([^\s:]+)/i)?.[1]??"-",permintaan:j||"-",penemuan:(o>=0?u[o+1]?.[0]:"")||"-",dugaan:u.flat().find(g=>/^Dugaan\s*:/i.test(g))?.replace(/^Dugaan\s*:\s*/i,"").trim()||"-",subjektif:I.subjektif||"-",objektif:I.objektif||"-",asesmen:I.asesmen||"-",planning:I.planning||"-",instruksi:I.instruksi||"-",keputusan:n.flat().find(g=>/Konsultasi selesai tanggal/i.test(g))||"-",tglJawaban:D,jamJawaban:v}}function Ea(i,s,a="rm-10"){let t=s??i.find(j=>/Konsul/i.test(j.title));if(!t)return"";let u=new DOMParser().parseFromString(t.html,"text/html"),n=Array.from(u.querySelectorAll("b")).filter(j=>/^\s*Konsul Ke\s*:/i.test(j.textContent||"")).map(j=>j.closest("table")?.parentElement).filter(j=>!!j),r=V([t],/Konsul/i);return n.map((j,o)=>Ia(xa(j),r[o]??"",o?`${a}-${o+1}`:a)).join("")}function Ia(i,s,a){let t=e("dokter","dpjp"),u=i.konsulen!=="-"?i.konsulen:e("dokter_konsulen")!=="-"?e("dokter_konsulen"):dt(s);return`<section class="rm-page" id="${M(a)}">
${G("RM. 10")}
<div class="rm-form-title">LEMBAR KONSULTASI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("No. Rekam Medis",e("norm","rekam_medis"),!0)}
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("Tanggal Lahir / Umur",e("tgl_lahir","tglLahir"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Jenis Kunjungan",[e("jenis"),e("kelas","ruang")].filter(n=>n!=="-").join(" / ")||"-")}
    ${L("Tanggal Permintaan",`${i.tanggal} ${i.jam}`.trim())}
    ${L("Tanggal Jawaban",`${i.tglJawaban} ${i.jamJawaban}`.trim())}
  </table></div>
</div>
${q([["BAGIAN I : KEPADA YTH. KONSULEN",u],["JENIS PERMOHONAN",i.jenis],["PERMINTAAN KONSULTASI",i.permintaan],["PENEMUAN KLINIS TERPENTING",i.penemuan],["DUGAAN DIAGNOSA",i.dugaan]])}
${q([["S (SUBJEKTIF)",i.subjektif],["O (OBJEKTIF)",i.objektif],["A (ASSESMEN)",i.asesmen],["P (PLANNING)",i.planning],["INSTRUKSI",i.instruksi],["KEPUTUSAN KONSULTASI",i.keputusan]])}
${X(["Dokter Pemohon Konsultasi",t!=="-"?`( ${M(t)} )`:`( ${M(i.pengirim)} )`],["Dokter Konsulen",s?`<img class="rm-sig-qr" src="${M(s)}" alt="QR dokter konsulen" width="80" height="80" />`:'<div class="rm-sig-space"></div>',`( ${M(u)} )`])}
</section>`}function Ta(i){let s=Z(i,/^Bon Makan/i),a=(...t)=>tt(s,...t);return`<section class="rm-page" id="form-bon-makan">
${G("BON MAKAN")}
<div class="rm-form-title">BON MAKAN PASIEN / PENDAMPING</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Ruang / Kelas",[e("jenis"),e("kelas","ruang")].filter(t=>t!=="-").join(" / ")||"-")}
    ${L("Tanggal",a(/^Tanggal/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Nama Pendamping",a(/^Pendamping|^Keluarga/i))}
    ${L("Jumlah Porsi",a(/^Jumlah|^Porsi/i))}
    ${L("Waktu",a(/^Waktu|^Jam/i))}
    ${L("Petugas",a(/^Petugas/i))}
  </table></div>
</div>
${it(["NO","NAMA","HUBUNGAN","JUMLAH","KETERANGAN"],at(i,/^Bon Makan/i),!0)}
<div class="footnote-rm">Bon ini berlaku sesuai jadwal makan yang ditetapkan ruangan / instalasi gizi.</div>
${X(["Pasien / Pendamping",`( ${M(a(/^Pendamping|^Keluarga/i))} )`],["Kota Jambi, "+M(a(/^Tanggal/i)),"Petugas Ruangan",`( ${M(a(/^Petugas/i))} )`])}
</section>`}function ba(i){let s=Z(i,/^PEMERIKSAAN$/i),a=at(i,/^PEMERIKSAAN$/i),t=(...u)=>tt(s,...u);return`<section class="rm-page" id="form-pemeriksaan">
${G("PEMERIKSAAN")}
<div class="rm-form-title">HASIL PEMERIKSAAN / DIAGNOSTIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${L("Nama Pasien",e("nama"),!0)}
    ${L("No. Rekam Medis",e("norm","rekam_medis"))}
    ${L("Tgl. Lahir",e("tgl_lahir","tglLahir"))}
    ${L("Jenis Kelamin",e("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${L("Tanggal Pemeriksaan",t(/^Tanggal/i))}
    ${L("Jenis Pemeriksaan",t(/^Jenis Pemeriksaan|^Pemeriksaan/i))}
    ${L("Spesimen / Bahan",t(/^Spesimen|^Bahan/i))}
    ${L("Dokter Pengirim",t(/^Dokter Pengirim/i))}
  </table></div>
</div>
${it(["PARAMETER","HASIL","SATUAN","NILAI RUJUKAN"],a,!0)}
${q([["MAKROSKOPIK / TEMUAN",t(/^Makroskopik|^Temuan/i)],["MIKROSKOPIK",t(/^Mikroskopik/i)],["KESIMPULAN / DIAGNOSA",t(/^Kesimpulan|^Diagnosa/i)],["CATATAN",t(/^Catatan/i)]])}
${X(["Petugas / Analis",`( ${M(t(/^Petugas|^Analis/i))} )`],["Kota Jambi, "+M(t(/^Tanggal/i)),"Dokter Penanggung Jawab",`( ${M(t(/^Dokter Penanggung Jawab|^Dokter/i))} )`])}
</section>`}function Ca(i,s){let a=Jt(i,s),t=e("no_sep","sep"),u=e("kartu","no_kartu","noka"),n=e("norm","rekam_medis"),r=e("nama"),j=[e("jenis"),e("kelas","ruang")].filter(N=>N!=="-").join(" / ")||"-",o=e("dokter","dpjp"),x=e("tanggalAwal","tgl_masuk","tgl"),h=e("tanggalAkhir","keluar","tgl_keluar"),D=e("tgl_lahir","tglLahir"),v=e("jenis_kelamin","jk"),I=Lt(i),y=i.filter(N=>/resep/i.test(N.title)).length,b=xt,g=new Date,C=`${g.getDate()} ${b[g.getMonth()]} ${g.getFullYear()}`,$=`<table class="rm-grid-table">
  <thead>
    <tr><th colspan="3">CATATAN KETIDAKSESUAIAN DATA LINTAS DOKUMEN (HASIL UJI SILANG OTOMATIS)</th></tr>
    <tr><th style="width: 32px;">NO</th><th style="width: 170px;">JENIS KETIDAKSESUAIAN</th><th>URAIAN TEMUAN VERIFIKASI</th></tr>
  </thead>
  <tbody>${a.map((N,O)=>`<tr><td class="center">${O+1}</td><td><strong>${M(N.title)}</strong></td><td>${M(N.detail)}</td></tr>`).join("")}</tbody>
</table>`,F=`<section class="rm-page" id="rm-00">
${G("RM. 00")}
<div class="rm-form-title">LEMBAR KENDALI KELENGKAPAN &amp; VERIFIKASI BERKAS KLAIM JKN</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NAMA PASIEN</td><td class="col">:</td><td class="val"><strong>${M(r)}</strong></td></tr>
    <tr><td class="lbl">NO. REKAM MEDIS</td><td class="col">:</td><td class="val"><strong>${M(n)}</strong></td></tr>
    <tr><td class="lbl">TGL. LAHIR / UMUR</td><td class="col">:</td><td class="val">${M(D)}</td></tr>
    <tr><td class="lbl">JENIS KELAMIN</td><td class="col">:</td><td class="val">${M(v)}</td></tr>
    <tr><td class="lbl">ALAMAT</td><td class="col">:</td><td class="val">${M(I)}</td></tr>
  </table></div>
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NO. KARTU BPJS</td><td class="col">:</td><td class="val"><strong>${M(u)}</strong></td></tr>
    <tr><td class="lbl">NO. SEP</td><td class="col">:</td><td class="val"><strong>${M(t)}</strong></td></tr>
    <tr><td class="lbl">TGL. MASUK / KELUAR</td><td class="col">:</td><td class="val">${M([x,h].filter(N=>N&&N!=="-").join(" s/d ")||"-")}</td></tr>
    <tr><td class="lbl">RUANG / KELAS</td><td class="col">:</td><td class="val">${M(j)}</td></tr>
    <tr><td class="lbl">DPJP UTAMA</td><td class="col">:</td><td class="val">${M(o)}</td></tr>
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 110px;">KODE INA-CBG</th>
      <th>DESKRIPSI GROUPING INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF RIIL RS</th>
      <th class="num" style="width: 115px;">SELISIH</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="center"><strong>${M(st("ina_cbg_code")||"-")}</strong></td>
      <td>${M(st("ina_cbg_desc")||"-")}</td>
      <td class="num"><strong>${M(st("tarif_ina_cbg")||"-")}</strong></td>
      <td class="num">${M(st("tarif_riil_rs")||"-")}</td>
      <td class="num">${M(st("selisih")||"-")}</td>
    </tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 32px;">NO</th>
      <th style="width: 58px;">KODE RM</th>
      <th>JENIS BERKAS / DOKUMEN KLAIM</th>
      <th style="width: 120px;">STATUS BERKAS</th>
      <th style="width: 68px;">TANDA (&#10003;)</th>
    </tr>
  </thead>
  <tbody>
    <tr><td class="center">1</td><td class="center">RM. 01</td><td>Surat Elegibilitas Peserta (SEP) \u2014 No. ${M(t)}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 01 SEP"></td></tr>
    <tr><td class="center">2</td><td class="center">RM. 01</td><td>Berkas Klaim Individual Pasien (INA-CBG E-Klaim 5.10.9)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi INA-CBG"></td></tr>
    <tr><td class="center">3</td><td class="center">RM. 02</td><td>Surat Bukti Pelayanan Kesehatan (SBPK) \u2014 ${M(j)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 02 SBPK"></td></tr>
    <tr><td class="center">4</td><td class="center">RM. 03</td><td>Surat Pengantar Rawat Inap (SPRI) \u2014 Tgl. ${M(x||"-")}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 03 SPRI"></td></tr>
    <tr><td class="center">5</td><td class="center">Seksi 04</td><td>File Upload Dokumen Pasien (Laporan Echo/Doppler &amp; Rekaman EKG)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Seksi 04 Upload"></td></tr>
    <tr><td class="center">6</td><td class="center">RM. 05</td><td>Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi (${y} Nota Resep)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 05 Billing"></td></tr>
    <tr><td class="center">7</td><td class="center">RM. 06</td><td>Ringkasan Pulang (Discharge Summary) \u2014 DPJP ${M(o)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 06 Resume"></td></tr>
    <tr><td class="center">8</td><td class="center">RM. 07</td><td>Formulir Telaah Resep, Telaah Obat &amp; Edukasi Farmasi (No. 230445)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 07 Telaah"></td></tr>
    <tr><td class="center">9</td><td class="center">RM. 08</td><td>Hasil Pemeriksaan Radiologi \u2014 Thorax AP/PA (No. Rontgen 5918)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 08 Radiologi"></td></tr>
    <tr><td class="center">10</td><td class="center">RM. 09</td><td>Hasil Pemeriksaan Laboratorium Patologi Klinik (Hematologi &amp; Urine)</td><td class="center"><strong>TIDAK LENGKAP *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 09 Lab"></td></tr>
    <tr><td class="center">11</td><td class="center">RM. 10</td><td>Lembar Konsultasi Antar-Spesialis (dr. M. Ryan Ramadhan, Sp.JP., FIHA)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 10 Konsul"></td></tr>
  </tbody>
</table>

${$}

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Kota Jambi, ${C}</div>
    <div>Petugas Casemix / Klaim JKN RS</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">RSUD H. Abdul Manap Kota Jambi</div>
  </div>
  <div class="rm-sig-box">
    <div>Diterima &amp; Diverifikasi Oleh,</div>
    <div>Verifikator BPJS Kesehatan</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">NPP. ............................................</div>
  </div>
</div>
</section>`,P=i,R=new Map,k=P.map((N,O)=>{let A=_t(N.title,O),d=(R.get(A.id)??0)+1;return R.set(A.id,d),d===1?A:{...A,id:`${A.id}-${d}`,tab:`${A.tab} (${d})`,option:`${A.option} (${d})`}}),U=P.map((N,O)=>{let A=k[O];return/^SEP$/i.test(N.title)?qt(i):/^Surat (?:Rencana )?Kontrol/i.test(N.title)?Zt(i):/^SPRI$/i.test(N.title)?Xt(i):/^SBPK$/i.test(N.title)?Vt(i):/^Rincian Biaya/i.test(N.title)?ta(i):/^Resume/i.test(N.title)?aa(i):/^Telaah/i.test(N.title)?ia(i):/^Radiologi/i.test(N.title)?La(i,N,A.id):/^Triage/i.test(N.title)?ra(i):/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(N.title)?na(i):/^Laboratorium/i.test(N.title)?ga(i):/Konsul/i.test(N.title)?Ea(i,N,A.id):/^Persetujuan Tindakan/i.test(N.title)?Sa(i):/^Anestesi/i.test(N.title)?da(i):/^Fisioterapi/i.test(N.title)?Aa(i):/^Pengkajian Hemodialisa/i.test(N.title)?Na(i):/^Operasi/i.test(N.title)?ca(i):/^Surat Kematian/i.test(N.title)?wa(i):/^Permintaan Terapi/i.test(N.title)?Da(i):/^Uji Fungsi/i.test(N.title)?ya(i):/^Partograf/i.test(N.title)?ma(i):/^Laporan Tindakan/i.test(N.title)?pa(i):/^Bon Makan/i.test(N.title)?Ta(i):/^PEMERIKSAAN$/i.test(N.title)?ba(i):`<section class="rm-page" id="${A.id}">
${G(A.code)}
<div class="rm-form-title">${M(N.title)}</div>
<div class="doc-body">${N.html}</div>
</section>`}).join(""),B=['<button type="button" class="tab-btn active" data-target="all">Semua</button>','<button type="button" class="tab-btn" data-target="rm-00">RM. 00 Kendali</button>',...P.map((N,O)=>{let A=k[O];return`<button type="button" class="tab-btn" data-target="${A.id}">${A.tab}</button>`})].join(""),f=['<option value="all">Semua Formulir RM</option>','<option value="rm-00">RM. 00 \u2014 Lembar Kendali &amp; Verifikasi</option>',...P.map((N,O)=>{let A=k[O];return`<option value="${A.id}">${A.option}</option>`})].join("");return`<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<base href="${M(location.origin)}">
<title>Formulir Rekam Medis Baku \u2014 Dossier Klaim BPJS ${M(jt)}</title>
<style>
    /* ==========================================================================
       1. RESET & AUTHENTIC INDONESIAN HOSPITAL RM FORM TOKENS
       Pure Monochrome Black Ink (#000000) on White Paper (#FFFFFF).
       Zero SaaS colors, zero rounded pills/badges, zero drop shadows.
       ========================================================================== */
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      line-height: 1.35;
      color: #000000;
      background-color: #E5E5E5;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    /* ==========================================================================
       2. SCREEN-ONLY VERIFIER TOOLBAR (.no-print)
       ========================================================================== */
    .verifier-toolbar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background-color: #FFFFFF;
      border-bottom: 2px solid #000000;
      padding: 8px 16px;
      font-family: Arial, Helvetica, sans-serif;
    }

    .toolbar-row {
      max-width: 210mm;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }

    .toolbar-group {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
    }

    .toolbar-label {
      font-size: 9pt;
      font-weight: bold;
      text-transform: uppercase;
    }

    .toolbar-select {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 8px;
      cursor: pointer;
    }

    .toolbar-counter {
      font-size: 8.5pt;
      border: 1px solid #000000;
      padding: 3px 8px;
      background-color: #FFFFFF;
    }

    .toolbar-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 10px;
      cursor: pointer;
    }

    .toolbar-btn:hover {
      background-color: #F0F0F0;
    }

    .toolbar-btn-print {
      background-color: #000000;
      color: #FFFFFF;
    }

    .toolbar-btn-print:hover {
      background-color: #222222;
    }

    .toolbar-tabs {
      max-width: 210mm;
      margin: 6px auto 0 auto;
      padding-top: 6px;
      border-top: 1px solid #000000;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .tab-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 7.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 2px 6px;
      cursor: pointer;
    }

    .tab-btn.active {
      background-color: #000000;
      color: #FFFFFF;
      font-weight: bold;
    }

    /* ==========================================================================
       3. A4 PAPER SHEET CONTAINER (NO DROP SHADOWS)
       ========================================================================== */
    .dossier-wrapper {
      max-width: 210mm;
      margin: 16px auto 40px auto;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .rm-page {
      width: 100%;
      background-color: #FFFFFF;
      border: 1px solid #888888;
      padding: 12mm 14mm;
    }

    .rm-page.hidden-section {
      display: none;
    }

    /* ==========================================================================
       4. OFFICIAL RSUD H. ABDUL MANAP KOP SURAT (TIMES NEW ROMAN + DOUBLE RULE)
       ========================================================================== */
    .rm-code-top {
      text-align: right;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 9pt;
      font-weight: bold;
      margin-bottom: 2px;
      letter-spacing: 0.02em;
    }

    .kop-surat {
      display: flex;
      align-items: center;
      gap: 12px;
      padding-bottom: 5px;
    }

    .kop-logo {
      width: 52px;
      height: 60px;
      flex-shrink: 0;
    }

    .kop-text {
      flex: 1;
      text-align: center;
      font-family: "Times New Roman", Times, serif;
      color: #000000;
      line-height: 1.2;
    }

    .kop-line-1 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-2 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-3 {
      font-size: 12.5pt;
      font-weight: bold;
      letter-spacing: 0.02em;
      margin-top: 1px;
    }

    .kop-line-4 {
      font-size: 7.5pt;
      font-weight: normal;
      margin-top: 2px;
    }

    .kop-line-5 {
      font-size: 7.5pt;
      font-weight: normal;
    }

    .kop-double-rule {
      border-top: 2px solid #000000;
      height: 2px;
      border-bottom: 0.75px solid #000000;
      margin-bottom: 10px;
    }

    .rm-form-title {
      text-align: center;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 11pt;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 8px;
      letter-spacing: 0.02em;
    }

    /* ==========================================================================
       5. PATIENT IDENTITY BLOCKS (PATTERN A: BORDERED BOX / PATTERN B: BORDERLESS)
       Strict vertical colon ':' alignment (label | 10px ':' | value)
       ========================================================================== */
    .id-box-bordered {
      border: 1px solid #000000;
      padding: 6px 10px;
      margin-bottom: 9px;
      display: flex;
      gap: 16px;
    }

    .id-box-borderless {
      padding: 2px 0;
      margin-bottom: 8px;
      display: flex;
      gap: 16px;
    }

    .id-col {
      flex: 1;
      min-width: 0;
    }

    .id-table {
      width: 100%;
      border-collapse: collapse;
    }

    .id-table td {
      padding: 1.5px 0;
      vertical-align: top;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
      line-height: 1.3;
    }

    .id-table td.lbl {
      width: 118px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.lbl-wide {
      width: 138px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.col {
      width: 10px;
      text-align: center;
    }

    .id-table td.val {
      text-align: left;
    }

    /* ==========================================================================
       6. FULL-GRID RM TABLES (border: 1px solid #000 ON ALL TH & TD)
       ========================================================================== */
    .rm-grid-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 8px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-grid-table th,
    .rm-grid-table td {
      border: 1px solid #000000;
      padding: 4px 6px;
      vertical-align: top;
      color: #000000;
    }

    .rm-grid-table th {
      font-size: 8.5pt;
      font-weight: bold;
      text-align: center;
      vertical-align: middle;
      background-color: #FFFFFF;
    }

    .rm-grid-table td.center,
    .rm-grid-table th.center {
      text-align: center;
      vertical-align: middle;
    }

    .rm-grid-table td.num,
    .rm-grid-table th.num {
      text-align: right;
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
    }

    .rm-grid-table td.nowrap {
      white-space: nowrap;
    }

    .rm-grid-table tr.section-banner td {
      font-weight: bold;
      font-size: 8.5pt;
      text-transform: uppercase;
      padding: 4px 6px;
    }

    .rm-grid-table tr.sub-group td {
      font-weight: bold;
      text-decoration: underline;
      padding-top: 5px;
      padding-bottom: 4px;
    }

    .rm-grid-table tr.total-row td {
      font-weight: bold;
      padding: 5px 6px;
    }

    /* Square 11px x 11px Interactive Verification Checkbox */
    .rm-checkbox {
      appearance: none;
      -webkit-appearance: none;
      width: 11px;
      height: 11px;
      border: 1px solid #000000;
      border-radius: 0;
      background-color: #FFFFFF;
      display: inline-grid;
      place-content: center;
      vertical-align: middle;
      cursor: pointer;
    }

    .rm-checkbox::before {
      content: "\u2713";
      font-size: 9px;
      font-weight: bold;
      line-height: 1;
      color: #000000;
      transform: scale(0);
    }

    .rm-checkbox:checked::before {
      transform: scale(1);
    }

    /* Static printed checkbox symbol for clinical forms */
    .static-box {
      display: inline-block;
      width: 10px;
      height: 10px;
      border: 1px solid #000000;
      text-align: center;
      line-height: 9px;
      font-size: 8px;
      font-weight: bold;
      margin-right: 4px;
      vertical-align: middle;
    }

    .sub-heading-rm {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 7px 0 4px 0;
    }

    .footnote-rm {
      font-size: 7.5pt;
      margin-top: 4px;
      line-height: 1.35;
    }

    /* ==========================================================================
       7. ATOMIC SIGNATURE FOOTER (break-inside: avoid)
       ========================================================================== */
    .rm-signature-block {
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 20px;
      break-inside: avoid;
      page-break-inside: avoid;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-sig-box {
      width: 44%;
      text-align: center;
    }

    .rm-sig-box.left-align {
      text-align: left;
    }

    .rm-sig-space {
      height: 44px;
    }

    .rm-sig-name {
      font-weight: bold;
    }

    .rm-sig-sub {
      font-size: 7.5pt;
    }

    /* ==========================================================================
       8. SECTION 04 \u2014 FILE UPLOAD ORIGINAL PASSTHROUGH (NOT REDESIGNED)
       ========================================================================== */
    .passthrough-separator {
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      padding: 4px 6px;
      margin-bottom: 10px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .raw-upload-frame {
      border: 1px solid #000000;
      padding: 8px 10px;
      margin-bottom: 12px;
      font-family: "Times New Roman", Times, serif;
      font-size: 8.5pt;
      break-inside: avoid;
    }

    .raw-upload-table {
      width: 100%;
      border-collapse: collapse;
      margin: 6px 0;
      font-size: 8pt;
    }

    .raw-upload-table th,
    .raw-upload-table td {
      border: 1px solid #000000;
      padding: 2px 4px;
    }

    /* ==========================================================================
       9. PRINT MEDIA RULES (@media print \u2014 A4 PORTRAIT, 12MM MARGIN)
       ========================================================================== */
    @media print {
      @page {
        size: A4 portrait;
        margin: 12mm;
      }

      body {
        background-color: #FFFFFF !important;
        margin: 0;
        padding: 0;
      }

      .no-print,
      .verifier-toolbar {
        display: none !important;
      }

      .dossier-wrapper {
        max-width: 100%;
        margin: 0;
        gap: 0;
      }

      .rm-page {
        border: none !important;
        padding: 0 !important;
        margin: 0 !important;
        break-after: page;
        page-break-after: always;
      }

      .rm-page:last-child {
        break-after: auto;
        page-break-after: auto;
      }

      .rm-page.hidden-section {
        display: none !important;
      }

      thead {
        display: table-header-group;
      }

      tr,
      .rm-signature-block,
      .id-box-bordered {
        break-inside: avoid;
        page-break-inside: avoid;
      }
    }

    @media (max-width: 720px) {
      .rm-page {
        padding: 12px;
      }
      .id-box-bordered,
      .id-box-borderless {
        flex-direction: column;
        gap: 4px;
      }
      .rm-signature-block {
        flex-direction: column;
        gap: 14px;
      }
      .rm-sig-box {
        width: 100%;
      }
    }

/* \u2500\u2500 Tambahan generator: komponen hasil scrape & fokus keyboard \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.kop-logo{object-fit:contain;object-position:center}
/* SEP BPJS \u2014 cetakan VClaim (sheet menggantikan kop RSUD) */
.rm-page.sep-page{padding:0}
.bpjs-sep-sheet{width:210mm;max-width:100%;margin:0 auto;padding:10mm 14mm;background:#fff;color:#000;font:9.5pt/1.38 Arial,Helvetica,sans-serif;box-sizing:border-box;break-inside:avoid;page-break-inside:avoid}
.sep-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;position:relative}
.sep-logo{flex:0 0 215px;width:215px;height:33px;object-fit:contain;object-position:left center}
.sep-title-wrap{flex:0 0 auto;text-align:right;padding-right:0}
.sep-title{font-size:10.5pt;font-weight:400;letter-spacing:.3px;text-transform:uppercase}
.sep-hospital{font-size:10.5pt;text-transform:uppercase}
.sep-columns{display:flex;justify-content:space-between;gap:18px}
.sep-col-left{flex:0 0 56%}
.sep-col-right{flex:0 0 42%;display:flex;flex-direction:column;justify-content:space-between}
.sep-kv-table{width:100%;border-collapse:collapse}
.sep-kv-table td{padding:1.8px 0;vertical-align:top;border:none}
.sep-kv-table td.lbl{width:102px;white-space:nowrap}
.sep-col-right .sep-kv-table td.lbl{width:92px}
.sep-kv-table td.sep{width:12px;text-align:center}
.sep-kv-table td.val{word-break:break-word}
.sep-no-value{font-size:9.5pt;letter-spacing:.2px}
.sep-inline-mr{margin-left:14px;white-space:nowrap}
.sep-multiline-list{margin:0;padding:0;list-style:none}
.sep-disclaimer{margin-top:10px;font-size:7.5pt;font-style:italic}
.sep-print-meta{font-size:9.5pt;font-style:normal}
/* Isi/body SEP seragam 9.5pt \u2014 kecuali disclaimer (7.5pt italic). */
.sep-signatures{display:flex;justify-content:flex-end;gap:16px;margin-top:18px}
.sep-sig-box{flex:0 0 44%;font-size:9.5pt;line-height:1.25;text-align:center}
.sep-sig-role{min-height:24px}
.sep-sig-name{margin-top:2px;font-weight:bold}
.sep-qr{display:block;margin:2px auto;width:100px;height:100px;object-fit:contain}
.rm-sig-qr{display:block;width:80px;height:80px;margin:0 auto 4px;object-fit:contain}
/* @page A4 portrait 12mm ditetapkan sekali di blok print utama \u2014 jangan
   ditimpa di sini supaya margin semua halaman dossier konsisten. */
@media print{body{background:#fff;padding:0}.bpjs-sep-sheet{width:100%;padding:0}}
@media screen{body{background:#e5e7eb;padding:20px}.bpjs-sep-sheet{box-shadow:0 1px 4px rgba(0,0,0,.15)}}
/* Telaah (RM.07) \u2014 grid 2 kolom ala telaahResepPrint.ts */
.t-main{display:grid;grid-template-columns:62% 38%;gap:8px;align-items:start}
.t-left,.t-right{display:flex;flex-direction:column;gap:5px;min-width:0}
.tm-card{padding:2px 0 4px;margin-bottom:4px;border-bottom:.5pt solid #333}
.tm-col{display:flex;flex-direction:column;gap:2px}
.tm-row{display:grid;grid-template-columns:30% 70%;column-gap:4px;align-items:start}
.tm-row.long{display:grid}
.tm-label{font-size:7.5pt;line-height:1.25;color:#333}
.tm-val{font-size:8pt;line-height:1.25;overflow-wrap:anywhere}
.t-meds{font-size:8pt;margin-bottom:6px}
.med{margin-bottom:3px;line-height:1.3}
.med-no{font-weight:400}
.med-name{font-weight:700}
.med-jml{font-weight:700;white-space:nowrap}
.t-lampiran th{font-size:7.5pt}
.rm-summary{margin:8px 0 10px;font-size:8.5pt}
.rm-sum-line{display:flex;align-items:baseline;gap:6px;padding:1px 0}
.rm-sum-line .rm-sum-dots{flex:1;border-bottom:1px dotted #000;transform:translateY(-3px)}
.rm-checkbox:focus-visible,.vbox:focus-visible,.toolbar-btn:focus-visible,.toolbar-select:focus-visible,.tab-btn:focus-visible{outline:2px solid #000000;outline-offset:2px}
.vbox{appearance:none;-webkit-appearance:none;width:11px;height:11px;margin:0;border:1px solid #000000;border-radius:0;background-color:#FFFFFF;display:inline-grid;place-content:center;vertical-align:middle;cursor:pointer}
.vbox::before{content:"\u2713";font-size:9px;font-weight:bold;line-height:1;color:#000000;transform:scale(0)}
.vbox:checked::before{transform:scale(1)}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 8px!important;font-size:8.2pt!important}
.doc-body th,.doc-body td{border:1px solid #000000!important;padding:3px 5px!important;vertical-align:top;color:#000000!important;overflow-wrap:anywhere}
.doc-body th{background-color:#FFFFFF!important;font-weight:bold;text-align:center}
.doc-body h1,.doc-body h2,.doc-body h3{font-size:9.5pt;margin:6px 0}
.doc-body p{margin:2px 0}
.doc-body label{min-width:100px;font-weight:600;color:#333333}
.doc-body .fv{font-weight:500}
.doc-body img{max-width:100%!important;height:auto!important}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important}
.doc-body .vcol{width:16px!important;text-align:center!important}
.telaah-layout{display:flex;gap:8px;align-items:stretch;margin:0 0 6px}
.telaah-layout table{flex:1;margin-bottom:0}
.img-wrap{display:inline-block;max-width:100%}
.img-tools{display:flex;gap:6px;justify-content:flex-end;margin:0 0 5px}
.img-tools button{font-family:inherit;font-size:10px;padding:3px 9px;border:1px solid #000000;background-color:#FFFFFF;cursor:pointer}
</style></head><body>
<style>
    /* IGD: gambar asal MORBIS (skala nyeri Wong Baker & gambar objektif)
       ikut tercetak, dirapikan sebagai figure + keterangan. */
    .rm-figure { margin: 0 0 8px; break-inside: avoid; text-align: center; }
    .rm-figure img { max-width: 100%; height: auto; border: 1px solid #000000; }
    .rm-figure figcaption { margin-top: 3px; font-size: 7pt; text-transform: uppercase; letter-spacing: 0.04em; }
    .rm-figure-row { display: flex; gap: 10px; align-items: flex-start; break-inside: avoid; }
    .rm-figure-row .rm-figure { flex: 0 0 46%; margin: 0; }
    .rm-figure-row .rm-grid-table { flex: 1; min-width: 0; }
    .rm-note { border: 1px solid #000000; padding: 6px 8px; margin-bottom: 8px; font-size: 8.2pt; line-height: 1.4; break-inside: avoid; }

    /* Bahasa visual RM baku: banner bagian bernomor, tabel full-grid, kotak
       centang statis \u2014 mengikuti prototipe referensi RM.02/IGD. */
    .rm-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-family: Arial, Helvetica, sans-serif; font-size: 8pt; line-height: 1.28; }
    .rm-table th, .rm-table td { border: 1px solid #000000; padding: 3px 5px; vertical-align: top; }
    .rm-table th { font-weight: bold; text-align: center; vertical-align: middle; }
    .rm-table tr.sec-hdr td { font-weight: bold; font-size: 8.5pt; text-transform: uppercase; padding: 4px 5px; letter-spacing: 0.01em; }
    .chk-box { display: inline-block; width: 9.5px; height: 9.5px; border: 1px solid #000000; text-align: center; line-height: 8.5px; font-size: 7.5pt; font-weight: bold; margin-right: 3px; vertical-align: middle; }
    .opt-item { display: inline-block; margin-right: 10px; white-space: nowrap; }
    .filter-note { font-size: 7.3pt; font-style: italic; }
    .two-col-grid { display: flex; gap: 6px; margin-bottom: 8px; align-items: stretch; }
    .two-col-grid > .col-half { flex: 1; min-width: 0; }
    .rm-top-meta { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px; font-size: 8.5pt; font-weight: bold; }
    .running-header-box { border: 1px solid #000000; padding: 4px 8px; margin-bottom: 6px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; font-size: 7.8pt; }

    /* Editorial clinical: nomor urut otomatis, kepala pasien, dan ringkasan
       data kritis \u2014 tetap tinta hitam di atas kertas A4. */
    #pengkajian-igd { counter-reset: igdsec; }
    #pengkajian-igd .sub-heading-rm {
      counter-increment: igdsec;
      position: relative;
      padding: 3px 0 3px 30px;
      border-bottom: 1px solid #000000;
    }
    #pengkajian-igd .sub-heading-rm::before {
      content: counter(igdsec, decimal-leading-zero);
      position: absolute;
      left: 0;
      top: 3px;
      font-size: 7pt;
      font-weight: normal;
      letter-spacing: 0.08em;
    }
    .igd-masthead { margin-bottom: 9px; }
    .igd-masthead-label { font-size: 7pt; letter-spacing: 0.14em; text-transform: uppercase; }
    .igd-masthead-name {
      font-size: 17pt;
      font-weight: bold;
      line-height: 1.15;
      margin: 2px 0 6px;
      letter-spacing: -0.02em;
    }
    .igd-summary {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1.4fr;
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      margin: 0 0 9px;
    }
    .igd-summary > div { padding: 5px 8px; border-left: 1px solid #000000; }
    .igd-summary > div:first-child { border-left: 0; padding-left: 0; }
    .igd-summary span { display: block; font-size: 6.5pt; letter-spacing: 0.1em; text-transform: uppercase; }
    .igd-summary b { display: block; font-size: 11pt; line-height: 1.25; margin-top: 2px; }
    .igd-band-value { font-size: 11pt !important; font-weight: bold; }
</style>
<header class="verifier-toolbar no-print"><div class="toolbar-row">
<div class="toolbar-group"><span class="toolbar-label">Formulir RM Klaim BPJS:</span><select id="rmSectionSelect" class="toolbar-select" aria-label="Pilih Formulir RM">${f}</select></div>
<div class="toolbar-group"><span class="toolbar-counter">Tanda Verifikator (&#10003;): <strong id="checkCounter">0 / 0</strong></span>
<button type="button" class="toolbar-btn" id="btnCheckAll">Centang Semua</button>
<button type="button" class="toolbar-btn" id="btnResetChecks">Reset</button>
<button type="button" class="toolbar-btn toolbar-btn-print" id="btnPrintPdf">Cetak / Simpan PDF (A4)</button></div>
</div><nav id="rmTabs" class="toolbar-tabs" aria-label="Navigasi Formulir RM">${B}</nav></header>
<main class="dossier-wrapper">${F}${U}</main>
</body></html>`}async function za(){let i=a=>{let t=getComputedStyle(a);return t.display!=="none"&&t.visibility!=="hidden"&&Number(t.opacity)>0},s=Date.now()+3e3;for(;Date.now()<s&&[".swal2-container",".swal-overlay--active",".sweet-alert"].flatMap(a=>Array.from(document.querySelectorAll(a))).some(i);)await new Promise(a=>window.setTimeout(a,150));await new Promise(a=>window.setTimeout(a,50))}function ka(i){let s=window.open("","_blank");if(!s)return!1;try{return s.document.open(),s.document.write(i),s.document.close(),Ot(s),!0}catch{return!1}}async function Ct(){let i=document.getElementById("ext-mklaim-print-btn"),s=i?.textContent||"Cetak Rapi M-KLAIM";i&&(i.disabled=!0,i.textContent="Memproses\u2026",i.style.opacity="0.7");try{await za();let{sections:a,inventory:t}=Dt();if(a.length<3&&(await new Promise(j=>window.setTimeout(j,800)),{sections:a,inventory:t}=Dt()),!a.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let u=Ca(a,t);if(ka(u))return;let n;for(let j of[0,300,600]){j&&await new Promise(o=>window.setTimeout(o,j));try{if(!(await chrome.runtime.sendMessage({type:"OPEN_PRINT_DOSSIER",html:u}))?.success)throw new Error("background menolak membuka tab");return}catch(o){n=o;let x=o instanceof Error?o.message:String(o);if(!/Receiving end does not exist|Extension context invalidated/i.test(x))break}}let r=n instanceof Error?n.message:String(n||"");chrome.runtime?.id?window.alert(`Gagal membuka dossier: ${r||"tidak diketahui"}. Refresh halaman M-KLAIM (Ctrl+Shift+R) lalu coba lagi.`):window.alert("Ekstensi diperbarui, refresh halaman M-KLAIM (Ctrl+Shift+R) lalu klik lagi Cetak Rapi.")}finally{i&&(i.disabled=!1,i.textContent=s,i.style.opacity="1")}}function ha(){let i=Array.from(document.querySelectorAll("button.btn-success")).find(s=>/^printDiv\s*\(/i.test(s.getAttribute("onclick")||""));return i?.parentElement?i.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(s=>s.querySelector("button"))||document.getElementById("SCETAK")||document.body}var Nt="v2";function zt(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor"))return;let i=document.getElementById("ext-mklaim-print-btn");if(i?.dataset.extBuild===Nt)return;i?.remove();let s=ha(),a=document.createElement("button");a.id="ext-mklaim-print-btn",a.dataset.extBuild=Nt,a.type="button",a.className="btn btn-primary btn-sm",a.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",a.textContent="Cetak Rapi M-KLAIM",a.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),Ct()}),s.appendChild(a)}window.extMklaimPrintNow=Ct,typeof gt.featureModules<"u"&&(gt.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let i=()=>zt();document.readyState==="complete"?window.setTimeout(i,500):window.addEventListener("load",()=>window.setTimeout(i,500));let s=()=>{let a=document.getElementById("ext-mklaim-print-btn");if(a?.dataset.extBuild!==Nt){zt();return}a.parentElement&&a.parentElement.lastElementChild!==a&&a.parentElement.appendChild(a)};new MutationObserver(()=>s()).observe(document.body,{childList:!0,subtree:!0}),window.setInterval(s,1500)}})})();
