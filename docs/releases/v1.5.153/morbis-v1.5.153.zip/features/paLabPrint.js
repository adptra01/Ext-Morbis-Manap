"use strict";var __morbis_feature=(()=>{var B="extensionConfig";function it(m,f,x){let h=f?.features?.[m];if(!h)return!0;if(h.enabled===!1)return!1;let w=x??f?.currentRole??"admin";if(w==="admin")return!0;let g=h.allowedRoles;return!Array.isArray(g)||g.length===0?!0:g.includes(w)}async function at(m){try{let f=(await chrome.storage.sync.get(B))?.[B]??null;return it(m,f)}catch{return!0}}function nt(m,f){at(m).then(x=>{if(x)try{f()}catch(h){console.error(`[featureGate:${m}] gagal jalan:`,h)}})}var M="ext-free-text-noop",rt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function ot(m){try{let f=m.toUpper;if(typeof f=="function"&&f[M]===!0)return!0;let x=function(h){return h?.value??""};x[M]=!0;try{Object.defineProperty(m,"toUpper",{value:x,writable:!0,configurable:!0})}catch{m.toUpper=x}return!0}catch{return!1}}nt("paLabPrint",function(){"use strict";function m(){try{ot(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let w=document.createElement("style");w.id="ext-free-text-style",w.textContent=rt,document.head.appendChild(w)}}catch{}}m(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",m),window.setInterval(m,3e3);async function f(){let w="ext-pa-print-proc";if(document.documentElement.getAttribute(w))return;document.documentElement.setAttribute(w,"1");let g=t=>E(t?.textContent||"");function O(t){return t.replace(/<[^>]+>/g," ")}function lt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function E(t){return lt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function o(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let N=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",S=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>g(t)).filter(Boolean);for(;S.length<3;)S.push("");let j=[],_=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(_){let t=document.createElement("div");t.innerHTML=_.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),j=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let L=j.join(" "),F=t=>{let e=L.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},K=F("telp"),$=F("fax"),R=(L.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],T=(L.match(/https?:\/\/[^\s;,]+/)||[""])[0],y=L.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");R&&(y=y.split(R).join("")),T&&(y=y.split(T).join("")),y=y.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let st=["Alamat: "+y,K?"Telp: "+K:"",$?"Fax: "+$:""].filter(Boolean).join(", "),pt=[R?"Email: "+R:"",T?"Website: "+T:""].filter(Boolean).join(", ");j=[st,pt].filter(Boolean);let U=g(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",z=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let a=g(e[0]),l=g(e[2]),s=g(e[3]),r=g(e[5]);a&&z.push([a,l]),s&&z.push([s,r])}});let v=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],b=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),k=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",a=!1,l=t.querySelector(".section-title");if(l)e=g(l),a=!0;else{let n=d=>d.split(":")[0].trim();for(let d of Array.from(t.children).slice(0,3)){let u=g(d);if(u&&u.length<=24&&v.includes(b(n(u)))){e=n(u);break}}if(!e){let d=(t.textContent||"").split(`
`).map(u=>u.trim()).find(Boolean)||"";d&&v.includes(b(n(d)))&&(e=n(d))}if(!e)return}let s=document.createElement("div");s.innerHTML=t.innerHTML,s.querySelector(".section-title")?.remove();let r=s.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(n=>n.split(/<br\s*\/?>|\n/).map(d=>E(d.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(n=>n.length),c=[],i=[];r.forEach((n,d)=>{n.forEach((u,D)=>{d>0&&D===0&&c.length&&i.push(c.length),c.push(u)})});let p=c;if(!a&&p.length&&b(p[0])===b(e)){p.shift();for(let n=0;n<i.length;n++)i[n]-=1;for(;i.length&&i[0]<=0;)i.shift()}p.length>1&&!/^[IVXLC]+\.\s/.test(p[0])&&p.slice(1).some(n=>/^II\.\s/.test(n))&&(p[0]="I. "+p[0]),e&&k.push({title:e,items:p,para:i})});let ct=/^catatan\s*:?/i,dt=/^icd[\s-]*o\b\s*:?/i,H=[];for(let t of k){let e=[{title:t.title,items:[],para:[]}],a=e[0],l=!1,s=(r,c)=>{a={title:r,items:[],para:[],bare:c},e.push(a),l=!0};if(t.items.forEach((r,c)=>{let i=r.match(ct),p=i?null:r.match(dt);if(i){b(a.title)!=="catatan"&&s("Catatan");let n=r.slice(i[0].length).trim();n&&(t.para.includes(c)&&a.para.push(a.items.length),a.items.push(n));return}if(p){b(a.title)!=="icdo"&&s("ICD-0",!0),t.para.includes(c)&&a.para.push(a.items.length),a.items.push(r);return}t.para.includes(c)&&a.para.push(a.items.length),a.items.push(r)}),l)for(let r of e)r.items.length&&H.push(r);else H.push(e[0])}k.length=0,k.push(...H),k.forEach((t,e)=>t._i=e),k.sort((t,e)=>{let a=t._i??0,l=e._i??0,s=v.indexOf(b(t.title)),r=v.indexOf(b(e.title)),c=s===-1?v.length:s,i=r===-1?v.length:r;return c!==i?c-i:a-l});function ut(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let a=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),l=t.getAttribute("placeholder")||"",s=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(a+" "+l+" "+s).slice(0,300)}}function mt(t,e,a){let l=e.toLowerCase().split(/[^a-z0-9]+/).filter(i=>i.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(i));if(!l.length)return"";let s=l.sort((i,p)=>p.length-i.length)[0],r="",c=-1;return t.querySelectorAll("input, textarea, select").forEach(i=>{let{val:p,ctx:n}=ut(i);if(!p||p===e||!p.toLowerCase().includes(s))return;let d=a.test(n)?2:0;d>c&&(c=d,r=p)}),r}function gt(t,e){return(t.querySelector(e)?.value||"").trim()}async function ft(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let a=i=>/ket\w*\s*klinis/i.test(i),l=i=>/^dokter/i.test(i)||/^rs\b/i.test(i),s=t.map(([i,p],n)=>({label:i,value:p,idx:n})).filter(i=>l(i.label)?!!i.value:a(i.label));if(!s.length)return;let r=new AbortController,c=window.setTimeout(()=>r.abort(),6e3);try{let i=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),p=await fetch(i.toString(),{credentials:"same-origin",signal:r.signal});if(!p.ok){window.console.info("[paPrint] override: fetch input status "+p.status);return}let n=await p.text(),d=new DOMParser().parseFromString(n,"text/html");window.console.info('[paPrint] override: input title="'+(d.title||"").slice(0,60)+'" len='+n.length+" fields="+d.querySelectorAll("input, textarea, select").length);for(let u of s){if(a(u.label)){let At=gt(d,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),q=E(O(At));window.console.info("[paPrint] override: "+u.label+' cetak="'+u.value+'" input="'+q+'"'),q&&q!==u.value&&(t[u.idx][1]=q);continue}let D=/^dokter/i.test(u.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,vt=mt(d,u.value,D),I=E(O(vt||""));window.console.info("[paPrint] override: "+u.label+' cetak="'+u.value+'" input="'+I+'"'),I&&I!==u.value&&(t[u.idx][1]=I)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(c)}}await ft(z).catch(()=>{});let A=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>g(t)).filter(Boolean),W=A[0]||"",Q=A[1]||"",P=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",G=A.find(t=>/^\(.*\)$/.test(t))||A[2]||"",J=A.find(t=>/^nip\.?/i.test(t))||A[3]||"",V=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",ht=Array.from(document.body.querySelectorAll("script")),bt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),C=z.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let a=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,l=a.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||a,s=l.split(/\s+-\s*/);if(s.length>=3&&/rawat\s+inap/i.test(s[1])){let r=bt(s[1].trim()),c=s.slice(2).join(" - ").trim(),i=c?r+" - "+c:r;if(i)return[t,i]}return[t,l]}),xt=C.map(([t,e])=>'<div class="info-item"><div class="info-label">'+o(t)+'</div><div class="info-colon">:</div><div class="info-value">'+o(e)+"</div></div>").join(""),X=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+o(t)+"</strong>":o(t),Y=t=>/^catatan/i.test(t.trim()),Z=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),wt=C.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function tt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(a=>{if(!a.ok)throw new Error("img "+a.status);return a.blob()}).then(a=>new Promise((l,s)=>{let r=new FileReader;r.onload=()=>l(String(r.result)),r.onerror=()=>s(r.error),r.readAsDataURL(a)})).catch(()=>e)}async function kt(){let[t,e]=await Promise.all([tt(N),P?tt(P):Promise.resolve("")]),a="";for(let i=0;i<C.length;i+=2){let p=C[i],n=C[i+1];a+="<tr><td>"+o(p[0])+"</td><td>:</td><td>"+o(p[1])+"</td>"+(n?"<td>"+o(n[0])+"</td><td>:</td><td>"+o(n[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let l="";for(let i of k){if(Y(i.title)){let n=i.items.length?i.items:["Tidak ada"];l+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top"><b><u>CATATAN:</u></b></td><td>'+n.map(d=>"- "+o(Z(d)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(i.bare){i.items.forEach((n,d)=>{l+='<p style="margin:'+(d===0?"12pt":"0")+' 0 6pt 0;font-size:11pt;"><b>'+o(n.toUpperCase())+"</b></p>"});continue}l+='<p style="margin:12pt 0 0 0;font-size:11pt;"><b><u>'+o(i.title.toUpperCase())+"</u></b></p>";let p=b(i.title)==="kesimpulan";i.items.forEach((n,d)=>{let u=p?"<b>"+o(n)+"</b>":X(n);l+='<p style="margin:'+(i.para.includes(d)?"14pt":"0")+' 0 6pt 0;text-align:justify;">'+u+"</p>"})}let s='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+o(U)+'</title></head><body style="font-family:Arial,sans-serif;font-size:11pt;"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+t+'" width="90"></td><td align="center">'+S.slice(0,3).map(i=>'<b style="font-size:16pt;">'+o(i)+"</b>").join("<br>")+'<br><span style="font-size:9pt;">'+j.map(i=>o(i)).join("<br>")+'</span></td></tr></table><hr><p align="center"><b><u>'+o(U.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2">'+a+"</table>"+l+'<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+o(W)+'</p><p style="margin:0 0 6pt 0;">'+o(Q)+"</p>"+(e?'<p style="margin:0 0 6pt 0;"><img src="'+e+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+o(G)+'</b></p><p style="margin:0 0 6pt 0;">'+o(J)+"</p></td></tr></table></body></html>",r=new Blob(["\uFEFF"+s],{type:"application/msword"}),c=document.createElement("a");c.href=URL.createObjectURL(r),c.download="Hasil-PA-"+wt+".doc",document.body.appendChild(c),c.click(),window.setTimeout(()=>{URL.revokeObjectURL(c.href),c.remove()},4e3)}let yt=k.map(t=>{if(Y(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(l=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+o(Z(l)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=b(t.title)==="kesimpulan",a='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+'">'+t.items.map((l,s)=>'<div class="item-list'+(t.para.includes(s)?" item-para":"")+'">'+(e?"<strong>"+o(l)+"</strong>":X(l))+"</div>").join("")+"</div>";return t.bare?a:'<div class="section-judul">'+o(t.title)+"</div>"+a}).join("");document.body.innerHTML='<a href="'+o(V)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+o(N)+'" alt="Logo"></div><div class="kop-text">'+S.slice(0,3).map(t=>'<h1 class="kop-atas">'+o(t)+"</h1>").join("")+'<div class="kop-alamat">'+j.map(t=>o(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+o(U)+'</div><div class="patient-info-container">'+xt+'</div><div class="hasil-pa">'+yt+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+o(W)+"</p><p>"+o(Q)+"</p>"+(P?'<img src="'+o(P)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+o(G)+'</p><p style="margin-top: 2px;">'+o(J)+"</p></div></div></div>",ht.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),kt().catch(()=>{window.location.href=V})}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let et="ext-pa-print-style";if(!document.getElementById(et)){let t=document.createElement("style");t.id=et,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: 16pt;
            margin: 0;
            line-height: 1.2;
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: 7.5pt;
            margin-top: 5px;
            color: #334155;
            line-height: 1.3;
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: 12pt;
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: 4pt;
            line-height: 1;
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: 6pt;
        }

        .section-isi {
            font-size: 5pt;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: 6pt;
            font-weight: bold;
            line-height: 1.2;
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: 5pt;
            line-height: 1.25;
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: 6pt;
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Cetak 14px khusus fitur PA (ramah lansia, ikut turun 2 tingkat
           mengikuti permintaan): blok ini SENGAJA
           paling akhir \u2014 rule dasar di atasnya berspesifisitas
           sama sehingga hanya menang bila muncul belakangan. HANYA
           @media print: tampilan layar tidak berubah, fitur lain tak
           tersentuh (<style> ini hanya ada di halaman cetak PA). */
        @media print {
            .section-isi,
            .section-isi-bare,
            .section-catatan {
                font-size: 11px;
            }

            .patient-info-container {
                font-size: 10px;
            }

            .ttd-box {
                font-size: 10px;
            }

            .section-judul,
            .catatan-label {
                font-size: 8pt;
            }
        }
      `,document.head.appendChild(t)}}let x=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),f().catch(()=>{})):Date.now()-x>5e3&&window.clearInterval(h)},200)})})();
