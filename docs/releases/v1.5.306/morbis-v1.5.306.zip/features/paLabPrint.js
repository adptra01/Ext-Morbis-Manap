"use strict";var __morbis_feature=(()=>{var it="extensionConfig";function nt(r,a,f){if(a?.extensionEnabled===!1)return!1;let g=a?.features?.[r];if(!g)return!0;if(g.enabled===!1)return!1;let y=f??a?.currentRole??"admin";if(y==="admin")return!0;let E=g.allowedRoles;return!Array.isArray(E)||E.length===0?!0:E.includes(y)}async function Lt(r){try{let a=await chrome.runtime.sendMessage({type:"GET_CONFIG"});if(a?.config)return nt(r,a.config)}catch{}try{let a=(await chrome.storage.local.get(it))?.[it]??null;return nt(r,a)}catch{return!0}}function zt(r,a){Lt(r).then(f=>{if(f)try{a()}catch(g){console.error(`[featureGate:${r}] gagal jalan:`,g)}}).catch(f=>console.error(`[featureGate:${r}] gagal baca config:`,f))}var rt="ext-free-text-noop",qt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function Rt(r){try{let a=r.toUpper;if(typeof a=="function"&&a[rt]===!0)return!0;let f=function(g){return g?.value??""};f[rt]=!0;try{Object.defineProperty(r,"toUpper",{value:f,writable:!0,configurable:!0})}catch{r.toUpper=f}return!0}catch{return!1}}var J="ext-pa-typo",Tt=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi (termasuk ICD-O, Saran & Catatan)"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],A={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},icdo:{fs:6,lh:1.2},catatan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},ot=4,lt=24,Mt=.5,Ft=2.5;function st(r,a,f,g){let y=typeof r=="number"?r:Number(r);return Number.isFinite(y)?Math.min(g,Math.max(f,y)):a}function S(r,a){let f=r??{};return{fs:st(f.fs,a.fs,ot,lt),lh:st(f.lh,a.lh,Mt,Ft)}}function $(r){let a=r??{};return{kop:S(a.kop,A.kop),pasien:S(a.pasien,A.pasien),judul:S(a.judul,A.judul),isi:S(a.isi,A.isi),kesimpulan:S(a.kesimpulan,A.kesimpulan),icdo:S(a.icdo,A.icdo),catatan:S(a.catatan,A.catatan),ttd:S(a.ttd,A.ttd)}}function W(){return $(null)}function pt(r){try{if(!r)return W();let a=r.getItem(J);return a?$(JSON.parse(a)):W()}catch{return W()}}function Bt(r,a){try{return r?(r.setItem(J,JSON.stringify($(a))),!0):!1}catch{return!1}}function Pt(r){try{r?.removeItem(J)}catch{}}function dt(r){let a=$(r),f=g=>Math.min(lt,Math.max(ot,g));return{...a,alamatFs:f(a.kop.fs-8.5),judulLapFs:f(a.kop.fs-4)}}var b=r=>String(Math.round(r*100)/100);function Dt(r){let a=dt(r);return{"--pa-kop-fs":`${b(a.kop.fs)}pt`,"--pa-kop-lh":b(a.kop.lh),"--pa-alamat-fs":`${b(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(a.judulLapFs)}pt`,"--pa-pasien-fs":`${b(a.pasien.fs)}pt`,"--pa-pasien-lh":b(a.pasien.lh),"--pa-judul-fs":`${b(a.judul.fs)}pt`,"--pa-judul-lh":b(a.judul.lh),"--pa-isi-fs":`${b(a.isi.fs)}pt`,"--pa-isi-lh":b(a.isi.lh),"--pa-kesimpulan-fs":`${b(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(a.kesimpulan.lh),"--pa-icdo-fs":`${b(a.icdo.fs)}pt`,"--pa-icdo-lh":b(a.icdo.lh),"--pa-catatan-fs":`${b(a.catatan.fs)}pt`,"--pa-catatan-lh":b(a.catatan.lh),"--pa-ttd-fs":`${b(a.ttd.fs)}pt`,"--pa-ttd-lh":b(a.ttd.lh)}}function $t(r,a){if(r)try{for(let[f,g]of Object.entries(Dt(a)))r.setProperty(f,g)}catch{}}var Ht="[IVXLC]+(?:\\s*(?:dan|&|,|/|-)\\s*[IVXLC]+)*",Ut=new RegExp("^(\\(?"+Ht+"[.)]|\\d+[.)]|[-\u2022\u2013\u2014*])\\s*");function M(r){let a=(r??"").replace(/^\s+/,""),f=a.match(Ut);if(!f)return null;let g=a.slice(f[0].length).trim();return g===""?null:[f[1],g]}var Nt={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" ",plusmn:"\xB1",pm:"\xB1",equals:"=",ge:"\u2265",geq:"\u2265",le:"\u2264",leq:"\u2264",ne:"\u2260",neq:"\u2260",times:"\xD7",divide:"\xF7",deg:"\xB0",micro:"\xB5",hellip:"\u2026",ndash:"\u2013",mdash:"\u2014",bull:"\u2022",middot:"\xB7",ldquo:"\u201C",rdquo:"\u201D",lsquo:"\u2018",rsquo:"\u2019",laquo:"\xAB",raquo:"\xBB",trade:"\u2122",reg:"\xAE",copy:"\xA9"},Ot=/&(#x[0-9a-f]+|#\d+|[a-z][a-z0-9]*);/gi;function Gt(r){if(!Number.isFinite(r)||r<32||r>1114111)return" ";try{return String.fromCodePoint(r)}catch{return" "}}function ut(r){return String(r??"").replace(Ot,(a,f)=>{if(f[0]==="#"){let g=/^#x([0-9a-f]+)$/i.exec(f);return Gt(g?parseInt(g[1],16):parseInt(f.slice(1),10))}return Nt[f.toLowerCase()]??a})}zt("paLabPrint",function(){"use strict";function r(){try{Rt(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let y=document.createElement("style");y.id="ext-free-text-style",y.textContent=qt,document.head.appendChild(y)}}catch{}}if(r(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",r),window.setInterval(r,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let y="ext-pa-print-proc";if(document.documentElement.getAttribute(y))return;document.documentElement.setAttribute(y,"1");let E=()=>{try{return window.localStorage??null}catch{return null}},C=pt(E()),Q=()=>{try{$t(document.documentElement.style,C)}catch{}};Q();let w=t=>H(t?.textContent||"");function ct(t){return t.replace(/<[^>]+>/g," ")}function Kt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function H(t){let e=Kt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ");return ut(ut(e)).replace(/\s+/g," ").trim()}function u(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let mt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",U=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>w(t)).filter(Boolean);for(;U.length<3;)U.push("");let F=[],ft=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(ft){let t=document.createElement("div");t.innerHTML=ft.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),F=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let N=F.join(" "),ht=t=>{let e=N.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},gt=ht("telp"),bt=ht("fax"),O=(N.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],G=(N.match(/https?:\/\/[^\s;,]+/)||[""])[0],L=N.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");O&&(L=L.split(O).join("")),G&&(L=L.split(G).join("")),L=L.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let _t=["Alamat: "+L,gt?"Telp: "+gt:"",bt?"Fax: "+bt:""].filter(Boolean).join(", "),Vt=[O?"Email: "+O:"",G?"Website: "+G:""].filter(Boolean).join(", ");F=[_t,Vt].filter(Boolean);let X=w(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",K=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let o=w(e[0]),s=w(e[2]),d=w(e[3]),p=w(e[5]);o&&K.push([o,s]),d&&K.push([d,p])}});let z=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],x=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),I=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",o=!1,s=t.querySelector(".section-title");if(s)e=w(s),o=!0;else{let l=c=>c.split(":")[0].trim();for(let c of Array.from(t.children).slice(0,3)){let h=w(c);if(h&&h.length<=24&&z.includes(x(l(h)))){e=l(h);break}}if(!e){let c=(t.textContent||"").split(`
`).map(h=>h.trim()).find(Boolean)||"";c&&z.includes(x(l(c)))&&(e=l(c))}if(!e)return}let d=document.createElement("div");d.innerHTML=t.innerHTML,d.querySelector(".section-title")?.remove();let p=d.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(l=>l.split(/<br\s*\/?>|\n/).map(c=>H(c.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(l=>l.length),m=[],n=[];p.forEach((l,c)=>{l.forEach((h,k)=>{c>0&&k===0&&m.length&&n.push(m.length),m.push(h)})});let i=m;if(!o&&i.length&&x(i[0])===x(e)){i.shift();for(let l=0;l<n.length;l++)n[l]-=1;for(;n.length&&n[0]<=0;)n.shift()}i.length>1&&!/^[IVXLC]+\.\s/.test(i[0])&&!/:\s*$/.test(i[0])&&i.slice(1).some(l=>/^II\.\s/.test(l))&&(i[0]="I. "+i[0]),e&&I.push({title:e,items:i,para:n})});let Jt=/^catatan\s*:?/i,Wt=/^icd[\s-]*o\b\s*:?/i,Z=[];for(let t of I){let e=[{title:t.title,items:[],para:[]}],o=e[0],s=!1,d=(p,m)=>{o={title:p,items:[],para:[],bare:m},e.push(o),s=!0};if(t.items.forEach((p,m)=>{let n=p.match(Jt),i=n?null:p.match(Wt);if(n){x(o.title)!=="catatan"&&d("Catatan");let l=p.slice(n[0].length).trim();l&&(t.para.includes(m)&&o.para.push(o.items.length),o.items.push(l));return}if(i){x(o.title)!=="icdo"&&d("ICD-0",!0),t.para.includes(m)&&o.para.push(o.items.length),o.items.push(p);return}t.para.includes(m)&&o.para.push(o.items.length),o.items.push(p)}),s)for(let p of e)p.items.length&&Z.push(p);else Z.push(e[0])}I.length=0,I.push(...Z),I.forEach((t,e)=>t._i=e),I.sort((t,e)=>{let o=t._i??0,s=e._i??0,d=z.indexOf(x(t.title)),p=z.indexOf(x(e.title)),m=d===-1?z.length:d,n=p===-1?z.length:p;return m!==n?m-n:o-s});function Qt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let o=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),s=t.getAttribute("placeholder")||"",d=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(o+" "+s+" "+d).slice(0,300)}}function Xt(t,e,o){let s=e.toLowerCase().split(/[^a-z0-9]+/).filter(n=>n.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(n));if(!s.length)return"";let d=s.sort((n,i)=>i.length-n.length)[0],p="",m=-1;return t.querySelectorAll("input, textarea, select").forEach(n=>{let{val:i,ctx:l}=Qt(n);if(!i||i===e||!i.toLowerCase().includes(d))return;let c=o.test(l)?2:0;c>m&&(m=c,p=i)}),p}function Zt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Yt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let o=n=>/ket\w*\s*klinis/i.test(n),s=n=>/^dokter/i.test(n)||/^rs\b/i.test(n),d=t.map(([n,i],l)=>({label:n,value:i,idx:l})).filter(n=>s(n.label)?!!n.value:o(n.label));if(!d.length)return;let p=new AbortController,m=window.setTimeout(()=>p.abort(),6e3);try{let n=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),i=await fetch(n.toString(),{credentials:"same-origin",signal:p.signal});if(!i.ok){window.console.info("[paPrint] override: fetch input status "+i.status);return}let l=await i.text(),c=new DOMParser().parseFromString(l,"text/html");window.console.info('[paPrint] override: input title="'+(c.title||"").slice(0,60)+'" len='+l.length+" fields="+c.querySelectorAll("input, textarea, select").length);for(let h of d){if(o(h.label)){let at=Zt(c,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),R=H(ct(at));window.console.info("[paPrint] override: "+h.label+' cetak="'+h.value+'" input="'+R+'"'),R&&R!==h.value&&(t[h.idx][1]=R);continue}let k=/^dokter/i.test(h.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,P=Xt(c,h.value,k),j=H(ct(P||""));window.console.info("[paPrint] override: "+h.label+' cetak="'+h.value+'" input="'+j+'"'),j&&j!==h.value&&(t[h.idx][1]=j)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(m)}}await Yt(K).catch(()=>{});let q=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>w(t)).filter(Boolean),xt=q[0]||"",kt=q[1]||"",_=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",yt=q.find(t=>/^\(.*\)$/.test(t))||q[2]||"",vt=q.find(t=>/^nip\.?/i.test(t))||q[3]||"",wt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",te=Array.from(document.body.querySelectorAll("script")),ee=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),B=K.map(([t,e])=>{if(/^(cara|care)\s+peroleh(an)?$/i.test(t.trim()))return["Cara Perolehan",e];if(!/^ruang/i.test(t))return[t,e];let o=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,s=o.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||o,d=s.split(/\s+-\s*/);if(d.length>=3&&/rawat\s+inap/i.test(d[1])){let p=ee(d[1].trim()),m=d.slice(2).join(" - ").trim(),n=m?p+" - "+m:p;if(n)return[t,n]}return[t,s]}),ae=B.map(([t,e])=>'<div class="info-item"><div class="info-label">'+u(t)+'</div><div class="info-colon">:</div><div class="info-value">'+u(e)+"</div></div>").join(""),Y=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+u(t)+"</strong>":u(t),ie=t=>/^catatan/i.test(t.trim()),tt=t=>/^saran/i.test(t.trim()),jt=t=>ie(t)||tt(t),ne=t=>tt(t)?"Saran:":"Catatan:",et=t=>t.replace(/^(catatan|saran)\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),re=B.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function At(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(o=>{if(!o.ok)throw new Error("img "+o.status);return o.blob()}).then(o=>new Promise((s,d)=>{let p=new FileReader;p.onload=()=>s(String(p.result)),p.onerror=()=>d(p.error),p.readAsDataURL(o)})).catch(()=>e)}async function oe(){let t=dt(C),[e,o]=await Promise.all([At(mt),_?At(_):Promise.resolve("")]),s="";for(let i=0;i<B.length;i+=2){let l=B[i],c=B[i+1];s+="<tr><td>"+u(l[0])+"</td><td>:</td><td>"+u(l[1])+"</td>"+(c?"<td>"+u(c[0])+"</td><td>:</td><td>"+u(c[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let d="";for(let i of I){if(jt(i.title)){let v=i.items.length?i.items:["Tidak ada"],D=v.length>1,T=tt(i.title)?"SARAN:":"CATATAN:";d+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+T+'</b></td><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';">'+v.map(V=>(D?"- ":"")+"<b>"+u(et(V)||"Tidak ada")+"</b>").join("<br>")+"</td></tr></table>";continue}if(i.bare){i.items.forEach((v,D)=>{d+='<p style="margin:'+(D===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+u(v.toUpperCase())+"</b></p>"});continue}let l=["makroskopik","mikroskopik","kesimpulan"].includes(x(i.title)),c=x(i.title)==="icdo";d+='<p style="margin:12pt 0 0 0;font-size:'+(c?t.isi.fs:t.judul.fs)+'pt;"><b>'+(l?"<u>":"")+u(i.title.toUpperCase())+(l?"</u>":"")+"</b></p>";let h=x(i.title)==="kesimpulan",k=x(i.title)==="icdo",P=h||k||x(i.title)==="saran",j=h?t.kesimpulan.fs:t.isi.fs,at=h?t.kesimpulan.lh:t.isi.lh,R=Math.max(0,...i.items.map(v=>M(v)?.[0].length??0)),Ct=Math.max(18,Math.round(R*j*.62)+4);i.items.forEach((v,D)=>{let T=M(v),V=i.items.length===1&&T!==null&&/^[-•–—*]$/.test(T[0]),It=V?et(v)||T[1]:v,se=P?"<b>"+u(It)+"</b>":Y(It),pe=T&&!V?"margin-left:"+Ct+"pt;text-indent:-"+Ct+"pt;":"";d+='<p style="margin:'+(i.para.includes(D)?"4pt":"0")+" 0 6pt 0;font-size:"+j+"pt;line-height:"+at+";text-align:justify;"+pe+'">'+se+"</p>"})}let p='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+u(X)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+U.slice(0,3).map(i=>'<b style="font-size:'+t.kop.fs+'pt;">'+u(i)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+F.map(i=>u(i)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+u(X.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+s+"</table>"+d+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+u(xt)+'</p><p style="margin:0 0 6pt 0;">'+u(kt)+"</p>"+(o?'<p style="margin:0 0 6pt 0;"><img src="'+o+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+u(yt)+'</b></p><p style="margin:0 0 6pt 0;">'+u(vt)+"</p></td></tr></table></body></html>",m=new Blob(["\uFEFF"+p],{type:"application/msword"}),n=document.createElement("a");n.href=URL.createObjectURL(m),n.download="Hasil-PA-"+re+".doc",document.body.appendChild(n),n.click(),window.setTimeout(()=>{URL.revokeObjectURL(n.href),n.remove()},4e3)}let le=I.map(t=>{if(jt(t.title)){let l=t.items.length?t.items:["Tidak ada"],c=l.length>1;return'<div class="section-catatan"><span class="catatan-label">'+ne(t.title)+'</span><div class="catatan-list">'+l.map(h=>{let k="<span>"+u(et(h)||"Tidak ada")+"</span>";return c?'<div class="catatan-item"><span class="catatan-dash">-</span>'+k+"</div>":'<div class="catatan-item">'+k+"</div>"}).join("")+"</div></div>"}let e=x(t.title)==="kesimpulan",o=x(t.title)==="icdo",s=e||o||x(t.title)==="saran",d=Math.max(3,...t.items.map(l=>(M(l)?.[0].length??0)+1)),p='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+(o&&!t.bare?" section-icdo":"")+'" style="--pa-marker-ch:'+d+'ch">'+t.items.map((l,c)=>{let h=t.para.includes(c)?" item-para":"",k=M(l),P=!k&&/:\s*$/.test(l)&&c+1<t.items.length&&!!M(t.items[c+1])&&t.para.includes(c+1);if(k&&!(t.items.length===1&&/^[-•–—*]$/.test(k[0]))){let j=s?"<strong>"+u(k[1])+"</strong>":Y(k[1]);return'<div class="item-list has-marker'+h+'"><span class="item-marker">'+(s?"<strong>"+u(k[0])+"</strong>":u(k[0]))+"</span><span>"+j+"</span></div>"}return'<div class="item-list'+h+(P?" item-intro":"")+'">'+(s?"<strong>"+u(l)+"</strong>":Y(l))+"</div>"}).join("")+"</div>";if(t.bare)return p;let m=x(t.title),n=["makroskopik","mikroskopik","kesimpulan"].includes(m)?" u":"",i=m==="icdo"?" i":"";return'<div class="section-judul'+n+i+'">'+u(t.title)+"</div>"+p}).join("");document.body.innerHTML='<a href="'+u(wt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+u(mt)+'" alt="Logo"></div><div class="kop-text">'+U.slice(0,3).map(t=>'<h1 class="kop-atas">'+u(t)+"</h1>").join("")+'<div class="kop-alamat">'+F.map(t=>u(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+u(X)+'</div><div class="patient-info-container">'+ae+'</div><div class="hasil-pa">'+le+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+u(xt)+"</p><p>"+u(kt)+"</p>"+(_?'<img src="'+u(_)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+u(yt)+'</p><p style="margin-top: 2px;">'+u(vt)+"</p></div></div></div>",te.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),oe().catch(()=>{window.location.href=wt})});let St=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(s,d,p,m,n,i,l,c)=>"<label>"+u(p)+'<input type="range" data-g="'+u(s)+'" data-f="'+d+'" min="'+m+'" max="'+n+'" step="'+i+'" value="'+l+'"><output data-o="'+u(s+"-"+d)+'">'+u(String(l)+c)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+Tt.map(s=>'<div class="t-typo-group"><strong>'+u(s.label)+'</strong><div class="t-typo-row">'+e(s.key,"fs","Font (pt)",4,20,.5,C[s.key].fs,"pt")+e(s.key,"lh","Spasi baris",.5,2.5,.05,C[s.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(s=>{let d=s;d.addEventListener("input",()=>{let p=d.dataset.g,m=d.dataset.f;if(!p||!m||!C[p])return;C[p][m]=Number(d.value),Q();let n=t.querySelector(`output[data-o="${p}-${m}"]`);n&&(n.textContent=d.value+(m==="fs"?"pt":""))})});let o=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let s=Bt(E(),C);o&&(o.textContent=s?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Pt(E()),C=pt(E()),Q(),St(),o){let s=t.querySelector("[data-note]");s&&(s.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&St(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let Et="ext-pa-print-style";if(!document.getElementById(Et)){let t=document.createElement("style");t.id=Et,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-transform: uppercase;
        }

        /* Garis bawah hanya untuk header Makroskopik/Mikroskopik/Kesimpulan
           (permintaan user 2026-11-06). */
        .section-judul.u {
            text-decoration: underline;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Isi ICD-O yang dirender server DENGAN judul section sendiri:
           menyatu dengan Catatan/Saran \u2192 ikut grup Isi yang sama
           (user 2026-11-06), selalu bold.
           Varian tanpa judul memakai .section-isi-bare (grup Isi sama). */
        .section-icdo {
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Header ICD-O berjudul menyatu dengan isinya \u2192 grup Isi
           (bukan Judul), supaya header+isi sama besar. */
        .section-judul.i {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Hanging indent: baris bernomor/berpoin \u2014 penanda di kolom
           kiri tetap, teks lanjutan sejajar di bawah teks. */
        /* Hanging indent: penanda (I., II., VII., ...) di kolom kiri tetap
           (posisi absolut), teks paragraf mulai di indent tetap sehingga
           baris lanjutan & antar item sejajar meski lebar penanda beda. */
        .item-list.has-marker {
            position: relative;
            padding-left: var(--pa-marker-ch, 3ch);
        }

        .item-marker {
            position: absolute;
            left: 0;
            top: 0;
            white-space: nowrap;
        }

        /* Item tanpa penomoran dalam section yang punya penomoran (mis.
           "Diterima 2 buah jaringan..." di Makroskopik) ikut terindent
           agar sejajar dengan teks setelah Romawi. */
        .section-isi:has(.item-list.has-marker) .item-list:not(.has-marker) {
            padding-left: var(--pa-marker-ch, 3ch);
        }

        /* Baris pengantar yang dipisah baris kosong \u2192 rata kiri. */
        .section-isi:has(.item-list.has-marker) .item-list.item-intro {
            padding-left: 0;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap rapat. */
        .item-list.item-para {
            margin-top: 4px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah), dan memakai grup
           Isi yang sama dengan Catatan/Saran (user 2026-11-06). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN & SARAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya).
           Header dan isi menyatu dalam satu baris, jadi keduanya memakai
           grup Isi yang sama (\u2699\uFE0F Gaya \u2192 Isi), sama besar dengan isi \u2014
           sesuai permintaan user 2026-11-06. Seluruh isinya bold. */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
            font-weight: bold;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let f=Date.now(),g=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(g),a().catch(()=>{})):Date.now()-f>5e3&&window.clearInterval(g)},200)})})();
