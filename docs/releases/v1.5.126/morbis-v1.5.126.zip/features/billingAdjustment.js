"use strict";var __morbis_feature=(()=>{var _="extensionConfig";function H(c,d,s){let m=d?.features?.[c];if(!m)return!0;if(m.enabled===!1)return!1;let f=s??d?.currentRole??"admin";if(f==="admin")return!0;let p=m.allowedRoles;return!Array.isArray(p)||p.length===0?!0:p.includes(f)}async function $(c){try{let d=(await chrome.storage.sync.get(_))?.[_]??null;return H(c,d)}catch{return!0}}function O(c,d){$(c).then(s=>{if(s)try{d()}catch(m){console.error(`[featureGate:${c}] gagal jalan:`,m)}})}O("billingAdjustment",function(){"use strict";let c="data-ext-billing-adj",d=0,s=null,m=!1;function f(){s!==null&&(clearInterval(s),s=null)}function p(){return document.documentElement.getAttribute(c)==="1"}function i(e){return document.querySelector(e)?.value??""}function r(e){if(!e)return 0;let t=String(e).replace(/[.,](?=\d{3}(?:[.,]|$))/g,"").replace(/[.,](?=\d{1,2}$)/,".");return parseFloat(t)||0}function u(e){return e.toLocaleString("id-ID").replace(/,/g,".")}function x(e,t){let a=e.match(new RegExp("^"+t+"_(\\d+)$"));return a?a[1]:null}function F(){if(document.getElementById("ext-billing-adj-css"))return;let e=document.createElement("style");e.id="ext-billing-adj-css",e.textContent=`
      #totalharga.ext-billing-editable,
      #pembulatanShow.ext-billing-editable,
      #ext-total-jasa.ext-billing-editable {
        background: #fef3c7 !important;
        border: 2px solid #f59e0b !important;
        border-radius: 4px;
        padding: 4px 8px;
        font-weight: 600;
        color: #92400e;
        cursor: text;
        min-width: 100px;
        text-align: right;
      }
      #totalharga.ext-billing-editable:focus,
      #pembulatanShow.ext-billing-editable:focus,
      #ext-total-jasa.ext-billing-editable:focus {
        border-color: #d97706 !important;
        box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.3);
        outline: none;
      }
      .ext-billing-total-display {
        background: #dbeafe !important;
        border: 2px solid #3b82f6 !important;
        border-radius: 4px;
        padding: 4px 8px;
        font-weight: 700;
        color: #1e40af;
        min-width: 120px;
        text-align: right;
        display: inline-block;
      }
      .ext-billing-regen-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 14px;
        background: #2563eb;
        color: #fff;
        border: none;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        margin-left: 8px;
      }
      .ext-billing-regen-btn:hover { background: #1d4ed8; }
      .ext-billing-regen-btn:active { background: #1e40af; }
      .ext-billing-regen-btn svg { width: 14px; height: 14px; }
      .ext-billing-status {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 600;
        margin-left: 8px;
      }
      .ext-billing-status.ok { background: #d1fae5; color: #065f46; }
      .ext-billing-status.warning { background: #fef3c7; color: #92400e; }
      .ext-billing-auto-mode {
        display: inline-block;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: 600;
        margin-left: 4px;
        background: #e0e7ff;
        color: #3730a3;
      }
    `,document.head.appendChild(e)}function k(e,t){document.querySelector(".ext-billing-status")?.remove();let a=document.createElement("span");a.className="ext-billing-status "+t,a.textContent=e;let n=document.querySelector(".ext-billing-regen-btn");n?.parentElement&&n.parentElement.insertBefore(a,n.nextSibling),setTimeout(()=>a.remove(),3e3)}function A(e){let t=r(i("#harga_"+e)),a=r(i("#frekuensi_"+e)),n=r(i("#diskon_"+e)),l=t*a-n,o=document.querySelector("#total_"+e);return o&&(o.value=u(l)),l}function L(){let e=0;return document.querySelectorAll('input[id^="total_"]').forEach(t=>{x(t.id,"total")&&(e+=r(t.value))}),e}function B(){let e=document.querySelectorAll("table");for(let t of Array.from(e))for(let a of Array.from(t.querySelectorAll("tr"))){let n=a.querySelectorAll("td");if(!n.length||n[0].textContent.trim()!=="Total")continue;let l=(n[1]?.textContent??"").match(/Tunai\s*:?\s*([\d.]+)/);if(l)return r(l[1])}return 0}function q(e){let t=document.querySelectorAll("table")[1]?.querySelector("b"),a=document.querySelector("#ext-total-jasa");a?a.value=u(e):t&&(t.textContent=u(e));let n=document.querySelector("#total_billing");n&&(n.value=String(Math.round(e)))}function g(){let e=r(i("#totalharga")),t=r(i("#biaya_adm")),a=r(i("#biaya_materai")),n=r(i("#diskon")),l=r(i("#klaim_bpjs")),o=r(i("#tarik_uang_muka")),v=r(i("#pembulatanShow")),E=r(i("#bayar")),h=e+t+a-n-l+o+v,C=document.querySelector("#total_belum_dibayar");C&&(C.value=String(Math.round(h)));let T=document.querySelector("#pembulatan"),M=document.querySelector("#pembulatanShow");T&&M&&(T.value=M.value);let S=Array.from(document.querySelectorAll("td")).find(b=>b.textContent.trim().toLowerCase()==="total belum dibayar")?.parentElement?.querySelector("td:last-child");if(S&&!S.querySelector("input")){let b=S.querySelector(".ext-billing-total-display");b||(S.textContent="",b=document.createElement("span"),b.className="ext-billing-total-display",S.appendChild(b)),b.textContent=u(h)}let R=Math.max(0,E-h),K=document.querySelector("#kembali2"),D=document.querySelector("#kembali1");K&&(K.value=String(R)),D&&(D.textContent=u(R));let w=Math.max(0,h-E),I=document.querySelector("#sisaTagihan2"),N=document.querySelector("#sisaTagihan1");I&&(I.value=String(w)),N&&(N.textContent=u(w));let z=document.querySelector("#total1");z&&(z.textContent=E>=h?"0":u(w))}function y(e,t){e.dataset.extRtBound!=="1"&&(e.dataset.extRtBound="1",e.addEventListener("input",t),e.addEventListener("keyup",t),e.addEventListener("change",t))}function j(){document.querySelectorAll('input[id^="frekuensi_"]').forEach(l=>{let o=x(l.id,"frekuensi");o&&A(o)});let e=L(),t=document.querySelector("#ext-total-jasa");if(t){t.value=u(e),t.dataset.autoMode="true";let l=document.querySelector("#totaljasa-auto-indicator");l&&(l.style.display="")}q(e);let a=e+B(),n=document.querySelector("#totalharga");n&&(n.value=u(a),n.dataset.original=n.value),g(),k("Regenerated: "+u(a),"ok")}function G(){let e=document.querySelectorAll("table"),t=e[1]?.querySelector("td:last-child"),a=e[1]?.querySelector("b");if(!t||document.querySelector("#ext-total-jasa"))return;let n=document.createElement("input");n.type="text",n.id="ext-total-jasa",n.className="ext-billing-editable",n.value=a?.textContent.trim()??i("#total_billing"),n.dataset.autoMode="true",a?a.replaceWith(n):t.prepend(n);let l=document.createElement("span");l.className="ext-billing-auto-mode",l.textContent="AUTO",l.id="totaljasa-auto-indicator",n.after(l),y(n,()=>{n.dataset.autoMode="false",l.style.display="none",q(r(n.value)),g()}),n.addEventListener("blur",()=>k("Total jasa diupdate","ok")),n.addEventListener("keydown",o=>{o.key==="Enter"&&(o.preventDefault(),n.blur())})}function P(){let e=document.querySelector("#totalharga");!e||e.dataset.extBillingBound==="1"||(e.dataset.extBillingBound="1",e.classList.add("ext-billing-editable"),e.dataset.original=e.value,y(e,()=>{g()}),e.addEventListener("blur",()=>{e.dataset.original=e.value,k("Total diupdate","ok")}),e.addEventListener("keydown",t=>{t.key==="Enter"&&(t.preventDefault(),e.blur())}))}function U(){let e=document.querySelector("#pembulatanShow");!e||e.dataset.extBillingBound==="1"||(e.dataset.extBillingBound="1",e.removeAttribute("readonly"),e.readOnly=!1,e.removeAttribute("disabled"),e.disabled=!1,e.classList.add("ext-billing-editable"),e.dataset.original=e.value,y(e,()=>{g()}),e.addEventListener("blur",()=>{e.dataset.original=e.value}),e.addEventListener("keydown",t=>{t.key==="Enter"&&(t.preventDefault(),e.blur())}))}function W(){if(document.documentElement.dataset.extBillingRows==="1")return;document.documentElement.dataset.extBillingRows="1";let e=t=>{let a=t.target;if(!(a instanceof HTMLInputElement))return;let n=x(a.id,"frekuensi")??x(a.id,"harga")??x(a.id,"diskon");if(!n)return;A(n);let l=L(),o=document.querySelector("#ext-total-jasa");o&&o.dataset.autoMode!=="false"&&(o.value=u(l)),q(l);let v=document.querySelector("#totalharga");v&&(v.value=u(l+B())),g()};document.addEventListener("input",e),document.addEventListener("keyup",e),document.addEventListener("change",e)}function J(){["biaya_adm","biaya_materai","diskon","klaim_bpjs","tarik_uang_muka","bayar"].forEach(t=>{let a=document.querySelector("#"+t);a&&y(a,g)});let e=document.querySelector("#diskon_dalam_persen");e&&y(e,()=>{let t=r(e.value),a=r(i("#totalharga")),n=document.querySelector("#diskon");n&&(n.value=u(a*t/100)),g()})}function Q(){if(document.querySelector(".ext-billing-regen-btn"))return;let e=document.querySelector("button");if(!e?.parentElement)return;let t=document.createElement("button");t.type="button",t.className="ext-billing-regen-btn",t.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Regenerate Total',t.addEventListener("click",j),e.parentElement.insertBefore(t,e.nextSibling)}function V(){document.documentElement.dataset.extBillingKeys!=="1"&&(document.documentElement.dataset.extBillingKeys="1",document.addEventListener("keydown",e=>{if(e.ctrlKey&&e.shiftKey&&e.key==="R"&&(e.preventDefault(),j()),e.ctrlKey&&e.shiftKey&&e.key==="T"){e.preventDefault();let t=document.querySelector("#totalharga");t?.focus(),t?.select()}if(e.ctrlKey&&e.shiftKey&&e.key==="P"){e.preventDefault();let t=document.querySelector("#pembulatanShow");t?.focus(),t?.select()}}))}function X(){m||(m=!0,F(),G(),P(),U(),W(),J(),Q(),V(),g(),console.log("[BillingAdj] initialized"))}s=window.setInterval(()=>{if(d++,!p()){d>=150&&f();return}document.querySelector("#totalharga")&&document.querySelector("#pembulatanShow")?(f(),X()):d>=150&&f()},100)})})();
