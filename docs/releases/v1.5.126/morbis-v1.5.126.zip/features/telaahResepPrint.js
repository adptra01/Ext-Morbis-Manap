"use strict";var __morbis_feature=(()=>{var U="extensionConfig";function et(g,u,w){let f=u?.features?.[g];if(!f)return!0;if(f.enabled===!1)return!1;let S=w??u?.currentRole??"admin";if(S==="admin")return!0;let x=f.allowedRoles;return!Array.isArray(x)||x.length===0?!0:x.includes(S)}async function at(g){try{let u=(await chrome.storage.sync.get(U))?.[U]??null;return et(g,u)}catch{return!0}}function nt(g,u){at(g).then(w=>{if(w)try{u()}catch(f){console.error(`[featureGate:${g}] gagal jalan:`,f)}})}nt("telaahResep",function(){"use strict";async function g(){let S="ext-telaah-proc",x=document.querySelector(".halaman");if(!x||x.getAttribute(S))return;let d=x;d.setAttribute(S,"1");let p=t=>(t?.textContent||"").replace(/\s+/g," ").trim();function r(t){return String(t??"").replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[a])}let it=t=>t?r(t.replace(/^(.*?)(\d+)$/,`$1
$2`)):"-",rt=d.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",v="RSUD H. ABDUL MANAP",I=[],M=d.querySelector("#head-cetak-logo");if(M){let t=M.querySelector("b");v=t?p(t):v;let a=document.createElement("div");a.innerHTML=M.innerHTML.replace(/<br\s*\/?>/gi,`
`),I=(a.textContent||"").split(`
`).map(e=>e.trim()).filter(Boolean).filter(e=>e!==v)}let _=new Map,P=[];d.querySelectorAll(".halaman > table:first-of-type table").forEach(t=>{t.querySelectorAll("tr").forEach(a=>{let e=a.querySelectorAll("td");if(e.length<2)return;let n=p(e[0]),s=p(e[1]).replace(/^:\s*/,"");if(n&&!_.has(n)&&_.set(n,s),/^diagnosa$/i.test(n)){let m=(e[1].innerHTML||"").replace(/<br\s*\/?>/gi,`
`),o=document.createElement("div");o.innerHTML=m,P=(o.textContent||"").split(`
`).map(l=>l.trim()).filter(l=>l&&!/^:/.test(l)&&!/tidak ada/i.test(l))}})});let lt=t=>_.get(t)??"",R=[],D=Array.from(d.querySelectorAll("table.resep-item"))[1],C="",K="",A=[],q=[],ot="",z="";async function st(){let t=new URLSearchParams(window.location.search),a=t.get("id_resep")||t.get("id")||t.get("penjualan")||"";if(!a)return;let e="/inventory/resep/penerimaan/detail?id="+a;try{let n=await fetch(e,{credentials:"include"});if(!n.ok)return;let s=await n.text(),m=new DOMParser().parseFromString(s,"text/html"),o=i=>(m.querySelector("#"+i)||m.querySelector('input[name="'+i+'"]')||m.querySelector('input[id*="'+i+'"]'))?.value?.trim()||"";C=o("id_visit")||t.get("visit")||C,K=o("id_kunjungan")||K,z=o("no_sep")||z;let l=Array.from(m.querySelectorAll("fieldset#perhatian")).find(i=>{let h=i.querySelector("legend");return h&&/riwayat\s*diagnosa\s*pasien/i.test(p(h))});if(l){let i=Array.from(l.querySelectorAll("li")).map(b=>p(b)).filter(Boolean),h=-1,E=Array.from(l.querySelectorAll("strong, b"));for(let b of E)if(/diagnosa\s*sekunder/i.test(p(b))){let X=b.closest("li");if(X){let k=Array.from(l.querySelectorAll("li")).indexOf(X);k>=0&&(h=k)}else{let k=b.nextElementSibling;if(k&&k.tagName==="OL"){let Z=k.querySelector("li");if(Z){let tt=Array.from(l.querySelectorAll("li")).indexOf(Z);tt>=0&&(h=tt)}}}break}h>=0&&h<i.length?(A=i.slice(0,h),q=i.slice(h).filter(b=>b&&!/tidak ada/i.test(b))):i.length&&(A=i)}}catch{}}function mt(t){let a=o=>typeof o=="string"?o.trim():"",e=a(t.nama_barang),n=a(t.kekuatan),s=a(t.sediaan),m=a(t.satuan);return n&&(e+=(e?" ":"")+n),s&&(e+=(e?", ":"")+s),m&&(e+=(e?" @":"")+m),e}function dt(t){return{NO_R:t.no_r,JENIS_R:t.jenis_r,JENIS_RSP:t.jenis_r,NAMA_RACIKAN:t.nama_racikan,ATURAN_PAKAI_MANUAL:t.aturan_pakai_manual,JUMLAH_RACIKAN:t.jumlah_racikan,NAMA:mt(t),KEKUATAN_R_RACIK:t.kekuatan_r_racik,KEKUATAN:t.kekuatan,JUMLAH_R_PAKAI:t.jumlah_r_pakai,SEDIAAN:t.sediaan,JUMLAH_R_RESEP:t.jumlah_r_resep}}async function ct(t){try{let a=await fetch("/inventory/search?opsi=tabel_penjualan_lama&id_penjualan="+encodeURIComponent(t),{credentials:"include",cache:"no-store"});if(!a.ok)return[];let e=await a.json();return(Array.isArray(e)?e:Object.values(e??{})).filter(n=>typeof n=="object"&&n!==null).map(dt).filter(n=>String(n.NO_R??"").trim()!=="")}catch{return[]}}async function pt(){let t=y.get("id_resep")||y.get("id")||y.get("penjualan")||"";if(!t)return[];try{let a=await fetch("/inventory/resep/akses/penerimaan?type=ajax&opsi=data-resep-new&q=1&id="+encodeURIComponent(t),{credentials:"include",cache:"no-store"});if(!a.ok)return[];let e=await a.json(),n=String(e?.ID_PENJUALAN??"").trim();if(n&&n!=="0"){let s=await ct(n);if(s.length)return s}return Array.isArray(e?.resep)?e.resep:[]}catch{return[]}}function ht(t){try{let a=new URL(t);if(a.protocol!=="http:"&&a.protocol!=="https:")return!1;let e=a.hostname.toLowerCase();return["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"].includes(e)?!0:e.endsWith(".rsudkotajambi.id")||e.endsWith(".ddev.site")}catch{return!1}}async function gt(t){try{let a="http://dev.rsudkotajambi.id/rs";try{let s=localStorage.getItem("ext-farmasi-app-base");s&&ht(s)&&(a=s.replace(/\/+$/,""))}catch{}let e=await fetch(a+"/api/queue/lookup?resep_id="+encodeURIComponent(t),{cache:"no-store",credentials:"omit",signal:AbortSignal.timeout(8e3)});if(!e.ok)return"";let n=await e.json();if(n.ok&&n.found&&n.queue?.queue_number)return n.queue.queue_number}catch{}return""}let y=new URLSearchParams(window.location.search),J=y.get("id_resep")||y.get("id")||y.get("penjualan")||"";await st();let H=await pt();if(H.length){R.length=0;let t=new Map;for(let a of H){let e=String(a.NO_R??"").trim();e&&(t.has(e)||t.set(e,[]),t.get(e).push(a))}for(let[a,e]of t){let n=e[0],s=String(n.JENIS_R??"").toLowerCase()==="racikan"||String(n.JENIS_RSP??"").toLowerCase()==="racikan",m=String(n.NAMA_RACIKAN??"").trim(),o=String(n.ATURAN_PAKAI_MANUAL??"").trim().replace(/^-\s*/,"").trim();if(s||e.length>1){let l={no:"R/"+a,name:m||"",jml:"",jumlahJadi:String(n.JUMLAH_RACIKAN??"").trim()||"",sediaan:m,aturan:o?[o]:[],subMeds:e.map(i=>({name:String(i.NAMA??"").trim(),strength:String(i.KEKUATAN_R_RACIK??i.KEKUATAN??"").trim(),dose:"",jmlPerR:String(i.JUMLAH_R_PAKAI??"").trim(),sediaan:String(i.SEDIAAN??"").trim()}))};R.push(l)}else{let l={no:"R/"+a,name:String(n.NAMA??"").trim(),jml:String(n.JUMLAH_R_RESEP??n.JUMLAH_R_PAKAI??"").trim(),jumlahJadi:"",sediaan:String(n.SEDIAAN??"").trim(),aturan:o?[o]:[],subMeds:[]};R.push(l)}}}!A.length&&P.length&&(A=P);let O=d.querySelector("#form_checklist_telaah_resep"),B=t=>{let a=[];if(!O)return a;let e=Array.from(O.querySelectorAll("table")).find(n=>p(n.querySelector("tr td"))===t);return e&&e.querySelectorAll("tr").forEach((n,s)=>{if(s===0)return;let m=n.querySelectorAll("td");if(m.length<2)return;let o=p(m[0]),l=p(m[1]);o&&l&&l!==t&&a.push([o,l])}),a},ut=B("Telaah Resep"),ft=B("Telaah Obat"),$=Array.from(d.querySelectorAll("center, strong")).find(t=>/Obat tidak boleh diganti/i.test(p(t))),bt=$?p($):"Obat tidak boleh diganti tanpa sepengetahuan Dokter",L=(t,a,e="",n="")=>'<div class="tm-row'+(n?" "+n:"")+'"><span class="tm-label">'+r(t)+':</span><span class="tm-val'+(e?" "+e:"")+'">'+(a&&a.trim()?r(a):"-")+"</span></div>",F=[...A.length?[A.join(", ")]:[],...q.length?[q.join(", ")]:[]],c=t=>lt(t),N=c("Jenis Kelamin"),xt=/^perempuan$/i.test(N)?"P":/^laki-laki$/i.test(N)?"L":N,At=(c("Nama Pasien")||"-")+(N?" ("+xt+")":""),yt=(c("Dokter")||"-")+(c("Ruangan/Poli")?" / "+c("Ruangan/Poli"):""),W=t=>{for(let a of _.keys())if(t.test(a))return _.get(a)||"";return""},kt=W(/alergi/i),j=W(/berat|\bbb\b/i),Y=j?/\bkg\b/i.test(j)?j:j+" kg":"- kg",wt=(kt||"-")+" / "+(j?"BB "+Y:Y),St=[["Pasien",At,""],["No. RM",c("No. RM"),""],["Tgl. Lahir",c("Tgl. Lahir/Umur"),""],["Alergi & BB",wt,""],["Alamat",c("Alamat"),"long"],["No HP",c("No HP"),""]],_t=[["Dokter",yt,""],["SIP Dokter",c("SIP Dokter"),""],["No Resep",c("No Resep"),""],["No SEP",z||"-",""],["Tanggal",c("Tanggal & Jam"),""],["Penjamin",c("Penjamin"),""]],jt=L("Diagnosa",F.length?F.join(", "):"-","","long"),vt='<section class="tm-card tm-card--small tm-card--left"><div class="tm-col">'+St.map(([t,a,e])=>L(t,a,"",e)).join("")+jt+"</div></section>",Rt='<section class="tm-card tm-card--right"><div class="tm-col">'+_t.map(([t,a,e])=>L(t,a,"",e)).join("")+"</div></section>",Nt=R.map(t=>{if(t.subMeds.length){let e=t.subMeds.map((i,h)=>{let E=i.jmlPerR||"";return'<div class="med-line'+(h>0?" indent":"")+'">'+(h===0?'<span class="med-no">'+r(t.no)+"</span> ":"")+'<span class="med-name">'+r(i.name)+"</span>"+(E?', <span class="med-jml">Jml: '+r(E)+"</span>":"")+"</div>"}).join(""),n=t.jumlahJadi?r(t.jumlahJadi):"",s=t.sediaan?r(t.sediaan):"Racikan",m=t.aturan.length?t.aturan.map(i=>r(i.replace(/^\(|\)$/g,""))).join(" "):"",o=n?"Jml "+n+" "+s+(m?" - ("+m+")":""):"",l=o?'<div class="med-jadiracik">'+o+"</div>":"";return'<div class="med">'+e+l+"</div>"}let a=t.jml||"";return'<div class="med"><div class="med-line"><span class="med-no">'+r(t.no)+'</span> <span class="med-name">'+r(t.name)+"</span>"+(a?', <span class="med-jml">Jml: '+r(a)+"</span>":"")+"</div>"+(t.aturan.length?'<div class="med-aturan">'+t.aturan.map(e=>r(e)).join("<br/>")+"</div>":"")+"</div>"}).join(""),T=D?Array.from(D.querySelectorAll("tr:first-child td")).map(t=>p(t)).filter(Boolean):["Hitung","Timbang","Kemas"];T.some(t=>/paraf/i.test(t))||T.push("Paraf");let Tt=T.length,Et='<table class="t-admin"><thead><tr>'+T.map(t=>'<th class="l">'+r(t)+"</th>").join("")+"</tr></thead><tbody><tr>"+Array.from({length:Tt}).map(()=>'<td class="blk"></td>').join("")+"</tr></tbody></table>",G=(t,a)=>'<table class="t-check"><thead><tr><th class="l" colspan="2">'+r(t)+'</th><th class="yt">Y/T</th></tr></thead><tbody>'+a.map(([e,n])=>'<tr><td class="num">'+r(e)+"</td><td>"+r(n)+'</td><td class="yt"></td></tr>').join("")+"</tbody></table>",It='<header class="t-head"><img class="t-logo" alt="Logo" src="'+r(rt)+'"/><div class="t-bhead"><h1 class="t-hname">'+r(v)+"</h1>"+(I[0]?'<div class="t-hsub">'+r(I[0])+"</div>":"")+'</div><div class="t-antrian">'+it(ot)+'</div></header><main class="t-main"><section class="t-left">'+vt+'<div class="t-meds">'+Nt+"</div>"+Et+'</section><section class="t-right">'+Rt+G("Telaah Resep",ut)+G("Telaah Obat",ft)+'<table class="t-check"><thead><tr><th class="c" colspan="2">Perubahan resep</th></tr><tr><th class="c half">Tertulis</th><th class="c half">Menjadi</th></tr></thead><tbody><tr><td class="blk4"></td><td class="blk4"></td></tr><tr><td class="c">Apoteker</td><td class="c">Disetujui Dokter</td></tr><tr><td class="blk4"></td><td class="blk4"></td></tr><tr><td class="c" colspan="2">Waktu Tunggu</td></tr><tr><td class="third">Masuk</td><td></td></tr><tr><td>Diserahkan</td><td></td></tr><tr><td class="twothird">Paraf Pasien/Keluarga</td><td class="blk3"></td></tr></tbody></table></section></main><footer class="t-footer">'+r(bt)+'</footer><div class="t-print no-print"><button type="button" class="t-btn" onclick="window.print()">Cetak</button></div>';if(d.innerHTML=It,J){let t=d.querySelector(".t-antrian");gt(J).then(a=>{a&&t&&t.isConnected&&(t.textContent=a.replace(/^(.*?)(\d+)$/,`$1
$2`))})}let V=866;d.scrollHeight>V&&(d.classList.add("compact"),d.offsetHeight,d.scrollHeight>V&&(d.classList.remove("compact"),d.classList.add("ultra")));let Q="ext-telaah-style";if(!document.getElementById(Q)){let t=document.createElement("style");t.id=Q,t.textContent=`
        /* === PRINT CONTRACT: 105mm \xD7 241mm === */
        .halaman{box-sizing:border-box;width:105mm!important;height:auto!important;max-height:241mm;margin:0!important;padding:0 3mm}
        @page{size:105mm 241mm;margin:0}
        .halaman *{box-sizing:border-box;font-size:11px!important}
        .halaman{font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.25;color:#000;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}

        /* HEADER 3 kolom: logo | brand & alamat | no antrian */
        .t-head{display:flex;align-items:center;padding-bottom:6px;border-bottom:1.5px solid #000;margin-bottom:8px;gap:10px}
        .t-logo{width:50px;height:50px;object-fit:contain;object-position:left top;flex:none}
        .t-bhead{flex:1;font-size:11px;min-width:0}
        .t-hname{font-size:12px;font-weight:800;margin:0 0 2px;letter-spacing:-.01em}
        .t-hsub{line-height:1.2;font-size:10px}
        .t-antrian{flex:none;text-align:right;font-size:36px!important;font-weight:800;color:#198754;letter-spacing:-.02em;font-variant-numeric:tabular-nums;min-width:0;overflow-wrap:anywhere;line-height:1;white-space:pre-line}

        /* METADATA \u2014 grid: label kiri, nilai kanan (efisien tinggi) */
        .tm-card{background:#fff;padding:2px 0 4px;margin-bottom:4px;font-size:11px;border-bottom:0.5pt solid #333}
        .tm-card--small .tm-label{font-size:9px!important}
        .tm-card--small .tm-val{font-size:10px!important}
        .tm-col{display:flex;flex-direction:column;gap:3px}
        .tm-row{display:grid;grid-template-columns:35% 65%;column-gap:4px;align-items:start}
        .tm-card--left .tm-row{grid-template-columns:20% 65%}
        .tm-card--right .tm-row{grid-template-columns:30% 65%}
        .tm-label{color:#5b6470;font-size:10px;line-height:1.25;text-align:left}
        .tm-val{color:#000;line-height:1.25;word-wrap:break-word;overflow-wrap:anywhere}
        /* field panjang (alamat, diagnosa) tetap di grid 2 kolom biar wrap di kanan */
        .tm-row.long{display:grid}
        .tm-row.long .tm-label{display:block}

        /* MAIN 2 kolom \u2014 kiri lebih lebar utk nama obat */
        .t-main{display:grid;grid-template-columns:62% 38%;gap:6px;align-items:start}
        .t-left,.t-right{display:flex;flex-direction:column;gap:5px;min-width:0}
        .t-right .t-check{margin-bottom:0}
        .t-meds{margin-bottom:8px;font-size:11px;min-width:0}

        /* DAFTAR OBAT */
        .med{margin-bottom:6px}
        .med-line{font-size:11px;line-height:1.35;text-align:left}
        .med-line.indent{margin-left:0}
        .med-no{font-weight:400}
        .med-name{font-weight:600}
        .med-sep{color:#374151}
        .med-jml{white-space:nowrap;font-weight:600;color:#047857}
        .med-aturan{margin-left:0;font-size:10px;color:#374151;margin-top:1px}
        .med-jadiracik{margin-top:3px;padding-top:1px;font-size:11px;font-weight:700}

        /* TABEL \u2014 checklist (font sama dengan info pasien & dokter = 10px) */
        table{width:100%;border-collapse:collapse;font-size:10px}
        .halaman th,.halaman td{border:0.5pt solid #333;padding:1px 3px;font-weight:400;font-size:10px!important;line-height:1.2}
        thead th{font-weight:400}
        .yt{width:32px;text-align:center}
        .num{width:16px;text-align:center}
        .l{text-align:left}
        .c{text-align:center}
        .half{width:50%}
        .third{width:33.333%}
        .twothird{width:66.667%}
        .blk{height:40px;padding:.5pt 3px}
        .blk2{min-height:10px}
        .blk3{min-height:35px}
        .blk4{height:40px;padding:.5pt 3px}
        .t-sub{text-align:center;font-size:10px!important;margin:3px 0}

        /* FOOTER + BUTTON */
        .t-footer{margin-top:10px;text-align:center;font-weight:700;font-style:italic;font-size:11px}
        .t-print{margin-top:24px;display:flex;gap:8px}
        .t-btn{border:1px solid #d1d5db;background:#fff;border-radius:6px;padding:6px 14px;font-size:11px;cursor:pointer}
        .t-btn:hover{background:#f9fafb}
        @media print{.no-print{display:none!important}}

        /* === ADAPTIVE DENSITY (gentle fallback) === */
        .halaman.compact .t-head{padding-bottom:4px;margin-bottom:6px;gap:8px}
        .halaman.compact .t-logo{width:45px;height:45px}
        .halaman.compact .t-hname{font-size:11px!important}
        .halaman.compact .t-antrian{font-size:30px!important}
        .halaman.compact .tm-card{padding:1px 0 2px;margin-bottom:2px}
        .halaman.compact .tm-col{gap:2px}
        .halaman.compact .tm-label{font-size:9px!important}
        .halaman.compact .tm-val{font-size:10px!important}
        .halaman.compact .t-main{gap:4px}
        .halaman.compact .t-left,.halaman.compact .t-right{gap:3px}
        .halaman.compact .t-meds{margin-bottom:4px}
        .halaman.compact .med{margin-bottom:3px}
        .halaman.compact .blk{height:30px}
        .halaman.compact .blk3{min-height:25px}
        .halaman.compact .blk4{height:30px}
        .halaman.compact .t-footer{margin-top:6px}

        .halaman.ultra .t-head{padding-bottom:3px;margin-bottom:4px;gap:6px}
        .halaman.ultra .t-logo{width:40px;height:40px}
        .halaman.ultra .t-hname{font-size:10px!important}
        .halaman.ultra .t-antrian{font-size:26px!important}
        .halaman.ultra .tm-card{padding:1px 0;margin-bottom:1px}
        .halaman.ultra .tm-col{gap:1px}
        .halaman.ultra .tm-label{font-size:8px!important}
        .halaman.ultra .tm-val{font-size:9px!important}
        .halaman.ultra .t-main{gap:3px}
        .halaman.ultra .t-left,.halaman.ultra .t-right{gap:2px}
        .halaman.ultra .t-meds{margin-bottom:2px}
        .halaman.ultra .med{margin-bottom:2px}
        .halaman.ultra .med-line{font-size:10px!important}
        .halaman.ultra .blk{height:30px}
        .halaman.ultra .blk3{min-height:20px}
        .halaman.ultra .blk4{height:30px}
        .halaman.ultra .t-footer{margin-top:4px;font-size:10px!important}
      `,document.head.appendChild(t)}}let u=g,w=Date.now(),f=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-telaah")==="1"?(window.clearInterval(f),u()):Date.now()-w>5e3&&window.clearInterval(f)},200)})})();
