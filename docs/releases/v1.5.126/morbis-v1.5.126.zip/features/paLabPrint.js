"use strict";var __morbis_feature=(()=>{var B="extensionConfig";function tt(g,f,k){let h=f?.features?.[g];if(!h)return!0;if(h.enabled===!1)return!1;let u=k??f?.currentRole??"admin";if(u==="admin")return!0;let y=h.allowedRoles;return!Array.isArray(y)||y.length===0?!0:y.includes(u)}async function et(g){try{let f=(await chrome.storage.sync.get(B))?.[B]??null;return tt(g,f)}catch{return!0}}function it(g,f){et(g).then(k=>{if(k)try{f()}catch(h){console.error(`[featureGate:${g}] gagal jalan:`,h)}})}it("paLabPrint",function(){"use strict";async function g(){let h="ext-pa-print-proc";if(document.documentElement.getAttribute(h))return;document.documentElement.setAttribute(h,"1");let u=t=>C(t?.textContent||"");function y(t){return t.replace(/<[^>]+>/g," ")}function at(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function C(t){return at(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function l(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let M=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",E=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>u(t)).filter(Boolean);for(;E.length<3;)E.push("");let j=[],N=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(N){let t=document.createElement("div");t.innerHTML=N.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),j=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let L=j.join(" "),_=t=>{let e=L.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},O=_("telp"),F=_("fax"),R=(L.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],T=(L.match(/https?:\/\/[^\s;,]+/)||[""])[0],w=L.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");R&&(w=w.split(R).join("")),T&&(w=w.split(T).join("")),w=w.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let nt=["Alamat: "+w,O?"Telp: "+O:"",F?"Fax: "+F:""].filter(Boolean).join(", "),rt=[R?"Email: "+R:"",T?"Website: "+T:""].filter(Boolean).join(", ");j=[nt,rt].filter(Boolean);let H=u(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",z=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let a=u(e[0]),s=u(e[2]),p=u(e[3]),r=u(e[5]);a&&z.push([a,s]),p&&z.push([p,r])}});let v=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],b=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),x=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",a=!1,s=t.querySelector(".section-title");if(s)e=u(s),a=!0;else{let n=m=>m.split(":")[0].trim();for(let m of Array.from(t.children).slice(0,3)){let c=u(m);if(c&&c.length<=24&&v.includes(b(n(c)))){e=n(c);break}}if(!e){let m=(t.textContent||"").split(`
`).map(c=>c.trim()).find(Boolean)||"";m&&v.includes(b(n(m)))&&(e=n(m))}if(!e)return}let p=document.createElement("div");p.innerHTML=t.innerHTML,p.querySelector(".section-title")?.remove();let r=p.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(n=>n.split(/<br\s*\/?>|\n/).map(m=>C(m.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(n=>n.length),d=[],i=[];r.forEach((n,m)=>{n.forEach((c,D)=>{m>0&&D===0&&d.length&&i.push(d.length),d.push(c)})});let o=d;if(!a&&o.length&&b(o[0])===b(e)){o.shift();for(let n=0;n<i.length;n++)i[n]-=1;for(;i.length&&i[0]<=0;)i.shift()}o.length>1&&!/^[IVXLC]+\.\s/.test(o[0])&&o.slice(1).some(n=>/^II\.\s/.test(n))&&(o[0]="I. "+o[0]),e&&x.push({title:e,items:o,para:i})});let ot=/^catatan\s*:?/i,lt=/^icd[\s-]*o\b\s*:?/i,U=[];for(let t of x){let e=[{title:t.title,items:[],para:[]}],a=e[0],s=!1,p=(r,d)=>{a={title:r,items:[],para:[],bare:d},e.push(a),s=!0};if(t.items.forEach((r,d)=>{let i=r.match(ot),o=i?null:r.match(lt);if(i){b(a.title)!=="catatan"&&p("Catatan");let n=r.slice(i[0].length).trim();n&&(t.para.includes(d)&&a.para.push(a.items.length),a.items.push(n));return}if(o){b(a.title)!=="icdo"&&p("ICD-0",!0),t.para.includes(d)&&a.para.push(a.items.length),a.items.push(r);return}t.para.includes(d)&&a.para.push(a.items.length),a.items.push(r)}),s)for(let r of e)r.items.length&&U.push(r);else U.push(e[0])}x.length=0,x.push(...U),x.forEach((t,e)=>t._i=e),x.sort((t,e)=>{let a=t._i??0,s=e._i??0,p=v.indexOf(b(t.title)),r=v.indexOf(b(e.title)),d=p===-1?v.length:p,i=r===-1?v.length:r;return d!==i?d-i:a-s});function st(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let a=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),s=t.getAttribute("placeholder")||"",p=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(a+" "+s+" "+p).slice(0,300)}}function pt(t,e,a){let s=e.toLowerCase().split(/[^a-z0-9]+/).filter(i=>i.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(i));if(!s.length)return"";let p=s.sort((i,o)=>o.length-i.length)[0],r="",d=-1;return t.querySelectorAll("input, textarea, select").forEach(i=>{let{val:o,ctx:n}=st(i);if(!o||o===e||!o.toLowerCase().includes(p))return;let m=a.test(n)?2:0;m>d&&(d=m,r=o)}),r}function dt(t,e){return(t.querySelector(e)?.value||"").trim()}async function ct(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let a=i=>/ket\w*\s*klinis/i.test(i),s=i=>/^dokter/i.test(i)||/^rs\b/i.test(i),p=t.map(([i,o],n)=>({label:i,value:o,idx:n})).filter(i=>s(i.label)?!!i.value:a(i.label));if(!p.length)return;let r=new AbortController,d=window.setTimeout(()=>r.abort(),6e3);try{let i=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),o=await fetch(i.toString(),{credentials:"same-origin",signal:r.signal});if(!o.ok){window.console.info("[paPrint] override: fetch input status "+o.status);return}let n=await o.text(),m=new DOMParser().parseFromString(n,"text/html");window.console.info('[paPrint] override: input title="'+(m.title||"").slice(0,60)+'" len='+n.length+" fields="+m.querySelectorAll("input, textarea, select").length);for(let c of p){if(a(c.label)){let wt=dt(m,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),I=C(y(wt));window.console.info("[paPrint] override: "+c.label+' cetak="'+c.value+'" input="'+I+'"'),I&&I!==c.value&&(t[c.idx][1]=I);continue}let D=/^dokter/i.test(c.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,xt=pt(m,c.value,D),q=C(y(xt||""));window.console.info("[paPrint] override: "+c.label+' cetak="'+c.value+'" input="'+q+'"'),q&&q!==c.value&&(t[c.idx][1]=q)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(d)}}await ct(z).catch(()=>{});let A=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>u(t)).filter(Boolean),K=A[0]||"",$=A[1]||"",P=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",W=A.find(t=>/^\(.*\)$/.test(t))||A[2]||"",Q=A.find(t=>/^nip\.?/i.test(t))||A[3]||"",G=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",mt=Array.from(document.body.querySelectorAll("script")),ut=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),S=z.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let a=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,s=a.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||a,p=s.split(/\s+-\s*/);if(p.length>=3&&/rawat\s+inap/i.test(p[1])){let r=ut(p[1].trim()),d=p.slice(2).join(" - ").trim(),i=d?r+" - "+d:r;if(i)return[t,i]}return[t,s]}),gt=S.map(([t,e])=>'<div class="info-item"><div class="info-label">'+l(t)+'</div><div class="info-colon">:</div><div class="info-value">'+l(e)+"</div></div>").join(""),J=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+l(t)+"</strong>":l(t),V=t=>/^catatan/i.test(t.trim()),X=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),ft=S.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function Y(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(a=>{if(!a.ok)throw new Error("img "+a.status);return a.blob()}).then(a=>new Promise((s,p)=>{let r=new FileReader;r.onload=()=>s(String(r.result)),r.onerror=()=>p(r.error),r.readAsDataURL(a)})).catch(()=>e)}async function ht(){let[t,e]=await Promise.all([Y(M),P?Y(P):Promise.resolve("")]),a="";for(let i=0;i<S.length;i+=2){let o=S[i],n=S[i+1];a+="<tr><td>"+l(o[0])+"</td><td>:</td><td>"+l(o[1])+"</td>"+(n?"<td>"+l(n[0])+"</td><td>:</td><td>"+l(n[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let s="";for(let i of x){if(V(i.title)){let o=i.items.length?i.items:["Tidak ada"];s+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top"><b><u>CATATAN:</u></b></td><td>'+o.map(n=>"- "+l(X(n)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(i.bare){i.items.forEach((o,n)=>{s+='<p style="margin:'+(n===0?"12pt":"0")+' 0 6pt 0;font-size:11pt;"><b>'+l(o.toUpperCase())+"</b></p>"});continue}s+='<p style="margin:12pt 0 0 0;font-size:11pt;"><b><u>'+l(i.title.toUpperCase())+"</u></b></p>",i.items.forEach((o,n)=>{s+='<p style="margin:'+(i.para.includes(n)?"14pt":"0")+' 0 6pt 0;text-align:justify;">'+J(o)+"</p>"})}let p='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+l(H)+'</title></head><body style="font-family:Arial,sans-serif;font-size:11pt;"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+t+'" width="90"></td><td align="center">'+E.slice(0,3).map(i=>'<b style="font-size:16pt;">'+l(i)+"</b>").join("<br>")+'<br><span style="font-size:9pt;">'+j.map(i=>l(i)).join("<br>")+'</span></td></tr></table><hr><p align="center"><b><u>'+l(H.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2">'+a+"</table>"+s+'<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+l(K)+'</p><p style="margin:0 0 6pt 0;">'+l($)+"</p>"+(e?'<p style="margin:0 0 6pt 0;"><img src="'+e+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+l(W)+'</b></p><p style="margin:0 0 6pt 0;">'+l(Q)+"</p></td></tr></table></body></html>",r=new Blob(["\uFEFF"+p],{type:"application/msword"}),d=document.createElement("a");d.href=URL.createObjectURL(r),d.download="Hasil-PA-"+ft+".doc",document.body.appendChild(d),d.click(),window.setTimeout(()=>{URL.revokeObjectURL(d.href),d.remove()},4e3)}let bt=x.map(t=>{if(V(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(a=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+l(X(a)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+'">'+t.items.map((a,s)=>'<div class="item-list'+(t.para.includes(s)?" item-para":"")+'">'+J(a)+"</div>").join("")+"</div>";return t.bare?e:'<div class="section-judul">'+l(t.title)+"</div>"+e}).join("");document.body.innerHTML='<a href="'+l(G)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+l(M)+'" alt="Logo"></div><div class="kop-text">'+E.slice(0,3).map(t=>'<h1 class="kop-atas">'+l(t)+"</h1>").join("")+'<div class="kop-alamat">'+j.map(t=>l(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+l(H)+'</div><div class="patient-info-container">'+gt+'</div><div class="hasil-pa">'+bt+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+l(K)+"</p><p>"+l($)+"</p>"+(P?'<img src="'+l(P)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+l(W)+'</p><p style="margin-top: 2px;">'+l(Q)+"</p></div></div></div>",mt.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),ht().catch(()=>{window.location.href=G})}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let Z="ext-pa-print-style";if(!document.getElementById(Z)){let t=document.createElement("style");t.id=Z,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 9pt;
            color: #000;
            line-height: 1.4;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: 16pt;
            margin: 0;
            line-height: 1.2;
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: 7.5pt;
            margin-top: 5px;
            color: #334155;
            line-height: 1.3;
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: 12pt;
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 11pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 9pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.5;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: 10pt;
            line-height: 1;
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: 11pt;
        }

        .section-isi {
            font-size: 10pt;
            line-height: 1.5;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: 11pt;
            font-weight: bold;
            line-height: 1.4;
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: 10pt;
            line-height: 1.5;
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: 11pt;
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 6px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Cetak 16px khusus fitur PA (ramah lansia): blok ini SENGAJA
           paling akhir \u2014 rule dasar (10/11pt) di atasnya berspesifisitas
           sama sehingga hanya menang bila muncul belakangan. HANYA
           @media print: tampilan layar tidak berubah, fitur lain tak
           tersentuh (<style> ini hanya ada di halaman cetak PA). */
        @media print {
            .section-isi,
            .section-isi-bare,
            .section-catatan,
            .patient-info-container,
            .ttd-box {
                font-size: 16px;
            }

            .section-judul,
            .catatan-label {
                font-size: 13pt;
            }
        }
      `,document.head.appendChild(t)}}let f=Date.now(),k=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(k),g().catch(()=>{})):Date.now()-f>5e3&&window.clearInterval(k)},200)})})();
