"use strict";var __morbis_feature=(()=>{var j='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',P=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${j};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,y=null;function $(){return y||(y=new CSSStyleSheet,y.replaceSync(P)),y}var C=!1;function H(){if(C||document.getElementById("ext-pjs-font"))return;C=!0;let i=document.createElement("link");i.id="ext-pjs-font",i.rel="stylesheet",i.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(i)}function q(i,c="open"){let x=i.attachShadow({mode:c});return x.adoptedStyleSheets=[$()],H(),x}var R=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,F=class extends HTMLElement{constructor(){super();let i=q(this);i.innerHTML=`
      <style>${R}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=i.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",i=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){i.stopPropagation(),i.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(i){(i==="disabled"||i==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}};customElements.get("ext-btn")||customElements.define("ext-btn",F);var A="extensionConfig";function K(i,c,x){let g=c?.features?.[i];if(!g)return!0;if(g.enabled===!1)return!1;let v=x??c?.currentRole??"admin";if(v==="admin")return!0;let m=g.allowedRoles;return!Array.isArray(m)||m.length===0?!0:m.includes(v)}async function U(i){try{let c=(await chrome.storage.sync.get(A))?.[A]??null;return K(i,c)}catch{return!0}}function M(i,c){U(i).then(x=>{if(x)try{c()}catch(g){console.error(`[featureGate:${i}] gagal jalan:`,g)}})}M("labHistory",function(){let i=t=>document.querySelector(t),c=t=>i(t)?.value?.trim()||"",x=null;function g(){return{idLab:new URLSearchParams(window.location.search).get("id_lab")||c('input[name="id_lab"]'),idVisit:c('input[name="id_visit"]'),idHasilLab:c('input[name="hasil[1][id]"]')}}async function v(t,n){try{let e=((await(await fetch(`/admisi/pelaksanaan_pelayanan/laboratorium-data?id_visit=${n}`,{credentials:"same-origin"})).text()).match(/<tr[^>]*>[\s\S]*?<\/tr>/g)||[]).find(r=>r.includes(`nolab="${t}"`));if(!e)return null;let o=e.match(/cetakFormPermintaanLab\(\s*(\d+)/)?.[1]||null,d=e.match(/edit_tanggal\(\s*\d+\s*,\s*\d+\s*,\s*"([^"]+)"/)?.[1]||null;return o?{id:o,tgl:d}:null}catch{return null}}function m(t){window.open(t,"_blank")}let w=["dok_luar","nama_rs"],b={},k=null;function E(t){return t.toLowerCase().split(" ").map(n=>n&&n.charAt(0).toUpperCase()+n.slice(1)).join(" ")}function T(t){return document.querySelector(`[name="${t}"]`)}function z(t,n){let e=b[t];return e===void 0?(n&&(b[t]=n),!1):n===e?!1:n.toLowerCase()!==e.toLowerCase()?(b[t]=n,!1):n===E(e)?!0:(b[t]=n,!1)}function _(){try{for(let t of w){let n=T(t);n&&z(t,(n.value??"").trim())}}catch{}}function D(){try{for(let t of w){let n=T(t);n&&z(t,(n.value??"").trim())&&(n.value=b[t],window.console.info("[paKeepCase] "+t+" dikembalikan ke ejaan asli"))}}catch{}}function I(){let t=window.XMLHttpRequest.prototype;if(t.__extKeepPatched)return;t.__extKeepPatched=!0;let n=t.open,e=t.send;t.open=function(...o){try{let d=o[1];this.__extUrl=typeof d=="string"?d:String(d)}catch{}return n.apply(this,o)},t.send=function(...o){try{let d=this,r=o[0],l=d.__extUrl;if(Object.keys(b).length&&typeof l=="string"&&l.includes("pemeriksaan-pa")&&typeof r=="string"&&r.includes("dok_luar=")){let s=new URLSearchParams(r),u=!1;for(let a of w){let p=b[a],f=s.get(a);p&&f!==null&&f!==p&&f===E(p)&&(s.set(a,p),u=!0)}if(u)return window.console.info("[paKeepCase] payload dok_luar/nama_rs dikembalikan ke ejaan asli"),e.call(this,s.toString())}else if(Object.keys(b).length&&typeof l=="string"&&l.includes("pemeriksaan-pa")&&typeof FormData<"u"&&r instanceof FormData&&(r.has("dok_luar")||r.has("nama_rs")))for(let s of w){let u=b[s],a=r.get(s);u&&typeof a=="string"&&a!==u&&a===E(u)&&(window.console.info("[paKeepCase] payload FormData "+s+" dikembalikan"),r.set(s,u))}}catch{}return e.apply(this,o)}}function V(){let t=window;t.__paKeepCase||(t.__paKeepCase=!0,_(),document.addEventListener("input",n=>{let e=n.target;e&&typeof e.matches=="function"&&e.matches("input, textarea, select")&&_()},!0),document.addEventListener("focusout",()=>_(),!0),document.addEventListener("submit",()=>_(),!0),I(),k=window.setInterval(D,300),window.console.info("[paKeepCase] aktif di input-hasil-pa"))}function B(t,n){let e=document.createElement("div");e.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:999999;display:flex;align-items:center;justify-content:center;";let o=document.createElement("div");o.style.cssText="background:#fff;border-radius:8px;padding:16px 18px;min-width:340px;box-shadow:0 8px 30px rgba(0,0,0,.25);font-family:Arial,sans-serif;";let d=document.createElement("div");d.textContent="Edit Tanggal Pengajuan",d.style.cssText="font-weight:700;font-size:14px;margin-bottom:10px;color:#1e293b;";let r=document.createElement("input");r.type="date",r.style.cssText="width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:6px;font-size:13px;padding:10px;";let l=x?.match(/^(\d{2})\/(\d{2})\/(\d{4})/);l&&(r.value=`${l[3]}-${l[2]}-${l[1]}`);let s=document.createElement("div");s.textContent="Server menerima dd/mm/yyyy hh:mm:ss \u2014 waktu diset otomatis ke 00:00:00.",s.style.cssText="font-size:11px;color:#64748b;margin:4px 0 12px;";let u=document.createElement("div");u.style.cssText="display:flex;justify-content:flex-end;";let a=document.createElement("button");a.type="button",a.textContent="Edit Tanggal",a.style.cssText="margin:18px;padding:15px;border:none;border-radius:6px;font-size:12px;font-weight:600;color:#fff;background:#2563eb;cursor:pointer;";let p=document.createElement("button");p.type="button",p.textContent="Batal",p.style.cssText="margin:18px;padding:15px;border:none;border-radius:6px;font-size:12px;font-weight:600;color:#fff;background:#dc2626;cursor:pointer;",a.addEventListener("click",async()=>{let f=r.value.trim();if(!f){alert("Isi tanggal pengajuan baru dulu.");return}let[h,J,Y]=f.split("-"),W=`${Y}/${J}/${h} 00:00:00`;a.disabled=!0,a.textContent="Menyimpan\u2026";let S;try{S=(await(await fetch("/laboratorium/control/edit_tanggal",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:new URLSearchParams({lab:t,id_visit:n,date:W,action:"edit"}).toString()})).json()).status==1}catch{S=!1}e.remove(),alert(S?"Edit Tanggal Pengajuan berhasil diubah.":"Gagal menyimpan tanggal baru."),S&&window.location.reload()}),p.addEventListener("click",()=>e.remove()),e.addEventListener("click",f=>{f.target===e&&e.remove()}),u.append(a,p),o.append(d,r,s,u),e.appendChild(o),document.body.appendChild(e),r.focus()}function O(){let t=Array.from(document.querySelectorAll("fieldset")).find(a=>a.textContent?.includes("Data Pasien"));if(!t)return;let n=document.querySelector("[data-ext-lab-actions]");n&&n.remove();let{idLab:e,idVisit:o,idHasilLab:d}=g();if(!e||!o||!d){console.warn("[inputHasilPa] Missing ids",{idLab:e,idVisit:o,idHasilLab:d});return}let r=document.createElement("div");r.setAttribute("data-ext-lab-actions","true"),r.style.cssText="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0;";let l=(a,p,f)=>{let h=document.createElement("ext-btn");return h.setAttribute("variant",p),h.setAttribute("size","sm"),h.textContent=a,h.addEventListener("click",f),h},s=d;v(e,o).then(a=>{a?(s=a.id,x=a.tgl,console.log("[inputHasilPa] permintaan data",{idLab:e,idVisit:o,id:a.id,tgl:a.tgl})):console.warn("[inputHasilPa] Baris lab tidak ditemukan di daftar, pakai hasil[1][id].",{idLab:e,idVisit:o})}),r.append(l("Edit Tanggal Pengajuan","primary",()=>B(e,o)),l("Cetak","info",()=>m(`/laboratorium/print/hasil-lab?id=${e}&nolab=${e}`)),l("Cetak Form Permintaan Lab","secondary",()=>m(`/admisi/formulir-permintaan-labor/cetak?id=${s}&id_visit=${o}&jenis=cetak`)),l("Edit Form Permintaan Lab","secondary",()=>m(`/admisi/formulir-permintaan-labor/form?id=${s}&id_visit=undefined&jenis=edit`)),l("Halaman Asli Pengajuan Lab","ghost",()=>m(`/admisi/pelaksanaan_pelayanan/laboratorium-data?id_visit=${o}`)));let u=Array.from(document.querySelectorAll("fieldset")).find(a=>a.textContent?.includes("Tanggal Hasil"));if(u)u.after(r);else{let a=document.querySelector("form");a?a.appendChild(r):t.after(r)}}function L(){document.documentElement.getAttribute("data-ext-lab-history")&&(V(),O())}let X=performance.now();(function t(){document.documentElement.getAttribute("data-ext-lab-history")?L():performance.now()-X<5e3&&setTimeout(t,200)})();let G=history.pushState;history.pushState=function(...t){G.apply(this,t),setTimeout(L,100)},window.addEventListener("popstate",()=>setTimeout(L,100)),window.addEventListener("pagehide",()=>{k!==null&&(clearInterval(k),k=null)})})})();
