"use strict";var __morbis_feature=(()=>{var J="extensionConfig";function bt(p,n,g){let h=n?.features?.[p];if(!h)return!0;if(h.enabled===!1)return!1;let x=g??n?.currentRole??"admin";if(x==="admin")return!0;let w=h.allowedRoles;return!Array.isArray(w)||w.length===0?!0:w.includes(x)}async function xt(p){try{let n=(await chrome.storage.sync.get(J))?.[J]??null;return bt(p,n)}catch{return!0}}function yt(p,n){xt(p).then(g=>{if(g)try{n()}catch(h){console.error(`[featureGate:${p}] gagal jalan:`,h)}})}var W="ext-free-text-noop",vt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function wt(p){try{let n=p.toUpper;if(typeof n=="function"&&n[W]===!0)return!0;let g=function(h){return h?.value??""};g[W]=!0;try{Object.defineProperty(p,"toUpper",{value:g,writable:!0,configurable:!0})}catch{p.toUpper=g}return!0}catch{return!1}}var $="ext-pa-typo",kt=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi"},{key:"ttd",label:"TTD"}],C={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},Q=4,V=24,jt=1,At=2.5;function X(p,n,g,h){let x=typeof p=="number"?p:Number(p);return Number.isFinite(x)?Math.min(h,Math.max(g,x)):n}function L(p,n){let g=p??{};return{fs:X(g.fs,n.fs,Q,V),lh:X(g.lh,n.lh,jt,At)}}function I(p){let n=p??{};return{kop:L(n.kop,C.kop),pasien:L(n.pasien,C.pasien),judul:L(n.judul,C.judul),isi:L(n.isi,C.isi),ttd:L(n.ttd,C.ttd)}}function N(){return I(null)}function Z(p){try{if(!p)return N();let n=p.getItem($);return n?I(JSON.parse(n)):N()}catch{return N()}}function St(p,n){try{return p?(p.setItem($,JSON.stringify(I(n))),!0):!1}catch{return!1}}function Et(p){try{p?.removeItem($)}catch{}}function Y(p){let n=I(p),g=h=>Math.min(V,Math.max(Q,h));return{...n,alamatFs:g(n.kop.fs-8.5),judulLapFs:g(n.kop.fs-4)}}var b=p=>String(Math.round(p*100)/100);function Ct(p){let n=Y(p);return{"--pa-kop-fs":`${b(n.kop.fs)}pt`,"--pa-kop-lh":b(n.kop.lh),"--pa-alamat-fs":`${b(n.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(n.judulLapFs)}pt`,"--pa-pasien-fs":`${b(n.pasien.fs)}pt`,"--pa-pasien-lh":b(n.pasien.lh),"--pa-judul-fs":`${b(n.judul.fs)}pt`,"--pa-judul-lh":b(n.judul.lh),"--pa-isi-fs":`${b(n.isi.fs)}pt`,"--pa-isi-lh":b(n.isi.lh),"--pa-ttd-fs":`${b(n.ttd.fs)}pt`,"--pa-ttd-lh":b(n.ttd.lh)}}function Lt(p,n){if(p)try{for(let[g,h]of Object.entries(Ct(n)))p.setProperty(g,h)}catch{}}yt("paLabPrint",function(){"use strict";function p(){try{wt(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let x=document.createElement("style");x.id="ext-free-text-style",x.textContent=vt,document.head.appendChild(x)}}catch{}}if(p(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",p),window.setInterval(p,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function n(){let x="ext-pa-print-proc";if(document.documentElement.getAttribute(x))return;document.documentElement.setAttribute(x,"1");let w=()=>{try{return window.localStorage??null}catch{return null}},k=Z(w()),_=()=>{try{Lt(document.documentElement.style,k)}catch{}};_();let v=t=>q(t?.textContent||"");function tt(t){return t.replace(/<[^>]+>/g," ")}function zt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function q(t){return zt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let et=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",P=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>v(t)).filter(Boolean);for(;P.length<3;)P.push("");let z=[],at=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(at){let t=document.createElement("div");t.innerHTML=at.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),z=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let F=z.join(" "),it=t=>{let e=F.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},nt=it("telp"),rt=it("fax"),M=(F.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],U=(F.match(/https?:\/\/[^\s;,]+/)||[""])[0],A=F.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");M&&(A=A.split(M).join("")),U&&(A=A.split(U).join("")),A=A.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Tt=["Alamat: "+A,nt?"Telp: "+nt:"",rt?"Fax: "+rt:""].filter(Boolean).join(", "),Rt=[M?"Email: "+M:"",U?"Website: "+U:""].filter(Boolean).join(", ");z=[Tt,Rt].filter(Boolean);let K=v(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",H=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let i=v(e[0]),r=v(e[2]),l=v(e[3]),s=v(e[5]);i&&H.push([i,r]),l&&H.push([l,s])}});let S=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],y=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),j=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",i=!1,r=t.querySelector(".section-title");if(r)e=v(r),i=!0;else{let c=u=>u.split(":")[0].trim();for(let u of Array.from(t.children).slice(0,3)){let m=v(u);if(m&&m.length<=24&&S.includes(y(c(m)))){e=c(m);break}}if(!e){let u=(t.textContent||"").split(`
`).map(m=>m.trim()).find(Boolean)||"";u&&S.includes(y(c(u)))&&(e=c(u))}if(!e)return}let l=document.createElement("div");l.innerHTML=t.innerHTML,l.querySelector(".section-title")?.remove();let s=l.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(c=>c.split(/<br\s*\/?>|\n/).map(u=>q(u.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(c=>c.length),f=[],a=[];s.forEach((c,u)=>{c.forEach((m,R)=>{u>0&&R===0&&f.length&&a.push(f.length),f.push(m)})});let o=f;if(!i&&o.length&&y(o[0])===y(e)){o.shift();for(let c=0;c<a.length;c++)a[c]-=1;for(;a.length&&a[0]<=0;)a.shift()}o.length>1&&!/^[IVXLC]+\.\s/.test(o[0])&&o.slice(1).some(c=>/^II\.\s/.test(c))&&(o[0]="I. "+o[0]),e&&j.push({title:e,items:o,para:a})});let It=/^catatan\s*:?/i,qt=/^icd[\s-]*o\b\s*:?/i,G=[];for(let t of j){let e=[{title:t.title,items:[],para:[]}],i=e[0],r=!1,l=(s,f)=>{i={title:s,items:[],para:[],bare:f},e.push(i),r=!0};if(t.items.forEach((s,f)=>{let a=s.match(It),o=a?null:s.match(qt);if(a){y(i.title)!=="catatan"&&l("Catatan");let c=s.slice(a[0].length).trim();c&&(t.para.includes(f)&&i.para.push(i.items.length),i.items.push(c));return}if(o){y(i.title)!=="icdo"&&l("ICD-0",!0),t.para.includes(f)&&i.para.push(i.items.length),i.items.push(s);return}t.para.includes(f)&&i.para.push(i.items.length),i.items.push(s)}),r)for(let s of e)s.items.length&&G.push(s);else G.push(e[0])}j.length=0,j.push(...G),j.forEach((t,e)=>t._i=e),j.sort((t,e)=>{let i=t._i??0,r=e._i??0,l=S.indexOf(y(t.title)),s=S.indexOf(y(e.title)),f=l===-1?S.length:l,a=s===-1?S.length:s;return f!==a?f-a:i-r});function Pt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let i=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),r=t.getAttribute("placeholder")||"",l=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(i+" "+r+" "+l).slice(0,300)}}function Ft(t,e,i){let r=e.toLowerCase().split(/[^a-z0-9]+/).filter(a=>a.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(a));if(!r.length)return"";let l=r.sort((a,o)=>o.length-a.length)[0],s="",f=-1;return t.querySelectorAll("input, textarea, select").forEach(a=>{let{val:o,ctx:c}=Pt(a);if(!o||o===e||!o.toLowerCase().includes(l))return;let u=i.test(c)?2:0;u>f&&(f=u,s=o)}),s}function Mt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Ut(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let i=a=>/ket\w*\s*klinis/i.test(a),r=a=>/^dokter/i.test(a)||/^rs\b/i.test(a),l=t.map(([a,o],c)=>({label:a,value:o,idx:c})).filter(a=>r(a.label)?!!a.value:i(a.label));if(!l.length)return;let s=new AbortController,f=window.setTimeout(()=>s.abort(),6e3);try{let a=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),o=await fetch(a.toString(),{credentials:"same-origin",signal:s.signal});if(!o.ok){window.console.info("[paPrint] override: fetch input status "+o.status);return}let c=await o.text(),u=new DOMParser().parseFromString(c,"text/html");window.console.info('[paPrint] override: input title="'+(u.title||"").slice(0,60)+'" len='+c.length+" fields="+u.querySelectorAll("input, textarea, select").length);for(let m of l){if(i(m.label)){let Kt=Mt(u,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),O=q(tt(Kt));window.console.info("[paPrint] override: "+m.label+' cetak="'+m.value+'" input="'+O+'"'),O&&O!==m.value&&(t[m.idx][1]=O);continue}let R=/^dokter/i.test(m.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,_t=Ft(u,m.value,R),D=q(tt(_t||""));window.console.info("[paPrint] override: "+m.label+' cetak="'+m.value+'" input="'+D+'"'),D&&D!==m.value&&(t[m.idx][1]=D)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(f)}}await Ut(H).catch(()=>{});let E=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>v(t)).filter(Boolean),ot=E[0]||"",lt=E[1]||"",B=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",st=E.find(t=>/^\(.*\)$/.test(t))||E[2]||"",pt=E.find(t=>/^nip\.?/i.test(t))||E[3]||"",dt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Ht=Array.from(document.body.querySelectorAll("script")),Bt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),T=H.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let i=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,r=i.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||i,l=r.split(/\s+-\s*/);if(l.length>=3&&/rawat\s+inap/i.test(l[1])){let s=Bt(l[1].trim()),f=l.slice(2).join(" - ").trim(),a=f?s+" - "+f:s;if(a)return[t,a]}return[t,r]}),Dt=T.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),ct=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),ut=t=>/^catatan/i.test(t.trim()),ft=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),Ot=T.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function mt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(i=>{if(!i.ok)throw new Error("img "+i.status);return i.blob()}).then(i=>new Promise((r,l)=>{let s=new FileReader;s.onload=()=>r(String(s.result)),s.onerror=()=>l(s.error),s.readAsDataURL(i)})).catch(()=>e)}async function $t(){let t=Y(k),[e,i]=await Promise.all([mt(et),B?mt(B):Promise.resolve("")]),r="";for(let o=0;o<T.length;o+=2){let c=T[o],u=T[o+1];r+="<tr><td>"+d(c[0])+"</td><td>:</td><td>"+d(c[1])+"</td>"+(u?"<td>"+d(u[0])+"</td><td>:</td><td>"+d(u[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let l="";for(let o of j){if(ut(o.title)){let u=o.items.length?o.items:["Tidak ada"];l+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.judul.fs+'pt"><b><u>CATATAN:</u></b></td><td>'+u.map(m=>"- "+d(ft(m)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(o.bare){o.items.forEach((u,m)=>{l+='<p style="margin:'+(m===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.judul.fs+'pt;"><b>'+d(u.toUpperCase())+"</b></p>"});continue}l+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b><u>'+d(o.title.toUpperCase())+"</u></b></p>";let c=y(o.title)==="kesimpulan";o.items.forEach((u,m)=>{let R=c?"<b>"+d(u)+"</b>":ct(u);l+='<p style="margin:'+(o.para.includes(m)?"14pt":"0")+' 0 6pt 0;text-align:justify;">'+R+"</p>"})}let s='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(K)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+P.slice(0,3).map(o=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(o)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+z.map(o=>d(o)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(K.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+r+"</table>"+l+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(ot)+'</p><p style="margin:0 0 6pt 0;">'+d(lt)+"</p>"+(i?'<p style="margin:0 0 6pt 0;"><img src="'+i+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(st)+'</b></p><p style="margin:0 0 6pt 0;">'+d(pt)+"</p></td></tr></table></body></html>",f=new Blob(["\uFEFF"+s],{type:"application/msword"}),a=document.createElement("a");a.href=URL.createObjectURL(f),a.download="Hasil-PA-"+Ot+".doc",document.body.appendChild(a),a.click(),window.setTimeout(()=>{URL.revokeObjectURL(a.href),a.remove()},4e3)}let Nt=j.map(t=>{if(ut(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(r=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+d(ft(r)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=y(t.title)==="kesimpulan",i='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+'">'+t.items.map((r,l)=>'<div class="item-list'+(t.para.includes(l)?" item-para":"")+'">'+(e?"<strong>"+d(r)+"</strong>":ct(r))+"</div>").join("")+"</div>";return t.bare?i:'<div class="section-judul">'+d(t.title)+"</div>"+i}).join("");document.body.innerHTML='<a href="'+d(dt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(et)+'" alt="Logo"></div><div class="kop-text">'+P.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+z.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(K)+'</div><div class="patient-info-container">'+Dt+'</div><div class="hasil-pa">'+Nt+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(ot)+"</p><p>"+d(lt)+"</p>"+(B?'<img src="'+d(B)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(st)+'</p><p style="margin-top: 2px;">'+d(pt)+"</p></div></div></div>",Ht.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),$t().catch(()=>{window.location.href=dt})});let gt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(r,l,s,f,a,o,c,u)=>"<label>"+d(s)+'<input type="range" data-g="'+d(r)+'" data-f="'+l+'" min="'+f+'" max="'+a+'" step="'+o+'" value="'+c+'"><output data-o="'+d(r+"-"+l)+'">'+d(String(c)+u)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+kt.map(r=>'<div class="t-typo-group"><strong>'+d(r.label)+'</strong><div class="t-typo-row">'+e(r.key,"fs","Font (pt)",4,20,.5,k[r.key].fs,"pt")+e(r.key,"lh","Spasi baris",1,2.5,.05,k[r.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(r=>{let l=r;l.addEventListener("input",()=>{let s=l.dataset.g,f=l.dataset.f;if(!s||!f||!k[s])return;k[s][f]=Number(l.value),_();let a=t.querySelector(`output[data-o="${s}-${f}"]`);a&&(a.textContent=l.value+(f==="fs"?"pt":""))})});let i=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let r=St(w(),k);i&&(i.textContent=r?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Et(w()),k=Z(w()),_(),gt(),i){let r=t.querySelector("[data-note]");r&&(r.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&gt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let ht="ext-pa-print-style";if(!document.getElementById(ht)){let t=document.createElement("style");t.id=ht,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-judul-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let g=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),n().catch(()=>{})):Date.now()-g>5e3&&window.clearInterval(h)},200)})})();
