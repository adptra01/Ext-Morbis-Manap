"use strict";var __morbis_feature=(()=>{var A=Object.defineProperty,Y=Object.getOwnPropertyDescriptor,Z=Object.getOwnPropertyNames,ee=Object.prototype.hasOwnProperty,te=(e,t)=>{for(var a in t)A(e,a,{get:t[a],enumerable:!0})},ae=(e,t,a,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of Z(t))!ee.call(e,r)&&r!==a&&A(e,r,{get:()=>t[r],enumerable:!(n=Y(t,r))||n.enumerable});return e},ne=e=>ae(A({},"__esModule",{value:!0}),e),P={};te(P,{applySelectAll:()=>O,clearSelection:()=>y,getSelected:()=>U,initMKlaimBulkVerifFeature:()=>W,isEligible:()=>H,parseIdVisit:()=>oe,pruneSelection:()=>V});function re(){return window}var _="ext-batch-shared-style";function N(){if(document.getElementById(_))return;let e=document.createElement("style");e.id=_,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }
    .ext-status-badge[data-status="warning"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function ie(e,t,a=2){let n=r=>fetch(e,t).catch(i=>{if(r<=0)throw i;return new Promise(o=>setTimeout(o,1e3*(3-r))).then(()=>n(r-1))});return n(a)}function B(e){return new Promise(t=>{N();let a=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",n=document.createElement("div");n.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",n.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${a}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,n.querySelector("h3").textContent=e.title;let r=n.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((s,c)=>{c>0&&r.appendChild(document.createElement("br")),r.appendChild(document.createTextNode(s))});let i=s=>{n.remove(),document.removeEventListener("keydown",o),t(s)},o=s=>{s.key==="Escape"&&i(!1)};n.querySelector(".ext-modal-close").addEventListener("click",()=>i(!1)),n.addEventListener("click",s=>{s.target===n&&i(!1)}),n.querySelector("[data-ext-ok]").addEventListener("click",()=>i(!0));let d=n.querySelector("[data-ext-cancel]");d&&d.addEventListener("click",()=>i(!1)),document.addEventListener("keydown",o),document.body.appendChild(n)})}var J=re(),l={endpointVerif:"/v2/m-klaim/control/verif",endpointBatal:"/v2/m-klaim/control/batal-verif",delayMs:600,barId:"ext-bulk-verif-bar",cssId:"ext-bulk-verif-style",readyTimeoutMs:15e3,readyPollMs:250,warnIfMoreThan:100,UJI_SAJA:!1},b=[{sel:"#data-table",kind:"main",nama:"Klaim",aksi:"Verif",endpoint:l.endpointVerif,danger:!1},{sel:"#data-table-verif",kind:"verif",nama:"Sudah Terverifikasi",aksi:"Batal Verif",endpoint:l.endpointBatal,danger:!0}],f={main:new Set,verif:new Set},p=!1;function O(e,t,a){let n=0;return t.forEach(r=>{!r.id||!r.eligible||(a?f[e].add(r.id):f[e].delete(r.id),n+=1)}),n}function V(e,t){let a=new Set;t.forEach(r=>{r.id&&r.eligible&&a.add(r.id)});let n=0;return Array.from(f[e]).forEach(r=>{a.has(r)||(f[e].delete(r),n+=1)}),n}function U(e){return Array.from(f[e])}function y(e){f[e].clear()}function oe(e){let t=e.match(/\d+/);return t?t[0]:null}function H(e,t,a){return t?e==="main"?!0:a:!1}function le(){if(document.getElementById(l.cssId))return;let e=document.createElement("style");e.id=l.cssId,e.textContent=`
    #${l.barId} {
      position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
      z-index: 2147482000; display: none; align-items: center; gap: 14px;
      background: #0f172a; color: #f8fafc; border-radius: 12px;
      padding: 10px 16px; font-family: 'Inter', system-ui, sans-serif;
      font-size: 13px; box-shadow: 0 8px 28px rgba(15,23,42,.35);
    }
    #${l.barId} .bv-item { display: flex; align-items: center; gap: 8px; }
    #${l.barId} .bv-label { color: #cbd5e1; }
    #${l.barId} .bv-count { color: #f8fafc; font-weight: 700; }
    #${l.barId} button {
      border: none; border-radius: 8px; cursor: pointer; padding: 7px 14px;
      font-size: 12.5px; font-weight: 700; font-family: inherit;
    }
    #${l.barId} .bv-aksi { background: #2563eb; color: #fff; }
    #${l.barId} .bv-aksi:hover { background: #1d4ed8; }
    #${l.barId} .bv-aksi-danger { background: #dc2626; color: #fff; }
    #${l.barId} .bv-aksi-danger:hover { background: #b91c1c; }
    #${l.barId} .bv-reset { background: #334155; color: #e2e8f0; }
    #${l.barId} .bv-reset:hover { background: #475569; }
    #${l.barId} button:disabled { opacity: .55; cursor: not-allowed; }

    /* Status + progress saat proses massal berjalan */
    #${l.barId} .bv-status { color: #f8fafc; font-weight: 700; min-width: 150px; }
    #${l.barId} .bv-progress {
      position: relative; width: 220px; height: 9px; border-radius: 999px;
      background: #1e293b; overflow: hidden; flex: 0 0 auto;
    }
    #${l.barId} .bv-progress > i {
      position: absolute; top: 0; left: 0; bottom: 0; width: 0%;
      border-radius: 999px; background: linear-gradient(90deg, #2563eb, #38bdf8);
      transition: width .25s ease;
    }
    #${l.barId} .bv-progress.done > i {
      background: linear-gradient(90deg, #16a34a, #4ade80);
    }

    .bv-check {
      display: inline-flex; align-items: center; justify-content: center;
      margin-right: 6px; vertical-align: middle; cursor: pointer;
    }
    /* Kolom khusus checkbox: <th> sendiri di posisi 0 + <td> sejajar di tiap
       baris. <th> HANYA ditambahkan setelah DataTables aktif (lihat
       renderHeaderCheckbox) supaya jumlah kolom yang dibaca saat init tetap
       16 dan pemetaan data ajax tidak bergeser. */
    th.bv-sel-th {
      width: 30px; min-width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
      /* Kolom terkunci (freeze pane): tetap terlihat saat tabel digeser
         horizontal (kontainer scroll: .main overflow-x auto di halaman). */
      position: -webkit-sticky; position: sticky; left: 0; z-index: 11;
      box-shadow: 2px 0 3px rgba(15, 23, 42, .10);
    }
    th.bv-sel-th input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    th.bv-sel-th input:disabled { cursor: not-allowed; }
    td.bv-sel {
      width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
      position: -webkit-sticky; position: sticky; left: 0; z-index: 9;
    }
    .table-hover tbody tr:hover > td.bv-sel,
    tbody tr:hover > td.bv-sel { background: #eef2f7; }
    td.bv-sel input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    td.bv-sel input:disabled { cursor: not-allowed; }
    /* Penanda fitur aktif - memudahkan diagnosis di console */
    html[data-ext-bulk-verif='1'] td.bv-sel { background: #eff6ff; }
  `,document.head.appendChild(e),N()}function u(e){return document.querySelector(e.sel)}function T(e){let t=window.jQuery;if(!t)return null;try{return t(e.sel).DataTable()??null}catch{return null}}function K(e){return(Array.isArray(e)?e:[e]).filter(t=>t instanceof HTMLElement)}function C(e){let t=e.querySelector('[onclick*="detail("]');if(t){let n=(t.getAttribute("onclick")||"").match(/\d+/);if(n)return n[0]}let a=e.querySelector('[onclick*="BatalVerif("]');if(a){let n=(a.getAttribute("onclick")||"").match(/\d+/);if(n)return n[0]}return null}function M(e,t){return H(e.kind,!!t.querySelector('button[onclick*="detail("]'),!!t.querySelector('button[onclick*="BatalVerif("]'))}function D(e,t){return{id:C(t),eligible:M(e,t)}}function G(e){let t=u(e);if(!t)return[];let a=T(e);if(a)try{return K(a.rows({search:"applied"}).nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(n=>!n.classList.contains("dataTables_empty"))}function de(e){let t=u(e);if(!t)return[];let a=T(e);if(a)try{return K(a.rows().nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(n=>!n.classList.contains("dataTables_empty"))}function se(e,t){let a=C(t);if(!a){let o=document.createElement("td");o.className="bv-sel",o.dataset.extBvUnid="1";let d=document.createElement("input");d.type="checkbox",d.disabled=!0,d.title="id_visit tidak terbaca dari markup baris ini",o.appendChild(d),t.insertBefore(o,t.firstChild);return}let n=M(e,t),r=document.createElement("td");r.className="bv-sel";let i=document.createElement("input");i.type="checkbox",i.dataset.extBvId=a,i.checked=f[e.kind].has(a),l.UJI_SAJA?(i.disabled=!0,i.title="Mode uji - belum bisa dipilih"):(i.disabled=p||!n,i.title=p?"Sedang diproses...":n?"Pilih baris ini":"Baris tidak memenuhi syarat aksi ini",i.addEventListener("change",()=>{i.checked?f[e.kind].add(a):f[e.kind].delete(a),k(),x(e)})),r.appendChild(i),t.insertBefore(r,t.firstChild)}function ce(e){e.querySelectorAll("tbody td.bv-sel").forEach(t=>t.remove())}function R(e){let t=u(e);t&&(ce(t),t.querySelectorAll("tbody tr").forEach(a=>se(e,a)),x(e))}function x(e){let t=u(e)?.querySelector("thead input[data-ext-bv-header]");if(!t)return;let a=G(e).filter(i=>M(e,i)),n=a.length,r=a.filter(i=>{let o=C(i);return!!o&&f[e.kind].has(o)}).length;t.disabled=l.UJI_SAJA||p||n===0,t.checked=n>0&&r===n,t.indeterminate=r>0&&r<n}function ue(e){if(!e)return!1;try{if(window.jQuery?.fn?.DataTable?.isDataTable?.(e))return!0}catch{}return e.classList.contains("dataTable")}function Q(e){let t=u(e);if(!ue(t))return;let a=t?.querySelector("thead tr");if(!a)return;if(a.querySelector('th[data-ext-bv-header="1"]')){x(e);return}let n=document.createElement("th");n.className="bv-sel-th",n.dataset.extBvHeader="1",n.title="Pilih / batal pilih semua baris yang cocok dengan pencarian";let r=document.createElement("input");r.type="checkbox",r.dataset.extBvHeader="1",r.disabled=!0,l.UJI_SAJA?r.title="Mode uji - belum bisa dipilih":(r.title="Pilih semua hasil pencarian",r.addEventListener("change",()=>{let i=G(e).map(o=>D(e,o));O(e.kind,i,r.checked),R(e),k()})),n.appendChild(r),a.insertBefore(n,a.firstChild),l.UJI_SAJA?r.disabled=!0:x(e)}function L(){b.forEach(S),k()}function v(){return document.getElementById(l.barId)}function j(e,t,a,n,r,i=!1){let o=v();if(!o)return;let d=a>0?Math.min(100,Math.round(t/a*100)):0;o.innerHTML="";let s=document.createElement("div");s.className="bv-item";let c=document.createElement("span");c.className="bv-status",c.textContent=i?`Selesai - ${e.nama}`:`${e.nama}: ${t}/${a}`;let m=document.createElement("div");m.className=i?"bv-progress done":"bv-progress";let $=document.createElement("i");$.style.width=`${d}%`,m.appendChild($);let I=document.createElement("span");I.className="bv-label",i?I.textContent=r>0?`OK ${n} \xB7 Gagal ${r}`:`OK ${n} dari ${a}`:I.textContent=r>0?`OK ${n} \xB7 Gagal ${r}`:`OK ${n}`,s.append(c,m,I),o.appendChild(s),o.style.display="flex"}function k(){let e=v();if(!e)return;let t=b.map(n=>[n,f[n.kind].size]).filter(([,n])=>n>0);if(l.UJI_SAJA||t.length===0){e.style.display="none";return}if(p)return;e.innerHTML="",t.forEach(([n,r])=>{let i=document.createElement("div");i.className="bv-item";let o=document.createElement("span");o.className="bv-label",o.textContent=`${n.nama}: `;let d=document.createElement("span");d.className="bv-count",d.textContent=`${r} dipilih`;let s=document.createElement("button");s.className=n.danger?"bv-aksi bv-aksi-danger":"bv-aksi",s.textContent=n.aksi,s.addEventListener("click",()=>{he(n)}),i.append(o,d,s),e.appendChild(i)});let a=document.createElement("button");a.className="bv-reset",a.textContent="Batal Pilih",a.addEventListener("click",()=>{b.forEach(n=>y(n.kind)),L()}),e.appendChild(a),e.style.display="flex"}function be(){if(v())return;let e=document.createElement("div");e.id=l.barId,e.style.display="none",document.body.appendChild(e)}async function fe(e,t){try{let a=new URLSearchParams({id_visit:t}),n=await ie(e,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:a.toString(),credentials:"same-origin"});if(!n.ok)return{id:t,ok:!1,pesan:`HTTP ${n.status}`};let r=await n.json(),i=String(r.kode)==="200";return{id:t,ok:i,pesan:r.message??(i?"Sukses":"Gagal")}}catch(a){return{id:t,ok:!1,pesan:a.message||"Gagal koneksi"}}}function pe(e){let t=de(e).map(n=>D(e,n)),a=V(e.kind,t);return{valid:U(e.kind),gugur:a}}async function he(e){if(p)return;let{valid:t,gugur:a}=pe(e);if(t.length===0){y(e.kind),L(),await B({title:"Tidak ada baris yang bisa diproses",message:"Pilihan tidak lagi cocok dengan data di tabel. Silakan pilih ulang.",okLabel:"Mengerti",hideCancel:!0});return}let n=Math.ceil(t.length*l.delayMs/1e3),r=[`${e.nama}: ${t.length} baris akan diproses.`];if(a>0&&r.push(`${a} pilihan diabaikan (data berubah/tidak memenuhi syarat).`),r.push(e.danger?"Verifikasi yang dibatalkan kembali ke daftar belum terverifikasi.":"Data yang tidak memenuhi syarat akan ditolak server."),t.length>l.warnIfMoreThan&&r.push(`PERINGATAN: jumlah besar, proses \xB1${n} detik. Jangan tutup halaman.`),r.push("Lanjutkan?"),!await B({title:`${e.aksi} ${t.length} data?`,message:r.join(`
`),variant:e.danger?"danger":"primary",okLabel:`Ya, ${e.aksi}`,cancelLabel:"Batal"}))return;p=!0,b.forEach(c=>x(c)),j(e,0,t.length,0,0);let i=[],o=0;for(let c=0;c<t.length;c+=1){let m=await fe(e.endpoint,t[c]);m.ok?o+=1:i.push(m),j(e,c+1,t.length,o,i.length),c<t.length-1&&await new Promise($=>setTimeout($,l.delayMs))}p=!1,y(e.kind),j(e,t.length,t.length,o,i.length,!0),await new Promise(c=>setTimeout(c,700));let d=[`${e.aksi} selesai.`,`Berhasil: ${o} dari ${t.length}`];i.length>0&&(d.push("",`Gagal: ${i.length}`),i.slice(0,10).forEach(c=>d.push(`#${c.id} - ${c.pesan}`)),i.length>10&&d.push(`... dan ${i.length-10} lainnya`));let s=v();s&&(s.style.display="none"),await B({title:"Hasil",message:d.join(`
`),okLabel:"Muat ulang tabel",hideCancel:!0}),we(),window.location.reload()}function me(){return new Promise(e=>{let t=Date.now(),a=()=>{if(b.some(n=>u(n))||Date.now()-t>l.readyTimeoutMs){e();return}setTimeout(a,l.readyPollMs)};a()})}var h=!1,w=[],E=new Map;function xe(){w.forEach(e=>e.disconnect()),w.length=0,E.clear()}function g(e){if(!h){h=!0;try{Q(e),R(e),k()}finally{h=!1}}}function X(e){let t=e.querySelectorAll("tbody tr").length;return t===0||e.querySelectorAll("tbody td.bv-sel").length===t}function ge(e,t){let a=new MutationObserver(()=>{if(h)return;let r=u(e);if(r){if(r!==t){S(e);return}X(r)||g(e)}});a.observe(t,{childList:!0,subtree:!0}),w.push(a);let n=t.parentElement;if(n){let r=new MutationObserver(()=>{let i=u(e);i&&i!==t&&S(e)});r.observe(n,{childList:!0}),w.push(r)}}function S(e){let t=u(e);if(t){if(Q(e),E.get(e.sel)===t){g(e);return}E.set(e.sel,t),g(e),ge(e,t)}}function ye(){setInterval(()=>{h||b.forEach(e=>{let t=E.get(e.sel),a=u(e);a&&(!t||!document.contains(t)||a!==t)?S(e):(a&&!X(a)||a&&!a.querySelector('thead th[data-ext-bv-header="1"]'))&&g(e)})},Math.max(1e3,l.readyPollMs*4))}function ve(){let e=window.jQuery;e&&b.forEach(t=>{let a=u(t);if(!(!a||a.dataset.extBvBound==="1")){a.dataset.extBvBound="1";try{e(t.sel).off("draw.dt.extBv").on("draw.dt.extBv",()=>{p||h||g(t)})}catch{}}})}var F="ext-bv-dtsearch-",q="ext-bv-filter";function z(e){return(u(e)?.closest(".dataTables_wrapper")??document.getElementById(`${e.sel.replace(/^#/,"")}_wrapper`))?.querySelector(".dataTables_filter input")??null}function ke(e,t){e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0,key:"a"})),e.dispatchEvent(new Event("search",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function we(){try{b.forEach(t=>{let a=T(t),n=a?String(a.search()??""):z(t)?.value??null;n!==null&&sessionStorage.setItem(F+t.kind,n)});let e={};document.querySelectorAll('input:not([type="checkbox"]):not([type="radio"]), select, textarea').forEach(t=>{let a=t.id||t.name;a&&(t.closest(`#${l.barId}`)||(e[a]=t.value??""))}),sessionStorage.setItem(q,JSON.stringify(e))}catch{}}function Ee(){let e=()=>{Array.from(document.querySelectorAll('button, a, input[type="button"], input[type="submit"]')).find(a=>(a.getAttribute("onclick")||"").replace(/\s+/g,"").startsWith("cari("))?.click()},t=a=>{b.every(n=>{let r=u(n);return!!r&&r.classList.contains("dataTable")})?window.setTimeout(e,250):a<60?window.setTimeout(()=>t(a+1),250):e()};t(0)}function Se(){try{let e=sessionStorage.getItem(q),t=!1;if(e){let a=JSON.parse(e);for(let[n,r]of Object.entries(a)){let i=document.getElementById(n)||document.querySelector(`[name="${n}"]`);if(i){let o=i;o.value!==r&&(t=!0),o.value=r,i.dispatchEvent(new Event("input",{bubbles:!0})),i.dispatchEvent(new Event("change",{bubbles:!0}))}}sessionStorage.removeItem(q)}t&&Ee(),b.forEach(a=>{let n=F+a.kind,r=sessionStorage.getItem(n);if(r===null)return;let i=o=>{let d=z(a);if(!d){o<40?window.setTimeout(()=>i(o+1),250):sessionStorage.removeItem(n);return}ke(d,r),window.setTimeout(()=>{(z(a)?.value??null)===r?sessionStorage.removeItem(n):o<10?i(o+1):sessionStorage.removeItem(n)},600)};i(0)})}catch{}}function W(){try{le(),me().then(()=>{xe(),be(),L(),ve(),ye(),Se(),document.documentElement.setAttribute("data-ext-bulk-verif","1");let e=b.map(t=>{let a=u(t),n=a?a.querySelectorAll("tbody tr:not(.dataTables_empty)").length:0,r=a?a.querySelectorAll("tbody td.bv-sel").length:0,i=a?a.querySelectorAll("tbody td.bv-sel[data-ext-bv-unid]").length:0,o=a?!!a.querySelector('thead th[data-ext-bv-header="1"]'):!1;return`${t.sel}: kolom=${r}/${n}${i?` (${i} tanpa id)`:""} ${o?"header=ok":"header=BELUM"}`});console.log("[BulkVerif] Init complete -",e.join(" | "),l.UJI_SAJA?"(MODE UJI: checkbox nonaktif)":"")})}catch(e){console.error("[BulkVerif] Init error:",e)}}return typeof J.featureModules<"u"&&(J.featureModules.mKlaimBulkVerif={id:"mKlaimBulkVerif",name:"Bulk Verif / Batal Verif",description:"Verifikasi atau batalkan verifikasi banyak klaim sekaligus",match:{regex:/^\/v2\/m-klaim\/?$/},run:W}),ne(P)})();
