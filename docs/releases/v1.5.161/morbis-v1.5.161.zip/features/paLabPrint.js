"use strict";var __morbis_feature=(()=>{var Z="extensionConfig";function Lt(o,a,f){let h=a?.features?.[o];if(!h)return!0;if(h.enabled===!1)return!1;let k=f??a?.currentRole??"admin";if(k==="admin")return!0;let w=h.allowedRoles;return!Array.isArray(w)||w.length===0?!0:w.includes(k)}async function Ct(o){try{let a=(await chrome.storage.sync.get(Z))?.[Z]??null;return Lt(o,a)}catch{return!0}}function zt(o,a){Ct(o).then(f=>{if(f)try{a()}catch(h){console.error(`[featureGate:${o}] gagal jalan:`,h)}})}var tt="ext-free-text-noop",Tt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function It(o){try{let a=o.toUpper;if(typeof a=="function"&&a[tt]===!0)return!0;let f=function(h){return h?.value??""};f[tt]=!0;try{Object.defineProperty(o,"toUpper",{value:f,writable:!0,configurable:!0})}catch{o.toUpper=f}return!0}catch{return!1}}var G="ext-pa-typo",Rt=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],z={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},et=4,at=24,qt=.5,Ft=2.5;function it(o,a,f,h){let k=typeof o=="number"?o:Number(o);return Number.isFinite(k)?Math.min(h,Math.max(f,k)):a}function T(o,a){let f=o??{};return{fs:it(f.fs,a.fs,et,at),lh:it(f.lh,a.lh,qt,Ft)}}function N(o){let a=o??{};return{kop:T(a.kop,z.kop),pasien:T(a.pasien,z.pasien),judul:T(a.judul,z.judul),isi:T(a.isi,z.isi),kesimpulan:T(a.kesimpulan,z.kesimpulan),ttd:T(a.ttd,z.ttd)}}function J(){return N(null)}function nt(o){try{if(!o)return J();let a=o.getItem(G);return a?N(JSON.parse(a)):J()}catch{return J()}}function Pt(o,a){try{return o?(o.setItem(G,JSON.stringify(N(a))),!0):!1}catch{return!1}}function Mt(o){try{o?.removeItem(G)}catch{}}function rt(o){let a=N(o),f=h=>Math.min(at,Math.max(et,h));return{...a,alamatFs:f(a.kop.fs-8.5),judulLapFs:f(a.kop.fs-4)}}var y=o=>String(Math.round(o*100)/100);function Nt(o){let a=rt(o);return{"--pa-kop-fs":`${y(a.kop.fs)}pt`,"--pa-kop-lh":y(a.kop.lh),"--pa-alamat-fs":`${y(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${y(a.judulLapFs)}pt`,"--pa-pasien-fs":`${y(a.pasien.fs)}pt`,"--pa-pasien-lh":y(a.pasien.lh),"--pa-judul-fs":`${y(a.judul.fs)}pt`,"--pa-judul-lh":y(a.judul.lh),"--pa-isi-fs":`${y(a.isi.fs)}pt`,"--pa-isi-lh":y(a.isi.lh),"--pa-kesimpulan-fs":`${y(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":y(a.kesimpulan.lh),"--pa-ttd-fs":`${y(a.ttd.fs)}pt`,"--pa-ttd-lh":y(a.ttd.lh)}}function Ut(o,a){if(o)try{for(let[f,h]of Object.entries(Nt(a)))o.setProperty(f,h)}catch{}}var Ht=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function W(o){let a=o??"",f=a.match(Ht);if(!f)return null;let h=a.slice(f[0].length).trim();return h===""?null:[f[1],h]}var ot=o=>Math.round(o*10)/10;function Bt(o,a,f=.35){let h=Number.isFinite(o)&&o>0?o:0,k=Number.isFinite(a)&&a>0?a:12,w=ot(h+f*k);return{padPx:w,indentPx:-w}}function Dt(o,a){let f=Number.isFinite(a)&&a>0?a:11,h=(o??"").length;return h===0?0:ot(h*.55*f+.35*f)}zt("paLabPrint",function(){"use strict";function o(){try{It(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let k=document.createElement("style");k.id="ext-free-text-style",k.textContent=Tt,document.head.appendChild(k)}}catch{}}if(o(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",o),window.setInterval(o,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let k="ext-pa-print-proc";if(document.documentElement.getAttribute(k))return;document.documentElement.setAttribute(k,"1");let w=()=>{try{return window.localStorage??null}catch{return null}},E=nt(w()),Q=()=>{try{Ut(document.documentElement.style,E)}catch{}};Q();let S=t=>U(t?.textContent||"");function lt(t){return t.replace(/<[^>]+>/g," ")}function Ot(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function U(t){return Ot(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let st=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",H=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>S(t)).filter(Boolean);for(;H.length<3;)H.push("");let P=[],pt=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(pt){let t=document.createElement("div");t.innerHTML=pt.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),P=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let B=P.join(" "),dt=t=>{let e=B.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},ct=dt("telp"),ut=dt("fax"),D=(B.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],O=(B.match(/https?:\/\/[^\s;,]+/)||[""])[0],C=B.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");D&&(C=C.split(D).join("")),O&&(C=C.split(O).join("")),C=C.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let $t=["Alamat: "+C,ct?"Telp: "+ct:"",ut?"Fax: "+ut:""].filter(Boolean).join(", "),Kt=[D?"Email: "+D:"",O?"Website: "+O:""].filter(Boolean).join(", ");P=[$t,Kt].filter(Boolean);let V=S(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",$=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let n=S(e[0]),r=S(e[2]),p=S(e[3]),s=S(e[5]);n&&$.push([n,r]),p&&$.push([p,s])}});let I=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],j=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),L=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",n=!1,r=t.querySelector(".section-title");if(r)e=S(r),n=!0;else{let c=m=>m.split(":")[0].trim();for(let m of Array.from(t.children).slice(0,3)){let b=S(m);if(b&&b.length<=24&&I.includes(j(c(b)))){e=c(b);break}}if(!e){let m=(t.textContent||"").split(`
`).map(b=>b.trim()).find(Boolean)||"";m&&I.includes(j(c(m)))&&(e=c(m))}if(!e)return}let p=document.createElement("div");p.innerHTML=t.innerHTML,p.querySelector(".section-title")?.remove();let s=p.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(c=>c.split(/<br\s*\/?>|\n/).map(m=>U(m.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(c=>c.length),u=[],i=[];s.forEach((c,m)=>{c.forEach((b,g)=>{m>0&&g===0&&u.length&&i.push(u.length),u.push(b)})});let l=u;if(!n&&l.length&&j(l[0])===j(e)){l.shift();for(let c=0;c<i.length;c++)i[c]-=1;for(;i.length&&i[0]<=0;)i.shift()}l.length>1&&!/^[IVXLC]+\.\s/.test(l[0])&&l.slice(1).some(c=>/^II\.\s/.test(c))&&(l[0]="I. "+l[0]),e&&L.push({title:e,items:l,para:i})});let _t=/^catatan\s*:?/i,Gt=/^icd[\s-]*o\b\s*:?/i,X=[];for(let t of L){let e=[{title:t.title,items:[],para:[]}],n=e[0],r=!1,p=(s,u)=>{n={title:s,items:[],para:[],bare:u},e.push(n),r=!0};if(t.items.forEach((s,u)=>{let i=s.match(_t),l=i?null:s.match(Gt);if(i){j(n.title)!=="catatan"&&p("Catatan");let c=s.slice(i[0].length).trim();c&&(t.para.includes(u)&&n.para.push(n.items.length),n.items.push(c));return}if(l){j(n.title)!=="icdo"&&p("ICD-0",!0),t.para.includes(u)&&n.para.push(n.items.length),n.items.push(s);return}t.para.includes(u)&&n.para.push(n.items.length),n.items.push(s)}),r)for(let s of e)s.items.length&&X.push(s);else X.push(e[0])}L.length=0,L.push(...X),L.forEach((t,e)=>t._i=e),L.sort((t,e)=>{let n=t._i??0,r=e._i??0,p=I.indexOf(j(t.title)),s=I.indexOf(j(e.title)),u=p===-1?I.length:p,i=s===-1?I.length:s;return u!==i?u-i:n-r});function Jt(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let n=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),r=t.getAttribute("placeholder")||"",p=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(n+" "+r+" "+p).slice(0,300)}}function Wt(t,e,n){let r=e.toLowerCase().split(/[^a-z0-9]+/).filter(i=>i.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(i));if(!r.length)return"";let p=r.sort((i,l)=>l.length-i.length)[0],s="",u=-1;return t.querySelectorAll("input, textarea, select").forEach(i=>{let{val:l,ctx:c}=Jt(i);if(!l||l===e||!l.toLowerCase().includes(p))return;let m=n.test(c)?2:0;m>u&&(u=m,s=l)}),s}function Qt(t,e){return(t.querySelector(e)?.value||"").trim()}async function Vt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let n=i=>/ket\w*\s*klinis/i.test(i),r=i=>/^dokter/i.test(i)||/^rs\b/i.test(i),p=t.map(([i,l],c)=>({label:i,value:l,idx:c})).filter(i=>r(i.label)?!!i.value:n(i.label));if(!p.length)return;let s=new AbortController,u=window.setTimeout(()=>s.abort(),6e3);try{let i=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),l=await fetch(i.toString(),{credentials:"same-origin",signal:s.signal});if(!l.ok){window.console.info("[paPrint] override: fetch input status "+l.status);return}let c=await l.text(),m=new DOMParser().parseFromString(c,"text/html");window.console.info('[paPrint] override: input title="'+(m.title||"").slice(0,60)+'" len='+c.length+" fields="+m.querySelectorAll("input, textarea, select").length);for(let b of p){if(n(b.label)){let q=Qt(m,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),A=U(lt(q));window.console.info("[paPrint] override: "+b.label+' cetak="'+b.value+'" input="'+A+'"'),A&&A!==b.value&&(t[b.idx][1]=A);continue}let g=/^dokter/i.test(b.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,x=Wt(m,b.value,g),v=U(lt(x||""));window.console.info("[paPrint] override: "+b.label+' cetak="'+b.value+'" input="'+v+'"'),v&&v!==b.value&&(t[b.idx][1]=v)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(u)}}await Vt($).catch(()=>{});let R=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>S(t)).filter(Boolean),mt=R[0]||"",ft=R[1]||"",K=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",gt=R.find(t=>/^\(.*\)$/.test(t))||R[2]||"",ht=R.find(t=>/^nip\.?/i.test(t))||R[3]||"",bt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Xt=Array.from(document.body.querySelectorAll("script")),Yt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),M=$.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let n=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,r=n.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||n,p=r.split(/\s+-\s*/);if(p.length>=3&&/rawat\s+inap/i.test(p[1])){let s=Yt(p[1].trim()),u=p.slice(2).join(" - ").trim(),i=u?s+" - "+u:s;if(i)return[t,i]}return[t,r]}),Zt=M.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),Y=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),xt=t=>/^catatan/i.test(t.trim()),yt=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),te=M.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function kt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(n=>{if(!n.ok)throw new Error("img "+n.status);return n.blob()}).then(n=>new Promise((r,p)=>{let s=new FileReader;s.onload=()=>r(String(s.result)),s.onerror=()=>p(s.error),s.readAsDataURL(n)})).catch(()=>e)}async function ee(){let t=rt(E),[e,n]=await Promise.all([kt(st),K?kt(K):Promise.resolve("")]),r="";for(let l=0;l<M.length;l+=2){let c=M[l],m=M[l+1];r+="<tr><td>"+d(c[0])+"</td><td>:</td><td>"+d(c[1])+"</td>"+(m?"<td>"+d(m[0])+"</td><td>:</td><td>"+d(m[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let p="";for(let l of L){if(xt(l.title)){let g=l.items.length?l.items:["Tidak ada"];p+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.judul.fs+'pt"><b><u>CATATAN:</u></b></td><td>'+g.map(x=>"- "+d(yt(x)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(l.bare){l.items.forEach((g,x)=>{p+='<p style="margin:'+(x===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.judul.fs+'pt;"><b>'+d(g.toUpperCase())+"</b></p>"});continue}p+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b><u>'+d(l.title.toUpperCase())+"</u></b></p>";let c=j(l.title)==="kesimpulan",m=c?t.kesimpulan.fs:t.isi.fs,b=c?t.kesimpulan.lh:t.isi.lh;l.items.forEach((g,x)=>{let v=c?"<b>"+d(g)+"</b>":Y(g),q=W(g),A=m*1.8,F=Math.max(0,...l.items.map(ne=>{let Et=W(ne);return Et?Dt(Et[0],m):0})),St=(F>0?Math.max(A,F):A).toFixed(1),ie="margin-left:"+St+"pt;"+(q?"text-indent:-"+St+"pt;":"");p+='<p style="margin:'+(l.para.includes(x)?"14pt":"0")+" 0 6pt 0;font-size:"+m+"pt;line-height:"+b+";text-align:justify;"+ie+'">'+v+"</p>"})}let s='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(V)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+H.slice(0,3).map(l=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(l)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+P.map(l=>d(l)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(V.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+r+"</table>"+p+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(mt)+'</p><p style="margin:0 0 6pt 0;">'+d(ft)+"</p>"+(n?'<p style="margin:0 0 6pt 0;"><img src="'+n+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(gt)+'</b></p><p style="margin:0 0 6pt 0;">'+d(ht)+"</p></td></tr></table></body></html>",u=new Blob(["\uFEFF"+s],{type:"application/msword"}),i=document.createElement("a");i.href=URL.createObjectURL(u),i.download="Hasil-PA-"+te+".doc",document.body.appendChild(i),i.click(),window.setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},4e3)}let ae=L.map(t=>{if(xt(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(r=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+d(yt(r)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=j(t.title)==="kesimpulan",n='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+'">'+t.items.map((r,p)=>{let s=t.para.includes(p)?" item-para":"",u=W(r);if(u){let i=e?"<strong>"+d(u[1])+"</strong>":Y(u[1]);return'<div class="item-list has-marker'+s+'"><span class="item-marker">'+d(u[0])+"</span> <span>"+i+"</span></div>"}return'<div class="item-list'+s+'">'+(e?"<strong>"+d(r)+"</strong>":Y(r))+"</div>"}).join("")+"</div>";return t.bare?n:'<div class="section-judul">'+d(t.title)+"</div>"+n}).join("");function _(t=document){let e;try{e=Array.from(t.querySelectorAll(".section-isi"))}catch{return}for(let n of e){if(n.classList.contains("section-isi-bare"))continue;let r;try{r=Array.from(n.querySelectorAll(":scope > .item-list"))}catch{r=Array.from(n.children).filter(g=>g.classList.contains("item-list"))}let p=()=>{try{n.style.paddingLeft="";for(let g of r){let x=g;x.style.paddingLeft="0px",x.style.textIndent="0px"}}catch{}},s=r.filter(g=>g.classList.contains("has-marker"));if(!s.length){p();continue}let u=12;try{let g=parseFloat(getComputedStyle(n).fontSize);Number.isFinite(g)&&g>0&&(u=g)}catch{}let i=0,l=new Map;for(let g of s){let x=g.querySelector(".item-marker");if(!x||!x.textContent)continue;let v=0;try{let q=document.createRange();q.selectNodeContents(x);let A=Array.from(q.getClientRects()).filter(F=>F.width>.5);A.length&&(v=Math.max(...A.map(F=>F.width)))}catch{}v>0&&(l.set(g,v),v>i&&(i=v))}if(i<=0){p();continue}let{padPx:c}=Bt(i,u),m=c.toFixed(1)+"px",b=(-c).toFixed(1)+"px";try{n.style.paddingLeft=m;for(let g of r){let x=g;x.style.paddingLeft="0px",x.style.textIndent=l.has(g)?b:"0px"}}catch{}}}let vt;function wt(){try{window.clearTimeout(vt)}catch{}vt=window.setTimeout(()=>{_()},250)}document.body.innerHTML='<a href="'+d(bt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(st)+'" alt="Logo"></div><div class="kop-text">'+H.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+P.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(V)+'</div><div class="patient-info-container">'+Zt+'</div><div class="hasil-pa">'+ae+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(mt)+"</p><p>"+d(ft)+"</p>"+(K?'<img src="'+d(K)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(gt)+'</p><p style="margin-top: 2px;">'+d(ht)+"</p></div></div></div>",Xt.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),ee().catch(()=>{window.location.href=bt})});let jt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(r,p,s,u,i,l,c,m)=>"<label>"+d(s)+'<input type="range" data-g="'+d(r)+'" data-f="'+p+'" min="'+u+'" max="'+i+'" step="'+l+'" value="'+c+'"><output data-o="'+d(r+"-"+p)+'">'+d(String(c)+m)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+Rt.map(r=>'<div class="t-typo-group"><strong>'+d(r.label)+'</strong><div class="t-typo-row">'+e(r.key,"fs","Font (pt)",4,20,.5,E[r.key].fs,"pt")+e(r.key,"lh","Spasi baris",.5,2.5,.05,E[r.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(r=>{let p=r;p.addEventListener("input",()=>{let s=p.dataset.g,u=p.dataset.f;if(!s||!u||!E[s])return;E[s][u]=Number(p.value),Q(),wt();let i=t.querySelector(`output[data-o="${s}-${u}"]`);i&&(i.textContent=p.value+(u==="fs"?"pt":""))})});let n=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let r=Pt(w(),E);n&&(n.textContent=r?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Mt(w()),E=nt(w()),Q(),jt(),n){let r=t.querySelector("[data-note]");r&&(r.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&jt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let At="ext-pa-print-style";if(!document.getElementById(At)){let t=document.createElement("style");t.id=At,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        /* Base gutter di CONTAINER (.section-isi): semua item (polos maupun
           ber-marker, baris pertama maupun lanjutan) berbagi kolom teks
           yang sama; hanya marker yang menggantung di gutter. */
        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            padding-left: 1.8em;
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Hanya marker yang menggantung \u2014 padding sudah disediakan container. */
        .item-list.has-marker {
            text-indent: -1.8em;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-judul-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}_();try{document.fonts?.ready&&document.fonts.ready.then(()=>{_()})}catch{}window.addEventListener("resize",wt),window.addEventListener("beforeprint",()=>{_()})}let f=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),a().catch(()=>{})):Date.now()-f>5e3&&window.clearInterval(h)},200)})})();
