"use strict";var __morbis_feature=(()=>{var V="http://dev.rsudkotajambi.id/rs",W="ext-farmasi-app-base",Y=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],F=".rsudkotajambi.id";function Q(t){try{let e=new URL(t);if(e.protocol!=="http:"&&e.protocol!=="https:")return!1;let a=e.hostname.toLowerCase();return Y.includes(a)?!0:a.endsWith(F)}catch{return!1}}function X(){try{let t=localStorage.getItem(W);if(t&&Q(t))return t.replace(/\/+$/,"")}catch{}return V}function Z(){return X()}function tt(t,e=8e3){try{let a=window.requestIdleCallback;if(typeof a=="function"){a.call(window,t,{timeout:e});return}}catch{}window.setTimeout(t,Math.min(e,1500))}function et(){return window}var nt='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',O=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${nt};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,E=null;function at(){return E||(E=new CSSStyleSheet,E.replaceSync(O)),E}var D=!1;function rt(){if(D||document.getElementById("ext-pjs-font"))return;D=!0;let t=document.createElement("link");t.id="ext-pjs-font",t.rel="stylesheet",t.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(t)}function R(t,e="open"){let a=t.attachShadow({mode:e});return a.adoptedStyleSheets=[at()],rt(),a}var P=!1;function it(){if(P)return;P=!0;let t=document.createElement("style");t.id="ext-token-css",t.textContent=O.replace(":host",":root"),document.head.appendChild(t)}var ot=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,st=class extends HTMLElement{constructor(){super();let t=R(this);t.innerHTML=`
      <style>${ot}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=t.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",t=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){t.stopPropagation(),t.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(t){(t==="disabled"||t==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}},I=typeof window<"u"?window.customElements:null;if(I)try{I.get("ext-btn")||I.define("ext-btn",st)}catch(t){console.warn("[MORBIS Ext] gagal registrasi ext-btn:",t)}var dt=`
  :host { display: block; }
  input {
    width: 100%;
    box-sizing: border-box;
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text);
    background: var(--ext-surface);
    border: 1px solid var(--ext-border);
    border-radius: var(--ext-radius-md);
    padding: 9px 12px;
    min-height: 42px;
    transition: border-color var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
  }
  input::placeholder { color: var(--ext-text-muted); }
  input:focus { outline: none; border-color: var(--ext-primary); box-shadow: var(--ext-ring); }
  input:disabled { background: var(--ext-surface-2); color: var(--ext-text-muted); cursor: not-allowed; }
  :host([invalid]) input { border-color: var(--ext-danger); }

  :host([size='sm']) input {
    font-size: var(--ext-font-size-sm);
    padding: 6px 10px;
    min-height: 32px;
    border-radius: var(--ext-radius-sm);
  }
  :host([size='lg']) input {
    font-size: var(--ext-font-size-lg);
    padding: 12px 14px;
    min-height: 50px;
  }
`,lt=class extends HTMLElement{constructor(){super();let t=R(this);t.innerHTML=`<style>${dt}</style><input />`,this.input=t.querySelector("input");for(let e of["change","focus","blur"])this.input.addEventListener(e,()=>this.dispatchEvent(new Event(e)))}static get observedAttributes(){return["type","placeholder","value","disabled","invalid"]}connectedCallback(){this.sync()}attributeChangedCallback(){this.sync()}sync(){let{input:t}=this;if(!t)return;t.type=this.getAttribute("type")||"text",t.placeholder=this.getAttribute("placeholder")||"",t.disabled=this.hasAttribute("disabled"),t.setAttribute("aria-invalid",this.hasAttribute("invalid")?"true":"false");let e=this.getAttribute("value");e!==null&&t.value!==e&&(t.value=e)}get value(){return this.input.value}set value(t){this.input.value=t??""}focus(){this.input.focus()}},$=typeof window<"u"?window.customElements:null;if($)try{$.get("ext-input")||$.define("ext-input",lt)}catch(t){console.warn("[MORBIS Ext] gagal registrasi ext-input:",t)}var C="[MORBIS Ext] visiteKonsul",S=et();function B(){try{let t=new URLSearchParams(location.search).get("id_visit");return t&&t.trim()?t.trim():null}catch{return null}}var ut=Z(),A=ut+"/api/visite-konsul";function K(t,e){return t?.message||(e?`HTTP ${e.status}`:"gagal menghubungi server")}async function ct(t){let e=await fetch(`${A}/list?id_visit=${encodeURIComponent(t)}`,{credentials:"omit"}),a=await e.json().catch(()=>null);return a?.ok?{rows:(a.data||[]).map(n=>({id:n.id,jenis:n.jenis,nama_dokter:n.nama_dokter,id_dokter:n.id_dokter,saving:!1}))}:{rows:[],error:K(a,e)}}async function pt(t,e,a){let n=await(await fetch(`${A}/save`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"omit",body:JSON.stringify({id:e.id,id_visit:Number(t),jenis:e.jenis,id_dokter:e.id_dokter,nama_dokter:e.nama_dokter,user:a})})).json();return n?.ok?{id:n.data.id,jenis:n.data.jenis,nama_dokter:n.data.nama_dokter,id_dokter:n.data.id_dokter,saving:!1}:null}async function xt(t,e){return!!(await(await fetch(`${A}/delete`,{method:"DELETE",headers:{"Content-Type":"application/json"},credentials:"omit",body:JSON.stringify({id:t,id_visit:Number(e)})})).json())?.ok}async function mt(t){let e=await fetch(`${A}/dokter?q=${encodeURIComponent(t)}`,{credentials:"omit"}),a=await e.json().catch(()=>null);return a?.ok?{items:a.data||[]}:{items:[],error:K(a,e)}}function z(t,e,a){if((typeof window<"u"?window.customElements:null)?.get?.("ext-btn")){let r=document.createElement("ext-btn");return r.setAttribute("variant",t),r.setAttribute("size",e),r.textContent=a,r}let n=document.createElement("button");return n.type="button",n.textContent=a,n.className=`ext-vk-btn ext-vk-btn--${t} ext-vk-btn--${e}`,n}function ft(){try{let t=document.querySelector('input[name="id_user"], #id_user');if(t?.value?.trim())return t.value.trim()}catch{}return"petugas"}function q(t){return`ext-vk-cache-${t}`}function M(t){return`ext-vk-pending-${t}`}function j(){try{return window.localStorage||null}catch{return null}}function ht(t){let e=j();if(!e)return[];try{let a=e.getItem(q(t));if(!a)return[];let n=JSON.parse(a);return Array.isArray(n)?n.filter(r=>r&&typeof r.nama_dokter=="string").map(r=>({id:typeof r.id=="number"?r.id:null,jenis:r.jenis==="konsul"?"konsul":"visite",nama_dokter:String(r.nama_dokter),id_dokter:typeof r.id_dokter=="number"?r.id_dokter:null,saving:!1})):[]}catch{return[]}}function L(t,e){let a=j();if(a)try{a.setItem(q(t),JSON.stringify(e.map(n=>({id:n.id,jenis:n.jenis,nama_dokter:n.nama_dokter,id_dokter:n.id_dokter}))))}catch{}}function _(t){let e=j();if(!e)return[];try{let a=e.getItem(M(t));if(!a)return[];let n=JSON.parse(a);return Array.isArray(n)?n.filter(r=>r&&typeof r.nama_dokter=="string").map(r=>({id:typeof r.id=="number"?r.id:null,jenis:r.jenis==="konsul"?"konsul":"visite",nama_dokter:String(r.nama_dokter),id_dokter:typeof r.id_dokter=="number"?r.id_dokter:null,saving:!1})):[]}catch{return[]}}function N(t,e){let a=j();if(a)try{e.length?a.setItem(M(t),JSON.stringify(e.map(n=>({id:n.id,jenis:n.jenis,nama_dokter:n.nama_dokter,id_dokter:n.id_dokter})))):a.removeItem(M(t))}catch{}}function vt(t,e){let a=[...t];for(let n of e)a.find(r=>r.jenis===n.jenis&&r.nama_dokter.trim().toLowerCase()===n.nama_dokter.trim().toLowerCase())||a.push(n);return a}function bt(){let t=document.createElement("style");t.textContent=`
    .ext-vk-card { margin: 12px 0; padding: 12px; border: 1px solid var(--ext-border); border-radius: var(--ext-radius-md); background: var(--ext-surface); font-family: var(--ext-font-family); }
    .ext-vk-card h2, .ext-vk-card h3 { margin: 0 0 8px; font-size: var(--ext-font-size-md); font-weight: 700; color: var(--ext-text); }
    .ext-vk-card > ext-btn, .ext-vk-card > .ext-vk-btn { margin-right: 6px; }
    .ext-vk-btn { display: inline-flex; align-items: center; justify-content: center; font-family: var(--ext-font-family); font-weight: 600; border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); cursor: pointer; margin-right: 6px; }
    .ext-vk-btn--sm { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; }
    .ext-vk-btn--primary { background: var(--ext-primary); color: var(--ext-text-on-primary); border-color: var(--ext-primary); }
    .ext-vk-btn--secondary { background: var(--ext-surface); color: var(--ext-text); }
    .ext-vk-btn--danger { background: var(--ext-danger); color: var(--ext-text-on-primary); border-color: var(--ext-danger); }
    .ext-vk-btn:disabled { opacity: 0.55; cursor: not-allowed; }
    .ext-vk-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
    .ext-vk-table th, .ext-vk-table td { border: 1px solid var(--ext-border); padding: 4px 6px; font-size: var(--ext-font-size-sm); color: var(--ext-text); }
    .ext-vk-table th { background: var(--ext-surface-2); }
    .ext-vk-autocomplete { position: relative; }
    .ext-vk-input { width: 100%; box-sizing: border-box; padding: 6px 10px; font-size: var(--ext-font-size-sm); border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); font-family: var(--ext-font-family); color: var(--ext-text); background: var(--ext-surface); }
    .ext-vk-suggest { position: absolute; top: 100%; left: 0; right: 0; background: var(--ext-surface); border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); max-height: 160px; overflow-y: auto; z-index: 9999; box-shadow: var(--ext-shadow-md); }
    .ext-vk-suggest div { padding: 6px 8px; font-size: var(--ext-font-size-sm); color: var(--ext-text); cursor: pointer; }
    .ext-vk-suggest div:hover { background: var(--ext-surface-2); }
    .ext-vk-status { font-size: var(--ext-font-size-xs); color: var(--ext-text-muted); margin-left: 6px; }
    .ext-vk-warn { margin: 0 0 8px; padding: 8px 10px; font-size: var(--ext-font-size-sm); border-radius: var(--ext-radius-sm); background: var(--ext-danger-soft); border: 1px solid #f3c1be; color: var(--ext-danger); }
  `,document.head.appendChild(t)}function gt(t,e,a){let n=()=>{let c=t.value;return typeof c=="string"?c:t.getAttribute("value")??""},r=c=>{let b=t;try{b.value=c}catch{}t.setAttribute("value",c)},w=t.parentElement,o=null,k=null;function x(){o&&(o.remove(),o=null)}t.addEventListener("input",()=>{k&&window.clearTimeout(k),k=window.setTimeout(async()=>{let c=n().trim();if(c.length<2){x();return}let{items:b,error:y}=await mt(c);if(x(),!(!b.length&&!y)){if(o=document.createElement("div"),o.className="ext-vk-suggest",y&&!b.length){let s=document.createElement("div");s.textContent=`Pencarian dokter gagal: ${y}`,s.style.color="var(--ext-danger)",o.appendChild(s),w.appendChild(o);return}for(let s of b){let f=document.createElement("div");f.textContent=s.nama,f.addEventListener("mousedown",u=>{u.preventDefault(),r(s.nama),a(s.id,s.nama),x()}),o.appendChild(f)}w.appendChild(o)}},250)}),t.addEventListener("blur",()=>window.setTimeout(x,150))}function H(t,e,a,n,r,w){let o=document.createElement("div");o.className="ext-vk-card";let k=document.createElement("h3");k.textContent=t,o.appendChild(k);let x=document.createElement("table");x.className="ext-vk-table";let c=document.createElement("thead");c.innerHTML='<tr><th style="width:40px">No</th><th>Dokter</th><th style="width:60px">Aksi</th></tr>',x.appendChild(c);let b=document.createElement("tbody");x.appendChild(b),o.appendChild(x);let y=z("secondary","sm","+ Tambah");o.appendChild(y);let s=z("primary","sm","Simpan");o.appendChild(s);let f=z("secondary","sm","Sinkron");o.appendChild(f);let u=document.createElement("span");u.className="ext-vk-status",o.appendChild(u);function T(){b.innerHTML="",a.filter(i=>i.jenis===e).forEach((i,h)=>{let p=document.createElement("tr"),g=document.createElement("td");g.textContent=String(h+1),p.appendChild(g);let v=document.createElement("td"),l=document.createElement("div");l.className="ext-vk-autocomplete";let d;if(window.customElements?.get?.("ext-input")){d=document.createElement("ext-input"),d.setAttribute("type","text"),d.setAttribute("size","sm"),d.setAttribute("placeholder","Ketik nama dokter...");try{d.value=i.nama_dokter}catch{}d.setAttribute("value",i.nama_dokter)}else{let m=document.createElement("input");m.type="text",m.placeholder="Ketik nama dokter...",m.value=i.nama_dokter,m.className="ext-vk-input",d=m}l.appendChild(d),v.appendChild(l),gt(d,i,(m,Ct)=>{i.id_dokter=m,i.nama_dokter=Ct,u.textContent="Belum disimpan"}),d.addEventListener("change",()=>{let m=d.value;i.nama_dokter=(typeof m=="string"?m:d.getAttribute("value")??"").trim(),u.textContent="Belum disimpan"}),p.appendChild(v);let U=document.createElement("td"),G=z("danger","sm","Hapus");G.addEventListener("click",async()=>{if(i.id&&!await xt(i.id,n)){u.textContent="Gagal hapus";return}let m=a.indexOf(i);m>=0&&a.splice(m,1),T(),u.textContent="Dihapus"}),U.appendChild(G),p.appendChild(U),b.appendChild(p)})}async function J(i){if(!i.nama_dokter.trim()||i.saving)return!1;i.saving=!0;let h=await pt(n,i,r);return i.saving=!1,h?(i.id=h.id,i.id_dokter=h.id_dokter,i.nama_dokter=h.nama_dokter,!0):!1}s.addEventListener("click",async()=>{let i=a.filter(v=>v.jenis===e&&v.nama_dokter.trim());if(!i.length){u.textContent="Belum ada data";return}let h=!!window.customElements?.get?.("ext-btn");h?s.setAttribute("loading",""):(s.disabled=!0,s.textContent="Menyimpan..."),u.textContent="Menyimpan...",L(n,a);let p=0,g=[];for(let v of i)await J(v)?p++:g.push(v);if(g.length)N(n,[..._(n),...g]);else{let v=_(n).filter(l=>!i.some(d=>d.jenis===l.jenis&&d.nama_dokter.trim().toLowerCase()===l.nama_dokter.trim().toLowerCase()));N(n,v)}L(n,a),h?s.removeAttribute("loading"):(s.disabled=!1,s.textContent="Simpan"),p===i.length?u.textContent="Tersimpan":p===0?u.textContent="Offline \u2014 tersimpan lokal, akan dikirim saat online":u.textContent=`Tersimpan ${p}/${i.length} (sisanya lokal)`,p!==i.length&&console.warn(C,"gagal simpan",e,p,"/",i.length)}),f.addEventListener("click",async()=>{let i=_(n).filter(l=>l.jenis===e);if(!i.length){u.textContent="Tidak ada data pending";return}let h=!!window.customElements?.get?.("ext-btn");h?f.setAttribute("loading",""):(f.disabled=!0,f.textContent="Sinkron..."),u.textContent="Menyinkronkan...";let p=0,g=[];for(let l of i)await J(l)?p++:g.push(l);let v=_(n).filter(l=>l.jenis!==e);N(n,[...v,...g]);for(let l of i)a.some(d=>d.jenis===l.jenis&&d.nama_dokter.trim().toLowerCase()===l.nama_dokter.trim().toLowerCase())||a.push({...l,saving:!1});L(n,a),T(),h?f.removeAttribute("loading"):(f.disabled=!1,f.textContent="Sinkron"),u.textContent=g.length?`Gagal ${g.length}, coba lagi`:`Sinkron ${p} data`}),y.addEventListener("click",()=>{a.push({id:null,jenis:e,nama_dokter:"",id_dokter:null,saving:!1}),T()}),T(),w.appendChild(o)}function kt(){return Array.from(document.querySelectorAll("h2.judul")).find(e=>/halaman\s+utama/i.test(e.textContent||""))||Array.from(document.querySelectorAll("h1, h2, h3")).find(e=>/halaman\s+utama/i.test(e.textContent||""))||null}async function yt(t=5e3){let e=Date.now()+t;for(;;){let a=kt();if(a||Date.now()>e)return a;await new Promise(n=>setTimeout(n,250))}}async function wt(){let t=B();if(!t||S.__extVisiteKonsul)return;S.__extVisiteKonsul=!0,it(),bt();let e=ft(),a=document.querySelector("#main-content, .content, main, #content");a||(a=document.body);let n=document.createElement("div");n.className="ext-vk-card";let r=document.createElement("h2");r.textContent="Visite & Konsul Dokter Spesialis IGD (input manual)",n.appendChild(r);let w=await yt();w?w.insertAdjacentElement("afterend",n):a.insertBefore(n,a.firstChild);let o=[],{rows:k,error:x}=await ct(t);if(x){let c=document.createElement("div");c.className="ext-vk-warn",c.textContent=`API visite-konsul tidak aktif (${x}). Menampilkan data lokal (cache). Pencarian & simpan dokter akan gagal sampai admin Reports mengaktifkan grup API ini.`,n.appendChild(c),console.warn(C,"api list gagal:",x);let b=ht(t),y=_(t),s=vt(b,y);o.push(...s)}else o.push(...k),L(t,k);H("VISITE","visite",o,t,e,n),H("KONSUL","konsul",o,t,e,n),console.log(C,"loaded",o.length,"rows for visit",t)}typeof S.featureModules<"u"?S.featureModules.visiteKonsul={id:"visiteKonsul",name:"Visite & Konsul Dokter (IGD)",description:"Input manual visite & konsul dokter spesialis IGD di halaman utama pelayanan (data di Reports SIMRS)",match:{pathname:"/admisi/pelaksanaan_pelayanan/halaman-utama"},enabledWhen:()=>!!B(),run:()=>tt(()=>{wt().catch(t=>console.error(C,t))},500)}:console.warn(C,"featureModules not defined, registration skipped")})();
