"use strict";var __morbis_feature=(()=>{var at="extensionConfig";function St(d,i,g){let h=i?.features?.[d];if(!h)return!0;if(h.enabled===!1)return!1;let y=g??i?.currentRole??"admin";if(y==="admin")return!0;let A=h.allowedRoles;return!Array.isArray(A)||A.length===0?!0:A.includes(y)}async function Ct(d){try{let i=(await chrome.storage.local.get(at))?.[at]??null;return St(d,i)}catch{return!0}}function Et(d,i){Ct(d).then(g=>{if(g)try{i()}catch(h){console.error(`[featureGate:${d}] gagal jalan:`,h)}})}var it="ext-free-text-noop",It='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function Lt(d){try{let i=d.toUpper;if(typeof i=="function"&&i[it]===!0)return!0;let g=function(h){return h?.value??""};g[it]=!0;try{Object.defineProperty(d,"toUpper",{value:g,writable:!0,configurable:!0})}catch{d.toUpper=g}return!0}catch{return!1}}var G="ext-pa-typo",zt=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi (termasuk ICD-O, Saran & Catatan)"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],w={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},icdo:{fs:6,lh:1.2},catatan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},nt=4,rt=24,Rt=.5,Tt=2.5;function ot(d,i,g,h){let y=typeof d=="number"?d:Number(d);return Number.isFinite(y)?Math.min(h,Math.max(g,y)):i}function j(d,i){let g=d??{};return{fs:ot(g.fs,i.fs,nt,rt),lh:ot(g.lh,i.lh,Rt,Tt)}}function M(d){let i=d??{};return{kop:j(i.kop,w.kop),pasien:j(i.pasien,w.pasien),judul:j(i.judul,w.judul),isi:j(i.isi,w.isi),kesimpulan:j(i.kesimpulan,w.kesimpulan),icdo:j(i.icdo,w.icdo),catatan:j(i.catatan,w.catatan),ttd:j(i.ttd,w.ttd)}}function J(){return M(null)}function lt(d){try{if(!d)return J();let i=d.getItem(G);return i?M(JSON.parse(i)):J()}catch{return J()}}function qt(d,i){try{return d?(d.setItem(G,JSON.stringify(M(i))),!0):!1}catch{return!1}}function Pt(d){try{d?.removeItem(G)}catch{}}function st(d){let i=M(d),g=h=>Math.min(rt,Math.max(nt,h));return{...i,alamatFs:g(i.kop.fs-8.5),judulLapFs:g(i.kop.fs-4)}}var b=d=>String(Math.round(d*100)/100);function Ht(d){let i=st(d);return{"--pa-kop-fs":`${b(i.kop.fs)}pt`,"--pa-kop-lh":b(i.kop.lh),"--pa-alamat-fs":`${b(i.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(i.judulLapFs)}pt`,"--pa-pasien-fs":`${b(i.pasien.fs)}pt`,"--pa-pasien-lh":b(i.pasien.lh),"--pa-judul-fs":`${b(i.judul.fs)}pt`,"--pa-judul-lh":b(i.judul.lh),"--pa-isi-fs":`${b(i.isi.fs)}pt`,"--pa-isi-lh":b(i.isi.lh),"--pa-kesimpulan-fs":`${b(i.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(i.kesimpulan.lh),"--pa-icdo-fs":`${b(i.icdo.fs)}pt`,"--pa-icdo-lh":b(i.icdo.lh),"--pa-catatan-fs":`${b(i.catatan.fs)}pt`,"--pa-catatan-lh":b(i.catatan.lh),"--pa-ttd-fs":`${b(i.ttd.fs)}pt`,"--pa-ttd-lh":b(i.ttd.lh)}}function Dt(d,i){if(d)try{for(let[g,h]of Object.entries(Ht(i)))d.setProperty(g,h)}catch{}}var Mt=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function V(d){let i=d??"",g=i.match(Mt);if(!g)return null;let h=i.slice(g[0].length).trim();return h===""?null:[g[1],h]}Et("paLabPrint",function(){"use strict";function d(){try{Lt(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let y=document.createElement("style");y.id="ext-free-text-style",y.textContent=It,document.head.appendChild(y)}}catch{}}if(d(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",d),window.setInterval(d,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function i(){let y="ext-pa-print-proc";if(document.documentElement.getAttribute(y))return;document.documentElement.setAttribute(y,"1");let A=()=>{try{return window.localStorage??null}catch{return null}},S=lt(A()),W=()=>{try{Dt(document.documentElement.style,S)}catch{}};W();let v=t=>F(t?.textContent||"");function pt(t){return t.replace(/<[^>]+>/g," ")}function Ft(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function F(t){return Ft(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function c(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let dt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",$=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>v(t)).filter(Boolean);for(;$.length<3;)$.push("");let q=[],ct=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(ct){let t=document.createElement("div");t.innerHTML=ct.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),q=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let U=q.join(" "),ut=t=>{let e=U.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},mt=ut("telp"),ft=ut("fax"),B=(U.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],N=(U.match(/https?:\/\/[^\s;,]+/)||[""])[0],E=U.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");B&&(E=E.split(B).join("")),N&&(E=E.split(N).join("")),E=E.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let $t=["Alamat: "+E,mt?"Telp: "+mt:"",ft?"Fax: "+ft:""].filter(Boolean).join(", "),Ut=[B?"Email: "+B:"",N?"Website: "+N:""].filter(Boolean).join(", ");q=[$t,Ut].filter(Boolean);let Q=v(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",O=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let r=v(e[0]),o=v(e[2]),l=v(e[3]),s=v(e[5]);r&&O.push([r,o]),l&&O.push([l,s])}});let L=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],k=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),C=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",r=!1,o=t.querySelector(".section-title");if(o)e=v(o),r=!0;else{let p=f=>f.split(":")[0].trim();for(let f of Array.from(t.children).slice(0,3)){let u=v(f);if(u&&u.length<=24&&L.includes(k(p(u)))){e=p(u);break}}if(!e){let f=(t.textContent||"").split(`
`).map(u=>u.trim()).find(Boolean)||"";f&&L.includes(k(p(f)))&&(e=p(f))}if(!e)return}let l=document.createElement("div");l.innerHTML=t.innerHTML,l.querySelector(".section-title")?.remove();let s=l.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(p=>p.split(/<br\s*\/?>|\n/).map(f=>F(f.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(p=>p.length),m=[],n=[];s.forEach((p,f)=>{p.forEach((u,I)=>{f>0&&I===0&&m.length&&n.push(m.length),m.push(u)})});let a=m;if(!r&&a.length&&k(a[0])===k(e)){a.shift();for(let p=0;p<n.length;p++)n[p]-=1;for(;n.length&&n[0]<=0;)n.shift()}a.length>1&&!/^[IVXLC]+\.\s/.test(a[0])&&!/:\s*$/.test(a[0])&&a.slice(1).some(p=>/^II\.\s/.test(p))&&(a[0]="I. "+a[0]),e&&C.push({title:e,items:a,para:n})});let Bt=/^catatan\s*:?/i,Nt=/^icd[\s-]*o\b\s*:?/i,X=[];for(let t of C){let e=[{title:t.title,items:[],para:[]}],r=e[0],o=!1,l=(s,m)=>{r={title:s,items:[],para:[],bare:m},e.push(r),o=!0};if(t.items.forEach((s,m)=>{let n=s.match(Bt),a=n?null:s.match(Nt);if(n){k(r.title)!=="catatan"&&l("Catatan");let p=s.slice(n[0].length).trim();p&&(t.para.includes(m)&&r.para.push(r.items.length),r.items.push(p));return}if(a){k(r.title)!=="icdo"&&l("ICD-0",!0),t.para.includes(m)&&r.para.push(r.items.length),r.items.push(s);return}t.para.includes(m)&&r.para.push(r.items.length),r.items.push(s)}),o)for(let s of e)s.items.length&&X.push(s);else X.push(e[0])}C.length=0,C.push(...X),C.forEach((t,e)=>t._i=e),C.sort((t,e)=>{let r=t._i??0,o=e._i??0,l=L.indexOf(k(t.title)),s=L.indexOf(k(e.title)),m=l===-1?L.length:l,n=s===-1?L.length:s;return m!==n?m-n:r-o});function Ot(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let r=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),o=t.getAttribute("placeholder")||"",l=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(r+" "+o+" "+l).slice(0,300)}}function Kt(t,e,r){let o=e.toLowerCase().split(/[^a-z0-9]+/).filter(n=>n.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(n));if(!o.length)return"";let l=o.sort((n,a)=>a.length-n.length)[0],s="",m=-1;return t.querySelectorAll("input, textarea, select").forEach(n=>{let{val:a,ctx:p}=Ot(n);if(!a||a===e||!a.toLowerCase().includes(l))return;let f=r.test(p)?2:0;f>m&&(m=f,s=a)}),s}function _t(t,e){return(t.querySelector(e)?.value||"").trim()}async function Gt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let r=n=>/ket\w*\s*klinis/i.test(n),o=n=>/^dokter/i.test(n)||/^rs\b/i.test(n),l=t.map(([n,a],p)=>({label:n,value:a,idx:p})).filter(n=>o(n.label)?!!n.value:r(n.label));if(!l.length)return;let s=new AbortController,m=window.setTimeout(()=>s.abort(),6e3);try{let n=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),a=await fetch(n.toString(),{credentials:"same-origin",signal:s.signal});if(!a.ok){window.console.info("[paPrint] override: fetch input status "+a.status);return}let p=await a.text(),f=new DOMParser().parseFromString(p,"text/html");window.console.info('[paPrint] override: input title="'+(f.title||"").slice(0,60)+'" len='+p.length+" fields="+f.querySelectorAll("input, textarea, select").length);for(let u of l){if(r(u.label)){let et=_t(f,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),x=F(pt(et));window.console.info("[paPrint] override: "+u.label+' cetak="'+u.value+'" input="'+x+'"'),x&&x!==u.value&&(t[u.idx][1]=x);continue}let I=/^dokter/i.test(u.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,H=Kt(f,u.value,I),R=F(pt(H||""));window.console.info("[paPrint] override: "+u.label+' cetak="'+u.value+'" input="'+R+'"'),R&&R!==u.value&&(t[u.idx][1]=R)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(m)}}await Gt(O).catch(()=>{});let z=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>v(t)).filter(Boolean),gt=z[0]||"",ht=z[1]||"",K=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",bt=z.find(t=>/^\(.*\)$/.test(t))||z[2]||"",kt=z.find(t=>/^nip\.?/i.test(t))||z[3]||"",xt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Jt=Array.from(document.body.querySelectorAll("script")),Vt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),P=O.map(([t,e])=>{if(/^(cara|care)\s+peroleh(an)?$/i.test(t.trim()))return["Cara Perolehan",e];if(!/^ruang/i.test(t))return[t,e];let r=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,o=r.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||r,l=o.split(/\s+-\s*/);if(l.length>=3&&/rawat\s+inap/i.test(l[1])){let s=Vt(l[1].trim()),m=l.slice(2).join(" - ").trim(),n=m?s+" - "+m:s;if(n)return[t,n]}return[t,o]}),Wt=P.map(([t,e])=>'<div class="info-item"><div class="info-label">'+c(t)+'</div><div class="info-colon">:</div><div class="info-value">'+c(e)+"</div></div>").join(""),Z=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+c(t)+"</strong>":c(t),Qt=t=>/^catatan/i.test(t.trim()),Y=t=>/^saran/i.test(t.trim()),yt=t=>Qt(t)||Y(t),Xt=t=>Y(t)?"Saran:":"Catatan:",tt=t=>t.replace(/^(catatan|saran)\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),Zt=P.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function vt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(r=>{if(!r.ok)throw new Error("img "+r.status);return r.blob()}).then(r=>new Promise((o,l)=>{let s=new FileReader;s.onload=()=>o(String(s.result)),s.onerror=()=>l(s.error),s.readAsDataURL(r)})).catch(()=>e)}async function Yt(){let t=st(S),[e,r]=await Promise.all([vt(dt),K?vt(K):Promise.resolve("")]),o="";for(let a=0;a<P.length;a+=2){let p=P[a],f=P[a+1];o+="<tr><td>"+c(p[0])+"</td><td>:</td><td>"+c(p[1])+"</td>"+(f?"<td>"+c(f[0])+"</td><td>:</td><td>"+c(f[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let l="";for(let a of C){if(yt(a.title)){let x=a.items.length?a.items:["Tidak ada"],D=x.length>1,T=Y(a.title)?"SARAN:":"CATATAN:";l+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+T+'</b></td><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';">'+x.map(_=>(D?"- ":"")+"<b>"+c(tt(_)||"Tidak ada")+"</b>").join("<br>")+"</td></tr></table>";continue}if(a.bare){a.items.forEach((x,D)=>{l+='<p style="margin:'+(D===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+c(x.toUpperCase())+"</b></p>"});continue}let p=["makroskopik","mikroskopik","kesimpulan"].includes(k(a.title)),f=k(a.title)==="icdo";l+='<p style="margin:12pt 0 0 0;font-size:'+(f?t.isi.fs:t.judul.fs)+'pt;"><b>'+(p?"<u>":"")+c(a.title.toUpperCase())+(p?"</u>":"")+"</b></p>";let u=k(a.title)==="kesimpulan",I=k(a.title)==="icdo",H=u||I||k(a.title)==="saran",R=u?t.kesimpulan.fs:t.isi.fs,et=u?t.kesimpulan.lh:t.isi.lh;a.items.forEach((x,D)=>{let T=V(x),_=a.items.length===1&&T!==null&&/^[-•–—*]$/.test(T[0]),At=_?tt(x)||T[1]:x,ee=H?"<b>"+c(At)+"</b>":Z(At),ae=T&&!_?"margin-left:18pt;text-indent:-18pt;":"";l+='<p style="margin:'+(a.para.includes(D)?"4pt":"0")+" 0 6pt 0;font-size:"+R+"pt;line-height:"+et+";text-align:justify;"+ae+'">'+ee+"</p>"})}let s='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+c(Q)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+$.slice(0,3).map(a=>'<b style="font-size:'+t.kop.fs+'pt;">'+c(a)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+q.map(a=>c(a)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+c(Q.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+o+"</table>"+l+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+c(gt)+'</p><p style="margin:0 0 6pt 0;">'+c(ht)+"</p>"+(r?'<p style="margin:0 0 6pt 0;"><img src="'+r+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+c(bt)+'</b></p><p style="margin:0 0 6pt 0;">'+c(kt)+"</p></td></tr></table></body></html>",m=new Blob(["\uFEFF"+s],{type:"application/msword"}),n=document.createElement("a");n.href=URL.createObjectURL(m),n.download="Hasil-PA-"+Zt+".doc",document.body.appendChild(n),n.click(),window.setTimeout(()=>{URL.revokeObjectURL(n.href),n.remove()},4e3)}let te=C.map(t=>{if(yt(t.title)){let a=t.items.length?t.items:["Tidak ada"],p=a.length>1;return'<div class="section-catatan"><span class="catatan-label">'+Xt(t.title)+'</span><div class="catatan-list">'+a.map(f=>{let u="<span>"+c(tt(f)||"Tidak ada")+"</span>";return p?'<div class="catatan-item"><span class="catatan-dash">-</span>'+u+"</div>":'<div class="catatan-item">'+u+"</div>"}).join("")+"</div></div>"}let e=k(t.title)==="kesimpulan",r=k(t.title)==="icdo",o=e||r||k(t.title)==="saran",l='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+(r&&!t.bare?" section-icdo":"")+'">'+t.items.map((a,p)=>{let f=t.para.includes(p)?" item-para":"",u=V(a),I=!u&&/:\s*$/.test(a)&&p+1<t.items.length&&!!V(t.items[p+1])&&t.para.includes(p+1);if(u&&!(t.items.length===1&&/^[-•–—*]$/.test(u[0]))){let H=o?"<strong>"+c(u[1])+"</strong>":Z(u[1]);return'<div class="item-list has-marker'+f+'"><span class="item-marker">'+(o?"<strong>"+c(u[0])+"</strong>":c(u[0]))+"</span><span>"+H+"</span></div>"}return'<div class="item-list'+f+(I?" item-intro":"")+'">'+(o?"<strong>"+c(a)+"</strong>":Z(a))+"</div>"}).join("")+"</div>";if(t.bare)return l;let s=k(t.title),m=["makroskopik","mikroskopik","kesimpulan"].includes(s)?" u":"",n=s==="icdo"?" i":"";return'<div class="section-judul'+m+n+'">'+c(t.title)+"</div>"+l}).join("");document.body.innerHTML='<a href="'+c(xt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+c(dt)+'" alt="Logo"></div><div class="kop-text">'+$.slice(0,3).map(t=>'<h1 class="kop-atas">'+c(t)+"</h1>").join("")+'<div class="kop-alamat">'+q.map(t=>c(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+c(Q)+'</div><div class="patient-info-container">'+Wt+'</div><div class="hasil-pa">'+te+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+c(gt)+"</p><p>"+c(ht)+"</p>"+(K?'<img src="'+c(K)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+c(bt)+'</p><p style="margin-top: 2px;">'+c(kt)+"</p></div></div></div>",Jt.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),Yt().catch(()=>{window.location.href=xt})});let wt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(o,l,s,m,n,a,p,f)=>"<label>"+c(s)+'<input type="range" data-g="'+c(o)+'" data-f="'+l+'" min="'+m+'" max="'+n+'" step="'+a+'" value="'+p+'"><output data-o="'+c(o+"-"+l)+'">'+c(String(p)+f)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+zt.map(o=>'<div class="t-typo-group"><strong>'+c(o.label)+'</strong><div class="t-typo-row">'+e(o.key,"fs","Font (pt)",4,20,.5,S[o.key].fs,"pt")+e(o.key,"lh","Spasi baris",.5,2.5,.05,S[o.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(o=>{let l=o;l.addEventListener("input",()=>{let s=l.dataset.g,m=l.dataset.f;if(!s||!m||!S[s])return;S[s][m]=Number(l.value),W();let n=t.querySelector(`output[data-o="${s}-${m}"]`);n&&(n.textContent=l.value+(m==="fs"?"pt":""))})});let r=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let o=qt(A(),S);r&&(r.textContent=o?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Pt(A()),S=lt(A()),W(),wt(),r){let o=t.querySelector("[data-note]");o&&(o.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&wt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let jt="ext-pa-print-style";if(!document.getElementById(jt)){let t=document.createElement("style");t.id=jt,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-transform: uppercase;
        }

        /* Garis bawah hanya untuk header Makroskopik/Mikroskopik/Kesimpulan
           (permintaan user 2026-11-06). */
        .section-judul.u {
            text-decoration: underline;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Isi ICD-O yang dirender server DENGAN judul section sendiri:
           menyatu dengan Catatan/Saran \u2192 ikut grup Isi yang sama
           (user 2026-11-06), selalu bold.
           Varian tanpa judul memakai .section-isi-bare (grup Isi sama). */
        .section-icdo {
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Header ICD-O berjudul menyatu dengan isinya \u2192 grup Isi
           (bukan Judul), supaya header+isi sama besar. */
        .section-judul.i {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Hanging indent: baris bernomor/berpoin \u2014 penanda di kolom
           kiri tetap, teks lanjutan sejajar di bawah teks. */
        /* Hanging indent: penanda (I., II., VII., ...) di kolom kiri tetap
           (posisi absolut), teks paragraf mulai di indent tetap sehingga
           baris lanjutan & antar item sejajar meski lebar penanda beda. */
        .item-list.has-marker {
            position: relative;
            padding-left: 2ch;
        }

        .item-marker {
            position: absolute;
            left: 0;
            top: 0;
            white-space: nowrap;
        }

        /* Item tanpa penomoran dalam section yang punya penomoran (mis.
           "Diterima 2 buah jaringan..." di Makroskopik) ikut terindent
           agar sejajar dengan teks setelah Romawi. */
        .section-isi:has(.item-list.has-marker) .item-list:not(.has-marker) {
            padding-left: 2ch;
        }

        /* Baris pengantar yang dipisah baris kosong \u2192 rata kiri. */
        .section-isi:has(.item-list.has-marker) .item-list.item-intro {
            padding-left: 0;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap rapat. */
        .item-list.item-para {
            margin-top: 4px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah), dan memakai grup
           Isi yang sama dengan Catatan/Saran (user 2026-11-06). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN & SARAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya).
           Header dan isi menyatu dalam satu baris, jadi keduanya memakai
           grup Isi yang sama (\u2699\uFE0F Gaya \u2192 Isi), sama besar dengan isi \u2014
           sesuai permintaan user 2026-11-06. Seluruh isinya bold. */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
            font-weight: bold;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let g=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),i().catch(()=>{})):Date.now()-g>5e3&&window.clearInterval(h)},200)})})();
