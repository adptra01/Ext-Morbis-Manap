"use strict";var __morbis_feature=(()=>{function E(){return window}var x="RSUD H. Abdul Manap",v=E(),$=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],g=r=>document.getElementById(r)?.value?.trim()||"";function A(r){let a=e=>{let t=document.createElement("span");return t.className="fv",t.textContent=e,t};r.querySelectorAll("input").forEach(e=>{let t=(e.type||"text").toLowerCase();if(t==="hidden"){e.remove();return}if(t==="radio"||t==="checkbox"){if(!e.checked){e.remove();return}if(t==="radio"){e.replaceWith(a("\u2713"));return}let i=(e.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,s=>s.toUpperCase());e.replaceWith(a(i?"\u2713 "+i:"\u2713"));return}let l=(e.value||"").trim();l?e.replaceWith(a(l)):e.remove()}),r.querySelectorAll("textarea").forEach(e=>{let t=(e.value||"").trim();t?e.replaceWith(a(t)):e.remove()}),r.querySelectorAll("select").forEach(e=>{let t=(e.options[e.selectedIndex]?.textContent||e.value||"").trim();t?e.replaceWith(a(t)):e.remove()})}function B(r){try{let a=r.getContext("2d");if(!a||!r.width||!r.height)return!0;let e=a.getImageData(0,0,r.width,r.height).data,t=388,l=0,i=0;for(let n=0;n<e.length;n+=t)l+=(e[n]+e[n+1]+e[n+2])/3,i++;let s=l/Math.max(i,1);return s<8||s>250}catch{return!1}}function C(r){r.querySelectorAll("table").forEach(a=>{if(a.parentElement?.closest("table"))return;let e=Array.from(a.rows),t=e[0]?.cells.length||0;e.length<6||t<4||a.querySelector(".vcol")||e.forEach((l,i)=>{let s=Array.from(l.cells);if(!(!s.length||s.some(n=>n.colSpan>=3)))if(i===0){let n=document.createElement("th");n.className="vcol",n.textContent="Ver",l.appendChild(n)}else{let n=document.createElement("td");n.className="vcol";let c=document.createElement("span");c.className="box",n.appendChild(c),l.appendChild(n)}})})}var z=/Rincian Biaya|Resume|Telaah|Laboratorium|Radiologi|SPRI|SBPK/i;function k(r,a=!1){let e=r.cloneNode(!0),t=Array.from(r.querySelectorAll("canvas")),l=Array.from(e.querySelectorAll("canvas"));return t.forEach((i,s)=>{let n=l[s];if(n){if(B(i)){n.remove();return}try{let c=document.createElement("img");c.src=i.toDataURL("image/png"),c.style.cssText="max-width:100%;height:auto;",n.replaceWith(c)}catch{let c=document.createElement("div");c.className="fv",c.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",n.replaceWith(c)}}}),A(e),$.forEach(i=>e.querySelectorAll(i).forEach(s=>s.remove())),e.querySelectorAll("tr").forEach(i=>{let s=Array.from(i.cells);for(let n=s.length-1;n>=0;n--){let c=s[n];if(!(!(c.textContent||"").trim()&&!c.querySelector("img,table,input")))break;c.remove()}}),e.querySelectorAll("[style]").forEach(i=>{let s=((i.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");s?i.setAttribute("style",s):i.removeAttribute("style")}),e.removeAttribute("id"),e.removeAttribute("class"),e.removeAttribute("style"),e.querySelectorAll("div").forEach(i=>{!i.children.length&&!(i.textContent||"").trim()&&i.remove()}),a&&C(e),e.innerHTML.trim()}function T(r,a){let e=(r.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return e=e.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),e||`Berkas ${String(a+1).padStart(2,"0")}`}function R(){let r=Array.from(document.querySelectorAll(".isidalam")),a=new Set,e=[],t=[];if(r.forEach((l,i)=>{let s=T(l,i);if(a.has(s))return;a.add(s);let n=k(l,z.test(s));if(n.length<20){t.push({title:s,docNo:null});return}e.push({title:s,html:n}),t.push({title:s,docNo:e.length})}),!e.length){let l=document.querySelector("#section-to-print");if(l){let i="Detail Klaim";e.push({title:i,html:k(l)}),t.push({title:i,docNo:1})}}return{sections:e,inventory:t}}var u=r=>r.replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[a]),L=r=>(new DOMParser().parseFromString(r.replace(/src="data:[^"]*"/g,""),"text/html").body.textContent||"").replace(/\s+/g," ").trim(),N=r=>{let a=r.split(/[-/]/).map(i=>i.trim());if(a.length!==3)return r;let[e,t,l]=a;return e.length===4?`${e}-${t.padStart(2,"0")}-${l.padStart(2,"0")}`:`${l}-${t.padStart(2,"0")}-${e.padStart(2,"0")}`},I=/(?:Tgl|Tanggal)\.?\s*Masuk(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,M=/(?:Tgl|Tanggal)\.?\s*(?:Keluar|Pulang)(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,y=/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]{8,})/gi;function q(r,a){let e=[],t=r.map(o=>({t:o.title,x:L(o.html)})),l=o=>{let p=[],h=new Set;return t.forEach(b=>{let W=new RegExp(o.source,o.flags),f;for(;f=W.exec(b.x);){let S=b.t+"|"+f[1];h.has(S)||(h.add(S),p.push({t:b.t,d:o===y?f[1]:N(f[1])}))}}),p},i=l(I);new Set(i.map(o=>o.d)).size>1&&e.push({level:"warn",title:"Tanggal masuk berbeda antar berkas",detail:i.map(o=>`${o.t} ${o.d}`).join(" \xB7 ")+" \u2014 samakan sebelum berkas dikirim ke verifikator."});let s=l(M);if(i.length&&s.length){let o=i.map(h=>h.d).sort()[0],p=s.map(h=>h.d).sort().pop();p<o&&e.push({level:"warn",title:"Tanggal keluar lebih awal dari tanggal masuk",detail:`Masuk ${o} \xB7 Keluar ${p}.`})}let n=l(y);new Set(n.map(o=>o.d)).size>1&&e.push({level:"warn",title:"Nomor SEP berbeda antar lembar",detail:n.map(o=>`${o.t} ${o.d}`).join(" \xB7 ")});let c=[/^SEP$/i,/SBPK/i,/Resume/i,/Rincian Biaya/i],d=a.filter(o=>o.docNo===null&&c.some(p=>p.test(o.title)));d.length&&e.push({level:"warn",title:"Berkas inti belum terisi",detail:d.map(o=>o.title).join(", ")+"."});let m=t.find(o=>/Rincian Biaya/i.test(o.t));return m&&!/Total\s+(Biaya|Transaksi|Resep|Jasa)/i.test(m.x)&&e.push({level:"warn",title:"Rincian biaya tanpa baris total",detail:"Tidak ditemukan Total Biaya/Transaksi/Resep pada lembar Rincian Biaya."}),["Laboratorium","Radiologi"].forEach(o=>{let p=t.find(h=>new RegExp(o,"i").test(h.t));p&&p.x.length<60&&e.push({level:"info",title:`Lembar ${o} hanya lampiran gambar`,detail:"Tidak ada teks hasil yang bisa dicocokkan otomatis \u2014 cocokkan manual dengan Resume dan Rincian Biaya."})}),e}function P(r,a){let e="/assets/images/logo/Kota Jambi.png",t=(d,m)=>`<div class="meta-item"><span class="meta-label">${u(d)}</span><span class="meta-value">${u(m||"\u2014")}</span></div>`,l=a.filter(d=>d.docNo!==null).length,i=a.map(d=>{let m=d.docNo!==null;return`<tr>
        <td class="c-no">${m?String(d.docNo).padStart(2,"0"):"\u2014"}</td>
        <td>${u(d.title)}</td>
        <td class="c-stat">${m?"Ada":'<span class="st-empty">Tidak terisi</span>'}</td>
        <td class="c-ver"><span class="box"></span></td>
      </tr>`}).join(""),s=q(r,a),n=s.length?`<section class="checks">
  <h2>Catatan Pemeriksaan Otomatis</h2>
  <ul>${s.map(d=>`<li class="check ${d.level}"><span class="mark">${d.level==="warn"?"\u25B2":"\u2022"}</span><span><b>${u(d.title)}</b> \u2014 ${u(d.detail)}</span></li>`).join("")}</ul>
</section>`:"",c=r.map((d,m)=>`
      <section class="doc">
        <div class="doc-head">
          <span class="doc-num">${String(m+1).padStart(2,"0")}</span>
          <h2>${u(d.title)}</h2>
          <span class="doc-rule"></span>
        </div>
        <div class="doc-body">${d.html}</div>
      </section>`).join("");return`<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<base href="${u(location.origin)}">
<title>Dossier Cetak M-KLAIM \u2014 ${u(x)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,500;8..60,700&display=swap" rel="stylesheet">
<style>
:root{
  --ink:#17212b; --muted:#5b6b78; --accent:#0f766e; --accent-soft:#e6f4f1;
  --paper:#fdfcf9; --rule:#d7dee2; --chip:#f1f5f4;
  --sans:'IBM Plex Sans','Segoe UI',sans-serif; --serif:'Source Serif 4',Georgia,serif;
}
@page{size:A4;margin:14mm 13mm;}
*{box-sizing:border-box;}
html,body{margin:0;padding:0;}
body{
  background:var(--paper); color:var(--ink); font-family:var(--sans);
  font-size:11px; line-height:1.55; padding:22px 26px;
  -webkit-print-color-adjust:exact; print-color-adjust:exact;
}
.cover{
  display:grid; grid-template-columns:64px 1fr; gap:16px; align-items:center;
  border-bottom:3px double var(--ink); padding-bottom:14px; margin-bottom:18px;
}
.cover img{width:64px;height:64px;object-fit:contain;}
.eyebrow{font-size:9px;letter-spacing:.22em;text-transform:uppercase;color:var(--accent);font-weight:700;}
.cover h1{font-family:var(--serif);font-size:22px;line-height:1.15;margin:3px 0 2px;font-weight:700;}
.cover .sub{font-size:10px;color:var(--muted);}
.meta{
  display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 16px;
  border-top:1px solid var(--ink);border-bottom:1px solid var(--rule);
  padding:10px 0;margin-bottom:12px;background:transparent;
}
.meta-item{display:flex;flex-direction:column;gap:2px;min-width:0;}
.meta-label{font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;}
.meta-value{font-weight:600;font-size:11px;overflow-wrap:anywhere;}
/* Lembar Kendali \u2014 inventaris berkas (halaman 1) */
.control{margin:0 0 10px;}
.control h2{
  font-family:var(--serif);font-size:13px;margin:0 0 2px;text-transform:uppercase;
  letter-spacing:.06em;
}
.control .note{font-size:9px;color:var(--muted);margin:0 0 8px;}
.ctl{width:100%;border-collapse:collapse;font-size:9.5px;}
.ctl th{
  border-bottom:1px solid var(--ink);text-align:left;padding:3px 6px;
  font-size:8px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);font-weight:700;
}
.ctl td{border-bottom:1px solid var(--rule);padding:3px 6px;vertical-align:middle;}
.ctl tr:last-child td{border-bottom:1px solid var(--ink);}
.ctl .c-no{width:26px;color:var(--muted);font-variant-numeric:tabular-nums;}
.ctl .c-stat{width:92px;}
.ctl .c-ver{width:74px;text-align:center;}
.st-empty{color:var(--muted);font-style:italic;}
.box{display:inline-block;width:11px;height:11px;border:1px solid var(--ink);vertical-align:-2px;}
.ctl-sum{margin:6px 0 0;font-size:9px;color:var(--muted);}
/* Catatan pemeriksaan otomatis */
.checks{margin:14px 0 0;}
.checks h2{font-family:var(--serif);font-size:12px;margin:0 0 4px;text-transform:uppercase;letter-spacing:.06em;}
.checks ul{list-style:none;margin:0;padding:0;}
.check{display:flex;gap:7px;padding:4px 0;border-bottom:1px solid var(--rule);font-size:9.5px;line-height:1.45;}
.check .mark{flex:0 0 10px;font-weight:700;}
.check.warn .mark{color:#8a1c1c;}
.check.info .mark{color:var(--muted);}
/* Kolom Verifikasi pada tabel */
.doc-body .vcol{width:18px!important;padding:4px 2px!important;text-align:center!important;}
.img-wrap{display:inline-block;max-width:100%;}
.img-tools{display:flex;gap:6px;justify-content:flex-end;margin:0 0 5px;}
.img-tools button{
  font:inherit;font-size:10px;padding:3px 9px;border:1px solid var(--rule);
  background:#fff;border-radius:4px;cursor:pointer;color:var(--muted);
}
.img-tools button:hover{border-color:var(--accent);color:var(--accent);}
.doc{margin:0 0 24px;break-inside:avoid-page;}
.doc-head{display:flex;align-items:baseline;gap:10px;margin-bottom:8px;border-bottom:1px solid var(--ink);padding-bottom:5px;}
.doc-num{
  font-family:var(--serif);font-size:15px;color:var(--accent);font-weight:700;
  min-width:24px;
}
.doc-head h2{
  font-family:var(--serif);font-size:13px;margin:0;text-transform:uppercase;
  letter-spacing:.06em;
}
.doc-rule{display:none;}
.doc-body{background:transparent;border:0;border-radius:0;padding:2px 0 0;}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 10px;border:0!important;}
.doc-body th,.doc-body td{border:0!important;border-bottom:1px solid var(--rule)!important;padding:5px 7px;font-size:10px!important;text-align:left;vertical-align:top;overflow-wrap:anywhere;}
.doc-body th{background:transparent!important;font-weight:700;color:var(--ink);border-bottom:1px solid var(--ink)!important;letter-spacing:.04em;text-transform:uppercase;font-size:9px!important;}
.doc-body h1,.doc-body h2,.doc-body h3{font-family:var(--serif);font-size:13px;margin:6px 0;}
.doc-body p{margin:3px 0;}
.doc-body label{display:inline-block;min-width:112px;font-weight:600;color:var(--muted);font-size:9px;letter-spacing:.02em;text-transform:uppercase;}
.doc-body .fv{font-weight:500;color:var(--ink);}
.doc-body img{max-width:100%!important;height:auto!important;}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important;}
.screen-bar{
  position:sticky;top:0;z-index:9;display:flex;justify-content:flex-end;gap:8px;
  background:rgba(253,252,249,.94);backdrop-filter:blur(6px);
  padding:8px 0 12px;margin:-22px -26px 14px;padding-left:26px;padding-right:26px;
  border-bottom:1px solid var(--rule);
}
.screen-bar button{font:inherit;font-size:11px;font-weight:600;cursor:pointer;border-radius:5px;padding:7px 14px;}
.btn-print{background:var(--accent);color:#fff;border:1px solid var(--accent);}
.btn-close{background:#fff;color:var(--ink);border:1px solid var(--rule);}
.sign{display:flex;justify-content:flex-end;margin-top:26px;}
.sign-box{width:230px;text-align:center;font-size:10px;color:var(--muted);}
.sign-space{height:52px;}
@media print{
  .screen-bar,.img-tools{display:none!important;}
  body{padding:0;background:#fff;font-size:10px;}
  main{break-before:page;}
  .doc{break-after:page;}
  .doc:last-child{break-after:auto;}
  /* Header tabel diulang tiap halaman + baris tidak terpotong di batas kertas */
  .doc-body thead{display:table-header-group;}
  .doc-body tr,.sign-box{break-inside:avoid;page-break-inside:avoid;}
  .meta,.doc-body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}
}
@media screen and (max-width:900px){
  .meta{grid-template-columns:repeat(2,minmax(0,1fr));}
}
</style>
</head>
<body>
<div class="screen-bar">
  <button type="button" class="btn-close" id="close-view">Tutup</button>
  <button type="button" class="btn-print" id="print-view">\u{1F5A8} Cetak</button>
</div>
<header class="cover">
  <img src="${u(e)}" alt="Logo">
  <div>
    <div class="eyebrow">Dossier Cetak \xB7 Detail Klaim</div>
    <h1>${u(x)}</h1>
    <div class="sub">Laporan lengkap berkas klaim &bull; ${new Date().toLocaleString("id-ID")}</div>
  </div>
</header>
<div class="meta">
  ${t("No. RM",g("norm"))}
  ${t("Nama Pasien",g("nama"))}
  ${t("No. Registrasi",g("no_registrasi")||g("reg"))}
  ${t("ID Visit",g("id_visit"))}
  ${t("Tanggal Awal",g("tanggalAwal"))}
  ${t("Tanggal Akhir",g("tanggalAkhir"))}
  ${t("Status",g("status"))}
  ${t("Billing",g("billing"))}
</div>
<section class="control">
  <h2>Lembar Kendali Berkas Klaim</h2>
  <p class="note">Nomor mengacu pada nomor berkas di dossier. Centang kolom Verifikasi setelah berkas diperiksa.</p>
  <table class="ctl">
    <thead><tr><th class="c-no">No</th><th>Nama Berkas</th><th class="c-stat">Status</th><th class="c-ver">Verifikasi</th></tr></thead>
    <tbody>${i}</tbody>
  </table>
  <p class="ctl-sum">${a.length} berkas terdaftar &middot; ${l} berisi &middot; ${a.length-l} tidak terisi</p>
</section>
${n}
<main>${c}</main>
<div class="sign"><div class="sign-box">
  <div>Petugas Verifikasi</div><div class="sign-space"></div>
  <div><strong>( .................................... )</strong></div>
</div></div>
</body>
</html>`}function K(r){let a=r.document,e=t=>{if(t.dataset.tools||!t.naturalWidth||t.naturalWidth<260||t.closest("table"))return;t.dataset.tools="1";let l=a.createElement("span");l.className="img-wrap",t.parentNode?.insertBefore(l,t),l.appendChild(t);let i=a.createElement("span");i.className="img-tools";let s=(n,c)=>{let d=a.createElement("button");return d.type="button",d.dataset.act=c,d.textContent=n,d};i.appendChild(s("\u21BB Rotasi 90\xB0","rot")),i.appendChild(s("Hapus","del")),l.insertBefore(i,t),i.addEventListener("click",n=>{let c=n.target.closest("button")?.dataset.act;if(c==="del"){l.remove();return}if(c!=="rot")return;let d=t.naturalWidth,m=t.naturalHeight;if(!d||!m)return;let o=a.createElement("canvas");o.width=m,o.height=d;let p=o.getContext("2d");if(p){p.translate(m/2,d/2),p.rotate(Math.PI/2),p.drawImage(t,-d/2,-m/2);try{t.src=o.toDataURL("image/png")}catch{}}})};a.querySelectorAll(".doc-body img").forEach(t=>{t.complete?e(t):t.addEventListener("load",()=>e(t),{once:!0})})}function D(){let{sections:r,inventory:a}=R();if(!r.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let e=window.open("","_blank");if(!e){window.alert("Popup diblokir \u2014 izinkan popup untuk membuka dossier cetak M-KLAIM.");return}e.document.open(),e.document.write(P(r,a)),e.document.close(),K(e);let t=()=>{try{e.focus(),e.print()}catch{}};e.document.getElementById("print-view")?.addEventListener("click",t),e.document.getElementById("close-view")?.addEventListener("click",()=>{e.confirm("Tutup halaman cetak ini?")&&e.close()}),e.addEventListener("afterprint",()=>{e.confirm("Apakah menu print ini akan ditutup?")&&e.close()}),e.setTimeout(t,600)}function j(){let r=Array.from(document.querySelectorAll("button.btn-success")).find(a=>/^printDiv\s*\(/i.test(a.getAttribute("onclick")||""));return r?.parentElement?r.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(a=>a.querySelector("button"))||document.getElementById("SCETAK")||document.body}function w(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor")||document.getElementById("ext-mklaim-print-btn"))return;let r=j(),a=document.createElement("button");a.id="ext-mklaim-print-btn",a.type="button",a.className="btn btn-primary btn-sm",a.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",a.innerHTML="\u{1F5A8} Cetak Rapi M-KLAIM",a.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),D()}),r.appendChild(a)}typeof v.featureModules<"u"&&(v.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let r=()=>w();document.readyState==="complete"?window.setTimeout(r,500):window.addEventListener("load",()=>window.setTimeout(r,500));let a=()=>{let e=document.getElementById("ext-mklaim-print-btn");e?.parentElement&&e.parentElement.lastElementChild!==e&&e.parentElement.appendChild(e)};new MutationObserver(()=>{document.getElementById("ext-mklaim-print-btn")?a():w()}).observe(document.body,{childList:!0,subtree:!0}),window.setInterval(a,1500)}})})();
