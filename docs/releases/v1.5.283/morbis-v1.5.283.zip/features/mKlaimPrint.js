"use strict";var __morbis_feature=(()=>{function Qt(){return window}var mt="RSUD H. Abdul Manap";function Kt(i){let L=()=>{try{i.focus(),i.print()}catch{}},a=i.document;a.getElementById("btnPrintPdf")?.addEventListener("click",L);let e=Array.from(a.querySelectorAll(".rm-page")),n=a.getElementById("rmSectionSelect"),r=Array.from(a.querySelectorAll(".tab-btn")),s=p=>{n&&(n.value=p),r.forEach(z=>z.classList.toggle("active",z.dataset.target===p)),e.forEach(z=>{let N=p==="all"||z.id===p||z.id.startsWith(`${p}-`);z.classList.toggle("hidden-section",!N)}),i.scrollTo({top:0,behavior:"smooth"})};n?.addEventListener("change",p=>s(p.target.value)),r.forEach(p=>p.addEventListener("click",()=>s(p.dataset.target||"all")));let l=a.getElementById("checkCounter"),o=Array.from(a.querySelectorAll(".rm-checkbox, .vbox")),y=()=>{l&&(l.textContent=`${o.filter(p=>p.checked).length} / ${o.length}`)};o.forEach(p=>p.addEventListener("change",y)),a.getElementById("btnCheckAll")?.addEventListener("click",()=>{o.forEach(p=>p.checked=!0),y()}),a.getElementById("btnResetChecks")?.addEventListener("click",()=>{o.forEach(p=>p.checked=!1),y()}),y();let C=(p,z)=>{let N=a.createElement("button");return N.type="button",N.className="ext-scroll-btn no-print",N.textContent=p,N.addEventListener("click",z),N},m=C("\u2191",()=>i.scrollTo({top:0,behavior:"smooth"})),$=C("\u2193",()=>i.scrollTo({top:a.documentElement.scrollHeight,behavior:"smooth"})),h=a.createElement("style");h.textContent=".ext-scroll-btn{position:fixed;right:14px;width:34px;height:34px;border:1px solid #000;background:#fff;font-size:16px;font-weight:bold;cursor:pointer;z-index:9999;display:flex;align-items:center;justify-content:center}.ext-scroll-btn:first-of-type{bottom:56px}.ext-scroll-btn:last-of-type{bottom:14px}",a.head.appendChild(h),a.body.appendChild(m),a.body.appendChild($),i.addEventListener("afterprint",()=>{i.confirm("Apakah menu print ini akan ditutup?")&&i.close()})}var bt=Qt(),Bt=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],At=i=>document.getElementById(i)?.value?.trim()||"",M=(...i)=>{for(let L of i){let a=At(L).replace(/^\s*:\s*/,"").trim();if(a)return a}return"-"};function Ft(i){let L=a=>{let e=document.createElement("span");return e.className="fv",e.textContent=a,e};i.querySelectorAll("input").forEach(a=>{let e=(a.type||"text").toLowerCase();if(e==="hidden"){a.remove();return}if(e==="radio"||e==="checkbox"){if(!a.checked){a.remove();return}if(e==="radio"){a.replaceWith(L("\u2713"));return}let r=(a.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,s=>s.toUpperCase());a.replaceWith(L(r?"\u2713 "+r:"\u2713"));return}let n=(a.value||"").trim();n?a.replaceWith(L(n)):a.remove()}),i.querySelectorAll("textarea").forEach(a=>{let e=(a.value||"").trim();e?a.replaceWith(L(e)):a.remove()}),i.querySelectorAll("select").forEach(a=>{let e=(a.options[a.selectedIndex]?.textContent||a.value||"").trim();e?a.replaceWith(L(e)):a.remove()})}function Gt(i){try{if(!i.width||!i.height)return!0;let L=64,a=document.createElement("canvas");a.width=L,a.height=L;let e=a.getContext("2d",{willReadFrequently:!0});if(!e)return!1;e.drawImage(i,0,0,L,L);let n=e.getImageData(0,0,L,L).data,r=0;for(let l=0;l<n.length;l+=4)r+=(n[l]+n[l+1]+n[l+2])/3;let s=r/(L*L);return s<8||s>250}catch{return!1}}function Jt(i){i.querySelectorAll("table").forEach(L=>{if(L.parentElement?.closest("table"))return;let a=Array.from(L.rows),e=a[0]?.cells.length||0;a.length<6||e<4||L.querySelector(".vcol")||a.forEach((n,r)=>{let s=Array.from(n.cells);if(!(!s.length||s.some(l=>l.colSpan>=3)))if(r===0){let l=document.createElement("th");l.className="vcol",l.textContent="Ver",n.appendChild(l)}else{let l=document.createElement("td");l.className="vcol";let o=document.createElement("input");o.type="checkbox",o.className="vbox",l.appendChild(o),n.appendChild(l)}})})}var Ht=/Rincian Biaya|Resume|Telaah|Laboratorium|Radiologi|SPRI|SBPK/i;function Wt(i){i.querySelectorAll(".tabel-juduls").forEach(a=>a.remove()),i.querySelectorAll("h1,h2,td").forEach(a=>{let e=(a.textContent||"").replace(/\s+/g," ").trim();/^RSUD H\.? ABDUL MANAP$/i.test(e)&&a.remove()}),i.querySelectorAll("tr").forEach(a=>{let e=(a.textContent||"").replace(/\s+/g," ").trim();(/^(RSUD H\.? ABDUL MANAP|PEMERINTAH KOTA JAMBI|Jl\. Sk\. Rd\. Syahbudin)/i.test(e)||/^(RINCIAN\s+BIAYA|LAPORAN|FORMULIR)/i.test(e)&&a.querySelector("u,b,strong"))&&a.remove()});let L=i.querySelector("table");L&&Array.from(i.querySelectorAll("hr")).forEach(a=>{L.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_PRECEDING&&a.remove()})}function kt(i,L=!1){let a=i.cloneNode(!0),e=Array.from(i.querySelectorAll("canvas")),n=Array.from(a.querySelectorAll("canvas"));return e.forEach((r,s)=>{let l=n[s];if(l){if(Gt(r)){l.remove();return}try{let o=document.createElement("img");o.src=r.toDataURL("image/png"),o.style.cssText="max-width:100%;height:auto;",l.replaceWith(o)}catch{let o=document.createElement("div");o.className="fv",o.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",l.replaceWith(o)}}}),Ft(a),Bt.forEach(r=>a.querySelectorAll(r).forEach(s=>s.remove())),a.querySelectorAll("tr").forEach(r=>{let s=Array.from(r.cells);for(let l=s.length-1;l>=0;l--){let o=s[l];if(!(!(o.textContent||"").trim()&&!o.querySelector("img,table,input")))break;o.remove()}}),a.querySelectorAll("[style]").forEach(r=>{let s=((r.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");s?r.setAttribute("style",s):r.removeAttribute("style")}),a.removeAttribute("id"),a.removeAttribute("class"),a.removeAttribute("style"),a.querySelectorAll("div").forEach(r=>{!r.children.length&&!(r.textContent||"").trim()&&r.remove()}),Wt(a),L&&Jt(a),a.innerHTML.trim()}function _t(i,L){let a=(i.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return a=a.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),a||`Berkas ${String(L+1).padStart(2,"0")}`}var qt=/^(Konsul|Radiologi)/i;function Ct(){let i=Array.from(document.querySelectorAll(".isidalam")),L=new Set,a=[],e=[];if(i.forEach((n,r)=>{let s=_t(n,r);if(!qt.test(s)&&L.has(s))return;L.add(s);let l=kt(n,Ht.test(s));if(l.length<20){e.push({title:s,docNo:null});return}a.push({title:s,html:l}),e.push({title:s,docNo:a.length})}),!a.length){let n=document.querySelector("#section-to-print");if(n){let r="Detail Klaim";a.push({title:r,html:kt(n)}),e.push({title:r,docNo:1})}}return{sections:a,inventory:e}}var t=i=>gt(i).replace(/[&<>"']/g,L=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[L]),G=i=>t(i).replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).replace(/\n/g,"<br/>"),yt=i=>(new DOMParser().parseFromString(i.replace(/src="data:[^"]*"/g,""),"text/html").body.textContent||"").replace(/\s+/g," ").trim(),Vt=i=>{let L=i.split(/[-/]/).map(r=>r.trim());if(L.length!==3)return i;let[a,e,n]=L;return a.length===4?`${a}-${e.padStart(2,"0")}-${n.padStart(2,"0")}`:`${n}-${e.padStart(2,"0")}-${a.padStart(2,"0")}`},Xt=/(?:Tgl|Tanggal)\.?\s*Masuk(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,Zt=/(?:Tgl|Tanggal)\.?\s*(?:Keluar|Pulang)(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,ht=/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]{8,})/gi;function ta(i,L){let a=[],e=i.map(m=>({t:m.title,x:yt(m.html)})),n=m=>{let $=[],h=new Set;return e.forEach(p=>{let z=new RegExp(m.source,m.flags),N;for(;N=z.exec(p.x);){let v=p.t+"|"+N[1];h.has(v)||(h.add(v),$.push({t:p.t,d:m===ht?N[1]:Vt(N[1])}))}}),$},r=n(Xt);new Set(r.map(m=>m.d)).size>1&&a.push({level:"warn",title:"Tanggal masuk berbeda antar berkas",detail:r.map(m=>`${m.t} ${m.d}`).join(" \xB7 ")+" \u2014 samakan sebelum berkas dikirim ke verifikator."});let s=n(Zt);if(r.length&&s.length){let m=r.map(h=>h.d).sort()[0],$=s.map(h=>h.d).sort().pop();$<m&&a.push({level:"warn",title:"Tanggal keluar lebih awal dari tanggal masuk",detail:`Masuk ${m} \xB7 Keluar ${$}.`})}let l=n(ht);new Set(l.map(m=>m.d)).size>1&&a.push({level:"warn",title:"Nomor SEP berbeda antar lembar",detail:l.map(m=>`${m.t} ${m.d}`).join(" \xB7 ")});let o=[/^SEP$/i,/SBPK/i,/Resume/i,/Rincian Biaya/i],y=L.filter(m=>m.docNo===null&&o.some($=>$.test(m.title)));y.length&&a.push({level:"warn",title:"Berkas inti belum terisi",detail:y.map(m=>m.title).join(", ")+"."});let C=e.find(m=>/Rincian Biaya/i.test(m.t));return C&&!/Total\s+(Biaya|Transaksi|Resep|Jasa)/i.test(C.x)&&a.push({level:"warn",title:"Rincian biaya tanpa baris total",detail:"Tidak ditemukan Total Biaya/Transaksi/Resep pada lembar Rincian Biaya."}),["Laboratorium","Radiologi"].forEach(m=>{let $=e.find(h=>new RegExp(m,"i").test(h.t));$&&$.x.length<60&&a.push({level:"info",title:`Lembar ${m} hanya lampiran gambar`,detail:"Tidak ada teks hasil yang bisa dicocokkan otomatis \u2014 cocokkan manual dengan Resume dan Rincian Biaya."})}),a}var aa="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAIAAAABc2X6AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAb0klEQVR4nOV7d3gUVdv+MzM72zebLdnNJtn03kgIJQQIHRN6AAEVBHn15QWliSIoiqIiIKDYX6VbEJCOdOkkhJJCIL1v+ibZXmZ3yu+PVX4ImLKU77uu7772n/Oc8zznvvfMmVMHYRgGHgaHwzFp/Jjeffo+NPd/M3Jzcg4c+f2fclkdeCb16vPeBx8+AUpPFqtWvttBLvrUePwvQUct7MK3BQd/K7/wFKg8Ot7pNX2oOqnjMp0LLtfXn63LvdeCAMLAw3v+/yxejh7VaZnOBT+Iwb49Kgz1tWatKznUNyFaFnSy5tr8HhO/KzgUKwvKCB64vfiEkyYnBA90lVl65btlSc/naEsPV2XdjfNs6CAUkN3l51f2eTFPW36oKvPtpOfNTtuR6qzFCc9uLzoxPWIEC8WaLG1rbu5anfLK1sJjpfo6l2+af+8TtdfdIO9OH54YknpXCQAkeIVlBA/8uN/LA1RxDDA/P/NekjJi/+iPUn3i/xUz+tX4iTOj0pQ88Yo+M+fEjrs3ziDfhCF+iWI2/70+s+bGjQeA5yNGLE6ckqyMnt9jUpin79z4CQny0PeTZw/0if137Fi1UHHXd0ni1AR5iBvku9HCCp54SeJULsaeGj5ET5hDxD7tduP63N0AECn1V/FlIw8uGeKXWNBa0XvPHM1Le3O15ZN/f++HYW/6bZ08KrBvub4u2TsGQxDq7wNhsnd0ub6ur3cMhiAAIMB5vRThesLsyv255HSkxN9OOlzJWGngcHUSiiCD/BLe6zPzYn1+m83wc9kf9D8Mrg+iGy3cYjP8XHJ6hH8vL54kzFOd6BW2teiYhSQAwEcgRxAkWKwSswUNllaKYVqsOg+2ABAAAECgvyruWFUWzTBRkoD7wvZXxR2vyXZQzhhpEABU6OvGBKWU6WpduZsGLeCy2K02vSt5p72aYqjVKf/GUVZGSOr44AFn63O7rrZ7ggHgVlvVkapMmqEBYGfxSY251WXXE6Yfi07MjEpvtRkDPbzZKOYj9GqzG+86pqhiZ0Slidj8/qpYABjkE//NoIVcDHfQZH9V7AsRI8UcoSurWFcbLPYtN/zZV4ftW5irLcsISXUlGYAvbx08U3vDlZx3fmO9pa1bErrdh5O9o4cfWPz8iVUj7hkAclrKfrhztJ8qtsrYECL2a/zXAQxBLzfccuXiCNbHO2pb0bErDQUuVXbK8e+48S9EjizV1fbxjtpedPxyw62/BNdUGuodNOXy3TNqVX+f+Pq/XpAAIMJ5ERL/UYfe/LHoxPjgAd3l3723NJ/FmXx8pdZmAIDMxtsu4+WGW42W1symwrcuf6MjzKMOvzkqsN+vpX8YnbYSneaTGz+J2PxV2ds/y/stVhYULwsGgOzm4rlnN3jxPfeUXxDivI15v8VIAxPkIefrcrOa7tSYmk0OW6Wx8d2sHzAEa7C07am4oBBIyw31ACDlivrtnddqNx6vvZ7kFdpdwUgHc+nVH656/8OPllz6emPe3kR5iIjN7270p4bbbdXthOmXke88FzFi1cp3O5gRd7WFvx78ej9VzGOi9/gx+vDSYzXXulKye490iZ5ss9NuUXpS8OajwR7dUNE9wdeaHQVtzm5SerJI9mZ3S/D/udWS+4JJu5UkbO75tpXlW7X1blf9KHBn8QAATotR/+18hs1DU59jaIqhaYahgWEYmmZoyvUDmmEY6q7lr1zaqCmz6Zrs+jZ5RE+Oh9TlDjTFMHd9GVwoDp+y+PFKdcFNwY72JtRTAQDIjaP3mBFAALHolZbmu8mHAwWQYnRzXn5+W4JKhiDIPSEAAOhmxnYYYeRqp8QP9Q7iShT/EKjbcFOwQB0uePnTh2Y5dC2GK3tFrdV/NzMAYGlt5Mu875UXLAss1lRGhEa4yvCMzYh3MGNsxXSNXhWXoQIAwEFRJpbAoQpzqCId6hi+fxSCYe7RBrcFdwC2RAFjXiUfsDstxspTv0Rl/OdeIw9AdCdbQ9hUPQcDQGt5Ln7xJ5LGHc8s5ub8jvI9vDU5bAyTMXZoKICGAubGXj2wzL6xMPFNDOe4Qe/xC/4nlJ/8OXz0rAftipi+JYc3y8IT2EJPTmgihCSwEWADAvGpAFBTliM6t0XxZx8BBAEJkJKGvDJNiSA43g0aT0lwe0WB2D+CMOm157apuVdkHA0gtJ7wrbEmS3pMCE2bXnp0e9TE/wAAIH/r97ywns7gHpXZh+XX9nowjrt2zNzuHpOnJLju6gm5hBggmTlhsZnLuTt7v02SJ4+fWvfbqRlcSV99dZFnYNSDvgiGcVMydPFDDOd2KEovclAE4P7/pet4GhOPloIsWduWL+dtnDbJ5FJLUiKSEgEAiwVjR9m+ff2HQPtX5ad+6SAILvTExi6sn7q60TOQpGlG5ucemSfewgzDMAWfbv6mmcdlKJrX1DxWp+9PUh4ACAszSCVXlIojfL5tzdLc2XOqdZXTJMEdLVG4fhHMS+srS28KfdzZ0IKn0MI15w/Mn3aJx2UcTmlZ2XKjoS+XY/QQVXqIKjgck16fUlb2jtPpiWGwYa2h6fKOrsQUhney+dwBnrhgr/avevV0AiDVNa8iCC4UaDzZ+TLjcZnudwlyVSjQoAhSXTsHAJHL6NTA/ZS709Uu4skKNjVUjR90BwAMxgSHQ8XhGoVIMTsnl7zEcV7i49mVHtYsNtdIEAEGUxwAPDPU0FLozm5z1/FkBetrS2OiSQAwmuIxFsFmm1n1lUSFj+2WyJYrslcoscpGNm7GWHaTKR4AoiJIc2P1E6X0ZF9aTqtFJKIBgKRECEqhqBPsFGNnUW0oYwVahTE2FAUCQWiS9AAAnM2gtOWJUnqyLcz18GxrQwEAx3UMjVEUjsg5LC8LO8LBiXXiSjuiQCjgMwwLx3UAYLUiwJbcF6ROm/uQ0O7iyQqWBMfm5eMA4OlxkyS5TgefUMSyE9oFCTX8nhpujzpHcJzDISKdXLH4BgDk5eOSkPuHpQuNOw3mx7Z4fjyPNEORDEOjLPY9JpomSZ5UcenmgAw4IxQUC/l3CLsfIIzTX4Kr2xGasqEygvAg7GKBoFDILwOA01fDpINj742MIIieaDISLWKh72Oh+hgEMxRpObguwFuu9U9B1X/S1R3eFCLltqqS2rwXZ169mJLs8FdvraxeaLH4OxxmFPMFAJrCnU4+l1Mb4P8DAJSUsUrwN/wAqW+/VabPJmnCTxQdqRhCMxQA1LblFOsuMwydoEhXiiPcZvsYHmnSakwID+w1cChLk++yMAydFOQdk5QsaS9Txvb75sy8xiYMw6yhIWuVin2AWK02pdWmAMSqVB4IDv4MQ20GI/rJz5P9+k+obsoq0WVSjLPBWnpUs2lX/iIOar5Q/dmeyg8Mpjqadv5esUGjy3ObrfstbG2uJW1mnkKNi6QWvtfPWaUUS4bmnfcMS8QFYtI7Ys+V2x4x/RlNmWrUu0u/t741eWtsNCmXnZPLzt0XqroG+2DrBNnozwGQQGVyXXVJpfEGQVowJ+IrvhPtQWBc86/F4hZS02puGOI3W4RJn65ghsHtej99cfaBHU6ng5IHOtOnK1pPOz19ay+fajywCWT+5mdeCGFbtBadMCwJAFTj1n1yfkDUmY8njqyIiiDvLnUqq1gHTvrcsL2pnjDdtQBq1BXqHU1x4iE1xjwexRNQRRRBoxiK0iiDIhyKc6l626zE/z5VwX5MexK3IVNbKZfLRqaPriwvKz21OSw8vLH2lpDPGztuXJtWW5q1u0XqI9CdsIm9eAp/APBNGWegRn2SlUkdyJZyNAhl0ZEhjKy3d1Kq+p69C6U4IoaxnKr9dpjPv260HHJgE49qj4fwElhc7VDv6fW24or2awjifk/snmAMAQCoQ2UOGsPEXoBgZ06e6D9wYEN9PY/PDw+PqKquzrpypV+/FIDiHgFKs9msuXmAHvkqirEAAMFYqsRUgFQOofFiSuu4wx6sAsVYpdpLUyM+ymv6PUI6gKCs7YCHcIMmBczL0uxKj3xTzY9m4dzHLxhBENfO270LbSH+51/bi2cUpvTFSDuLdko8JSPT0m4XFMTGxYeGhVVXV4s8RJOnTrt0/nz/gakRBJFvqDZI/3bMx2UM/nC1Dh4iGAAGB73C4XiEi/v5yOKKmv4AAItT5ynwS/aZAgAh3gPvLcx6YCfgn44HOxGM4zhBOABAzvMEAKPDDABS7p/R8xySUWL72PRnjEajSCRCUTQ4OMRVj1zuJRSJ2Gy22k9NEATGwjCCc+7vSyAT4hNLH8xk3n7oxgWH4wEAPrI4ABio7j0mYCGJhNfYQeJx/+0BAPBgIwCgI8wAoBLIAcBut7sjGP76q6KlAQBwq7XymYC+fBZyRuOa66L7q5GxXnYpm92kdZzRYmaK44E6+4usvnzMaqROtTjanJgI48pxyglU9f0zZO5imUZC5Ou4CR0QAACFSDorMuNCPVFT83AZCh5KMfTttkoAiJYGAkDHFyA6EiwUCU0mU6JXOABcbboDAFESvERHWElXSORSG+/vHpyzuvu2TjEAHAAA/kaXQ9t5SqeYbtBBJ4I7hb+IVdBabnLa/YVeCr6kVauVy+UdlO9IcGJiz9ycm6mDBquFXufr8ymG5rHQncMVbXbqEVmKW7dYQF6LD3rEOD4CTIgjZzU5AJCiigOAG9evJfXu3YFLR+/3vsn9rmZmAsBQv8R2wnSl4RYAqIWsNjv9iL9IOKmnlDQmeETB8TIcAI5UZwLAcHVPALiWfbXjG8AdtbDcy0urbQGA0YH9dhSf2l12LtU3QcZD381upx7t5iEhC1imPqkkMps5KW4HQRFIUuD1Zu2lhgIMQdIDkxmGMZlMQqGwA69OxuGAgMCqqsr0wGQhi/tr6R+fDpgbIuZa5wa5zdIFa+vLSOn30fSRZnBfcJwMF7PRr/NPUAw9yCfeRyC/lZ8XG9fJcUQngseOn3Bg/75Fry+ZGJq6s/jUj0Un58SNr9A7p55ocZsoALwm+nmmBBqROLcjIADD/DhOmvzu9mEAmBWVBgBHDh2aM+/Vjh07a+HAQE1tDUVR8+Im7Cw+9WnOr7NjRkdJ2cPUvAqDu3cfHKYpom8dFFbEmuTm8QFALwXbm49tKzymMWvlXI8p4cNsNpvJZOr4FQ1dmVqmpY86dvTI2PETUn3iLjYUbL59ZG58xsaBskYLSbt1v8XpFNAFXB5mDCWWNaCqjgsbLezz1R61JhvvnpGcwxKnBSyxU44Pr+0EgPnxE/kszs6ftk169tlOa+9c8LARIxfNf3X02HEf9J095MDi97K3PRs2VM4T//e2adV1XafuD8X7smnL1N/HMftaGWXHJU1WuGIFALhnMwXGBK0T4dgn13+pMjXJuKIFCZMdDkduzs0XZ73UadX/eDHtXpw8fsxqtWZMmjz+6NuHqzJnRAzfOXKFk2ZyWhyd+j4UgoZPw6zv1gmeI/ymd9dXxFGqPZLK9fU9ds22ksSmga8tSJi8dfMPsbFxfZKTO3Xv0mppZFr64gWvjUxL25Q6/2xdzo8lZ8YEpkwJH9pbyVl7U+/GPOQV+g8Ggf1tVx3mG91ylPNDZiXsJWlq1unVVpLo6RU6Lz6jrbW1tKR49suvdCVClwQjCPLagkWfb1j/znvvb+g/b875ja+cXR8vD4mUBvT15ryT1f6PdzkeBj/isr//BQAIlw1ni7y74QnQ1/dfHEy47Mp3V5rucDF82/DlLBTb8Onaha8v6WKELj3SLnz/3beRUVEDBw2aevz9veUXwsS+V5792ovnyQB0/QsIwlxBFgzE6UYAMKPB1/EELadLi1sOSzQ67GMBLvul5PT0Ux8zAN8MWjQ3fsLhgwftdtuUac91kUA3BNM0/cbihW8uWy6SSwb+9lpea0UfZeSpCRvEbMGxauuM0y1EZ/OvcCjc5LOsgfIyEtxJXiduOcXBbFsBLcrnyDp25LJE02K3+Iji/9DcGH1kOUE5X4ke9f2wpZUVFZu//2712odfr3kouiEYAPR63Yrly9at36hnbAP2vVZlbErxjj42bp2YI7zWTJToHP98UeluhQAMhDe93IO1u1S5EfEIcRAmDk/cgYeQrQgQ9wZAzmlyxh5dbiGJ9IA+h8asthrN7yxbum7jZ3x+N+bk3RMMAJWVFV9t+nzt+o0aq3bI/kW15pZEecjRcWt9BHKagUsNtjL9gzd47oe3ds0I1uoddj8th9dxSbW418TITUK21+HKy8+d/NBKEsP8Eg+P/QQlYenri5etWOHj070N+m4LBoA7twu2bdm8eu2nTYQu/dDSQl2NWijfN+rD3sooi5N+/VLbbxX/eCCG0s5e9JkFqi1D5TfzZStRcUc3vHGMG6eYgCCsTbl73rjyHcXQ44NSdqWtREhm+dI3Xp2/MDQsrLvkuyo48/wBX/+ogOBIV/LO7dubv//uo0/WOFjM1OPvn9bc5GL4+gFz58VPRABIGgCA9bClp9Nht2fJ2JgVAA45Q+u4ng+tTiGIGBmyQiGINDos/zm7flfZOQBYEJ+xYeBrNov1nWVL5y9cHBYeDgAkSZ469EXv1BleXl6PU/D1S7tl7S81sN/tO/wNHMcBoKa6+tM1q5eveM/b12fl1a1rbv5CMXS6f+//Dn1DLVLSDPyhsa3L0bc+MErHOg9OEv3qrWAKcTGFPfivoAnek5JU01EEO1+XM/vM2ipTs4DF/XrwoplRaRpN7ZqPP1q+4l0/PzUAVFcU1mXPRsm6fjM0SNfu9XRVsMloqjqmDvM13NQk+6fs8A8MB4DqqqovN302fsLE1MGDL9TnzT6zptLYJMJ5K/vMnN9jEhvDDQ568x1Tq51io39jwzB0qvKn+4w83DNOkcFliQCg2dq+PPP7HUUnaWB6KyJ2jng7Uhpw8cL5Qwf2L1j0ekBgIMMwWX98qzQv9ZNbcg2vJ4/e0BUV3RAMAFePzEuUfAsANVqRXvoV38PXdGsKov40r8hqMBgWLVlCosz72du+yN/voMkwsc+q5NnPhg3FEJRiIKvRvqXQlN1sd9WGIMwL/sPvRlYJ4xJVU2MV43CUa3JYvsjft+7mLqPTJsS5K/vMXJQwhSapLz7bwGZz4oPbmNYd/oPO1t54u5f3fjaL0ZlQc8it0PCufp7QJcHNzc31NSWakv1pQZtclsY2rKZFmBxlsDuQXO1ERDFv757dM16c1bdfv6L2mrcyvztSlQUAURL/NxKnPh85gouxAaBc7zxYaTlea7vebFsWM0oljAuTDomUp8n5wQDQYtV9W3Dwq1sHWu1GFEGeDx/2Scq//YSK3JycLT/8N33USLFpYy91JoLA0avCMcl/frqWXyVBQ7aLpOEhoSEsFv5IgimK2rfjbX/Obwp+ja/X37ri5QL2gDgHw0BBJR4f4ixu8HH6fZVb0FRdXf3qawt8fH2zGu+surb9ZO0NBhgvrvilqLRZ0elR0kCXO0kzJG12Pb00Q1+oy9tadOy38gt2yokiyLjAlPeTX+ohD21rbf3qy01SqTQxWiQ3vaEUG/kcBgBMVqSqkRUf8v8X5BY7UtkosuLJ3MC3+yR3tDfYSQvr9fo7WZskls9CvA13jXnleKgvKeQxDANz13uO6W9P62u3Eegd0yyfuLd2/fwjh8N9Zc5/pDJZnrZsY+6ePeXnCcqJACTIQyeHDhoX3D9GFkzS5JWGgkOVl/dVXNSYtQDAxfBpYUOX9JwaKwu2WMzbtmxubGiY+tzz7SVrE2S7a5sxsw2pbWZlpNoAoKASD/AmPfh/kqcZyNNEsQM/SkyegKId7Ux26ZFuaWkuyVwZjG+Ri0mdGa2oZ/WKcADAkStcXy/q8i2OB59OSya8pVRhvZoJ+EKq7LFl8/cCPn/GrJd8ff20Nt32whPbi44X/vVFoa9AZnJYjc4/zyOiJP4vRafPikr34nnq9bqfdu6oramZ+dK/HOYKpPbVKJ/6Q5e4UUHkN/sEFI3MzTBHB5Lw11MGAOVNMoP4/d6D57iGj47RjZdWaeF1bd5cFT+vphnzkVEBSmrPOd6NInZTG/ryOOvRy9xxqfaB8YTFjtxunxCcvAHB8J92bNfr9eMmZCT3SwEEclpKfi09+1v5hWpTMwD4C70mhw6aFj6slzISAaSkuHj3rl9I0vn8jBc9xR6ll1+P8dzLwWHfBa6TRAqrWBEBpLeUFvHp/nGO8npWaR0rNZ64rX8+etAGL0UnGwnuCAYAp9N59dQ6c9WaEJVNq8eiApwUhazfJRTwmMIq1svjLCeyuO/NNuEspr6V34QviEl5k8PlHjl0MPtqVkhI6LiMDLXanwHI15ZRDN1TEY4AYjDofz9y5Mb1a2Fh4VOmPcfl8fIufSGzrJGJTD8cFtgIJL2f/U4lfuIqZ2QfYkgS4a+grhayVTK6uEHp3+erxOQJXeffbcEuFORfL7nwSvSAD5srDvaQbKvXYtVN2NkbHMKJyD1pfwXVO9rBwSFIRZY2SE2ieSGJ85Teqory8sOHDtRpNJGRUSPT0j3E4j9On7qWnS0UCkaNHpvUu7fRaCy8tpXdtiHat37fOV5NM0bRSEaq7fhVbmMrOm6gPSXW0WZklZFvCensW+XYqBlblUqf7pJ3RzAAMDSNoCgA3Li8m988z1+uO5fDbjeitU2s4hqWxINeOdu0abdgepo1SEXVtnBbkTEsr6mhMcMkEklJcfGpkyeMRsOwYSN69+1LEERxwWVHy16BdW+4r+FSPvvyLY7Bgqhk9Mx069aj/PED7c06NCXWcbsuiBe1LbrHIJvNhuM4i+XOab6bgu9FY4Om9OKcnt4n9GbkZDY3XE0aLYjZimoN6MVcdnoKMWWIjcViAKC6kWOgIhBeBMJWACCMs52xlXPpO2G+FgyFAxd5PcMdJ65yWw0oAyDiM1IPOrUHoVZSJitaZJ6dMHy9WNzRQvIpCQYAhmGuXdjB1y4NV2kr6llqJfX5bkGoH1Vcy+KxmVfGWRZ87rnqZaPNjnhJaLGQdh22MwBaHeogkXotllnA5nEZnRGdm2HZtEdgsKCDE4mEMKe/ksrXhPLCv4lLGvHoPOFxCXahtVVbdGlFEHurzIO0E0hJLevwFe6ofkRFHXb6OjdcTY4ZYP9yj0CrRwNVFADgLCbYh2KzmSOXuNNG2KoaWMmxDg7O2AlELKQTwpy1Wn4z+42eQ97i8x/bl7yPU7AL5SX5TfkrwsXHPPj0nSr8+FUOGwcMZdoM6PxnLfM3irk4SDzoUD+yrI6llNBFNSyZBx0RQCIINLWiC6eYRXymRY/XOJ4L6v2Brzrw8dJ7/IJdKLqdrStd74MdUsmchBMx25BbFbhESNsdiNmGVDWwKAZ0RlTTjC2aaj6Xw5k6zMZlM1w2U9vC1aJTvWOXBodGPwliT0qwC3WamrrCnUzbr0GSYonoz4MZowWtbsRUcqrNgIb7k641YrsJrdbFIF4vBMa96O3dyfnLo+DJCnaBYZjKirL2uvOM+RpjKwJCA5QRgAHMA9h+CD8aEfaVqYcEh4RCtza43cL/A+p9uOR8npnAAAAAAElFTkSuQmCC",ia=[[/^Triage/i,{id:"triage",code:"TRIAGE",tab:"Triage IGD",option:"Triage \u2014 Pengkajian Awal IGD"}],[/PENGKAJIAN INSTALASI GAWAT DARURAT/i,{id:"pengkajian-igd",code:"PENGKAJIAN IGD",tab:"Pengkajian IGD",option:"Pengkajian IGD \u2014 Lembar Pengkajian Instalasi Gawat Darurat"}],[/^SEP$/i,{id:"rm-01",code:"RM. 01",tab:"RM. 01 SEP/CBG",option:"RM. 01 \u2014 SEP &amp; Berkas Klaim Individual (INA-CBG)"}],[/^Surat (?:Rencana )?Kontrol/i,{id:"surat-kontrol",code:"SURAT KONTROL",tab:"Surat Rencana Kontrol",option:"Surat Rencana Kontrol \u2014 BPJS VClaim"}],[/^SBPK$/i,{id:"rm-02",code:"RM. 02",tab:"RM. 02 SBPK",option:"RM. 02 \u2014 Surat Bukti Pelayanan Kesehatan (SBPK)"}],[/^SPRI$/i,{id:"rm-03",code:"RM. 03",tab:"RM. 03 SPRI",option:"RM. 03 \u2014 Surat Pengantar Rawat Inap (SPRI)"}],[/^Rincian Biaya/i,{id:"rm-05",code:"RM. 05",tab:"RM. 05 Billing",option:"RM. 05 \u2014 Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi"}],[/^Resume/i,{id:"rm-06",code:"RM. 06",tab:"RM. 06 Resume",option:"RM. 06 \u2014 Ringkasan Pulang (Discharge Summary)"}],[/^Telaah/i,{id:"rm-07",code:"RM. 07",tab:"RM. 07 Telaah",option:"RM. 07 \u2014 Formulir Telaah Resep, Obat &amp; Edukasi"}],[/^Radiologi/i,{id:"rm-08",code:"RM. 08",tab:"RM. 08 Radiologi",option:"RM. 08 \u2014 Hasil Pemeriksaan Radiologi"}],[/^Laboratorium/i,{id:"rm-09",code:"RM. 09",tab:"RM. 09 Lab",option:"RM. 09 \u2014 Hasil Pemeriksaan Laboratorium Patologi Klinik"}],[/Konsul/i,{id:"rm-10",code:"RM. 10",tab:"RM. 10 Konsul",option:"RM. 10 \u2014 Lembar Konsultasi Antar-Spesialis"}],[/^Persetujuan Tindakan/i,{id:"form-konsent",code:"RM. 19A",tab:"RM. 19A Persetujuan",option:"RM. 19A \u2014 Persetujuan Tindakan Kedokteran"}],[/^Anestesi/i,{id:"form-anestesi",code:"RM. 21",tab:"RM. 21 Anestesi",option:"RM. 21 \u2014 Laporan Anestesi"}],[/^Fisioterapi/i,{id:"form-fisioterapi",code:"FISIOTERAPI",tab:"Fisioterapi",option:"Fisioterapi \u2014 Assesmen &amp; Terapi"}],[/^Pengkajian Hemodialisa/i,{id:"form-hemodialisa",code:"HEMODIALISA",tab:"Hemodialisa",option:"Hemodialisa \u2014 Pengkajian &amp; Sesi"}],[/^Operasi/i,{id:"form-operasi",code:"RM. 20",tab:"RM. 20 Operasi",option:"RM. 20 \u2014 Laporan Pelaksanaan Operasi"}],[/^Surat Kematian/i,{id:"form-kematian",code:"KEMATIAN",tab:"Surat Kematian",option:"Surat Kematian \u2014 Surat Keterangan"}],[/^Permintaan Terapi/i,{id:"form-terapi",code:"TERAPI",tab:"Permintaan Terapi",option:"Permintaan Terapi \u2014 Rehabilitasi Medik"}],[/^Uji Fungsi/i,{id:"form-uji-fungsi",code:"UJI FUNGSI",tab:"Uji Fungsi",option:"Uji Fungsi \u2014 Lembar Uji Fungsi"}],[/^Partograf/i,{id:"form-partograf",code:"PARTOGRAF",tab:"Partograf",option:"Partograf \u2014 Pemantauan Persalinan"}],[/^Laporan Tindakan/i,{id:"form-laporan-tindakan",code:"LAPORAN TINDAKAN",tab:"Laporan Tindakan",option:"Laporan Tindakan \u2014 Pelaksanaan Tindakan"}],[/^Bon Makan/i,{id:"form-bon-makan",code:"BON MAKAN",tab:"Bon Makan",option:"Bon Makan \u2014 Pasien / Pendamping"}],[/^PEMERIKSAAN$/i,{id:"form-pemeriksaan",code:"PEMERIKSAAN",tab:"Pemeriksaan",option:"Pemeriksaan \u2014 Hasil Diagnostik"}]],ea=(i,L)=>ia.find(([a])=>a.test(i))?.[1]??{id:`doc-${L+1}`,code:"FORMULIR RM KLAIM JKN",tab:`RM. ${String(L+1).padStart(2,"0")} ${i}`,option:`RM. ${String(L+1).padStart(2,"0")} \u2014 ${i}`},H=i=>`<div class="rm-code-top">${i}</div>
<div class="kop-surat"><img class="kop-logo" src="${aa}" alt="Logo Kota Jambi"><div class="kop-text">
<div class="kop-line-1">PEMERINTAH KOTA JAMBI</div>
<div class="kop-line-2">DINAS KESEHATAN</div>
<div class="kop-line-3">RUMAH SAKIT UMUM DAERAH H. ABDUL MANAP</div>
<div class="kop-line-4">Alamat : Jl. Sk. Rd. Syahbuddin Kel. Mayang Mangurai Kec. Alam Barajo Kota Jambi 36129 &#9742; (0741) 670459</div>
<div class="kop-line-5">email : rsud_ham.jambi@yahoo.co.id, rsud@jambikota.go.id, website : rsud.jambikota.go.id</div>
</div></div><div class="kop-double-rule"></div>`,u=(i,L,a=!1)=>`<tr><td class="lbl">${i}</td><td class="col">:</td><td class="val">${a?`<strong>${G(L)}</strong>`:G(L)}</td></tr>`,zt="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDEuNjMgMzEuMDIiPgogIDxkZWZzPgogICAgPHN0eWxlPgogICAgICAuY2xzLTEsIC5jbHMtMiB7CiAgICAgICAgZmlsbDogIzAwYTU1MTsKICAgICAgfQoKICAgICAgLmNscy0zLCAuY2xzLTQgewogICAgICAgIGZpbGw6ICMwMjNmODc7CiAgICAgIH0KCiAgICAgIC5jbHMtNSB7CiAgICAgICAgZmlsbDogI2ZmZjsKICAgICAgfQoKICAgICAgLmNscy01LCAuY2xzLTQsIC5jbHMtMiB7CiAgICAgICAgZmlsbC1ydWxlOiBldmVub2RkOwogICAgICB9CiAgICA8L3N0eWxlPgogIDwvZGVmcz4KICA8ZyBpZD0iTGF5ZXJfMS0yIiBkYXRhLW5hbWU9IkxheWVyIDEiPgogICAgPGc+CiAgICAgIDxnPgogICAgICAgIDxnPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTAyLjkxLDE1LjFjLS44Mi0yLjQtMS42NS00LjgtMi40Ny03LjJsLTEuODYsMi4zMnY0Ljg5YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjksMC0xMS4zNywwLTE3LjA2aC42NGMuMzEsMCwuNTcsMCwuODcuMDUsMS4wMi4xOSwxLjQ5LjksMS40OSwxLjl2NS4zMmw1LjMxLTYuMzlDMTA0LjY0LDAsMTA1LjA3LDAsMTA2LjI5LDBoLjQxYy0xLjQsMS44LTIuOCwzLjU5LTQuMiw1LjM5LDEuNDMsMy44OSwyLjg3LDcuNzgsNC4zLDExLjY3aC0uNDdjLS42OSwwLTEuMzUuMDMtMS45OC0uMjYtLjQzLS4yLS43OC0uNS0xLjA0LS44OC0uMTgtLjI2LS4yOS0uNTMtLjM5LS44MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTExNy45NCwxNC44NmMtLjc1LDEuNjItMi41MywyLjIzLTQuNDMsMi4yMy0yLjk0LDAtNC41NS0xLjYxLTUuMjctMy43Mi0uNS0xLjQ2LS42Ni0zLjI4LS4zOS00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjcxLTMuMTUtMy45OC0yLjgyLTQuNzQtLjAyLS4xNS41NS0uMjQsMS4yNC0uMjYsMi4wNWg1LjI3WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTIyLjkxLDE1LjAzYy41My4zNSwxLjE3LjUzLDEuOTEuNTNzMS4zNS0uMTgsMS43My0uNTVjLjM4LS4zNi41Ny0uODMuNTctMS40LDAtLjQtLjA2LS43My0uMTktMS0uMTMtLjI3LS4yOS0uNS0uNS0uNjktLjItLjE5LS40NC0uMzUtLjctLjQ3LS4yNy0uMTItLjUzLS4yNC0uODEtLjM0LS42MS0uMjItMS4xNy0uNDYtMS42OC0uNzEtLjUxLS4yNi0uOTUtLjU1LTEuMzItLjg3LS4zNy0uMzItLjY2LS42OS0uODctMS4xMS0uMjEtLjQyLS4zMS0uOS0uMzEtMS40NiwwLS42Ni4xMi0xLjI0LjM1LTEuNzMuMjMtLjUuNTYtLjkxLjk4LTEuMjQuNDItLjMzLjkxLS41OCwxLjQ5LS43NS41Ny0uMTcsMS4yLS4yNSwxLjg3LS4yNS44MiwwLDEuNTkuMTMsMi4zMS40MS43Mi4yNywxLjI0Ljc3LDEuNTgsMS41LS45Ny42OC0xLjYuMTktMi4yMS0uMDMtLjExLS4wNi0uMjMtLjExLS4zNS0uMTYtLjM0LS4xMi0uNzEtLjE4LTEuMTEtLjE4LS4zMiwwLS42My4wNC0uOTMuMTEtLjMuMDctLjU2LjE5LS43OS4zNC0uMjMuMTUtLjQuMzUtLjUzLjU4LS4xMy4yMy0uMTkuNTItLjE5Ljg1LDAsLjU1LjE3Ljk5LjUxLDEuMjkuMzQuMzEuNzYuNTYsMS4yNy43Ny41MS4yLDEuMDYuNCwxLjY0LjU4LjU5LjE4LDEuMTQuNDMsMS42NC43My41MS4zMS45My43MSwxLjI3LDEuMjEuMzQuNS41MSwxLjE3LjUxLDIuMDIsMCwuNjQtLjEzLDEuMjItLjM3LDEuNzMtLjI1LjUxLS41OS45NC0xLjAzLDEuMjktLjQzLjM1LS45NS42Mi0xLjU2LjgxLS42LjE5LTEuMjUuMjgtMS45NC4yOC0xLjE2LDAtMi4xNS0uMjEtMi45Ny0uNjQtLjgyLS40Mi0xLjQzLTEuMDctMS44MS0xLjk1LjMyLS4yLjgzLS41LDEuNDktLjI2LjQ0LjE2LjcuNDksMS4wNy43NFoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE1Mi43MSw2LjcyYzAtLjctLjE2LTEuMTctLjUtMS40My0uMzMtLjI1LS44NS0uMzgtMS41Ni0uMzgtLjU4LDAtMS4xMi4xMy0xLjYyLjM4LS41LjI1LS44Ni41My0xLjA5Ljg1djkuMDZjMCwuOTUtLjQ1LDEuNjItMS40MiwxLjgxLS4yOS4wNS0uNTMuMDUtLjgzLjA1aC0uNjFWMGguNjFjLjMsMCwuNTQsMCwuODMuMDUuOTcuMTgsMS40Mi44NSwxLjQyLDEuODF2MS4yNmgwdjEuNThjLjM3LS40NS45Mi0uODQsMS42NC0xLjE4LjczLS4zNCwxLjU3LS41MSwyLjU0LS41MSwxLjE2LDAsMi4wMi4yOSwyLjU5Ljg2LjU2LjU3Ljg1LDEuNDYuODUsMi42NnYxMC41NGgtLjYxYy0uMywwLS41NCwwLS44My0uMDUtLjk3LS4xOC0xLjQyLS44NS0xLjQyLTEuODFWNi43MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE2NC44Nyw5LjI5Yy0uMzIuMTYtLjcuMjktMS4xNC4zOC0uNDMuMDktLjg1LjItMS4yNi4zMi0uODEuMjMtMS4zOC41OS0xLjc0LDEuMDctLjM1LjQ4LS41MywxLjExLS41MywxLjg4LDAsLjg3LjE3LDEuNTEuNTIsMS45MS4zNS40Ljg5LjYsMS42My42LjU2LDAsMS4wNi0uMTMsMS41LS4zOS40My0uMjYuNzctLjYzLDEuMDEtMS4wOXYtNC42N2gwWm0uMjIsNS44N2MtLjMyLjYtLjgxLDEuMDYtMS40NSwxLjQxLS42NC4zNC0xLjQuNTEtMi4yNy41MS0xLjMyLDAtMi4zMS0uMzMtMi45Ni0uOTktLjY1LS42Ni0uOTgtMS41OC0uOTgtMi43NnMuMjYtMi4wOC43Ny0yLjcxYy41MS0uNjMsMS4zMS0xLjExLDIuMzktMS40NC4zNS0uMTIuNzMtLjIxLDEuMTItLjI3LjM5LS4wNy43OC0uMTMsMS4xNi0uMi4zOC0uMDYuNzQtLjE0LDEuMDktLjI0Ljc5LS4yMi44Ny0uNDIuODgtLjk4LDAtLjI2LDAtLjUyLDAtLjc3LDAtLjcxLS4xNi0xLjI1LS40OC0xLjYxLS4zMi0uMzYtLjkzLS41NS0xLjg0LS41NS0uNjgsMC0xLjI2LjEzLTEuNzUuNC0uOTUuNTItMS4zNy45NC0yLjYuMzQuNDctLjgxLDEuMTEtMS40LDEuOTItMS43Ni44MS0uMzYsMS42OS0uNTMsMi42NC0uNTMuNjgsMCwxLjMyLjA1LDEuOTIuMTQuNi4wOSwxLjEzLjI4LDEuNTcuNTQuNDQuMjcuNzkuNjUsMS4wNSwxLjEzLjI2LjQ5LjM5LDEuMTIuMzksMS45MXYxMC4zM2MtLjA3LDAtLjQ1LDAtLjc3LDAtMS4zNiwwLTEuNzgtLjcyLTEuODEtMS45MVoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE3Ny43OSwxNi4xNmMtLjQ1LjMzLS45MS41Ni0xLjM5LjctLjQ4LjE0LTEuMS4yMS0xLjg3LjIxLTEuMjIsMC0yLjE4LS4zNS0yLjg3LTEuMDQtLjY5LS42OS0xLjA0LTEuNjUtMS4wNC0yLjg4VjQuMzloLS40NmMtLjc5LS4wMi0xLjIxLS4xNS0xLjIxLTEuMzhoMS42N1YwaC42MWMuMywwLC41NCwwLC44My4wNS45Ny4xOCwxLjQyLjg1LDEuNDIsMS44MXYxLjE1aDEuNjdjLjc5LjAyLDEuMjEuMTUsMS4yMSwxLjM4aC0yLjl2OC43N2MwLC43Ni4xNywxLjM1LjUsMS43Ny4zMy40Mi44Ni42NCwxLjU4LjY0LjI2LDAsLjUtLjAyLjctLjA1Ljg0LS4xMywxLjI1LS4wMSwxLjU3LjY1WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTk4Ljc4LDYuNzJjMC0uNy0uMTctMS4xNy0uNS0xLjQzLS4zMy0uMjUtLjg1LS4zOC0xLjU2LS4zOC0uNTgsMC0xLjEyLjEzLTEuNjIuMzgtLjUuMjUtLjg2LjUzLTEuMDkuODV2OS4wNmMwLC45NS0uNDUsMS42Mi0xLjQyLDEuODEtLjI5LjA1LS41My4wNS0uODMuMDVoLS42MVYzaC42MWMuMywwLC41NCwwLC44My4wNS45MS4xNywxLjM2Ljc4LDEuNDEsMS42NGgwYy4zNy0uNDUuOTItLjg0LDEuNjQtMS4xOC43Mi0uMzQsMS41Ny0uNTEsMi41NC0uNTEsMS4xNiwwLDIuMDIuMjksMi41OS44Ni41Ni41Ny44NSwxLjQ2Ljg1LDIuNjZ2MTAuNTRoLS42MWMtLjMsMC0uNTQsMC0uODMtLjA1LS45Ny0uMTgtMS40Mi0uODUtMS40Mi0xLjgxVjYuNzJaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xNDIuMTEsMTQuODZjLS43NSwxLjYyLTIuNTMsMi4yMy00LjQzLDIuMjMtMi45NCwwLTQuNTUtMS42MS01LjI3LTMuNzItLjUtMS40Ni0uNjYtMy4yOC0uNC00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjctMy4xNS0zLjk4LTIuODItNC43NC0uMDItLjE1LjU1LS4yNCwxLjI0LS4yNiwyLjA1aDUuMjdaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xODYuMjYsOS4yOWMtLjMyLjE2LS43LjI5LTEuMTQuMzgtLjQzLjA5LS44NS4yLTEuMjYuMzItLjgxLjIzLTEuMzkuNTktMS43NCwxLjA3LS4zNS40OC0uNTMsMS4xMS0uNTMsMS44OCwwLC44Ny4xNywxLjUxLjUyLDEuOTEuMzUuNC44OS42LDEuNjMuNi41NiwwLDEuMDYtLjEzLDEuNS0uMzkuNDQtLjI2Ljc3LS42MywxLjAyLTEuMDl2LTQuNjdoMFptLjIyLDUuODdjLS4zMi42LS44MSwxLjA2LTEuNDUsMS40MS0uNjQuMzQtMS40LjUxLTIuMjcuNTEtMS4zMiwwLTIuMzEtLjMzLTIuOTYtLjk5LS42NS0uNjYtLjk4LTEuNTgtLjk4LTIuNzZzLjI2LTIuMDguNzctMi43MWMuNTItLjYzLDEuMzEtMS4xMSwyLjM5LTEuNDQuMzUtLjEyLjczLS4yMSwxLjEyLS4yNy4zOS0uMDcuNzgtLjEzLDEuMTYtLjIuMzgtLjA2Ljc0LS4xNCwxLjA5LS4yNC43OS0uMjIuODctLjQyLjg4LS45OCwwLS4yNiwwLS41MiwwLS43NywwLS43MS0uMTYtMS4yNS0uNDgtMS42MS0uMzItLjM2LS45My0uNTUtMS44NC0uNTUtLjY4LDAtMS4yNi4xMy0xLjc1LjQtLjk1LjUyLTEuMzcuOTQtMi42LjM0LjQ3LS44MSwxLjExLTEuNCwxLjkyLTEuNzYuODEtLjM2LDEuNjktLjUzLDIuNjQtLjUzLjY4LDAsMS4zMi4wNSwxLjkyLjE0LjYuMDksMS4xMy4yOCwxLjU3LjU0LjQ0LjI3Ljc5LjY1LDEuMDUsMS4xMy4yNi40OS4zOSwxLjEyLjM5LDEuOTF2MTAuMzNjLS4wNywwLS40NSwwLS43NywwLTEuMzYsMC0xLjc4LS43Mi0xLjgxLTEuOTFaIi8+CiAgICAgICAgPC9nPgogICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTUxLjczLDcuNzJjMS44OC0uMDYsMi40MS0xLjcsMi40MS0zLjA3LDAtMS40NC0uMTUtMy4wNy0yLjEtMy4wN2gtMi41MXY2LjE0aDIuMlptLS4wMyw3LjljLjkzLDAsMS42Mi0uMjYsMi4wNi0uNzguNDQtLjUyLjY2LTEuMzYuNjYtMi41MiwwLTEuNDctLjItMi45Ny0yLjIyLTMuMjdoLTIuNjh2Ni41N2gyLjE3Wm0tNS4xNywxLjQ3Vi4wNGg1Ljg2YzMuMzEsMCw0Ljc5LDIuMTIsNC40OSw0LjktLjE0LDEuMjgtLjYyLDIuNi0xLjkxLDMuMjksMy4xNi45NiwzLjE2LDUuNTgsMS4zLDcuNTgtLjguODUtMi4wNywxLjI4LTMuODMsMS4yOGgtNS45MVoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im02MC42Ni4wNGg1Ljc5Yy44NywwLDEuNjEuMDksMi4yMi4yNy42MS4xOCwxLjEuNDQsMS40Ny44LjM3LjM2LjY0LjgxLjgxLDEuMzUuMTcuNTQuMjUsMS4xOC4yNSwxLjksMCwxLjE2LS4wOSwyLjEzLS4yNywyLjktLjE4Ljc4LS40NywxLjQxLS44OSwxLjg4LS40Mi40Ny0uOTcuODItMS42NSwxLjAyLS42OC4yMS0xLjUzLjMxLTIuNTUuMzFoLTIuMnY0LjY2YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjgsMC0xMS4zNywwLTE3LjA1aDBabTQuODgsOC45M2MuNDgsMCwuODktLjA2LDEuMjItLjE5LjMzLS4xMy42LS4zNC44Mi0uNjMuMjItLjMuMzctLjY5LjQ3LTEuMTguMS0uNDkuMTQtMS4xLjE0LTEuODNzLS4wNC0xLjMtLjEyLTEuNzZjLS4wOC0uNDYtLjIxLS44Mi0uMzctMS4wOS0uMTctLjI3LS4zOS0uNDUtLjY2LS41Ni0uMjctLjEtLjYxLS4xNi0xLjAxLS4xNmgtMi4zN3Y3LjM5aDEuODhaIi8+CiAgICAgICAgPHBhdGggY2xhc3M9ImNscy0zIiBkPSJtNzQuNC4wNGguNjNjLjMxLDAsLjU2LDAsLjg2LjA1LDEuMDEuMTksMS40OC44OSwxLjQ4LDEuODh2MTAuODhjMCwyLjgzLTEuNjcsNC4yNS01LjAyLDQuMjUtLjE2LDAtLjMxLDAtLjQ2LDAtMS4wOS0uMDItMi4wNi0uMjctMi44OS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxLjMuMi42NC4zNSwxLjAyLjQ0LjgxLjIsMS45Ni4yMSwyLjc0LS4yMi43OS0uNDQuODYtMS4yNy44Ni0yLjA1Vi4wNFoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im04Mi41OSwxNC44NGMuNTUuMzcsMS4yMy41NiwyLjA1LjU2LjM5LDAsLjc2LS4wNiwxLjExLS4xOC4zNS0uMTIuNjYtLjI5LjkzLS41Mi4yNy0uMjIuNDgtLjQ5LjYzLS44Mi4xNS0uMzIuMjMtLjY4LjIzLTEuMDksMC0uMzYtLjA2LS42Ny0uMTctLjk1LS4xMS0uMjctLjI3LS41Mi0uNDYtLjczLS4xOS0uMjItLjQyLS40MS0uNjktLjU5LS4yNy0uMTgtLjU1LS4zNi0uODYtLjU1LS42OS0uNC0xLjMzLS43OS0xLjkyLTEuMTctLjU5LS4zOC0xLjEtLjc5LTEuNTMtMS4yMi0uNDMtLjQzLS43OC0uOTEtMS4wMy0xLjQzLS4yNS0uNTItLjM3LTEuMTQtLjM3LTEuODYsMC0uNjIuMTEtMS4xOC4zMy0xLjcuMjItLjUyLjU0LS45Ni45Ny0xLjM0LjQzLS4zOC45NS0uNjgsMS41Ni0uODkuNjEtLjIyLDEuMzEtLjMyLDIuMS0uMzIsMS4wMywwLDEuOTIuMjEsMi42Ni42My43NC40MiwxLjI0LDEuMDIsMS41LDEuNzgtLjg2LjM3LTEuNDkuMTctMi4xOS0uMzUtLjQ0LS4yOS0uOTctLjQ0LTEuNTgtLjQ0LS44NSwwLTEuNTIuMjEtMS45OS42Mi0uNDcuNDItLjcxLDEtLjcxLDEuNzYsMCwuNjMuMTgsMS4xNS41NCwxLjU3LjM2LjQyLjgxLjc5LDEuMzUsMS4xMy41NC4zNCwxLjEzLjY2LDEuNzYuOTcuNjQuMzEsMS4yMi42NywxLjc2LDEuMDguNTQuNDEuOTkuOSwxLjM1LDEuNDcuMzYuNTcuNTQsMS4yOS41NCwyLjE1LDAsLjY3LS4xMywxLjMtLjM5LDEuODctLjI2LjU3LS42MywxLjA3LTEuMTEsMS40OC0uNDguNDItMS4wNy43NC0xLjc3Ljk4LS43LjI0LTEuNDkuMzYtMi4zOC4zNi0xLjE0LDAtMi4xNC0uMjUtMy4wMS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxWiIvPgogICAgICA8L2c+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTExMy4wOCwyOS4xM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNy0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOVptLTUuNTYsMi4zOHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjE4LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjUtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTQuNy0yLjk1aC0xLjAxbC0xLjE2LDQuMTMtMS4xOC00LjEzaC0xLjA1bDEuNyw1LjMxLS4wOC4zNmMtLjAyLjExLS4wNS4yLS4xLjI5LS4wNS4wOS0uMTEuMTYtLjE4LjIxLS4wOC4wNS0uMTcuMDgtLjI5LjA4LS4xNCwwLS4yNi0uMDItLjM3LS4wNS0uMTEtLjAzLS4xOS0uMDYtLjI1LS4wOS0uMDYtLjAzLS4wOS0uMDUtLjA5LS4wNWwuMTEuODZzLjA0LjAyLjExLjA1Yy4wNy4wMy4xNy4wNi4zLjA5LjEzLjAzLjI4LjA0LjQ2LjA0LjIyLDAsLjQtLjA0LjU1LS4xMi4xNS0uMDguMjctLjE5LjM3LS4zMi4xLS4xNC4xOC0uMy4yNS0uNDguMDctLjE4LjEzLS4zOC4yLS41OWwxLjcyLTUuNThoMFptLTUuMDgsNS4zM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjEyLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTYuMzEtMi4zNWMwLC4yMy0uMDIuNDMtLjA3LjYtLjA1LjE2LS4xMi4zLS4yMi40Mi0uMDguMTEtLjE4LjE5LS4yNy4yNS0uMS4wNi0uMTkuMTEtLjI5LjEzLS4wOS4wMy0uMTguMDUtLjI1LjA1LS4wNywwLS4xMi4wMS0uMTUuMDFoLTEuMDl2LTIuOTZoMS4wOWMuMDgsMCwuMTcsMCwuMjcuMDIuMTEuMDIuMjIuMDUuMzMuMS4xMS4wNS4yMi4xMy4zMi4yNC4xLjExLjE4LjI2LjI0LjQ0LjA2LjE4LjA5LjQyLjA5LjdoMFptMS4yNCwwYzAtLjM5LS4wNS0uNzMtLjE0LTEuMDEtLjA5LS4yOC0uMjItLjUyLS4zOC0uNzEtLjE2LS4xOS0uMzUtLjM0LS41Ni0uNDUtLjIxLS4xMS0uNDUtLjE5LS42OS0uMjQtLjI1LS4wNS0uNS0uMDctLjc3LS4wN2gtMi4yM3Y3LjJoMS4ydi0yLjI5aDEuMDdjLjIxLDAsLjQyLS4wMS42NC0uMDQuMjEtLjAzLjQyLS4wOS42My0uMTguMjEtLjA5LjQxLS4yMy42LS40Mi4yLS4xOC4zNS0uNDMuNDYtLjczLjExLS4zLjE3LS42Ni4xNy0xLjA2aDBabTU1LjU0LDMuMTRjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xMy4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOS0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOC45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM4LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS00LjE3LTQuMjRsLS4xNS0uOTdjLS4wNS0uMDMtLjA5LS4wNi0uMTMtLjA4LS4wNC0uMDItLjA3LS4wNC0uMS0uMDUtLjAzLS4wMS0uMDctLjAzLS4xMi0uMDQtLjA2LS4wMS0uMTEtLjAyLS4xNS0uMDMtLjA0LDAtLjA5LDAtLjE0LDAtLjA5LDAtLjE3LDAtLjI1LjAxLS4wOC4wMS0uMTYuMDMtLjI0LjA3LS4wOC4wMy0uMTUuMDgtLjIyLjE1LS4wOC4wOC0uMTUuMTUtLjIuMjMtLjA1LjA4LS4wOS4xNS0uMTIuMjEtLjAzLjA2LS4wNS4xMS0uMDYuMTR2LS43MmgtMS4wNHY1LjMzaDEuMDR2LTMuMDNjMC0uMDksMC0uMTksMC0uMzEsMC0uMTEuMDItLjIzLjA0LS4zNS4wMy0uMTIuMDctLjI0LjEyLS4zNi4wNi0uMS4xMi0uMTguMjEtLjI2LjA4LS4wOC4xOC0uMTQuMjktLjE4LjExLS4wNC4yNC0uMDcuMzgtLjA3LjE3LDAsLjMzLjAzLjQ2LjA5LjEzLjA2LjI2LjEzLjM3LjIzaDBabS01LjE1LDIuNjVjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzgtLjQxdi4zMWMwLC4wNSwwLC4xLjAxLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjgzLjQ1YzAsLjEyLS4wMy4yMy0uMS4zMi0uMDcuMDktLjE2LjE2LS4yNy4yMi0uMTEuMDYtLjI0LjEtLjM3LjEzLS4xMy4wMy0uMjcuMDQtLjQuMDQtLjI2LDAtLjQ4LS4wMy0uNjctLjA5LS4xOS0uMDYtLjMzLS4xNS0uNDQtLjI1LS4xLS4xMS0uMTUtLjI0LS4xNS0uMzksMC0uMS4wMi0uMTkuMDUtLjI4LjAzLS4wOC4wNy0uMTUuMTItLjIxLjA1LS4wNi4wOS0uMS4xMi0uMTMuMDQtLjAzLjA1LS4wNS4wNi0uMDVoLjkxYy4yMywwLC40Mi4wMy41Ny4wNy4xNS4wNC4yNi4wOS4zNS4xNi4wOC4wNy4xNC4xNC4xOC4yMi4wMy4wOC4wNS4xNi4wNS4yNWgwWm0tLjEzLTQuMDNjMCwuMjQtLjA0LjQ0LS4xMi42MS0uMDguMTctLjIuMy0uMzYuMzktLjE2LjA5LS4zNi4xNC0uNi4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMTksMCwuMzYuMDQuNDkuMS4xMy4wNi4yNC4xNS4zMi4yNS4wOC4xLjE0LjIyLjE3LjM1LjA0LjEzLjA1LjI2LjA1LjM5aDBabTEuMTcsMy45OGMwLS41LS4xNy0uODYtLjUzLTEuMS0uMzYtLjI0LS44OS0uMzYtMS41OS0uMzUtLjA4LDAtLjE3LDAtLjI4LDAtLjExLDAtLjIyLDAtLjM0LDAtLjEyLDAtLjIyLS4wMi0uMzItLjA0LS4xLS4wMi0uMTgtLjA1LS4yNC0uMS0uMDYtLjA1LS4wOS0uMTEtLjEtLjE5LDAtLjA5LjAzLS4xNi4xLS4yMS4wNi0uMDUuMTUtLjA4LjI2LS4xLjExLS4wMi4yNC0uMDMuMzgtLjAzLjE0LDAsLjI5LDAsLjQ2LDAsLjQ0LDAsLjgyLS4wOCwxLjEzLS4yMy4zMS0uMTUuNTQtLjM2LjcxLS42NS4xNi0uMjguMjQtLjYyLjI0LTEuMDF2LTEuNzNoLS41M3MtLjA5LDAtLjEzLDBjLS4wNSwwLS4wOS4wMS0uMTQuMDMtLjA1LjAyLS4wOS4wNi0uMTMuMTEtLjA0LjA1LS4wNi4xMS0uMDcuMTcsMCwuMDYtLjAxLjExLDAsLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjM5LS4xNi0uMTYtLjA0LS4zNC0uMDYtLjU1LS4wNi0uMTQsMC0uMjguMDEtLjQzLjA1LS4xNS4wMy0uMy4wOS0uNDUuMTctLjE1LjA4LS4yOC4xOS0uNC4zMy0uMTIuMTQtLjIxLjMxLS4yOC41Mi0uMDcuMjEtLjEuNDYtLjEuNzYsMCwuMi4wMy4zOC4wOC41NC4wNS4xNi4xMi4yOS4xOS40LjA4LjExLjE1LjIuMjMuMjcuMDguMDcuMTQuMTMuMTkuMTYuMDUuMDMuMDguMDUuMDguMDUsMCwwLS4wNCwwLS4xLjAxLS4wNy4wMS0uMTUuMDMtLjI0LjA3LS4xLjAzLS4xOS4wOC0uMjkuMTUtLjEuMDctLjE4LjE2LS4yNC4yNy0uMDYuMTEtLjEuMjYtLjEuNDMsMCwuMTMsMCwuMjQuMDQuMzMuMDMuMDkuMDguMTcuMTQuMjMuMDYuMDYuMTIuMTEuMTkuMTQuMDcuMDQuMTMuMDYuMi4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA5LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjguMTcuMi40Mi4zNS43NC40Ny4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTYuMjUuMDVjMCwuMTItLjAzLjIzLS4xLjMyLS4wNy4wOS0uMTYuMTYtLjI3LjIyLS4xMS4wNi0uMjQuMS0uMzcuMTMtLjE0LjAzLS4yNy4wNC0uNC4wNC0uMjYsMC0uNDgtLjAzLS42Ny0uMDktLjE5LS4wNi0uMzMtLjE1LS40NC0uMjUtLjEtLjExLS4xNS0uMjQtLjE1LS4zOSwwLS4xLjAyLS4xOS4wNi0uMjguMDMtLjA4LjA3LS4xNS4xMi0uMjEuMDUtLjA2LjA5LS4xLjEyLS4xMy4wNC0uMDMuMDUtLjA1LjA1LS4wNWguOTFjLjIzLDAsLjQyLjAzLjU3LjA3LjE1LjA0LjI2LjA5LjM1LjE2LjA4LjA3LjE0LjE0LjE4LjIyLjAzLjA4LjA1LjE2LjA1LjI1aDBabS0uMTMtNC4wM2MwLC4yNC0uMDQuNDQtLjEyLjYxLS4wOC4xNy0uMi4zLS4zNi4zOS0uMTYuMDktLjM2LjE0LS41OS4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMiwwLC4zNi4wNC40OS4xLjEzLjA2LjI0LjE1LjMyLjI1LjA4LjEuMTQuMjIuMTcuMzUuMDQuMTMuMDUuMjYuMDUuMzloMFptMS4xNywzLjk4YzAtLjUtLjE3LS44Ni0uNTMtMS4xLS4zNi0uMjQtLjg5LS4zNi0xLjU5LS4zNS0uMDgsMC0uMTcsMC0uMjgsMC0uMTEsMC0uMjIsMC0uMzQsMC0uMTIsMC0uMjItLjAyLS4zMi0uMDQtLjEtLjAyLS4xOC0uMDUtLjI0LS4xLS4wNi0uMDUtLjA5LS4xMS0uMS0uMTksMC0uMDkuMDMtLjE2LjEtLjIxLjA2LS4wNS4xNS0uMDguMjYtLjEuMTEtLjAyLjI0LS4wMy4zOC0uMDMuMTQsMCwuMjksMCwuNDYsMCwuNDQsMCwuODItLjA4LDEuMTMtLjIzLjMxLS4xNS41NC0uMzYuNzEtLjY1LjE2LS4yOC4yNC0uNjIuMjQtMS4wMXYtMS43M2gtLjUzcy0uMDksMC0uMTMsMGMtLjA1LDAtLjA5LjAxLS4xNC4wMy0uMDUuMDItLjA5LjA2LS4xNC4xMS0uMDQuMDUtLjA2LjExLS4wNy4xNywwLC4wNi0uMDEuMTEtLjAxLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjQtLjE2LS4xNi0uMDQtLjM0LS4wNi0uNTUtLjA2LS4xNCwwLS4yOC4wMS0uNDMuMDUtLjE1LjAzLS4zLjA5LS40NS4xNy0uMTUuMDgtLjI4LjE5LS40LjMzLS4xMi4xNC0uMjEuMzEtLjI4LjUyLS4wNy4yMS0uMS40Ni0uMS43NiwwLC4yLjAzLjM4LjA4LjU0LjA1LjE2LjEyLjI5LjE5LjQuMDguMTEuMTUuMi4yMy4yNy4wOC4wNy4xNC4xMy4xOS4xNi4wNS4wMy4wOC4wNS4wOC4wNSwwLDAtLjA0LDAtLjEuMDEtLjA3LjAxLS4xNS4wMy0uMjQuMDctLjEuMDMtLjE5LjA4LS4yOS4xNS0uMS4wNy0uMTguMTYtLjI0LjI3LS4wNi4xMS0uMS4yNi0uMS40MywwLC4xMywwLC4yNC4wNC4zMy4wMy4wOS4wOC4xNy4xNC4yMy4wNi4wNi4xMi4xMS4xOS4xNC4wNy4wNC4xMy4wNi4xOS4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA4LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjhzLjQyLjM1Ljc0LjQ3Yy4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTQ2LjE4LS40di0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTIuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNy0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM2LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMjQtMS4yNmMtLjA1LjA2LS4xMS4xMy0uMTguMTgtLjA3LjA2LS4xNS4xMS0uMjQuMTYtLjExLjA1LS4yMi4wOS0uMzIuMTEtLjEuMDItLjIxLjAzLS4zMi4wMy0uMjEsMC0uMzktLjA1LS41NC0uMTUtLjE1LS4wOS0uMjYtLjIzLS4zNS0uNC0uMDktLjE3LS4xNS0uMzctLjItLjU5LS4wNC0uMjMtLjA2LS40Ny0uMDctLjc0LDAtLjE1LDAtLjMxLjAyLS40OS4wMS0uMTguMDQtLjM2LjA4LS41My4wNC0uMTguMS0uMzQuMTgtLjQ5LjA4LS4xNS4xOS0uMjcuMzMtLjM2LjE0LS4wOS4zMS0uMTQuNTItLjE0LjE5LDAsLjM0LjAzLjQ4LjA4LjEzLjA1LjI0LjEzLjMyLjIyLjA4LjA4LjEzLjE4LjE4LjI4LjA0LjEuMDcuMjEuMDguMzIuMDEuMTEuMDIuMjIuMDIuMzJ2Mi4xN2gwWm0xLjA0LDEuMjZ2LTcuMjNoLTEuMDR2Mi40cy0uMDEtLjAyLS4wNC0uMDZjLS4wMy0uMDQtLjA3LS4wOS0uMTItLjE1LS4wNi0uMDYtLjE0LS4xMi0uMjMtLjE4LS4xLS4wNi0uMjItLjExLS4zNi0uMTUtLjE0LS4wNC0uMzItLjA2LS41MS0uMDYtLjI4LDAtLjUyLjA1LS43My4xMy0uMjEuMDktLjM5LjIxLS41NC4zNi0uMTUuMTUtLjI4LjMyLS4zOC41MS0uMS4xOS0uMTguMzktLjI0LjYtLjA2LjIxLS4xLjQyLS4xMy42Mi0uMDMuMjEtLjA0LjQtLjA0LjU4LDAsLjI5LjAyLjU3LjA3Ljg0LjA1LjI3LjEyLjUyLjIxLjc1LjEuMjMuMjMuNDMuMzkuNi4xNi4xNy4zNS4zLjU3LjQuMjMuMDkuNDkuMTQuNzkuMTMuMTksMCwuMzYtLjAzLjUyLS4wOC4xNS0uMDUuMy0uMTIuNDMtLjIxLjEzLS4wOS4yNy0uMi4zOS0uMzJ2LjUzaC45OVptLTYuNDYtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDcuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMTQtMi4xNWMwLC4xOS0uMDIuMzYtLjA3LjQ5LS4wNS4xMy0uMTIuMjQtLjIxLjMzLS4xMS4xMS0uMjQuMTgtLjM4LjIyLS4xNC4wNC0uMjkuMDctLjQ0LjA3LS4xNSwwLS4yOSwwLS40MiwwaC0xLjAzdi0yLjIxaDEuMDNjLjE2LDAsLjMyLDAsLjQ4LjAyLjE2LjAxLjMuMDQuNDQuMDkuMTMuMDUuMjUuMTIuMzQuMjIuMDguMDkuMTUuMi4xOS4zMy4wNS4xMi4wNy4yNy4wNy40NGgwWm0tLjI2LTMuMDZjMCwuMi0uMDQuMzctLjEuNS0uMDcuMTMtLjE1LjIzLS4yNi4zLS4xLjA4LS4yMS4xMy0uMzMuMTYtLjExLjAzLS4yMi4wNS0uMzEuMDYtLjEsMC0uMTcuMDEtLjIyLDBoLTEuMDd2LTIuMDVoMS4wN3MuMSwwLC4xNywwYy4wNywwLC4xNS4wMS4yNC4wMi4wOC4wMS4xNy4wMy4yNS4wNi4wOC4wMy4xNS4wNy4yLjEyLjEyLjA5LjIxLjIuMjcuMzMuMDYuMTMuMDkuMjkuMDkuNDhoMFptMS41LDMuMDRjMC0uMTQtLjAxLS4yNy0uMDQtLjQxLS4wMy0uMTQtLjA4LS4yNy0uMTUtLjM5LS4wNy0uMTMtLjE2LS4yNC0uMjgtLjM1LS4xNC0uMTMtLjMtLjIzLS40Ny0uMjktLjE3LS4wNy0uMzUtLjExLS41Mi0uMTQuMTItLjA0LjIzLS4wOS4zNS0uMTUuMTItLjA2LjIyLS4xMy4zMi0uMi4xLS4wOC4xOC0uMTYuMjUtLjI2LjA4LS4xNC4xNS0uMjkuMi0uNDcuMDUtLjE4LjA4LS4zOC4wOC0uNjEsMC0uMjYtLjA0LS41LS4xMy0uNy0uMDgtLjItLjItLjM3LS4zNC0uNTEtLjE0LS4xNC0uMy0uMjQtLjQ4LS4zMi0uMjItLjEtLjQ2LS4xNy0uNy0uMi0uMjQtLjAzLS41MS0uMDUtLjc5LS4wNWgtMi4yN3Y3LjJoMi4yNWMuMTcsMCwuMzYsMCwuNTUtLjAxLjE5LS4wMS4zOC0uMDMuNTctLjA3LjE5LS4wNC4zNy0uMS41NS0uMTcuMTctLjA4LjMzLS4xOC40Ny0uMzEuMTUtLjE2LjI3LS4zMi4zNi0uNS4wOS0uMTguMTQtLjM2LjE4LS41NS4wMy0uMTkuMDUtLjM3LjA1LS41NmgwWm0xMTIuNDksMi4xN3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS01LjM3LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMxLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzQuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4zNCw2Ljd2LTMuNTZjMC0uMTIsMC0uMjYtLjAyLS40MS0uMDEtLjE1LS4wNC0uMy0uMDgtLjQ0LS4wNC0uMTUtLjExLS4yOS0uMTktLjQzLS4wOC0uMTQtLjItLjI1LS4zNC0uMzYtLjEzLS4wOS0uMjgtLjE2LS40NC0uMi0uMTYtLjA0LS4zMS0uMDYtLjQ3LS4wNi0uMjEsMC0uNC4wMy0uNTYuMDktLjE2LjA2LS4zLjEyLS40Mi4yMS0uMTIuMDgtLjIxLjE3LS4yOS4yNS0uMDguMDktLjEzLjE2LS4xNy4yMy0uMDQuMDctLjA2LjExLS4wNy4xMiwwLS4wMy0uMDItLjA4LS4wNS0uMTUtLjAzLS4wNy0uMDgtLjE1LS4xNS0uMjQtLjA2LS4wOS0uMTUtLjE3LS4yNi0uMjUtLjA5LS4wNi0uMTktLjExLS4zLS4xNS0uMTEtLjA0LS4yMS0uMDctLjMyLS4wOC0uMTEtLjAyLS4yMS0uMDItLjMtLjAyLS4yMiwwLS40Mi4wMy0uNTguMDktLjE3LjA2LS4zLjEzLS40Mi4yMi0uMTEuMDktLjIuMTgtLjI3LjI4LS4wNy4wOS0uMTEuMTgtLjEzLjI1di0uNzJoLTEuMDN2NS4zM2gxLjAzdi0zLjI3YzAtLjIyLjAyLS40LjA1LS41NS4wMy0uMTQuMDgtLjI2LjE0LS4zNS4wNS0uMDkuMTItLjE2LjE4LS4yMi4wOC0uMDguMTYtLjEzLjI2LS4xOC4xLS4wNC4yMS0uMDcuMzQtLjA3LjE2LDAsLjI5LjAyLjM4LjA2LjEuMDQuMTguMDguMjQuMTUuMDguMDcuMTQuMTUuMTkuMjUuMDUuMDkuMDguMjEuMS4zNC4wMi4xMy4wMy4yOS4wMy40N3YzLjM3aDEuMDF2LTMuMjdjMC0uMTIsMC0uMjUuMDEtLjM4LjAxLS4xMy4wNC0uMjYuMDktLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA4LS4wOC4xOC0uMTQuMjktLjE4LjEtLjA0LjIxLS4wNi4zMy0uMDYuMTMsMCwuMjQuMDEuMzUuMDQuMS4wMy4yLjA4LjI5LjE2LjA3LjA3LjEzLjE0LjE2LjIxLjA0LjA3LjA2LjEyLjA3LjE2LjAxLjA1LjAzLjExLjA0LjE4LjAxLjA3LjAyLjE2LjAzLjI0LDAsLjA5LjAxLjE4LjAxLjI3djMuMzdoMS4wMVptLTkuMTItMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE4Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wOC4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEuMDEuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTUuMDMtMi42MnYtNC41OGgtMS4ydjQuNThjMCwuMTYsMCwuMzMtLjAxLjUsMCwuMTctLjAzLjM0LS4wNy40OS0uMDMuMTYtLjA5LjMtLjE2LjQzLS4xLjE1LS4yMy4yNy0uMzkuMzUtLjE2LjA4LS4zNS4xMi0uNTYuMTItLjE2LDAtLjMxLS4wMi0uNDQtLjA1LS4xNC0uMDMtLjI2LS4wNy0uMzctLjExLS4xLS4wNC0uMTktLjA4LS4yNS0uMTEtLjA2LS4wMy0uMDktLjA1LS4xLS4wNmwuMjYsMS4wNHMuMDMuMDEuMDguMDRjLjA1LjAzLjEyLjA2LjIyLjA5LjEuMDMuMjIuMDcuMzUuMDkuMTQuMDMuMjkuMDQuNDcuMDQuMDcsMCwuMTYsMCwuMjgsMCwuMTIsMCwuMjUtLjAzLjM5LS4wNi4xNC0uMDMuMjgtLjA4LjQzLS4xNS4xNC0uMDcuMjctLjE2LjM5LS4yNy4xMi0uMTEuMjMtLjI0LjMxLS4zOC4wOS0uMTQuMTYtLjMuMjItLjQ5LjA2LS4xOC4xLS40LjEyLS42NS4wMy0uMjUuMDQtLjU0LjA0LS44N2gwWm0zMS4xNiwyLjYydi0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTEuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIyLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMS0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOC0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptMzIuNTEsMHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjM1LTEuNTljMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDYtLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMS0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzItLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDguMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjE1LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMyLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzMuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4xMiw1LjE5YzAtLjI2LS4wNi0uNDgtLjE3LS42Ny0uMTEtLjE5LS4yNi0uMzUtLjQ2LS40OC0uMTktLjEzLS40MS0uMjUtLjY1LS4zNS0uMTItLjA1LS4yNC0uMS0uMzctLjE2LS4xMi0uMDUtLjI0LS4xMi0uMzUtLjE5LS4xMS0uMDctLjE5LS4xNS0uMjYtLjI0LS4wNy0uMDktLjEtLjItLjEtLjMyLDAtLjIyLjA4LS4zOC4yMi0uNS4xNS0uMTEuMzUtLjE3LjYyLS4xNy4yMSwwLC40LjAyLjU2LjA1LjE2LjA0LjI5LjA5LjQuMTQuMTEuMDYuMTkuMS4yNC4xNS4wNS4wNC4wOC4wNi4wOC4wN2wtLjE1LS44OHMtLjAyLS4wMi0uMDctLjA2Yy0uMDUtLjA0LS4xMy0uMDgtLjIzLS4xMy0uMTEtLjA1LS4yNS0uMDktLjQyLS4xMi0uMTctLjAzLS4zOS0uMDUtLjY0LS4wNC0uMjMsMC0uNDUuMDMtLjY1LjA5LS4yLjA2LS4zOC4xNS0uNTMuMjgtLjE1LjEyLS4yNy4yNy0uMzYuNDUtLjA5LjE4LS4xMy4zOS0uMTMuNjIsMCwuMjQuMDUuNDUuMTMuNjIuMDguMTcuMTkuMzIuMzMuNDMuMTQuMTIuMjkuMjIuNDUuMzEuMTYuMDguMzMuMTYuNDkuMjMuMTYuMDcuMzIuMTUuNDUuMjIuMTQuMDguMjUuMTcuMzMuMjcuMDguMS4xMy4yMy4xMy4zOCwwLC4yNC0uMDguNDItLjIzLjU0LS4xNS4xMi0uMzguMTctLjcuMTctLjE5LDAtLjM3LS4wMy0uNTUtLjA4LS4xOC0uMDUtLjM0LS4xLS40OC0uMTctLjE0LS4wNi0uMjYtLjEyLS4zNC0uMTctLjA4LS4wNS0uMTMtLjA3LS4xMy0uMDhsLjE1LDEuMDFjLjA3LjA0LjE3LjA5LjI5LjE0LjEzLjA2LjMuMS41LjE0LjIuMDQuNDUuMDYuNzMuMDUuMjcsMCwuNTMtLjA0Ljc3LS4xMi4yNC0uMDguNDUtLjIuNjQtLjM2LjE0LS4xMi4yNi0uMjguMzQtLjQ2LjA4LS4xOS4xMy0uNDEuMTMtLjY2aDBabS01LjM3LTEuMTFjMCwuMzgtLjA0LjcxLS4xMi45OS0uMDguMjgtLjIxLjUtLjM3LjY2LS4xNy4xNi0uMzguMjQtLjY0LjI0LS4yOSwwLS41My0uMDctLjcxLS4yLS4xOC0uMTQtLjMyLS4zNC0uNC0uNjItLjA5LS4yOC0uMTMtLjY0LS4xMy0xLjA3LDAtLjI2LjAxLS41Mi4wNC0uNzYuMDMtLjI0LjA5LS40Ni4xOC0uNjUuMDktLjE5LjIxLS4zNC4zOC0uNDUuMTYtLjExLjM3LS4xNy42NC0uMTcuMjEsMCwuMzguMDUuNTIuMTMuMTQuMDguMjUuMTkuMzMuMzMuMDguMTQuMTQuMjkuMTguNDcuMDQuMTcuMDcuMzUuMDguNTQuMDEuMTkuMDIuMzguMDIuNTZoMFptMS4xLS4wMmMwLS4yOS0uMDItLjU4LS4wNy0uODUtLjA1LS4yNy0uMTItLjUzLS4yMy0uNzYtLjExLS4yMy0uMjQtLjQ0LS40Mi0uNjItLjE3LS4xOC0uMzktLjMyLS42NC0uNDItLjI1LS4xLS41NS0uMTUtLjktLjE2LS4zNCwwLS42NC4wNS0uOS4xNS0uMjYuMS0uNDguMjQtLjY2LjQxLS4xOC4xOC0uMzMuMzgtLjQ0LjYyLS4xMS4yNC0uMi40OS0uMjUuNzctLjA1LjI4LS4wOC41Ni0uMDguODYsMCwuNDEuMDQuNzguMTIsMS4xMS4wOC4zMy4yMS42Mi40Ljg2LjE4LjI0LjQyLjQyLjcyLjU1LjMuMTMuNjYuMTksMS4wOC4yLjM2LDAsLjY3LS4wNy45NS0uMjEuMjgtLjE0LjUyLS4zMy43MS0uNTguMTktLjI1LjM0LS41NC40NC0uODcuMS0uMzMuMTUtLjY4LjE1LTEuMDZoMFptLTUuMzIuNTZjMC0uMjMtLjA0LS40NC0uMS0uNjMtLjA3LS4xOS0uMTctLjM1LS4zLS41LS4xNC0uMTctLjI5LS4zMS0uNDctLjQzLS4xOC0uMTItLjM2LS4yMy0uNTUtLjMyLS4xOS0uMDktLjM4LS4xOC0uNTctLjI2LS4xOS0uMDgtLjM2LS4xNi0uNTItLjI1LS4xNi0uMDgtLjMtLjE4LS40MS0uMjgtLjA3LS4wNy0uMTItLjE0LS4xNi0uMi0uMDQtLjA2LS4wNy0uMTMtLjA4LS4yLS4wMi0uMDctLjAyLS4xNC0uMDItLjIyLDAtLjE0LjAzLS4yNy4wOS0uNC4wNi0uMTMuMTctLjI1LjMyLS4zNS4xLS4wNy4yMy0uMTIuNC0uMTUuMTYtLjAzLjM2LS4wNS42LS4wNS4xMiwwLC4yNCwwLC4zNi4wMy4xMi4wMi4yMy4wNC4zMy4wNi4xNS4wMy4yOC4wNy4zOC4xMS4xLjA0LjE4LjA3LjI0LjEuMDYuMDMuMDkuMDUuMTEuMDdsLS4yNC0xLjAzcy0uMDMtLjAyLS4wOS0uMDVjLS4wNi0uMDMtLjE1LS4wNi0uMjctLjEtLjEyLS4wMy0uMjgtLjA2LS40Ny0uMDktLjE5LS4wMy0uNDItLjA0LS42OS0uMDQtLjIxLDAtLjQxLjAyLS42Mi4wNS0uMi4wNC0uNC4xLS41OC4xOC0uMTkuMDgtLjM2LjItLjUyLjM0LS4xNC4xMi0uMjYuMjYtLjM0LjQtLjA5LjE0LS4xNS4yOS0uMTkuNDQtLjA0LjE1LS4wNi4zLS4wNi40NSwwLC4xNy4wMi4zNC4wNS41LjAzLjE2LjA5LjMxLjE3LjQ2LjEuMTYuMjEuMy4zNi40Mi4xNC4xMi4zMS4yMy40OC4zMi4xOC4wOS4zNi4xOS41NS4yNy4xOS4wOS4zOC4xOC41Ni4yOC4xOS4xLjM2LjIxLjUyLjM0LjEuMDguMTkuMTYuMjYuMjQuMDcuMDguMTIuMTcuMTYuMjcuMDMuMS4wNS4yMS4wNS4zNCwwLC4yLS4wNC4zNy0uMTIuNS0uMDguMTQtLjE5LjI2LS4zNS4zNi0uMDguMDYtLjE3LjEtLjI4LjEzLS4xMS4wMy0uMjIuMDYtLjMzLjA3LS4xMS4wMi0uMjEuMDItLjMuMDMtLjA5LDAtLjE1LDAtLjE4LDAtLjExLDAtLjIyLDAtLjMzLS4wMi0uMTEtLjAxLS4yMi0uMDMtLjMyLS4wNS0uMjItLjA0LS40MS0uMDktLjU2LS4xMy0uMTUtLjA0LS4yNy0uMDgtLjM0LS4xMS0uMDgtLjAzLS4xMi0uMDQtLjEzLS4wNWwuMjYsMS4wMXMuMDQuMDIuMS4wNWMuMDYuMDMuMTYuMDcuMjkuMTEuMTMuMDQuMy4wOC41MS4xMS4yMS4wMy40NS4wNS43NC4wNS4yMiwwLC40NS0uMDIuNjktLjA1LjI0LS4wNC40Ny0uMS43LS4xOS4yMy0uMDkuNDMtLjIyLjYxLS4zOS4xOC0uMTYuMzMtLjM3LjQ0LS42My4xMS0uMjUuMTYtLjU2LjE3LS45MloiLz4KICAgICAgPGc+CiAgICAgICAgPGc+CiAgICAgICAgICA8Zz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtMi41MiwxNS4wNGMuNDQtMy4wNSwzLjUtMy44OCwzLjc5LTYuNjYtMS4zOC42MS0zLjAzLjQyLTQuMjQtLjU4LTEuMzQsMi40MS0xLjQxLDQuNzguNDUsNy4yNFoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtOC40Myw2LjE5YzEuNTYtLjIzLDIuOS0xLjMzLDQuMTgtMi40MSwxLjc3LTEuNSw0LjI0LTMuMzUsNi41OS0zLjE3QzE1LS42OSwxMC40NS4yNCw3LjY4LDEuOTRjMS4wNywxLjE4LDEuMzEsMi44NC43NSw0LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC41LDE1Ljk5Yy0uNDQsMy4wNS0zLjUsMy44OC0zLjc5LDYuNjYsMS4zOC0uNjEsMy4wMy0uNDIsNC4yNC41OCwxLjM0LTIuNDEsMS40MS00Ljc4LS40NS03LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yMi41OSwyNC44NGMtMS41Ni4yMy0yLjksMS4zMy00LjE4LDIuNDEtMS43NywxLjUtNC4yNCwzLjM1LTYuNTksMy4xNyw0LjIsMS4zLDguNzQuMzcsMTEuNTEtMS4zMy0xLjA3LTEuMTgtMS4zMS0yLjg0LS43NS00LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0xNS45OSwyLjUyYzMuMDUuNDQsMy44NywzLjUsNi42NiwzLjc5LS42MS0xLjM4LS40Mi0zLjAzLjU4LTQuMjQtMi40MS0xLjM0LTQuNzgtMS40MS03LjI0LjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yNC44NCw4LjQzYy4yMywxLjU2LDEuMzMsMi45LDIuNDEsNC4xOCwxLjUsMS43NywzLjM1LDQuMjQsMy4xNyw2LjU5LDEuMy00LjIuMzctOC43NC0xLjMzLTExLjUxLTEuMTgsMS4wNy0yLjg0LDEuMzItNC4yNC43NVoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0yIiBkPSJtMTUuMDQsMjguNWMtMy4wNS0uNDQtMy44OC0zLjUtNi42Ni0zLjc5LjYxLDEuMzguNDIsMy4wMy0uNTgsNC4yNCwyLjQxLDEuMzQsNC43OCwxLjQxLDcuMjQtLjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02LjE5LDIyLjU5Yy0uMjMtMS41Ni0xLjMzLTIuOS0yLjQxLTQuMTgtMS41LTEuNzctMy4zNC00LjI0LTMuMTctNi41OS0xLjMsNC4yLS4zNyw4Ljc0LDEuMzMsMTEuNTEsMS4xOC0xLjA3LDIuODQtMS4zMSw0LjI0LS43NVoiLz4KICAgICAgICAgIDwvZz4KICAgICAgICAgIDxnPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yOC43NiwyLjI2YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02Ljk2LDI0LjA3YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC43NiwyOC43NmMtMS4zLDEuMy0zLjQsMS4zLTQuNywwLTEuMy0xLjMtMS4zLTMuNCwwLTQuNywxLjMtMS4zLDMuNC0xLjMsNC43LDBzMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im02Ljk2LDYuOTZjLTEuMywxLjMtMy40LDEuMy00LjcsMC0xLjMtMS4zLTEuMy0zLjQsMC00LjcsMS4zLTEuMywzLjQtMS4zLDQuNywwLDEuMywxLjMsMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgICAgICA8Zz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMiIgZD0ibTE0LjEsMTguMzF2MS4xN2gyLjgzdi0yLjU1bDIuNDMsMi4zNWMuMi4xOS4xOS4zLjE5LjQ5di44czAsLjAyLDAsLjA0aDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAyLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMiwwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMtLjAxLjA0aDBzMCwuMDMtLjAxLjAzaDBzMCwuMDIsMCwuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMtLjAxLjAzLS4wMi4wNGgwczAsLjAyLS4wMS4wM2gwczAsLjAyLS4wMS4wM2gwczAsLjAzLS4wMi4wM2gwczAsLjAyLS4wMS4wM2gwcy0uMDEuMDItLjAyLjAzYzAsMCwwLDAtLjAxLjAxLDAsMCwwLC4wMS0uMDEuMDJoMHMwLC4wMi0uMDEuMDJjMCwwLDAsMC0uMDEuMDEsMCwwLS4wMS4wMS0uMDIuMDIsMCwwLDAsMC0uMDEuMDEsMCwwLDAsMC0uMDEuMDFoLS4wMXMtLjAxLjAyLS4wMS4wMmMwLDAsMCwwLS4wMS4wMWgwcy0uMDEuMDEtLjAyLjAyaDBzMCwwLS4wMS4wMWMwLDAsMCwwLS4wMS4wMWgtLjAxcy0uMDEuMDItLjAxLjAyYzAsMC0uMDIuMDEtLjAyLjAyaC0uMDFzMCwuMDItLjAxLjAyaC0uMDFzMCwuMDItLjAxLjAyYzAsMCwwLDAtLjAxLDAsMCwwLS4wMi4wMS0uMDMuMDJoMHMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaC0uMDFzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaDBzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAyLjAxLS4wMi4wMWMwLDAsMCwwLS4wMSwwLS4yLjA5LS40MS4xNC0uNjQuMTRoLTMuOTF2MS4xN2wtMi41LTIuNDgsMi41LTIuNDhoMFptMi44My00LjIxaDIuNTV2Mi44M2gtMS4xN2wyLjQ4LDIuNSwyLjQ4LTIuNWgtMS4xN3YtMy45MWMwLS4yMy0uMDUtLjQ1LS4xNC0uNjQsMCwwLDAsMCwwLS4wMXYtLjAycy0uMDEtLjAxLS4wMS0uMDFjMC0uMDEtLjAxLS4wMi0uMDItLjAzaDBzMC0uMDIsMC0uMDJoMHMwLS4wMiwwLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRoMHMwLS4wMi0uMDEtLjAzaDBzMC0uMDItLjAxLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRjMCwwLDAsMCwwLS4wMSwwLDAsMCwwLS4wMS0uMDFoMHMwLS4wMi0uMDEtLjAzaDBzLS4wMS0uMDMtLjAyLS4wM2gtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMWgwcy0uMDEtLjAxLS4wMi0uMDJoMHMwLDAtLjAxLS4wMWgtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMSwwLDAtLjAxLS4wMS0uMDItLjAyLDAsMCwwLDAtLjAxLDAsMCwwLDAsMC0uMDEtLjAxaC0uMDFzLS4wMS0uMDItLjAyLS4wMmMwLDAsMCwwLS4wMS0uMDEsMCwwLS4wMS0uMDEtLjAyLS4wMWgtLjAxczAtLjAyLS4wMS0uMDJoLS4wMXMtLjAxLS4wMi0uMDItLjAyaC0uMDFzLS4wMS0uMDItLjAyLS4wMmgtLjAxcy0uMDEtLjAyLS4wMi0uMDJoLS4wMXMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDEtLjAxLS4wMi0uMDJoMHMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDItLjAxLS4wMi0uMDJoMHMtLjAyLS4wMS0uMDMtLjAyaDBzLS4wMSwwLS4wMi0uMDFoLS4wMXMtLjAyLS4wMS0uMDMtLjAxaDBzLS4wMiwwLS4wMy0uMDFoLS4wMXMtLjAxLDAtLjAyLS4wMWgwcy0uMDIsMC0uMDMtLjAxaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wNCwwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wNCwwaC0uOGMtLjE4LDAtLjI5LS4wMi0uNDkuMTlsLTIuMzUsMi40M2gwWm0tMi44MywyLjgzaC0yLjU1di0yLjgzaDEuMTdsLTIuNDgtMi41LTIuNDgsMi41aDEuMTd2My45MWMwLC4yMy4wNS40NS4xNC42NCwwLDAsMCwwLDAsLjAxdi4wMnMuMDEuMDEuMDEuMDFjMCwuMDEuMDEuMDIuMDIuMDNoMHMwLC4wMiwwLC4wMmgwczAsLjAyLDAsLjAzaDBzLjAxLjAzLjAyLjA0aDBzMCwuMDIuMDEuMDNoMHMwLC4wMi4wMS4wM2gwcy4wMS4wMy4wMi4wNGMwLDAsMCwwLDAsLjAxLDAsMCwwLDAsLjAxLjAxaDBzMCwuMDIuMDEuMDNoMHMuMDEuMDMuMDIuMDRoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMWgwcy4wMS4wMS4wMi4wMmgwczAsMCwuMDEuMDFoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMSwwLDAsLjAxLjAxLjAyLjAyLDAsMCwwLDAsLjAxLjAxLDAsMCwwLDAsLjAxLjAxaC4wMXMuMDEuMDIuMDIuMDJjMCwwLDAsMCwuMDEuMDEsMCwwLC4wMS4wMS4wMi4wMWguMDFzMCwuMDIuMDEuMDJoLjAxcy4wMS4wMi4wMi4wMmguMDFzLjAxLjAyLjAyLjAyaC4wMXMuMDEuMDIuMDIuMDJoLjAxcy4wMi4wMi4wMy4wMmgwcy4wMS4wMS4wMi4wMmguMDFzLjAxLjAxLjAyLjAyaDBzLjAyLjAyLjAzLjAyaDBzLjAxLjAxLjAyLjAyaDBzLjAyLjAxLjAyLjAyaDBzLjAyLjAxLjAzLjAyaDBzLjAxLjAxLjAyLjAxaC4wMXMuMDIuMDEuMDMuMDFoMHMuMDIsMCwuMDMuMDFoMHMuMDIsMCwuMDIuMDFoLjAxcy4wMiwwLC4wMy4wMWgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoMHMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaC4wMXMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoLjAxcy4wMiwwLC4wMywwaDBzLjAyLDAsLjA0LDBoMHMuMDIsMCwuMDMsMGguMDFzLjAyLDAsLjA0LDBoLjhjLjE4LDAsLjI5LjAyLjQ5LS4xOWwyLjM1LTIuNDNoMFptMC0yLjgzbC0yLjQzLTIuMzVjLS4yMS0uMi0uMTktLjMtLjE5LS40OXYtLjhzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA1aDBzMC0uMDIsMC0uMDRoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAyLjAxLS4wNGgwczAtLjAyLDAtLjAzaDBzMC0uMDMuMDEtLjA0aDBzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwcy4wMS0uMDMuMDItLjA0aDBzMC0uMDIuMDEtLjAzaDBzMC0uMDIuMDEtLjAzaDBzMC0uMDMuMDItLjAzaDBzMC0uMDIuMDEtLjAzaDBzLjAxLS4wMi4wMS0uMDNjMCwwLDAsMCwuMDEtLjAxLDAsMCwwLS4wMS4wMS0uMDJoMHMwLS4wMi4wMS0uMDJjMCwwLDAsMCwuMDEtLjAxLDAsMCwuMDEtLjAxLjAyLS4wMiwwLDAsMCwwLC4wMS0uMDEsMCwwLDAsMCwuMDEtLjAxaC4wMXMuMDEtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMS0uMDFoMHMuMDEtLjAxLjAyLS4wMmgwczAsMCwuMDEtLjAxYzAsMCwwLDAsLjAxLS4wMWguMDFzLjAxLS4wMi4wMS0uMDJjMCwwLC4wMi0uMDEuMDItLjAyaC4wMXMwLS4wMi4wMS0uMDJoLjAxczAtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMSwwLDAsMCwuMDItLjAxLjAzLS4wMmgwcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmguMDFzLjAyLS4wMi4wMy0uMDJoLjAxcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmgwcy4wMi0uMDIuMDMtLjAyaC4wMXMuMDItLjAxLjAyLS4wMWMwLDAsMCwwLC4wMSwwLC4yLS4wOS40MS0uMTQuNjQtLjE0aDMuOTF2LTEuMTdsMi41LDIuNDgtMi41LDIuNDh2LTEuMTdoLTIuODN2Mi41NVoiLz4KICAgICAgICAgIDxwb2x5Z29uIGNsYXNzPSJjbHMtNSIgcG9pbnRzPSIxNC4xMSAxOS40NSAxNC4xMSAxNi45MiAxMS41NyAxNi45MiAxMS41NyAxNC4xMSAxNC4xMSAxNC4xMSAxNC4xMSAxMS41NyAxNi45MiAxMS41NyAxNi45MiAxNC4xMSAxOS40NSAxNC4xMSAxOS40NSAxNi45MiAxNi45MiAxNi45MiAxNi45MiAxOS40NSAxNC4xMSAxOS40NSIvPgogICAgICAgIDwvZz4KICAgICAgPC9nPgogICAgPC9nPgogIDwvZz4KPC9zdmc+",ft=i=>i.replace(/\s+/g," ").replace(/Telep\s+on/gi,"Telepon").replace(/Kunjunga\s+n/gi,"Kunjungan").replace(/Spes\s+ialis/gi,"Spesialis").trim();function Ma(i){let L=i.find(w=>/^SEP$/i.test(w.title)),a=L?yt(L.html):"",e=L&&new DOMParser().parseFromString(L.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",n=w=>ft(a.match(w)?.[1]||"")||"-",r=(w,k)=>n(new RegExp(`${w}\\s*:\\s*([\\s\\S]*?)(?=${k}|$)`,"i")),s=M("no_sep","sep")!=="-"?M("no_sep","sep"):n(/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]+)/i),l=n(/Tgl\.?\s*SEP\s*[:.]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})/i),o=M("no_hp","telepon")!=="-"?M("no_hp","telepon"):r("No\\.?\\s*Telepon","Sub\\/Spesialis"),y=M("kelas").replace(/^Kelas\s*/i,""),C=M("tgl_lahir","tglLahir").replace(/^:\s*/,"").split(/\s*\/\s*/)[0]?.trim()||"-",m=r("Kelamin","No\\.?\\s*Telepon"),$=M("dokter","dpjp"),h=M("kartu","no_kartu","noka"),p=M("norm","rekam_medis"),z=M("nama")||"-",N=h.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),v=N?`${t(N[1].trim())}<span class="sep-inline-mr">No.MR : ${t(N[2].trim())}</span>`:`${t(h)}${p!=="-"?`<span class="sep-inline-mr">No.MR : ${t(p)}</span>`:""}`,O=M("jenis_kunjungan")!=="-"?M("jenis_kunjungan"):n(/Jns\.?\s*Kunjungan\s*[:.]?\s*([\s\S]*?)(?:\s+Kls\.?\s*Hak|$)/i),K=O.replace(/^-\s*/,"").split(/\s+-\s+|\n/).map(w=>w.trim()).filter(Boolean),Q=K.length>1?'<ul class="sep-multiline-list">'+K.map(w=>`<li>${t(w)}</li>`).join("")+"</ul>":t(O),D=M("peserta","jenis_peserta")!=="-"?M("peserta","jenis_peserta"):r("(?<!Nama )Peserta","COB|Jns\\.?\\s*Rawat"),Y=M("penjamin")!=="-"?M("penjamin"):r("Penjamin","\\*Saya|CATATAN"),P=M("faskes_perujuk","faskes")!=="-"?M("faskes_perujuk","faskes"):r("Faskes\\s*Perujuk","Diagnosa\\s*Awal"),x=M("diagnosa_awal")!=="-"?M("diagnosa_awal"):r("Diagnosa\\s*Awal","Catatan|Peserta"),E=M("catatan_sep","catatan")!=="-"?M("catatan_sep","catatan"):r("Catatan","Peserta|COB"),S=M("sub_spesialis","spesialis")!=="-"?M("sub_spesialis","spesialis"):r("Sub\\/Spesialis","Dokter"),R=n(/Cetakan\s+ke\s*[:.]?\s*(\d+)/i),A=R!=="-"?`<div class="sep-print-meta">Cetakan ke ${t(R)}</div>`:"",c=(w,k,T="",j=!1)=>`<tr><td class="lbl${j?" right":""}">${w}</td><td class="sep">:</td><td class="val${T?" "+T:""}">${k}</td></tr>`,U='<tr><td colspan="3">&nbsp;</td></tr>',g=y!=="-"?`Kelas ${t(y)}`:"-";return`<section class="rm-page sep-page" id="rm-01">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${zt}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT ELEGIBILITAS PESERTA</div>
     <div class="sep-hospital">${t(mt.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-columns">
   <div class="sep-col-left"><table class="sep-kv-table">
     ${c("No. SEP",`<span class="sep-no-value">${t(s)}</span>`)}
     ${c("Tgl. SEP",t(l))}
     ${c("No.Kartu",v)}
     ${c("Nama Peserta",`<strong>${t(z)}</strong>`)}
     ${c("Tgl.Lahir",`${t(C)} &nbsp;&nbsp; Kelamin : ${t(m)}`)}
     ${c("No.Telepon",t(o))}
     ${c("Sub/Spesialis",t(S))}
     ${c("Dokter",t($))}
     ${c("Faskes Perujuk",t(P!=="-"?P:`${mt} - Kota Jambi`))}
     ${c("Diagnosa Awal",t(x))}
     ${c("Catatan",t(E))}
   </table></div>
   <div class="sep-col-right"><table class="sep-kv-table">
     ${U}${U}
     ${c("Peserta",t(D),"",!0)}
     ${c("COB","-","",!0)}
     ${c("Jns.Rawat",`<strong>${t(M("jenis"))}</strong>`,"",!0)}
     ${c("Jns.Kunjungan",Q,"",!0)}
     ${c("Kls.Hak",`<strong>${g}</strong>`,"",!0)}
     ${c("Kls.Rawat",`<strong>${g}</strong>`,"",!0)}
     ${c("Penjamin",t(Y),"",!0)}
   </table></div>
 </div>
 <div class="sep-disclaimer">
   *Saya Menyetujui BPJS Kesehatan menggunakan informasi Medis Pasien jika diperlukan.<br/>
   *SEP bukan sebagai bukti penjamin peserta
 </div>
 ${A}
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div class="sep-sig-role">Pasien/<br/>Keluarga Pasien</div>
     ${e?`<img class="sep-qr" src="${t(e)}" alt="QR SEP" width="100" height="100" />`:""}
     <div class="sep-sig-name">(${t(z)})</div>
   </div>
 </div>
 </section>
</section>`}function sa(i){let L=i.find(P=>/^SPRI$/i.test(P.title)),a=V(i,/^SPRI$/i)[0]??"",e=L?new DOMParser().parseFromString(L.html,"text/html"):null,n=P=>{if(!e)return"-";for(let x of Array.from(e.querySelectorAll("tr"))){let E=Array.from(x.cells);if(!E.length)continue;let S=(E[0].textContent||"").replace(/\s+/g," ").trim();if(!P.test(S))continue;if(E.length===1)return S;let R=E.slice(1).map(A=>(A.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()).filter(Boolean).join(`
`).trim();if(R)return R}return"-"},r=(P,x)=>x.match(P)?.[1]?.trim()||"-",s=n(/^Pemeriksaan Fisik$/i),l=r(/Keadaan Umum\s*:\s*(.*?)\s*(?:Tensi|$)/i,s),o=r(/Tensi\s*:\s*(.*?)\s*(?:Nadi|$)/i,s),y=r(/Nadi\s*:\s*(.*?)\s*(?:RR|$)/i,s),C=r(/RR\s*:\s*(.*?)\s*(?:Suhu|$)/i,s),m=r(/Suhu\s*:\s*(.*?)\s*(?:BB|$)/i,s),$=r(/BB\s*:\s*(.*?)\s*(?:TB|$)/i,s),h=r(/TB\s*:\s*(.*?)$/i,s),p=r(/Pemeriksaan Fisik\s*:\s*([\s\S]*)$/i,s),z=n(/^Catatan$/i),N=n(/^Diit$/i),v=n(/^Terapi$/i),O=n(/^Kota Jambi,.*Jam|^Waktu Pengantar/i),K=O.match(/^(Kota Jambi,.*?Jam\s*\d{1,2}:\d{2})/i)?.[1]||O,Q=M("dokter","dpjp"),D=M("tgl_lahir","tglLahir").split(/\s*\/\s*/),Y=D.length>1?`${D[1]} (${D[0]})`:D[0]||"-";return`<section class="rm-page" id="rm-03">
${H("RM. 03")}
<div class="rm-form-title">SURAT PENGANTAR RAWAT INAP (SPRI)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${u("Umur / Tgl. Lahir",Y)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Alamat",jt(i))}
    ${u("Dikirim Oleh",Q)}
    ${u("Waktu Pengantar",K)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr><th colspan="7">PEMERIKSAAN TANDA VITAL &amp; ANTROPOMETRI SAAT MASUK</th></tr>
    <tr>
      <th>KEADAAN UMUM</th><th>TEKANAN DARAH</th><th>NADI</th>
      <th>PERNAPASAN (RR)</th><th>SUHU</th><th>BERAT BADAN</th><th>TINGGI BADAN</th>
    </tr>
  </thead>
  <tbody><tr>
    <td class="center"><strong>${t(l)}</strong></td>
    <td class="center"><strong>${t(o)}</strong></td>
    <td class="center">${t(y)}</td>
    <td class="center">${t(C)}</td>
    <td class="center">${t(m)}</td>
    <td class="center">${t($)}</td>
    <td class="center">${t(h)}</td>
  </tr></tbody>
</table>

<table class="rm-grid-table">
  <tbody>
    <tr><td style="width: 175px;"><strong>ANAMNESIS</strong></td><td>${G(n(/^Anamnesis$/i))}</td></tr>
    <tr><td><strong>RIWAYAT PENYAKIT KELUARGA</strong></td><td>${G(n(/^Riwayat Penyakit Keluarga$/i))}</td></tr>
    <tr><td><strong>RIWAYAT ALERGI</strong></td><td>${G(n(/^Riwayat Alergi$/i))}</td></tr>
    <tr><td><strong>PEMERIKSAAN FISIK / CATATAN</strong></td><td>${p!=="-"?`<strong>${G(p)}</strong>`:"-"}${z!=="-"?`<br/>${G(z)}`:""}</td></tr>
    <tr><td><strong>PEMERIKSAAN PENUNJANG AWAL</strong></td><td>${G(n(/^Pemeriksaan Penunjang$/i))}</td></tr>
    <tr><td><strong>DIAGNOSA KERJA</strong></td><td><strong>${G(n(/^Diagnosa Kerja$/i))}</strong></td></tr>
    <tr><td><strong>TERAPI &amp; DIIT AWAL</strong></td><td>${G(v)}${N!=="-"?`<br/><strong>Diit :</strong> ${G(N)}`:""}</td></tr>
  </tbody>
</table>

<div class="rm-signature-block" style="justify-content:flex-end;">
  <div class="rm-sig-box">
    <div>${t(K)}</div>
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(Q)} )</div>
  </div>
</div>
</section>`}function La(i){let L=i.find(E=>/^SBPK$/i.test(E.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=new Map,n=new Map,r=[],s="-";if(a){for(let R of Array.from(a.querySelectorAll("tr"))){let A=Array.from(R.cells);for(let c=0;c<A.length-2;c++){let U=(A[c].textContent||"").replace(/\s+/g," ").trim();if((A[c+1].textContent||"").trim()!==":")continue;let g=(A[c+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();U&&g&&!e.has(U)&&e.set(U,g)}A.length>=5&&/^[A-Z]\d{2}(?:\.\d+)?$/.test(A[2].textContent?.trim()??"")&&A[0].textContent?.trim()&&A[1].textContent?.trim()&&r.push({unit:(A[0].textContent||"").replace(/\s+/g," ").trim(),diag:(A[1].textContent||"").replace(/\s+/g," ").trim(),icd:(A[2].textContent||"").trim(),dokter:(A[4].textContent||"").replace(/\s+/g," ").trim()||"-"})}for(let R of Array.from(a.querySelectorAll("li"))){let A=(R.textContent||"").replace(/\s+/g," ").trim();if(!A||/\([A-Z]\d{2}(?:\.\d+)?\)$/i.test(A))continue;let c=A.toUpperCase();n.set(c,(n.get(c)||0)+1)}let E=Array.from(a.querySelectorAll("table")),S=(E[E.length-1]?.textContent||"").match(/\((dr\.[^)]+)\)/i);S&&(s=S[1].trim())}let l=E=>{for(let[S,R]of e)if(E.test(S))return R;return"-"},o=l(/^No Kartu BPJS$/i),y=M("norm","rekam_medis"),C=M("nama"),m=l(/^Tanggal lahir/i),$=l(/^Alamat$/i),h=M("no_sep","sep")!=="-"?M("no_sep","sep"):l(/^No SEP$/i),p=l(/^Jenis Kelamin$/i),z=/^L$/i.test(p)?"Laki-laki (L)":/^P$/i.test(p)?"Perempuan (P)":p,N=l(/^Tgl\.? Masuk RS$/i),v=l(/^Berat badan/i),O=r[0]?.unit||l(/^Unit Pelayanan|^Poliklinik/i),K=l(/^ANAMNESE$/i),Q=s!=="-"?s:M("dokter","dpjp"),D=V(i,/^SBPK/i)[0]??"",Y=V(i,/^SEP/i)[0]??V(i,/^Rincian Biaya/i)[0]??"",P=r.length?r.map(E=>`<tr><td>${t(E.unit)}</td><td>Diagnosa</td><td><strong>${t(E.diag)}</strong></td><td class="center">${t(E.icd)}</td><td>${t(E.dokter)}</td></tr>`).join(""):`<tr><td>${G(O)}</td><td>Diagnosa Utama</td><td><strong>${G(l(/^Diagnosa utama/i))}</strong></td><td class="center">-</td><td>${t(Q)}</td></tr>
       <tr><td>${G(O)}</td><td>Diagnosa Tambahan</td><td>${G(l(/^Diagnosa tambahan/i))}</td><td class="center">-</td><td>${t(Q)}</td></tr>`,x=Array.from(n.entries()).map(([E,S],R)=>`<tr><td class="center">${R+1}</td><td>${t(E)}</td><td>${t(Q)}</td><td class="center">${S}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi SBPK Item ${R+1}"></td></tr>`).join("");return`<section class="rm-page" id="rm-02">
${H("RM. 02")}
<div class="rm-form-title">SURAT BUKTI PELAYANAN KESEHATAN (SBPK)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("No. Kartu BPJS",o)}
    ${u("No. Rekam Medis",y)}
    ${u("Nama Pasien",C,!0)}
    ${u("Tgl. Lahir / Umur",m)}
    ${u("Alamat",$)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("No. SEP",h)}
    ${u("Jenis Kelamin",z)}
    ${u("Tgl. Masuk RS",`${N} (*)`,!0)}
    ${u("Berat Badan Bayi",v)}
    ${u("Unit Pelayanan",O)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    <tr>
      <td style="width: 170px;"><strong>Hasil anamnesa datang untuk</strong></td>
      <td>
        <span class="static-box">&nbsp;</span> Suspek &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&#10003;</span> <strong>Tegak Diagnosa</strong> &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Observasi &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Kontrol lanjutan &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Buka Balutan / Jahitan
      </td>
    </tr>
    <tr><td><strong>ANAMNESE</strong></td><td>${G(K)}</td></tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 150px;">POLIKLINIK / RUANG</th>
    <th style="width: 120px;">JENIS DIAGNOSA</th>
    <th>DIAGNOSA</th>
    <th style="width: 65px;">ICD X</th>
    <th style="width: 165px;">DOKTER / PETUGAS</th>
  </tr></thead>
  <tbody>${P}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>TINDAKAN / PEMERIKSAAN PENUNJANG / TERAPI (TERAGGREGASI)</th>
    <th style="width: 165px;">UNIT / DOKTER PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${x}</tbody>
</table>

<div class="footnote-rm">
  (*) Catatan Sistem: periksa kembali tanggal masuk pada SBPK dengan SEP &amp; Resume sebelum berkas dikirim.
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Pasien / Keluarga Pasien</div>
    ${Y?`<img class="rm-sig-qr" src="${t(Y)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${Y?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(C)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penanggung Jawab Pelayanan (DPJP)</div>
    ${D?`<img class="rm-sig-qr" src="${t(D)}" alt="QR persetujuan DPJP" width="80" height="80" />`:""}
    ${D?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(Q)} )</div>
  </div>
</div>
</section>`}var vt=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];function Dt(i){let L=String(i??"").replace(/^\s*:\s*/,"").trim(),a=L.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/)||L.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(!a)return L||"-";let[e,n,r]=a.slice(1),s=e.length===4?e:r,l=vt[Number(n)-1];return l?`${Number(e.length===4?r:e)} ${l} ${s}`:L}function ua(i){let L=i.find(P=>/^Surat (?:Rencana )?Kontrol/i.test(P.title)),a=L?yt(L.html):"",e=P=>ft(a.match(P)?.[1]||"")||"-",n=(P,x)=>e(new RegExp(`${P}\\s*:\\s*([\\s\\S]*?)(?=${x}|$)`,"i")),r=(P,x)=>{for(let E of P){let S=M(E);if(S!=="-")return S}return e(x)},s=L&&new DOMParser().parseFromString(L.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||""||V(i,/^SEP/i)[0]||V(i,/^Resume/i)[0]||V(i,/^SBPK/i)[0]||V(i,/^Rincian Biaya/i)[0]||"",l=r(["no_surat_kontrol","no_surat"],/NO\.\s*([0-9A-Z]{10,})/i),o=e(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i)!=="-"?e(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i):M("dokter","dpjp"),y=M("dokter","dpjp")!=="-"?M("dokter","dpjp"):o,C=r(["kartu","no_kartu","noka"],/No\.?\s*Kartu\s*[:.]?\s*([\s\S]*?)(?=Nama\s*Peserta|$)/i),m=M("norm","rekam_medis"),$=C.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),h=$?`${t($[1].trim())}<span class="sep-inline-mr">No.MR : ${t($[2].trim())}</span>`:`${t(C)}${m!=="-"?`<span class="sep-inline-mr">No.MR : ${t(m)}</span>`:""}`,p=M("nama")!=="-"?M("nama"):n("Nama\\s*Peserta","Tanggal Lahir"),z=M("jenis_kelamin","jk"),N=/perempuan|^p$/i.test(z)?"Perempuan":/laki|^l$/i.test(z)?"Laki-laki":a.match(/Nama Peserta\s*:\s*[^()]*\((Perempuan|Laki-laki)\)/i)?.[1]||"",v=N&&!new RegExp(`\\(${N}\\)`,"i").test(p)?`${p} (${N})`:p,O=Dt(r(["tgl_lahir","tglLahir"],/Tanggal Lahir\s*[:.]?\s*([\s\S]*?)(?=Diagnosa|$)/i)),K=r(["diagnosa_awal","diagnosa"],/Diagnosa\s*[:.]?\s*([\s\S]*?)(?=Tanggal entri|$)/i),Q=Dt(r(["tanggalAwal","tgl_masuk","tgl"],/Tanggal entri\s*[:.]?\s*([\s\S]*?)(?=Demikian|$)/i)),D=(P,x)=>`<tr><td class="lbl">${P}</td><td class="sep">:</td><td class="val">${x}</td></tr>`,Y=P=>`<tr><td class="val" colspan="3" style="padding-top:6px;">${t(P)}</td></tr>`;return`<section class="rm-page sep-page" id="surat-kontrol">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${zt}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT RENCANA KONTROL</div>
     <div class="sep-hospital">${t(mt.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-no-value" style="text-align:right;margin-bottom:10px;">NO. ${t(l)}</div>
 <div class="sep-columns">
   <div class="sep-col-left" style="flex:1 1 100%;"><table class="sep-kv-table">
     <tr><td class="lbl">Kepada Yth</td><td class="sep">:</td><td class="val"><strong>${t(o)}</strong></td></tr>
     ${Y("Mohon pemeriksaan dan penangan lebih lanjut :")}
     ${D("No.Kartu",h)}
     ${D("Nama Peserta",`<strong>${t(v)}</strong>`)}
     ${D("Tanggal Lahir",t(O))}
     ${D("Diagnosa",t(K))}
     ${D("Tanggal entri",t(Q))}
     ${Y("Demikian atas bantuannya, diucapkan banyak terima kasih.")}
   </table></div>
 </div>
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div>Mengetahui,</div>
     ${s?`<img class="sep-qr" src="${t(s)}" alt="QR tanda tangan DPJP" width="100" height="100" />`:""}
     <div class="sep-sig-name">( ${t(y)} )</div>
   </div>
 </div>
 </section>
</section>`}function ra(i){let L=i.find(g=>/^Rincian Biaya/i.test(g.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=new Map,n=new Map;if(a){let g=Array.from(a.querySelectorAll("table")),w=g.find(T=>/frek/i.test(T.rows[0]?.textContent||""));for(let T of Array.from(w?.rows??[])){let j=Array.from(T.cells).map(at=>(at.textContent||"").replace(/\s+/g," ").trim());if(j.length<6||!/^\d+\.?$/.test(j[0]))continue;let b=j[2]||"-",B=b.toUpperCase().replace(/\s+/g," ").trim(),W=parseInt(j[4],10)||1,X=parseFloat((j[7]||"0").replace(/\./g,"").replace(",","."))||0,Mt=e.get(B);Mt?(Mt.frek+=W,Mt.jaminan+=X):e.set(B,{name:b,petugas:j[3]||"-",frek:W,tarif:j[5]||"-",jaminan:X})}let k=g.find(T=>/nama\s*obat/i.test(T.rows[0]?.textContent||""));for(let T of Array.from(k?.rows??[])){let j=Array.from(T.cells).map(at=>(at.textContent||"").replace(/\s+/g," ").trim());if(j.length<5||!/^\d+(\.\d+)?$/.test(j[2]))continue;let b=j[1].replace(/^\d+\s*/,"").trim()||"-",B=b.toUpperCase().replace(/\s+/g," ").trim(),W=parseFloat(j[2].replace(",","."))||0,X=parseFloat((j[5]||"0").replace(/\./g,"").replace(",","."))||0,Mt=n.get(B);Mt?(Mt.qty+=W,Mt.jaminan+=X):n.set(B,{name:b,qty:W,jaminan:X})}}let r=g=>{if(!a)return 0;for(let w of Array.from(a.querySelectorAll("tr"))){let k=Array.from(w.cells).map(T=>(T.textContent||"").replace(/\s+/g," ").trim());if(k.some(T=>g.test(T)))for(let T of k.slice(1)){let j=parseFloat(T.replace(/\./g,"").replace(",","."));if(Number.isFinite(j)&&j!==0)return j}}return 0},s=r(/^Total Jasa Rp/i),l=r(/^Total Resep/i),o=r(/^Jasa Pelayanan/i),y=r(/^Biaya Administrasi/i),C=r(/^Biaya Materai/i),m=r(/^Diskon/i),$=r(/^Pembulatan/i),h=r(/^Total Biaya/i),p=s+l+o,z=Math.max(0,p-h),N=g=>g.toLocaleString("id-ID",{minimumFractionDigits:0,maximumFractionDigits:0}),v=(g,w,k=!1)=>`<div class="rm-sum-line"${k?' style="font-weight:bold;border-top:1px solid #000;"':""}><span>${t(g)}</span><span class="rm-sum-dots"></span><span>${t(w)}</span></div>`,O=Array.from(e.values()).map((g,w)=>`<tr><td class="center">${w+1}</td><td>${t(g.name)}</td><td>${t(g.petugas)}</td><td class="center">${g.frek}</td><td class="num">${t(g.tarif)}</td><td class="num">${N(g.jaminan)}</td></tr>`).join(""),K=Array.from(n.values()).map((g,w)=>`<tr><td class="center">${w+1}</td><td>${t(g.name)}</td><td class="center">${g.qty}</td><td class="num">${N(g.jaminan)}</td></tr>`).join(""),Q=M("norm","rekam_medis"),D=M("nama"),Y=M("dokter","dpjp"),P=jt(i),x=M("no_sep","sep"),E=[M("jenis"),M("kelas","ruang")].filter(g=>g!=="-").join(" / ")||"-",S=M("tanggalAwal","tgl_masuk","tgl"),R=M("tanggalAkhir","keluar","tgl_keluar"),A=V(i,/^Rincian Biaya/i),c=A.find(g=>/pasien/i.test(decodeURIComponent(g)))??A[0]??"",U=A.find(g=>/penerima/i.test(decodeURIComponent(g)))??A[1]??"";return`<section class="rm-page" id="rm-05">
${H("RM. 05")}
<div class="rm-form-title">RINCIAN BIAYA PELAYANAN RAWAT INAP &amp; FARMASI</div>

<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${u("No. Rekam Medis",Q)}
    ${u("Nama Pasien",D,!0)}
    ${u("Alamat Pasien",P)}
    ${u("Unit / Instalasi",E)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Golongan Pasien",`BPJS KESEHATAN (SEP: ${x})`)}
    ${u("Dokter DPJP",Y)}
    ${u("Periode Rawat",`${S} s/d ${R}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>URAIAN TINDAKAN / PELAYANAN</th>
    <th style="width: 155px;">DOKTER / PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="num" style="width: 88px;">TARIF (Rp)</th>
    <th class="num" style="width: 98px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${O}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>NAMA OBAT / ALKES</th>
    <th class="center" style="width: 52px;">QTY</th>
    <th class="num" style="width: 120px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${K}</tbody>
</table>

<div class="rm-summary">
  ${v("Sub Total Layanan Medis / Tindakan",N(s))}
  ${v("Sub Total Penjualan (Farmasi/Obat)",N(l))}
  ${v("Jasa Pelayanan (Jasa Medis/Paramudis)",N(o))}
  ${v("Jasa Sarana","0")}
  ${v("Biaya Administrasi",N(y))}
  ${v("Biaya Materai",N(C))}
  ${v("Diskon",N(m))}
  ${v("Pembulatan",N($))}
  ${v("TOTAL TAGIHAN (KOTOR)",N(p),!0)}
  ${v("Ditanggung Jaminan / Klaim BPJS",N(h))}
  ${v("TANGGUNGAN PASIEN (Sisa yang harus dibayar)",N(z))}
  ${v("Uang Muka / Deposit","0")}
  ${v("Bayar (Tunai/Non-Tunai)",N(z))}
  ${v("Kembali","0")}
  ${v("Status",z===0?"Lunas":"-")}
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Yang Menyerahkan,</div>
    <div>Pasien / Keluarga Pasien</div>
    ${c?`<img class="rm-sig-qr" src="${t(c)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${c?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(D)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Yang Menerima</div>
    ${U?`<img class="rm-sig-qr" src="${t(U)}" alt="QR penerima" width="80" height="80" />`:""}
    ${U?"":'<div class="rm-sig-space"></div>'}
    <div>(Petugas Billing / Kasir)</div>
  </div>
</div>
</section>`}function na(i){let L=i.find(g=>/^Resume/i.test(g.title)),a=V(i,/^Resume/i)[0]??"",e=V(i,/^SEP/i)[0]??V(i,/^Rincian Biaya/i)[0]??"",n=L?new DOMParser().parseFromString(L.html,"text/html"):null,r=new Map;if(n)for(let g of Array.from(n.querySelectorAll("tr"))){let w=Array.from(g.cells);for(let k=0;k<w.length-2;k++){let T=(w[k].textContent||"").replace(/\s+/g," ").trim().replace(/^-\s*/,"").replace(/\s*:$/,"");if((w[k+1].textContent||"").trim()!==":")continue;let j=(w[k+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();T&&j&&!r.has(T)&&r.set(T,j)}}let s=(...g)=>{for(let[w,k]of r)if(g.some(T=>T.test(w)))return k;return"-"},l=g=>{for(let[w,k]of r)if(g.test(w))return k;return"-"},o=M("nama"),y=M("norm","rekam_medis"),C=M("tgl_lahir","tglLahir"),m=M("jenis_kelamin","jk"),$=s(/^Tanggal Masuk$/i),h=s(/^Tanggal Keluar$/i),p=s(/^Ruang Rawat$/i),z=s(/^Kelas$/i),N=M("dokter","dpjp"),v=s(/^Anemnesa|^Anamnesa/i),O=s(/^Pemeriksaan Fisik$/i),K=s(/^Hasil Pemeriksaan Diagnostik/i),Q=s(/^Diagnosa Utama$/i),D=s(/^Diagnosa Sekunder$/i),Y=s(/^Prosedur \/ Operasi|^Diagnosa Tindakan/i),P=s(/^Pengobatan$/i),x=s(/^Obat Pulang$/i),E=s(/^Kondisi Pulang$/i),S=s(/^Catatan Kondisi Pulang$/i),R=s(/^Jadwal Kontrol$/i),A=s(/^Pemeriksaan Lanjutan/i),c=[["TD",l(/^TD$/)],["HR",l(/^HR$/)],["RR",l(/^RR$/)],["S",l(/^S$/)],["SpO2",l(/^SPO2$/)],["GCS",l(/^GCS$/)]].filter(([,g])=>g!=="-").map(([g,w])=>`${g}: ${w}`).join(" | "),U=(g,w)=>`<tr><td style="width: 175px;"><strong>${g}</strong></td><td>${G(w)}</td></tr>`;return`<section class="rm-page" id="rm-06">
${H("RM. 06")}
<div class="rm-form-title">RINGKASAN PULANG (DISCHARGE SUMMARY)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",o,!0)}
    ${u("No. Rekam Medis",y,!0)}
    ${u("Tgl. Lahir / Kelamin",`${C} / ${m}`)}
    ${u("Jenis Kasus",s(/^Jenis Kasus$/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Masuk",$)}
    ${u("Tanggal Keluar",h)}
    ${u("Ruang / Kelas",`${p} / ${z}`)}
    ${u("DPJP / Rawat Bersama",N)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    ${U("ALASAN / INDIKASI RAWAT &amp; ANAMNESA",`${s(/^Alasan \/ Indikasi Rawat/i)}
${v}`.trim())}
    ${U("PEMERIKSAAN FISIK &amp; TANDA VITAL MASUK",`${O}${c?`
Vital Signs : ${c}`:""}`.trim())}
    ${U("HASIL PEMERIKSAAN DIAGNOSTIK",K)}
    ${U("DIAGNOSA UTAMA",Q)}
    ${U("DIAGNOSA SEKUNDER",D)}
    ${U("TINDAKAN / PROSEDUR (ICD-9-CM)",Y)}
    ${U("PENGOBATAN SELAMA RAWAT",P)}
    ${U("OBAT PULANG",x)}
    ${U("KONDISI &amp; CARA PULANG",`${E}
${S}`.trim())}
    ${U("INSTRUKSI &amp; JADWAL KONTROL",`${R}
${A}`.trim())}
    ${U("STATUS RUJUKAN &amp; PELAYANAN KB",s(/^Apakah pasien rujukan masuk/i))}
  </tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Mengetahui Pasien / Keluarga</div>
    ${e?`<img class="rm-sig-qr" src="${t(e)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${e?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(o)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Yang Membuat</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan DPJP" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(N)} )</div>
  </div>
</div>
</section>`}function la(i){let L=i.find(k=>/^Telaah/i.test(k.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=new Map,n=[],r=[],s=[];if(a){for(let T of Array.from(a.querySelectorAll("tr"))){let j=Array.from(T.cells).map(b=>(b.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let b=0;b<j.length-2;b++){let B=j[b].replace(/:$/,"").trim();j[b+1]===":"&&B&&j[b+2]&&!e.has(B)&&e.set(B,j[b+2])}for(let b of j){let B=b.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);B&&!e.has(B[1].trim())&&e.set(B[1].trim(),B[2].trim())}}for(let T of Array.from(a.querySelectorAll("tr"))){let j=Array.from(T.cells).map(B=>(B.textContent||"").replace(/\s+/g," ").trim());if(j.length<2||!/^R\/\d+$/i.test(j[0]))continue;let b=j[1].match(/^(.*?)\s*Jml:\s*(\S+)/i);n.push({no:j[0],name:b?b[1].trim():j[1],jml:b?b[2]:"-"})}for(let T of Array.from(a.querySelectorAll("table"))){let j=(T.rows[0]?.textContent||"").replace(/\s+/g," ").trim();if(!/^(Telaah Resep|Telaah Obat|Edukasi)/i.test(j))continue;let b=[];for(let B of Array.from(T.rows).slice(1)){let W=Array.from(B.cells).map(X=>(X.textContent||"").replace(/\s+/g," ").trim());W.length<2||!/^\d+$/.test(W[0])||b.push([W[0],W[1]])}b.length&&r.push({title:j.split(/\s{2,}/)[0]||j,rows:b})}let k=Array.from(a.querySelectorAll("table")).find(T=>/Hitung/i.test(T.rows[0]?.textContent||""));k&&s.push(...Array.from(k.rows[0].cells).map(T=>(T.textContent||"").replace(/\s+/g," ").trim()).filter(T=>/Hitung|Timbang|Kemas|Penyerahan/i.test(T)))}s.length||s.push("Hitung","Timbang","Kemas","Penyerahan");let l=(...k)=>{for(let[T,j]of e)if(k.some(b=>b.test(T)))return j;return"-"},o=k=>{for(let T of Array.from(document.querySelectorAll("td"))){let j=(T.textContent||"").replace(/\s+/g," ").trim(),b=j.match(k);if(!b)continue;let B=j.slice((b.index??0)+b[0].length).replace(/^\s*:\s*/,"").trim();if(B)return B;let W=(T.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim();if(W&&!/^:/.test(W))return W}return"-"},y=M("dokter","dpjp")!=="-"?M("dokter","dpjp"):l(/^Dokter/i),C=l(/^No Resep/i),m=o(/^Ruangan\/Poli/i)!=="-"?o(/^Ruangan\/Poli/i):l(/^Ruangan\/?Poli/i,/^Ruangan/i),$=o(/^Tanggal Periksa/i)!=="-"?o(/^Tanggal Periksa/i):l(/^Tanggal/i,/^Tanggal & Jam/i),h=o(/^Jam Datang/i)!=="-"?o(/^Jam Datang/i):l(/^Jam/i),p=l(/^SIP/i),z=M("nama")!=="-"?M("nama"):l(/^Nama Pasien/i),N=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):l(/^No\.? RM/i),v=jt(i),O=M("tgl_lahir","tglLahir").replace(/^:\s*/,"")||l(/^Tgl\.? Lahir/i),K=M("no_hp","telepon").replace(/^:\s*/,"")||l(/^No HP/i),Q=l(/^Penjamin/i),D=l(/alergi/i),Y=l(/berat|\bbb\b/i),P=M("jenis_kelamin","jk").replace(/^:\s*/,""),x=/perempuan|^p$/i.test(P)?"P":/laki|^l$/i.test(P)?"L":P,E=z+(x&&x!=="-"?` (${x})`:""),S=`${D!=="-"?D:"-"} / ${Y!=="-"?`BB ${Y}${/\bkg\b/i.test(Y)?"":" kg"}`:"- kg"}`,R=M("no_sep","sep")!=="-"?M("no_sep","sep"):M("kartu"),A='<table class="rm-grid-table"><thead><tr>'+s.map(k=>`<th class="center">${t(k)}</th>`).join("")+"</tr></thead><tbody><tr>"+s.map(()=>'<td style="height:30px">&nbsp;</td>').join("")+"</tr></tbody></table>",c=r.length?r.map(k=>`<table class="rm-grid-table"><thead><tr><th colspan="2">${t(k.title)}</th><th style="width:44px;">Y/T</th></tr></thead><tbody>`+k.rows.map(([T,j])=>`<tr><td class="center" style="width:28px;">${t(T)}</td><td>${t(j)}</td><td class="center">&nbsp;</td></tr>`).join("")+"</tbody></table>").join(""):"",U='<table class="rm-grid-table"><tbody><tr><th colspan="2">PERUBAHAN RESEP</th></tr><tr><th>Tertulis</th><th>Menjadi</th></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><td class="center">Apoteker</td><td class="center">Disetujui Dokter</td></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><th colspan="2">WAKTU TUNGGU</th></tr><tr><td>Masuk</td><td>&nbsp;</td></tr><tr><td>Diserahkan</td><td>&nbsp;</td></tr><tr><td>Paraf Pasien/Keluarga</td><td style="height:30px">&nbsp;</td></tr></tbody></table>',g=(k,T,j=!1)=>`<div class="tm-row${j?" long":""}"><span class="tm-label">${t(k)}:</span><span class="tm-val">${T&&T.trim()&&T!=="-"?t(T):"-"}</span></div>`,w=n.length?n.map(k=>`<div class="med"><span class="med-no">${t(k.no)}</span> <span class="med-name">${t(k.name)}</span>`+(k.jml&&k.jml!=="-"?`, <span class="med-jml">Jml: ${t(k.jml)}</span>`:"")+"</div>").join(""):'<div class="med">Tidak ada data obat pada halaman telaah.</div>';return`<section class="rm-page" id="rm-07">
${H("RM. 07")}
<div class="rm-form-title">FORMULIR TELAAH RESEP, TELAAH OBAT &amp; EDUKASI FARMASI</div>

<div class="t-main">
  <div class="t-left">
    <div class="tm-card tm-card--small tm-card--left"><div class="tm-col">
      ${g("Pasien",E)}
      ${g("No. RM",N)}
      ${g("Tgl. Lahir",O)}
      ${g("Alergi &amp; BB",S)}
      ${g("Alamat",v,!0)}
      ${g("No HP",K)}
    </div></div>
    <div class="t-meds">${w}</div>
    ${A}
    <table class="rm-grid-table t-lampiran"><thead><tr>
      <th>Srt. Rujuk Balik</th><th>Surat Iter</th><th>Hasil Lab</th>
    </tr></thead><tbody><tr>
      <td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td>
    </tr></tbody></table>
  </div>
  <div class="t-right">
    <div class="tm-card tm-card--right"><div class="tm-col">
      ${g("Dokter",y)}
      ${g("SIP Dokter",p)}
      ${g("No Resep",C)}
      ${g("No SEP",R)}
      ${g("Ruangan",m)}
      ${g("Tanggal",$)}
      ${g("Jam",h)}
      ${g("Penjamin",Q)}
    </div></div>
    ${c}
    ${U}
  </div>
</div>

<div class="footnote-rm">Obat tidak boleh diganti tanpa sepengetahuan Dokter.</div>
</section>`}var ja=/^(No\.?\s*(RONTGEN|RM)|Umur|Tanggal Periksa|Bed|Status|Nama Pasien|Jenis Kelamin|Alamat|dr\.?\s*(Pengirim|DPJP)|Dokter (Pengirim|DPJP)|Diagnosa (Klinis|ICD))/i,oa=/<div[^>]*class="[^"]*head-cetak-instansi[^"]*"[^>]*>\s*HASIL PEMERIKSAAN RADIOLOGI/i;function da(i,L,a="rm-08"){let e=L??i.find(n=>/^Radiologi/i.test(n.title));return ma(e?.html??"",oa).map((n,r)=>{let s=V([{title:"Radiologi",html:n}],/Radiologi/i)[0]??"";return Sa(i,n,s,r?`${a}-${r+1}`:a)}).join("")}function Sa(i,L,a,e){let n=new DOMParser().parseFromString(L,"text/html"),r=wa(n,ja),s=[],l="";for(let A of Array.from(n.querySelectorAll("tr"))){let c=Array.from(A.cells).map(Nt);for(let U of c){let g=U.match(/^expertise\s*:\s*([\s\S]+)$/i);g&&!l&&(l=g[1].trim())}c.length>=4&&/^\d+$/.test(c[0])&&c[1]&&s.push({name:c[1],golongan:c[2],kontras:c[3]})}let o=(...A)=>{for(let[c,U]of r)if(A.some(g=>g.test(c)))return U;return"-"},y=o(/^No\.? RONTGEN/i),C=o(/^Tanggal Periksa/i),m=o(/^Umur/i),$=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):o(/^No\.? RM/i),h=M("nama")!=="-"?M("nama"):o(/^Nama Pasien/i),p=M("jenis_kelamin","jk").replace(/^:\s*/,"")||o(/^Jenis Kelamin/i),z=/perempuan|^p$/i.test(p)?"P":/laki|^l$/i.test(p)?"L":p,N=jt(i),v=o(/^Bed|^Ruang/i),O=o(/^Status/i),K=o(/^dr\.? Pengirim|^Dokter Pengirim/i),Q=o(/^dr\.? DPJP|^Dokter DPJP/i),D=(n.body.textContent||"").replace(/\s+/g," ").match(/\(\s*([^)]{3,80})\s*\)/)?.[1]?.trim()||"-",Y=Q!=="-"?Q:D!=="-"?D:ct(a),P=o(/^Diagnosa Klinis/i),x=o(/^Diagnosa ICD/i),E=s.length&&s[0].golongan||"-",S=s.length?s.map((A,c)=>`<tr><td class="center">${c+1}</td><td><strong>${t(A.name)}</strong></td><td class="center">${t(A.golongan||"-")}</td><td class="center">${t(A.kontras||"-")}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Radiologi ${c+1}"></td></tr>`).join(""):'<tr><td class="center">-</td><td>Tidak ada jenis pemeriksaan tercatat.</td><td class="center">-</td><td class="center">-</td><td class="center">-</td></tr>',R=l?l.replace(/^\s*\d+\.\s*/,"").replace(/^\n+|\n+$/g,"").split(`
`).map(A=>A.trim()).map(A=>A?`<div>${t(A)}</div>`:"<div>&nbsp;</div>").join(""):"<div>Tidak ada expertise tercatat pada halaman.</div>";return`<section class="rm-page" id="${t(e)}">
${H("RM. 08")}
<div class="rm-form-title">HASIL PEMERIKSAAN RADIOLOGI</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("No. Rontgen",y,!0)}
    ${u("Tanggal Periksa",C)}
    ${u("No. Rekam Medis",$)}
    ${u("Nama Pasien",h,!0)}
    ${u("Jenis Kelamin",z!=="-"?`Laki-laki / Perempuan (${z})`:"-")}
    ${u("Alamat",N)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Umur / Tgl. Lahir",m)}
    ${u("Ruang / Asal",v!=="-"&&O!=="-"?`${v} (Status: ${O})`:v)}
    ${u("Dokter Pengirim",K)}
    ${u("Dokter DPJP / Penilai",Y)}
    ${u("Diagnosa Klinis",P)}
    ${u("Diagnosa ICD",x)}
    ${u("Status Pasien",O)}
    ${u("Golongan / Jenis",`${E} \u2014 ${s[0]?.kontras||"-"}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>JENIS PEMERIKSAAN</th>
    <th style="width: 110px;">GOLONGAN</th>
    <th style="width: 110px;">KONTRAS</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${S}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr><th>URAIAN EXPERTISE &amp; KESAN PEMERIKSAAN</th></tr></thead>
  <tbody><tr><td style="padding: 8px 10px; line-height: 1.5;">${R}</td></tr></tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>No. Rontgen : ${t(y)}</div>
    <div>Jenis Pemeriksaan : ${t(E)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penilai</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan radiolog" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(Y)} )</div>
  </div>
</div>
</section>`}var Aa=i=>{for(let L of i){if(!/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(L.title))continue;let a=new DOMParser().parseFromString(L.html,"text/html");for(let e of Array.from(a.querySelectorAll("table"))){let n=Array.from(e.rows[0]?.cells||[]).map(r=>Nt(r)).join(" ");if(/^Triase/i.test(n))return Array.from(e.rows).slice(1).map(r=>Array.from(r.cells).map(Nt))}}return[]};function ca(i){let L=i.find(S=>/^Triage/i.test(S.title)),a=V(i,/^Triage/i)[0]??"",e=L?new DOMParser().parseFromString(L.html,"text/html"):null,n=new Map,r="-";if(e){for(let R of Array.from(e.querySelectorAll("tr"))){let A=Array.from(R.cells).map(c=>(c.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let c=0;c<A.length-2;c++){let U=A[c].replace(/:$/,"").trim();A[c+1]===":"&&U&&A[c+2]&&!n.has(U)&&n.set(U,A[c+2])}for(let c of A){let U=c.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);!U||U[2].includes(":")||U[2].length>120||n.has(U[1].trim())||n.set(U[1].trim(),U[2].trim())}}let S=(e.textContent||"").replace(/\s+/g," ").match(/Dokter yang memeriksa\s*\(([^)]+)\)/i);S&&(r=S[1].trim())}let s=(...S)=>{for(let[R,A]of n)if(S.some(c=>c.test(R)))return A;return"-"},l=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):s(/^No\.?\s*RM/i),o=M("nama")!=="-"?M("nama"):s(/^Nama$/i),y=s(/^Tanggal$/i),C=s(/^Jam Datang/i),m=s(/^Jam Registrasi/i),$=s(/^Cara Datang/i),h=s(/^Diantar Polisi/i),p=s(/^No\.?\s*ID/i),z=s(/^Pengantar Pasien/i),N=s(/^Riwayat Penyakit Dahulu/i),v=s(/^Keluhan Utama/i),O=s(/^Keadaan Umum/i),K=s(/^Suhu/i),Q=s(/^Nadi/i),D=s(/^RR$/i),Y=s(/^Tekanan Darah/i),P=s(/^Jam$/i),x=s(/^No\.?\s*Antrian/i),E=s(/^Status/i);return`<section class="rm-page" id="triage">
${H("TRIAGE")}
<div class="rm-form-title">TRIAGE TERINTEGRASI &amp; PENGKAJIAN AWAL IGD</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("No. Rekam Medis",l,!0)}
    ${u("Nama Pasien",o,!0)}
    ${u("Tanggal",y)}
    ${u("Jam Datang",C)}
    ${u("Jam Registrasi",m)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Cara Datang",$)}
    ${u("Diantar Polisi",h)}
    ${u("No. ID",p)}
    ${u("Pengantar Pasien",z)}
    ${u("Status Triage",E,!0)}
  </table></div>
</div>

<div class="sub-heading-rm">ANAMNESA &amp; RIWAYAT</div>
<table class="rm-grid-table"><tbody>
  ${u("Riwayat Penyakit Dahulu",N)}
  ${u("Keluhan Utama",v)}
</tbody></table>

<div class="sub-heading-rm">TANDA VITAL &amp; PEMERIKSAAN</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${u("Keadaan Umum",O)}
    ${u("Suhu (\xB0C)",K)}
    ${u("Nadi (x/menit)",Q)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("RR (x/menit)",D)}
    ${u("Tekanan Darah (mmHg)",Y)}
    ${u("Jam",P)}
    ${u("No. Antrian",x)}
  </table></div>
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Status Triage : ${t(E)}</div>
    <div>No. Antrian : ${t(x)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(r!=="-"?r:ct(a))} )</div>
  </div>
</div>
</section>`}function ga(i){let L=i.find(d=>/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(d.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=a?Array.from(a.querySelectorAll("table")):[],n=d=>(d.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim(),r=d=>d?Array.from(d.rows).map(f=>Array.from(f.cells).map(n)):[],s=d=>{let f=e.find(F=>d.test((F.rows[0]?.textContent||"").replace(/\s+/g," ").trim()));return r(f)},l=d=>{let f=e.find(F=>d.test(F.textContent||""));return r(f)},o=e.find(d=>/^Usia$/i.test((d.rows[1]?.cells[1]?.textContent||"").trim())),y=e.find(d=>/^Riwayat Jatuh$/i.test((d.rows[1]?.cells[1]?.textContent||"").trim())),C=d=>d.reduce((f,F)=>{let Z=w(F),q=Z==="-"?0:Number(Z);return f+(Number.isFinite(q)?q:0)},0),m=(d,f)=>f?d>=45?"TINGGI":d>=25?"SEDANG":"RENDAH":d>=12?"TINGGI":d>=6?"SEDANG":"RENDAH",$=(d,f)=>{let F=C(d);return`${F} \u2014 ${m(F,f)}`},h=d=>d?Array.from(d.rows).map((f,F)=>{let Z=Array.from(f.cells).map(q=>{let nt=Nt(q),J=q.rowSpan>1?` rowspan="${q.rowSpan}"`:"",lt=q.colSpan>1?` colspan="${q.colSpan}"`:"",I=/JUMLAH SKOR|Keterangan Hasil|Catatan/i.test(nt),_=nt.includes("\u2713"),tt=F===0?"th":"td";return`<${tt}${J}${lt}${I?' style="font-weight:bold;text-align:right;"':""}>${_?`<strong>${t(nt)}</strong>`:t(nt||"-")}</${tt}>`}).join("");return`<tr${F===0?' class="sec-hdr"':""}>${Z}</tr>`}).join(""):'<tr><td colspan="5">-</td></tr>',p=s(/^Triase/i),z=s(/^Pengkajian\s*0\s*1\s*2\s*Nilai/i),N=l(/MORSE FALL SCALE/i),v=s(/^Objektif\s*Kelainan/i),O=s(/^Diagnosa Utama$/i),K=s(/^Diagnosa Banding$/i),Q=s(/^Tindakan$/i),D=s(/^Pukul\s*Nama Obat/i),Y=s(/^No\s*Nama Perawat IGD/i),P=(d,f)=>{let F=Array.isArray(f)?f.join(""):f;return'<table class="rm-grid-table"><thead><tr>'+d.map(Z=>`<th>${t(Z)}</th>`).join("")+"</tr></thead><tbody>"+(F||'<tr><td colspan="'+d.length+'">-</td></tr>')+"</tbody></table>"},x=z.slice(1).map(d=>{if(d.some(f=>/^TOTAL$/i.test((f||"").trim()))){let f=d[d.length-1]||"-";return`<tr style="font-weight:bold;"><td colspan="4" style="text-align:right;"><strong>TOTAL</strong></td><td class="center"><strong>${t(f)}</strong></td></tr>`}return"<tr>"+d.map((f,F)=>`<td${F===0?"":' class="center"'}>${t(f||"-")}</td>`).join("")+"</tr>"}).join(""),E=v.slice(1).map(d=>`<tr><td>${t(d[0]||"-")}</td><td>${t(d.slice(1).filter(Boolean).join(" ")||"-")}</td></tr>`).join(""),S=[["DIAGNOSA UTAMA",O.slice(1).flat().filter(Boolean).join(" ")||"-"],["DIAGNOSA BANDING",K.slice(1).flat().filter(Boolean).join(" ")||"-"]].map(([d,f])=>`<tr><td style="width:180px;"><strong>${d}</strong></td><td>${t(f)}</td></tr>`).join(""),R=Q.slice(1).flat().filter(Boolean).join(" ")||"-",A=D.slice(1).filter(d=>d.some(Boolean)).map(d=>"<tr>"+d.slice(0,4).map(f=>`<td>${t(f||"-")}</td>`).join("")+"</tr>").join(""),c=Y.slice(1).flat().filter(Boolean).join(" \xB7 "),U=Aa(i).find(d=>(d[0]||"").includes("\u2713"))?.slice(1)||[],g=d=>{let f=d.find(q=>/^JUMLAH SKOR/i.test(q[0]||"")),F=d.find(q=>/^Keterangan Hasil/i.test(q[0]||"")),Z=f?.slice(1).filter(Boolean).join(" ")||"-";return F?`${Z} \xB7 ${F.slice(1).filter(Boolean).join(" ")}`:Z},w=d=>document.querySelector(`input[name="${d}"]:checked`)?.value||"-",k=d=>(Array.from(a?.querySelectorAll("label")||[]).find(f=>d.test((f.textContent||"").replace(/\s+/g," ").trim()))?.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim()||"-",T=(Array.from(a?.querySelectorAll("div")||[]).find(d=>/^Planning\s*:\s*Terapy/i.test((d.textContent||"").trim().slice(0,80)))?.nextElementSibling?.textContent||"").split(/TINDAK LANJUT/i)[0].split(/Kondisi Pasien Saat Pindah/i)[0].replace(/[ \t]+/g," ").trim()||"-",j=M("pengkajian_keperawatan"),[b,B,W]=(()=>{let d=j.split(/\n\s*RPD\s*:/i),f=d[0].replace(/^\s*Subjektif\s*:\s*/i,"").trim()||"-",F=(d[1]||"").split(/\n\s*RPO\s*:/i);return[f,F[0]?.trim()||"-",F[1]?.trim()||"-"]})(),X=(d,f)=>w(d)==="ya"?M(f):w(d)==="tidak"?"Tidak":"-",Mt=d=>{let f=Array.from(document.querySelectorAll(`input[name="${d}"]:checked`)).map(F=>F.value).filter(Boolean);return f.length?f.join(", "):"-"},at=d=>({tanpa_bantuan:"Jalan Tanpa Bantuan",kursi_roda:"Kursi Roda",tempat_tidur:"Brankar",dengan_bantuan:"Dengan Bantuan",tidak_ada:"Tidak mengalami cedera",lantas:"KLL",lainnya:"Lainnya",tidak:"Tidak Terganggu",ya:"Ada Gangguan",Bpjs:"BPJS Kesehatan"})[d]||d||"-",rt=(d,f)=>`<tr><td style="width:175px;"><strong>${d}</strong></td><td>${f}</td></tr>`,It=(d,f)=>`<tr><td class="lbl">${d}</td><td class="col">:</td><td class="val">${f}</td></tr>`,pt=Number(M("nutrisi_bb")),ut=Number(M("nutrisi_tb"))/100,Tt=pt>0&&ut>0?(pt/(ut*ut)).toFixed(1).replace(".",","):"-";return`<section class="rm-page" id="pengkajian-igd">
${H("PENGKAJIAN IGD")}
<div class="rm-form-title">LEMBAR PENGKAJIAN INSTALASI GAWAT DARURAT</div>

<div class="igd-masthead">
  <div class="igd-masthead-label">Pasien \xB7 Instalasi Gawat Darurat</div>
  <div class="igd-masthead-name">${t(M("nama"))}</div>
</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${u("Tgl. Lahir / Umur",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?"Perempuan (P)":"Laki-laki (L)")}
    ${u("Agama / Suku",`${k(/^Agama/i)} / ${k(/^Suku/i)}`)}
    ${u("Pekerjaan",M("pekerjaan"))}
    ${u("No. Telp / HP",M("no_hp","telepon"))}
    ${u("Nama Orangtua / Pasangan",`${M("nama_orangtua")} / ${M("nama_pasangan")}`)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Masuk",M("tgl_masuk"))}
    ${u("Tiba di IGD / Diperiksa",`Pukul ${M("pukul_tiba_di_rs")} / Diperiksa Pukul ${M("pukul_diperiksa")}`)}
    ${u("Prosedur Masuk",at(w("kaji[prosedur_masuk]")))}
    ${u("Cara Masuk",at(w("kaji[cara_masuk]")))}
    ${u("Penyebab Cedera",at(w("kaji[penyebab_cedera]")))}
    ${u("Status Alergi",X("kaji[status_alergi]","status_alergi_text"))}
    ${u("Gangguan Perilaku",at(w("kaji[gangguan_perilaku]")))}
    ${It("Status Kehamilan",/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?t(M("status_kehamilan")):'<span class="filter-note">Tidak berlaku (Pasien Laki-laki \u2014 disaring otomatis)</span>')}
  </table></div>
</div>

<div class="igd-summary">
  <div><span>Triase</span><b>${t(U[0]||"-")} ${t(U[1]||"")}</b></div>
  <div><span>GCS / Kesadaran</span><b>${t(M("vital_gcs"))} \xB7 ${t(M("vital_kesadaran"))}</b></div>
  <div><span>SpO2 / Nadi</span><b>${t(M("vital_spo"))} \xB7 ${t(M("vital_nadi"))}</b></div>
  <div><span>Risiko Jatuh (Morse)</span><b>${t(g(N))}</b></div>
</div>

<div class="sub-heading-rm">KONDISI AWAL &amp; RIWAYAT</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${u("Prosedur Masuk",w("kaji[prosedur_masuk]"))}
    ${u("Cara Masuk",w("kaji[cara_masuk]"))}
    ${u("Status Alergi",X("kaji[status_alergi]","status_alergi_text"))}
    ${u("Status Psikologi",w("kaji[status_psikologi]"))}
    ${u("Status Sosial",w("kaji[status_sosial]"))}
    ${u("Status Ekonomi",w("kaji[status_ekonomi]"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Nutrisi (BB/TB)",`${M("nutrisi_bb")} kg / ${M("nutrisi_tb")} cm`)}
    ${u("Kognitif",w("kaji[fungsi_kognitif]"))}
    ${u("Motorik",w("kaji[fungsi_motorik]"))}
    ${u("Hambatan Pembelajaran",X("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text"))}
    ${u("Kebutuhan Edukasi",w("kaji[kebutuhan_edukasi]"))}
    ${u("Penerjemah",X("kaji[dibutuhkan_penerjemah]","penerjemah_text"))}
  </table></div>
</div>

<div class="sub-heading-rm">TANDA VITAL SAAT MASUK</div>
${P(["TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","GCS (E/V/M)","KESADARAN"],["<tr>"+[xt(M("vital_td")),M("vital_nadi"),M("vital_nafas"),M("vital_suhu"),M("vital_spo"),M("vital_gcs")].map(d=>`<td class="center">${t(d)}</td>`).join("")+`<td class="center">${t([M("vital_e"),M("vital_m"),M("vital_v")].join("/"))}</td><td class="center">${t(M("vital_kesadaran"))}</td></tr>`])}

<div class="sub-heading-rm">KONDISI SAAT PINDAH / PULANG DARI IGD</div>
${P(["PUKUL","TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","KESADARAN"],["<tr>"+[M("waktu_pasien_pulang"),xt(M("kondisi_pasien_td")),M("kondisi_pasien_nadi"),M("kondisi_pasien_nafas"),M("kondisi_pasien_suhu"),M("kondisi_pasien_spo"),M("kondisi_pasien_gcs"),M("kondisi_pasien_kesadaran")].map(d=>`<td class="center">${t(d)}</td>`).join("")+"</tr>"])}

<div class="sub-heading-rm">TRIASE (DIISI OLEH DOKTER)</div>
<table class="rm-table">
  <thead>
    <tr><th style="width:34px;">PILIH</th><th style="width:95px;">SKALA TRIASE</th><th>KATEGORI &amp; KETERANGAN KLINIS</th><th style="width:105px;">RESPON TIME</th></tr>
  </thead>
  <tbody>${p.slice(1).map(d=>{let f=(d[0]||"").includes("\u2713"),F=d.length>=4?d.slice(1,4):d.slice(0,3);return`<tr${f?' style="font-weight:bold;"':""}><td class="center"><span class="chk-box">${f?"&#10003;":"&nbsp;"}</span></td>${F.map(Z=>`<td>${t(Z||"-")}</td>`).join("")}</tr>`}).join("")}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">II. PENGKAJIAN PSIKOSOSIAL, SPIRITUAL, EKONOMI, NUTRISI &amp; FUNGSIONAL</td></tr></thead>
  <tbody>
    ${rt("Status Psikologi",w("kaji[status_psikologi]")||"-")}
    ${rt("Status Sosial &amp; Spiritual",`Hubungan keluarga: ${w("kaji[status_sosial]")||"-"} | Kegiatan keagamaan: ${t(M("status_spiritual"))}`)}
    ${rt("Status Pembiayaan",at(w("kaji[status_ekonomi]")))}
    ${rt("Antropometri &amp; Nutrisi",`BB: <strong>${t(M("nutrisi_bb"))} Kg</strong> | TB: <strong>${t(M("nutrisi_tb"))} Cm</strong> | IMT: <strong>${Tt} kg/m&sup2;</strong> | Konsul Gizi: ${w("kaji[nutrisi_konsul]")||"-"}`)}
    ${rt("Status Fungsional",`Kognitif: ${w("kaji[fungsi_kognitif]")||"-"} | Motorik: ${w("kaji[fungsi_motorik]")||"-"}`)}
    ${rt("Komunikasi &amp; Edukasi",`Hambatan: ${X("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text")} | Penerjemah: ${X("kaji[dibutuhkan_penerjemah]","penerjemah_text")} | Kebutuhan Edukasi: ${Mt("kaji[kebutuhan_edukasi]")}`)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">III. ASESMEN NYERI \u2014 WONG BAKER / NRS (PQRST)</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;"><strong>Skala Wong Baker</strong></td>
      <td><span class="filter-note">Skala nyeri Wong Baker (0\u20135) \u2014 lihat halaman asal; di dossier ini tidak ditampilkan sebagai gambar.</span></td>
    </tr>
    <tr><td><strong>(P) Faktor Pencetus</strong></td><td>${t(M("faktor_pencetus"))}</td></tr>
    <tr><td><strong>(Q) Kualitas Nyeri</strong></td><td>${w("kaji[qualitas]")||"-"}</td></tr>
    <tr><td><strong>(R) Lokasi &amp; Penjalaran</strong></td><td>${t(M("lokasi_nyeri"))} &nbsp;|&nbsp; <strong>Menjalar:</strong> ${w("kaji[nyeri_menjalar]")||"-"}</td></tr>
    <tr><td><strong>(S) Skala Nyeri (NRS 0\u201310)</strong></td><td>${t(M("skala_nyeri"))} &nbsp;|&nbsp; Wong Baker: ${t(M("emo_wong"))}</td></tr>
    <tr><td><strong>(T) Waktu &amp; Frekuensi</strong></td><td>${t(M("lamanya_nyeri"))} &nbsp;|&nbsp; ${w("kaji[nyeri_frekwensi]")||"-"}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="5">IV. PENGKAJIAN NYERI (FLACC)</td></tr>
    <tr><th>PENGKAJIAN</th><th>0</th><th>1</th><th>2</th><th>NILAI</th></tr>
  </thead>
  <tbody>${x||'<tr><td colspan="5">-</td></tr>'}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">V. ASESMEN AWAL RESIKO JATUH PADA ANAK (HUMPTY DUMPTY)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${$(["kaji[arja_usia]","kaji[arja_jenis_kelamin]","kaji[arja_diagnosis]","kaji[arja_gangguan_kognitif]","kaji[arja_faktor_lingkungan]","kaji[arja_respon_pembedahan]","kaji[arja_medikamentosa]"],!1)}</strong></td>
    </tr>
    ${h(o)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">VI. ASESMEN AWAL RESIKO JATUH PADA DEWASA (MORSE FALL SCALE)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${$(["kaji[arja_dewasa_jatuh]","kaji[arja_dewasa_diagnosa]","kaji[arja_dewasa_alat]","kaji[arja_dewasa_infus]","kaji[arja_dewasa_carajalan]","kaji[arja_dewasa_mental]"],!0)}</strong></td>
    </tr>
    ${h(y)}
  </tbody>
</table>

<div class="two-col-grid">
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0; height: 100%;">
      <thead>
        <tr class="sec-hdr"><td colspan="3">VI-A. PERBANDINGAN TANDA VITAL (OBJEKTIF)</td></tr>
        <tr><th>PARAMETER</th><th style="width: 108px;">AWAL IGD</th><th style="width: 108px;">PINDAH HCU</th></tr>
      </thead>
      <tbody>
        ${[["Tekanan Darah (TD)",M("vital_td"),M("kondisi_pasien_td")],["Nadi (HR)",M("vital_nadi"),M("kondisi_pasien_nadi")],["Pernapasan (RR)",M("vital_nafas"),M("kondisi_pasien_nafas")],["Suhu Aksila",M("vital_suhu"),M("kondisi_pasien_suhu")],["Saturasi Oksigen (SpO2)",M("vital_spo"),M("kondisi_pasien_spo")],["Kesadaran",M("vital_kesadaran"),M("kondisi_pasien_kesadaran")],["Skor GCS",M("vital_gcs"),M("kondisi_pasien_gcs")]].map(([d,f,F])=>`<tr><td><strong>${t(d)}</strong></td><td class="center">${t(f)}</td><td class="center">${t(F)}</td></tr>`).join("")}
      </tbody>
    </table>
  </div>
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0;">
      <thead>
        <tr class="sec-hdr"><td colspan="2">VI-B. PEMERIKSAAN FISIK LOKALIS &amp; PENUNJANG</td></tr>
        <tr><th>OBJEKTIF</th><th>KELAINAN</th></tr>
      </thead>
      <tbody>${E}</tbody>
    </table>
  </div>
</div>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">V. PENGKAJIAN MEDIS DOKTER IGD \u2014 ANAMNESIS (SUBJEKTIF)</td></tr></thead>
  <tbody>
    <tr><td style="width:155px;"><strong>(a) Keluhan Utama &amp; RPS</strong></td><td>${G(b)}</td></tr>
    <tr><td><strong>(b) Riwayat Penyakit Dahulu (RPD)</strong></td><td>${G(B)}</td></tr>
    <tr><td><strong>(c) Riwayat Penggunaan Obat (RPO)</strong></td><td>${G(W)}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">VI. DIAGNOSA &amp; TINDAKAN & PLANNING TERINTEGRASI</td></tr></thead>
  <tbody>
    ${S}
    <tr><td style="width:165px;"><strong>TINDAKAN</strong></td><td>${t(R)}</td></tr>
    <tr>
      <td><strong>PEMERIKSAAN PENUNJANG</strong></td>
      <td>EKG: ${t(k(/^EKG$/i))} &nbsp;|&nbsp; Radiologi: ${t(k(/^Radiologi$/i))} &nbsp;|&nbsp; Laboratorium: ${t(k(/^Laboratorium$/i))}</td>
    </tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">IX. PENGKAJIAN KEPERAWATAN &amp; MEDIS</td></tr></thead>
  <tbody><tr><td style="width:165px;"><strong>PENGKAJIAN KEPERAWATAN</strong></td><td>${G(M("pengkajian_keperawatan"))}</td></tr></tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">X. PLANNING / TERAPI TERINTEGRASI</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;vertical-align:top;"><strong>Tatalaksana Awal (A)</strong></td>
      <td>${G(T.split(/Konsul dr\./i)[0].trim()||"-")}</td>
    </tr>
    ${T.split(/(?=Konsul dr\.)/i).slice(1).map((d,f)=>{let F=d.match(/^Konsul (dr\.?[^:\n]+)/i)?.[1]?.trim()||"-",Z=d.match(/Plan\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",q=d.match(/Terapi\s*:\s*([\s\S]*?)(?=Konsul dr\.|$)/i)?.[1]?.trim()||"-",nt=d.match(/Dx\s*:\s*([\s\S]*?)(?=Masalah\s*:|Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",J=d.match(/Masalah\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-";return`<tr>
          <td style="width:165px;vertical-align:top;"><strong>Advis ( ${String.fromCharCode(66+f)} ) \u2014 ${t(F)}</strong></td>
          <td>
            ${nt!=="-"?`<strong>Dx:</strong> ${G(nt)}<br/>`:""}
            ${J!=="-"?`<strong>Masalah:</strong> ${G(J)}<br/>`:""}
            ${Z!=="-"?`<strong>Visite Plan:</strong> ${G(Z)}<br/>`:""}
            ${q!=="-"?`<strong>Terapi:</strong> ${G(q)}`:""}
          </td>
        </tr>`}).join("")}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">XI. DISPOSISI TINDAK LANJUT</td></tr></thead>
  <tbody>
    <tr><td style="width:165px;"><strong>Tindak Lanjut</strong></td><td>${w("medis[tindak_lanjut]")||"-"}</td></tr>
    <tr><td><strong>Ruangan Rawat Inap</strong></td><td>${t(M("tindak_lanjut_ruangan_ranap"))} \u2014 Indikasi: ${t(M("tindak_lanjut_indikasi_ranap"))}</td></tr>
    <tr><td><strong>Pukul Pindah / Pulang</strong></td><td>${t(M("waktu_pasien_pulang"))}</td></tr>
    <tr><td><strong>Kondisi Pasien Saat Pindah</strong></td><td>TD ${t(xt(M("kondisi_pasien_td")))} | Nadi ${t(M("kondisi_pasien_nadi"))} | RR ${t(M("kondisi_pasien_nafas"))} | Suhu ${t(M("kondisi_pasien_suhu"))} | SpO2 ${t(M("kondisi_pasien_spo"))} | GCS ${t(M("kondisi_pasien_gcs"))} | Kesadaran ${t(M("kondisi_pasien_kesadaran"))}</td></tr>
  </tbody>
</table>

<div class="sub-heading-rm">OBAT / TERAPI IGD</div>
${P(["PUKUL","NAMA OBAT","DOSIS / RUTE","TANDA TANGAN"],A)}

<div class="sub-heading-rm">PERAWAT IGD</div>
<table class="rm-grid-table"><tbody><tr><td>${t(c||"-")}</td></tr></tbody></table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Ruangan : ${t(M("tindak_lanjut_ruangan_ranap"))}</div>
    <div>Perawat Ruangan : ${t(M("perawat_ruangan"))}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter IGD</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( ${t(M("dokter_igd","dokter"))} )</div>
  </div>
</div>
</section>`}function Na(i,L){let a=[/^Telaah/i,/^SBPK/i,/^Radiologi/i],e=r=>{let s=a.findIndex(l=>l.test(r));return s<0?99:s},n=[...i].sort((r,s)=>e(r.title)-e(s.title));for(let r of n){let s=new DOMParser().parseFromString(r.html,"text/html");for(let l of Array.from(s.querySelectorAll("tr"))){let o=Array.from(l.cells).map(y=>(y.textContent||"").replace(/\s+/g," ").trim());for(let y=0;y<o.length-2;y++)if(L.test(o[y])&&o[y+1]===":"&&o[y+2])return o[y+2];for(let y of o){let C=y.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);if(C&&L.test(C[1].trim())&&C[2]&&!C[2].includes(":")&&C[2].length<=160)return C[2].trim()}}}return"-"}var jt=i=>At("alamat").replace(/^\s*:\s*/,"").trim()||Na(i,/^Alamat/i),V=(i,L)=>{let a=i.find(n=>L.test(n.title));if(!a)return[];let e=new DOMParser().parseFromString(a.html,"text/html");return Array.from(e.querySelectorAll("img")).map(n=>n.getAttribute("src")||"").filter(n=>/qr|barcode/i.test(n))},ct=i=>{if(!i)return"-";try{let L=decodeURIComponent(i.replace(/\+/g," "));return(L.match(/approve\s*([\s\S]*?)\s+tgl\b/i)?.[1]||L.match(/(dr\.[^&]+)/i)?.[1]||"").split(/\s+(?:tgl|jam)\b/i)[0].replace(/\s+/g," ").trim()||"-"}catch{return"-"}},xt=i=>/\d/.test(i)?i:"-";function it(i,L){let a=i.find(r=>L.test(r.title)),e=a?new DOMParser().parseFromString(a.html,"text/html"):null,n=new Map;if(!e)return n;for(let r of Array.from(e.querySelectorAll("tr"))){let s=Array.from(r.cells).map(l=>(l.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let l=0;l<s.length-1;l++){let o=s[l].replace(/^[-:\s]+|[\s:]+$/g,"");!o||n.has(o)||(s[l+1]===":"&&s[l+2]?n.set(o,s[l+2]):s[l+1].startsWith(":")&&s[l+1].length>1&&n.set(o,s[l+1].replace(/^:\s*/,"").trim()))}for(let l of s){let o=l.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);o&&o[2].length<=120&&!n.has(o[1].trim())&&n.set(o[1].trim(),o[2].trim())}}return n}var gt=i=>i.replace(/&gt;/gi,">").replace(/&lt;/gi,"<").replace(/&quot;/gi,'"').replace(/&#39;/g,"'").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&nbsp;/gi," ");function Nt(i){return gt((i.innerHTML||"").replace(/<!--[\s\S]*?-->/g,"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim())}function ma(i,L){let a=new RegExp(L.source,L.flags.includes("g")?L.flags:L.flags+"g"),e=Array.from(i.matchAll(a)).map(n=>n.index??0);return e.length<2?[i]:e.map((n,r)=>i.slice(n,r+1<e.length?e[r+1]:i.length))}function wa(i,L){let a=new Map;for(let e of Array.from(i.querySelectorAll("tr"))){let n=Array.from(e.cells).map(Nt);for(let r=0;r<n.length-1;r++){let s=n[r].replace(/^[-:\s]+|[\s:]+$/g,"").trim();if(!L.test(s)||a.has(s))continue;let l=n[r+1].replace(/^:\s*/,"").trim();l&&a.set(s,l)}}return a}var et=(i,...L)=>{for(let[a,e]of i)if(L.some(n=>n.test(a)))return gt(e);return"-"};function ot(i,L,a=30){let e=i.find(s=>L.test(s.title)),n=e?new DOMParser().parseFromString(e.html,"text/html"):null;if(!n)return[];let r=[];for(let s of Array.from(n.querySelectorAll("tr"))){let l=Array.from(s.cells).map(o=>(o.textContent||"").replace(/\s+/g," ").trim());if(l.length&&l.some(Boolean)&&r.push(l),r.length>=a)break}return r}var st=i=>'<table class="rm-grid-table"><tbody>'+i.map(([L,a])=>`<tr><td style="width:175px;"><strong>${L}</strong></td><td>${G(a)}</td></tr>`).join("")+"</tbody></table>",dt=(i,L,a=!1)=>{let e=a?[...i,"VER (&#10003;)"]:i;return'<table class="rm-grid-table"><thead><tr>'+e.map(n=>`<th>${n}</th>`).join("")+"</tr></thead><tbody>"+(L.length?L.map(n=>"<tr>"+e.map((r,s)=>a&&s===e.length-1?'<td class="center"><input type="checkbox" class="rm-checkbox"></td>':`<td>${G(n[s]||"-")}</td>`).join("")+"</tr>").join(""):`<tr><td colspan="${e.length}">-</td></tr>`)+"</tbody></table>"},Lt=(i,L)=>'<div class="rm-signature-block">'+[i,L].map((a,e)=>`<div class="rm-sig-box${e?"":" left-align"}">`+a.slice(0,-1).map(n=>`<div>${n}</div>`).join("")+`<div class="rm-sig-space"></div><div class="rm-sig-name">${a[a.length-1]}</div></div>`).join("")+"</div>";function pa(i){let L=i.find(j=>/^Persetujuan Tindakan/i.test(j.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=a?Array.from(a.querySelectorAll("table")):[],n=j=>gt((j.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()),r=j=>j?Array.from(j.rows).map(b=>Array.from(b.cells).map(n)):[],s=j=>j?.querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",l=j=>j.replace(/-->\s*/g,"").replace(/\btsb\b/gi,"tersebut").replace(/pembiuasan/gi,"pembiusan").replace(/\bizi Tuhan\b/gi,"izin Tuhan").replace(/\bresiko\b/gi,"risiko").replace(/\bAm\.?kep\b/gi,"A.Md.Kep").replace(/\s+/g," ").trim(),o=e.find(j=>/PEMBERIAN INFORMASI/i.test(j.rows[0]?.textContent||"")),y=e.find(j=>/JENIS INFORMASI/i.test(j.rows[0]?.textContent||"")),C=e.find(j=>/Dengan ini menyatakan bahwa saya dokter/i.test(j.rows[0]?.textContent||"")),m=e.find(j=>/PERSETUJUAN TINDAKAN KEDOKTERAN/i.test(j.rows[0]?.textContent||"")),$=r(o).slice(1).map(j=>[j[0]||"-",l((j[1]||j[2]||"-").replace(/^:\s*/,""))]).filter((j,b,B)=>B.findIndex(W=>W[0]===j[0])===b),h=r(y).slice(1).map((j,b)=>({no:/^\d+$/.test(j[0]||"")?j[0]:String(b+1),label:l(j[1]||"-"),isi:l(j[2]||"-"),centang:(j[3]||"").includes("\u2713")})),p=(C?Array.from(C.rows):[]).map(j=>({teks:l(n(j.cells[0])),ttd:l(j.cells[1]?n(j.cells[1]):""),qr:s(j.cells[1])})).filter((j,b,B)=>B.findIndex(W=>W.teks===j.teks)===b),z=r(m),N=l(z[2]?.join(" ")||"-"),v=l(z[3]?.join(" ")||"-"),O=(m?Array.from(m.rows[4]?.cells||[]):[]).map((j,b)=>({teks:l(n(j)),qr:b===2?s(j):""})),K=M("nama"),Q=j=>j.replace(/Jambi\s*,?\s*\d{1,2}\/\d{1,2}\/\d{4}\s*,?\s*Jam\s*[\d:.]+/gi,"").replace(/\s+/g," ").trim(),D=j=>j.match(/\(([^)]+)\)/)?.[1]?.trim()||Q(j)||"-",Y=Q(N),P=Q(v),x=Y.match(/Nama\s*:\s*(.+?)(?=\s+Umur\s*:|$)/i)?.[1]?.trim()||"-",E=Y.match(/Umur\s*:\s*(.+?)(?=\s+Jenis Kelamin\s*:|$)/i)?.[1]?.trim()||"-",S=Y.match(/Jenis Kelamin\s*:\s*(.+?)(?=\s+Alamat\s*:|$)/i)?.[1]?.trim()||"-",R=Y.match(/Alamat\s*:\s*(.+)$/i)?.[1]?.trim()||"-",A=h.find(j=>j.no==="3")?.isi||"-",c=j=>P.match(j)?.[0]?.trim()||"",U=[c(/Saya memahami perlunya dan manfaat tindakan tersebut[\s\S]*?(?=Saya juga menyadari|$)/i),c(/Saya juga menyadari[\s\S]*?(?=Saya memahami perlunya tindakan pembiusan|Saya bertanggung jawab|$)/i),c(/Saya memahami perlunya tindakan pembiusan[\s\S]*?(?=Saya bertanggung jawab|$)/i),c(/Saya bertanggung jawab[\s\S]*$/i)].filter(Boolean),g=(j,b)=>{let B=Q(O[j]?.teks||"").replace(b,"");return D(B)},w=g(0,/Yang Menyatakan/i),k=g(1,/Saksi Keluarga/i),T=g(2,/Saksi Rumah Sakit/i);return`<section class="rm-page" id="form-konsent">
${H("RM. 19A")}
<div class="rm-form-title">PERSETUJUAN TINDAKAN KEDOKTERAN (RM 19 A)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",K,!0)}
    ${u("Umur",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
    ${u("Alamat",jt(i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${$.map(([j,b])=>u(j,b,j==="Penerima Informasi / Pemberi Persetujuan")).join("")}
  </table></div>
</div>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="4">I. PEMBERIAN INFORMASI</td></tr>
    <tr><th style="width:28px;">NO</th><th>JENIS INFORMASI</th><th>ISI INFORMASI</th><th style="width:70px;">TANDA (&#10003;)</th></tr>
  </thead>
  <tbody>
    ${h.length?h.map(j=>`<tr><td class="center">${t(j.no)}</td><td>${t(j.label)}</td><td>${G(j.isi)}</td><td class="center">${j.centang?"&#10003;":"&nbsp;"}</td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="4">II. PERNYATAAN PEMBERI &amp; PENERIMA INFORMASI</td></tr></thead>
  <tbody>
    ${p.length?p.map((j,b)=>`<tr><td colspan="3">${G(Q(j.teks))}</td><td style="text-align:center;vertical-align:top;"><div>${b===0?"Tanda Tangan Dokter":"Tanda Tangan Penerima"}</div>`+(j.qr?`<img class="rm-sig-qr" src="${t(j.qr)}" alt="QR tanda tangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>')+`<div>( <strong>${t(D(j.ttd))}</strong> )</div></td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
    <tr><td colspan="4">* Bila pasien tidak kompeten atau tidak mau menerima informasi, maka penerima informasi adalah wali atau keluarga terdekat.</td></tr>
  </tbody>
</table>

<div style="border:1px solid #000000;margin-bottom:5px;">
  <div class="sec-hdr" style="border-bottom:1px solid #000000;padding:4px 6px;">III. PERSETUJUAN TINDAKAN KEDOKTERAN</div>
  <div style="padding:5px 8px;">
    <div>Yang bertanda tangan di bawah ini, saya:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:80px;">Nama</td><td style="width:10px;">:</td><td><strong>${t(x)}</strong></td><td style="width:80px;">Umur</td><td style="width:10px;">:</td><td>${t(E)}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td>${t(S)}</td><td>Alamat</td><td>:</td><td>${t(R)}</td></tr>
    </tbody></table>
    <div>Dengan ini menyatakan <strong>PERSETUJUAN</strong> untuk dilakukannya tindakan kedokteran (<strong>${t(A)}</strong>) terhadap: &nbsp; <span class="chk-box">&nbsp;</span> diri saya sendiri &nbsp; <span class="chk-box">&#10003;</span> <strong>Wali / Keluarga dari pasien</strong>:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:90px;">Nama Pasien</td><td style="width:10px;">:</td><td><strong>${t(K)}</strong></td><td style="width:70px;">Umur</td><td style="width:10px;">:</td><td>${t(M("tgl_lahir","tglLahir"))}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td><span class="chk-box">${/laki|^l$/i.test(M("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Laki-laki &nbsp; <span class="chk-box">${/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Perempuan</td><td>Alamat</td><td>:</td><td>${t(jt(i))}</td></tr>
    </tbody></table>
    ${U.map((j,b)=>`<div style="text-align:justify;margin:3px 0;">${b+1}. ${t(j)}</div>`).join("")}
    <table class="rm-table"><thead><tr>
      <th>Yang Menyatakan / Pemberi Persetujuan</th><th>Saksi Keluarga</th><th>Saksi Rumah Sakit</th>
    </tr></thead><tbody><tr>
      <td style="text-align:center;">
        ${O[0]?.qr?`<img class="rm-sig-qr" src="${t(O[0].qr)}" alt="QR penandatangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(w)}</strong> )
      </td>
      <td style="text-align:center;">
        ${O[1]?.qr?`<img class="rm-sig-qr" src="${t(O[1].qr)}" alt="QR saksi keluarga" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(k)}</strong> )
      </td>
      <td style="text-align:center;">
        ${O[2]?.qr?`<img class="rm-sig-qr" src="${t(O[2].qr)}" alt="QR saksi rumah sakit" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(T)}</strong> )
      </td>
    </tr></tbody></table>
  </div>
</div>
</section>`}function ya(i){let L=i.find(I=>/^Anestesi/i.test(I.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=it(i,/^Anestesi/i),n=(...I)=>et(e,...I),r=(...I)=>{let _=gt(n(...I)).replace(/\s+/g," ").trim();return _&&_!=="-"?_:"-"},s=a?(a.body.textContent||"").replace(/\s+/g," ").trim():"",l=a?Array.from(a.querySelectorAll("table")):[],o=I=>I?Array.from(I.rows).map(_=>Array.from(_.cells).map(tt=>(tt.textContent||"").replace(/\s+/g," ").trim())):[],y=I=>new RegExp(`${I.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}\\s*\u2713`,"i").test(s)?"&#10003;":"&nbsp;",C=(...I)=>{for(let _ of i){let tt=new DOMParser().parseFromString(_.html,"text/html");for(let Qa of Array.from(tt.querySelectorAll("tr"))){let wt=Array.from(Qa.cells).map(St=>(St.textContent||"").replace(/\s+/g," ").trim());for(let St=0;St<wt.length-1;St++){let Ka=wt[St].replace(/^[-:\s]+|[\s:]+$/g,"");if(!I.some(Ba=>Ba.test(Ka)))continue;let Yt=wt[St+1]===":"?wt[St+2]||"":wt[St+1].replace(/^:\s*/,"").trim();if(Yt)return Yt}}}return"-"},m=M("nama")!=="-"?M("nama"):r(/^Nama Pasien/i),$=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):r(/^No\.? RM/i),h=M("tgl_lahir","tglLahir")!=="-"?M("tgl_lahir","tglLahir"):C(/^Tgl\.? Lahir|^Tanggal Lahir/i),p=M("umur")!=="-"?M("umur"):C(/^Umur/i),z=Number(p.match(/(\d{1,3})/)?.[1]||0),N=M("jenis_kelamin","jk")!=="-"?M("jenis_kelamin","jk"):C(/^Jenis Kelamin/i),v=/perempuan|^p$/i.test(N)?"Perempuan (P)":/laki|^l$/i.test(N)?"Laki-laki (L)":N,O=r(/^Dokter Anestesi/i),K=r(/^Dokter Bedah/i)!=="-"?r(/^Dokter Bedah/i):M("dokter","dpjp"),Q=r(/^Penata Anestesi/i),D=r(/^Ruangan/i)!=="-"?r(/^Ruangan/i):M("jenis","kelas","ruang"),Y=r(/^Tanggal/i)!=="-"?r(/^Tanggal/i):M("tgl","tanggalAwal","tgl_masuk"),P=r(/^Diagnosis Prabedah|^Diagnosa Pra/i),x=r(/^Diagnosis Pasca Bedah|^Diagnosa Pasca/i),E=r(/^Jenis pembedahan/i),S=r(/^Jenis operasi/i),R=r(/^Jam Mulai/i),A=I=>{let _=l.find(tt=>I.test(tt.rows[0]?.textContent||""));return _?o(_).slice(1).map(tt=>tt.slice(1).filter(Boolean).join(" ")).filter(Boolean).join(", "):"-"},c=A(/MEDIKASI/i),U=A(/PEMBERIAN CAIRAN/i),g=s.match(/kristaloid\s+(\d+)\s*ml/i)?.[1]??"-",w=s.match(/perdarahan\s*\(?EBL\)?\s*(\d+)\s*ml/i)?.[1]??"-",k=s.match(/diuresis\s*(\d+)\s*ml/i)?.[1]??"-",T=s.match(/Respirasi\s*:\s*([^,]+)/i)?.[1]?.trim()??"-",j=l.find(I=>/Informed Consent/i.test(I.textContent||"")),b=o(j).flat().filter(Boolean).map(I=>({label:I.replace(/^[\d\s✓]+/,"").trim(),on:/✓/.test(I)})).filter(I=>I.label&&I.label.length<60),B=b.length?b.map(I=>`<div><span class="chk-box">${I.on?"&#10003;":"&nbsp;"}</span> ${t(I.label)}</div>`).join(""):"<div>-</div>",W=l.find(I=>/PENYAKIT PENYERTA/i.test(I.textContent||"")),X=o(W).slice(1).filter(I=>I.length>=2&&I[0]&&!/PENYAKIT PENYERTA/i.test(I[0])),Mt=X.length?X.map(I=>`<div><span class="chk-box">${/ya|ada|\+/i.test(I[1])?"&#10003;":"&nbsp;"}</span> ${t(I[0])}</div>`).join(""):"<div>-</div>",at=Array.from(a?.querySelectorAll("img")||[]).filter(I=>{let _=I.getAttribute("src")||"",tt=I.getAttribute("class")||"";return!!_&&!/logo|kars|qr|barcode/i.test(_)&&!/logo/i.test(tt)}),rt=I=>I?`<div class="chart-frame">${I.outerHTML}</div>`:'<div class="chart-frame">Grafik tidak tersedia pada berkas ini.</div>',It=rt(at[0]),pt=rt(at[1]??at[0]),ut=V(i,/^Anestesi/i),Tt=[["Dokter Spesialis Anestesiologi",ut[0]||"",O!=="-"?O:ct(ut[0])],["Dokter Operator",ut[1]||"",K!=="-"?K:ct(ut[1])],["Penata / Perawat Anestesi",ut[2]||"",Q!=="-"?Q:ct(ut[2])]].map(([I,_,tt])=>'<div class="tte-box"><div>'+t(I)+'</div><div class="tte-qr">'+(_?`<img src="${t(_)}" alt="QR TTE" width="54" height="54" />`:"")+'</div><div class="tte-name">'+t(tt)+"</div></div>").join(""),d=z>0&&z<18,f=/spinal|subarachnoid|regional/i.test([r(/^Rencana Anestesi/i),r(/^Teknik/i),s].join(" ")),F=d?'<tr><td>Skor Steward</td><td colspan="3">Berlaku untuk pasien anak; skor diisi di halaman asal.</td></tr>':`<tr><td>Aldrete Score</td><td colspan="3">Aktivitas \xB7 Pernapasan \xB7 Sirkulasi \xB7 Kesadaran \xB7 Warna \u2014 skor diisi di halaman asal.</td></tr>
       <tr><td>Bromage Score</td><td colspan="3">${f?"Gerakan penuh dari tungkai dan pergelangan kaki (blok motorik pulih) \u2014 skor diisi di halaman asal.":"Tidak Berlaku (anestesi non-regional)."}</td></tr>
       <tr><td>Steward Score</td><td colspan="3"><em>Tidak Berlaku (khusus pasien anak \u2014 pasien dewasa).</em></td></tr>`,Z=l.find(I=>/INSTRUKSI PASCA ANESTESI/i.test(I.textContent||"")),q=o(Z).flat().map(I=>I.replace(/^[\d\s]+/,"").trim()).filter(I=>I&&!/INSTRUKSI PASCA ANESTESI/i.test(I)&&I.length>3),nt=q.length?'<ol class="an-instruksi">'+q.map(I=>`<li>${t(I)}</li>`).join("")+"</ol>":"<div>-</div>",J=(I,_)=>`<tr><td class="k">${I}</td><td class="c">:</td><td class="v">${_}</td></tr>`,lt=I=>`<tr><th class="rm-sec-head" style="text-align:left;">${I}</th></tr>`;return`<section class="rm-page" id="form-anestesi">
<div class="an-meta"><span>Halaman 1 dari 2</span><span>RM. 21</span></div>
${H("RM. 21")}
<div class="rm-form-title">LAPORAN ANESTESI</div>
<div class="an-subtitle">REKAM PELAKSANAAN ANESTESI</div>

<table class="rm-grid-table"><tbody><tr>
  <td style="width:52%;"><table class="an-kv">
    ${J("Nama Pasien",`<strong>${t(m)}</strong>`)}
    ${J("No. Rekam Medis",`<strong>${t($)}</strong>`)}
    ${J("Tgl. Lahir / Umur",`${t(h)} (${t(p)} / ${t(v)})`)}
    ${J("Diagnosa Pra Bedah",t(P))}
    ${J("Diagnosa Pasca Bedah",`<strong>${t(x)}</strong>`)}
  </table></td>
  <td><table class="an-kv">
    ${J("Tanggal Tindakan",`<strong>${t(Y)}</strong>`)}
    ${J("Jenis Pembedahan",t(E))}
    ${J("Jenis Operasi",t(S))}
    ${J("Ruangan",t(D))}
    ${J("Dokter Anestesi",`<strong>${t(O)}</strong>`)}
  </table></td>
</tr></tbody></table>

<table class="rm-grid-table"><tbody>${lt("A. JENIS PERSIAPAN ANESTESI")}
<tr><td><div class="an-grid-4">${B}</div></td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${lt("B. PENGKAJIAN PRA BEDAH &amp; RENCANA ANESTESI")}
<tr><td><table class="an-kv">
  ${J("Waktu Mulai",t(R))}
  ${J("Dokter Operator",t(K))}
  ${J("Asisten Bedah",t(r(/^Asisten Bedah|^Asisten/i)))}
  ${J("Instrumen Bedah",t(r(/^Instrumen Bedah|^Perawat Instrumen/i)))}
  ${J("Rencana Anestesi",`${y("Anestesi Umum")} Umum &nbsp; ${y("Spinal")} Spinal &nbsp; ${y("Epidural")} Epidural &nbsp; ${y("Kaudal")} Kaudal`)}
</table>
<div class="an-risk"><strong>Riwayat Penyakit &amp; Faktor Risiko:</strong><div class="an-grid-3">${Mt}</div></div>
</td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${lt("C. INDUKSI &amp; MONITORING ANESTESI")}
<tr><td><table class="an-kv">
  ${J("Teknik / Lokasi Tusukan",`${t(r(/^Teknik :|^Lokasi Tusukan/i))} ${t(r(/^Analgesia setinggi/i))}`)}
  ${J("Anestesi Lokal",t(r(/^Anestesi lokal/i)))}
  ${J("ASA",`${y(" I ")} I &nbsp; ${y(" II ")} II &nbsp; ${y(" III ")} III &nbsp; ${y(" IV ")} IV &nbsp; ${y(" V ")} V &nbsp; ${y(" E ")} E`)}
</table></td></tr>
<tr><td>${It}</td></tr></tbody></table>

<!-- ================= HALAMAN 2 ================= -->
<div class="an-page-break"></div>
<div class="an-running">
  <span><strong>LAPORAN ANESTESI (LANJUTAN)</strong> \u2014 ${t(mt)}</span>
  <span>Pasien: <strong>${t(m)}</strong> \u2022 RM: <strong>${t($)}</strong></span>
  <span><strong>Halaman 2 dari 2 \u2022 RM. 21</strong></span>
</div>

<table class="rm-grid-table"><tbody>${lt("D. MEDIKASI, CAIRAN &amp; JALAN NAPAS")}
<tr><td><table class="an-kv">
  ${J("Medikasi",t(c))}
  ${J("Pemberian Cairan",t(U))}
  ${J("Total Asupan Cairan",g==="-"?"-":`${g} ml`)}
  ${J("Total Keluaran Cairan",`Perdarahan ${w} ml \u2022 Diuresis ${k} ml`)}
  ${J("Pengelolaan Napas",t(T))}
</table></td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${lt("E. PEMANTAUAN RUANG PULIH SADAR")}
<tr><td>${pt}</td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${lt("F. PENILAIAN KELAYAKAN PINDAH RUANGAN")}
${F}</tbody></table>

<table class="rm-grid-table"><tbody>${lt("G. INSTRUKSI PASCA ANESTESI")}
<tr><td>${nt}</td></tr></tbody></table>

<div class="an-tte-note">Jambi, ${t(Y)} \u2014 Dokumen ditandatangani secara elektronik (TTE):</div>
<footer class="an-tte">${Tt}</footer>
</section>`}function Da(i){let L=it(i,/^Fisioterapi/i),a=ot(i,/^Fisioterapi/i),e=(...n)=>et(L,...n);return`<section class="rm-page" id="form-fisioterapi">
${H("FISIOTERAPI")}
<div class="rm-form-title">LEMBAR ASSESMEN &amp; TERAPI FISIOTERAPI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal",e(/^Tanggal/i))}
    ${u("Diagnosa",e(/^Diagnosa/i))}
    ${u("Ruang / Asal",e(/^Ruang|^Unit/i))}
    ${u("Terapis",e(/^Terapis|^Fisioterapis/i))}
  </table></div>
</div>
${st([["KELUHAN UTAMA (SUBJEKTIF)",e(/^Keluhan|^Subjektif/i)],["PEMERIKSAAN OBJEKTIF (ROM / MMT / FUNGSI)",e(/^Objektif|^Pemeriksaan/i)],["ASSESMEN FISIOTERAPI",e(/^Assesmen|^Diagnosa Fisio/i)],["RENCANA TERAPI &amp; TUJUAN",e(/^Rencana|^Terapi|^Tujuan/i)]])}
<div class="sub-heading-rm">PELAKSANAAN TERAPI</div>
${dt(["TANGGAL","MODALITAS / LATIHAN","FREKUENSI","RESPON PASIEN"],a,!0)}
${Lt(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Terapis / Fisioterapis",`( ${t(e(/^Terapis|^Fisioterapis/i))} )`])}
</section>`}function xa(i){let L=it(i,/^Pengkajian Hemodialisa/i),a=ot(i,/^Pengkajian Hemodialisa/i),e=(...n)=>et(L,...n);return`<section class="rm-page" id="form-hemodialisa">
${H("HEMODIALISA")}
<div class="rm-form-title">LEMBAR PENGKAJIAN &amp; SESI HEMODIALISA</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Sesi",e(/^Tanggal/i))}
    ${u("Akses Vaskular",e(/^Akses/i))}
    ${u("Diagnosa",e(/^Diagnosa/i))}
    ${u("Perawat / Dokter",e(/^Perawat|^Dokter/i))}
  </table></div>
</div>
${dt(["PARAMETER","SEBELUM DIALISA","SESUDAH DIALISA","KETERANGAN"],[["Berat Badan",e(/^BB Sebelum|^Berat Sebelum/),e(/^BB Sesudah|^Berat Sesudah/),"-"],["Tekanan Darah",e(/^TD Sebelum|^Tekanan Sebelum/),e(/^TD Sesudah|^Tekanan Sesudah/),"-"],["Nadi",e(/^Nadi Sebelum/),e(/^Nadi Sesudah/),"-"],...a],!0)}
${st([["BLOOD FLOW / DIALYSATE FLOW",e(/^Blood Flow|^Dialysate/i)],["ULTRAFILTRASI &amp; Heparinisasi",e(/^Ultrafiltrasi|^UF|^Heparin/i)],["ADEKUASI (Kt/V)",e(/^Kt\/V|^Adekuasi/i)],["KOMPLIKASI / CATATAN",e(/^Komplikasi|^Catatan/i)]])}
${Lt(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Perawat Hemodialisa",`( ${t(e(/^Perawat/i))} )`])}
</section>`}function Ea(i){let L=i.find(x=>/^Operasi/i.test(x.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=it(i,/^Operasi/i),n=(...x)=>et(e,...x),r=x=>gt(x).replace(/\bantispetik\b/gi,"antiseptik").replace(/\bincisi\b/gi,"insisi").replace(/\bfacia\b/gi,"fasia").replace(/\bdaryantul\b/gi,"daryantulle").replace(/\bPendarahan\b/g,"Perdarahan").replace(/\bTranfusi\b/g,"Transfusi").replace(/\bEFEKTIF\b/g,"Elektif").replace(/\s+/g," ").trim(),s=(...x)=>{let E=r(n(...x));return E&&E!=="-"?E:"-"},l=(x,E)=>{for(let S of x){let R=M(S);if(R!=="-")return r(R)}return s(E)},o=(()=>{if(!a)return[];let x=Array.from(a.querySelectorAll("td")).find(E=>/^\s*Uraian Pembedahan\b/i.test(E.textContent||""))?.parentElement?.nextElementSibling?.querySelector("td")?.textContent||"";return x.trim()||(x=Array.from(a.querySelectorAll("td")).map(E=>(E.textContent||"").trim()).sort((E,S)=>S.length-E.length)[0]||""),x.split(/\n+/).map(E=>r(E)).filter(Boolean)})(),y=a?Array.from(a.querySelectorAll("td")).map(x=>(x.textContent||"").replace(/\s+/g," ").trim()).filter(x=>/^-?\s*(MAYOR|MINOR|EFEKTIF|ELEKTIF|EMERGENSI|CITO|SEDANG|KHUSUS)$/i.test(x)).join(" "):"",C=x=>x.test(y)?"&#10003;":"&nbsp;",m=s(/^Komplikasi/i),$=m==="-"?'<span class="chk-box">&#10003;</span> Tidak ada komplikasi &nbsp;&nbsp; <span class="chk-box">&nbsp;</span> Ada, sebutkan: ..............................':'<span class="chk-box">&nbsp;</span> Tidak ada komplikasi &nbsp;&nbsp; <span class="chk-box">&#10003;</span> Ada: <strong>'+t(m)+"</strong>",h=s(/^Penggunaan Implan/i),p=/^Ya/i.test(h)?`<span class="chk-box">&nbsp;</span> Tidak &nbsp; <span class="chk-box">&#10003;</span> Ya \u2014 Jenis: ${t(s(/^Jenis Implan/i))} | No. Seri: ${t(s(/^Nomor Implan/i))}`:'<span class="chk-box">&#10003;</span> Tidak &nbsp; <span class="chk-box">&nbsp;</span> Ya',z=s(/^Tanggal Bedah/i),N=l(["dokter_operator","operator"],/^Dokter Operator|^Operator/i),v=V(i,/^Operasi/i)[0]??"",O=M("jenis_kelamin","jk")||s(/^Jenis Kelamin/i),K=/perempuan|^p$/i.test(O)?"Perempuan (P)":/laki|^l$/i.test(O)?"Laki-laki (L)":O,Q=z!=="-"?Dt(z):"-",D=(x,E,S="")=>`<tr><td class="k${S}">${x}</td><td class="c">:</td><td class="v">${E}</td></tr>`,Y=(x,E=2)=>`<tr><th class="rm-sec-head" colspan="${E}" style="text-align:left;">${x}</th></tr>`,P=o.length?'<ol class="op-steps">'+o.map(x=>`<li>${t(x)}</li>`).join("")+"</ol>":"<div>-</div>";return`<section class="rm-page" id="form-operasi">
${H("RM. 20")}
<div class="rm-form-title">LAPORAN PELAKSANAAN OPERASI</div>

<div class="id-box-borderless">
  <div class="id-col"><table class="op-kv">
    ${D("Nama Pasien",`<strong>${t(l(["nama"],/^Nama Pasien|^Nama$/i))}</strong>`)}
    ${D("Tanggal Lahir / Umur",`${t(l(["tgl_lahir","tglLahir"],/^Tanggal Lahir|^Tgl Lahir/i))} (${t(M("umur")||s(/^Umur/i))})`)}
  </table></div>
  <div class="id-col"><table class="op-kv">
    ${D("No. Rekam Medis",`<strong>${t(l(["norm","rekam_medis"],/^No\.? RM/i))}</strong>`)}
    ${D("Jenis Kelamin",t(K))}
  </table></div>
</div>

<table class="rm-grid-table"><tbody>
  ${Y("I. TIM OPERASI &amp; WAKTU PEMBEDAHAN")}
  <tr>
    <td style="width:54%;">
      <table class="op-kv">
        ${D("Dokter Operator",`<strong>${t(N)}</strong>`)}
        ${D("Asisten / Dr. Anestesi",t(s(/^Asisten/i)))}
        ${D("Perawat Instrumen",t(s(/^Perawat Instrumen/i)))}
      </table>
    </td>
    <td>
      <table class="op-kv">
        ${D("Tanggal Bedah",`<strong>${t(z)}</strong>`)}
        ${D("Jam Mulai \u2013 Selesai",`${t(s(/^Jam Mulai/i))} \u2013 ${t(s(/^Jam Selesai/i))}`)}
        ${D("Lama Waktu Bedah",`<strong>${t(s(/^Waktu Bedah/i))}</strong>`)}
      </table>
    </td>
  </tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  ${Y("II. DIAGNOSIS, KLASIFIKASI &amp; TINDAKAN / ICD-9-CM")}
  <tr>
    <td style="width:54%;">
      <table class="op-kv">
        ${D("Diagnosis Pra Bedah",t(s(/^Diagnosis Pra Bedah|^Diagnosa Pra/i)))}
        ${D("Diagnosis Pasca Bedah",`<strong>${t(s(/^Diagnosis Pasca Bedah|^Diagnosa Pasca/i))}</strong>`)}
        ${D("Nama / Macam Operasi",`<strong>${t(s(/^Nama Macam Operasi|^Tindakan|^Prosedur/i))}</strong>`)}
      </table>
    </td>
    <td>
      <table class="op-kv">
        <tr><td class="k">Kategori Operasi</td><td class="c">:</td><td class="v"><span class="chk-box">${C(/MAYOR/i)}</span> Mayor &nbsp; <span class="chk-box">${C(/SEDANG|MINOR/i)}</span> Sedang &nbsp; <span class="chk-box">${C(/KHUSUS/i)}</span> Khusus</td></tr>
        <tr><td class="k">Sifat Operasi</td><td class="c">:</td><td class="v"><span class="chk-box">${C(/ELEKTIF|EFEKTIF/i)}</span> Elektif &nbsp; <span class="chk-box">${C(/CITO|EMERGENSI/i)}</span> Cito / Emergensi</td></tr>
        ${D("Jaringan Dieksisi",t(s(/^Jaringan yang Dieksisi|^Jaringan Dieksisi/i)))}
        <tr><td class="k">Penggunaan Implan</td><td class="c">:</td><td class="v">${p}</td></tr>
      </table>
    </td>
  </tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  ${Y("III. URAIAN PEMBEDAHAN")}
  <tr><td class="op-narrative">
    <div><strong>Langkah-Langkah Tindakan:</strong></div>
    ${P}
  </td></tr>
  <tr><td><strong>IV. Komplikasi Intraoperatif:</strong> &nbsp; ${$}</td></tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  <tr>
    <th class="rm-sec-head" style="width:50%;text-align:left;">V. PEMERIKSAAN PATOLOGI ANATOMI (PA)</th>
    <th class="rm-sec-head" style="text-align:left;">VI. PERDARAHAN, TRANSFUSI &amp; DRAINASE</th>
  </tr>
  <tr>
    <td><table class="op-kv">
      ${D("Jaringan ke PA",`<strong>${t(s(/^Jaringan ke Patologi/i))}</strong>`)}
      ${D("Dikirim Untuk",t(s(/^Dikirim Untuk/i)))}
      ${D("Jenis Jaringan",t(s(/^Jenis Jaringan/i)))}
      ${D("Tanggal Pengiriman",t(s(/^Tanggal Jaringan/i)))}
    </table></td>
    <td><table class="op-kv">
      ${D("Perkiraan Perdarahan",`<strong>${t(s(/^Perkiraan Pendarahan|^Perkiraan Perdarahan/i))}</strong>`)}
      ${D("Transfusi Darah",t(s(/^Tranfusi Darah|^Transfusi Darah/i)))}
      ${D("Pemakaian Drain",t(s(/^Pemakaian Drain/i)))}
    </table></td>
  </tr>
</tbody></table>

<div class="rm-signature-block" style="justify-content:flex-end;">
  <div class="rm-sig-box">
    <div>Jambi, ${t(Q)}</div>
    <div>Dokter Operator,</div>
    ${v?`<img class="rm-sig-qr" src="${t(v)}" alt="QR TTE dokter operator" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(N)} )</div>
  </div>
</div>
</section>`}function Ia(i){let L=i.find(n=>/^Laboratorium/i.test(n.title)),a=L?new DOMParser().parseFromString(L.html,"text/html"):null,e=a?Array.from(a.querySelectorAll("img")).map(n=>n.outerHTML).filter(n=>!/logo/i.test(n)):[];return`<section class="rm-page" id="rm-09">
${H("RM. 09")}
<div class="rm-form-title">HASIL PEMERIKSAAN LABORATORIUM PATOLOGI KLINIK</div>
<div class="passthrough-separator"><span>LAMPIRAN HASIL LABORATORIUM (LIS)</span><span>FILE UPLOAD</span></div>
<div class="raw-upload-frame">
  ${e.length?e.join("<br/>"):"-"}
</div>
</section>`}function Ta(i){let L=it(i,/^Surat Kematian/i),a=(...e)=>et(L,...e);return`<section class="rm-page" id="form-kematian">
${H("KEMATIAN")}
<div class="rm-form-title">SURAT KETERANGAN KEMATIAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Tgl. Lahir / Umur",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
    ${u("Alamat",jt(i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Kematian",a(/^Tanggal Kematian|^Tanggal/i))}
    ${u("Jam Kematian",a(/^Jam/i))}
    ${u("Tempat Kematian",a(/^Tempat/i))}
    ${u("Ruang / Kelas",[M("jenis"),M("kelas","ruang")].filter(e=>e!=="-").join(" / ")||"-")}
  </table></div>
</div>
${st([["PENYEBAB KEMATIAN LANGSUNG (I)",a(/^Penyebab Langsung|^Penyebab I/i)],["PENYEBAB ANTARA (II)",a(/^Penyebab Antara|^Penyebab II/i)],["PENYAKIT / KONDISI LAIN",a(/^Penyakit Lain|^Kondisi Lain/i)],["KETERANGAN",a(/^Keterangan|^Catatan/i)]])}
${Lt(["Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(a(/^Tanggal Kematian|^Tanggal/i)),"Dokter yang Menyatakan Meninggal",`( ${t(M("dokter","dpjp"))} )`])}
</section>`}function ba(i){let L=it(i,/^Permintaan Terapi/i),a=ot(i,/^Permintaan Terapi/i),e=(...n)=>et(L,...n);return`<section class="rm-page" id="form-terapi">
${H("TERAPI")}
<div class="rm-form-title">PERMINTAAN TERAPI REHABILITASI MEDIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Permintaan",e(/^Tanggal/i))}
    ${u("Ruangan / Unit Asal",e(/^Ruang|^Unit/i))}
    ${u("Dokter Pengirim",e(/^Dokter Pengirim/i))}
    ${u("Diagnosa",e(/^Diagnosa/i))}
  </table></div>
</div>
${st([["JENIS TERAPI YANG DIMINTA",e(/^Jenis Terapi|^Terapi/i)],["TUJUAN TERAPI",e(/^Tujuan/i)],["FREKUENSI / RENCANA",e(/^Frekuensi|^Rencana/i)],["CATATAN KLINIS",e(/^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN PERMINTAAN</div>
${dt(["NO","TERAPI / MODALITAS","FREKUENSI","KETERANGAN"],a,!0)}
${Lt(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Dokter Pengirim",`( ${t(e(/^Dokter Pengirim/i))} )`])}
</section>`}function ka(i){let L=it(i,/^Uji Fungsi/i),a=ot(i,/^Uji Fungsi/i),e=(...n)=>et(L,...n);return`<section class="rm-page" id="form-uji-fungsi">
${H("UJI FUNGSI")}
<div class="rm-form-title">LEMBAR UJI FUNGSI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Pemeriksaan",e(/^Tanggal/i))}
    ${u("Diagnosa",e(/^Diagnosa/i))}
    ${u("Petugas Uji",e(/^Petugas|^Terapis/i))}
    ${u("Alat / Metode",e(/^Alat|^Metode/i))}
  </table></div>
</div>
${dt(["PARAMETER FUNGSI","NILAI / SKOR","SATUAN","KETERANGAN"],a,!0)}
${st([["HASIL / INTERPRETASI",e(/^Hasil|^Interpretasi/i)],["KESIMPULAN",e(/^Kesimpulan/i)],["REKOMENDASI TERAPI",e(/^Rekomendasi|^Saran/i)]])}
${Lt(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Petugas Uji Fungsi",`( ${t(e(/^Petugas|^Terapis/i))} )`])}
</section>`}function Ca(i){let L=it(i,/^Partograf/i),a=ot(i,/^Partograf/i),e=(...n)=>et(L,...n);return`<section class="rm-page" id="form-partograf">
${H("PARTOGRAF")}
<div class="rm-form-title">PARTOGRAF \u2014 PEMANTAUAN KEMAJUAN PERSALINAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Umur",e(/^Umur/i))}
    ${u("Grafida / Paritas",e(/^Grafida|^Paritas|^G/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("HPHT",e(/^HPHT/i))}
    ${u("Taksiran Persalinan",e(/^Taksiran|^TP/i))}
    ${u("Tanggal Persalinan",e(/^Tanggal/i))}
    ${u("Petugas",e(/^Petugas|^Bidan/i))}
  </table></div>
</div>
<div class="sub-heading-rm">KEMAJUAN PERSALINAN &amp; OBSERVASI</div>
${dt(["JAM","PEMBUKAAN","TURUN","KONTRAKSI","DJJ","TD / NADI","SUHU","URINE","CATATAN"],a,!0)}
${st([["KEADAAN IBU &amp; JANIN",e(/^Keadaan|^Kondisi/i)],["TINDAKAN / PENYIMPANGAN",e(/^Tindakan|^Penyimpangan/i)],["CATATAN",e(/^Catatan/i)]])}
${Lt(["Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Bidan / Petugas Persalinan",`( ${t(e(/^Petugas|^Bidan/i))} )`])}
</section>`}function ha(i){let L=it(i,/^Laporan Tindakan/i),a=ot(i,/^Laporan Tindakan/i),e=(...n)=>et(L,...n);return`<section class="rm-page" id="form-laporan-tindakan">
${H("LAPORAN TINDAKAN")}
<div class="rm-form-title">LAPORAN PELAKSANAAN TINDAKAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Tindakan",e(/^Tanggal/i))}
    ${u("Jenis Tindakan",e(/^Jenis Tindakan|^Tindakan/i))}
    ${u("Ruang / Unit",e(/^Ruang|^Unit/i))}
    ${u("Pelaksana",e(/^Pelaksana|^Petugas|^Dokter/i))}
  </table></div>
</div>
${st([["INDIKASI / DIAGNOSA",e(/^Indikasi|^Diagnosa/i)],["URAIAN TINDAKAN",e(/^Uraian|^Prosedur/i)],["HASIL TINDAKAN",e(/^Hasil/i)],["KOMPLIKASI / CATATAN",e(/^Komplikasi|^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN TINDAKAN</div>
${dt(["NO","TINDAKAN","WAKTU / JAM","PELAKSANA"],a,!0)}
${Lt(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Pelaksana Tindakan",`( ${t(e(/^Pelaksana|^Petugas|^Dokter/i))} )`])}
</section>`}var Ot=i=>i?Array.from(i.rows).map(L=>Array.from(L.cells).map(Nt)):[],$t=i=>[i.match(/(\d{1,2}\/\d{1,2}\/\d{4})/)?.[1]??"-",i.match(/Pukul\s*([\d:]+)/i)?.[1]??"-"],Pt=i=>i.match(/dr\.[^\n]+/i)?.[0]?.trim()??"-";function za(i){let L=Array.from(i.querySelectorAll("table")),a=L[0]??null,e=L.find(N=>/Jawaban Konsultasi/i.test(N.textContent||""))??null,n=Ot(a),r=Ot(e),s=n[0]??[],l=n[1]?.[0]||"",o=n.findIndex(N=>/^Penemuan Klinis/i.test(N[0]||"")),[y,C]=$t(s[1]||""),[m,$]=$t(r[1]?.[1]||""),h={};for(let N of r.slice(2))for(let v of N){let O=v.match(/^(Subjektif|Objektif|Assesmen|Planning|Instruksi)\s*:\s*([\s\S]*)$/i);O&&(h[O[1].toLowerCase()]=O[2].trim()||"-")}let p=(s[0]||"").replace(/^\s*Konsul Ke\s*:\s*/i,"").replace(/\s+/g," ").trim(),z=Pt(r[r.length-1]?.[1]||"");return{konsulen:z!=="-"?z:p||"-",pengirim:Pt(n[n.length-1]?.[1]||""),tanggal:y,jam:C,jenis:l.match(/Mohon\s+Konsultasi\s+([^\s:]+)/i)?.[1]??"-",permintaan:l||"-",penemuan:(o>=0?n[o+1]?.[0]:"")||"-",dugaan:n.flat().find(N=>/^Dugaan\s*:/i.test(N))?.replace(/^Dugaan\s*:\s*/i,"").trim()||"-",subjektif:h.subjektif||"-",objektif:h.objektif||"-",asesmen:h.asesmen||"-",planning:h.planning||"-",instruksi:h.instruksi||"-",keputusan:r.flat().find(N=>/Konsultasi selesai tanggal/i.test(N))||"-",tglJawaban:m,jamJawaban:$}}function fa(i,L,a="rm-10"){let e=L??i.find(l=>/Konsul/i.test(l.title));if(!e)return"";let n=new DOMParser().parseFromString(e.html,"text/html"),r=Array.from(n.querySelectorAll("b")).filter(l=>/^\s*Konsul Ke\s*:/i.test(l.textContent||"")).map(l=>l.closest("table")?.parentElement).filter(l=>!!l),s=V([e],/Konsul/i);return r.map((l,o)=>va(za(l),s[o]??"",o?`${a}-${o+1}`:a)).join("")}function va(i,L,a){let e=M("dokter","dpjp"),n=i.konsulen!=="-"?i.konsulen:M("dokter_konsulen")!=="-"?M("dokter_konsulen"):ct(L);return`<section class="rm-page" id="${t(a)}">
${H("RM. 10")}
<div class="rm-form-title">LEMBAR KONSULTASI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("Tanggal Lahir / Umur",M("tgl_lahir","tglLahir"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Jenis Kunjungan",[M("jenis"),M("kelas","ruang")].filter(r=>r!=="-").join(" / ")||"-")}
    ${u("Tanggal Permintaan",`${i.tanggal} ${i.jam}`.trim())}
    ${u("Tanggal Jawaban",`${i.tglJawaban} ${i.jamJawaban}`.trim())}
  </table></div>
</div>
${st([["BAGIAN I : KEPADA YTH. KONSULEN",n],["JENIS PERMOHONAN",i.jenis],["PERMINTAAN KONSULTASI",i.permintaan],["PENEMUAN KLINIS TERPENTING",i.penemuan],["DUGAAN DIAGNOSA",i.dugaan]])}
${st([["S (SUBJEKTIF)",i.subjektif],["O (OBJEKTIF)",i.objektif],["A (ASSESMEN)",i.asesmen],["P (PLANNING)",i.planning],["INSTRUKSI",i.instruksi],["KEPUTUSAN KONSULTASI",i.keputusan]])}
${Lt(["Dokter Pemohon Konsultasi",e!=="-"?`( ${t(e)} )`:`( ${t(i.pengirim)} )`],["Dokter Konsulen",L?`<img class="rm-sig-qr" src="${t(L)}" alt="QR dokter konsulen" width="80" height="80" />`:'<div class="rm-sig-space"></div>',`( ${t(n)} )`])}
</section>`}function Oa(i){let L=it(i,/^Bon Makan/i),a=(...e)=>et(L,...e);return`<section class="rm-page" id="form-bon-makan">
${H("BON MAKAN")}
<div class="rm-form-title">BON MAKAN PASIEN / PENDAMPING</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Ruang / Kelas",[M("jenis"),M("kelas","ruang")].filter(e=>e!=="-").join(" / ")||"-")}
    ${u("Tanggal",a(/^Tanggal/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Nama Pendamping",a(/^Pendamping|^Keluarga/i))}
    ${u("Jumlah Porsi",a(/^Jumlah|^Porsi/i))}
    ${u("Waktu",a(/^Waktu|^Jam/i))}
    ${u("Petugas",a(/^Petugas/i))}
  </table></div>
</div>
${dt(["NO","NAMA","HUBUNGAN","JUMLAH","KETERANGAN"],ot(i,/^Bon Makan/i),!0)}
<div class="footnote-rm">Bon ini berlaku sesuai jadwal makan yang ditetapkan ruangan / instalasi gizi.</div>
${Lt(["Pasien / Pendamping",`( ${t(a(/^Pendamping|^Keluarga/i))} )`],["Kota Jambi, "+t(a(/^Tanggal/i)),"Petugas Ruangan",`( ${t(a(/^Petugas/i))} )`])}
</section>`}function $a(i){let L=it(i,/^PEMERIKSAAN$/i),a=ot(i,/^PEMERIKSAAN$/i),e=(...n)=>et(L,...n);return`<section class="rm-page" id="form-pemeriksaan">
${H("PEMERIKSAAN")}
<div class="rm-form-title">HASIL PEMERIKSAAN / DIAGNOSTIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${u("Nama Pasien",M("nama"),!0)}
    ${u("No. Rekam Medis",M("norm","rekam_medis"))}
    ${u("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${u("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${u("Tanggal Pemeriksaan",e(/^Tanggal/i))}
    ${u("Jenis Pemeriksaan",e(/^Jenis Pemeriksaan|^Pemeriksaan/i))}
    ${u("Spesimen / Bahan",e(/^Spesimen|^Bahan/i))}
    ${u("Dokter Pengirim",e(/^Dokter Pengirim/i))}
  </table></div>
</div>
${dt(["PARAMETER","HASIL","SATUAN","NILAI RUJUKAN"],a,!0)}
${st([["MAKROSKOPIK / TEMUAN",e(/^Makroskopik|^Temuan/i)],["MIKROSKOPIK",e(/^Mikroskopik/i)],["KESIMPULAN / DIAGNOSA",e(/^Kesimpulan|^Diagnosa/i)],["CATATAN",e(/^Catatan/i)]])}
${Lt(["Petugas / Analis",`( ${t(e(/^Petugas|^Analis/i))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Dokter Penanggung Jawab",`( ${t(e(/^Dokter Penanggung Jawab|^Dokter/i))} )`])}
</section>`}function Pa(i,L){let a=ta(i,L),e=M("no_sep","sep"),n=M("kartu","no_kartu","noka"),r=M("norm","rekam_medis"),s=M("nama"),l=[M("jenis"),M("kelas","ruang")].filter(S=>S!=="-").join(" / ")||"-",o=M("dokter","dpjp"),y=M("tanggalAwal","tgl_masuk","tgl"),C=M("tanggalAkhir","keluar","tgl_keluar"),m=M("tgl_lahir","tglLahir"),$=M("jenis_kelamin","jk"),h=jt(i),p=i.filter(S=>/resep/i.test(S.title)).length,z=vt,N=new Date,v=`${N.getDate()} ${z[N.getMonth()]} ${N.getFullYear()}`,O=`<table class="rm-grid-table">
  <thead>
    <tr><th colspan="3">CATATAN KETIDAKSESUAIAN DATA LINTAS DOKUMEN (HASIL UJI SILANG OTOMATIS)</th></tr>
    <tr><th style="width: 32px;">NO</th><th style="width: 170px;">JENIS KETIDAKSESUAIAN</th><th>URAIAN TEMUAN VERIFIKASI</th></tr>
  </thead>
  <tbody>${a.map((S,R)=>`<tr><td class="center">${R+1}</td><td><strong>${t(S.title)}</strong></td><td>${t(S.detail)}</td></tr>`).join("")}</tbody>
</table>`,K=`<section class="rm-page" id="rm-00">
${H("RM. 00")}
<div class="rm-form-title">LEMBAR KENDALI KELENGKAPAN &amp; VERIFIKASI BERKAS KLAIM JKN</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NAMA PASIEN</td><td class="col">:</td><td class="val"><strong>${t(s)}</strong></td></tr>
    <tr><td class="lbl">NO. REKAM MEDIS</td><td class="col">:</td><td class="val"><strong>${t(r)}</strong></td></tr>
    <tr><td class="lbl">TGL. LAHIR / UMUR</td><td class="col">:</td><td class="val">${t(m)}</td></tr>
    <tr><td class="lbl">JENIS KELAMIN</td><td class="col">:</td><td class="val">${t($)}</td></tr>
    <tr><td class="lbl">ALAMAT</td><td class="col">:</td><td class="val">${t(h)}</td></tr>
  </table></div>
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NO. KARTU BPJS</td><td class="col">:</td><td class="val"><strong>${t(n)}</strong></td></tr>
    <tr><td class="lbl">NO. SEP</td><td class="col">:</td><td class="val"><strong>${t(e)}</strong></td></tr>
    <tr><td class="lbl">TGL. MASUK / KELUAR</td><td class="col">:</td><td class="val">${t([y,C].filter(S=>S&&S!=="-").join(" s/d ")||"-")}</td></tr>
    <tr><td class="lbl">RUANG / KELAS</td><td class="col">:</td><td class="val">${t(l)}</td></tr>
    <tr><td class="lbl">DPJP UTAMA</td><td class="col">:</td><td class="val">${t(o)}</td></tr>
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 110px;">KODE INA-CBG</th>
      <th>DESKRIPSI GROUPING INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF RIIL RS</th>
      <th class="num" style="width: 115px;">SELISIH</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="center"><strong>${t(At("ina_cbg_code")||"-")}</strong></td>
      <td>${t(At("ina_cbg_desc")||"-")}</td>
      <td class="num"><strong>${t(At("tarif_ina_cbg")||"-")}</strong></td>
      <td class="num">${t(At("tarif_riil_rs")||"-")}</td>
      <td class="num">${t(At("selisih")||"-")}</td>
    </tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 32px;">NO</th>
      <th style="width: 58px;">KODE RM</th>
      <th>JENIS BERKAS / DOKUMEN KLAIM</th>
      <th style="width: 120px;">STATUS BERKAS</th>
      <th style="width: 68px;">TANDA (&#10003;)</th>
    </tr>
  </thead>
  <tbody>
    <tr><td class="center">1</td><td class="center">RM. 01</td><td>Surat Elegibilitas Peserta (SEP) \u2014 No. ${t(e)}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 01 SEP"></td></tr>
    <tr><td class="center">2</td><td class="center">RM. 01</td><td>Berkas Klaim Individual Pasien (INA-CBG E-Klaim 5.10.9)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi INA-CBG"></td></tr>
    <tr><td class="center">3</td><td class="center">RM. 02</td><td>Surat Bukti Pelayanan Kesehatan (SBPK) \u2014 ${t(l)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 02 SBPK"></td></tr>
    <tr><td class="center">4</td><td class="center">RM. 03</td><td>Surat Pengantar Rawat Inap (SPRI) \u2014 Tgl. ${t(y||"-")}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 03 SPRI"></td></tr>
    <tr><td class="center">5</td><td class="center">Seksi 04</td><td>File Upload Dokumen Pasien (Laporan Echo/Doppler &amp; Rekaman EKG)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Seksi 04 Upload"></td></tr>
    <tr><td class="center">6</td><td class="center">RM. 05</td><td>Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi (${p} Nota Resep)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 05 Billing"></td></tr>
    <tr><td class="center">7</td><td class="center">RM. 06</td><td>Ringkasan Pulang (Discharge Summary) \u2014 DPJP ${t(o)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 06 Resume"></td></tr>
    <tr><td class="center">8</td><td class="center">RM. 07</td><td>Formulir Telaah Resep, Telaah Obat &amp; Edukasi Farmasi (No. 230445)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 07 Telaah"></td></tr>
    <tr><td class="center">9</td><td class="center">RM. 08</td><td>Hasil Pemeriksaan Radiologi \u2014 Thorax AP/PA (No. Rontgen 5918)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 08 Radiologi"></td></tr>
    <tr><td class="center">10</td><td class="center">RM. 09</td><td>Hasil Pemeriksaan Laboratorium Patologi Klinik (Hematologi &amp; Urine)</td><td class="center"><strong>TIDAK LENGKAP *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 09 Lab"></td></tr>
    <tr><td class="center">11</td><td class="center">RM. 10</td><td>Lembar Konsultasi Antar-Spesialis (dr. M. Ryan Ramadhan, Sp.JP., FIHA)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 10 Konsul"></td></tr>
  </tbody>
</table>

${O}

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Kota Jambi, ${v}</div>
    <div>Petugas Casemix / Klaim JKN RS</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">RSUD H. Abdul Manap Kota Jambi</div>
  </div>
  <div class="rm-sig-box">
    <div>Diterima &amp; Diverifikasi Oleh,</div>
    <div>Verifikator BPJS Kesehatan</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">NPP. ............................................</div>
  </div>
</div>
</section>`,Q=i,D=new Map,Y=Q.map((S,R)=>{let A=ea(S.title,R),c=(D.get(A.id)??0)+1;return D.set(A.id,c),c===1?A:{...A,id:`${A.id}-${c}`,tab:`${A.tab} (${c})`,option:`${A.option} (${c})`}}),P=Q.map((S,R)=>{let A=Y[R];return/^SEP$/i.test(S.title)?Ma(i):/^Surat (?:Rencana )?Kontrol/i.test(S.title)?ua(i):/^SPRI$/i.test(S.title)?sa(i):/^SBPK$/i.test(S.title)?La(i):/^Rincian Biaya/i.test(S.title)?ra(i):/^Resume/i.test(S.title)?na(i):/^Telaah/i.test(S.title)?la(i):/^Radiologi/i.test(S.title)?da(i,S,A.id):/^Triage/i.test(S.title)?ca(i):/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(S.title)?ga(i):/^Laboratorium/i.test(S.title)?Ia(i):/Konsul/i.test(S.title)?fa(i,S,A.id):/^Persetujuan Tindakan/i.test(S.title)?pa(i):/^Anestesi/i.test(S.title)?ya(i):/^Fisioterapi/i.test(S.title)?Da(i):/^Pengkajian Hemodialisa/i.test(S.title)?xa(i):/^Operasi/i.test(S.title)?Ea(i):/^Surat Kematian/i.test(S.title)?Ta(i):/^Permintaan Terapi/i.test(S.title)?ba(i):/^Uji Fungsi/i.test(S.title)?ka(i):/^Partograf/i.test(S.title)?Ca(i):/^Laporan Tindakan/i.test(S.title)?ha(i):/^Bon Makan/i.test(S.title)?Oa(i):/^PEMERIKSAAN$/i.test(S.title)?$a(i):`<section class="rm-page" id="${A.id}">
${H(A.code)}
<div class="rm-form-title">${t(S.title)}</div>
<div class="doc-body">${S.html}</div>
</section>`}).join(""),x=['<button type="button" class="tab-btn active" data-target="all">Semua</button>','<button type="button" class="tab-btn" data-target="rm-00">RM. 00 Kendali</button>',...Q.map((S,R)=>{let A=Y[R];return`<button type="button" class="tab-btn" data-target="${A.id}">${A.tab}</button>`})].join(""),E=['<option value="all">Semua Formulir RM</option>','<option value="rm-00">RM. 00 \u2014 Lembar Kendali &amp; Verifikasi</option>',...Q.map((S,R)=>{let A=Y[R];return`<option value="${A.id}">${A.option}</option>`})].join("");return`<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<base href="${t(location.origin)}">
<title>Formulir Rekam Medis Baku \u2014 Dossier Klaim BPJS ${t(mt)}</title>
<style>
    /* ==========================================================================
       1. RESET & AUTHENTIC INDONESIAN HOSPITAL RM FORM TOKENS
       Pure Monochrome Black Ink (#000000) on White Paper (#FFFFFF).
       Zero SaaS colors, zero rounded pills/badges, zero drop shadows.
       ========================================================================== */
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      line-height: 1.35;
      color: #000000;
      background-color: #E5E5E5;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    /* ==========================================================================
       2. SCREEN-ONLY VERIFIER TOOLBAR (.no-print)
       ========================================================================== */
    .verifier-toolbar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background-color: #FFFFFF;
      border-bottom: 2px solid #000000;
      padding: 8px 16px;
      font-family: Arial, Helvetica, sans-serif;
    }

    .toolbar-row {
      max-width: 210mm;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }

    .toolbar-group {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
    }

    .toolbar-label {
      font-size: 9pt;
      font-weight: bold;
      text-transform: uppercase;
    }

    .toolbar-select {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 8px;
      cursor: pointer;
    }

    .toolbar-counter {
      font-size: 8.5pt;
      border: 1px solid #000000;
      padding: 3px 8px;
      background-color: #FFFFFF;
    }

    .toolbar-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 10px;
      cursor: pointer;
    }

    .toolbar-btn:hover {
      background-color: #F0F0F0;
    }

    .toolbar-btn-print {
      background-color: #000000;
      color: #FFFFFF;
    }

    .toolbar-btn-print:hover {
      background-color: #222222;
    }

    .toolbar-tabs {
      max-width: 210mm;
      margin: 6px auto 0 auto;
      padding-top: 6px;
      border-top: 1px solid #000000;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .tab-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 7.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 2px 6px;
      cursor: pointer;
    }

    .tab-btn.active {
      background-color: #000000;
      color: #FFFFFF;
      font-weight: bold;
    }

    /* ==========================================================================
       3. A4 PAPER SHEET CONTAINER (NO DROP SHADOWS)
       ========================================================================== */
    .dossier-wrapper {
      max-width: 210mm;
      margin: 16px auto 40px auto;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .rm-page {
      width: 100%;
      background-color: #FFFFFF;
      border: 1px solid #888888;
      padding: 12mm 14mm;
    }

    .rm-page.hidden-section {
      display: none;
    }

    /* ==========================================================================
       4. OFFICIAL RSUD H. ABDUL MANAP KOP SURAT (TIMES NEW ROMAN + DOUBLE RULE)
       ========================================================================== */
    .rm-code-top {
      text-align: right;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 9pt;
      font-weight: bold;
      margin-bottom: 2px;
      letter-spacing: 0.02em;
    }

    .kop-surat {
      display: flex;
      align-items: center;
      gap: 12px;
      padding-bottom: 5px;
    }

    .kop-logo {
      width: 52px;
      height: 60px;
      flex-shrink: 0;
    }

    .kop-text {
      flex: 1;
      text-align: center;
      font-family: "Times New Roman", Times, serif;
      color: #000000;
      line-height: 1.2;
    }

    .kop-line-1 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-2 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-3 {
      font-size: 12.5pt;
      font-weight: bold;
      letter-spacing: 0.02em;
      margin-top: 1px;
    }

    .kop-line-4 {
      font-size: 7.5pt;
      font-weight: normal;
      margin-top: 2px;
    }

    .kop-line-5 {
      font-size: 7.5pt;
      font-weight: normal;
    }

    .kop-double-rule {
      border-top: 2px solid #000000;
      height: 2px;
      border-bottom: 0.75px solid #000000;
      margin-bottom: 10px;
    }

    .rm-form-title {
      text-align: center;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 11pt;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 8px;
      letter-spacing: 0.02em;
    }

    /* ==========================================================================
       5. PATIENT IDENTITY BLOCKS (PATTERN A: BORDERED BOX / PATTERN B: BORDERLESS)
       Strict vertical colon ':' alignment (label | 10px ':' | value)
       ========================================================================== */
    .id-box-bordered {
      border: 1px solid #000000;
      padding: 6px 10px;
      margin-bottom: 9px;
      display: flex;
      gap: 16px;
    }

    .id-box-borderless {
      padding: 2px 0;
      margin-bottom: 8px;
      display: flex;
      gap: 16px;
    }

    .id-col {
      flex: 1;
      min-width: 0;
    }

    .id-table {
      width: 100%;
      border-collapse: collapse;
    }

    .id-table td {
      padding: 1.5px 0;
      vertical-align: top;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
      line-height: 1.3;
    }

    .id-table td.lbl {
      width: 118px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.lbl-wide {
      width: 138px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.col {
      width: 10px;
      text-align: center;
    }

    .id-table td.val {
      text-align: left;
    }

    /* ==========================================================================
       6. FULL-GRID RM TABLES (border: 1px solid #000 ON ALL TH & TD)
       ========================================================================== */
    .rm-grid-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 8px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-grid-table th,
    .rm-grid-table td {
      border: 1px solid #000000;
      padding: 4px 6px;
      vertical-align: top;
      color: #000000;
    }

    .rm-grid-table th {
      font-size: 8.5pt;
      font-weight: bold;
      text-align: center;
      vertical-align: middle;
      background-color: #FFFFFF;
    }

    .rm-grid-table td.center,
    .rm-grid-table th.center {
      text-align: center;
      vertical-align: middle;
    }

    .rm-grid-table td.num,
    .rm-grid-table th.num {
      text-align: right;
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
    }

    .rm-grid-table td.nowrap {
      white-space: nowrap;
    }

    .rm-grid-table tr.section-banner td {
      font-weight: bold;
      font-size: 8.5pt;
      text-transform: uppercase;
      padding: 4px 6px;
    }

    .rm-grid-table tr.sub-group td {
      font-weight: bold;
      text-decoration: underline;
      padding-top: 5px;
      padding-bottom: 4px;
    }

    .rm-grid-table tr.total-row td {
      font-weight: bold;
      padding: 5px 6px;
    }

    /* Square 11px x 11px Interactive Verification Checkbox */
    .rm-checkbox {
      appearance: none;
      -webkit-appearance: none;
      width: 11px;
      height: 11px;
      border: 1px solid #000000;
      border-radius: 0;
      background-color: #FFFFFF;
      display: inline-grid;
      place-content: center;
      vertical-align: middle;
      cursor: pointer;
    }

    .rm-checkbox::before {
      content: "\u2713";
      font-size: 9px;
      font-weight: bold;
      line-height: 1;
      color: #000000;
      transform: scale(0);
    }

    .rm-checkbox:checked::before {
      transform: scale(1);
    }

    /* Static printed checkbox symbol for clinical forms */
    .static-box {
      display: inline-block;
      width: 10px;
      height: 10px;
      border: 1px solid #000000;
      text-align: center;
      line-height: 9px;
      font-size: 8px;
      font-weight: bold;
      margin-right: 4px;
      vertical-align: middle;
    }

    .sub-heading-rm {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 7px 0 4px 0;
    }

    .footnote-rm {
      font-size: 7.5pt;
      margin-top: 4px;
      line-height: 1.35;
    }

    /* ==========================================================================
       7. ATOMIC SIGNATURE FOOTER (break-inside: avoid)
       ========================================================================== */
    .rm-signature-block {
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 20px;
      break-inside: avoid;
      page-break-inside: avoid;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-sig-box {
      width: 44%;
      text-align: center;
    }

    .rm-sig-box.left-align {
      text-align: left;
    }

    .rm-sig-space {
      height: 44px;
    }

    .rm-sig-name {
      font-weight: bold;
    }

    .rm-sig-sub {
      font-size: 7.5pt;
    }

    /* ==========================================================================
       8. SECTION 04 \u2014 FILE UPLOAD ORIGINAL PASSTHROUGH (NOT REDESIGNED)
       ========================================================================== */
    .passthrough-separator {
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      padding: 4px 6px;
      margin-bottom: 10px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .raw-upload-frame {
      border: 1px solid #000000;
      padding: 8px 10px;
      margin-bottom: 12px;
      font-family: "Times New Roman", Times, serif;
      font-size: 8.5pt;
      break-inside: avoid;
    }

    .raw-upload-table {
      width: 100%;
      border-collapse: collapse;
      margin: 6px 0;
      font-size: 8pt;
    }

    .raw-upload-table th,
    .raw-upload-table td {
      border: 1px solid #000000;
      padding: 2px 4px;
    }

    /* ==========================================================================
       9. PRINT MEDIA RULES (@media print \u2014 A4 PORTRAIT, 12MM MARGIN)
       ========================================================================== */
    @media print {
      @page {
        size: A4 portrait;
        margin: 12mm;
      }

      body {
        background-color: #FFFFFF !important;
        margin: 0;
        padding: 0;
      }

      .no-print,
      .verifier-toolbar {
        display: none !important;
      }

      .dossier-wrapper {
        max-width: 100%;
        margin: 0;
        gap: 0;
      }

      .rm-page {
        border: none !important;
        padding: 0 !important;
        margin: 0 !important;
        break-after: page;
        page-break-after: always;
      }

      .rm-page:last-child {
        break-after: auto;
        page-break-after: auto;
      }

      .rm-page.hidden-section {
        display: none !important;
      }

      thead {
        display: table-header-group;
      }

      tr,
      .rm-signature-block,
      .id-box-bordered {
        break-inside: avoid;
        page-break-inside: avoid;
      }
    }

    @media (max-width: 720px) {
      .rm-page {
        padding: 12px;
      }
      .id-box-bordered,
      .id-box-borderless {
        flex-direction: column;
        gap: 4px;
      }
      .rm-signature-block {
        flex-direction: column;
        gap: 14px;
      }
      .rm-sig-box {
        width: 100%;
      }
    }

/* \u2500\u2500 Tambahan generator: komponen hasil scrape & fokus keyboard \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.kop-logo{object-fit:contain;object-position:center}
/* SEP BPJS \u2014 cetakan VClaim (sheet menggantikan kop RSUD) */
.rm-page.sep-page{padding:0}
.bpjs-sep-sheet{width:210mm;max-width:100%;margin:0 auto;padding:10mm 14mm;background:#fff;color:#000;font:9.5pt/1.38 Arial,Helvetica,sans-serif;box-sizing:border-box;break-inside:avoid;page-break-inside:avoid}
.sep-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;position:relative}
.sep-logo{flex:0 0 215px;width:215px;height:33px;object-fit:contain;object-position:left center}
.sep-title-wrap{flex:0 0 auto;text-align:right;padding-right:0}
.sep-title{font-size:10.5pt;font-weight:400;letter-spacing:.3px;text-transform:uppercase}
.sep-hospital{font-size:10.5pt;text-transform:uppercase}
.sep-columns{display:flex;justify-content:space-between;gap:18px}
.sep-col-left{flex:0 0 56%}
.sep-col-right{flex:0 0 42%;display:flex;flex-direction:column;justify-content:space-between}
.sep-kv-table{width:100%;border-collapse:collapse}
.sep-kv-table td{padding:1.8px 0;vertical-align:top;border:none}
.sep-kv-table td.lbl{width:102px;white-space:nowrap}
.sep-col-right .sep-kv-table td.lbl{width:92px}
.sep-kv-table td.sep{width:12px;text-align:center}
.sep-kv-table td.val{word-break:break-word}
.sep-no-value{font-size:9.5pt;letter-spacing:.2px}
.sep-inline-mr{margin-left:14px;white-space:nowrap}
.sep-multiline-list{margin:0;padding:0;list-style:none}
.sep-disclaimer{margin-top:10px;font-size:7.5pt;font-style:italic}
.sep-print-meta{font-size:9.5pt;font-style:normal}
/* Isi/body SEP seragam 9.5pt \u2014 kecuali disclaimer (7.5pt italic). */
.sep-signatures{display:flex;justify-content:flex-end;gap:16px;margin-top:18px}
.sep-sig-box{flex:0 0 44%;font-size:9.5pt;line-height:1.25;text-align:center}
.sep-sig-role{min-height:24px}
.sep-sig-name{margin-top:2px;font-weight:bold}
.sep-qr{display:block;margin:2px auto;width:100px;height:100px;object-fit:contain}
.rm-sig-qr{display:block;width:80px;height:80px;margin:0 auto 4px;object-fit:contain}
/* @page A4 portrait 12mm ditetapkan sekali di blok print utama \u2014 jangan
   ditimpa di sini supaya margin semua halaman dossier konsisten. */
@media print{body{background:#fff;padding:0}.bpjs-sep-sheet{width:100%;padding:0}}
@media screen{body{background:#e5e7eb;padding:20px}.bpjs-sep-sheet{box-shadow:0 1px 4px rgba(0,0,0,.15)}}
/* Telaah (RM.07) \u2014 grid 2 kolom ala telaahResepPrint.ts */
.t-main{display:grid;grid-template-columns:62% 38%;gap:8px;align-items:start}
.t-left,.t-right{display:flex;flex-direction:column;gap:5px;min-width:0}
.tm-card{padding:2px 0 4px;margin-bottom:4px;border-bottom:.5pt solid #333}
.tm-col{display:flex;flex-direction:column;gap:2px}
.tm-row{display:grid;grid-template-columns:30% 70%;column-gap:4px;align-items:start}
.tm-row.long{display:grid}
.tm-label{font-size:7.5pt;line-height:1.25;color:#333}
.tm-val{font-size:8pt;line-height:1.25;overflow-wrap:anywhere}
.t-meds{font-size:8pt;margin-bottom:6px}
.med{margin-bottom:3px;line-height:1.3}
.med-no{font-weight:400}
.med-name{font-weight:700}
.med-jml{font-weight:700;white-space:nowrap}
.t-lampiran th{font-size:7.5pt}
.rm-summary{margin:8px 0 10px;font-size:8.5pt}
.rm-sum-line{display:flex;align-items:baseline;gap:6px;padding:1px 0}
.rm-sum-line .rm-sum-dots{flex:1;border-bottom:1px dotted #000;transform:translateY(-3px)}
.rm-checkbox:focus-visible,.vbox:focus-visible,.toolbar-btn:focus-visible,.toolbar-select:focus-visible,.tab-btn:focus-visible{outline:2px solid #000000;outline-offset:2px}
.vbox{appearance:none;-webkit-appearance:none;width:11px;height:11px;margin:0;border:1px solid #000000;border-radius:0;background-color:#FFFFFF;display:inline-grid;place-content:center;vertical-align:middle;cursor:pointer}
.vbox::before{content:"\u2713";font-size:9px;font-weight:bold;line-height:1;color:#000000;transform:scale(0)}
.vbox:checked::before{transform:scale(1)}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 8px!important;font-size:8.2pt!important}
.doc-body th,.doc-body td{border:1px solid #000000!important;padding:3px 5px!important;vertical-align:top;color:#000000!important;overflow-wrap:anywhere}
.doc-body th{background-color:#FFFFFF!important;font-weight:bold;text-align:center}
.doc-body h1,.doc-body h2,.doc-body h3{font-size:9.5pt;margin:6px 0}
.doc-body p{margin:2px 0}
.doc-body label{min-width:100px;font-weight:600;color:#333333}
.doc-body .fv{font-weight:500}
.doc-body img{max-width:100%!important;height:auto!important}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important}
.doc-body .vcol{width:16px!important;text-align:center!important}
.telaah-layout{display:flex;gap:8px;align-items:stretch;margin:0 0 6px}
.telaah-layout table{flex:1;margin-bottom:0}
.img-wrap{display:inline-block;max-width:100%}
.img-tools{display:flex;gap:6px;justify-content:flex-end;margin:0 0 5px}
.img-tools button{font-family:inherit;font-size:10px;padding:3px 9px;border:1px solid #000000;background-color:#FFFFFF;cursor:pointer}
</style></head><body>
<style>
    /* IGD: gambar asal MORBIS (skala nyeri Wong Baker & gambar objektif)
       ikut tercetak, dirapikan sebagai figure + keterangan. */
    .rm-figure { margin: 0 0 8px; break-inside: avoid; text-align: center; }
    .rm-figure img { max-width: 100%; height: auto; border: 1px solid #000000; }
    .rm-figure figcaption { margin-top: 3px; font-size: 7pt; text-transform: uppercase; letter-spacing: 0.04em; }
    .rm-figure-row { display: flex; gap: 10px; align-items: flex-start; break-inside: avoid; }
    .rm-figure-row .rm-figure { flex: 0 0 46%; margin: 0; }
    .rm-figure-row .rm-grid-table { flex: 1; min-width: 0; }
    .rm-note { border: 1px solid #000000; padding: 6px 8px; margin-bottom: 8px; font-size: 8.2pt; line-height: 1.4; break-inside: avoid; }

    /* Bahasa visual RM baku: banner bagian bernomor, tabel full-grid, kotak
       centang statis \u2014 mengikuti prototipe referensi RM.02/IGD. */
    .rm-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-family: Arial, Helvetica, sans-serif; font-size: 8pt; line-height: 1.28; }
    .rm-table th, .rm-table td { border: 1px solid #000000; padding: 3px 5px; vertical-align: top; }
    .rm-table th { font-weight: bold; text-align: center; vertical-align: middle; }
    .rm-table tr.sec-hdr td { font-weight: bold; font-size: 8.5pt; text-transform: uppercase; padding: 4px 5px; letter-spacing: 0.01em; }
    .chk-box { display: inline-block; width: 9.5px; height: 9.5px; border: 1px solid #000000; text-align: center; line-height: 8.5px; font-size: 7.5pt; font-weight: bold; margin-right: 3px; vertical-align: middle; }
    .opt-item { display: inline-block; margin-right: 10px; white-space: nowrap; }
    .filter-note { font-size: 7.3pt; font-style: italic; }
    .two-col-grid { display: flex; gap: 6px; margin-bottom: 8px; align-items: stretch; }
    .two-col-grid > .col-half { flex: 1; min-width: 0; }
    .rm-top-meta { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px; font-size: 8.5pt; font-weight: bold; }
    .running-header-box { border: 1px solid #000000; padding: 4px 8px; margin-bottom: 6px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; font-size: 7.8pt; }

    /* Editorial clinical: nomor urut otomatis, kepala pasien, dan ringkasan
       data kritis \u2014 tetap tinta hitam di atas kertas A4. */
    #pengkajian-igd { counter-reset: igdsec; }
    #pengkajian-igd .sub-heading-rm {
      counter-increment: igdsec;
      position: relative;
      padding: 3px 0 3px 30px;
      border-bottom: 1px solid #000000;
    }
    #pengkajian-igd .sub-heading-rm::before {
      content: counter(igdsec, decimal-leading-zero);
      position: absolute;
      left: 0;
      top: 3px;
      font-size: 7pt;
      font-weight: normal;
      letter-spacing: 0.08em;
    }
    .igd-masthead { margin-bottom: 9px; }
    .igd-masthead-label { font-size: 7pt; letter-spacing: 0.14em; text-transform: uppercase; }
    .igd-masthead-name {
      font-size: 17pt;
      font-weight: bold;
      line-height: 1.15;
      margin: 2px 0 6px;
      letter-spacing: -0.02em;
    }
    .igd-summary {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1.4fr;
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      margin: 0 0 9px;
    }
    .igd-summary > div { padding: 5px 8px; border-left: 1px solid #000000; }
    .igd-summary > div:first-child { border-left: 0; padding-left: 0; }
    .igd-summary span { display: block; font-size: 6.5pt; letter-spacing: 0.1em; text-transform: uppercase; }
    .igd-summary b { display: block; font-size: 11pt; line-height: 1.25; margin-top: 2px; }
    .igd-band-value { font-size: 11pt !important; font-weight: bold; }

    /* Laporan Operasi (RM.20) \u2014 tabel label:nilai tanpa garis di dalam kotak,
       narasi pembedahan dipecah jadi langkah bernomor. */
    #form-operasi .op-kv { width: 100%; border-collapse: collapse; }
    #form-operasi .op-kv td { border: none; padding: 1.5px 0; vertical-align: top; font-size: 8.2pt; line-height: 1.3; }
    #form-operasi .op-kv td.k { width: 132px; white-space: nowrap; }
    #form-operasi .op-kv td.c { width: 10px; text-align: center; }
    #form-operasi .op-kv td.v { overflow-wrap: anywhere; }
    #form-operasi .op-narrative { padding: 6px 8px; line-height: 1.45; }
    #form-operasi .op-preface { margin-bottom: 5px; padding-bottom: 5px; border-bottom: 1px dashed #666666; }
    #form-operasi .op-steps { margin: 3px 0 0; padding-left: 18px; }
    #form-operasi .op-steps li { margin-bottom: 2px; }

    /* Laporan Anestesi (RM.21) \u2014 2 halaman A4, grafik terkunci, 3 TTE sejajar. */
    #form-anestesi .an-meta { display: flex; justify-content: space-between; font-size: 8pt; font-weight: bold; margin-bottom: 2px; }
    #form-anestesi .an-subtitle { text-align: center; font-size: 8.5pt; letter-spacing: 0.08em; margin: -4px 0 6px; }
    #form-anestesi .an-kv { width: 100%; border-collapse: collapse; }
    #form-anestesi .an-kv td { border: none; padding: 1.5px 0; vertical-align: top; font-size: 8.2pt; line-height: 1.3; }
    #form-anestesi .an-kv td.k { width: 112px; white-space: nowrap; }
    #form-anestesi .an-kv td.c { width: 10px; text-align: center; }
    #form-anestesi .an-kv td.v { overflow-wrap: anywhere; }
    #form-anestesi .an-grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 2px 6px; font-size: 8pt; }
    #form-anestesi .an-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px 8px; font-size: 7.8pt; margin-top: 2px; }
    #form-anestesi .an-risk { margin-top: 4px; padding-top: 4px; border-top: 1px dashed #666666; }
    #form-anestesi .chart-frame { padding: 4px; text-align: center; border: 1px solid #000000; break-inside: avoid; page-break-inside: avoid; }
    #form-anestesi .chart-frame img { max-width: 100%; height: auto; }
    #form-anestesi .an-page-break { page-break-before: always; break-before: page; }
    #form-anestesi .an-running { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; border-bottom: 1.5px solid #000000; padding-bottom: 4px; margin: 0 0 7px; font-size: 8pt; }
    #form-anestesi .an-instruksi { margin: 0; padding-left: 18px; line-height: 1.4; font-size: 8.2pt; }
    #form-anestesi .an-tte-note { font-size: 7.6pt; margin-top: 4px; }
    #form-anestesi .an-tte { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 8px; break-inside: avoid; page-break-inside: avoid; }
    #form-anestesi .an-tte .tte-box { border: 1px solid #000000; padding: 5px 4px; text-align: center; font-size: 8pt; }
    #form-anestesi .an-tte .tte-qr { width: 54px; height: 54px; margin: 4px auto; border: 1px solid #000000; padding: 2px; display: flex; align-items: center; justify-content: center; }
    #form-anestesi .an-tte .tte-name { font-weight: bold; text-decoration: underline; }
</style>
<header class="verifier-toolbar no-print"><div class="toolbar-row">
<div class="toolbar-group"><span class="toolbar-label">Formulir RM Klaim BPJS:</span><select id="rmSectionSelect" class="toolbar-select" aria-label="Pilih Formulir RM">${E}</select></div>
<div class="toolbar-group"><span class="toolbar-counter">Tanda Verifikator (&#10003;): <strong id="checkCounter">0 / 0</strong></span>
<button type="button" class="toolbar-btn" id="btnCheckAll">Centang Semua</button>
<button type="button" class="toolbar-btn" id="btnResetChecks">Reset</button>
<button type="button" class="toolbar-btn toolbar-btn-print" id="btnPrintPdf">Cetak / Simpan PDF (A4)</button></div>
</div><nav id="rmTabs" class="toolbar-tabs" aria-label="Navigasi Formulir RM">${x}</nav></header>
<main class="dossier-wrapper">${K}${P}</main>
</body></html>`}async function Ua(){let i=a=>{let e=getComputedStyle(a);return e.display!=="none"&&e.visibility!=="hidden"&&Number(e.opacity)>0},L=Date.now()+3e3;for(;Date.now()<L&&[".swal2-container",".swal-overlay--active",".sweet-alert"].flatMap(a=>Array.from(document.querySelectorAll(a))).some(i);)await new Promise(a=>window.setTimeout(a,150));await new Promise(a=>window.setTimeout(a,50))}function Ra(i){let L=window.open("","_blank");if(!L)return!1;try{return L.document.open(),L.document.write(i),L.document.close(),Kt(L),!0}catch{return!1}}async function Ut(){let i=document.getElementById("ext-mklaim-print-btn"),L=i?.textContent||"Cetak Rapi M-KLAIM";i&&(i.disabled=!0,i.textContent="Memproses\u2026",i.style.opacity="0.7");try{await Ua();let{sections:a,inventory:e}=Ct();if(a.length<3&&(await new Promise(l=>window.setTimeout(l,800)),{sections:a,inventory:e}=Ct()),!a.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let n=Pa(a,e);if(Ra(n))return;let r;for(let l of[0,300,600]){l&&await new Promise(o=>window.setTimeout(o,l));try{if(!(await chrome.runtime.sendMessage({type:"OPEN_PRINT_DOSSIER",html:n}))?.success)throw new Error("background menolak membuka tab");return}catch(o){r=o;let y=o instanceof Error?o.message:String(o);if(!/Receiving end does not exist|Extension context invalidated/i.test(y))break}}let s=r instanceof Error?r.message:String(r||"");chrome.runtime?.id?window.alert(`Gagal membuka dossier: ${s||"tidak diketahui"}. Refresh halaman M-KLAIM (Ctrl+Shift+R) lalu coba lagi.`):window.alert("Ekstensi diperbarui, refresh halaman M-KLAIM (Ctrl+Shift+R) lalu klik lagi Cetak Rapi.")}finally{i&&(i.disabled=!1,i.textContent=L,i.style.opacity="1")}}function Ya(){let i=Array.from(document.querySelectorAll("button.btn-success")).find(L=>/^printDiv\s*\(/i.test(L.getAttribute("onclick")||""));return i?.parentElement?i.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(L=>L.querySelector("button"))||document.getElementById("SCETAK")||document.body}var Et="v2";function Rt(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor"))return;let i=document.getElementById("ext-mklaim-print-btn");if(i?.dataset.extBuild===Et)return;i?.remove();let L=Ya(),a=document.createElement("button");a.id="ext-mklaim-print-btn",a.dataset.extBuild=Et,a.type="button",a.className="btn btn-primary btn-sm",a.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",a.textContent="Cetak Rapi M-KLAIM",a.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),Ut()}),L.appendChild(a)}window.extMklaimPrintNow=Ut,typeof bt.featureModules<"u"&&(bt.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let i=()=>Rt();document.readyState==="complete"?window.setTimeout(i,500):window.addEventListener("load",()=>window.setTimeout(i,500));let L=()=>{let a=document.getElementById("ext-mklaim-print-btn");if(a?.dataset.extBuild!==Et){Rt();return}a.parentElement&&a.parentElement.lastElementChild!==a&&a.parentElement.appendChild(a)};new MutationObserver(()=>L()).observe(document.body,{childList:!0,subtree:!0}),window.setInterval(L,1500)}})})();
