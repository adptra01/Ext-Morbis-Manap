"use strict";var __morbis_feature=(()=>{var A=Object.defineProperty,X=Object.getOwnPropertyDescriptor,F=Object.getOwnPropertyNames,Y=Object.prototype.hasOwnProperty,W=(e,t)=>{for(var a in t)A(e,a,{get:t[a],enumerable:!0})},Z=(e,t,a,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let n of F(t))!Y.call(e,n)&&n!==a&&A(e,n,{get:()=>t[n],enumerable:!(r=X(t,n))||r.enumerable});return e},ee=e=>Z(A({},"__esModule",{value:!0}),e),j={};W(j,{applySelectAll:()=>N,clearSelection:()=>k,getSelected:()=>J,initMKlaimBulkVerifFeature:()=>Q,isEligible:()=>V,parseIdVisit:()=>re,pruneSelection:()=>_});function te(){return window}var q="ext-batch-shared-style";function z(){if(document.getElementById(q))return;let e=document.createElement("style");e.id=q,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function ae(e,t,a=2){let r=n=>fetch(e,t).catch(i=>{if(n<=0)throw i;return new Promise(l=>setTimeout(l,1e3*(3-n))).then(()=>r(n-1))});return r(a)}function B(e){return new Promise(t=>{z();let a=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",r=document.createElement("div");r.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",r.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${a}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,r.querySelector("h3").textContent=e.title;let n=r.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((d,c)=>{c>0&&n.appendChild(document.createElement("br")),n.appendChild(document.createTextNode(d))});let i=d=>{r.remove(),document.removeEventListener("keydown",l),t(d)},l=d=>{d.key==="Escape"&&i(!1)};r.querySelector(".ext-modal-close").addEventListener("click",()=>i(!1)),r.addEventListener("click",d=>{d.target===r&&i(!1)}),r.querySelector("[data-ext-ok]").addEventListener("click",()=>i(!0));let s=r.querySelector("[data-ext-cancel]");s&&s.addEventListener("click",()=>i(!1)),document.addEventListener("keydown",l),document.body.appendChild(r)})}var P=te(),o={endpointVerif:"/v2/m-klaim/control/verif",endpointBatal:"/v2/m-klaim/control/batal-verif",delayMs:600,barId:"ext-bulk-verif-bar",cssId:"ext-bulk-verif-style",readyTimeoutMs:15e3,readyPollMs:250,warnIfMoreThan:100,UJI_SAJA:!1},f=[{sel:"#data-table",kind:"main",nama:"Klaim",aksi:"Verif",endpoint:o.endpointVerif,danger:!1},{sel:"#data-table-verif",kind:"verif",nama:"Sudah Terverifikasi",aksi:"Batal Verif",endpoint:o.endpointBatal,danger:!0}],b={main:new Set,verif:new Set},p=!1;function N(e,t,a){let r=0;return t.forEach(n=>{!n.id||!n.eligible||(a?b[e].add(n.id):b[e].delete(n.id),r+=1)}),r}function _(e,t){let a=new Set;t.forEach(n=>{n.id&&n.eligible&&a.add(n.id)});let r=0;return Array.from(b[e]).forEach(n=>{a.has(n)||(b[e].delete(n),r+=1)}),r}function J(e){return Array.from(b[e])}function k(e){b[e].clear()}function re(e){let t=e.match(/\d+/);return t?t[0]:null}function V(e,t,a){return t?e==="main"?!0:a:!1}function ne(){if(document.getElementById(o.cssId))return;let e=document.createElement("style");e.id=o.cssId,e.textContent=`
    #${o.barId} {
      position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
      z-index: 2147482000; display: none; align-items: center; gap: 14px;
      background: #0f172a; color: #f8fafc; border-radius: 12px;
      padding: 10px 16px; font-family: 'Inter', system-ui, sans-serif;
      font-size: 13px; box-shadow: 0 8px 28px rgba(15,23,42,.35);
    }
    #${o.barId} .bv-item { display: flex; align-items: center; gap: 8px; }
    #${o.barId} .bv-label { color: #cbd5e1; }
    #${o.barId} .bv-count { color: #f8fafc; font-weight: 700; }
    #${o.barId} button {
      border: none; border-radius: 8px; cursor: pointer; padding: 7px 14px;
      font-size: 12.5px; font-weight: 700; font-family: inherit;
    }
    #${o.barId} .bv-aksi { background: #2563eb; color: #fff; }
    #${o.barId} .bv-aksi:hover { background: #1d4ed8; }
    #${o.barId} .bv-aksi-danger { background: #dc2626; color: #fff; }
    #${o.barId} .bv-aksi-danger:hover { background: #b91c1c; }
    #${o.barId} .bv-reset { background: #334155; color: #e2e8f0; }
    #${o.barId} .bv-reset:hover { background: #475569; }
    #${o.barId} button:disabled { opacity: .55; cursor: not-allowed; }

    /* Status + progress saat proses massal berjalan */
    #${o.barId} .bv-status { color: #f8fafc; font-weight: 700; min-width: 150px; }
    #${o.barId} .bv-progress {
      position: relative; width: 220px; height: 9px; border-radius: 999px;
      background: #1e293b; overflow: hidden; flex: 0 0 auto;
    }
    #${o.barId} .bv-progress > i {
      position: absolute; top: 0; left: 0; bottom: 0; width: 0%;
      border-radius: 999px; background: linear-gradient(90deg, #2563eb, #38bdf8);
      transition: width .25s ease;
    }
    #${o.barId} .bv-progress.done > i {
      background: linear-gradient(90deg, #16a34a, #4ade80);
    }

    .bv-check {
      display: inline-flex; align-items: center; justify-content: center;
      margin-right: 6px; vertical-align: middle; cursor: pointer;
    }
    /* Kolom khusus checkbox: <th> sendiri di posisi 0 + <td> sejajar di tiap
       baris. <th> HANYA ditambahkan setelah DataTables aktif (lihat
       renderHeaderCheckbox) supaya jumlah kolom yang dibaca saat init tetap
       16 dan pemetaan data ajax tidak bergeser. */
    th.bv-sel-th {
      width: 30px; min-width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
      /* Kolom terkunci (freeze pane): tetap terlihat saat tabel digeser
         horizontal (kontainer scroll: .main overflow-x auto di halaman). */
      position: -webkit-sticky; position: sticky; left: 0; z-index: 11;
      box-shadow: 2px 0 3px rgba(15, 23, 42, .10);
    }
    th.bv-sel-th input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    th.bv-sel-th input:disabled { cursor: not-allowed; }
    td.bv-sel {
      width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
      position: -webkit-sticky; position: sticky; left: 0; z-index: 9;
    }
    .table-hover tbody tr:hover > td.bv-sel,
    tbody tr:hover > td.bv-sel { background: #eef2f7; }
    td.bv-sel input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    td.bv-sel input:disabled { cursor: not-allowed; }
    /* Penanda fitur aktif - memudahkan diagnosis di console */
    html[data-ext-bulk-verif='1'] td.bv-sel { background: #eff6ff; }
  `,document.head.appendChild(e),z()}function u(e){return document.querySelector(e.sel)}function O(e){let t=window.jQuery;if(!t)return null;try{return t(e.sel).DataTable()??null}catch{return null}}function U(e){return(Array.isArray(e)?e:[e]).filter(t=>t instanceof HTMLElement)}function C(e){let t=e.querySelector('[onclick*="detail("]');if(t){let r=(t.getAttribute("onclick")||"").match(/\d+/);if(r)return r[0]}let a=e.querySelector('[onclick*="BatalVerif("]');if(a){let r=(a.getAttribute("onclick")||"").match(/\d+/);if(r)return r[0]}return null}function M(e,t){return V(e.kind,!!t.querySelector('button[onclick*="detail("]'),!!t.querySelector('button[onclick*="BatalVerif("]'))}function H(e,t){return{id:C(t),eligible:M(e,t)}}function K(e){let t=u(e);if(!t)return[];let a=O(e);if(a)try{return U(a.rows({search:"applied"}).nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(r=>!r.classList.contains("dataTables_empty"))}function ie(e){let t=u(e);if(!t)return[];let a=O(e);if(a)try{return U(a.rows().nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(r=>!r.classList.contains("dataTables_empty"))}function oe(e,t){let a=C(t);if(!a){let l=document.createElement("td");l.className="bv-sel",l.dataset.extBvUnid="1";let s=document.createElement("input");s.type="checkbox",s.disabled=!0,s.title="id_visit tidak terbaca dari markup baris ini",l.appendChild(s),t.insertBefore(l,t.firstChild);return}let r=M(e,t),n=document.createElement("td");n.className="bv-sel";let i=document.createElement("input");i.type="checkbox",i.dataset.extBvId=a,i.checked=b[e.kind].has(a),o.UJI_SAJA?(i.disabled=!0,i.title="Mode uji - belum bisa dipilih"):(i.disabled=p||!r,i.title=p?"Sedang diproses...":r?"Pilih baris ini":"Baris tidak memenuhi syarat aksi ini",i.addEventListener("change",()=>{i.checked?b[e.kind].add(a):b[e.kind].delete(a),v(),m(e)})),n.appendChild(i),t.insertBefore(n,t.firstChild)}function le(e){e.querySelectorAll("tbody td.bv-sel").forEach(t=>t.remove())}function D(e){let t=u(e);t&&(le(t),t.querySelectorAll("tbody tr").forEach(a=>oe(e,a)),m(e))}function m(e){let t=u(e)?.querySelector("thead input[data-ext-bv-header]");if(!t)return;let a=K(e).filter(i=>M(e,i)),r=a.length,n=a.filter(i=>{let l=C(i);return!!l&&b[e.kind].has(l)}).length;t.disabled=o.UJI_SAJA||p||r===0,t.checked=r>0&&n===r,t.indeterminate=n>0&&n<r}function de(e){if(!e)return!1;try{if(window.jQuery?.fn?.DataTable?.isDataTable?.(e))return!0}catch{}return e.classList.contains("dataTable")}function G(e){let t=u(e);if(!de(t))return;let a=t?.querySelector("thead tr");if(!a)return;if(a.querySelector('th[data-ext-bv-header="1"]')){m(e);return}let r=document.createElement("th");r.className="bv-sel-th",r.dataset.extBvHeader="1",r.title="Pilih / batal pilih semua baris yang cocok dengan pencarian";let n=document.createElement("input");n.type="checkbox",n.dataset.extBvHeader="1",n.disabled=!0,o.UJI_SAJA?n.title="Mode uji - belum bisa dipilih":(n.title="Pilih semua hasil pencarian",n.addEventListener("change",()=>{let i=K(e).map(l=>H(e,l));N(e.kind,i,n.checked),D(e),v()})),r.appendChild(n),a.insertBefore(r,a.firstChild),o.UJI_SAJA?n.disabled=!0:m(e)}function L(){f.forEach($),v()}function y(){return document.getElementById(o.barId)}function T(e,t,a,r,n,i=!1){let l=y();if(!l)return;let s=a>0?Math.min(100,Math.round(t/a*100)):0;l.innerHTML="";let d=document.createElement("div");d.className="bv-item";let c=document.createElement("span");c.className="bv-status",c.textContent=i?`Selesai - ${e.nama}`:`${e.nama}: ${t}/${a}`;let x=document.createElement("div");x.className=i?"bv-progress done":"bv-progress";let S=document.createElement("i");S.style.width=`${s}%`,x.appendChild(S);let I=document.createElement("span");I.className="bv-label",i?I.textContent=n>0?`OK ${r} \xB7 Gagal ${n}`:`OK ${r} dari ${a}`:I.textContent=n>0?`OK ${r} \xB7 Gagal ${n}`:`OK ${r}`,d.append(c,x,I),l.appendChild(d),l.style.display="flex"}function v(){let e=y();if(!e)return;let t=f.map(r=>[r,b[r.kind].size]).filter(([,r])=>r>0);if(o.UJI_SAJA||t.length===0){e.style.display="none";return}if(p)return;e.innerHTML="",t.forEach(([r,n])=>{let i=document.createElement("div");i.className="bv-item";let l=document.createElement("span");l.className="bv-label",l.textContent=`${r.nama}: `;let s=document.createElement("span");s.className="bv-count",s.textContent=`${n} dipilih`;let d=document.createElement("button");d.className=r.danger?"bv-aksi bv-aksi-danger":"bv-aksi",d.textContent=r.aksi,d.addEventListener("click",()=>{be(r)}),i.append(l,s,d),e.appendChild(i)});let a=document.createElement("button");a.className="bv-reset",a.textContent="Batal Pilih",a.addEventListener("click",()=>{f.forEach(r=>k(r.kind)),L()}),e.appendChild(a),e.style.display="flex"}function se(){if(y())return;let e=document.createElement("div");e.id=o.barId,e.style.display="none",document.body.appendChild(e)}async function ce(e,t){try{let a=new URLSearchParams({id_visit:t}),r=await ae(e,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:a.toString(),credentials:"same-origin"});if(!r.ok)return{id:t,ok:!1,pesan:`HTTP ${r.status}`};let n=await r.json(),i=String(n.kode)==="200";return{id:t,ok:i,pesan:n.message??(i?"Sukses":"Gagal")}}catch(a){return{id:t,ok:!1,pesan:a.message||"Gagal koneksi"}}}function ue(e){let t=ie(e).map(r=>H(e,r)),a=_(e.kind,t);return{valid:J(e.kind),gugur:a}}async function be(e){if(p)return;let{valid:t,gugur:a}=ue(e);if(t.length===0){k(e.kind),L(),await B({title:"Tidak ada baris yang bisa diproses",message:"Pilihan tidak lagi cocok dengan data di tabel. Silakan pilih ulang.",okLabel:"Mengerti",hideCancel:!0});return}let r=Math.ceil(t.length*o.delayMs/1e3),n=[`${e.nama}: ${t.length} baris akan diproses.`];if(a>0&&n.push(`${a} pilihan diabaikan (data berubah/tidak memenuhi syarat).`),n.push(e.danger?"Verifikasi yang dibatalkan kembali ke daftar belum terverifikasi.":"Data yang tidak memenuhi syarat akan ditolak server."),t.length>o.warnIfMoreThan&&n.push(`PERINGATAN: jumlah besar, proses \xB1${r} detik. Jangan tutup halaman.`),n.push("Lanjutkan?"),!await B({title:`${e.aksi} ${t.length} data?`,message:n.join(`
`),variant:e.danger?"danger":"primary",okLabel:`Ya, ${e.aksi}`,cancelLabel:"Batal"}))return;p=!0,f.forEach(c=>m(c)),T(e,0,t.length,0,0);let i=[],l=0;for(let c=0;c<t.length;c+=1){let x=await ce(e.endpoint,t[c]);x.ok?l+=1:i.push(x),T(e,c+1,t.length,l,i.length),c<t.length-1&&await new Promise(S=>setTimeout(S,o.delayMs))}p=!1,k(e.kind),T(e,t.length,t.length,l,i.length,!0),await new Promise(c=>setTimeout(c,700));let s=[`${e.aksi} selesai.`,`Berhasil: ${l} dari ${t.length}`];i.length>0&&(s.push("",`Gagal: ${i.length}`),i.slice(0,10).forEach(c=>s.push(`#${c.id} - ${c.pesan}`)),i.length>10&&s.push(`... dan ${i.length-10} lainnya`));let d=y();d&&(d.style.display="none"),await B({title:"Hasil",message:s.join(`
`),okLabel:"Muat ulang tabel",hideCancel:!0}),window.location.reload()}function fe(){return new Promise(e=>{let t=Date.now(),a=()=>{if(f.some(r=>u(r))||Date.now()-t>o.readyTimeoutMs){e();return}setTimeout(a,o.readyPollMs)};a()})}var h=!1,w=[],E=new Map;function pe(){w.forEach(e=>e.disconnect()),w.length=0,E.clear()}function g(e){if(!h){h=!0;try{G(e),D(e),v()}finally{h=!1}}}function R(e){let t=e.querySelectorAll("tbody tr").length;return t===0||e.querySelectorAll("tbody td.bv-sel").length===t}function he(e,t){let a=new MutationObserver(()=>{if(h)return;let n=u(e);if(n){if(n!==t){$(e);return}R(n)||g(e)}});a.observe(t,{childList:!0,subtree:!0}),w.push(a);let r=t.parentElement;if(r){let n=new MutationObserver(()=>{let i=u(e);i&&i!==t&&$(e)});n.observe(r,{childList:!0}),w.push(n)}}function $(e){let t=u(e);if(t){if(G(e),E.get(e.sel)===t){g(e);return}E.set(e.sel,t),g(e),he(e,t)}}function xe(){setInterval(()=>{h||f.forEach(e=>{let t=E.get(e.sel),a=u(e);a&&(!t||!document.contains(t)||a!==t)?$(e):(a&&!R(a)||a&&!a.querySelector('thead th[data-ext-bv-header="1"]'))&&g(e)})},Math.max(1e3,o.readyPollMs*4))}function me(){let e=window.jQuery;e&&f.forEach(t=>{let a=u(t);if(!(!a||a.dataset.extBvBound==="1")){a.dataset.extBvBound="1";try{e(t.sel).off("draw.dt.extBv").on("draw.dt.extBv",()=>{p||h||g(t)})}catch{}}})}function Q(){try{ne(),fe().then(()=>{pe(),se(),L(),me(),xe(),document.documentElement.setAttribute("data-ext-bulk-verif","1");let e=f.map(t=>{let a=u(t),r=a?a.querySelectorAll("tbody tr:not(.dataTables_empty)").length:0,n=a?a.querySelectorAll("tbody td.bv-sel").length:0,i=a?a.querySelectorAll("tbody td.bv-sel[data-ext-bv-unid]").length:0,l=a?!!a.querySelector('thead th[data-ext-bv-header="1"]'):!1;return`${t.sel}: kolom=${n}/${r}${i?` (${i} tanpa id)`:""} ${l?"header=ok":"header=BELUM"}`});console.log("[BulkVerif] Init complete -",e.join(" | "),o.UJI_SAJA?"(MODE UJI: checkbox nonaktif)":"")})}catch(e){console.error("[BulkVerif] Init error:",e)}}return typeof P.featureModules<"u"&&(P.featureModules.mKlaimBulkVerif={id:"mKlaimBulkVerif",name:"Bulk Verif / Batal Verif",description:"Verifikasi atau batalkan verifikasi banyak klaim sekaligus",match:{regex:/^\/v2\/m-klaim\/?$/},run:Q}),ee(j)})();
