"use strict";var __morbis_feature=(()=>{function H(){return window}var d={background:"#ffffff",foreground:"#0a0a0e",card:"#ffffff",cardForeground:"#0a0a0e",primary:"#2469f0",primaryForeground:"#f8fafc",primaryHover:"#1d58cc",secondary:"#f1f5f9",secondaryForeground:"#1e293b",muted:"#f1f5f9",mutedForeground:"#64748b",accent:"#f1f5f9",accentForeground:"#1e293b",destructive:"#ef4444",destructiveForeground:"#f8fafc",border:"#e2e8f0",input:"#e2e8f0",ring:"#2469f0",success:"#1b8a4b",successBg:"#eaf6ef",warning:"#c47a1a",warningBg:"#fef4e4",error:"#ef4444",errorBg:"#fef2f2",info:"#2469f0",infoBg:"#eef3ff"},B=new Set;function F(t,e){if(B.has(t)){let a=document.getElementById(t);if(a)return a}let r=document.createElement("style");return r.id=t,r.textContent=e,document.head.appendChild(r),B.add(t),r}F("ext-shared-animations",`
  @keyframes fadeSlideIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
`);var I=H(),J="ext-cppt-search-style",U="ext-cppt-no-results";function Y(){let t=window.location.pathname;return/\/admisi\/pelaksanaan_pelayanan\/cppt\/?$/.test(t)?"rajal":/\/admisi\/detail-rawat-inap\/cppt\/?$/.test(t)?"ranap":null}function K(t){if(t.id==="history_cppt")return!0;let e=t.querySelector("tr");if(e){let r=Array.from(e.querySelectorAll("th, td")).map(a=>a.textContent?.trim().toLowerCase()||"");if(["waktu","penginput","subyektif","obyektif","assessment","instruksi"].filter(a=>r.some(n=>n.includes(a))).length>=2)return!0}return!!t.textContent?.toLowerCase().includes("cppt")}function _(){return Array.from(document.querySelectorAll("table")).filter(K)}function q(t){let e=t.querySelector("thead tr")||t.querySelector("tr");return e?Array.from(e.querySelectorAll("th, td")).map(r=>r.textContent?.trim()||"").filter(r=>r.length>0):[]}function b(t,...e){for(let r of e){let a=t.findIndex(n=>n.toLowerCase().includes(r));if(a!==-1)return a}return-1}function G(){F(J,`
    .ext-cppt-filter-bar {
      display: flex; flex-wrap: wrap; align-items: center; gap: 10px;
      padding: 12px 16px; margin: 10px 0;
      background: ${d.muted};
      border: 1px solid ${d.border}; border-radius: 8px;
    }
    .ext-cppt-filter-bar .ext-cppt-label {
      font-weight: 600; font-size: 13px; color: ${d.foreground}; margin-right: 4px;
    }
    .ext-cppt-filter-bar input, .ext-cppt-filter-bar select {
      padding: 6px 10px; border: 1px solid ${d.input}; border-radius: 5px;
      font-size: 13px; background: ${d.background}; color: ${d.foreground};
      outline: none; transition: border-color 0.15s;
      min-width: 0;
    }
    .ext-cppt-filter-bar input:focus, .ext-cppt-filter-bar select:focus {
      border-color: ${d.primary}; box-shadow: 0 0 0 2px ${d.primary}26;
    }
    .ext-cppt-filter-bar input.ext-cppt-search-input { flex: 1 1 180px; min-width: 140px; }
    .ext-cppt-filter-bar select.ext-cppt-dokter-select { flex: 0 1 160px; }
    .ext-cppt-filter-bar input.ext-cppt-date-input { flex: 0 1 130px; }
    .ext-cppt-filter-bar .ext-cppt-btn {
      padding: 6px 14px; border: none; border-radius: 5px;
      cursor: pointer; font-size: 12px; font-weight: 600;
      transition: all 0.15s; white-space: nowrap;
    }
    .ext-cppt-filter-bar .ext-cppt-btn-clear { background: ${d.error}; color: white; }
    .ext-cppt-filter-bar .ext-cppt-btn-clear:hover { background: #dc2626; }
    .ext-cppt-no-results {
      padding: 30px 20px; text-align: center;
      color: ${d.mutedForeground}; font-size: 14px; font-weight: 500;
      background: #fafafa; border: 1px dashed ${d.border};
      border-radius: 8px; margin: 10px 0;
    }
    .ext-cppt-table-wrapper {
      display: block !important; width: 100% !important;
      max-width: 100% !important; clear: both !important;
      float: none !important; flex: 0 0 100% !important;
      box-sizing: border-box !important; break-inside: avoid !important;
      page-break-inside: avoid !important;
    }
    .ext-cppt-filtered-row { display: none !important; }
  `)}function h(t){return Array.from(t.querySelectorAll("tr")).filter(e=>e.querySelector("td"))}function Q(t,e){let r=new Set;for(let a of t){let n=a.querySelectorAll("td")[e]?.textContent?.trim();n&&n.length>0&&r.add(n)}return Array.from(r).sort()}function V(t){let e=t.match(/(\d{2})\/(\d{2})\/(\d{4})/);return e?e[3]+"-"+e[2]+"-"+e[1]:t}function N(t){return"ext_cppt_filter_"+t}function M(t){return"cppt"+t+"_"}function W(t){try{let e=sessionStorage.getItem(N(t));if(e)return JSON.parse(e)}catch{}return{search:"",dokter:"",tanggalAwal:"",tanggalAkhir:""}}function L(t,e){try{sessionStorage.setItem(N(e),JSON.stringify(t))}catch{}}function X(t){let e=new URLSearchParams(window.location.search),r=M(t);return{search:e.get(r+"search")||"",dokter:e.get(r+"dokter")||"",tanggalAwal:e.get(r+"tgl_awal")||"",tanggalAkhir:e.get(r+"tgl_akhir")||""}}function z(t,e){let r=new URL(window.location.href),a=r.searchParams,n=M(e),l=(i,o)=>{o?a.set(i,o):a.delete(i)};l(n+"search",t.search),l(n+"dokter",t.dokter),l(n+"tgl_awal",t.tanggalAwal),l(n+"tgl_akhir",t.tanggalAkhir);let p=r.pathname+"?"+a.toString();p!==window.location.pathname+"?"+window.location.search.slice(1)&&window.history.replaceState(null,"",p)}function w(t,e,r,a,n){let l=0;for(let p of e){let i=p.querySelectorAll("td");if(i.length===0){l++;continue}let o=!0,s=i[r]?.textContent?.trim()||"",x=V(s.toLowerCase()),y=i[a]?.textContent?.trim().toLowerCase()||"",k=Array.from(i).map(f=>f.textContent?.trim().toLowerCase()||"").join(" ");if(t.search){let f=t.search.toLowerCase();k.includes(f)||(o=!1)}o&&t.dokter&&y!==t.dokter.toLowerCase()&&(o=!1),o&&t.tanggalAwal&&x<t.tanggalAwal&&(o=!1),o&&t.tanggalAkhir&&x>t.tanggalAkhir&&(o=!1),p.classList.toggle("ext-cppt-filtered-row",!o),o&&l++}n&&(n.style.display=l===0&&e.length>0?"block":"none")}function O(t,e){let r="ext-cppt-filter-"+e;if(t.parentElement?.classList.contains("ext-cppt-table-wrapper"))return;let a=document.getElementById(r);if(a){let c=a.closest(".ext-cppt-table-wrapper");c&&c.remove()}let n=document.getElementById("ext-cppt-nores-"+e);n&&n.remove();let l=q(t),p=b(l,"waktu","masuk","tanggal"),i=b(l,"penginput","dokter","pembuat");if(i===-1&&p===-1)return;let o=document.createElement("div");o.id=r,o.className="ext-cppt-filter-bar";let s=X(e);L(s,e);let x="ext-cppt-search-"+e,y="ext-cppt-dokter-"+e,k="ext-cppt-tgl-awal-"+e,f="ext-cppt-tgl-akhir-"+e,j="ext-cppt-clear-"+e,ee="ext-cppt-nores-"+e;o.innerHTML=`
    <span class="ext-cppt-label">Cari:</span>
    <input type="text" id="${x}" class="ext-cppt-search-input"
      placeholder="Cari..." value="${P(s.search)}">

    <span class="ext-cppt-label">Penginput:</span>
    <select id="${y}" class="ext-cppt-dokter-select">
      <option value="">Semua Dokter</option>
    </select>

    <span class="ext-cppt-label">Dari:</span>
    <input type="date" id="${k}" class="ext-cppt-date-input"
      value="${P(s.tanggalAwal)}">

    <span class="ext-cppt-label">S/d:</span>
    <input type="date" id="${f}" class="ext-cppt-date-input"
      value="${P(s.tanggalAkhir)}">

    <button class="ext-cppt-btn ext-cppt-btn-clear" id="${j}">Reset</button>
  `;let $=t.parentNode,te=$?getComputedStyle($).display:"unknown";console.log("[CPPT Filter] Table #"+e+" parent display:",te);let g=document.createElement("div");g.className="ext-cppt-table-wrapper",g.style.cssText="display:block !important;width:100% !important;clear:both;flex:0 0 100%;box-sizing:border-box",$?.insertBefore(g,t),g.appendChild(o),g.appendChild(t);let u=document.createElement("div");u.id=ee,u.className=U,u.textContent="Tidak ada data yang sesuai dengan filter.",u.style.display="none",g.appendChild(u),console.log("[CPPT Filter] Injected filter #"+e+" before table:",t.id||"(no id)");let m=document.getElementById(y),R=h(t);if(i!==-1&&m){let c=Q(R,i);for(let T of c){let E=document.createElement("option");E.value=T,E.textContent=T,T===s.dokter&&(E.selected=!0),m.appendChild(E)}}let v=document.getElementById(x),C=document.getElementById(k),A=document.getElementById(f),re=document.getElementById(j),D;function S(){clearTimeout(D),D=setTimeout(()=>{let c={search:v?.value||"",dokter:m?.value||"",tanggalAwal:C?.value||"",tanggalAkhir:A?.value||""};L(c,e),z(c,e),w(c,h(t),p,i,u)},250)}v?.addEventListener("input",S),m?.addEventListener("change",S),C?.addEventListener("input",S),A?.addEventListener("input",S),re?.addEventListener("click",()=>{v&&(v.value=""),m&&(m.value=""),C&&(C.value=""),A&&(A.value="");let c={search:"",dokter:"",tanggalAwal:"",tanggalAkhir:""};L(c,e),z(c,e),w(c,h(t),p,i,u)}),w(s,R,p,i,u)}function P(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Z(){if(!Y())return;document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{setTimeout(t,500)}):setTimeout(t,500),new MutationObserver(()=>{let e=_();for(let r=0;r<e.length;r++){let a=e[r];if(!a.parentElement?.classList.contains("ext-cppt-table-wrapper")){let n=document.getElementById("ext-cppt-filter-"+r);if(n){let l=n.closest(".ext-cppt-table-wrapper");l&&l.remove()}O(a,r)}}}).observe(document.body,{childList:!0,subtree:!0});function t(){let e=_();if(e.length!==0){G(),console.log("[CPPT Filter] Found "+e.length+" CPPT table(s)");for(let r=0;r<e.length;r++)console.log("[CPPT Filter] Table #"+r+": id="+(e[r].id||"(none)")+" parent="+(e[r].parentNode?.className||"(none)")+" rows="+e[r].querySelectorAll("tr").length),O(e[r],r);for(let r=0;r<e.length;r++){let a=e[r];new MutationObserver(()=>{let n=W(r);if(n.search||n.dokter||n.tanggalAwal||n.tanggalAkhir){let l=q(a),p=b(l,"waktu","masuk","tanggal"),i=b(l,"penginput","dokter","pembuat"),o="ext-cppt-nores-"+r;w(n,h(a),p,i,document.getElementById(o))}}).observe(a,{childList:!0,subtree:!0})}}}}typeof I.featureModules<"u"?I.featureModules.cpptSearchFilter={id:"cpptSearchFilter",name:"CPPT Search & Filter",description:"Cari dan filter data CPPT per tabel (Riwayat CPPT & History Kunjungan)",match:{oneOf:[{pathname:"/admisi/pelaksanaan_pelayanan/cppt"},{pathname:"/admisi/detail-rawat-inap/cppt"}]},run:Z}:console.warn("[CPPT Search] featureModules not defined, registration skipped")})();
