"use strict";var __morbis_feature=(()=>{var I={background:"#ffffff",foreground:"#0a0a0e",card:"#ffffff",cardForeground:"#0a0a0e",primary:"#2469f0",primaryForeground:"#f8fafc",primaryHover:"#1d58cc",secondary:"#f1f5f9",secondaryForeground:"#1e293b",muted:"#f1f5f9",mutedForeground:"#64748b",accent:"#f1f5f9",accentForeground:"#1e293b",destructive:"#ef4444",destructiveForeground:"#f8fafc",border:"#e2e8f0",input:"#e2e8f0",ring:"#2469f0",success:"#1b8a4b",successBg:"#eaf6ef",warning:"#c47a1a",warningBg:"#fef4e4",error:"#ef4444",errorBg:"#fef2f2",info:"#2469f0",infoBg:"#eef3ff"},ye=new Set;function be(e,r){if(ye.has(e)){let d=document.getElementById(e);if(d)return d}let a=document.createElement("style");return a.id=e,a.textContent=r,document.head.appendChild(a),ye.add(e),a}be("ext-shared-animations",`
  @keyframes fadeSlideIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
`);var et=/^[A-Z][0-9][0-9](\.[0-9]{1,2})?$/,tt=/^[0-9]{2}(\.[0-9]{1,2})?$/,at=/^(\d{1,3})\/(\d{1,3})$/,nt=/^\d+(\.\d+)?$/;function x(e){let r=e.trim();return r===""||/^[-–—]+$/.test(r)}function F(e){return et.test(e.trim().toUpperCase())}function X(e){return tt.test(e.trim())}function ke(e){let r=e.trim().replace(/\s+/g,""),a=at.exec(r);if(!a)return!1;let d=parseInt(a[1],10),l=parseInt(a[2],10);return d>=50&&d<=250&&l>=20&&l<=160}function C(e,r,a){let d=e.trim().replace(",",".");if(!nt.test(d))return!1;let l=parseFloat(d);return!isNaN(l)&&l>=r&&l<=a}function _e(e){return/[\p{L}\p{N}]/u.test(e)}var rt='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',it=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${rt};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,ee=null;function ot(){return ee||(ee=new CSSStyleSheet,ee.replaceSync(it)),ee}var we=!1;function st(){if(we||document.getElementById("ext-pjs-font"))return;we=!0;let e=document.createElement("link");e.id="ext-pjs-font",e.rel="stylesheet",e.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(e)}function Ee(e,r="open"){let a=e.attachShadow({mode:r});return a.adoptedStyleSheets=[ot()],st(),a}var lt=`
  :host { display: none; }
  :host([open]) { display: block; }
  .overlay {
    position: fixed;
    inset: 0;
    z-index: 2147483000;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(15, 23, 42, 0.55);
    backdrop-filter: blur(2px);
    animation: ext-fade var(--ext-duration-normal) var(--ext-ease);
    padding: var(--ext-space-6);
  }
  .modal {
    width: 520px;
    max-width: 100%;
    background: var(--ext-surface);
    border-radius: var(--ext-radius-lg);
    box-shadow: var(--ext-shadow-lg);
    overflow: hidden;
    animation: ext-slide-up var(--ext-duration-normal) var(--ext-ease);
  }
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--ext-space-4);
    padding: var(--ext-space-5) var(--ext-space-6);
    border-bottom: 1px solid var(--ext-border);
  }
  .title {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-lg);
    font-weight: 700;
    color: var(--ext-text);
    margin: 0;
  }
  .close {
    appearance: none;
    border: none;
    background: var(--ext-surface-2);
    color: var(--ext-text-secondary);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    font-size: 22px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color var(--ext-duration-fast) var(--ext-ease), color var(--ext-duration-fast) var(--ext-ease);
  }
  .close:hover { background: var(--ext-danger-soft); color: var(--ext-danger); }
  .close:focus-visible { outline: none; box-shadow: var(--ext-ring); }

  .body {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text-secondary);
    padding: var(--ext-space-6);
  }
  .footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--ext-space-3);
    padding: 0 var(--ext-space-6) var(--ext-space-6);
  }
  /* tombol utama di dalam modal memakai komponen ext-btn \u2014 styling via atribut host */
  ::slotted(*) { font-family: var(--ext-font-family); }

  /* variant accent line */
  :host([variant='danger']) .header { box-shadow: inset 4px 0 0 var(--ext-danger); }
  :host([variant='success']) .header { box-shadow: inset 4px 0 0 var(--ext-success); }
  :host([variant='info']) .header { box-shadow: inset 4px 0 0 var(--ext-info); }
  :host([variant='warning']) .header { box-shadow: inset 4px 0 0 var(--ext-warning); }

  @keyframes ext-fade { from { opacity: 0; } }
  @keyframes ext-slide-up {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
  }
`,ut=class extends HTMLElement{constructor(){super(),this.handleKey=e=>{e.key==="Escape"&&this.hasAttribute("open")&&this.cancel()},this.root=Ee(this),this.root.innerHTML=`
      <style>${lt}</style>
      <div class="overlay">
        <div class="modal" role="dialog" aria-modal="true">
          <div class="header">
            <h3 class="title"><slot name="title"></slot></h3>
            <button class="close" part="close" aria-label="Tutup">&times;</button>
          </div>
          <div class="body"><slot></slot></div>
          <div class="footer">
            <slot name="footer"></slot>
          </div>
        </div>
      </div>
    `}connectedCallback(){let e=this.root.querySelector(".overlay");this.root.querySelector(".close").addEventListener("click",()=>this.cancel()),e.addEventListener("click",r=>{r.target===e&&this.cancel()}),document.addEventListener("keydown",this.handleKey)}disconnectedCallback(){document.removeEventListener("keydown",this.handleKey)}get titleSlot(){return this.querySelector('[slot="title"]')}get footerSlot(){return this.querySelector('[slot="footer"]')}open(){this.setAttribute("open","")}close(){this.removeAttribute("open")}cancel(){this.dispatchEvent(new CustomEvent("ext-cancel")),this.close()}ok(){this.dispatchEvent(new CustomEvent("ext-ok"))}};customElements.get("ext-modal")||customElements.define("ext-modal",ut);var dt=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,ct=class extends HTMLElement{constructor(){super();let e=Ee(this);e.innerHTML=`
      <style>${dt}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=e.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",e=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){e.stopPropagation(),e.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(e){(e==="disabled"||e==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}};customElements.get("ext-btn")||customElements.define("ext-btn",ct);function Se(e){return new Promise(r=>{let a=document.createElement("ext-modal");a.setAttribute("variant",e.variant??"warning"),e.okLabel&&a.setAttribute("ok-label",e.okLabel),e.cancelLabel&&a.setAttribute("cancel-label",e.cancelLabel),e.hideCancel&&a.setAttribute("hide-cancel",""),a.innerHTML=`<h3 slot="title"></h3><div class="ext-confirm-body"></div><div slot="footer">
         <ext-btn data-ext-confirm-cancel variant="secondary"></ext-btn>
         <ext-btn data-ext-confirm-ok></ext-btn>
       </div>`;let d=a.querySelector('[slot="title"]');d.textContent=e.title;let l=a.querySelector(".ext-confirm-body");if(e.icon){let m=document.createElement("div");m.className="ext-confirm-icon",m.textContent=e.icon,l.appendChild(m)}e.message&&e.message.split(`
`).forEach((m,h)=>{h>0&&l.appendChild(document.createElement("br")),l.appendChild(document.createTextNode(m))}),a.querySelector("[data-ext-confirm-ok]").textContent=e.okLabel??"Lanjut";let p=a.querySelector("[data-ext-confirm-ok]");p.setAttribute("variant",e.variant==="danger"?"danger":"primary"),e.hideCancel?a.querySelector("[data-ext-confirm-cancel]")?.remove():a.querySelector("[data-ext-confirm-cancel]").textContent=e.cancelLabel??"Batal",p.addEventListener("click",()=>a.ok()),e.hideCancel||a.querySelector("[data-ext-confirm-cancel]").addEventListener("click",()=>a.cancel());let g=m=>{a.remove(),r(m)};a.addEventListener("ext-ok",()=>g(!0)),a.addEventListener("ext-cancel",()=>g(!1)),document.body.appendChild(a),a.open()})}var Ce="morbis_preop_markers";function je(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}function ft(e,r=Date.now()){let a={},d=0;for(let[l,p]of Object.entries(e))p&&p.markedAt&&r-p.markedAt<=2592e6?a[l]=p:d++;return{purged:a,count:d}}function pt(e=je(),r=Date.now()){if(!e)return{};try{let a=e.getItem(Ce);if(!a)return{};let d=JSON.parse(a);if(typeof d!="object"||d===null)return{};let{purged:l,count:p}=ft(d,r),g=0;for(let m of Object.keys(l)){let h=l[m];h&&((h.norm!==void 0||h.nama!==void 0||h.noReg!==void 0)&&g++,l[m]=mt(h))}return(p>0||g>0)&&ht(l,e),l}catch{return{}}}function mt(e){return{idVisit:e.idVisit,markedAt:e.markedAt}}function ht(e,r=je()){if(r)try{r.setItem(Ce,JSON.stringify(e))}catch{}}var gt="http://dev.rsudkotajambi.id/rs",xt="ext-farmasi-app-base",vt=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],yt=".rsudkotajambi.id",bt=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],Ae="Fitur nonaktif: server Reports menggunakan HTTP (belum mendukung HTTPS)";function te(e){try{let r=new URL(e??ae());if(r.protocol==="https:")return null;let a=r.hostname.toLowerCase();return bt.includes(a)?null:Ae}catch{return Ae}}function kt(e){try{let r=new URL(e);if(r.protocol!=="http:"&&r.protocol!=="https:")return!1;let a=r.hostname.toLowerCase();return vt.includes(a)?!0:a.endsWith(yt)}catch{return!1}}function ae(){try{let e=localStorage.getItem(xt);if(e&&kt(e))return e.replace(/\/+$/,"")}catch{}return gt}async function _t(e,r,a=fetch){let d=new AbortController,l=globalThis.setTimeout(()=>d.abort(),25e3);try{return await a(e,{...r,signal:d.signal})}finally{globalThis.clearTimeout(l)}}async function wt(e,r=fetch){try{let a=ae(),d=te(a);if(d)return console.warn("[casemixApi]",d,"\u2014 baca pusat dilewati:",e),null;let l=await _t(a+e,{cache:"no-store",credentials:"omit",headers:{Accept:"application/json"}},r);return l.ok?await l.json():null}catch{return null}}async function Et(e,r,a=fetch){if(!e)return[];let d="/api/reports/resume-history?id_visit="+encodeURIComponent(e)+(r?"&tipe="+r:""),l=await wt(d,a);return!l?.ok||!Array.isArray(l.data)?[]:l.data}function St(){try{let e=globalThis.crypto;if(e&&typeof e.randomUUID=="function")return e.randomUUID()}catch{}return`${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`}function z(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}var Ie="ext_rv_history_",Ct=Ie,Le="ext_rv_lastform_",Te="ext_migrated_rv_",$e=50;function re(e,r){return`${Ie}${r==="ranap"?"ri":"rj"}_${e||"unknown"}`}function Be(e,r){return`${Le}${r==="ranap"?"ri":"rj"}_${e||"unknown"}`}function ne(e,r){if(!e)return null;try{let a=e.getItem(r);return a?JSON.parse(a):null}catch{return null}}function ie(e,r,a){if(e)try{e.setItem(r,JSON.stringify(a))}catch{}}function jt(e,r){return JSON.stringify(e??null)===JSON.stringify(r??null)}function De(e,r){let a={};return Object.keys(e).forEach(d=>a[d]=!0),Object.keys(r).forEach(d=>a[d]=!0),Object.keys(a).filter(d=>!jt(e[d],r[d]))}function Ne(e){let r=e===void 0?"-":JSON.stringify(e);return r.length>60?r.slice(0,60)+"\u2026":r}function G(e,r,a=z()){let d=ne(a,re(e,r)),l=Array.isArray(d)?d:[];if(r==="ranap"){let p=ne(a,Ct+e);if(Array.isArray(p)&&p.length>0&&l.length===0){let g=p.map(m=>({...m,tipe:"ranap"}));return oe(g,e,"ranap",a),g}}return l}function oe(e,r,a,d=z()){ie(d,re(r,a),e.slice(-$e))}function At(e,r,a=z()){return ne(a,Be(e,r))||(r==="ranap"?ne(a,Le+e):null)}function se(e,r,a,d=z()){ie(d,Be(r,a),e)}function It(){try{let e=document.getElementById("userpanel");if(e){let l="",p="";if(e.querySelectorAll(".subgroup").forEach(m=>{let h=(m.querySelector(".subtitle")?.textContent||"").trim().toLowerCase(),w=(m.querySelector(".subcontent")?.textContent||"").trim();h==="username"&&w&&(l=w),h==="role"&&w&&(p=w)}),l)return`${l}${p?` (${p})`:""}`;let g=(e.querySelector("a")?.textContent||"").trim();if(g&&g!=="Petugas Rumah Sakit")return g}let r=(document.querySelector("#petugas, .petugas, .username, #username, .user-name")?.textContent||"").trim();if(r)return r.slice(0,80);let a=document.querySelector('input[name="dokter"], #dokter, input[name="nama_dokter"]')?.value?.trim();if(a)return a.slice(0,80);let d=document.querySelector('input[name="id_user"], #id_user')?.value?.trim();if(d)return`User #${d}`}catch{}return"petugas"}var Lt="/api/reports/resume-history";function Tt(){return ae()}function $t(e){return Te+e}function Bt(e,r){if(!e)return 0;try{let a=e.getItem(r);if(a===null)return 0;let d=Number(JSON.parse(a));return Number.isFinite(d)?d:0}catch{return 0}}function Dt(e,r,a,d){if(!(!e||!r))try{let l=$t(re(r,a));d>Bt(e,l)&&ie(e,l,d)}catch{}}function Nt(e,r,a=fetch,d=z(),l=e.tipe){let p={client_id:e.client_id??null,id_visit:r,id_resume:e.id_resume,aksi:e.aksi,tipe:e.tipe,waktu:new Date(e.at).toISOString(),user:e.user,before:e.before,after:e.after,changed:e.changed},g=async()=>{try{let m=Tt(),h=te(m);return h?(console.warn("[resumeHistory]",h,"\u2014 kirim resume dilewati:",r),!1):(await a(m+Lt,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(p),keepalive:!0,credentials:"omit"})).ok?(Dt(d,r,l,e.at),!0):!1}catch{return!1}};try{return g()}catch{return Promise.resolve(!1)}}var qe=null,Oe=0;function qt(e){if(!e.idVisit)return null;let r=e.now??Date.now(),a=e.store??z();se(e.after,e.idVisit,e.tipe,a);let d=JSON.stringify([e.idVisit,e.aksi,e.after]);if(qe===d&&r-Oe<5e3)return null;qe=d,Oe=r;let l={at:r,aksi:e.aksi,id_resume:e.idResume??"",user:e.user??It(),tipe:e.tipe,before:e.before??{},after:e.after,changed:De(e.before??{},e.after),client_id:St()},p=G(e.idVisit,e.tipe,a);p.push(l),oe(p,e.idVisit,e.tipe,a),se(e.after,e.idVisit,e.tipe,a);try{Nt(l,e.idVisit,e.fetcher??fetch,a,e.tipe)}catch{}return l}function ze(e){try{let r=document.createElement("div");r.textContent=e,r.style.cssText="position:fixed;top:20px;right:20px;z-index:2147483647;padding:14px 18px;border-radius:8px;background:#dcfce7;color:#065f46;border-left:5px solid #16a34a;font-weight:600;font-size:16px!important;line-height:1.6!important;font-family:"+Ue+"!important;box-shadow:0 4px 16px rgba(0,0,0,.15);max-width:420px;",document.body.appendChild(r),setTimeout(()=>r.remove(),4e3)}catch{}}function Ot(e){if(e!=null){if(typeof e=="string")return e;if(typeof e=="number"||typeof e=="boolean")return String(e);if(Array.isArray(e))return e.map(r=>{if(typeof r=="string")return r;try{return JSON.stringify(r)??""}catch{return""}});try{return JSON.stringify(e)??""}catch{return""}}}function Ve(e){let r={};if(!e||typeof e!="object"||Array.isArray(e))return r;for(let a of Object.keys(e)){let d=Ot(e[a]);d!==void 0&&(r[a]=d)}return r}function zt(e,r){try{if(!e||typeof e!="object")return null;let a=e.waktu?Date.parse(e.waktu):NaN;if(!Number.isFinite(a))return null;let d=Ve(e.after),l=Ve(e.before),p=e.tipe==="rajal"?"rajal":e.tipe==="ranap"?"ranap":r,g=Array.isArray(e.changed)?e.changed.filter(h=>typeof h=="string"):De(l,d),m=typeof e.client_id=="string"&&e.client_id?e.client_id:void 0;return{at:a,aksi:e.aksi==="buat"?"buat":"ubah",id_resume:typeof e.id_resume=="string"?e.id_resume:"",user:typeof e.user=="string"&&e.user?e.user:"petugas",tipe:p,before:l,after:d,changed:g,...m?{client_id:m}:{}}}catch{return null}}function Re(e){if(e.client_id)return"cid:"+e.client_id;try{return"h:"+e.at+"|"+e.user+"|"+e.aksi+"|"+JSON.stringify(e.after)}catch{return"h:"+e.at+"|"+e.user+"|"+e.aksi}}function Vt(e,r){let a=new Set(e.map(Re)),d=e.slice();for(let l of r){let p=Re(l);a.has(p)||(a.add(p),d.push(l))}return d.sort((l,p)=>l.at-p.at),d.slice(-$e)}var Ue="'Roboto','Segoe UI',system-ui,-apple-system,Arial,sans-serif";function Rt(e){try{document.querySelector("#ext-rv-history-overlay")?.remove()}catch{}let r=e.store??z(),a=G(e.idVisit,e.tipe,r).slice().reverse(),d=e.zIndex??99998,l=document.createElement("div");l.id="ext-rv-history-overlay",l.style.cssText=`position:fixed;inset:0;z-index:${d};background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:24px;`,l.addEventListener("click",function(L){L.target===l&&l.remove()});let p=document.createElement("div");p.style.cssText="background:#fff;border-radius:12px;max-width:680px;width:100%;max-height:82vh;display:flex;flex-direction:column;overflow:hidden;font-size:16px!important;line-height:1.6!important;color:#1c2530;font-family:"+Ue+"!important;",l.appendChild(p);let g=document.createElement("div");g.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #d0d5dd;font-weight:700;";let m=document.createElement("span");m.textContent=`${e.title??"Riwayat Resume"} (${a.length})`,g.appendChild(m);let h=document.createElement("button");h.type="button",h.textContent="\xD7",h.style.cssText="border:none;background:#f8fafc;width:32px;height:32px;border-radius:50%;font-family:inherit!important;font-size:16px!important;line-height:1!important;cursor:pointer;",h.onclick=function(){l.remove()},g.appendChild(h),p.appendChild(g);let w=document.createElement("div");w.style.cssText="padding:14px 18px;overflow-y:auto;",p.appendChild(w);let E=L=>{if(a=L,m.textContent=`${e.title??"Riwayat Resume"} (${a.length})`,w.replaceChildren(),!a.length){w.textContent="Belum ada riwayat untuk kunjungan ini. Riwayat tercatat otomatis setiap kali Simpan ditekan.";return}a.forEach(function(y,q){let P=a.length-q,A=document.createElement("div");A.style.cssText="border:1px solid #d0d5dd;border-radius:8px;padding:10px 12px;margin-bottom:10px;";let V=document.createElement("div");V.style.fontWeight="600";let H=y.user?` \u2014 oleh ${y.user}`:"",Y=y.after?._source==="verif_action",M=Y?" \u2014 verifikasi berkas":"";V.textContent=`#${P} \u2014 ${new Date(y.at).toLocaleString("id-ID")} \u2014 ${y.aksi==="buat"?"Buat baru":"Ubah"}${H} \u2014 ${y.changed.length} field berubah${M}`,A.appendChild(V);let B=document.createElement("div");B.style.cssText="display:none;margin-top:8px;background:#f8fafc;border-radius:6px;padding:8px 10px;font-size:13px;line-height:1.6;max-height:180px;overflow-y:auto;white-space:pre-wrap;",y.changed.length?B.textContent=y.changed.map(function($){return $+": "+Ne(y.before[$])+" \u2192 "+Ne(y.after[$])}).join(`
`):B.textContent="Tidak ada perbedaan field.",A.appendChild(B);let D=document.createElement("div");D.style.cssText="margin-top:8px;display:flex;gap:8px;";let O=document.createElement("button");O.type="button",O.textContent="Lihat",O.style.cssText="border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",O.onclick=function(){B.style.display=B.style.display==="none"?"block":"none"},D.appendChild(O);let T=document.createElement("button");if(T.type="button",T.textContent="Salin ke Form",T.style.cssText="background:#00875a;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",T.onclick=function(){try{e.onApply(y.after),l.remove()}catch{}},Y){let $=document.createElement("span");$.textContent="Entri verifikasi \u2014 bukan snapshot form, tidak untuk disalin.",$.style.cssText="align-self:center;color:#92400e;background:#fef3c7;border-radius:6px;padding:4px 10px;font-size:12px;line-height:1.5;",D.appendChild($)}else D.appendChild(T);A.appendChild(D),w.appendChild(A)})};E(a);try{document.body.appendChild(l)}catch{}if(e.idVisit){let L=te();if(L)try{let y=document.createElement("div");y.textContent=L+" \u2014 riwayat hanya dari PC ini.",y.style.cssText="margin-top:10px;padding:8px 10px;background:#fef3c7;color:#92400e;border-radius:6px;font-size:13px;line-height:1.5;",w.appendChild(y)}catch{}else try{Et(e.idVisit,e.tipe).then(y=>{try{if(!y.length||!l.isConnected)return;let q=[];for(let V of y){let H=zt(V,e.tipe);H&&q.push(H)}if(!q.length)return;let P=G(e.idVisit,e.tipe,r),A=Vt(P,q);if(A.length===P.length)return;oe(A,e.idVisit,e.tipe,r),E(A.slice().reverse());try{document.dispatchEvent(new CustomEvent("ext-rv-history-merged",{detail:{idVisit:e.idVisit,tipe:e.tipe,count:A.length}}))}catch{}}catch{}})}catch{}}}var Je="ext_migrated_preop_ids",Fe=Te,le=20;function Pe(e,r){if(!e)return null;try{let a=e.getItem(r);return a?JSON.parse(a):null}catch{return null}}function He(e,r,a){if(e)try{e.setItem(r,JSON.stringify(a))}catch{}}function Ut(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}async function ue(e,r,a=fetch){let d=ae(),l=te(d);if(l)return console.warn("[casemixBackfill]",l,"\u2014 backfill dilewati:",e),!1;try{return(await a(d+e,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(r),credentials:"omit"})).ok}catch{return!1}}function Jt(e,r){let a=new Set(r);return Object.keys(e).filter(d=>!a.has(d)).slice(0,le)}function Ft(e,r){return e.filter(a=>a.at>r).slice(0,le)}function Pt(e){let r=[];if(!e)return r;try{let a=[],d=e;if(typeof d.length=="number"&&d.key)for(let l=0;l<d.length;l++){let p=d.key(l);p&&a.push(p)}for(let l of a){let p=l.match(/^ext_rv_history_(ri|rj)_(.+)$/);if(p){r.push({key:l,idVisit:p[2],tipe:p[1]==="ri"?"ranap":"rajal"});continue}p=l.match(/^ext_rv_history_(.+)$/),p&&!p[1].startsWith("ri_")&&!p[1].startsWith("rj_")&&r.push({key:l,idVisit:p[1],tipe:"ranap"})}}catch{}return r}async function Ht(e=Ut(),r=fetch){let a={preopUploaded:0,resumeUploaded:0,offline:!1};if(!e)return a;try{let d=pt(e),l=Pe(e,Je)??[],p=Jt(d,l);for(let g of p){let m=d[g];if(m){if(!await ue("/api/casemix/pre-op/toggle",{id_visit:g,marked:!0,norm:m.norm??null,nama:m.nama??null,no_reg:m.noReg??null,user:null},r)){a.offline=!0;break}l.push(g),a.preopUploaded++}}try{let g=new Set(Object.keys(d)),m=[];for(let h of l){if(g.has(h)){m.push(h);continue}if(a.offline){m.push(h);continue}await ue("/api/casemix/pre-op/toggle",{id_visit:h,marked:!1},r)?a.preopUploaded++:(a.offline=!0,m.push(h))}(m.length!==l.length||a.preopUploaded>0)&&He(e,Je,m)}catch{}}catch{a.offline=!0}try{for(let{key:d,idVisit:l,tipe:p}of Pt(e)){if(!l||l==="unknown")continue;if(a.resumeUploaded>=le)break;let g=Pe(e,Fe+d)??0,m=G(l,p,e),h=Ft(m,g),w=g;for(let E of h){if(!await ue("/api/reports/resume-history",{client_id:E.client_id??null,id_visit:l,id_resume:E.id_resume,aksi:E.aksi,tipe:E.tipe??p,waktu:new Date(E.at).toISOString(),user:E.user,before:E.before,after:E.after,changed:E.changed},r)){a.offline=!0;break}w=Math.max(w,E.at),a.resumeUploaded++}if(w>g&&He(e,Fe+d,w),a.offline)break}}catch{a.offline=!0}try{(a.preopUploaded||a.resumeUploaded)&&window.console.debug(`[casemixBackfill] diunggah: ${a.preopUploaded} pre-op, ${a.resumeUploaded} resume`)}catch{}return a}var Me=null;function Mt(){if(Me!==null)return;let e=()=>{try{if(document.hidden)return}catch{}Ht().catch(()=>{})};window.setTimeout(e,5e3),Me=window.setInterval(e,3e4)}(function(){let e=0,r=setInterval(function(){e++;let t=document.documentElement.getAttribute("data-ext-resume-validator"),i=document.documentElement.getAttribute("data-ext-resume-history");if(t!==null||i!==null){clearInterval(r);let n=t==="1",o=i==="1"||n;if(!n&&!o)return;d(n,o)}else e>=100&&clearInterval(r)},50);function a(){let t=window.location.pathname;return t.includes("/tambah-resume-ri")||t.includes("/edit-resume-ri")?"ranap":t.includes("/rm-rawat-jalan-new")?"rajal":null}function d(t,i){let n=a();if(!n)return;let o=setInterval(function(){let s=document.getElementById("save"),u=n==="ranap"?document.querySelector('form[action*="rawat-inap-resume"], form[action*="edit-resume-rawat-inap"]'):document.querySelector('form#formdata, form[action*="rm-rawat-jalan"]');s&&u&&(clearInterval(o),l(u,s,n,t,i))},200)}function l(t,i,n,o,s){p();try{Mt()}catch{}if(s&&g(t,n,o),!o){s&&O(t,i,n);return}ca(n),n==="ranap"&&(Y("ranap")||(H(),P(t))),Gt(),Yt(),aa(),Zt(n),Qt(),Xt(),na(n),ra(n),Wt(t),O(t,i,n)}function p(){be("ext-rv-css",[`.ext-rv-error { border: 2px solid ${I.error} !important; background: ${I.errorBg} !important; transition: all 0.2s; }`,".ext-rv-toast { position: fixed; top: 20px; right: 20px; z-index: 99999; padding: 16px 24px; border-radius: 8px; font-size: 14px; font-weight: 600; box-shadow: 0 4px 16px rgba(0,0,0,0.15); max-width: 420px; line-height: 1.5; }",`.ext-rv-toast-error { background: ${I.errorBg}; color: #991b1b; border-left: 5px solid ${I.error}; }`,`.ext-rv-toast-success { background: ${I.successBg}; color: #065f46; border-left: 5px solid ${I.success}; }`,`.ext-rv-icd-valid { border: 2px solid ${I.success} !important; background: ${I.successBg} !important; }`,`.ext-rv-icd-invalid { border: 2px solid ${I.error} !important; background: ${I.errorBg} !important; }`].join(`
`))}function g(t,i,n){let o=window;if(i==="rajal"){let f=typeof o.simpan=="function"?o.simpan:null;if(f&&!f.__extWrapped){let k=function(...v){if(n&&!Z(i))return!1;D(t,i),K=!1;try{localStorage.removeItem(E())}catch{}return f.apply(this,v)};k.__extWrapped=!0,o.simpan=k}}else n&&(o.cekForm=function(){return Z(i)});t.onsubmit!==null&&(t.onsubmit=function(f){let k=n?Z(i):!0;return!k&&f?f.preventDefault():D(t,i),k});let s=o.jQuery;n&&typeof s=="object"&&s&&typeof s.fn?.on=="function"&&s.fn.on("submit",function(f){return Z(i)?!0:(f.preventDefault(),!1)});var u=t.submit.bind(t);t.submit=function(){if(!(n&&!Z(i))){D(t,i),K=!1,A();try{localStorage.removeItem(E())}catch{}u()}}}let m="ext_draft_resume_";var h=null,w=4320*60*1e3;function E(){let t=c("id_visit");return m+(t||"unknown")}var L=null,y=2e3;function q(t,i){return function(){L&&clearTimeout(L),L=setTimeout(t,i)}}function P(t){var i=function(){V(t)},n=t.querySelectorAll("input, textarea, select");n.forEach(function(o){o.addEventListener("change",q(i,y)),o.addEventListener("input",q(i,y))}),h=setInterval(i,3e4)}function A(){h!==null&&(clearInterval(h),h=null)}function V(t){let i=E(),n=new FormData(t),o={};n.forEach(function(s,u){o[u]=s.toString()}),o._saved_at=Date.now().toString();try{localStorage.setItem(i,JSON.stringify({savedAt:Date.now(),data:o}))}catch{}}async function H(){let t=E(),i;try{i=localStorage.getItem(t)}catch{return}if(!i)return;let n;try{n=JSON.parse(i)}catch{return}if(typeof n.savedAt!="number"||typeof n.data!="object"||n.data===null||Date.now()-n.savedAt>=w){try{localStorage.removeItem(t)}catch{}return}let o=n.data,s=function(){for(let u in o){if(u==="_saved_at")continue;let f=document.querySelector('[name="'+u+'"]');f&&!f.value&&(f.value=o[u])}try{localStorage.removeItem(t)}catch{}};if(await Se({title:"Draft Ditemukan",message:"Data draft sebelumnya ditemukan. Pulihkan?",variant:"info",okLabel:"Pulihkan",cancelLabel:"Hapus"}))s();else try{localStorage.removeItem(t)}catch{}}function Y(t){let i=t==="rajal"?"id_rawat_jalan":"id_resume_inap",n=document.getElementById(i);return!!n&&!!n.value}var M=null;function B(){return c("id_visit")}function D(t,i){let n=$(t),o=B(),s=c(i==="rajal"?"id_rawat_jalan":"id_resume_inap"),u=Y(i)?"ubah":"buat",f=At(o,i)||{};qt({idVisit:o,idResume:s,tipe:i,aksi:u,before:f,after:n}),T(o,i)}function O(t,i,n){let o=B();if(se($(t),o,n),T(o,n),M||!i.parentElement)return;let s=document.createElement("button");s.type="button",s.id="ext-rv-history-btn",s.textContent="Riwayat",s.style.cssText="margin-left:8px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:13px;",s.onclick=function(){Rt({idVisit:o,tipe:n,title:n==="rajal"?"Riwayat Resume Rajal":"Riwayat Resume Rawat Inap",zIndex:99998,onApply:function(u){Kt(t,u)}})},i.parentElement.insertBefore(s,i.nextSibling),M=s,T(o,n),window.addEventListener("ext-rv-history-merged",function(u){try{let f=u.detail;f&&f.idVisit===o&&f.tipe===n&&T(o,n)}catch{}})}function T(t,i){if(!M)return;let n=G(t,i).length;M.textContent=n>0?"Riwayat ("+n+")":"Riwayat"}function $(t){let i={},n=/^(kode_|diagnosa_|tindakan\d+$|nosokomial\d+$|kode\d+$|kode9\d+$)/;return t.querySelectorAll("input[name], textarea[name], select[name], input[id]:not([name]):not([type=button]):not([type=submit]), textarea[id]:not([name]), select[id]:not([name])").forEach(function(o){let s=o.getAttribute("name")||(n.test(o.id)?o.id:"");if(!s||s==="_saved_at"||s==="save")return;if(o instanceof HTMLInputElement&&(o.type==="checkbox"||o.type==="radio")){if(!o.checked)return;let f=i[s];f===void 0?i[s]=o.value:Array.isArray(f)?f.push(o.value):i[s]=[f,o.value];return}if(o instanceof HTMLSelectElement&&o.multiple){i[s]=Array.from(o.selectedOptions).map(function(f){return f.value});return}let u=i[s];u!==void 0&&!Array.isArray(u)?i[s]=[u,o.value]:Array.isArray(u)?u.push(o.value):i[s]=o.value}),i}function Kt(t,i){if(i._source==="verif_action"){ze("Entri verifikasi berkas \u2014 tidak bisa disalin ke form.");return}let n=0,o=0;Object.keys(i).forEach(function(s){let u=i[s],f=Array.from(t.querySelectorAll('[name="'+s+'"]'));if(!f.length){let v=t.querySelector("#"+CSS.escape(s));f=v?[v]:[]}if(!f.length){o++;return}let k=Array.isArray(u)?u:[u];f.forEach(function(v,_){if(v instanceof HTMLInputElement&&(v.type==="checkbox"||v.type==="radio"))v.checked=Array.isArray(u)?u.indexOf(v.value)>=0:v.value===u;else if(v instanceof HTMLSelectElement&&v.multiple){let b=Array.isArray(u)?u:[u];Array.from(v.options).forEach(function(S){S.selected=b.indexOf(S.value)>=0})}else v.value=k[_]??"";v.dispatchEvent(new Event("input",{bubbles:!0})),v.dispatchEvent(new Event("change",{bubbles:!0})),n++})}),ze("Disalin "+n+" field"+(o>0?", "+o+" nama tak ditemukan":"")+". Periksa lalu klik Simpan.")}let K=!1;function Wt(t){var i=t.querySelectorAll("input, textarea, select");i.forEach(function(n){n.addEventListener("change",function(){K=!0}),n.addEventListener("input",function(){K=!0})}),t.addEventListener("submit",function(){K=!1}),window.addEventListener("beforeunload",function(n){if(K)return n.preventDefault(),n.returnValue="Data yang belum disimpan akan hilang.",n.returnValue})}function Gt(){[{id:"suhu_pulang",min:30,max:45,step:.1},{id:"suhu",min:30,max:45,step:.1},{id:"nadi_pulang",min:20,max:250,step:1},{id:"nadi",min:20,max:250,step:1},{id:"rr_pulang",min:4,max:80,step:1},{id:"nafas",min:4,max:80,step:1},{id:"spo2_pulang",min:50,max:100,step:1},{id:"spo2",min:50,max:100,step:1},{id:"gcs_e",min:1,max:4,step:1},{id:"gcs_m",min:1,max:6,step:1},{id:"gcs_v",min:1,max:5,step:1},{id:"tinggi",min:30,max:250,step:1},{id:"berat",min:1,max:500,step:.1}].forEach(function(t){var i=document.getElementById(t.id);if(i){var n=i.value.trim();(n==="-"||n===""||isNaN(Number(n)))&&(i.value=""),i.type="number",i.min=String(t.min),i.max=String(t.max),i.step=String(t.step),i.placeholder||(i.placeholder=t.min+"-"+t.max)}})}function Yt(){var t=["td_pulang","td","tensi","tensi_pulang"];t.forEach(function(i){var n=document.getElementById(i);n&&(n.placeholder="120/80",n.pattern="[0-9]{2,3}/[0-9]{2,3}",n.title="Format: angka/angka (Contoh: 120/80)")})}function Zt(t){var i=t==="rajal"?["anamnesa","catatan","terapi_pengobatan","jenis_kasus","tindak_lanjut"]:["alasan_rawat","anamnesa","diagnosa_primary","kode_diagnosa_utama","jenis_kasus","keadaan_keluar","cara_keluar","tgl_keluar2"];i.forEach(function(n){var o=document.getElementById(n);o&&(o.required=!0)})}function Qt(){document.querySelectorAll('input:not([type="submit"]):not([type="button"])').forEach(function(t){t.addEventListener("keydown",function(i){i.key==="Enter"&&i.preventDefault()})})}function Xt(){document.querySelectorAll("textarea").forEach(function(t){t.style.overflow="hidden",t.style.resize="vertical",t.addEventListener("input",function(){t.style.height="auto",t.style.height=t.scrollHeight+"px"})})}let ea=["td_pulang","tensi","nadi_pulang","suhu_pulang","rr_pulang","spo2_pulang","gcs_e","gcs_m","gcs_v"];function ta(){let t=document.getElementById("keadaan_keluar")?.value||"",i=document.getElementById("cara_keluar")?.value||"";return[t,i,document.getElementById("keadaan_keluar")?.options[document.getElementById("keadaan_keluar")?.selectedIndex??0]?.text||"",document.getElementById("cara_keluar")?.options[document.getElementById("cara_keluar")?.selectedIndex??0]?.text||""].some(n=>/meninggal/i.test(n))}function de(){let t=ta();ea.forEach(function(i){var n=document.getElementById(i);n&&(t?(n.value&&!n.dataset.originalValue&&(n.dataset.originalValue=n.value),n.value="",n.disabled=!0,n.style.backgroundColor="#f5f5f5",n.style.color="#999",n.title="Otomatis kosong: pasien meninggal dunia"):(n.dataset.originalValue&&(n.value=n.dataset.originalValue,delete n.dataset.originalValue),n.disabled=!1,n.style.backgroundColor="",n.style.color="",n.title=""))})}function aa(){let t=document.getElementById("keadaan_keluar"),i=document.getElementById("cara_keluar");de(),t&&t.addEventListener("change",de),i&&i.addEventListener("change",de)}function na(t){var i=Ke(t),n=We(t);i.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("input",function(){var u=s.value.trim();s.classList.remove("ext-rv-icd-valid","ext-rv-icd-invalid"),u!==""&&(/^[A-Z][0-9][0-9](\.[0-9]{1,2})?$/i.test(u)?s.classList.add("ext-rv-icd-valid"):s.classList.add("ext-rv-icd-invalid"))})}),n.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("input",function(){var u=s.value.trim();s.classList.remove("ext-rv-icd-valid","ext-rv-icd-invalid"),u!==""&&(/^[0-9]{2}(\.[0-9]{1,2})?$/.test(u)?s.classList.add("ext-rv-icd-valid"):s.classList.add("ext-rv-icd-invalid"))})})}function ra(t){var i=Ke(t);i.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("blur",function(){var u=s.value.trim().toUpperCase();u&&(u=u.replace(".",""),u.length>3&&(u=u.substring(0,3)+"."+u.substring(3)),s.value=u,s.dispatchEvent(new Event("input")))})});var n=We(t);n.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("blur",function(){var u=s.value.trim();u&&(u=u.replace(".",""),u.length>2&&(u=u.substring(0,2)+"."+u.substring(2)),s.value=u,s.dispatchEvent(new Event("input")))})})}function Ke(t){if(t==="rajal"){let o=[];if(document.querySelectorAll('input[name="kode10[]"]').forEach(function(u){u.id&&o.push(u.id)}),o.length)return o;let s=[];for(let u=1;u<=20;u++)s.push("kode"+u);return s}for(var i=["kode_diagnosa_utama"],n=1;n<=10;n++)i.push("kode_diagnosa_sekunder"+n);return i}function We(t){if(t==="rajal"){let o=[];if(document.querySelectorAll('input[name="kode9[]"]').forEach(function(u){u.id&&o.push(u.id)}),o.length)return o;let s=[];for(let u=1;u<=20;u++)s.push("kode9"+u);return s}for(var i=[],n=1;n<=10;n++)i.push("kode_tindakan"+n);return i}function Z(t){sa();var i=[];function n(s,u,f){s||i.push({msg:u,id:f})}function o(s,u){let f=c(s);x(f)||_e(f)||n(!1,u+" tidak boleh hanya berisi simbol atau karakter khusus",s)}return t==="rajal"?oa(n,o):ia(n,o),i.length>0?(la(i),!1):!0}function ia(t,i){t(!!c("norm"),"No. RM harus diisi","norm"),t(!!c("pasien"),"Nama pasien harus diisi","pasien"),t(!!c("id_visit"),"Data kunjungan tidak valid","pasien"),i("alasan_rawat","Alasan rawat"),i("anamnesa","Anamnesa"),i("diagnosa_primary","Diagnosa primary"),i("terapi_pengobatan","Terapi/pengobatan"),t(!!c("kode_diagnosa_utama"),"Kode ICD-10 Diagnosa Utama harus diisi","kode_diagnosa_utama"),c("kode_diagnosa_utama")&&!x(c("kode_diagnosa_utama"))&&t(F(c("kode_diagnosa_utama")),"Format kode ICD-10 Diagnosa Utama tidak valid (contoh: A00, B20.9)","kode_diagnosa_utama"),c("diagnosa_utama")&&!ce("kode_diagnosa_utama",F)&&t(!!c("id_diagnosa_utama"),"Diagnosa Utama harus dipilih dari hasil pencarian (autocomplete)","diagnosa_utama");for(var n=1;n<=10;n++){var o=c("kode_diagnosa_sekunder"+n),s=c("diagnosa_sekunder"+n),u=c("id_diagnosa_sekunder"+n);o&&!x(o)&&t(F(o),"Format kode ICD-10 Diagnosa Sekunder "+n+" tidak valid","kode_diagnosa_sekunder"+n),s&&!x(s)&&!ce("kode_diagnosa_sekunder"+n,F)&&t(!!u,"Diagnosa Sekunder "+n+" harus dipilih dari hasil pencarian","diagnosa_sekunder"+n)}for(var f=1;f<=10;f++){var k=c("kode_tindakan"+f),v=c("tindakan"+f),_=c("id_tindakan"+f);k&&!x(k)&&t(X(k),"Format kode ICD-9 Tindakan "+f+" tidak valid (contoh: 45.16)","kode_tindakan"+f),v&&!x(v)&&!ce("kode_tindakan"+f,X)&&t(!!_,"Tindakan "+f+" harus dipilih dari hasil pencarian (autocomplete)","tindakan"+f)}var b=c("td_pulang")||c("tensi");b&&!x(b)&&t(ke(b),"Tekanan darah pulang tidak valid (contoh: 120/80)",c("td_pulang")?"td_pulang":"tensi");var S=c("keadaan_keluar"),j=S&&/meninggal\s*dunia/i.test(S),R=c("nadi_pulang");!j&&R&&!x(R)&&t(C(R,20,250),"Nadi pulang harus 20-250","nadi_pulang");var U=c("suhu_pulang");!j&&U&&!x(U)&&t(C(U,30,45),"Suhu pulang harus 30-45\xB0C","suhu_pulang");var N=c("rr_pulang");!j&&N&&!x(N)&&t(C(N,4,120),"RR pulang harus 4-120","rr_pulang");var pe=c("spo2_pulang");!j&&pe&&!x(pe)&&t(C(pe,50,100),"SpO2 pulang harus 50-100%","spo2_pulang"),t(!!c("jenis_kasus"),"Jenis kasus harus dipilih","jenis_kasus"),t(!!c("keadaan_keluar"),"Keadaan keluar harus dipilih","keadaan_keluar"),t(!!c("cara_keluar"),"Cara keluar harus dipilih","cara_keluar"),t(!!(c("tgl_keluar2")||c("tgl_keluar")),"Tanggal keluar harus diisi","tgl_keluar2");var me=c("gcs_e");!j&&me&&!x(me)&&t(C(me,1,4),"GCS Eye harus 1-4","gcs_e");var he=c("gcs_m");!j&&he&&!x(he)&&t(C(he,1,6),"GCS Motor harus 1-6","gcs_m");var W=c("gcs_v");!j&&W&&!x(W)&&t(C(W,1,5),"GCS Verbal harus 1-5","gcs_v");var ge=c("gcs_e"),xe=c("gcs_m");if(!j&&ge&&xe&&W&&!x(ge)&&!x(xe)&&!x(W)){var Ge=Number(ge)+Number(xe)+Number(W);t(C(String(Ge),3,15),"Total GCS (E+M+V) harus 3-15, saat ini "+Ge,"gcs_v")}var fa=Q("pasien_rujuk_masuk_opsi").toLowerCase();fa==="ya"&&t(fe("pasien_rujuk_masuk"),"Alasan Datang poin A: pilih asal rujukan masuk","pasien_rujuk_masuk_opsi-ya");var pa=Q("pasien_rujuk_dikembalikan_opsi").toLowerCase();pa==="ya"&&t(fe("pasien_rujuk_dikembalikan"),"Alasan Datang poin B: pilih asal rujukan dikembalikan","pasien_rujuk_dikembalikan_opsi-ya");var ma=Q("pasien_dirujuk_keluar_opsi").toLowerCase();ma==="ya"&&t(fe("pasien_rujuk_keluar"),"Alasan Datang poin C: pilih rujukan keluar","pasien_dirujuk_keluar_opsi-ya");var ha=Q("menggunakan_kb_opsi").toLowerCase();ha==="ya"&&(t(!!c("jenis_kb"),"Pelayanan KB: jenis KB harus dipilih","jenis_kb"),t(!!c("waktu_kb"),"Pelayanan KB: waktu KB harus dipilih","waktu_kb"),t(da(".monitoring_kb"),"Pelayanan KB: pilih minimal satu monitoring KB","monitoring_kb-komplikasi_kb"));var ga=Q("cek_status_covid").toLowerCase();ga==="1"&&t(!!c("status_covid"),"Status COVID: pilih jenis COVID","status_covid");var Ye=c("tgl_masuk")||c("tgl_masuk2"),Ze=c("tgl_keluar2")||c("tgl_keluar");if(Ye&&Ze){let ve=function(Qe){let J=Qe.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})(?:\s+(\d{1,2}):(\d{2}):(\d{2}))?/);if(J)return new Date(+J[3],+J[2]-1,+J[1],+(J[4]||0),+(J[5]||0),+(J[6]||0)).getTime();let Xe=Date.parse(Qe);return isNaN(Xe)?0:Xe};var xa=ve;t(ve(Ze)>=ve(Ye),"Tanggal keluar tidak boleh sebelum tanggal masuk","tgl_keluar2")}}function oa(t,i){t(!!c("id_visit"),"Data kunjungan tidak valid","id_visit"),t(!!c("nama_pasien"),"Nama pasien harus diisi","nama_pasien"),i("anamnesa","Anamnesa"),i("catatan","Catatan diagnosa"),i("terapi_pengobatan","Terapi/pengobatan"),["pemeriksaan_fisik","tindakan","planning"].forEach(function(_){let b=c(_);b&&!x(b)&&!_e(b)&&t(!1,(_==="pemeriksaan_fisik"?"Pemeriksaan fisik":_==="planning"?"Planning":"Tindakan")+" tidak boleh hanya berisi simbol atau karakter khusus",_)}),document.querySelectorAll('input[name="kode10[]"]').forEach(function(_,b){let S=(_.value||"").trim(),j=_.closest("tr"),R=(j?.querySelector('input[name="idicd[]"]')?.value||"").trim(),U=(j?.querySelector('input[name="nama[]"]')?.value||"").trim(),N=_.id||`kode10-${b}`;S&&!x(S)&&!F(S)&&t(!1,"Format kode ICD-10 baris "+(b+1)+" tidak valid (contoh: A00, B20.9)",N),(!x(S)||!x(U))&&!R&&!F(S)&&t(!1,"Diagnosa baris "+(b+1)+" harus dipilih dari hasil pencarian (autocomplete)",N)}),document.querySelectorAll('input[name="kode9[]"]').forEach(function(_,b){let S=(_.value||"").trim(),j=_.closest("tr"),R=(j?.querySelector('input[name="idicdTindakan[]"]')?.value||"").trim(),U=(j?.querySelector('input[name="namaTindakan[]"]')?.value||"").trim(),N=_.id||`kode9-${b}`;S&&!x(S)&&!X(S)&&t(!1,"Format kode ICD-9 Tindakan baris "+(b+1)+" tidak valid (contoh: 45.16)",N),(!x(S)||!x(U))&&!R&&!X(S)&&t(!1,"Tindakan baris "+(b+1)+" harus dipilih dari hasil pencarian (autocomplete)",N)});let n=c("tensi");n&&!x(n)&&t(ke(n),"Tekanan darah tidak valid (contoh: 120/80)","tensi");let o=c("nadi");o&&!x(o)&&t(C(o,20,250),"Nadi harus 20-250","nadi");let s=c("suhu");s&&!x(s)&&t(C(s,30,45),"Suhu harus 30-45\xB0C","suhu");let u=c("nafas");u&&!x(u)&&t(C(u,4,80),"Nafas harus 4-80","nafas");let f=c("spo2");f&&!x(f)&&t(C(f,50,100),"SpO2 harus 50-100%","spo2");let k=c("tinggi");k&&!x(k)&&t(C(k,30,250),"Tinggi badan harus 30-250 cm","tinggi");let v=c("berat");v&&!x(v)&&t(C(v,1,500),"Berat badan harus 1-500 kg","berat"),t(!!c("jenis_kasus"),"Jenis kasus harus dipilih","jenis_kasus"),t(!!c("tindak_lanjut"),"Tindak lanjut harus dipilih","tindak_lanjut")}function sa(){document.querySelectorAll(".ext-rv-error").forEach(function(t){t.classList.remove("ext-rv-error")})}function la(t){var i=t[0];let n=document.getElementById(i.id);n&&(n.focus(),n.classList.add("ext-rv-error"),setTimeout(function(){n.classList.remove("ext-rv-error")},3e3));for(var o=1;o<t.length;o++){var s=document.getElementById(t[o].id);s&&(s.classList.add("ext-rv-error"),(function(k){setTimeout(function(){k.classList.remove("ext-rv-error")},3e3)})(s))}for(var u=[],o=0;o<t.length;o++)u.push("\u2022 "+t[o].msg);var f=u.join(`
`);Se({title:"Validasi Gagal ("+t.length+" masalah)",message:f,variant:"warning",okLabel:"OK",hideCancel:!0})}function ua(t){return document.getElementById(t)}function c(t){return ua(t)?.value?.trim()||""}function ce(t,i){let n=c(t);return!!n&&!x(n)&&i(n)}function Q(t){return document.querySelector('input[name="'+t+'"]:checked')?.value||""}function fe(t){return document.querySelector('input[name="'+t+'"]:checked')!==null}function da(t){return document.querySelector(t+":checked")!==null}function ca(t){if(t==="rajal")return;function i(f,k){var v=document.getElementById(f);v&&v.addEventListener("input",function(_){if(!(_&&_.isTrusted===!1)){var b=document.getElementById(k);b&&(b.value="")}})}i("kode_diagnosa_utama","id_diagnosa_utama"),i("diagnosa_utama","id_diagnosa_utama");for(var n=1;n<=10;n++){var o="id_diagnosa_sekunder"+n;i("kode_diagnosa_sekunder"+n,o),i("diagnosa_sekunder"+n,o)}for(var s=1;s<=10;s++){var u="id_tindakan"+s;i("kode_tindakan"+s,u),i("tindakan"+s,u)}}})()})();
