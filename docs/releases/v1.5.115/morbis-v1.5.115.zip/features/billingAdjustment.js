"use strict";var __morbis_feature=void(function(){"use strict";let I="data-ext-billing-adj",x=0,f=null,q=!1;function y(){f!==null&&(clearInterval(f),f=null)}function N(){return document.documentElement.getAttribute(I)==="1"}function i(e){return document.querySelector(e)?.value??""}function o(e){if(!e)return 0;let t=String(e).replace(/[.,](?=\d{3}(?:[.,]|$))/g,"").replace(/[.,](?=\d{1,2}$)/,".");return parseFloat(t)||0}function u(e){return e.toLocaleString("id-ID").replace(/,/g,".")}function s(e,t){let l=e.match(new RegExp("^"+t+"_(\\d+)$"));return l?l[1]:null}function z(){if(document.getElementById("ext-billing-adj-css"))return;let e=document.createElement("style");e.id="ext-billing-adj-css",e.textContent=`
      #totalharga.ext-billing-editable,
      #pembulatanShow.ext-billing-editable,
      #ext-total-jasa.ext-billing-editable {
        background: #fef3c7 !important;
        border: 2px solid #f59e0b !important;
        border-radius: 4px;
        padding: 4px 8px;
        font-weight: 600;
        color: #92400e;
        cursor: text;
        min-width: 100px;
        text-align: right;
      }
      #totalharga.ext-billing-editable:focus,
      #pembulatanShow.ext-billing-editable:focus,
      #ext-total-jasa.ext-billing-editable:focus {
        border-color: #d97706 !important;
        box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.3);
        outline: none;
      }
      .ext-billing-total-display {
        background: #dbeafe !important;
        border: 2px solid #3b82f6 !important;
        border-radius: 4px;
        padding: 4px 8px;
        font-weight: 700;
        color: #1e40af;
        min-width: 120px;
        text-align: right;
        display: inline-block;
      }
      .ext-billing-regen-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 14px;
        background: #2563eb;
        color: #fff;
        border: none;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        margin-left: 8px;
      }
      .ext-billing-regen-btn:hover { background: #1d4ed8; }
      .ext-billing-regen-btn:active { background: #1e40af; }
      .ext-billing-regen-btn svg { width: 14px; height: 14px; }
      .ext-billing-status {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 600;
        margin-left: 8px;
      }
      .ext-billing-status.ok { background: #d1fae5; color: #065f46; }
      .ext-billing-status.warning { background: #fef3c7; color: #92400e; }
      .ext-billing-auto-mode {
        display: inline-block;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: 600;
        margin-left: 4px;
        background: #e0e7ff;
        color: #3730a3;
      }
    `,document.head.appendChild(e)}function S(e,t){document.querySelector(".ext-billing-status")?.remove();let l=document.createElement("span");l.className="ext-billing-status "+t,l.textContent=e;let n=document.querySelector(".ext-billing-regen-btn");n?.parentElement&&n.parentElement.insertBefore(l,n.nextSibling),setTimeout(()=>l.remove(),3e3)}function E(e){let t=o(i("#harga_"+e)),l=o(i("#frekuensi_"+e)),n=o(i("#diskon_"+e)),a=t*l-n,r=document.querySelector("#total_"+e);return r&&(r.value=u(a)),a}function w(){let e=0;return document.querySelectorAll('input[id^="total_"]').forEach(t=>{s(t.id,"total")&&(e+=o(t.value))}),e}function _(){let e=document.querySelectorAll("table");for(let t of Array.from(e))for(let l of Array.from(t.querySelectorAll("tr"))){let n=l.querySelectorAll("td");if(!n.length||n[0].textContent.trim()!=="Total")continue;let a=(n[1]?.textContent??"").match(/Tunai\s*:?\s*([\d.]+)/);if(a)return o(a[1])}return 0}function h(e){let t=document.querySelectorAll("table")[1]?.querySelector("b"),l=document.querySelector("#ext-total-jasa");l?l.value=u(e):t&&(t.textContent=u(e));let n=document.querySelector("#total_billing");n&&(n.value=String(Math.round(e)))}function d(){let e=o(i("#totalharga")),t=o(i("#biaya_adm")),l=o(i("#biaya_materai")),n=o(i("#diskon")),a=o(i("#klaim_bpjs")),r=o(i("#tarik_uang_muka")),p=o(i("#pembulatanShow")),v=o(i("#bayar")),g=e+t+l-n-a+r+p,B=document.querySelector("#total_belum_dibayar");B&&(B.value=String(Math.round(g)));let A=document.querySelector("#pembulatan"),C=document.querySelector("#pembulatanShow");A&&C&&(A.value=C.value);let b=Array.from(document.querySelectorAll("td")).find(c=>c.textContent.trim().toLowerCase()==="total belum dibayar")?.parentElement?.querySelector("td:last-child");if(b&&!b.querySelector("input")){let c=b.querySelector(".ext-billing-total-display");c||(b.textContent="",c=document.createElement("span"),c.className="ext-billing-total-display",b.appendChild(c)),c.textContent=u(g)}let j=Math.max(0,v-g),T=document.querySelector("#kembali2"),M=document.querySelector("#kembali1");T&&(T.value=String(j)),M&&(M.textContent=u(j));let k=Math.max(0,g-v),K=document.querySelector("#sisaTagihan2"),R=document.querySelector("#sisaTagihan1");K&&(K.value=String(k)),R&&(R.textContent=u(k));let D=document.querySelector("#total1");D&&(D.textContent=v>=g?"0":u(k))}function m(e,t){e.dataset.extRtBound!=="1"&&(e.dataset.extRtBound="1",e.addEventListener("input",t),e.addEventListener("keyup",t),e.addEventListener("change",t))}function L(){document.querySelectorAll('input[id^="frekuensi_"]').forEach(a=>{let r=s(a.id,"frekuensi");r&&E(r)});let e=w(),t=document.querySelector("#ext-total-jasa");if(t){t.value=u(e),t.dataset.autoMode="true";let a=document.querySelector("#totaljasa-auto-indicator");a&&(a.style.display="")}h(e);let l=e+_(),n=document.querySelector("#totalharga");n&&(n.value=u(l),n.dataset.original=n.value),d(),S("Regenerated: "+u(l),"ok")}function H(){let e=document.querySelectorAll("table"),t=e[1]?.querySelector("td:last-child"),l=e[1]?.querySelector("b");if(!t||document.querySelector("#ext-total-jasa"))return;let n=document.createElement("input");n.type="text",n.id="ext-total-jasa",n.className="ext-billing-editable",n.value=l?.textContent.trim()??i("#total_billing"),n.dataset.autoMode="true",l?l.replaceWith(n):t.prepend(n);let a=document.createElement("span");a.className="ext-billing-auto-mode",a.textContent="AUTO",a.id="totaljasa-auto-indicator",n.after(a),m(n,()=>{n.dataset.autoMode="false",a.style.display="none",h(o(n.value)),d()}),n.addEventListener("blur",()=>S("Total jasa diupdate","ok")),n.addEventListener("keydown",r=>{r.key==="Enter"&&(r.preventDefault(),n.blur())})}function $(){let e=document.querySelector("#totalharga");!e||e.dataset.extBillingBound==="1"||(e.dataset.extBillingBound="1",e.classList.add("ext-billing-editable"),e.dataset.original=e.value,m(e,()=>{d()}),e.addEventListener("blur",()=>{e.dataset.original=e.value,S("Total diupdate","ok")}),e.addEventListener("keydown",t=>{t.key==="Enter"&&(t.preventDefault(),e.blur())}))}function O(){let e=document.querySelector("#pembulatanShow");!e||e.dataset.extBillingBound==="1"||(e.dataset.extBillingBound="1",e.removeAttribute("readonly"),e.readOnly=!1,e.removeAttribute("disabled"),e.disabled=!1,e.classList.add("ext-billing-editable"),e.dataset.original=e.value,m(e,()=>{d()}),e.addEventListener("blur",()=>{e.dataset.original=e.value}),e.addEventListener("keydown",t=>{t.key==="Enter"&&(t.preventDefault(),e.blur())}))}function F(){if(document.documentElement.dataset.extBillingRows==="1")return;document.documentElement.dataset.extBillingRows="1";let e=t=>{let l=t.target;if(!(l instanceof HTMLInputElement))return;let n=s(l.id,"frekuensi")??s(l.id,"harga")??s(l.id,"diskon");if(!n)return;E(n);let a=w(),r=document.querySelector("#ext-total-jasa");r&&r.dataset.autoMode!=="false"&&(r.value=u(a)),h(a);let p=document.querySelector("#totalharga");p&&(p.value=u(a+_())),d()};document.addEventListener("input",e),document.addEventListener("keyup",e),document.addEventListener("change",e)}function P(){["biaya_adm","biaya_materai","diskon","klaim_bpjs","tarik_uang_muka","bayar"].forEach(t=>{let l=document.querySelector("#"+t);l&&m(l,d)});let e=document.querySelector("#diskon_dalam_persen");e&&m(e,()=>{let t=o(e.value),l=o(i("#totalharga")),n=document.querySelector("#diskon");n&&(n.value=u(l*t/100)),d()})}function W(){if(document.querySelector(".ext-billing-regen-btn"))return;let e=document.querySelector("button");if(!e?.parentElement)return;let t=document.createElement("button");t.type="button",t.className="ext-billing-regen-btn",t.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Regenerate Total',t.addEventListener("click",L),e.parentElement.insertBefore(t,e.nextSibling)}function J(){document.documentElement.dataset.extBillingKeys!=="1"&&(document.documentElement.dataset.extBillingKeys="1",document.addEventListener("keydown",e=>{if(e.ctrlKey&&e.shiftKey&&e.key==="R"&&(e.preventDefault(),L()),e.ctrlKey&&e.shiftKey&&e.key==="T"){e.preventDefault();let t=document.querySelector("#totalharga");t?.focus(),t?.select()}if(e.ctrlKey&&e.shiftKey&&e.key==="P"){e.preventDefault();let t=document.querySelector("#pembulatanShow");t?.focus(),t?.select()}}))}function U(){q||(q=!0,z(),H(),$(),O(),F(),P(),W(),J(),d(),console.log("[BillingAdj] initialized"))}f=window.setInterval(()=>{if(x++,!N()){x>=150&&y();return}document.querySelector("#totalharga")&&document.querySelector("#pembulatanShow")?(y(),U()):x>=150&&y()},100)})();
