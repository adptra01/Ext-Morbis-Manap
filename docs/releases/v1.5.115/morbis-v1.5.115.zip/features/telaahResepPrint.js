"use strict";var __morbis_feature=void(function(){"use strict";async function Q(){let I="ext-telaah-proc",j=document.querySelector(".halaman");if(!j||j.getAttribute(I))return;let d=j;d.setAttribute(I,"1");let c=t=>(t?.textContent||"").replace(/\s+/g," ").trim();function r(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let tt=t=>t?r(t.replace(/^(.*?)(\d+)$/,`$1
$2`)):"-",at=d.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",k="RSUD H. ABDUL MANAP",v=[],R=d.querySelector("#head-cetak-logo");if(R){let t=R.querySelector("b");k=t?c(t):k;let e=document.createElement("div");e.innerHTML=R.innerHTML.replace(/<br\s*\/?>/gi,`
`),v=(e.textContent||"").split(`
`).map(a=>a.trim()).filter(Boolean).filter(a=>a!==k)}let x=new Map,N=[];d.querySelectorAll(".halaman > table:first-of-type table").forEach(t=>{t.querySelectorAll("tr").forEach(e=>{let a=e.querySelectorAll("td");if(a.length<2)return;let n=c(a[0]),s=c(a[1]).replace(/^:\s*/,"");if(n&&!x.has(n)&&x.set(n,s),/^diagnosa$/i.test(n)){let m=(a[1].innerHTML||"").replace(/<br\s*\/?>/gi,`
`),o=document.createElement("div");o.innerHTML=m,N=(o.textContent||"").split(`
`).map(l=>l.trim()).filter(l=>l&&!/^:/.test(l)&&!/tidak ada/i.test(l))}})});let et=t=>x.get(t)??"",y=[],M=Array.from(d.querySelectorAll("table.resep-item"))[1],z="",L="",u=[],T=[],nt="",E="";async function it(){let t=new URLSearchParams(window.location.search),e=t.get("id_resep")||t.get("id")||t.get("penjualan")||"";if(!e)return;let a="/inventory/resep/penerimaan/detail?id="+e;try{let n=await fetch(a,{credentials:"include"});if(!n.ok)return;let s=await n.text(),m=new DOMParser().parseFromString(s,"text/html"),o=i=>(m.querySelector("#"+i)||m.querySelector('input[name="'+i+'"]')||m.querySelector('input[id*="'+i+'"]'))?.value?.trim()||"";z=o("id_visit")||t.get("visit")||z,L=o("id_kunjungan")||L,E=o("no_sep")||E;let l=Array.from(m.querySelectorAll("fieldset#perhatian")).find(i=>{let h=i.querySelector("legend");return h&&/riwayat\s*diagnosa\s*pasien/i.test(c(h))});if(l){let i=Array.from(l.querySelectorAll("li")).map(g=>c(g)).filter(Boolean),h=-1,_=Array.from(l.querySelectorAll("strong, b"));for(let g of _)if(/diagnosa\s*sekunder/i.test(c(g))){let Y=g.closest("li");if(Y){let b=Array.from(l.querySelectorAll("li")).indexOf(Y);b>=0&&(h=b)}else{let b=g.nextElementSibling;if(b&&b.tagName==="OL"){let V=b.querySelector("li");if(V){let G=Array.from(l.querySelectorAll("li")).indexOf(V);G>=0&&(h=G)}}}break}h>=0&&h<i.length?(u=i.slice(0,h),T=i.slice(h).filter(g=>g&&!/tidak ada/i.test(g))):i.length&&(u=i)}}catch{}}function rt(t){let e=o=>typeof o=="string"?o.trim():"",a=e(t.nama_barang),n=e(t.kekuatan),s=e(t.sediaan),m=e(t.satuan);return n&&(a+=(a?" ":"")+n),s&&(a+=(a?", ":"")+s),m&&(a+=(a?" @":"")+m),a}function lt(t){return{NO_R:t.no_r,JENIS_R:t.jenis_r,JENIS_RSP:t.jenis_r,NAMA_RACIKAN:t.nama_racikan,ATURAN_PAKAI_MANUAL:t.aturan_pakai_manual,JUMLAH_RACIKAN:t.jumlah_racikan,NAMA:rt(t),KEKUATAN_R_RACIK:t.kekuatan_r_racik,KEKUATAN:t.kekuatan,JUMLAH_R_PAKAI:t.jumlah_r_pakai,SEDIAAN:t.sediaan,JUMLAH_R_RESEP:t.jumlah_r_resep}}async function ot(t){try{let e=await fetch("/inventory/search?opsi=tabel_penjualan_lama&id_penjualan="+encodeURIComponent(t),{credentials:"include",cache:"no-store"});if(!e.ok)return[];let a=await e.json();return(Array.isArray(a)?a:Object.values(a??{})).filter(n=>typeof n=="object"&&n!==null).map(lt).filter(n=>String(n.NO_R??"").trim()!=="")}catch{return[]}}async function st(){let t=f.get("id_resep")||f.get("id")||f.get("penjualan")||"";if(!t)return[];try{let e=await fetch("/inventory/resep/akses/penerimaan?type=ajax&opsi=data-resep-new&q=1&id="+encodeURIComponent(t),{credentials:"include",cache:"no-store"});if(!e.ok)return[];let a=await e.json(),n=String(a?.ID_PENJUALAN??"").trim();if(n&&n!=="0"){let s=await ot(n);if(s.length)return s}return Array.isArray(a?.resep)?a.resep:[]}catch{return[]}}function mt(t){try{let e=new URL(t);if(e.protocol!=="http:"&&e.protocol!=="https:")return!1;let a=e.hostname.toLowerCase();return["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"].includes(a)?!0:a.endsWith(".rsudkotajambi.id")||a.endsWith(".ddev.site")}catch{return!1}}async function dt(t){try{let e="http://dev.rsudkotajambi.id/rs";try{let s=localStorage.getItem("ext-farmasi-app-base");s&&mt(s)&&(e=s.replace(/\/+$/,""))}catch{}let a=await fetch(e+"/api/queue/lookup?resep_id="+encodeURIComponent(t),{cache:"no-store",credentials:"omit",signal:AbortSignal.timeout(8e3)});if(!a.ok)return"";let n=await a.json();if(n.ok&&n.found&&n.queue?.queue_number)return n.queue.queue_number}catch{}return""}let f=new URLSearchParams(window.location.search),U=f.get("id_resep")||f.get("id")||f.get("penjualan")||"";await it();let D=await st();if(D.length){y.length=0;let t=new Map;for(let e of D){let a=String(e.NO_R??"").trim();a&&(t.has(a)||t.set(a,[]),t.get(a).push(e))}for(let[e,a]of t){let n=a[0],s=String(n.JENIS_R??"").toLowerCase()==="racikan"||String(n.JENIS_RSP??"").toLowerCase()==="racikan",m=String(n.NAMA_RACIKAN??"").trim(),o=String(n.ATURAN_PAKAI_MANUAL??"").trim().replace(/^-\s*/,"").trim();if(s||a.length>1){let l={no:"R/"+e,name:m||"",jml:"",jumlahJadi:String(n.JUMLAH_RACIKAN??"").trim()||"",sediaan:m,aturan:o?[o]:[],subMeds:a.map(i=>({name:String(i.NAMA??"").trim(),strength:String(i.KEKUATAN_R_RACIK??i.KEKUATAN??"").trim(),dose:"",jmlPerR:String(i.JUMLAH_R_PAKAI??"").trim(),sediaan:String(i.SEDIAAN??"").trim()}))};y.push(l)}else{let l={no:"R/"+e,name:String(n.NAMA??"").trim(),jml:String(n.JUMLAH_R_RESEP??n.JUMLAH_R_PAKAI??"").trim(),jumlahJadi:"",sediaan:String(n.SEDIAAN??"").trim(),aturan:o?[o]:[],subMeds:[]};y.push(l)}}}!u.length&&N.length&&(u=N);let K=d.querySelector("#form_checklist_telaah_resep"),C=t=>{let e=[];if(!K)return e;let a=Array.from(K.querySelectorAll("table")).find(n=>c(n.querySelector("tr td"))===t);return a&&a.querySelectorAll("tr").forEach((n,s)=>{if(s===0)return;let m=n.querySelectorAll("td");if(m.length<2)return;let o=c(m[0]),l=c(m[1]);o&&l&&l!==t&&e.push([o,l])}),e},pt=C("Telaah Resep"),ct=C("Telaah Obat"),J=Array.from(d.querySelectorAll("center, strong")).find(t=>/Obat tidak boleh diganti/i.test(c(t))),ht=J?c(J):"Obat tidak boleh diganti tanpa sepengetahuan Dokter",P=(t,e,a="",n="")=>'<div class="tm-row'+(n?" "+n:"")+'"><span class="tm-label">'+r(t)+':</span><span class="tm-val'+(a?" "+a:"")+'">'+(e&&e.trim()?r(e):"-")+"</span></div>",H=[...u.length?[u.join(", ")]:[],...T.length?[T.join(", ")]:[]],p=t=>et(t),w=p("Jenis Kelamin"),gt=/^perempuan$/i.test(w)?"P":/^laki-laki$/i.test(w)?"L":w,ut=(p("Nama Pasien")||"-")+(w?" ("+gt+")":""),ft=(p("Dokter")||"-")+(p("Ruangan/Poli")?" / "+p("Ruangan/Poli"):""),O=t=>{for(let e of x.keys())if(t.test(e))return x.get(e)||"";return""},bt=O(/alergi/i),A=O(/berat|\bbb\b/i),B=A?/\bkg\b/i.test(A)?A:A+" kg":"- kg",xt=(bt||"-")+" / "+(A?"BB "+B:B),At=[["Pasien",ut,""],["No. RM",p("No. RM"),""],["Tgl. Lahir",p("Tgl. Lahir/Umur"),""],["Alergi & BB",xt,""],["Alamat",p("Alamat"),"long"],["No HP",p("No HP"),""]],kt=[["Dokter",ft,""],["SIP Dokter",p("SIP Dokter"),""],["No Resep",p("No Resep"),""],["No SEP",E||"-",""],["Tanggal",p("Tanggal & Jam"),""],["Penjamin",p("Penjamin"),""]],yt=P("Diagnosa",H.length?H.join(", "):"-","","long"),wt='<section class="tm-card tm-card--small tm-card--left"><div class="tm-col">'+At.map(([t,e,a])=>P(t,e,"",a)).join("")+yt+"</div></section>",St='<section class="tm-card tm-card--right"><div class="tm-col">'+kt.map(([t,e,a])=>P(t,e,"",a)).join("")+"</div></section>",_t=y.map(t=>{if(t.subMeds.length){let a=t.subMeds.map((i,h)=>{let _=i.jmlPerR||"";return'<div class="med-line'+(h>0?" indent":"")+'">'+(h===0?'<span class="med-no">'+r(t.no)+"</span> ":"")+'<span class="med-name">'+r(i.name)+"</span>"+(_?', <span class="med-jml">Jml: '+r(_)+"</span>":"")+"</div>"}).join(""),n=t.jumlahJadi?r(t.jumlahJadi):"",s=t.sediaan?r(t.sediaan):"Racikan",m=t.aturan.length?t.aturan.map(i=>r(i.replace(/^\(|\)$/g,""))).join(" "):"",o=n?"Jml "+n+" "+s+(m?" - ("+m+")":""):"",l=o?'<div class="med-jadiracik">'+o+"</div>":"";return'<div class="med">'+a+l+"</div>"}let e=t.jml||"";return'<div class="med"><div class="med-line"><span class="med-no">'+r(t.no)+'</span> <span class="med-name">'+r(t.name)+"</span>"+(e?', <span class="med-jml">Jml: '+r(e)+"</span>":"")+"</div>"+(t.aturan.length?'<div class="med-aturan">'+t.aturan.map(a=>r(a)).join("<br/>")+"</div>":"")+"</div>"}).join(""),S=M?Array.from(M.querySelectorAll("tr:first-child td")).map(t=>c(t)).filter(Boolean):["Hitung","Timbang","Kemas"];S.some(t=>/paraf/i.test(t))||S.push("Paraf");let jt=S.length,vt='<table class="t-admin"><thead><tr>'+S.map(t=>'<th class="l">'+r(t)+"</th>").join("")+"</tr></thead><tbody><tr>"+Array.from({length:jt}).map(()=>'<td class="blk"></td>').join("")+"</tr></tbody></table>",$=(t,e)=>'<table class="t-check"><thead><tr><th class="l" colspan="2">'+r(t)+'</th><th class="yt">Y/T</th></tr></thead><tbody>'+e.map(([a,n])=>'<tr><td class="num">'+r(a)+"</td><td>"+r(n)+'</td><td class="yt"></td></tr>').join("")+"</tbody></table>",Rt='<header class="t-head"><img class="t-logo" alt="Logo" src="'+r(at)+'"/><div class="t-bhead"><h1 class="t-hname">'+r(k)+"</h1>"+(v[0]?'<div class="t-hsub">'+r(v[0])+"</div>":"")+'</div><div class="t-antrian">'+tt(nt)+'</div></header><main class="t-main"><section class="t-left">'+wt+'<div class="t-meds">'+_t+"</div>"+vt+'</section><section class="t-right">'+St+$("Telaah Resep",pt)+$("Telaah Obat",ct)+'<table class="t-check"><thead><tr><th class="c" colspan="2">Perubahan resep</th></tr><tr><th class="c half">Tertulis</th><th class="c half">Menjadi</th></tr></thead><tbody><tr><td class="blk4"></td><td class="blk4"></td></tr><tr><td class="c">Apoteker</td><td class="c">Disetujui Dokter</td></tr><tr><td class="blk4"></td><td class="blk4"></td></tr><tr><td class="c" colspan="2">Waktu Tunggu</td></tr><tr><td class="third">Masuk</td><td></td></tr><tr><td>Diserahkan</td><td></td></tr><tr><td class="twothird">Paraf Pasien/Keluarga</td><td class="blk3"></td></tr></tbody></table></section></main><footer class="t-footer">'+r(ht)+'</footer><div class="t-print no-print"><button type="button" class="t-btn" onclick="window.print()">Cetak</button></div>';if(d.innerHTML=Rt,U){let t=d.querySelector(".t-antrian");dt(U).then(e=>{e&&t&&t.isConnected&&(t.textContent=e.replace(/^(.*?)(\d+)$/,`$1
$2`))})}let F=866;d.scrollHeight>F&&(d.classList.add("compact"),d.offsetHeight,d.scrollHeight>F&&(d.classList.remove("compact"),d.classList.add("ultra")));let W="ext-telaah-style";if(!document.getElementById(W)){let t=document.createElement("style");t.id=W,t.textContent=`
        /* === PRINT CONTRACT: 105mm \xD7 241mm === */
        .halaman{box-sizing:border-box;width:105mm!important;height:auto!important;max-height:241mm;margin:0!important;padding:0 3mm}
        @page{size:105mm 241mm;margin:0}
        .halaman *{box-sizing:border-box;font-size:11px!important}
        .halaman{font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.25;color:#000;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}

        /* HEADER 3 kolom: logo | brand & alamat | no antrian */
        .t-head{display:flex;align-items:center;padding-bottom:6px;border-bottom:1.5px solid #000;margin-bottom:8px;gap:10px}
        .t-logo{width:50px;height:50px;object-fit:contain;object-position:left top;flex:none}
        .t-bhead{flex:1;font-size:11px;min-width:0}
        .t-hname{font-size:12px;font-weight:800;margin:0 0 2px;letter-spacing:-.01em}
        .t-hsub{line-height:1.2;font-size:10px}
        .t-antrian{flex:none;text-align:right;font-size:36px!important;font-weight:800;color:#198754;letter-spacing:-.02em;font-variant-numeric:tabular-nums;min-width:0;overflow-wrap:anywhere;line-height:1;white-space:pre-line}

        /* METADATA \u2014 grid: label kiri, nilai kanan (efisien tinggi) */
        .tm-card{background:#fff;padding:2px 0 4px;margin-bottom:4px;font-size:11px;border-bottom:0.5pt solid #333}
        .tm-card--small .tm-label{font-size:9px!important}
        .tm-card--small .tm-val{font-size:10px!important}
        .tm-col{display:flex;flex-direction:column;gap:3px}
        .tm-row{display:grid;grid-template-columns:35% 65%;column-gap:4px;align-items:start}
        .tm-card--left .tm-row{grid-template-columns:20% 65%}
        .tm-card--right .tm-row{grid-template-columns:30% 65%}
        .tm-label{color:#5b6470;font-size:10px;line-height:1.25;text-align:left}
        .tm-val{color:#000;line-height:1.25;word-wrap:break-word;overflow-wrap:anywhere}
        /* field panjang (alamat, diagnosa) tetap di grid 2 kolom biar wrap di kanan */
        .tm-row.long{display:grid}
        .tm-row.long .tm-label{display:block}

        /* MAIN 2 kolom \u2014 kiri lebih lebar utk nama obat */
        .t-main{display:grid;grid-template-columns:62% 38%;gap:6px;align-items:start}
        .t-left,.t-right{display:flex;flex-direction:column;gap:5px;min-width:0}
        .t-right .t-check{margin-bottom:0}
        .t-meds{margin-bottom:8px;font-size:11px;min-width:0}

        /* DAFTAR OBAT */
        .med{margin-bottom:6px}
        .med-line{font-size:11px;line-height:1.35;text-align:left}
        .med-line.indent{margin-left:0}
        .med-no{font-weight:400}
        .med-name{font-weight:600}
        .med-sep{color:#374151}
        .med-jml{white-space:nowrap;font-weight:600;color:#047857}
        .med-aturan{margin-left:0;font-size:10px;color:#374151;margin-top:1px}
        .med-jadiracik{margin-top:3px;padding-top:1px;font-size:11px;font-weight:700}

        /* TABEL \u2014 checklist (font sama dengan info pasien & dokter = 10px) */
        table{width:100%;border-collapse:collapse;font-size:10px}
        .halaman th,.halaman td{border:0.5pt solid #333;padding:1px 3px;font-weight:400;font-size:10px!important;line-height:1.2}
        thead th{font-weight:400}
        .yt{width:32px;text-align:center}
        .num{width:16px;text-align:center}
        .l{text-align:left}
        .c{text-align:center}
        .half{width:50%}
        .third{width:33.333%}
        .twothird{width:66.667%}
        .blk{height:40px;padding:.5pt 3px}
        .blk2{min-height:10px}
        .blk3{min-height:35px}
        .blk4{height:40px;padding:.5pt 3px}
        .t-sub{text-align:center;font-size:10px!important;margin:3px 0}

        /* FOOTER + BUTTON */
        .t-footer{margin-top:10px;text-align:center;font-weight:700;font-style:italic;font-size:11px}
        .t-print{margin-top:24px;display:flex;gap:8px}
        .t-btn{border:1px solid #d1d5db;background:#fff;border-radius:6px;padding:6px 14px;font-size:11px;cursor:pointer}
        .t-btn:hover{background:#f9fafb}
        @media print{.no-print{display:none!important}}

        /* === ADAPTIVE DENSITY (gentle fallback) === */
        .halaman.compact .t-head{padding-bottom:4px;margin-bottom:6px;gap:8px}
        .halaman.compact .t-logo{width:45px;height:45px}
        .halaman.compact .t-hname{font-size:11px!important}
        .halaman.compact .t-antrian{font-size:30px!important}
        .halaman.compact .tm-card{padding:1px 0 2px;margin-bottom:2px}
        .halaman.compact .tm-col{gap:2px}
        .halaman.compact .tm-label{font-size:9px!important}
        .halaman.compact .tm-val{font-size:10px!important}
        .halaman.compact .t-main{gap:4px}
        .halaman.compact .t-left,.halaman.compact .t-right{gap:3px}
        .halaman.compact .t-meds{margin-bottom:4px}
        .halaman.compact .med{margin-bottom:3px}
        .halaman.compact .blk{height:30px}
        .halaman.compact .blk3{min-height:25px}
        .halaman.compact .blk4{height:30px}
        .halaman.compact .t-footer{margin-top:6px}

        .halaman.ultra .t-head{padding-bottom:3px;margin-bottom:4px;gap:6px}
        .halaman.ultra .t-logo{width:40px;height:40px}
        .halaman.ultra .t-hname{font-size:10px!important}
        .halaman.ultra .t-antrian{font-size:26px!important}
        .halaman.ultra .tm-card{padding:1px 0;margin-bottom:1px}
        .halaman.ultra .tm-col{gap:1px}
        .halaman.ultra .tm-label{font-size:8px!important}
        .halaman.ultra .tm-val{font-size:9px!important}
        .halaman.ultra .t-main{gap:3px}
        .halaman.ultra .t-left,.halaman.ultra .t-right{gap:2px}
        .halaman.ultra .t-meds{margin-bottom:2px}
        .halaman.ultra .med{margin-bottom:2px}
        .halaman.ultra .med-line{font-size:10px!important}
        .halaman.ultra .blk{height:30px}
        .halaman.ultra .blk3{min-height:20px}
        .halaman.ultra .blk4{height:30px}
        .halaman.ultra .t-footer{margin-top:4px;font-size:10px!important}
      `,document.head.appendChild(t)}}let X=Q,Z=Date.now(),q=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-telaah")==="1"?(window.clearInterval(q),X()):Date.now()-Z>5e3&&window.clearInterval(q)},200)})();
