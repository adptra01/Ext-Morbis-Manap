"use strict";var __morbis_feature=(()=>{function A(e){return new Promise((n,a)=>{chrome.runtime.sendMessage(e,r=>{chrome.runtime.lastError?a(chrome.runtime.lastError):n(r)})})}var C="http://dev.rsudkotajambi.id/rs",L=null,m=null;async function I(){try{return((await chrome.storage.sync.get("extensionCustomUrls")).extensionCustomUrls??[]).filter(e=>e.url&&e.enabled!==!1).map(e=>e.url.replace(/\/+$/,"")+"/rs")}catch{return[]}}var R=["http://dev.rsudkotajambi.id/rs","http://103.147.236.138/rs"],j=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],B=[".rsudkotajambi.id",".ddev.site"];function M(e){try{let n=new URL(e);if(n.protocol!=="http:"&&n.protocol!=="https:")return!1;let a=n.hostname.toLowerCase();return j.includes(a)?!0:B.some(r=>a.endsWith(r))}catch{return!1}}async function z(e,n,a){return A({type:"QUEUE_API",url:e,method:n,body:a})}function U(e,n){return new Promise((a,r)=>{let o=setTimeout(()=>r(new Error("timeout")),n);e.then(t=>{clearTimeout(o),a(t)}).catch(t=>{clearTimeout(o),r(t)})})}function x(){return m||(m=(async()=>{try{let a=localStorage.getItem("ext-farmasi-app-base");if(a&&M(a))return a.replace(/\/+$/,"")}catch{}let e=await I(),n=[...new Set([...e,...R])];for(let a of n)try{let r=await U(z(a+"/api/queue/lookup?resep_id=probe","GET"),2500),o=r.contentType||"";if((r.status===200||r.status===422)&&o.includes("application/json"))return L=a,a}catch{}return C})(),m)}var g="";async function h(e){try{let n={...e};if(e.event==="ENQUEUE"&&delete n.queue_number,e.event==="BATAL"&&!e.queue_number)return console.warn("[MORBIS Ext] BATAL tanpa queue_number \u2014 dilewati"),{ok:!1};let a=await x(),r=new AbortController,o=setTimeout(()=>r.abort(),8e3),t=await fetch(a+"/api/queue/events",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(n),cache:"no-store",credentials:"omit",signal:r.signal});if(clearTimeout(o),!t.ok){let l="";try{l=(await t.json())?.message||""}catch{}throw new Error("HTTP "+t.status+(l?" \u2014 "+l:""))}let i=await t.json();return{ok:!!i.ok,queue_number:i.queue?.queue_number,created:i.created,duplicate:i.duplicate}}catch(n){let a=n.message;return a!==g&&(console.warn("[MORBIS Ext] queue sync gagal:",a),g=a),await O(e),{ok:!1}}}var d="ext-queue-retry-queue",P=20;async function O(e){try{let n=(await chrome.storage.local.get(d))[d]??[];if(n.some(a=>a.event_id===e.event_id))return;n.push(e),n.length>P&&n.shift(),await chrome.storage.local.set({[d]:n}),console.log("[MORBIS Ext] disimpan ke retry queue:",e.event,e.queue_number??"")}catch{}}async function $(){try{return(await chrome.storage.local.get(d))[d]??[]}catch{return[]}}async function y(e){try{let n=((await chrome.storage.local.get(d))[d]??[]).filter(a=>a.event_id!==e);await chrome.storage.local.set({[d]:n})}catch{}}async function H(){let e=await $();if(e.length)for(let n of[...e])try{(await N(n)).ok&&(await y(n.event_id),console.log("[MORBIS Ext] retry queue sukses:",n.event,n.queue_number??""))}catch(a){let r=a.message??"";(r.includes("HTTP 404")||r.includes("HTTP 422"))&&(await y(n.event_id),console.log("[MORBIS Ext] retry queue buang (stale):",n.event,n.queue_number??"",r))}}async function N(e){let n={...e};e.event==="ENQUEUE"&&delete n.queue_number;let a=await x(),r=new AbortController,o=setTimeout(()=>r.abort(),8e3),t=await fetch(a+"/api/queue/events",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(n),cache:"no-store",credentials:"omit",signal:r.signal});if(clearTimeout(o),!t.ok)throw new Error("HTTP "+t.status);let i=await t.json();return{ok:!!i.ok,queue_number:i.queue?.queue_number}}setInterval(()=>{H()},1e4);function w(e,n,a){return`${e}-${n}-${a}-${new Date().toISOString().slice(0,10)}`}function D(e,n=5e3){let a=document.documentElement,r=Date.now(),o=window.setInterval(()=>{a.getAttribute("data-ext-antrian-farmasi")==="1"?(window.clearInterval(o),e()):Date.now()-r>n&&(window.clearInterval(o),F())},200)}function F(){if(!document.body||document.getElementById("ext-feature-gate-notif"))return;let e=document.createElement("div");e.id="ext-feature-gate-notif",e.textContent="\u26A0\uFE0F Fitur antrian tidak aktif \u2014 muat ulang halaman (F5)",e.style.cssText="position:fixed;top:8px;right:8px;z-index:999999;background:#dc3545;color:#fff;padding:8px 16px;border-radius:6px;font:13px system-ui,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.2);",document.body.appendChild(e),setTimeout(()=>e.remove(),1e4)}var k="ext-batch-shared-style";function X(){if(document.getElementById(k))return;let e=document.createElement("style");e.id=k,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function K(e){return new Promise(n=>{X();let a=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",r=document.createElement("div");r.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",r.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${a}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,r.querySelector("h3").textContent=e.title;let o=r.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((s,c)=>{c>0&&o.appendChild(document.createElement("br")),o.appendChild(document.createTextNode(s))});let t=s=>{r.remove(),document.removeEventListener("keydown",i),n(s)},i=s=>{s.key==="Escape"&&t(!1)};r.querySelector(".ext-modal-close").addEventListener("click",()=>t(!1)),r.addEventListener("click",s=>{s.target===r&&t(!1)}),r.querySelector("[data-ext-ok]").addEventListener("click",()=>t(!0));let l=r.querySelector("[data-ext-cancel]");l&&l.addEventListener("click",()=>t(!1)),document.addEventListener("keydown",i),document.body.appendChild(r)})}var G="RSUD H. Abdul Manap";function v(e){let n=window.open("","_blank","width=400,height=560");if(!n)return K({title:"Popup Diblokir",message:"Izinkan popup untuk mencetak.",variant:"warning",okLabel:"OK",hideCancel:!0}),!1;let a=e.jenis||e.unit?`<div style="font-size:16px;margin-top:2px;">${[e.jenis,e.unit].filter(Boolean).join(" \xB7 ")}</div>`:"",r=e.tglLahir?`<div style="font-size:13px;margin-top:4px;color:#555;">${e.tglLahir}</div>`:"";return n.document.write('<html><head><title>Antrian Farmasi</title></head><body style="width:320px;padding-top:10px;font-family:Arial,Helvetica,sans-serif;text-align:center;"><div style="font-size:16px;font-weight:bold;text-transform:uppercase;">'+G+`</div><div style="font-size:14px;margin-top:2px;">Antrian Farmasi</div><div style="margin-top:14px;"><div style="font-size:110px;font-weight:900;letter-spacing:-2px;line-height:1;">${e.code}</div></div><div style="font-size:20px;font-weight:bold;margin-top:10px;">${e.nama}</div>`+r+a+`<div style="font-size:11px;margin-top:10px;color:#333;">${e.tanggal}</div><div style="font-size:13px;margin-top:14px;color:#555;">Silakan menunggu panggilan</div></body></html>`),n.document.close(),window.setTimeout(()=>{try{n.focus(),n.print()}catch{}},300),!0}var Q="/v2/antrol/search",J="sub=update_v2",W="/public/antrian-farmasi-v2/list-antrian-v2";async function V(e){try{let n=await fetch(await x()+"/api/queue/lookup?resep_id="+encodeURIComponent(e),{cache:"no-store",credentials:"omit"});if(!n.ok)return null;let a=await n.json();return!a.ok||!a.found||!a.queue?.queue_number?null:{queue_number:a.queue.queue_number,status:a.queue.status??""}}catch{return null}}async function S(e){let n=[e.get("id_resep")||"",e.get("id_resep","nomor_resep")||"",new URLSearchParams(location.search).get("id")??""].filter(a=>a&&a.length>=3);for(let a of n){let r=await V(a);if(r)return r}return null}function Y(e){if(e==="DIBATALKAN")return!0;try{let n=(document.querySelector("#isi, .card, .panel, .form-horizontal, form, table")||document.body).querySelectorAll("span, b, strong, td, .label, .badge, h3, h4");for(let a of n){let r=(a.textContent||"").trim();if(/^(batal|dibatalkan|resep batal|sudah dibatalkan)$/i.test(r)&&!a.closest("button, input, a"))return!0}}catch{}return!1}async function Z(e){return fetch(`${Q}?${J}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`id=${encodeURIComponent(e)}&taskid=6`,credentials:"include"}).then(n=>(console.log("[MORBIS Ext] antrian terdaftar id="+e,"status",n.status),!0)).catch(n=>(console.warn("[MORBIS Ext] gagal mendaftarkan antrian",n),!1))}async function ee(e,n){try{let a=await fetch(W,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:"type=check_antrian",cache:"no-store",credentials:"include"});if(!a.ok)return null;let r=await a.json();if(!Array.isArray(r))return null;let o=String(n??"").slice(0,16);return r.find(t=>String(t.ID_PASIEN??"")===String(e)&&(!o||String(t.WAKTU??"").slice(0,16)===o))??r.find(t=>String(t.ID_PASIEN??"")===String(e))??null}catch{return null}}async function te(e,n,a,r){if(!await Z(e))throw new Error("gagal antrol MORBIS");let o=r.get("id_pasien")||new URLSearchParams(location.search).get("norm")||"",t=r.get("waktu_pengajuan"),i=r.namaPasien(),l=a==="racik"?"racikan":"tunggal",s=(async()=>{for(let _=0;_<3;_++){let T=await ee(o,t);if(T)return T;await new Promise(ue=>setTimeout(ue,200))}return null})(),c=h({event_id:w("enq",e,e+"-"+l)+"-"+Date.now().toString(36),event:"ENQUEUE",resep_id:n,nama_pasien:i,norm:o||void 0,tgl_lahir:r.tglLahir()||void 0,shift:"",jenis:l,counter:"",payload:{idVisit:e,unit:"",waktu:t||""}}),[ce,q]=await Promise.all([s,c]);if(!q.ok)throw new Error("gagal terhubung App Antrian");let b=q.queue_number||"";if(!b)throw new Error("nomor antrian belum terbit");return v({nomorResep:n,nama:i,jenis:l,unit:String(ce?.NAMA_UNIT??""),tanggal:t?t.slice(0,10):"",code:b,tglLahir:r.tglLahir()}),b}async function ne(e,n,a){let r=w("bat",n,e)+"-"+Date.now().toString(36);return(await h({event_id:r,event:"BATAL",queue_number:e,resep_id:n})).ok?{ok:!0,gone:!1}:await S(a)?{ok:!1,gone:!1}:{ok:!0,gone:!0}}function ae(e,n,a,r="",o="",t=""){v({nomorResep:e,nama:a.namaPasien(),jenis:r,unit:o,tanggal:t,code:n,tglLahir:a.tglLahir()})}if(window.__extPenjualanAntrian)throw new Error("skip double inject penjualanResepAntrian");window.__extPenjualanAntrian=!0;var E=new URLSearchParams(location.search),re=E.get("visit")??"",oe=E.get("id")??"";function ie(){let e=document.querySelector("#nama_pasien")?.value?.trim();if(e)return e.toUpperCase();let n=document.querySelector("#nama")?.value?.trim();if(n)return n.toUpperCase();let a=Array.from(document.querySelectorAll("th, td, label, strong, b, span"));for(let t of a){let i=(t.textContent||"").trim();if(!/^nama\s*pasien$/i.test(i))continue;let l=t.nextElementSibling||t.parentElement?.querySelector("input, select")||t.parentElement?.nextElementSibling,s=(l?.textContent||l?.value||"").trim();if(s)return s.toUpperCase()}let r=/(resep|penjualan|antrian|farmasi|penerimaan|pendaftaran|detail|edit|input|rekap|daftar|shift|cetak|pembayaran|penyerahan|racik|racikan|obat|kasir|pilih|aturan|pakai|dosis|jumlah|satuan|harga|total|biaya|unit|depo|kekuatan|tipe|standar|kronis|klaim|inacbgs|batch|aksi|tambah|selesai|hapus|kembali|simpan)/i,o=Array.from(document.querySelectorAll("h1, h2, h3, .page-title, .card-title"));for(let t of o){if(t.closest('.modal, .modal-header, .modal-body, .dropdown, .dropdown-menu, [role="dialog"]'))continue;let i=(t.textContent||"").trim();if(!(!i||i.length<4||i.length>60||r.test(i)||i.split(/\s+/).filter(Boolean).length<2))return i.toUpperCase()}return""}function le(){let e=document.querySelector("#tgl_lahir")?.value?.trim();if(e)return e;let n=document.querySelectorAll("tr");for(let a of n){let r=a.querySelectorAll("td");for(let o=0;o<r.length-1;o++)if(/^tanggal\s*lahir$/i.test(r[o].textContent?.trim()||"")&&r[o+1]){let t=r[o+1].textContent?.trim();if(t&&t!==":")return t}}return""}function u(e,n){if(e){let a=document.querySelector("#"+e)?.value?.trim()||"";if(a)return a}if(n){let a=document.querySelector('input[name="'+n+'"]')?.value?.trim()||"";if(a)return a}return e==="id_resep"?oe:e==="id_visit"?re:""}var f={get:u,namaPasien:ie,tglLahir:le};function p(e,n){let a=document.querySelector("#ext-antrian-bar");if(!a)return;let r=u("nomor_resep","id_resep");if(e==="issued"&&n){a.innerHTML='<div style="display: flex; flex-direction: column; align-items: flex-start; width: 100%; gap: 6px;"><span style="font-size:18px;font-weight:800;color:#198754;line-height:1.3;">\u2713 Sudah antri \u2014 '+n+'</span><div style="display: flex; gap: 6px;"><button id="ext-antrian-cetak" class="btn" style="margin:0;background:#6c757d;color:#fff;border-color:#6c757d;" title="Cetak ulang kartu tanpa mengantrikan lagi">Cetak Kembali</button><button id="ext-antrian-batal" class="btn" style="margin:0;background:#dc3545;color:#fff;border-color:#dc3545;" title="Hapus antrian dari DB \u2014 resep bisa di-antrikan ulang">Batal antrian</button></div></div>',a.querySelector("#ext-antrian-cetak")?.addEventListener("click",()=>{if(r)try{ae(r,n||"",f)}catch{}}),a.querySelector("#ext-antrian-batal")?.addEventListener("click",async()=>{if(!confirm("Batalkan antrian "+n+"? Resep akan keluar dari daftar panggilan."))return;let t=a.querySelector("#ext-antrian-batal");if(t&&(t.disabled=!0,t.textContent="Membatalkan\u2026"),!(await ne(n||"",r,f)).ok){alert("[MORBIS Ext] Gagal membatalkan antrian. Coba lagi."),t&&(t.disabled=!1,t.textContent="Batal antrian");return}p("ready")});return}a.innerHTML='<button id="ext-antrian-racik" class="btn" style="margin:2px 6px 2px 0;background:#d97706;color:#fff;border-color:#d97706;" title="Antrikan sebagai obat RACIKAN (nomor R-XX)">Antrikan obat racik</button><button id="ext-antrian-tunggal" class="btn" style="margin:2px 0;background:#2193cf;color:#fff;border-color:#2193cf;" title="Antrikan sebagai obat TUNGGAL (nomor T-XX)">Antrikan obat tunggal</button>';let o=t=>{let i=u("id_visit"),l=u("id_resep","nomor_resep");if(!i||!l){alert("[MORBIS Ext] data resep belum dimuat. Coba lagi.");return}let s=document.querySelector(t==="racik"?"#ext-antrian-racik":"#ext-antrian-tunggal");s&&(s.disabled=!0,s.textContent="Memproses\u2026"),te(i,l,t,f).then(c=>p("issued",c)).catch(c=>alert("[MORBIS Ext] "+(c?.message||"gagal mengantrikan"))).finally(()=>{s&&(s.disabled=!1,s.textContent=t==="racik"?"Antrikan obat racik":"Antrikan obat tunggal")})};a.querySelector("#ext-antrian-racik")?.addEventListener("click",()=>o("racik")),a.querySelector("#ext-antrian-tunggal")?.addEventListener("click",()=>o("tunggal"))}function se(){let e=()=>{if(!document.body)return null;let a=Array.from(document.querySelectorAll('td[valign="top"]')).find(t=>t.querySelector('fieldset#perhatian, fieldset[id="perhatian"]'));if(a){let t=document.createElement("fieldset");t.id="ext-antrian-fieldset",t.style.cssText="margin-top:6px;",t.innerHTML="<legend>Antrian Farmasi</legend>";let i=document.createElement("div");return i.id="ext-antrian-bar",i.style.cssText="display:flex;flex-wrap:wrap;align-items:center;",t.appendChild(i),a.appendChild(t),i}let r=document.querySelector("form");if(r){let t=document.createElement("fieldset");t.id="ext-antrian-fieldset",t.style.cssText="margin-top:6px;",t.innerHTML="<legend>Antrian Farmasi</legend>";let i=document.createElement("div");i.id="ext-antrian-bar",i.style.cssText="display:flex;flex-wrap:wrap;align-items:center;",t.appendChild(i);let l=r.querySelector('button[type="submit"], input[type="submit"]');return l?l.parentElement?.insertBefore(t,l):r.prepend(t),i}let o=document.querySelector(".card-body, .panel-body, .form-horizontal");if(o){let t=document.createElement("fieldset");t.id="ext-antrian-fieldset",t.style.cssText="margin-top:6px;",t.innerHTML="<legend>Antrian Farmasi</legend>";let i=document.createElement("div");return i.id="ext-antrian-bar",i.style.cssText="display:flex;flex-wrap:wrap;align-items:center;",t.appendChild(i),o.prepend(t),i}if(!document.getElementById("ext-antrian-fieldset")){let t=document.createElement("div");return t.id="ext-antrian-fieldset",t.style.cssText="position:fixed;top:60px;right:12px;z-index:9999;background:#fff;border:1px solid #ccc;border-radius:8px;padding:8px;box-shadow:0 2px 8px rgba(0,0,0,.15);",t.innerHTML='<legend style="font-weight:700;margin-bottom:4px;display:block;">Antrian Farmasi</legend><div id="ext-antrian-bar" style="display:flex;flex-wrap:wrap;align-items:center;"></div>',document.body.appendChild(t),t.querySelector("#ext-antrian-bar")}return null},n=()=>{let a=document.querySelector("#ext-antrian-bar")||e();if(!a)return;let r=o=>{if(!u("id_resep","nomor_resep")){o<10?window.setTimeout(()=>r(o+1),800):p("ready");return}S(f).then(t=>{if(Y(t?.status)){a.innerHTML='<span style="color:#b02a37;font-weight:700;">Resep dibatalkan \u2014 antrian tidak tersedia</span>';return}t?p("issued",t.queue_number):o<10?window.setTimeout(()=>r(o+1),800):p("ready")})};r(0)};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",n,{once:!0}):n(),window.setTimeout(n,2e3),window.setTimeout(n,5e3)}D(()=>{de(),se()});function de(){let e=(o,t)=>String(o??"").includes("/v2/antrol/search")&&String(o??"").includes("sub=update_v2")&&String(t??"").includes("taskid=6"),n=XMLHttpRequest.prototype.open,a=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(o,t,...i){return this.__extUrl=String(t),n.apply(this,[o,t,...i])},XMLHttpRequest.prototype.send=function(o){if(e(this.__extUrl,o)){console.log("[MORBIS Ext] antrol otomatis diblokir (pakai tombol Antrian & Cetak)");return}return a.apply(this,[o])};let r=window.fetch.bind(window);window.fetch=((o,t)=>{let i=typeof o=="string"?o:o instanceof URL?o.toString():o.url;return e(i,t?.body)?(console.log("[MORBIS Ext] antrol otomatis diblokir (pakai tombol Antrian & Cetak)"),Promise.resolve(new Response(null,{status:200}))):r(o,t)})}})();
