"use strict";var __morbis_feature=(()=>{function A(e){return new Promise((t,n)=>{chrome.runtime.sendMessage(e,a=>{chrome.runtime.lastError?n(chrome.runtime.lastError):t(a)})})}var T="http://dev.rsudkotajambi.id/rs",C=null,m=null;async function L(){try{return((await chrome.storage.sync.get("extensionCustomUrls")).extensionCustomUrls??[]).filter(e=>e.url&&e.enabled!==!1).map(e=>e.url.replace(/\/+$/,"")+"/rs")}catch{return[]}}var I=["http://dev.rsudkotajambi.id/rs","http://103.147.236.138/rs"],R=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],j=[".rsudkotajambi.id",".ddev.site"];function B(e){try{let t=new URL(e);if(t.protocol!=="http:"&&t.protocol!=="https:")return!1;let n=t.hostname.toLowerCase();return R.includes(n)?!0:j.some(a=>n.endsWith(a))}catch{return!1}}async function M(e,t,n){return A({type:"QUEUE_API",url:e,method:t,body:n})}function U(e,t){return new Promise((n,a)=>{let o=setTimeout(()=>a(new Error("timeout")),t);e.then(r=>{clearTimeout(o),n(r)}).catch(r=>{clearTimeout(o),a(r)})})}function b(){return m||(m=(async()=>{try{let n=localStorage.getItem("ext-farmasi-app-base");if(n&&B(n))return n.replace(/\/+$/,"")}catch{}let e=await L(),t=[...new Set([...e,...I])];for(let n of t)try{let a=await U(M(n+"/api/queue/lookup?resep_id=probe","GET"),2500),o=a.contentType||"";if((a.status===200||a.status===422)&&o.includes("application/json"))return C=n,n}catch{}return T})(),m)}var g="";async function h(e){try{let t={...e};if(e.event==="ENQUEUE"&&delete t.queue_number,e.event==="BATAL"&&!e.queue_number)return console.warn("[MORBIS Ext] BATAL tanpa queue_number \u2014 dilewati"),{ok:!1};let n=await b(),a=new AbortController,o=setTimeout(()=>a.abort(),8e3),r=await fetch(n+"/api/queue/events",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t),cache:"no-store",credentials:"omit",signal:a.signal});if(clearTimeout(o),!r.ok){let s="";try{s=(await r.json())?.message||""}catch{}throw new Error("HTTP "+r.status+(s?" \u2014 "+s:""))}let i=await r.json();return{ok:!!i.ok,queue_number:i.queue?.queue_number,created:i.created,duplicate:i.duplicate}}catch(t){let n=t.message;return n!==g&&(console.warn("[MORBIS Ext] queue sync gagal:",n),g=n),await P(e),{ok:!1}}}var d="ext-queue-retry-queue",z=20;async function P(e){try{let t=(await chrome.storage.local.get(d))[d]??[];if(t.some(n=>n.event_id===e.event_id))return;t.push(e),t.length>z&&t.shift(),await chrome.storage.local.set({[d]:t}),console.log("[MORBIS Ext] disimpan ke retry queue:",e.event,e.queue_number??"")}catch{}}async function O(){try{return(await chrome.storage.local.get(d))[d]??[]}catch{return[]}}async function y(e){try{let t=((await chrome.storage.local.get(d))[d]??[]).filter(n=>n.event_id!==e);await chrome.storage.local.set({[d]:t})}catch{}}async function $(){let e=await O();if(e.length)for(let t of[...e])try{(await H(t)).ok&&(await y(t.event_id),console.log("[MORBIS Ext] retry queue sukses:",t.event,t.queue_number??""))}catch(n){let a=n.message??"";(a.includes("HTTP 404")||a.includes("HTTP 422"))&&(await y(t.event_id),console.log("[MORBIS Ext] retry queue buang (stale):",t.event,t.queue_number??"",a))}}async function H(e){let t={...e};e.event==="ENQUEUE"&&delete t.queue_number;let n=await b(),a=new AbortController,o=setTimeout(()=>a.abort(),8e3),r=await fetch(n+"/api/queue/events",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t),cache:"no-store",credentials:"omit",signal:a.signal});if(clearTimeout(o),!r.ok)throw new Error("HTTP "+r.status);let i=await r.json();return{ok:!!i.ok,queue_number:i.queue?.queue_number}}setInterval(()=>{$()},1e4);function w(e,t,n){return`${e}-${t}-${n}-${new Date().toISOString().slice(0,10)}`}function N(e,t=5e3){let n=document.documentElement,a=Date.now(),o=window.setInterval(()=>{n.getAttribute("data-ext-antrian-farmasi")==="1"?(window.clearInterval(o),e()):Date.now()-a>t&&(window.clearInterval(o),D())},200)}function D(){if(!document.body||document.getElementById("ext-feature-gate-notif"))return;let e=document.createElement("div");e.id="ext-feature-gate-notif",e.textContent="\u26A0\uFE0F Fitur antrian tidak aktif \u2014 muat ulang halaman (F5)",e.style.cssText="position:fixed;top:8px;right:8px;z-index:999999;background:#dc3545;color:#fff;padding:8px 16px;border-radius:6px;font:13px system-ui,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.2);",document.body.appendChild(e),setTimeout(()=>e.remove(),1e4)}var k="ext-batch-shared-style";function F(){if(document.getElementById(k))return;let e=document.createElement("style");e.id=k,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function X(e){return new Promise(t=>{F();let n=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",a=document.createElement("div");a.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",a.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${n}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,a.querySelector("h3").textContent=e.title;let o=a.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((l,c)=>{c>0&&o.appendChild(document.createElement("br")),o.appendChild(document.createTextNode(l))});let r=l=>{a.remove(),document.removeEventListener("keydown",i),t(l)},i=l=>{l.key==="Escape"&&r(!1)};a.querySelector(".ext-modal-close").addEventListener("click",()=>r(!1)),a.addEventListener("click",l=>{l.target===a&&r(!1)}),a.querySelector("[data-ext-ok]").addEventListener("click",()=>r(!0));let s=a.querySelector("[data-ext-cancel]");s&&s.addEventListener("click",()=>r(!1)),document.addEventListener("keydown",i),document.body.appendChild(a)})}var K="RSUD H. Abdul Manap";function v(e){let t=window.open("","_blank","width=400,height=560");if(!t)return X({title:"Popup Diblokir",message:"Izinkan popup untuk mencetak.",variant:"warning",okLabel:"OK",hideCancel:!0}),!1;let n=e.jenis||e.unit?`<div style="font-size:16px;margin-top:2px;">${[e.jenis,e.unit].filter(Boolean).join(" \xB7 ")}</div>`:"",a=e.tglLahir?`<div style="font-size:13px;margin-top:4px;color:#555;">${e.tglLahir}</div>`:"";return t.document.write('<html><head><title>Antrian Farmasi</title></head><body style="width:320px;padding-top:10px;font-family:Arial,Helvetica,sans-serif;text-align:center;"><div style="font-size:16px;font-weight:bold;text-transform:uppercase;">'+K+`</div><div style="font-size:14px;margin-top:2px;">Antrian Farmasi</div><div style="margin-top:14px;"><div style="font-size:110px;font-weight:900;letter-spacing:-2px;line-height:1;">${e.code}</div></div><div style="font-size:20px;font-weight:bold;margin-top:10px;">${e.nama}</div>`+a+n+`<div style="font-size:11px;margin-top:10px;color:#333;">${e.tanggal}</div><div style="font-size:13px;margin-top:14px;color:#555;">Silakan menunggu panggilan</div></body></html>`),t.document.close(),window.setTimeout(()=>{try{t.focus(),t.print()}catch{}},300),!0}var Q="/v2/antrol/search",G="sub=update_v2",J="/public/antrian-farmasi-v2/list-antrian-v2";async function W(e){try{let t=await fetch(await b()+"/api/queue/lookup?resep_id="+encodeURIComponent(e),{cache:"no-store",credentials:"omit"});if(!t.ok)return null;let n=await t.json();return!n.ok||!n.found||!n.queue?.queue_number?null:{queue_number:n.queue.queue_number,status:n.queue.status??""}}catch{return null}}async function S(e){let t=[e.get("id_resep")||"",e.get("id_resep","nomor_resep")||"",new URLSearchParams(location.search).get("id")??""].filter(n=>n&&n.length>=3);for(let n of t){let a=await W(n);if(a)return a}return null}function V(e){if(e==="DIBATALKAN")return!0;try{let t=(document.querySelector("#isi, .card, .panel, .form-horizontal, form, table")||document.body).querySelectorAll("span, b, strong, td, .label, .badge, h3, h4");for(let n of t){let a=(n.textContent||"").trim();if(/^(batal|dibatalkan|resep batal|sudah dibatalkan)$/i.test(a)&&!n.closest("button, input, a"))return!0}}catch{}return!1}async function Y(e){return fetch(`${Q}?${G}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`id=${encodeURIComponent(e)}&taskid=6`,credentials:"include"}).then(t=>(console.log("[MORBIS Ext] antrian terdaftar id="+e,"status",t.status),!0)).catch(t=>(console.warn("[MORBIS Ext] gagal mendaftarkan antrian",t),!1))}async function Z(e,t){try{let n=await fetch(J,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:"type=check_antrian",cache:"no-store",credentials:"include"});if(!n.ok)return null;let a=await n.json();if(!Array.isArray(a))return null;let o=String(t??"").slice(0,16);return a.find(r=>String(r.ID_PASIEN??"")===String(e)&&(!o||String(r.WAKTU??"").slice(0,16)===o))??a.find(r=>String(r.ID_PASIEN??"")===String(e))??null}catch{return null}}async function ee(e,t,n,a){if(!await Y(e))throw new Error("gagal antrol MORBIS");let o=a.get("id_pasien")||new URLSearchParams(location.search).get("norm")||"",r=a.get("waktu_pengajuan"),i=a.namaPasien(),s=n==="racik"?"racikan":"tunggal",l=(async()=>{for(let _=0;_<3;_++){let E=await Z(o,r);if(E)return E;await new Promise(de=>setTimeout(de,200))}return null})(),c=h({event_id:w("enq",e,e+"-"+s)+"-"+Date.now().toString(36),event:"ENQUEUE",resep_id:t,nama_pasien:i,norm:o||void 0,tgl_lahir:a.tglLahir()||void 0,shift:"",jenis:s,counter:"",payload:{idVisit:e,unit:"",waktu:r||""}}),[se,q]=await Promise.all([l,c]);if(!q.ok)throw new Error("gagal terhubung App Antrian");let x=q.queue_number||"";if(!x)throw new Error("nomor antrian belum terbit");return v({nomorResep:t,nama:i,jenis:s,unit:String(se?.NAMA_UNIT??""),tanggal:r?r.slice(0,10):"",code:x,tglLahir:a.tglLahir()}),x}async function te(e,t,n){let a=w("bat",t,e)+"-"+Date.now().toString(36);return(await h({event_id:a,event:"BATAL",queue_number:e,resep_id:t})).ok?{ok:!0,gone:!1}:await S(n)?{ok:!1,gone:!1}:{ok:!0,gone:!0}}function ne(e,t,n,a="",o="",r=""){v({nomorResep:e,nama:n.namaPasien(),jenis:a,unit:o,tanggal:r,code:t,tglLahir:n.tglLahir()})}if(window.__extAntrolShift)throw new Error("skip double inject farmasiAntrolShift");window.__extAntrolShift=!0;function ae(){let e=document.querySelector("#nama_pasien")?.value?.trim();if(e)return e.toUpperCase();let t=document.querySelector("#nama")?.value?.trim();if(t)return t.toUpperCase();let n=Array.from(document.querySelectorAll("th, td, label, strong, b, span"));for(let r of n){let i=(r.textContent||"").trim();if(!/^nama\s*pasien$/i.test(i))continue;let s=r.nextElementSibling||r.parentElement?.querySelector("input, select")||r.parentElement?.nextElementSibling,l=(s?.textContent||s?.value||"").trim();if(l)return l.toUpperCase()}let a=/(resep|penjualan|antrian|farmasi|penerimaan|pendaftaran|detail|edit|input|rekap|daftar|shift|cetak|pembayaran|penyerahan|racik|racikan|obat|kasir|pilih|aturan|pakai|dosis|jumlah|satuan|harga|total|biaya|unit|depo|kekuatan|tipe|standar|kronis|klaim|inacbgs|batch|aksi|tambah|selesai|hapus|kembali|simpan)/i,o=Array.from(document.querySelectorAll("h1, h2, h3, .page-title, .card-title"));for(let r of o){if(r.closest('.modal, .modal-header, .modal-body, .dropdown, .dropdown-menu, [role="dialog"]'))continue;let i=(r.textContent||"").trim();if(!(!i||i.length<4||i.length>60||a.test(i)||i.split(/\s+/).filter(Boolean).length<2))return i.toUpperCase()}return""}function re(){let e=document.querySelector("#tgl_lahir")?.value?.trim();if(e)return e;let t=document.querySelectorAll("tr");for(let n of t){let a=n.querySelectorAll("td");for(let o=0;o<a.length-1;o++)if(/^tanggal\s*lahir$/i.test(a[o].textContent?.trim()||"")&&a[o+1]){let r=a[o+1].textContent?.trim();if(r&&r!==":")return r}}return""}var p={get:(e,t)=>(document.querySelector("#"+e)?.value||(t?document.querySelector('input[name="'+t+'"]')?.value:"")||"").trim(),namaPasien:ae,tglLahir:re};function f(e,t){return document.querySelector("#"+e)?.value?.trim()||(t?document.querySelector('input[name="'+t+'"]')?.value?.trim():"")||""}function oe(e){return String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}function u(e,t){let n=document.querySelector("#ext-antrian-bar");if(!n)return;let a=f("nomor_resep","id_resep");if(e==="issued"&&t){let r=oe(t);n.innerHTML='<div style="display: flex; flex-direction: column; align-items: flex-start; width: 100%; gap: 6px;"><span style="font-size:18px;font-weight:800;color:#198754;line-height:1.3;">\u2713 Sudah antri \u2014 '+r+'</span><div style="display: flex; gap: 6px;"><button id="ext-antrian-cetak" class="btn" style="margin:0;background:#6c757d;color:#fff;border-color:#6c757d;" title="Cetak ulang kartu tanpa mengantrikan lagi">Cetak Kembali</button><button id="ext-antrian-batal" class="btn" style="margin:0;background:#dc3545;color:#fff;border-color:#dc3545;" title="Hapus antrian dari DB \u2014 resep bisa di-antrikan ulang">Batal antrian</button></div></div>',n.querySelector("#ext-antrian-cetak")?.addEventListener("click",()=>{if(a)try{ne(a,t||"",p)}catch{}}),n.querySelector("#ext-antrian-batal")?.addEventListener("click",async()=>{if(!confirm("Batalkan antrian "+t+"? Resep akan keluar dari daftar panggilan."))return;let i=n.querySelector("#ext-antrian-batal");if(i&&(i.disabled=!0,i.textContent="Membatalkan\u2026"),!(await te(t||"",a,p)).ok){alert("[MORBIS Ext] Gagal membatalkan antrian. Coba lagi."),i&&(i.disabled=!1,i.textContent="Batal antrian");return}u("ready")});return}n.innerHTML='<button id="ext-antrian-racik" class="btn" style="margin:2px 6px 2px 0;background:#d97706;color:#fff;border-color:#d97706;" title="Antrikan sebagai obat RACIKAN (nomor R-XX)">Antrikan obat racik</button><button id="ext-antrian-tunggal" class="btn" style="margin:2px 0;background:#2193cf;color:#fff;border-color:#2193cf;" title="Antrikan sebagai obat TUNGGAL (nomor T-XX)">Antrikan obat tunggal</button>';let o=r=>{let i=f("id_visit"),s=f("id_resep","nomor_resep");if(!i||!s){alert("[MORBIS Ext] data resep belum dimuat. Coba lagi.");return}let l=document.querySelector(r==="racik"?"#ext-antrian-racik":"#ext-antrian-tunggal");l&&(l.disabled=!0,l.textContent="Memproses\u2026"),ee(i,s,r,p).then(c=>u("issued",c)).catch(c=>alert("[MORBIS Ext] "+(c?.message||"gagal mengantrikan"))).finally(()=>{l&&(l.disabled=!1,l.textContent=r==="racik"?"Antrikan obat racik":"Antrikan obat tunggal")})};n.querySelector("#ext-antrian-racik")?.addEventListener("click",()=>o("racik")),n.querySelector("#ext-antrian-tunggal")?.addEventListener("click",()=>o("tunggal"))}function ie(){let e=()=>{let n=Array.from(document.querySelectorAll('td[valign="top"]')).find(r=>r.querySelector('fieldset#perhatian, fieldset[id="perhatian"]'));if(!n)return null;let a=document.createElement("fieldset");a.id="ext-antrian-fieldset",a.style.cssText="margin-top:6px;",a.innerHTML="<legend>Antrian Farmasi</legend>";let o=document.createElement("div");return o.id="ext-antrian-bar",o.style.cssText="display:flex;flex-wrap:wrap;align-items:center;",a.appendChild(o),n.appendChild(a),o},t=()=>{let n=document.querySelector("#ext-antrian-bar")||e();if(!n)return;let a=o=>{if(!f("id_resep","nomor_resep")){o<10?window.setTimeout(()=>a(o+1),800):u("ready");return}S(p).then(r=>{if(V(r?.status)){n.innerHTML='<span style="color:#b02a37;font-weight:700;">Resep dibatalkan \u2014 antrian tidak tersedia</span>';return}r?u("issued",r.queue_number):o<10?window.setTimeout(()=>a(o+1),800):u("ready")})};a(0)};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",t,{once:!0}):t(),window.setTimeout(t,2e3),window.setTimeout(t,5e3)}N(()=>{le(),ie()});function le(){let e=(o,r)=>String(o??"").includes("/v2/antrol/search")&&String(o??"").includes("sub=update_v2")&&String(r??"").includes("taskid=6"),t=XMLHttpRequest.prototype.open,n=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(o,r,...i){return this.__extUrl=String(r),t.apply(this,[o,r,...i])},XMLHttpRequest.prototype.send=function(o){if(e(this.__extUrl,o)){console.log("[MORBIS Ext] antrol otomatis diblokir (pakai tombol Antrian & Cetak)");return}return n.apply(this,[o])};let a=window.fetch.bind(window);window.fetch=((o,r)=>{let i=typeof o=="string"?o:o instanceof URL?o.toString():o.url;return e(i,r?.body)?(console.log("[MORBIS Ext] antrol otomatis diblokir (pakai tombol Antrian & Cetak)"),Promise.resolve(new Response(null,{status:200}))):a(o,r)})}})();
