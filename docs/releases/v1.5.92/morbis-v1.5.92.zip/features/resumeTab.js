"use strict";var __morbis_feature=(()=>{var qh=Object.create;var Lo=Object.defineProperty;var Hh=Object.getOwnPropertyDescriptor;var Uh=Object.getOwnPropertyNames;var zh=Object.getPrototypeOf,_h=Object.prototype.hasOwnProperty;var So=(e,a,t)=>()=>{if(t)throw t[0];try{return e&&(a=e(e=0)),a}catch(l){throw t=[l],l}};var ba=(e,a)=>()=>{try{return a||e((a={exports:{}}).exports,a),a.exports}catch(t){throw a=0,t}},Nh=(e,a)=>{for(var t in a)Lo(e,t,{get:a[t],enumerable:!0})},yd=(e,a,t,l)=>{if(a&&typeof a=="object"||typeof a=="function")for(let u of Uh(a))!_h.call(e,u)&&u!==t&&Lo(e,u,{get:()=>a[u],enumerable:!(l=Hh(a,u))||l.enumerable});return e};var q=(e,a,t)=>(t=e!=null?qh(zh(e)):{},yd(a||!e||!e.__esModule?Lo(t,"default",{value:e,enumerable:!0}):t,e)),Ph=e=>yd(Lo({},"__esModule",{value:!0}),e);var Dd=ba(le=>{"use strict";function Ss(e,a){var t=e.length;e.push(a);e:for(;0<t;){var l=t-1>>>1,u=e[l];if(0<yo(u,a))e[l]=a,e[t]=u,t=l;else break e}}function va(e){return e.length===0?null:e[0]}function bo(e){if(e.length===0)return null;var a=e[0],t=e.pop();if(t!==a){e[0]=t;e:for(var l=0,u=e.length,o=u>>>1;l<o;){var n=2*(l+1)-1,s=e[n],r=n+1,i=e[r];if(0>yo(s,t))r<u&&0>yo(i,s)?(e[l]=i,e[r]=t,l=r):(e[l]=s,e[n]=t,l=n);else if(r<u&&0>yo(i,t))e[l]=i,e[r]=t,l=r;else break e}}return a}function yo(e,a){var t=e.sortIndex-a.sortIndex;return t!==0?t:e.id-a.id}le.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(Cd=performance,le.unstable_now=function(){return Cd.now()}):(hs=Date,bd=hs.now(),le.unstable_now=function(){return hs.now()-bd});var Cd,hs,bd,Ra=[],at=[],Fh=1,ta=null,we=3,ys=!1,ru=!1,iu=!1,Cs=!1,kd=typeof setTimeout=="function"?setTimeout:null,Ad=typeof clearTimeout=="function"?clearTimeout:null,vd=typeof setImmediate<"u"?setImmediate:null;function Co(e){for(var a=va(at);a!==null;){if(a.callback===null)bo(at);else if(a.startTime<=e)bo(at),a.sortIndex=a.expirationTime,Ss(Ra,a);else break;a=va(at)}}function bs(e){if(iu=!1,Co(e),!ru)if(va(Ra)!==null)ru=!0,fl||(fl=!0,dl());else{var a=va(at);a!==null&&vs(bs,a.startTime-e)}}var fl=!1,du=-1,Td=5,wd=-1;function Md(){return Cs?!0:!(le.unstable_now()-wd<Td)}function xs(){if(Cs=!1,fl){var e=le.unstable_now();wd=e;var a=!0;try{e:{ru=!1,iu&&(iu=!1,Ad(du),du=-1),ys=!0;var t=we;try{a:{for(Co(e),ta=va(Ra);ta!==null&&!(ta.expirationTime>e&&Md());){var l=ta.callback;if(typeof l=="function"){ta.callback=null,we=ta.priorityLevel;var u=l(ta.expirationTime<=e);if(e=le.unstable_now(),typeof u=="function"){ta.callback=u,Co(e),a=!0;break a}ta===va(Ra)&&bo(Ra),Co(e)}else bo(Ra);ta=va(Ra)}if(ta!==null)a=!0;else{var o=va(at);o!==null&&vs(bs,o.startTime-e),a=!1}}break e}finally{ta=null,we=t,ys=!1}a=void 0}}finally{a?dl():fl=!1}}}var dl;typeof vd=="function"?dl=function(){vd(xs)}:typeof MessageChannel<"u"?(Ls=new MessageChannel,Id=Ls.port2,Ls.port1.onmessage=xs,dl=function(){Id.postMessage(null)}):dl=function(){kd(xs,0)};var Ls,Id;function vs(e,a){du=kd(function(){e(le.unstable_now())},a)}le.unstable_IdlePriority=5;le.unstable_ImmediatePriority=1;le.unstable_LowPriority=4;le.unstable_NormalPriority=3;le.unstable_Profiling=null;le.unstable_UserBlockingPriority=2;le.unstable_cancelCallback=function(e){e.callback=null};le.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Td=0<e?Math.floor(1e3/e):5};le.unstable_getCurrentPriorityLevel=function(){return we};le.unstable_next=function(e){switch(we){case 1:case 2:case 3:var a=3;break;default:a=we}var t=we;we=a;try{return e()}finally{we=t}};le.unstable_requestPaint=function(){Cs=!0};le.unstable_runWithPriority=function(e,a){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var t=we;we=e;try{return a()}finally{we=t}};le.unstable_scheduleCallback=function(e,a,t){var l=le.unstable_now();switch(typeof t=="object"&&t!==null?(t=t.delay,t=typeof t=="number"&&0<t?l+t:l):t=l,e){case 1:var u=-1;break;case 2:u=250;break;case 5:u=1073741823;break;case 4:u=1e4;break;default:u=5e3}return u=t+u,e={id:Fh++,callback:a,priorityLevel:e,startTime:t,expirationTime:u,sortIndex:-1},t>l?(e.sortIndex=t,Ss(at,e),va(Ra)===null&&e===va(at)&&(iu?(Ad(du),du=-1):iu=!0,vs(bs,t-l))):(e.sortIndex=u,Ss(Ra,e),ru||ys||(ru=!0,fl||(fl=!0,dl()))),e};le.unstable_shouldYield=Md;le.unstable_wrapCallback=function(e){var a=we;return function(){var t=we;we=a;try{return e.apply(this,arguments)}finally{we=t}}}});var Bd=ba((MC,Rd)=>{"use strict";Rd.exports=Dd()});var Gd=ba(E=>{"use strict";var As=Symbol.for("react.transitional.element"),Gh=Symbol.for("react.portal"),Vh=Symbol.for("react.fragment"),Xh=Symbol.for("react.strict_mode"),jh=Symbol.for("react.profiler"),Kh=Symbol.for("react.consumer"),Yh=Symbol.for("react.context"),Zh=Symbol.for("react.forward_ref"),Qh=Symbol.for("react.suspense"),Jh=Symbol.for("react.memo"),Ud=Symbol.for("react.lazy"),Wh=Symbol.for("react.activity"),Ed=Symbol.iterator;function $h(e){return e===null||typeof e!="object"?null:(e=Ed&&e[Ed]||e["@@iterator"],typeof e=="function"?e:null)}var zd={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},_d=Object.assign,Nd={};function ml(e,a,t){this.props=e,this.context=a,this.refs=Nd,this.updater=t||zd}ml.prototype.isReactComponent={};ml.prototype.setState=function(e,a){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,a,"setState")};ml.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Pd(){}Pd.prototype=ml.prototype;function Ts(e,a,t){this.props=e,this.context=a,this.refs=Nd,this.updater=t||zd}var ws=Ts.prototype=new Pd;ws.constructor=Ts;_d(ws,ml.prototype);ws.isPureReactComponent=!0;var Od=Array.isArray;function ks(){}var $={H:null,A:null,T:null,S:null},Fd=Object.prototype.hasOwnProperty;function Ms(e,a,t){var l=t.ref;return{$$typeof:As,type:e,key:a,ref:l!==void 0?l:null,props:t}}function ex(e,a){return Ms(e.type,a,e.props)}function Ds(e){return typeof e=="object"&&e!==null&&e.$$typeof===As}function ax(e){var a={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(t){return a[t]})}var qd=/\/+/g;function Is(e,a){return typeof e=="object"&&e!==null&&e.key!=null?ax(""+e.key):a.toString(36)}function tx(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(ks,ks):(e.status="pending",e.then(function(a){e.status==="pending"&&(e.status="fulfilled",e.value=a)},function(a){e.status==="pending"&&(e.status="rejected",e.reason=a)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function cl(e,a,t,l,u){var o=typeof e;(o==="undefined"||o==="boolean")&&(e=null);var n=!1;if(e===null)n=!0;else switch(o){case"bigint":case"string":case"number":n=!0;break;case"object":switch(e.$$typeof){case As:case Gh:n=!0;break;case Ud:return n=e._init,cl(n(e._payload),a,t,l,u)}}if(n)return u=u(e),n=l===""?"."+Is(e,0):l,Od(u)?(t="",n!=null&&(t=n.replace(qd,"$&/")+"/"),cl(u,a,t,"",function(i){return i})):u!=null&&(Ds(u)&&(u=ex(u,t+(u.key==null||e&&e.key===u.key?"":(""+u.key).replace(qd,"$&/")+"/")+n)),a.push(u)),1;n=0;var s=l===""?".":l+":";if(Od(e))for(var r=0;r<e.length;r++)l=e[r],o=s+Is(l,r),n+=cl(l,a,t,o,u);else if(r=$h(e),typeof r=="function")for(e=r.call(e),r=0;!(l=e.next()).done;)l=l.value,o=s+Is(l,r++),n+=cl(l,a,t,o,u);else if(o==="object"){if(typeof e.then=="function")return cl(tx(e),a,t,l,u);throw a=String(e),Error("Objects are not valid as a React child (found: "+(a==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":a)+"). If you meant to render a collection of children, use an array instead.")}return n}function vo(e,a,t){if(e==null)return e;var l=[],u=0;return cl(e,l,"","",function(o){return a.call(t,o,u++)}),l}function lx(e){if(e._status===-1){var a=e._result;a=a(),a.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t)},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t)}),e._status===-1&&(e._status=0,e._result=a)}if(e._status===1)return e._result.default;throw e._result}var Hd=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var a=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(a))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},ux={map:vo,forEach:function(e,a,t){vo(e,function(){a.apply(this,arguments)},t)},count:function(e){var a=0;return vo(e,function(){a++}),a},toArray:function(e){return vo(e,function(a){return a})||[]},only:function(e){if(!Ds(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};E.Activity=Wh;E.Children=ux;E.Component=ml;E.Fragment=Vh;E.Profiler=jh;E.PureComponent=Ts;E.StrictMode=Xh;E.Suspense=Qh;E.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=$;E.__COMPILER_RUNTIME={__proto__:null,c:function(e){return $.H.useMemoCache(e)}};E.cache=function(e){return function(){return e.apply(null,arguments)}};E.cacheSignal=function(){return null};E.cloneElement=function(e,a,t){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var l=_d({},e.props),u=e.key;if(a!=null)for(o in a.key!==void 0&&(u=""+a.key),a)!Fd.call(a,o)||o==="key"||o==="__self"||o==="__source"||o==="ref"&&a.ref===void 0||(l[o]=a[o]);var o=arguments.length-2;if(o===1)l.children=t;else if(1<o){for(var n=Array(o),s=0;s<o;s++)n[s]=arguments[s+2];l.children=n}return Ms(e.type,u,l)};E.createContext=function(e){return e={$$typeof:Yh,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:Kh,_context:e},e};E.createElement=function(e,a,t){var l,u={},o=null;if(a!=null)for(l in a.key!==void 0&&(o=""+a.key),a)Fd.call(a,l)&&l!=="key"&&l!=="__self"&&l!=="__source"&&(u[l]=a[l]);var n=arguments.length-2;if(n===1)u.children=t;else if(1<n){for(var s=Array(n),r=0;r<n;r++)s[r]=arguments[r+2];u.children=s}if(e&&e.defaultProps)for(l in n=e.defaultProps,n)u[l]===void 0&&(u[l]=n[l]);return Ms(e,o,u)};E.createRef=function(){return{current:null}};E.forwardRef=function(e){return{$$typeof:Zh,render:e}};E.isValidElement=Ds;E.lazy=function(e){return{$$typeof:Ud,_payload:{_status:-1,_result:e},_init:lx}};E.memo=function(e,a){return{$$typeof:Jh,type:e,compare:a===void 0?null:a}};E.startTransition=function(e){var a=$.T,t={};$.T=t;try{var l=e(),u=$.S;u!==null&&u(t,l),typeof l=="object"&&l!==null&&typeof l.then=="function"&&l.then(ks,Hd)}catch(o){Hd(o)}finally{a!==null&&t.types!==null&&(a.types=t.types),$.T=a}};E.unstable_useCacheRefresh=function(){return $.H.useCacheRefresh()};E.use=function(e){return $.H.use(e)};E.useActionState=function(e,a,t){return $.H.useActionState(e,a,t)};E.useCallback=function(e,a){return $.H.useCallback(e,a)};E.useContext=function(e){return $.H.useContext(e)};E.useDebugValue=function(){};E.useDeferredValue=function(e,a){return $.H.useDeferredValue(e,a)};E.useEffect=function(e,a){return $.H.useEffect(e,a)};E.useEffectEvent=function(e){return $.H.useEffectEvent(e)};E.useId=function(){return $.H.useId()};E.useImperativeHandle=function(e,a,t){return $.H.useImperativeHandle(e,a,t)};E.useInsertionEffect=function(e,a){return $.H.useInsertionEffect(e,a)};E.useLayoutEffect=function(e,a){return $.H.useLayoutEffect(e,a)};E.useMemo=function(e,a){return $.H.useMemo(e,a)};E.useOptimistic=function(e,a){return $.H.useOptimistic(e,a)};E.useReducer=function(e,a,t){return $.H.useReducer(e,a,t)};E.useRef=function(e){return $.H.useRef(e)};E.useState=function(e){return $.H.useState(e)};E.useSyncExternalStore=function(e,a,t){return $.H.useSyncExternalStore(e,a,t)};E.useTransition=function(){return $.H.useTransition()};E.version="19.2.8"});var Ge=ba((RC,Vd)=>{"use strict";Vd.exports=Gd()});var jd=ba(Ee=>{"use strict";var ox=Ge();function Xd(e){var a="https://react.dev/errors/"+e;if(1<arguments.length){a+="?args[]="+encodeURIComponent(arguments[1]);for(var t=2;t<arguments.length;t++)a+="&args[]="+encodeURIComponent(arguments[t])}return"Minified React error #"+e+"; visit "+a+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function tt(){}var Be={d:{f:tt,r:function(){throw Error(Xd(522))},D:tt,C:tt,L:tt,m:tt,X:tt,S:tt,M:tt},p:0,findDOMNode:null},nx=Symbol.for("react.portal");function sx(e,a,t){var l=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:nx,key:l==null?null:""+l,children:e,containerInfo:a,implementation:t}}var fu=ox.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function Io(e,a){if(e==="font")return"";if(typeof a=="string")return a==="use-credentials"?a:""}Ee.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=Be;Ee.createPortal=function(e,a){var t=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!a||a.nodeType!==1&&a.nodeType!==9&&a.nodeType!==11)throw Error(Xd(299));return sx(e,a,null,t)};Ee.flushSync=function(e){var a=fu.T,t=Be.p;try{if(fu.T=null,Be.p=2,e)return e()}finally{fu.T=a,Be.p=t,Be.d.f()}};Ee.preconnect=function(e,a){typeof e=="string"&&(a?(a=a.crossOrigin,a=typeof a=="string"?a==="use-credentials"?a:"":void 0):a=null,Be.d.C(e,a))};Ee.prefetchDNS=function(e){typeof e=="string"&&Be.d.D(e)};Ee.preinit=function(e,a){if(typeof e=="string"&&a&&typeof a.as=="string"){var t=a.as,l=Io(t,a.crossOrigin),u=typeof a.integrity=="string"?a.integrity:void 0,o=typeof a.fetchPriority=="string"?a.fetchPriority:void 0;t==="style"?Be.d.S(e,typeof a.precedence=="string"?a.precedence:void 0,{crossOrigin:l,integrity:u,fetchPriority:o}):t==="script"&&Be.d.X(e,{crossOrigin:l,integrity:u,fetchPriority:o,nonce:typeof a.nonce=="string"?a.nonce:void 0})}};Ee.preinitModule=function(e,a){if(typeof e=="string")if(typeof a=="object"&&a!==null){if(a.as==null||a.as==="script"){var t=Io(a.as,a.crossOrigin);Be.d.M(e,{crossOrigin:t,integrity:typeof a.integrity=="string"?a.integrity:void 0,nonce:typeof a.nonce=="string"?a.nonce:void 0})}}else a==null&&Be.d.M(e)};Ee.preload=function(e,a){if(typeof e=="string"&&typeof a=="object"&&a!==null&&typeof a.as=="string"){var t=a.as,l=Io(t,a.crossOrigin);Be.d.L(e,t,{crossOrigin:l,integrity:typeof a.integrity=="string"?a.integrity:void 0,nonce:typeof a.nonce=="string"?a.nonce:void 0,type:typeof a.type=="string"?a.type:void 0,fetchPriority:typeof a.fetchPriority=="string"?a.fetchPriority:void 0,referrerPolicy:typeof a.referrerPolicy=="string"?a.referrerPolicy:void 0,imageSrcSet:typeof a.imageSrcSet=="string"?a.imageSrcSet:void 0,imageSizes:typeof a.imageSizes=="string"?a.imageSizes:void 0,media:typeof a.media=="string"?a.media:void 0})}};Ee.preloadModule=function(e,a){if(typeof e=="string")if(a){var t=Io(a.as,a.crossOrigin);Be.d.m(e,{as:typeof a.as=="string"&&a.as!=="script"?a.as:void 0,crossOrigin:t,integrity:typeof a.integrity=="string"?a.integrity:void 0})}else Be.d.m(e)};Ee.requestFormReset=function(e){Be.d.r(e)};Ee.unstable_batchedUpdates=function(e,a){return e(a)};Ee.useFormState=function(e,a,t){return fu.H.useFormState(e,a,t)};Ee.useFormStatus=function(){return fu.H.useHostTransitionStatus()};Ee.version="19.2.8"});var Zd=ba((EC,Yd)=>{"use strict";function Kd(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Kd)}catch(e){console.error(e)}}Kd(),Yd.exports=jd()});var rg=ba(Qn=>{"use strict";var ge=Bd(),bc=Ge(),rx=Zd();function C(e){var a="https://react.dev/errors/"+e;if(1<arguments.length){a+="?args[]="+encodeURIComponent(arguments[1]);for(var t=2;t<arguments.length;t++)a+="&args[]="+encodeURIComponent(arguments[t])}return"Minified React error #"+e+"; visit "+a+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function vc(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Ju(e){var a=e,t=e;if(e.alternate)for(;a.return;)a=a.return;else{e=a;do a=e,(a.flags&4098)!==0&&(t=a.return),e=a.return;while(e)}return a.tag===3?t:null}function Ic(e){if(e.tag===13){var a=e.memoizedState;if(a===null&&(e=e.alternate,e!==null&&(a=e.memoizedState)),a!==null)return a.dehydrated}return null}function kc(e){if(e.tag===31){var a=e.memoizedState;if(a===null&&(e=e.alternate,e!==null&&(a=e.memoizedState)),a!==null)return a.dehydrated}return null}function Qd(e){if(Ju(e)!==e)throw Error(C(188))}function ix(e){var a=e.alternate;if(!a){if(a=Ju(e),a===null)throw Error(C(188));return a!==e?null:e}for(var t=e,l=a;;){var u=t.return;if(u===null)break;var o=u.alternate;if(o===null){if(l=u.return,l!==null){t=l;continue}break}if(u.child===o.child){for(o=u.child;o;){if(o===t)return Qd(u),e;if(o===l)return Qd(u),a;o=o.sibling}throw Error(C(188))}if(t.return!==l.return)t=u,l=o;else{for(var n=!1,s=u.child;s;){if(s===t){n=!0,t=u,l=o;break}if(s===l){n=!0,l=u,t=o;break}s=s.sibling}if(!n){for(s=o.child;s;){if(s===t){n=!0,t=o,l=u;break}if(s===l){n=!0,l=o,t=u;break}s=s.sibling}if(!n)throw Error(C(189))}}if(t.alternate!==l)throw Error(C(190))}if(t.tag!==3)throw Error(C(188));return t.stateNode.current===t?e:a}function Ac(e){var a=e.tag;if(a===5||a===26||a===27||a===6)return e;for(e=e.child;e!==null;){if(a=Ac(e),a!==null)return a;e=e.sibling}return null}var te=Object.assign,dx=Symbol.for("react.element"),ko=Symbol.for("react.transitional.element"),Su=Symbol.for("react.portal"),Sl=Symbol.for("react.fragment"),Tc=Symbol.for("react.strict_mode"),dr=Symbol.for("react.profiler"),wc=Symbol.for("react.consumer"),_a=Symbol.for("react.context"),oi=Symbol.for("react.forward_ref"),fr=Symbol.for("react.suspense"),cr=Symbol.for("react.suspense_list"),ni=Symbol.for("react.memo"),lt=Symbol.for("react.lazy"),mr=Symbol.for("react.activity"),fx=Symbol.for("react.memo_cache_sentinel"),Jd=Symbol.iterator;function cu(e){return e===null||typeof e!="object"?null:(e=Jd&&e[Jd]||e["@@iterator"],typeof e=="function"?e:null)}var cx=Symbol.for("react.client.reference");function pr(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===cx?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Sl:return"Fragment";case dr:return"Profiler";case Tc:return"StrictMode";case fr:return"Suspense";case cr:return"SuspenseList";case mr:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case Su:return"Portal";case _a:return e.displayName||"Context";case wc:return(e._context.displayName||"Context")+".Consumer";case oi:var a=e.render;return e=e.displayName,e||(e=a.displayName||a.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case ni:return a=e.displayName||null,a!==null?a:pr(e.type)||"Memo";case lt:a=e._payload,e=e._init;try{return pr(e(a))}catch{}}return null}var yu=Array.isArray,B=bc.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,F=rx.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Vt={pending:!1,data:null,method:null,action:null},gr=[],yl=-1;function wa(e){return{current:e}}function Ce(e){0>yl||(e.current=gr[yl],gr[yl]=null,yl--)}function Z(e,a){yl++,gr[yl]=e.current,e.current=a}var Ta=wa(null),Uu=wa(null),pt=wa(null),un=wa(null);function on(e,a){switch(Z(pt,a),Z(Uu,e),Z(Ta,null),a.nodeType){case 9:case 11:e=(e=a.documentElement)&&(e=e.namespaceURI)?oc(e):0;break;default:if(e=a.tagName,a=a.namespaceURI)a=oc(a),e=Yp(a,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Ce(Ta),Z(Ta,e)}function zl(){Ce(Ta),Ce(Uu),Ce(pt)}function hr(e){e.memoizedState!==null&&Z(un,e);var a=Ta.current,t=Yp(a,e.type);a!==t&&(Z(Uu,e),Z(Ta,t))}function nn(e){Uu.current===e&&(Ce(Ta),Ce(Uu)),un.current===e&&(Ce(un),Yu._currentValue=Vt)}var Rs,Wd;function Nt(e){if(Rs===void 0)try{throw Error()}catch(t){var a=t.stack.trim().match(/\n( *(at )?)/);Rs=a&&a[1]||"",Wd=-1<t.stack.indexOf(`
    at`)?" (<anonymous>)":-1<t.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Rs+e+Wd}var Bs=!1;function Es(e,a){if(!e||Bs)return"";Bs=!0;var t=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var l={DetermineComponentFrameRoot:function(){try{if(a){var g=function(){throw Error()};if(Object.defineProperty(g.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(g,[])}catch(c){var f=c}Reflect.construct(e,[],g)}else{try{g.call()}catch(c){f=c}e.call(g.prototype)}}else{try{throw Error()}catch(c){f=c}(g=e())&&typeof g.catch=="function"&&g.catch(function(){})}}catch(c){if(c&&f&&typeof c.stack=="string")return[c.stack,f.stack]}return[null,null]}};l.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(l.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(l.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var o=l.DetermineComponentFrameRoot(),n=o[0],s=o[1];if(n&&s){var r=n.split(`
`),i=s.split(`
`);for(u=l=0;l<r.length&&!r[l].includes("DetermineComponentFrameRoot");)l++;for(;u<i.length&&!i[u].includes("DetermineComponentFrameRoot");)u++;if(l===r.length||u===i.length)for(l=r.length-1,u=i.length-1;1<=l&&0<=u&&r[l]!==i[u];)u--;for(;1<=l&&0<=u;l--,u--)if(r[l]!==i[u]){if(l!==1||u!==1)do if(l--,u--,0>u||r[l]!==i[u]){var p=`
`+r[l].replace(" at new "," at ");return e.displayName&&p.includes("<anonymous>")&&(p=p.replace("<anonymous>",e.displayName)),p}while(1<=l&&0<=u);break}}}finally{Bs=!1,Error.prepareStackTrace=t}return(t=e?e.displayName||e.name:"")?Nt(t):""}function mx(e,a){switch(e.tag){case 26:case 27:case 5:return Nt(e.type);case 16:return Nt("Lazy");case 13:return e.child!==a&&a!==null?Nt("Suspense Fallback"):Nt("Suspense");case 19:return Nt("SuspenseList");case 0:case 15:return Es(e.type,!1);case 11:return Es(e.type.render,!1);case 1:return Es(e.type,!0);case 31:return Nt("Activity");default:return""}}function $d(e){try{var a="",t=null;do a+=mx(e,t),t=e,e=e.return;while(e);return a}catch(l){return`
Error generating stack: `+l.message+`
`+l.stack}}var xr=Object.prototype.hasOwnProperty,si=ge.unstable_scheduleCallback,Os=ge.unstable_cancelCallback,px=ge.unstable_shouldYield,gx=ge.unstable_requestPaint,Ye=ge.unstable_now,hx=ge.unstable_getCurrentPriorityLevel,Mc=ge.unstable_ImmediatePriority,Dc=ge.unstable_UserBlockingPriority,sn=ge.unstable_NormalPriority,xx=ge.unstable_LowPriority,Rc=ge.unstable_IdlePriority,Lx=ge.log,Sx=ge.unstable_setDisableYieldValue,Wu=null,Ze=null;function it(e){if(typeof Lx=="function"&&Sx(e),Ze&&typeof Ze.setStrictMode=="function")try{Ze.setStrictMode(Wu,e)}catch{}}var Qe=Math.clz32?Math.clz32:bx,yx=Math.log,Cx=Math.LN2;function bx(e){return e>>>=0,e===0?32:31-(yx(e)/Cx|0)|0}var Ao=256,To=262144,wo=4194304;function Pt(e){var a=e&42;if(a!==0)return a;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function On(e,a,t){var l=e.pendingLanes;if(l===0)return 0;var u=0,o=e.suspendedLanes,n=e.pingedLanes;e=e.warmLanes;var s=l&134217727;return s!==0?(l=s&~o,l!==0?u=Pt(l):(n&=s,n!==0?u=Pt(n):t||(t=s&~e,t!==0&&(u=Pt(t))))):(s=l&~o,s!==0?u=Pt(s):n!==0?u=Pt(n):t||(t=l&~e,t!==0&&(u=Pt(t)))),u===0?0:a!==0&&a!==u&&(a&o)===0&&(o=u&-u,t=a&-a,o>=t||o===32&&(t&4194048)!==0)?a:u}function $u(e,a){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&a)===0}function vx(e,a){switch(e){case 1:case 2:case 4:case 8:case 64:return a+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return a+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Bc(){var e=wo;return wo<<=1,(wo&62914560)===0&&(wo=4194304),e}function qs(e){for(var a=[],t=0;31>t;t++)a.push(e);return a}function eo(e,a){e.pendingLanes|=a,a!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Ix(e,a,t,l,u,o){var n=e.pendingLanes;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=t,e.entangledLanes&=t,e.errorRecoveryDisabledLanes&=t,e.shellSuspendCounter=0;var s=e.entanglements,r=e.expirationTimes,i=e.hiddenUpdates;for(t=n&~t;0<t;){var p=31-Qe(t),g=1<<p;s[p]=0,r[p]=-1;var f=i[p];if(f!==null)for(i[p]=null,p=0;p<f.length;p++){var c=f[p];c!==null&&(c.lane&=-536870913)}t&=~g}l!==0&&Ec(e,l,0),o!==0&&u===0&&e.tag!==0&&(e.suspendedLanes|=o&~(n&~a))}function Ec(e,a,t){e.pendingLanes|=a,e.suspendedLanes&=~a;var l=31-Qe(a);e.entangledLanes|=a,e.entanglements[l]=e.entanglements[l]|1073741824|t&261930}function Oc(e,a){var t=e.entangledLanes|=a;for(e=e.entanglements;t;){var l=31-Qe(t),u=1<<l;u&a|e[l]&a&&(e[l]|=a),t&=~u}}function qc(e,a){var t=a&-a;return t=(t&42)!==0?1:ri(t),(t&(e.suspendedLanes|a))!==0?0:t}function ri(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function ii(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Hc(){var e=F.p;return e!==0?e:(e=window.event,e===void 0?32:og(e.type))}function ef(e,a){var t=F.p;try{return F.p=e,a()}finally{F.p=t}}var Tt=Math.random().toString(36).slice(2),ve="__reactFiber$"+Tt,Ne="__reactProps$"+Tt,Zl="__reactContainer$"+Tt,Lr="__reactEvents$"+Tt,kx="__reactListeners$"+Tt,Ax="__reactHandles$"+Tt,af="__reactResources$"+Tt,ao="__reactMarker$"+Tt;function di(e){delete e[ve],delete e[Ne],delete e[Lr],delete e[kx],delete e[Ax]}function Cl(e){var a=e[ve];if(a)return a;for(var t=e.parentNode;t;){if(a=t[Zl]||t[ve]){if(t=a.alternate,a.child!==null||t!==null&&t.child!==null)for(e=dc(e);e!==null;){if(t=e[ve])return t;e=dc(e)}return a}e=t,t=e.parentNode}return null}function Ql(e){if(e=e[ve]||e[Zl]){var a=e.tag;if(a===5||a===6||a===13||a===31||a===26||a===27||a===3)return e}return null}function Cu(e){var a=e.tag;if(a===5||a===26||a===27||a===6)return e.stateNode;throw Error(C(33))}function Rl(e){var a=e[af];return a||(a=e[af]={hoistableStyles:new Map,hoistableScripts:new Map}),a}function ye(e){e[ao]=!0}var Uc=new Set,zc={};function el(e,a){_l(e,a),_l(e+"Capture",a)}function _l(e,a){for(zc[e]=a,e=0;e<a.length;e++)Uc.add(a[e])}var Tx=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),tf={},lf={};function wx(e){return xr.call(lf,e)?!0:xr.call(tf,e)?!1:Tx.test(e)?lf[e]=!0:(tf[e]=!0,!1)}function Go(e,a,t){if(wx(a))if(t===null)e.removeAttribute(a);else{switch(typeof t){case"undefined":case"function":case"symbol":e.removeAttribute(a);return;case"boolean":var l=a.toLowerCase().slice(0,5);if(l!=="data-"&&l!=="aria-"){e.removeAttribute(a);return}}e.setAttribute(a,""+t)}}function Mo(e,a,t){if(t===null)e.removeAttribute(a);else{switch(typeof t){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(a);return}e.setAttribute(a,""+t)}}function Ba(e,a,t,l){if(l===null)e.removeAttribute(t);else{switch(typeof l){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttributeNS(a,t,""+l)}}function ua(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function _c(e){var a=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(a==="checkbox"||a==="radio")}function Mx(e,a,t){var l=Object.getOwnPropertyDescriptor(e.constructor.prototype,a);if(!e.hasOwnProperty(a)&&typeof l<"u"&&typeof l.get=="function"&&typeof l.set=="function"){var u=l.get,o=l.set;return Object.defineProperty(e,a,{configurable:!0,get:function(){return u.call(this)},set:function(n){t=""+n,o.call(this,n)}}),Object.defineProperty(e,a,{enumerable:l.enumerable}),{getValue:function(){return t},setValue:function(n){t=""+n},stopTracking:function(){e._valueTracker=null,delete e[a]}}}}function Sr(e){if(!e._valueTracker){var a=_c(e)?"checked":"value";e._valueTracker=Mx(e,a,""+e[a])}}function Nc(e){if(!e)return!1;var a=e._valueTracker;if(!a)return!0;var t=a.getValue(),l="";return e&&(l=_c(e)?e.checked?"true":"false":e.value),e=l,e!==t?(a.setValue(e),!0):!1}function rn(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var Dx=/[\n"\\]/g;function sa(e){return e.replace(Dx,function(a){return"\\"+a.charCodeAt(0).toString(16)+" "})}function yr(e,a,t,l,u,o,n,s){e.name="",n!=null&&typeof n!="function"&&typeof n!="symbol"&&typeof n!="boolean"?e.type=n:e.removeAttribute("type"),a!=null?n==="number"?(a===0&&e.value===""||e.value!=a)&&(e.value=""+ua(a)):e.value!==""+ua(a)&&(e.value=""+ua(a)):n!=="submit"&&n!=="reset"||e.removeAttribute("value"),a!=null?Cr(e,n,ua(a)):t!=null?Cr(e,n,ua(t)):l!=null&&e.removeAttribute("value"),u==null&&o!=null&&(e.defaultChecked=!!o),u!=null&&(e.checked=u&&typeof u!="function"&&typeof u!="symbol"),s!=null&&typeof s!="function"&&typeof s!="symbol"&&typeof s!="boolean"?e.name=""+ua(s):e.removeAttribute("name")}function Pc(e,a,t,l,u,o,n,s){if(o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"&&(e.type=o),a!=null||t!=null){if(!(o!=="submit"&&o!=="reset"||a!=null)){Sr(e);return}t=t!=null?""+ua(t):"",a=a!=null?""+ua(a):t,s||a===e.value||(e.value=a),e.defaultValue=a}l=l??u,l=typeof l!="function"&&typeof l!="symbol"&&!!l,e.checked=s?e.checked:!!l,e.defaultChecked=!!l,n!=null&&typeof n!="function"&&typeof n!="symbol"&&typeof n!="boolean"&&(e.name=n),Sr(e)}function Cr(e,a,t){a==="number"&&rn(e.ownerDocument)===e||e.defaultValue===""+t||(e.defaultValue=""+t)}function Bl(e,a,t,l){if(e=e.options,a){a={};for(var u=0;u<t.length;u++)a["$"+t[u]]=!0;for(t=0;t<e.length;t++)u=a.hasOwnProperty("$"+e[t].value),e[t].selected!==u&&(e[t].selected=u),u&&l&&(e[t].defaultSelected=!0)}else{for(t=""+ua(t),a=null,u=0;u<e.length;u++){if(e[u].value===t){e[u].selected=!0,l&&(e[u].defaultSelected=!0);return}a!==null||e[u].disabled||(a=e[u])}a!==null&&(a.selected=!0)}}function Fc(e,a,t){if(a!=null&&(a=""+ua(a),a!==e.value&&(e.value=a),t==null)){e.defaultValue!==a&&(e.defaultValue=a);return}e.defaultValue=t!=null?""+ua(t):""}function Gc(e,a,t,l){if(a==null){if(l!=null){if(t!=null)throw Error(C(92));if(yu(l)){if(1<l.length)throw Error(C(93));l=l[0]}t=l}t==null&&(t=""),a=t}t=ua(a),e.defaultValue=t,l=e.textContent,l===t&&l!==""&&l!==null&&(e.value=l),Sr(e)}function Nl(e,a){if(a){var t=e.firstChild;if(t&&t===e.lastChild&&t.nodeType===3){t.nodeValue=a;return}}e.textContent=a}var Rx=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function uf(e,a,t){var l=a.indexOf("--")===0;t==null||typeof t=="boolean"||t===""?l?e.setProperty(a,""):a==="float"?e.cssFloat="":e[a]="":l?e.setProperty(a,t):typeof t!="number"||t===0||Rx.has(a)?a==="float"?e.cssFloat=t:e[a]=(""+t).trim():e[a]=t+"px"}function Vc(e,a,t){if(a!=null&&typeof a!="object")throw Error(C(62));if(e=e.style,t!=null){for(var l in t)!t.hasOwnProperty(l)||a!=null&&a.hasOwnProperty(l)||(l.indexOf("--")===0?e.setProperty(l,""):l==="float"?e.cssFloat="":e[l]="");for(var u in a)l=a[u],a.hasOwnProperty(u)&&t[u]!==l&&uf(e,u,l)}else for(var o in a)a.hasOwnProperty(o)&&uf(e,o,a[o])}function fi(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Bx=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Ex=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Vo(e){return Ex.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Na(){}var br=null;function ci(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var bl=null,El=null;function of(e){var a=Ql(e);if(a&&(e=a.stateNode)){var t=e[Ne]||null;e:switch(e=a.stateNode,a.type){case"input":if(yr(e,t.value,t.defaultValue,t.defaultValue,t.checked,t.defaultChecked,t.type,t.name),a=t.name,t.type==="radio"&&a!=null){for(t=e;t.parentNode;)t=t.parentNode;for(t=t.querySelectorAll('input[name="'+sa(""+a)+'"][type="radio"]'),a=0;a<t.length;a++){var l=t[a];if(l!==e&&l.form===e.form){var u=l[Ne]||null;if(!u)throw Error(C(90));yr(l,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(a=0;a<t.length;a++)l=t[a],l.form===e.form&&Nc(l)}break e;case"textarea":Fc(e,t.value,t.defaultValue);break e;case"select":a=t.value,a!=null&&Bl(e,!!t.multiple,a,!1)}}}var Hs=!1;function Xc(e,a,t){if(Hs)return e(a,t);Hs=!0;try{var l=e(a);return l}finally{if(Hs=!1,(bl!==null||El!==null)&&(jn(),bl&&(a=bl,e=El,El=bl=null,of(a),e)))for(a=0;a<e.length;a++)of(e[a])}}function zu(e,a){var t=e.stateNode;if(t===null)return null;var l=t[Ne]||null;if(l===null)return null;t=l[a];e:switch(a){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(l=!l.disabled)||(e=e.type,l=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!l;break e;default:e=!1}if(e)return null;if(t&&typeof t!="function")throw Error(C(231,a,typeof t));return t}var Xa=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),vr=!1;if(Xa)try{pl={},Object.defineProperty(pl,"passive",{get:function(){vr=!0}}),window.addEventListener("test",pl,pl),window.removeEventListener("test",pl,pl)}catch{vr=!1}var pl,dt=null,mi=null,Xo=null;function jc(){if(Xo)return Xo;var e,a=mi,t=a.length,l,u="value"in dt?dt.value:dt.textContent,o=u.length;for(e=0;e<t&&a[e]===u[e];e++);var n=t-e;for(l=1;l<=n&&a[t-l]===u[o-l];l++);return Xo=u.slice(e,1<l?1-l:void 0)}function jo(e){var a=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&a===13&&(e=13)):e=a,e===10&&(e=13),32<=e||e===13?e:0}function Do(){return!0}function nf(){return!1}function Pe(e){function a(t,l,u,o,n){this._reactName=t,this._targetInst=u,this.type=l,this.nativeEvent=o,this.target=n,this.currentTarget=null;for(var s in e)e.hasOwnProperty(s)&&(t=e[s],this[s]=t?t(o):o[s]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?Do:nf,this.isPropagationStopped=nf,this}return te(a.prototype,{preventDefault:function(){this.defaultPrevented=!0;var t=this.nativeEvent;t&&(t.preventDefault?t.preventDefault():typeof t.returnValue!="unknown"&&(t.returnValue=!1),this.isDefaultPrevented=Do)},stopPropagation:function(){var t=this.nativeEvent;t&&(t.stopPropagation?t.stopPropagation():typeof t.cancelBubble!="unknown"&&(t.cancelBubble=!0),this.isPropagationStopped=Do)},persist:function(){},isPersistent:Do}),a}var al={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},qn=Pe(al),to=te({},al,{view:0,detail:0}),Ox=Pe(to),Us,zs,mu,Hn=te({},to,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:pi,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==mu&&(mu&&e.type==="mousemove"?(Us=e.screenX-mu.screenX,zs=e.screenY-mu.screenY):zs=Us=0,mu=e),Us)},movementY:function(e){return"movementY"in e?e.movementY:zs}}),sf=Pe(Hn),qx=te({},Hn,{dataTransfer:0}),Hx=Pe(qx),Ux=te({},to,{relatedTarget:0}),_s=Pe(Ux),zx=te({},al,{animationName:0,elapsedTime:0,pseudoElement:0}),_x=Pe(zx),Nx=te({},al,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Px=Pe(Nx),Fx=te({},al,{data:0}),rf=Pe(Fx),Gx={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Vx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Xx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function jx(e){var a=this.nativeEvent;return a.getModifierState?a.getModifierState(e):(e=Xx[e])?!!a[e]:!1}function pi(){return jx}var Kx=te({},to,{key:function(e){if(e.key){var a=Gx[e.key]||e.key;if(a!=="Unidentified")return a}return e.type==="keypress"?(e=jo(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Vx[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:pi,charCode:function(e){return e.type==="keypress"?jo(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?jo(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Yx=Pe(Kx),Zx=te({},Hn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),df=Pe(Zx),Qx=te({},to,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:pi}),Jx=Pe(Qx),Wx=te({},al,{propertyName:0,elapsedTime:0,pseudoElement:0}),$x=Pe(Wx),eL=te({},Hn,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),aL=Pe(eL),tL=te({},al,{newState:0,oldState:0}),lL=Pe(tL),uL=[9,13,27,32],gi=Xa&&"CompositionEvent"in window,Iu=null;Xa&&"documentMode"in document&&(Iu=document.documentMode);var oL=Xa&&"TextEvent"in window&&!Iu,Kc=Xa&&(!gi||Iu&&8<Iu&&11>=Iu),ff=" ",cf=!1;function Yc(e,a){switch(e){case"keyup":return uL.indexOf(a.keyCode)!==-1;case"keydown":return a.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Zc(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var vl=!1;function nL(e,a){switch(e){case"compositionend":return Zc(a);case"keypress":return a.which!==32?null:(cf=!0,ff);case"textInput":return e=a.data,e===ff&&cf?null:e;default:return null}}function sL(e,a){if(vl)return e==="compositionend"||!gi&&Yc(e,a)?(e=jc(),Xo=mi=dt=null,vl=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(a.ctrlKey||a.altKey||a.metaKey)||a.ctrlKey&&a.altKey){if(a.char&&1<a.char.length)return a.char;if(a.which)return String.fromCharCode(a.which)}return null;case"compositionend":return Kc&&a.locale!=="ko"?null:a.data;default:return null}}var rL={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function mf(e){var a=e&&e.nodeName&&e.nodeName.toLowerCase();return a==="input"?!!rL[e.type]:a==="textarea"}function Qc(e,a,t,l){bl?El?El.push(l):El=[l]:bl=l,a=Tn(a,"onChange"),0<a.length&&(t=new qn("onChange","change",null,t,l),e.push({event:t,listeners:a}))}var ku=null,_u=null;function iL(e){Xp(e,0)}function Un(e){var a=Cu(e);if(Nc(a))return e}function pf(e,a){if(e==="change")return a}var Jc=!1;Xa&&(Xa?(Bo="oninput"in document,Bo||(Ns=document.createElement("div"),Ns.setAttribute("oninput","return;"),Bo=typeof Ns.oninput=="function"),Ro=Bo):Ro=!1,Jc=Ro&&(!document.documentMode||9<document.documentMode));var Ro,Bo,Ns;function gf(){ku&&(ku.detachEvent("onpropertychange",Wc),_u=ku=null)}function Wc(e){if(e.propertyName==="value"&&Un(_u)){var a=[];Qc(a,_u,e,ci(e)),Xc(iL,a)}}function dL(e,a,t){e==="focusin"?(gf(),ku=a,_u=t,ku.attachEvent("onpropertychange",Wc)):e==="focusout"&&gf()}function fL(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Un(_u)}function cL(e,a){if(e==="click")return Un(a)}function mL(e,a){if(e==="input"||e==="change")return Un(a)}function pL(e,a){return e===a&&(e!==0||1/e===1/a)||e!==e&&a!==a}var We=typeof Object.is=="function"?Object.is:pL;function Nu(e,a){if(We(e,a))return!0;if(typeof e!="object"||e===null||typeof a!="object"||a===null)return!1;var t=Object.keys(e),l=Object.keys(a);if(t.length!==l.length)return!1;for(l=0;l<t.length;l++){var u=t[l];if(!xr.call(a,u)||!We(e[u],a[u]))return!1}return!0}function hf(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function xf(e,a){var t=hf(e);e=0;for(var l;t;){if(t.nodeType===3){if(l=e+t.textContent.length,e<=a&&l>=a)return{node:t,offset:a-e};e=l}e:{for(;t;){if(t.nextSibling){t=t.nextSibling;break e}t=t.parentNode}t=void 0}t=hf(t)}}function $c(e,a){return e&&a?e===a?!0:e&&e.nodeType===3?!1:a&&a.nodeType===3?$c(e,a.parentNode):"contains"in e?e.contains(a):e.compareDocumentPosition?!!(e.compareDocumentPosition(a)&16):!1:!1}function em(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var a=rn(e.document);a instanceof e.HTMLIFrameElement;){try{var t=typeof a.contentWindow.location.href=="string"}catch{t=!1}if(t)e=a.contentWindow;else break;a=rn(e.document)}return a}function hi(e){var a=e&&e.nodeName&&e.nodeName.toLowerCase();return a&&(a==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||a==="textarea"||e.contentEditable==="true")}var gL=Xa&&"documentMode"in document&&11>=document.documentMode,Il=null,Ir=null,Au=null,kr=!1;function Lf(e,a,t){var l=t.window===t?t.document:t.nodeType===9?t:t.ownerDocument;kr||Il==null||Il!==rn(l)||(l=Il,"selectionStart"in l&&hi(l)?l={start:l.selectionStart,end:l.selectionEnd}:(l=(l.ownerDocument&&l.ownerDocument.defaultView||window).getSelection(),l={anchorNode:l.anchorNode,anchorOffset:l.anchorOffset,focusNode:l.focusNode,focusOffset:l.focusOffset}),Au&&Nu(Au,l)||(Au=l,l=Tn(Ir,"onSelect"),0<l.length&&(a=new qn("onSelect","select",null,a,t),e.push({event:a,listeners:l}),a.target=Il)))}function _t(e,a){var t={};return t[e.toLowerCase()]=a.toLowerCase(),t["Webkit"+e]="webkit"+a,t["Moz"+e]="moz"+a,t}var kl={animationend:_t("Animation","AnimationEnd"),animationiteration:_t("Animation","AnimationIteration"),animationstart:_t("Animation","AnimationStart"),transitionrun:_t("Transition","TransitionRun"),transitionstart:_t("Transition","TransitionStart"),transitioncancel:_t("Transition","TransitionCancel"),transitionend:_t("Transition","TransitionEnd")},Ps={},am={};Xa&&(am=document.createElement("div").style,"AnimationEvent"in window||(delete kl.animationend.animation,delete kl.animationiteration.animation,delete kl.animationstart.animation),"TransitionEvent"in window||delete kl.transitionend.transition);function tl(e){if(Ps[e])return Ps[e];if(!kl[e])return e;var a=kl[e],t;for(t in a)if(a.hasOwnProperty(t)&&t in am)return Ps[e]=a[t];return e}var tm=tl("animationend"),lm=tl("animationiteration"),um=tl("animationstart"),hL=tl("transitionrun"),xL=tl("transitionstart"),LL=tl("transitioncancel"),om=tl("transitionend"),nm=new Map,Ar="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Ar.push("scrollEnd");function Sa(e,a){nm.set(e,a),el(a,[e])}var dn=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var a=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(a))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},la=[],Al=0,xi=0;function zn(){for(var e=Al,a=xi=Al=0;a<e;){var t=la[a];la[a++]=null;var l=la[a];la[a++]=null;var u=la[a];la[a++]=null;var o=la[a];if(la[a++]=null,l!==null&&u!==null){var n=l.pending;n===null?u.next=u:(u.next=n.next,n.next=u),l.pending=u}o!==0&&sm(t,u,o)}}function _n(e,a,t,l){la[Al++]=e,la[Al++]=a,la[Al++]=t,la[Al++]=l,xi|=l,e.lanes|=l,e=e.alternate,e!==null&&(e.lanes|=l)}function Li(e,a,t,l){return _n(e,a,t,l),fn(e)}function ll(e,a){return _n(e,null,null,a),fn(e)}function sm(e,a,t){e.lanes|=t;var l=e.alternate;l!==null&&(l.lanes|=t);for(var u=!1,o=e.return;o!==null;)o.childLanes|=t,l=o.alternate,l!==null&&(l.childLanes|=t),o.tag===22&&(e=o.stateNode,e===null||e._visibility&1||(u=!0)),e=o,o=o.return;return e.tag===3?(o=e.stateNode,u&&a!==null&&(u=31-Qe(t),e=o.hiddenUpdates,l=e[u],l===null?e[u]=[a]:l.push(a),a.lane=t|536870912),o):null}function fn(e){if(50<qu)throw qu=0,Kr=null,Error(C(185));for(var a=e.return;a!==null;)e=a,a=e.return;return e.tag===3?e.stateNode:null}var Tl={};function SL(e,a,t,l){this.tag=e,this.key=t,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=a,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=l,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function je(e,a,t,l){return new SL(e,a,t,l)}function Si(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Fa(e,a){var t=e.alternate;return t===null?(t=je(e.tag,a,e.key,e.mode),t.elementType=e.elementType,t.type=e.type,t.stateNode=e.stateNode,t.alternate=e,e.alternate=t):(t.pendingProps=a,t.type=e.type,t.flags=0,t.subtreeFlags=0,t.deletions=null),t.flags=e.flags&65011712,t.childLanes=e.childLanes,t.lanes=e.lanes,t.child=e.child,t.memoizedProps=e.memoizedProps,t.memoizedState=e.memoizedState,t.updateQueue=e.updateQueue,a=e.dependencies,t.dependencies=a===null?null:{lanes:a.lanes,firstContext:a.firstContext},t.sibling=e.sibling,t.index=e.index,t.ref=e.ref,t.refCleanup=e.refCleanup,t}function rm(e,a){e.flags&=65011714;var t=e.alternate;return t===null?(e.childLanes=0,e.lanes=a,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=t.childLanes,e.lanes=t.lanes,e.child=t.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=t.memoizedProps,e.memoizedState=t.memoizedState,e.updateQueue=t.updateQueue,e.type=t.type,a=t.dependencies,e.dependencies=a===null?null:{lanes:a.lanes,firstContext:a.firstContext}),e}function Ko(e,a,t,l,u,o){var n=0;if(l=e,typeof e=="function")Si(e)&&(n=1);else if(typeof e=="string")n=bS(e,t,Ta.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case mr:return e=je(31,t,a,u),e.elementType=mr,e.lanes=o,e;case Sl:return Xt(t.children,u,o,a);case Tc:n=8,u|=24;break;case dr:return e=je(12,t,a,u|2),e.elementType=dr,e.lanes=o,e;case fr:return e=je(13,t,a,u),e.elementType=fr,e.lanes=o,e;case cr:return e=je(19,t,a,u),e.elementType=cr,e.lanes=o,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case _a:n=10;break e;case wc:n=9;break e;case oi:n=11;break e;case ni:n=14;break e;case lt:n=16,l=null;break e}n=29,t=Error(C(130,e===null?"null":typeof e,"")),l=null}return a=je(n,t,a,u),a.elementType=e,a.type=l,a.lanes=o,a}function Xt(e,a,t,l){return e=je(7,e,l,a),e.lanes=t,e}function Fs(e,a,t){return e=je(6,e,null,a),e.lanes=t,e}function im(e){var a=je(18,null,null,0);return a.stateNode=e,a}function Gs(e,a,t){return a=je(4,e.children!==null?e.children:[],e.key,a),a.lanes=t,a.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},a}var Sf=new WeakMap;function ra(e,a){if(typeof e=="object"&&e!==null){var t=Sf.get(e);return t!==void 0?t:(a={value:e,source:a,stack:$d(a)},Sf.set(e,a),a)}return{value:e,source:a,stack:$d(a)}}var wl=[],Ml=0,cn=null,Pu=0,oa=[],na=0,vt=null,Ia=1,ka="";function Ua(e,a){wl[Ml++]=Pu,wl[Ml++]=cn,cn=e,Pu=a}function dm(e,a,t){oa[na++]=Ia,oa[na++]=ka,oa[na++]=vt,vt=e;var l=Ia;e=ka;var u=32-Qe(l)-1;l&=~(1<<u),t+=1;var o=32-Qe(a)+u;if(30<o){var n=u-u%5;o=(l&(1<<n)-1).toString(32),l>>=n,u-=n,Ia=1<<32-Qe(a)+u|t<<u|l,ka=o+e}else Ia=1<<o|t<<u|l,ka=e}function yi(e){e.return!==null&&(Ua(e,1),dm(e,1,0))}function Ci(e){for(;e===cn;)cn=wl[--Ml],wl[Ml]=null,Pu=wl[--Ml],wl[Ml]=null;for(;e===vt;)vt=oa[--na],oa[na]=null,ka=oa[--na],oa[na]=null,Ia=oa[--na],oa[na]=null}function fm(e,a){oa[na++]=Ia,oa[na++]=ka,oa[na++]=vt,Ia=a.id,ka=a.overflow,vt=e}var Ie=null,ae=null,N=!1,gt=null,ia=!1,Tr=Error(C(519));function It(e){var a=Error(C(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Fu(ra(a,e)),Tr}function yf(e){var a=e.stateNode,t=e.type,l=e.memoizedProps;switch(a[ve]=e,a[Ne]=l,t){case"dialog":U("cancel",a),U("close",a);break;case"iframe":case"object":case"embed":U("load",a);break;case"video":case"audio":for(t=0;t<ju.length;t++)U(ju[t],a);break;case"source":U("error",a);break;case"img":case"image":case"link":U("error",a),U("load",a);break;case"details":U("toggle",a);break;case"input":U("invalid",a),Pc(a,l.value,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name,!0);break;case"select":U("invalid",a);break;case"textarea":U("invalid",a),Gc(a,l.value,l.defaultValue,l.children)}t=l.children,typeof t!="string"&&typeof t!="number"&&typeof t!="bigint"||a.textContent===""+t||l.suppressHydrationWarning===!0||Kp(a.textContent,t)?(l.popover!=null&&(U("beforetoggle",a),U("toggle",a)),l.onScroll!=null&&U("scroll",a),l.onScrollEnd!=null&&U("scrollend",a),l.onClick!=null&&(a.onclick=Na),a=!0):a=!1,a||It(e,!0)}function Cf(e){for(Ie=e.return;Ie;)switch(Ie.tag){case 5:case 31:case 13:ia=!1;return;case 27:case 3:ia=!0;return;default:Ie=Ie.return}}function gl(e){if(e!==Ie)return!1;if(!N)return Cf(e),N=!0,!1;var a=e.tag,t;if((t=a!==3&&a!==27)&&((t=a===5)&&(t=e.type,t=!(t!=="form"&&t!=="button")||Wr(e.type,e.memoizedProps)),t=!t),t&&ae&&It(e),Cf(e),a===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(317));ae=ic(e)}else if(a===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(317));ae=ic(e)}else a===27?(a=ae,wt(e.type)?(e=ti,ti=null,ae=e):ae=a):ae=Ie?fa(e.stateNode.nextSibling):null;return!0}function Zt(){ae=Ie=null,N=!1}function Vs(){var e=gt;return e!==null&&(ze===null?ze=e:ze.push.apply(ze,e),gt=null),e}function Fu(e){gt===null?gt=[e]:gt.push(e)}var wr=wa(null),ul=null,Pa=null;function ot(e,a,t){Z(wr,a._currentValue),a._currentValue=t}function Ga(e){e._currentValue=wr.current,Ce(wr)}function Mr(e,a,t){for(;e!==null;){var l=e.alternate;if((e.childLanes&a)!==a?(e.childLanes|=a,l!==null&&(l.childLanes|=a)):l!==null&&(l.childLanes&a)!==a&&(l.childLanes|=a),e===t)break;e=e.return}}function Dr(e,a,t,l){var u=e.child;for(u!==null&&(u.return=e);u!==null;){var o=u.dependencies;if(o!==null){var n=u.child;o=o.firstContext;e:for(;o!==null;){var s=o;o=u;for(var r=0;r<a.length;r++)if(s.context===a[r]){o.lanes|=t,s=o.alternate,s!==null&&(s.lanes|=t),Mr(o.return,t,e),l||(n=null);break e}o=s.next}}else if(u.tag===18){if(n=u.return,n===null)throw Error(C(341));n.lanes|=t,o=n.alternate,o!==null&&(o.lanes|=t),Mr(n,t,e),n=null}else n=u.child;if(n!==null)n.return=u;else for(n=u;n!==null;){if(n===e){n=null;break}if(u=n.sibling,u!==null){u.return=n.return,n=u;break}n=n.return}u=n}}function Jl(e,a,t,l){e=null;for(var u=a,o=!1;u!==null;){if(!o){if((u.flags&524288)!==0)o=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var n=u.alternate;if(n===null)throw Error(C(387));if(n=n.memoizedProps,n!==null){var s=u.type;We(u.pendingProps.value,n.value)||(e!==null?e.push(s):e=[s])}}else if(u===un.current){if(n=u.alternate,n===null)throw Error(C(387));n.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(e!==null?e.push(Yu):e=[Yu])}u=u.return}e!==null&&Dr(a,e,t,l),a.flags|=262144}function mn(e){for(e=e.firstContext;e!==null;){if(!We(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Qt(e){ul=e,Pa=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ke(e){return cm(ul,e)}function Eo(e,a){return ul===null&&Qt(e),cm(e,a)}function cm(e,a){var t=a._currentValue;if(a={context:a,memoizedValue:t,next:null},Pa===null){if(e===null)throw Error(C(308));Pa=a,e.dependencies={lanes:0,firstContext:a},e.flags|=524288}else Pa=Pa.next=a;return t}var yL=typeof AbortController<"u"?AbortController:function(){var e=[],a=this.signal={aborted:!1,addEventListener:function(t,l){e.push(l)}};this.abort=function(){a.aborted=!0,e.forEach(function(t){return t()})}},CL=ge.unstable_scheduleCallback,bL=ge.unstable_NormalPriority,ce={$$typeof:_a,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function bi(){return{controller:new yL,data:new Map,refCount:0}}function lo(e){e.refCount--,e.refCount===0&&CL(bL,function(){e.controller.abort()})}var Tu=null,Rr=0,Pl=0,Ol=null;function vL(e,a){if(Tu===null){var t=Tu=[];Rr=0,Pl=Ki(),Ol={status:"pending",value:void 0,then:function(l){t.push(l)}}}return Rr++,a.then(bf,bf),a}function bf(){if(--Rr===0&&Tu!==null){Ol!==null&&(Ol.status="fulfilled");var e=Tu;Tu=null,Pl=0,Ol=null;for(var a=0;a<e.length;a++)(0,e[a])()}}function IL(e,a){var t=[],l={status:"pending",value:null,reason:null,then:function(u){t.push(u)}};return e.then(function(){l.status="fulfilled",l.value=a;for(var u=0;u<t.length;u++)(0,t[u])(a)},function(u){for(l.status="rejected",l.reason=u,u=0;u<t.length;u++)(0,t[u])(void 0)}),l}var vf=B.S;B.S=function(e,a){Ap=Ye(),typeof a=="object"&&a!==null&&typeof a.then=="function"&&vL(e,a),vf!==null&&vf(e,a)};var jt=wa(null);function vi(){var e=jt.current;return e!==null?e:Y.pooledCache}function Yo(e,a){a===null?Z(jt,jt.current):Z(jt,a.pool)}function mm(){var e=vi();return e===null?null:{parent:ce._currentValue,pool:e}}var Wl=Error(C(460)),Ii=Error(C(474)),Nn=Error(C(542)),pn={then:function(){}};function If(e){return e=e.status,e==="fulfilled"||e==="rejected"}function pm(e,a,t){switch(t=e[t],t===void 0?e.push(a):t!==a&&(a.then(Na,Na),a=t),a.status){case"fulfilled":return a.value;case"rejected":throw e=a.reason,Af(e),e;default:if(typeof a.status=="string")a.then(Na,Na);else{if(e=Y,e!==null&&100<e.shellSuspendCounter)throw Error(C(482));e=a,e.status="pending",e.then(function(l){if(a.status==="pending"){var u=a;u.status="fulfilled",u.value=l}},function(l){if(a.status==="pending"){var u=a;u.status="rejected",u.reason=l}})}switch(a.status){case"fulfilled":return a.value;case"rejected":throw e=a.reason,Af(e),e}throw Kt=a,Wl}}function Ft(e){try{var a=e._init;return a(e._payload)}catch(t){throw t!==null&&typeof t=="object"&&typeof t.then=="function"?(Kt=t,Wl):t}}var Kt=null;function kf(){if(Kt===null)throw Error(C(459));var e=Kt;return Kt=null,e}function Af(e){if(e===Wl||e===Nn)throw Error(C(483))}var ql=null,Gu=0;function Oo(e){var a=Gu;return Gu+=1,ql===null&&(ql=[]),pm(ql,e,a)}function pu(e,a){a=a.props.ref,e.ref=a!==void 0?a:null}function qo(e,a){throw a.$$typeof===dx?Error(C(525)):(e=Object.prototype.toString.call(a),Error(C(31,e==="[object Object]"?"object with keys {"+Object.keys(a).join(", ")+"}":e)))}function gm(e){function a(h,d){if(e){var m=h.deletions;m===null?(h.deletions=[d],h.flags|=16):m.push(d)}}function t(h,d){if(!e)return null;for(;d!==null;)a(h,d),d=d.sibling;return null}function l(h){for(var d=new Map;h!==null;)h.key!==null?d.set(h.key,h):d.set(h.index,h),h=h.sibling;return d}function u(h,d){return h=Fa(h,d),h.index=0,h.sibling=null,h}function o(h,d,m){return h.index=m,e?(m=h.alternate,m!==null?(m=m.index,m<d?(h.flags|=67108866,d):m):(h.flags|=67108866,d)):(h.flags|=1048576,d)}function n(h){return e&&h.alternate===null&&(h.flags|=67108866),h}function s(h,d,m,x){return d===null||d.tag!==6?(d=Fs(m,h.mode,x),d.return=h,d):(d=u(d,m),d.return=h,d)}function r(h,d,m,x){var L=m.type;return L===Sl?p(h,d,m.props.children,x,m.key):d!==null&&(d.elementType===L||typeof L=="object"&&L!==null&&L.$$typeof===lt&&Ft(L)===d.type)?(d=u(d,m.props),pu(d,m),d.return=h,d):(d=Ko(m.type,m.key,m.props,null,h.mode,x),pu(d,m),d.return=h,d)}function i(h,d,m,x){return d===null||d.tag!==4||d.stateNode.containerInfo!==m.containerInfo||d.stateNode.implementation!==m.implementation?(d=Gs(m,h.mode,x),d.return=h,d):(d=u(d,m.children||[]),d.return=h,d)}function p(h,d,m,x,L){return d===null||d.tag!==7?(d=Xt(m,h.mode,x,L),d.return=h,d):(d=u(d,m),d.return=h,d)}function g(h,d,m){if(typeof d=="string"&&d!==""||typeof d=="number"||typeof d=="bigint")return d=Fs(""+d,h.mode,m),d.return=h,d;if(typeof d=="object"&&d!==null){switch(d.$$typeof){case ko:return m=Ko(d.type,d.key,d.props,null,h.mode,m),pu(m,d),m.return=h,m;case Su:return d=Gs(d,h.mode,m),d.return=h,d;case lt:return d=Ft(d),g(h,d,m)}if(yu(d)||cu(d))return d=Xt(d,h.mode,m,null),d.return=h,d;if(typeof d.then=="function")return g(h,Oo(d),m);if(d.$$typeof===_a)return g(h,Eo(h,d),m);qo(h,d)}return null}function f(h,d,m,x){var L=d!==null?d.key:null;if(typeof m=="string"&&m!==""||typeof m=="number"||typeof m=="bigint")return L!==null?null:s(h,d,""+m,x);if(typeof m=="object"&&m!==null){switch(m.$$typeof){case ko:return m.key===L?r(h,d,m,x):null;case Su:return m.key===L?i(h,d,m,x):null;case lt:return m=Ft(m),f(h,d,m,x)}if(yu(m)||cu(m))return L!==null?null:p(h,d,m,x,null);if(typeof m.then=="function")return f(h,d,Oo(m),x);if(m.$$typeof===_a)return f(h,d,Eo(h,m),x);qo(h,m)}return null}function c(h,d,m,x,L){if(typeof x=="string"&&x!==""||typeof x=="number"||typeof x=="bigint")return h=h.get(m)||null,s(d,h,""+x,L);if(typeof x=="object"&&x!==null){switch(x.$$typeof){case ko:return h=h.get(x.key===null?m:x.key)||null,r(d,h,x,L);case Su:return h=h.get(x.key===null?m:x.key)||null,i(d,h,x,L);case lt:return x=Ft(x),c(h,d,m,x,L)}if(yu(x)||cu(x))return h=h.get(m)||null,p(d,h,x,L,null);if(typeof x.then=="function")return c(h,d,m,Oo(x),L);if(x.$$typeof===_a)return c(h,d,m,Eo(d,x),L);qo(d,x)}return null}function S(h,d,m,x){for(var L=null,k=null,v=d,y=d=0,I=null;v!==null&&y<m.length;y++){v.index>y?(I=v,v=null):I=v.sibling;var M=f(h,v,m[y],x);if(M===null){v===null&&(v=I);break}e&&v&&M.alternate===null&&a(h,v),d=o(M,d,y),k===null?L=M:k.sibling=M,k=M,v=I}if(y===m.length)return t(h,v),N&&Ua(h,y),L;if(v===null){for(;y<m.length;y++)v=g(h,m[y],x),v!==null&&(d=o(v,d,y),k===null?L=v:k.sibling=v,k=v);return N&&Ua(h,y),L}for(v=l(v);y<m.length;y++)I=c(v,h,y,m[y],x),I!==null&&(e&&I.alternate!==null&&v.delete(I.key===null?y:I.key),d=o(I,d,y),k===null?L=I:k.sibling=I,k=I);return e&&v.forEach(function(oe){return a(h,oe)}),N&&Ua(h,y),L}function b(h,d,m,x){if(m==null)throw Error(C(151));for(var L=null,k=null,v=d,y=d=0,I=null,M=m.next();v!==null&&!M.done;y++,M=m.next()){v.index>y?(I=v,v=null):I=v.sibling;var oe=f(h,v,M.value,x);if(oe===null){v===null&&(v=I);break}e&&v&&oe.alternate===null&&a(h,v),d=o(oe,d,y),k===null?L=oe:k.sibling=oe,k=oe,v=I}if(M.done)return t(h,v),N&&Ua(h,y),L;if(v===null){for(;!M.done;y++,M=m.next())M=g(h,M.value,x),M!==null&&(d=o(M,d,y),k===null?L=M:k.sibling=M,k=M);return N&&Ua(h,y),L}for(v=l(v);!M.done;y++,M=m.next())M=c(v,h,y,M.value,x),M!==null&&(e&&M.alternate!==null&&v.delete(M.key===null?y:M.key),d=o(M,d,y),k===null?L=M:k.sibling=M,k=M);return e&&v.forEach(function(aa){return a(h,aa)}),N&&Ua(h,y),L}function A(h,d,m,x){if(typeof m=="object"&&m!==null&&m.type===Sl&&m.key===null&&(m=m.props.children),typeof m=="object"&&m!==null){switch(m.$$typeof){case ko:e:{for(var L=m.key;d!==null;){if(d.key===L){if(L=m.type,L===Sl){if(d.tag===7){t(h,d.sibling),x=u(d,m.props.children),x.return=h,h=x;break e}}else if(d.elementType===L||typeof L=="object"&&L!==null&&L.$$typeof===lt&&Ft(L)===d.type){t(h,d.sibling),x=u(d,m.props),pu(x,m),x.return=h,h=x;break e}t(h,d);break}else a(h,d);d=d.sibling}m.type===Sl?(x=Xt(m.props.children,h.mode,x,m.key),x.return=h,h=x):(x=Ko(m.type,m.key,m.props,null,h.mode,x),pu(x,m),x.return=h,h=x)}return n(h);case Su:e:{for(L=m.key;d!==null;){if(d.key===L)if(d.tag===4&&d.stateNode.containerInfo===m.containerInfo&&d.stateNode.implementation===m.implementation){t(h,d.sibling),x=u(d,m.children||[]),x.return=h,h=x;break e}else{t(h,d);break}else a(h,d);d=d.sibling}x=Gs(m,h.mode,x),x.return=h,h=x}return n(h);case lt:return m=Ft(m),A(h,d,m,x)}if(yu(m))return S(h,d,m,x);if(cu(m)){if(L=cu(m),typeof L!="function")throw Error(C(150));return m=L.call(m),b(h,d,m,x)}if(typeof m.then=="function")return A(h,d,Oo(m),x);if(m.$$typeof===_a)return A(h,d,Eo(h,m),x);qo(h,m)}return typeof m=="string"&&m!==""||typeof m=="number"||typeof m=="bigint"?(m=""+m,d!==null&&d.tag===6?(t(h,d.sibling),x=u(d,m),x.return=h,h=x):(t(h,d),x=Fs(m,h.mode,x),x.return=h,h=x),n(h)):t(h,d)}return function(h,d,m,x){try{Gu=0;var L=A(h,d,m,x);return ql=null,L}catch(v){if(v===Wl||v===Nn)throw v;var k=je(29,v,null,h.mode);return k.lanes=x,k.return=h,k}}}var Jt=gm(!0),hm=gm(!1),ut=!1;function ki(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Br(e,a){e=e.updateQueue,a.updateQueue===e&&(a.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function ht(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function xt(e,a,t){var l=e.updateQueue;if(l===null)return null;if(l=l.shared,(P&2)!==0){var u=l.pending;return u===null?a.next=a:(a.next=u.next,u.next=a),l.pending=a,a=fn(e),sm(e,null,t),a}return _n(e,l,a,t),fn(e)}function wu(e,a,t){if(a=a.updateQueue,a!==null&&(a=a.shared,(t&4194048)!==0)){var l=a.lanes;l&=e.pendingLanes,t|=l,a.lanes=t,Oc(e,t)}}function Xs(e,a){var t=e.updateQueue,l=e.alternate;if(l!==null&&(l=l.updateQueue,t===l)){var u=null,o=null;if(t=t.firstBaseUpdate,t!==null){do{var n={lane:t.lane,tag:t.tag,payload:t.payload,callback:null,next:null};o===null?u=o=n:o=o.next=n,t=t.next}while(t!==null);o===null?u=o=a:o=o.next=a}else u=o=a;t={baseState:l.baseState,firstBaseUpdate:u,lastBaseUpdate:o,shared:l.shared,callbacks:l.callbacks},e.updateQueue=t;return}e=t.lastBaseUpdate,e===null?t.firstBaseUpdate=a:e.next=a,t.lastBaseUpdate=a}var Er=!1;function Mu(){if(Er){var e=Ol;if(e!==null)throw e}}function Du(e,a,t,l){Er=!1;var u=e.updateQueue;ut=!1;var o=u.firstBaseUpdate,n=u.lastBaseUpdate,s=u.shared.pending;if(s!==null){u.shared.pending=null;var r=s,i=r.next;r.next=null,n===null?o=i:n.next=i,n=r;var p=e.alternate;p!==null&&(p=p.updateQueue,s=p.lastBaseUpdate,s!==n&&(s===null?p.firstBaseUpdate=i:s.next=i,p.lastBaseUpdate=r))}if(o!==null){var g=u.baseState;n=0,p=i=r=null,s=o;do{var f=s.lane&-536870913,c=f!==s.lane;if(c?(_&f)===f:(l&f)===f){f!==0&&f===Pl&&(Er=!0),p!==null&&(p=p.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});e:{var S=e,b=s;f=a;var A=t;switch(b.tag){case 1:if(S=b.payload,typeof S=="function"){g=S.call(A,g,f);break e}g=S;break e;case 3:S.flags=S.flags&-65537|128;case 0:if(S=b.payload,f=typeof S=="function"?S.call(A,g,f):S,f==null)break e;g=te({},g,f);break e;case 2:ut=!0}}f=s.callback,f!==null&&(e.flags|=64,c&&(e.flags|=8192),c=u.callbacks,c===null?u.callbacks=[f]:c.push(f))}else c={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},p===null?(i=p=c,r=g):p=p.next=c,n|=f;if(s=s.next,s===null){if(s=u.shared.pending,s===null)break;c=s,s=c.next,c.next=null,u.lastBaseUpdate=c,u.shared.pending=null}}while(!0);p===null&&(r=g),u.baseState=r,u.firstBaseUpdate=i,u.lastBaseUpdate=p,o===null&&(u.shared.lanes=0),At|=n,e.lanes=n,e.memoizedState=g}}function xm(e,a){if(typeof e!="function")throw Error(C(191,e));e.call(a)}function Lm(e,a){var t=e.callbacks;if(t!==null)for(e.callbacks=null,e=0;e<t.length;e++)xm(t[e],a)}var Fl=wa(null),gn=wa(0);function Tf(e,a){e=Za,Z(gn,e),Z(Fl,a),Za=e|a.baseLanes}function Or(){Z(gn,Za),Z(Fl,Fl.current)}function Ai(){Za=gn.current,Ce(Fl),Ce(gn)}var $e=wa(null),da=null;function nt(e){var a=e.alternate;Z(re,re.current&1),Z($e,e),da===null&&(a===null||Fl.current!==null||a.memoizedState!==null)&&(da=e)}function qr(e){Z(re,re.current),Z($e,e),da===null&&(da=e)}function Sm(e){e.tag===22?(Z(re,re.current),Z($e,e),da===null&&(da=e)):st(e)}function st(){Z(re,re.current),Z($e,$e.current)}function Xe(e){Ce($e),da===e&&(da=null),Ce(re)}var re=wa(0);function hn(e){for(var a=e;a!==null;){if(a.tag===13){var t=a.memoizedState;if(t!==null&&(t=t.dehydrated,t===null||ei(t)||ai(t)))return a}else if(a.tag===19&&(a.memoizedProps.revealOrder==="forwards"||a.memoizedProps.revealOrder==="backwards"||a.memoizedProps.revealOrder==="unstable_legacy-backwards"||a.memoizedProps.revealOrder==="together")){if((a.flags&128)!==0)return a}else if(a.child!==null){a.child.return=a,a=a.child;continue}if(a===e)break;for(;a.sibling===null;){if(a.return===null||a.return===e)return null;a=a.return}a.sibling.return=a.return,a=a.sibling}return null}var ja=0,O=null,K=null,de=null,xn=!1,Hl=!1,Wt=!1,Ln=0,Vu=0,Ul=null,kL=0;function ne(){throw Error(C(321))}function Ti(e,a){if(a===null)return!1;for(var t=0;t<a.length&&t<e.length;t++)if(!We(e[t],a[t]))return!1;return!0}function wi(e,a,t,l,u,o){return ja=o,O=a,a.memoizedState=null,a.updateQueue=null,a.lanes=0,B.H=e===null||e.memoizedState===null?Qm:_i,Wt=!1,o=t(l,u),Wt=!1,Hl&&(o=Cm(a,t,l,u)),ym(e),o}function ym(e){B.H=Xu;var a=K!==null&&K.next!==null;if(ja=0,de=K=O=null,xn=!1,Vu=0,Ul=null,a)throw Error(C(300));e===null||me||(e=e.dependencies,e!==null&&mn(e)&&(me=!0))}function Cm(e,a,t,l){O=e;var u=0;do{if(Hl&&(Ul=null),Vu=0,Hl=!1,25<=u)throw Error(C(301));if(u+=1,de=K=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}B.H=Jm,o=a(t,l)}while(Hl);return o}function AL(){var e=B.H,a=e.useState()[0];return a=typeof a.then=="function"?uo(a):a,e=e.useState()[0],(K!==null?K.memoizedState:null)!==e&&(O.flags|=1024),a}function Mi(){var e=Ln!==0;return Ln=0,e}function Di(e,a,t){a.updateQueue=e.updateQueue,a.flags&=-2053,e.lanes&=~t}function Ri(e){if(xn){for(e=e.memoizedState;e!==null;){var a=e.queue;a!==null&&(a.pending=null),e=e.next}xn=!1}ja=0,de=K=O=null,Hl=!1,Vu=Ln=0,Ul=null}function Oe(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return de===null?O.memoizedState=de=e:de=de.next=e,de}function ie(){if(K===null){var e=O.alternate;e=e!==null?e.memoizedState:null}else e=K.next;var a=de===null?O.memoizedState:de.next;if(a!==null)de=a,K=e;else{if(e===null)throw O.alternate===null?Error(C(467)):Error(C(310));K=e,e={memoizedState:K.memoizedState,baseState:K.baseState,baseQueue:K.baseQueue,queue:K.queue,next:null},de===null?O.memoizedState=de=e:de=de.next=e}return de}function Pn(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function uo(e){var a=Vu;return Vu+=1,Ul===null&&(Ul=[]),e=pm(Ul,e,a),a=O,(de===null?a.memoizedState:de.next)===null&&(a=a.alternate,B.H=a===null||a.memoizedState===null?Qm:_i),e}function Fn(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return uo(e);if(e.$$typeof===_a)return ke(e)}throw Error(C(438,String(e)))}function Bi(e){var a=null,t=O.updateQueue;if(t!==null&&(a=t.memoCache),a==null){var l=O.alternate;l!==null&&(l=l.updateQueue,l!==null&&(l=l.memoCache,l!=null&&(a={data:l.data.map(function(u){return u.slice()}),index:0})))}if(a==null&&(a={data:[],index:0}),t===null&&(t=Pn(),O.updateQueue=t),t.memoCache=a,t=a.data[a.index],t===void 0)for(t=a.data[a.index]=Array(e),l=0;l<e;l++)t[l]=fx;return a.index++,t}function Ka(e,a){return typeof a=="function"?a(e):a}function Zo(e){var a=ie();return Ei(a,K,e)}function Ei(e,a,t){var l=e.queue;if(l===null)throw Error(C(311));l.lastRenderedReducer=t;var u=e.baseQueue,o=l.pending;if(o!==null){if(u!==null){var n=u.next;u.next=o.next,o.next=n}a.baseQueue=u=o,l.pending=null}if(o=e.baseState,u===null)e.memoizedState=o;else{a=u.next;var s=n=null,r=null,i=a,p=!1;do{var g=i.lane&-536870913;if(g!==i.lane?(_&g)===g:(ja&g)===g){var f=i.revertLane;if(f===0)r!==null&&(r=r.next={lane:0,revertLane:0,gesture:null,action:i.action,hasEagerState:i.hasEagerState,eagerState:i.eagerState,next:null}),g===Pl&&(p=!0);else if((ja&f)===f){i=i.next,f===Pl&&(p=!0);continue}else g={lane:0,revertLane:i.revertLane,gesture:null,action:i.action,hasEagerState:i.hasEagerState,eagerState:i.eagerState,next:null},r===null?(s=r=g,n=o):r=r.next=g,O.lanes|=f,At|=f;g=i.action,Wt&&t(o,g),o=i.hasEagerState?i.eagerState:t(o,g)}else f={lane:g,revertLane:i.revertLane,gesture:i.gesture,action:i.action,hasEagerState:i.hasEagerState,eagerState:i.eagerState,next:null},r===null?(s=r=f,n=o):r=r.next=f,O.lanes|=g,At|=g;i=i.next}while(i!==null&&i!==a);if(r===null?n=o:r.next=s,!We(o,e.memoizedState)&&(me=!0,p&&(t=Ol,t!==null)))throw t;e.memoizedState=o,e.baseState=n,e.baseQueue=r,l.lastRenderedState=o}return u===null&&(l.lanes=0),[e.memoizedState,l.dispatch]}function js(e){var a=ie(),t=a.queue;if(t===null)throw Error(C(311));t.lastRenderedReducer=e;var l=t.dispatch,u=t.pending,o=a.memoizedState;if(u!==null){t.pending=null;var n=u=u.next;do o=e(o,n.action),n=n.next;while(n!==u);We(o,a.memoizedState)||(me=!0),a.memoizedState=o,a.baseQueue===null&&(a.baseState=o),t.lastRenderedState=o}return[o,l]}function bm(e,a,t){var l=O,u=ie(),o=N;if(o){if(t===void 0)throw Error(C(407));t=t()}else t=a();var n=!We((K||u).memoizedState,t);if(n&&(u.memoizedState=t,me=!0),u=u.queue,Oi(km.bind(null,l,u,e),[e]),u.getSnapshot!==a||n||de!==null&&de.memoizedState.tag&1){if(l.flags|=2048,Gl(9,{destroy:void 0},Im.bind(null,l,u,t,a),null),Y===null)throw Error(C(349));o||(ja&127)!==0||vm(l,a,t)}return t}function vm(e,a,t){e.flags|=16384,e={getSnapshot:a,value:t},a=O.updateQueue,a===null?(a=Pn(),O.updateQueue=a,a.stores=[e]):(t=a.stores,t===null?a.stores=[e]:t.push(e))}function Im(e,a,t,l){a.value=t,a.getSnapshot=l,Am(a)&&Tm(e)}function km(e,a,t){return t(function(){Am(a)&&Tm(e)})}function Am(e){var a=e.getSnapshot;e=e.value;try{var t=a();return!We(e,t)}catch{return!0}}function Tm(e){var a=ll(e,2);a!==null&&_e(a,e,2)}function Hr(e){var a=Oe();if(typeof e=="function"){var t=e;if(e=t(),Wt){it(!0);try{t()}finally{it(!1)}}}return a.memoizedState=a.baseState=e,a.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ka,lastRenderedState:e},a}function wm(e,a,t,l){return e.baseState=t,Ei(e,K,typeof l=="function"?l:Ka)}function TL(e,a,t,l,u){if(Vn(e))throw Error(C(485));if(e=a.action,e!==null){var o={payload:u,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(n){o.listeners.push(n)}};B.T!==null?t(!0):o.isTransition=!1,l(o),t=a.pending,t===null?(o.next=a.pending=o,Mm(a,o)):(o.next=t.next,a.pending=t.next=o)}}function Mm(e,a){var t=a.action,l=a.payload,u=e.state;if(a.isTransition){var o=B.T,n={};B.T=n;try{var s=t(u,l),r=B.S;r!==null&&r(n,s),wf(e,a,s)}catch(i){Ur(e,a,i)}finally{o!==null&&n.types!==null&&(o.types=n.types),B.T=o}}else try{o=t(u,l),wf(e,a,o)}catch(i){Ur(e,a,i)}}function wf(e,a,t){t!==null&&typeof t=="object"&&typeof t.then=="function"?t.then(function(l){Mf(e,a,l)},function(l){return Ur(e,a,l)}):Mf(e,a,t)}function Mf(e,a,t){a.status="fulfilled",a.value=t,Dm(a),e.state=t,a=e.pending,a!==null&&(t=a.next,t===a?e.pending=null:(t=t.next,a.next=t,Mm(e,t)))}function Ur(e,a,t){var l=e.pending;if(e.pending=null,l!==null){l=l.next;do a.status="rejected",a.reason=t,Dm(a),a=a.next;while(a!==l)}e.action=null}function Dm(e){e=e.listeners;for(var a=0;a<e.length;a++)(0,e[a])()}function Rm(e,a){return a}function Df(e,a){if(N){var t=Y.formState;if(t!==null){e:{var l=O;if(N){if(ae){a:{for(var u=ae,o=ia;u.nodeType!==8;){if(!o){u=null;break a}if(u=fa(u.nextSibling),u===null){u=null;break a}}o=u.data,u=o==="F!"||o==="F"?u:null}if(u){ae=fa(u.nextSibling),l=u.data==="F!";break e}}It(l)}l=!1}l&&(a=t[0])}}return t=Oe(),t.memoizedState=t.baseState=a,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Rm,lastRenderedState:a},t.queue=l,t=Km.bind(null,O,l),l.dispatch=t,l=Hr(!1),o=zi.bind(null,O,!1,l.queue),l=Oe(),u={state:a,dispatch:null,action:e,pending:null},l.queue=u,t=TL.bind(null,O,u,o,t),u.dispatch=t,l.memoizedState=e,[a,t,!1]}function Rf(e){var a=ie();return Bm(a,K,e)}function Bm(e,a,t){if(a=Ei(e,a,Rm)[0],e=Zo(Ka)[0],typeof a=="object"&&a!==null&&typeof a.then=="function")try{var l=uo(a)}catch(n){throw n===Wl?Nn:n}else l=a;a=ie();var u=a.queue,o=u.dispatch;return t!==a.memoizedState&&(O.flags|=2048,Gl(9,{destroy:void 0},wL.bind(null,u,t),null)),[l,o,e]}function wL(e,a){e.action=a}function Bf(e){var a=ie(),t=K;if(t!==null)return Bm(a,t,e);ie(),a=a.memoizedState,t=ie();var l=t.queue.dispatch;return t.memoizedState=e,[a,l,!1]}function Gl(e,a,t,l){return e={tag:e,create:t,deps:l,inst:a,next:null},a=O.updateQueue,a===null&&(a=Pn(),O.updateQueue=a),t=a.lastEffect,t===null?a.lastEffect=e.next=e:(l=t.next,t.next=e,e.next=l,a.lastEffect=e),e}function Em(){return ie().memoizedState}function Qo(e,a,t,l){var u=Oe();O.flags|=e,u.memoizedState=Gl(1|a,{destroy:void 0},t,l===void 0?null:l)}function Gn(e,a,t,l){var u=ie();l=l===void 0?null:l;var o=u.memoizedState.inst;K!==null&&l!==null&&Ti(l,K.memoizedState.deps)?u.memoizedState=Gl(a,o,t,l):(O.flags|=e,u.memoizedState=Gl(1|a,o,t,l))}function Ef(e,a){Qo(8390656,8,e,a)}function Oi(e,a){Gn(2048,8,e,a)}function ML(e){O.flags|=4;var a=O.updateQueue;if(a===null)a=Pn(),O.updateQueue=a,a.events=[e];else{var t=a.events;t===null?a.events=[e]:t.push(e)}}function Om(e){var a=ie().memoizedState;return ML({ref:a,nextImpl:e}),function(){if((P&2)!==0)throw Error(C(440));return a.impl.apply(void 0,arguments)}}function qm(e,a){return Gn(4,2,e,a)}function Hm(e,a){return Gn(4,4,e,a)}function Um(e,a){if(typeof a=="function"){e=e();var t=a(e);return function(){typeof t=="function"?t():a(null)}}if(a!=null)return e=e(),a.current=e,function(){a.current=null}}function zm(e,a,t){t=t!=null?t.concat([e]):null,Gn(4,4,Um.bind(null,a,e),t)}function qi(){}function _m(e,a){var t=ie();a=a===void 0?null:a;var l=t.memoizedState;return a!==null&&Ti(a,l[1])?l[0]:(t.memoizedState=[e,a],e)}function Nm(e,a){var t=ie();a=a===void 0?null:a;var l=t.memoizedState;if(a!==null&&Ti(a,l[1]))return l[0];if(l=e(),Wt){it(!0);try{e()}finally{it(!1)}}return t.memoizedState=[l,a],l}function Hi(e,a,t){return t===void 0||(ja&1073741824)!==0&&(_&261930)===0?e.memoizedState=a:(e.memoizedState=t,e=wp(),O.lanes|=e,At|=e,t)}function Pm(e,a,t,l){return We(t,a)?t:Fl.current!==null?(e=Hi(e,t,l),We(e,a)||(me=!0),e):(ja&42)===0||(ja&1073741824)!==0&&(_&261930)===0?(me=!0,e.memoizedState=t):(e=wp(),O.lanes|=e,At|=e,a)}function Fm(e,a,t,l,u){var o=F.p;F.p=o!==0&&8>o?o:8;var n=B.T,s={};B.T=s,zi(e,!1,a,t);try{var r=u(),i=B.S;if(i!==null&&i(s,r),r!==null&&typeof r=="object"&&typeof r.then=="function"){var p=IL(r,l);Ru(e,a,p,Je(e))}else Ru(e,a,l,Je(e))}catch(g){Ru(e,a,{then:function(){},status:"rejected",reason:g},Je())}finally{F.p=o,n!==null&&s.types!==null&&(n.types=s.types),B.T=n}}function DL(){}function zr(e,a,t,l){if(e.tag!==5)throw Error(C(476));var u=Gm(e).queue;Fm(e,u,a,Vt,t===null?DL:function(){return Vm(e),t(l)})}function Gm(e){var a=e.memoizedState;if(a!==null)return a;a={memoizedState:Vt,baseState:Vt,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ka,lastRenderedState:Vt},next:null};var t={};return a.next={memoizedState:t,baseState:t,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ka,lastRenderedState:t},next:null},e.memoizedState=a,e=e.alternate,e!==null&&(e.memoizedState=a),a}function Vm(e){var a=Gm(e);a.next===null&&(a=e.alternate.memoizedState),Ru(e,a.next.queue,{},Je())}function Ui(){return ke(Yu)}function Xm(){return ie().memoizedState}function jm(){return ie().memoizedState}function RL(e){for(var a=e.return;a!==null;){switch(a.tag){case 24:case 3:var t=Je();e=ht(t);var l=xt(a,e,t);l!==null&&(_e(l,a,t),wu(l,a,t)),a={cache:bi()},e.payload=a;return}a=a.return}}function BL(e,a,t){var l=Je();t={lane:l,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null},Vn(e)?Ym(a,t):(t=Li(e,a,t,l),t!==null&&(_e(t,e,l),Zm(t,a,l)))}function Km(e,a,t){var l=Je();Ru(e,a,t,l)}function Ru(e,a,t,l){var u={lane:l,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null};if(Vn(e))Ym(a,u);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=a.lastRenderedReducer,o!==null))try{var n=a.lastRenderedState,s=o(n,t);if(u.hasEagerState=!0,u.eagerState=s,We(s,n))return _n(e,a,u,0),Y===null&&zn(),!1}catch{}if(t=Li(e,a,u,l),t!==null)return _e(t,e,l),Zm(t,a,l),!0}return!1}function zi(e,a,t,l){if(l={lane:2,revertLane:Ki(),gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null},Vn(e)){if(a)throw Error(C(479))}else a=Li(e,t,l,2),a!==null&&_e(a,e,2)}function Vn(e){var a=e.alternate;return e===O||a!==null&&a===O}function Ym(e,a){Hl=xn=!0;var t=e.pending;t===null?a.next=a:(a.next=t.next,t.next=a),e.pending=a}function Zm(e,a,t){if((t&4194048)!==0){var l=a.lanes;l&=e.pendingLanes,t|=l,a.lanes=t,Oc(e,t)}}var Xu={readContext:ke,use:Fn,useCallback:ne,useContext:ne,useEffect:ne,useImperativeHandle:ne,useLayoutEffect:ne,useInsertionEffect:ne,useMemo:ne,useReducer:ne,useRef:ne,useState:ne,useDebugValue:ne,useDeferredValue:ne,useTransition:ne,useSyncExternalStore:ne,useId:ne,useHostTransitionStatus:ne,useFormState:ne,useActionState:ne,useOptimistic:ne,useMemoCache:ne,useCacheRefresh:ne};Xu.useEffectEvent=ne;var Qm={readContext:ke,use:Fn,useCallback:function(e,a){return Oe().memoizedState=[e,a===void 0?null:a],e},useContext:ke,useEffect:Ef,useImperativeHandle:function(e,a,t){t=t!=null?t.concat([e]):null,Qo(4194308,4,Um.bind(null,a,e),t)},useLayoutEffect:function(e,a){return Qo(4194308,4,e,a)},useInsertionEffect:function(e,a){Qo(4,2,e,a)},useMemo:function(e,a){var t=Oe();a=a===void 0?null:a;var l=e();if(Wt){it(!0);try{e()}finally{it(!1)}}return t.memoizedState=[l,a],l},useReducer:function(e,a,t){var l=Oe();if(t!==void 0){var u=t(a);if(Wt){it(!0);try{t(a)}finally{it(!1)}}}else u=a;return l.memoizedState=l.baseState=u,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:u},l.queue=e,e=e.dispatch=BL.bind(null,O,e),[l.memoizedState,e]},useRef:function(e){var a=Oe();return e={current:e},a.memoizedState=e},useState:function(e){e=Hr(e);var a=e.queue,t=Km.bind(null,O,a);return a.dispatch=t,[e.memoizedState,t]},useDebugValue:qi,useDeferredValue:function(e,a){var t=Oe();return Hi(t,e,a)},useTransition:function(){var e=Hr(!1);return e=Fm.bind(null,O,e.queue,!0,!1),Oe().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,a,t){var l=O,u=Oe();if(N){if(t===void 0)throw Error(C(407));t=t()}else{if(t=a(),Y===null)throw Error(C(349));(_&127)!==0||vm(l,a,t)}u.memoizedState=t;var o={value:t,getSnapshot:a};return u.queue=o,Ef(km.bind(null,l,o,e),[e]),l.flags|=2048,Gl(9,{destroy:void 0},Im.bind(null,l,o,t,a),null),t},useId:function(){var e=Oe(),a=Y.identifierPrefix;if(N){var t=ka,l=Ia;t=(l&~(1<<32-Qe(l)-1)).toString(32)+t,a="_"+a+"R_"+t,t=Ln++,0<t&&(a+="H"+t.toString(32)),a+="_"}else t=kL++,a="_"+a+"r_"+t.toString(32)+"_";return e.memoizedState=a},useHostTransitionStatus:Ui,useFormState:Df,useActionState:Df,useOptimistic:function(e){var a=Oe();a.memoizedState=a.baseState=e;var t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return a.queue=t,a=zi.bind(null,O,!0,t),t.dispatch=a,[e,a]},useMemoCache:Bi,useCacheRefresh:function(){return Oe().memoizedState=RL.bind(null,O)},useEffectEvent:function(e){var a=Oe(),t={impl:e};return a.memoizedState=t,function(){if((P&2)!==0)throw Error(C(440));return t.impl.apply(void 0,arguments)}}},_i={readContext:ke,use:Fn,useCallback:_m,useContext:ke,useEffect:Oi,useImperativeHandle:zm,useInsertionEffect:qm,useLayoutEffect:Hm,useMemo:Nm,useReducer:Zo,useRef:Em,useState:function(){return Zo(Ka)},useDebugValue:qi,useDeferredValue:function(e,a){var t=ie();return Pm(t,K.memoizedState,e,a)},useTransition:function(){var e=Zo(Ka)[0],a=ie().memoizedState;return[typeof e=="boolean"?e:uo(e),a]},useSyncExternalStore:bm,useId:Xm,useHostTransitionStatus:Ui,useFormState:Rf,useActionState:Rf,useOptimistic:function(e,a){var t=ie();return wm(t,K,e,a)},useMemoCache:Bi,useCacheRefresh:jm};_i.useEffectEvent=Om;var Jm={readContext:ke,use:Fn,useCallback:_m,useContext:ke,useEffect:Oi,useImperativeHandle:zm,useInsertionEffect:qm,useLayoutEffect:Hm,useMemo:Nm,useReducer:js,useRef:Em,useState:function(){return js(Ka)},useDebugValue:qi,useDeferredValue:function(e,a){var t=ie();return K===null?Hi(t,e,a):Pm(t,K.memoizedState,e,a)},useTransition:function(){var e=js(Ka)[0],a=ie().memoizedState;return[typeof e=="boolean"?e:uo(e),a]},useSyncExternalStore:bm,useId:Xm,useHostTransitionStatus:Ui,useFormState:Bf,useActionState:Bf,useOptimistic:function(e,a){var t=ie();return K!==null?wm(t,K,e,a):(t.baseState=e,[e,t.queue.dispatch])},useMemoCache:Bi,useCacheRefresh:jm};Jm.useEffectEvent=Om;function Ks(e,a,t,l){a=e.memoizedState,t=t(l,a),t=t==null?a:te({},a,t),e.memoizedState=t,e.lanes===0&&(e.updateQueue.baseState=t)}var _r={enqueueSetState:function(e,a,t){e=e._reactInternals;var l=Je(),u=ht(l);u.payload=a,t!=null&&(u.callback=t),a=xt(e,u,l),a!==null&&(_e(a,e,l),wu(a,e,l))},enqueueReplaceState:function(e,a,t){e=e._reactInternals;var l=Je(),u=ht(l);u.tag=1,u.payload=a,t!=null&&(u.callback=t),a=xt(e,u,l),a!==null&&(_e(a,e,l),wu(a,e,l))},enqueueForceUpdate:function(e,a){e=e._reactInternals;var t=Je(),l=ht(t);l.tag=2,a!=null&&(l.callback=a),a=xt(e,l,t),a!==null&&(_e(a,e,t),wu(a,e,t))}};function Of(e,a,t,l,u,o,n){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(l,o,n):a.prototype&&a.prototype.isPureReactComponent?!Nu(t,l)||!Nu(u,o):!0}function qf(e,a,t,l){e=a.state,typeof a.componentWillReceiveProps=="function"&&a.componentWillReceiveProps(t,l),typeof a.UNSAFE_componentWillReceiveProps=="function"&&a.UNSAFE_componentWillReceiveProps(t,l),a.state!==e&&_r.enqueueReplaceState(a,a.state,null)}function $t(e,a){var t=a;if("ref"in a){t={};for(var l in a)l!=="ref"&&(t[l]=a[l])}if(e=e.defaultProps){t===a&&(t=te({},t));for(var u in e)t[u]===void 0&&(t[u]=e[u])}return t}function Wm(e){dn(e)}function $m(e){console.error(e)}function ep(e){dn(e)}function Sn(e,a){try{var t=e.onUncaughtError;t(a.value,{componentStack:a.stack})}catch(l){setTimeout(function(){throw l})}}function Hf(e,a,t){try{var l=e.onCaughtError;l(t.value,{componentStack:t.stack,errorBoundary:a.tag===1?a.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function Nr(e,a,t){return t=ht(t),t.tag=3,t.payload={element:null},t.callback=function(){Sn(e,a)},t}function ap(e){return e=ht(e),e.tag=3,e}function tp(e,a,t,l){var u=t.type.getDerivedStateFromError;if(typeof u=="function"){var o=l.value;e.payload=function(){return u(o)},e.callback=function(){Hf(a,t,l)}}var n=t.stateNode;n!==null&&typeof n.componentDidCatch=="function"&&(e.callback=function(){Hf(a,t,l),typeof u!="function"&&(Lt===null?Lt=new Set([this]):Lt.add(this));var s=l.stack;this.componentDidCatch(l.value,{componentStack:s!==null?s:""})})}function EL(e,a,t,l,u){if(t.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){if(a=t.alternate,a!==null&&Jl(a,t,u,!0),t=$e.current,t!==null){switch(t.tag){case 31:case 13:return da===null?In():t.alternate===null&&se===0&&(se=3),t.flags&=-257,t.flags|=65536,t.lanes=u,l===pn?t.flags|=16384:(a=t.updateQueue,a===null?t.updateQueue=new Set([l]):a.add(l),ur(e,l,u)),!1;case 22:return t.flags|=65536,l===pn?t.flags|=16384:(a=t.updateQueue,a===null?(a={transitions:null,markerInstances:null,retryQueue:new Set([l])},t.updateQueue=a):(t=a.retryQueue,t===null?a.retryQueue=new Set([l]):t.add(l)),ur(e,l,u)),!1}throw Error(C(435,t.tag))}return ur(e,l,u),In(),!1}if(N)return a=$e.current,a!==null?((a.flags&65536)===0&&(a.flags|=256),a.flags|=65536,a.lanes=u,l!==Tr&&(e=Error(C(422),{cause:l}),Fu(ra(e,t)))):(l!==Tr&&(a=Error(C(423),{cause:l}),Fu(ra(a,t))),e=e.current.alternate,e.flags|=65536,u&=-u,e.lanes|=u,l=ra(l,t),u=Nr(e.stateNode,l,u),Xs(e,u),se!==4&&(se=2)),!1;var o=Error(C(520),{cause:l});if(o=ra(o,t),Ou===null?Ou=[o]:Ou.push(o),se!==4&&(se=2),a===null)return!0;l=ra(l,t),t=a;do{switch(t.tag){case 3:return t.flags|=65536,e=u&-u,t.lanes|=e,e=Nr(t.stateNode,l,e),Xs(t,e),!1;case 1:if(a=t.type,o=t.stateNode,(t.flags&128)===0&&(typeof a.getDerivedStateFromError=="function"||o!==null&&typeof o.componentDidCatch=="function"&&(Lt===null||!Lt.has(o))))return t.flags|=65536,u&=-u,t.lanes|=u,u=ap(u),tp(u,e,t,l),Xs(t,u),!1}t=t.return}while(t!==null);return!1}var Ni=Error(C(461)),me=!1;function be(e,a,t,l){a.child=e===null?hm(a,null,t,l):Jt(a,e.child,t,l)}function Uf(e,a,t,l,u){t=t.render;var o=a.ref;if("ref"in l){var n={};for(var s in l)s!=="ref"&&(n[s]=l[s])}else n=l;return Qt(a),l=wi(e,a,t,n,o,u),s=Mi(),e!==null&&!me?(Di(e,a,u),Ya(e,a,u)):(N&&s&&yi(a),a.flags|=1,be(e,a,l,u),a.child)}function zf(e,a,t,l,u){if(e===null){var o=t.type;return typeof o=="function"&&!Si(o)&&o.defaultProps===void 0&&t.compare===null?(a.tag=15,a.type=o,lp(e,a,o,l,u)):(e=Ko(t.type,null,l,a,a.mode,u),e.ref=a.ref,e.return=a,a.child=e)}if(o=e.child,!Pi(e,u)){var n=o.memoizedProps;if(t=t.compare,t=t!==null?t:Nu,t(n,l)&&e.ref===a.ref)return Ya(e,a,u)}return a.flags|=1,e=Fa(o,l),e.ref=a.ref,e.return=a,a.child=e}function lp(e,a,t,l,u){if(e!==null){var o=e.memoizedProps;if(Nu(o,l)&&e.ref===a.ref)if(me=!1,a.pendingProps=l=o,Pi(e,u))(e.flags&131072)!==0&&(me=!0);else return a.lanes=e.lanes,Ya(e,a,u)}return Pr(e,a,t,l,u)}function up(e,a,t,l){var u=l.children,o=e!==null?e.memoizedState:null;if(e===null&&a.stateNode===null&&(a.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),l.mode==="hidden"){if((a.flags&128)!==0){if(o=o!==null?o.baseLanes|t:t,e!==null){for(l=a.child=e.child,u=0;l!==null;)u=u|l.lanes|l.childLanes,l=l.sibling;l=u&~o}else l=0,a.child=null;return _f(e,a,o,t,l)}if((t&536870912)!==0)a.memoizedState={baseLanes:0,cachePool:null},e!==null&&Yo(a,o!==null?o.cachePool:null),o!==null?Tf(a,o):Or(),Sm(a);else return l=a.lanes=536870912,_f(e,a,o!==null?o.baseLanes|t:t,t,l)}else o!==null?(Yo(a,o.cachePool),Tf(a,o),st(a),a.memoizedState=null):(e!==null&&Yo(a,null),Or(),st(a));return be(e,a,u,t),a.child}function bu(e,a){return e!==null&&e.tag===22||a.stateNode!==null||(a.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),a.sibling}function _f(e,a,t,l,u){var o=vi();return o=o===null?null:{parent:ce._currentValue,pool:o},a.memoizedState={baseLanes:t,cachePool:o},e!==null&&Yo(a,null),Or(),Sm(a),e!==null&&Jl(e,a,l,!0),a.childLanes=u,null}function Jo(e,a){return a=yn({mode:a.mode,children:a.children},e.mode),a.ref=e.ref,e.child=a,a.return=e,a}function Nf(e,a,t){return Jt(a,e.child,null,t),e=Jo(a,a.pendingProps),e.flags|=2,Xe(a),a.memoizedState=null,e}function OL(e,a,t){var l=a.pendingProps,u=(a.flags&128)!==0;if(a.flags&=-129,e===null){if(N){if(l.mode==="hidden")return e=Jo(a,l),a.lanes=536870912,bu(null,e);if(qr(a),(e=ae)?(e=Qp(e,ia),e=e!==null&&e.data==="&"?e:null,e!==null&&(a.memoizedState={dehydrated:e,treeContext:vt!==null?{id:Ia,overflow:ka}:null,retryLane:536870912,hydrationErrors:null},t=im(e),t.return=a,a.child=t,Ie=a,ae=null)):e=null,e===null)throw It(a);return a.lanes=536870912,null}return Jo(a,l)}var o=e.memoizedState;if(o!==null){var n=o.dehydrated;if(qr(a),u)if(a.flags&256)a.flags&=-257,a=Nf(e,a,t);else if(a.memoizedState!==null)a.child=e.child,a.flags|=128,a=null;else throw Error(C(558));else if(me||Jl(e,a,t,!1),u=(t&e.childLanes)!==0,me||u){if(l=Y,l!==null&&(n=qc(l,t),n!==0&&n!==o.retryLane))throw o.retryLane=n,ll(e,n),_e(l,e,n),Ni;In(),a=Nf(e,a,t)}else e=o.treeContext,ae=fa(n.nextSibling),Ie=a,N=!0,gt=null,ia=!1,e!==null&&fm(a,e),a=Jo(a,l),a.flags|=4096;return a}return e=Fa(e.child,{mode:l.mode,children:l.children}),e.ref=a.ref,a.child=e,e.return=a,e}function Wo(e,a){var t=a.ref;if(t===null)e!==null&&e.ref!==null&&(a.flags|=4194816);else{if(typeof t!="function"&&typeof t!="object")throw Error(C(284));(e===null||e.ref!==t)&&(a.flags|=4194816)}}function Pr(e,a,t,l,u){return Qt(a),t=wi(e,a,t,l,void 0,u),l=Mi(),e!==null&&!me?(Di(e,a,u),Ya(e,a,u)):(N&&l&&yi(a),a.flags|=1,be(e,a,t,u),a.child)}function Pf(e,a,t,l,u,o){return Qt(a),a.updateQueue=null,t=Cm(a,l,t,u),ym(e),l=Mi(),e!==null&&!me?(Di(e,a,o),Ya(e,a,o)):(N&&l&&yi(a),a.flags|=1,be(e,a,t,o),a.child)}function Ff(e,a,t,l,u){if(Qt(a),a.stateNode===null){var o=Tl,n=t.contextType;typeof n=="object"&&n!==null&&(o=ke(n)),o=new t(l,o),a.memoizedState=o.state!==null&&o.state!==void 0?o.state:null,o.updater=_r,a.stateNode=o,o._reactInternals=a,o=a.stateNode,o.props=l,o.state=a.memoizedState,o.refs={},ki(a),n=t.contextType,o.context=typeof n=="object"&&n!==null?ke(n):Tl,o.state=a.memoizedState,n=t.getDerivedStateFromProps,typeof n=="function"&&(Ks(a,t,n,l),o.state=a.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof o.getSnapshotBeforeUpdate=="function"||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(n=o.state,typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount(),n!==o.state&&_r.enqueueReplaceState(o,o.state,null),Du(a,l,o,u),Mu(),o.state=a.memoizedState),typeof o.componentDidMount=="function"&&(a.flags|=4194308),l=!0}else if(e===null){o=a.stateNode;var s=a.memoizedProps,r=$t(t,s);o.props=r;var i=o.context,p=t.contextType;n=Tl,typeof p=="object"&&p!==null&&(n=ke(p));var g=t.getDerivedStateFromProps;p=typeof g=="function"||typeof o.getSnapshotBeforeUpdate=="function",s=a.pendingProps!==s,p||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(s||i!==n)&&qf(a,o,l,n),ut=!1;var f=a.memoizedState;o.state=f,Du(a,l,o,u),Mu(),i=a.memoizedState,s||f!==i||ut?(typeof g=="function"&&(Ks(a,t,g,l),i=a.memoizedState),(r=ut||Of(a,t,r,l,f,i,n))?(p||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(a.flags|=4194308)):(typeof o.componentDidMount=="function"&&(a.flags|=4194308),a.memoizedProps=l,a.memoizedState=i),o.props=l,o.state=i,o.context=n,l=r):(typeof o.componentDidMount=="function"&&(a.flags|=4194308),l=!1)}else{o=a.stateNode,Br(e,a),n=a.memoizedProps,p=$t(t,n),o.props=p,g=a.pendingProps,f=o.context,i=t.contextType,r=Tl,typeof i=="object"&&i!==null&&(r=ke(i)),s=t.getDerivedStateFromProps,(i=typeof s=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(n!==g||f!==r)&&qf(a,o,l,r),ut=!1,f=a.memoizedState,o.state=f,Du(a,l,o,u),Mu();var c=a.memoizedState;n!==g||f!==c||ut||e!==null&&e.dependencies!==null&&mn(e.dependencies)?(typeof s=="function"&&(Ks(a,t,s,l),c=a.memoizedState),(p=ut||Of(a,t,p,l,f,c,r)||e!==null&&e.dependencies!==null&&mn(e.dependencies))?(i||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(l,c,r),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(l,c,r)),typeof o.componentDidUpdate=="function"&&(a.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(a.flags|=1024)):(typeof o.componentDidUpdate!="function"||n===e.memoizedProps&&f===e.memoizedState||(a.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||n===e.memoizedProps&&f===e.memoizedState||(a.flags|=1024),a.memoizedProps=l,a.memoizedState=c),o.props=l,o.state=c,o.context=r,l=p):(typeof o.componentDidUpdate!="function"||n===e.memoizedProps&&f===e.memoizedState||(a.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||n===e.memoizedProps&&f===e.memoizedState||(a.flags|=1024),l=!1)}return o=l,Wo(e,a),l=(a.flags&128)!==0,o||l?(o=a.stateNode,t=l&&typeof t.getDerivedStateFromError!="function"?null:o.render(),a.flags|=1,e!==null&&l?(a.child=Jt(a,e.child,null,u),a.child=Jt(a,null,t,u)):be(e,a,t,u),a.memoizedState=o.state,e=a.child):e=Ya(e,a,u),e}function Gf(e,a,t,l){return Zt(),a.flags|=256,be(e,a,t,l),a.child}var Ys={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Zs(e){return{baseLanes:e,cachePool:mm()}}function Qs(e,a,t){return e=e!==null?e.childLanes&~t:0,a&&(e|=Ke),e}function op(e,a,t){var l=a.pendingProps,u=!1,o=(a.flags&128)!==0,n;if((n=o)||(n=e!==null&&e.memoizedState===null?!1:(re.current&2)!==0),n&&(u=!0,a.flags&=-129),n=(a.flags&32)!==0,a.flags&=-33,e===null){if(N){if(u?nt(a):st(a),(e=ae)?(e=Qp(e,ia),e=e!==null&&e.data!=="&"?e:null,e!==null&&(a.memoizedState={dehydrated:e,treeContext:vt!==null?{id:Ia,overflow:ka}:null,retryLane:536870912,hydrationErrors:null},t=im(e),t.return=a,a.child=t,Ie=a,ae=null)):e=null,e===null)throw It(a);return ai(e)?a.lanes=32:a.lanes=536870912,null}var s=l.children;return l=l.fallback,u?(st(a),u=a.mode,s=yn({mode:"hidden",children:s},u),l=Xt(l,u,t,null),s.return=a,l.return=a,s.sibling=l,a.child=s,l=a.child,l.memoizedState=Zs(t),l.childLanes=Qs(e,n,t),a.memoizedState=Ys,bu(null,l)):(nt(a),Fr(a,s))}var r=e.memoizedState;if(r!==null&&(s=r.dehydrated,s!==null)){if(o)a.flags&256?(nt(a),a.flags&=-257,a=Js(e,a,t)):a.memoizedState!==null?(st(a),a.child=e.child,a.flags|=128,a=null):(st(a),s=l.fallback,u=a.mode,l=yn({mode:"visible",children:l.children},u),s=Xt(s,u,t,null),s.flags|=2,l.return=a,s.return=a,l.sibling=s,a.child=l,Jt(a,e.child,null,t),l=a.child,l.memoizedState=Zs(t),l.childLanes=Qs(e,n,t),a.memoizedState=Ys,a=bu(null,l));else if(nt(a),ai(s)){if(n=s.nextSibling&&s.nextSibling.dataset,n)var i=n.dgst;n=i,l=Error(C(419)),l.stack="",l.digest=n,Fu({value:l,source:null,stack:null}),a=Js(e,a,t)}else if(me||Jl(e,a,t,!1),n=(t&e.childLanes)!==0,me||n){if(n=Y,n!==null&&(l=qc(n,t),l!==0&&l!==r.retryLane))throw r.retryLane=l,ll(e,l),_e(n,e,l),Ni;ei(s)||In(),a=Js(e,a,t)}else ei(s)?(a.flags|=192,a.child=e.child,a=null):(e=r.treeContext,ae=fa(s.nextSibling),Ie=a,N=!0,gt=null,ia=!1,e!==null&&fm(a,e),a=Fr(a,l.children),a.flags|=4096);return a}return u?(st(a),s=l.fallback,u=a.mode,r=e.child,i=r.sibling,l=Fa(r,{mode:"hidden",children:l.children}),l.subtreeFlags=r.subtreeFlags&65011712,i!==null?s=Fa(i,s):(s=Xt(s,u,t,null),s.flags|=2),s.return=a,l.return=a,l.sibling=s,a.child=l,bu(null,l),l=a.child,s=e.child.memoizedState,s===null?s=Zs(t):(u=s.cachePool,u!==null?(r=ce._currentValue,u=u.parent!==r?{parent:r,pool:r}:u):u=mm(),s={baseLanes:s.baseLanes|t,cachePool:u}),l.memoizedState=s,l.childLanes=Qs(e,n,t),a.memoizedState=Ys,bu(e.child,l)):(nt(a),t=e.child,e=t.sibling,t=Fa(t,{mode:"visible",children:l.children}),t.return=a,t.sibling=null,e!==null&&(n=a.deletions,n===null?(a.deletions=[e],a.flags|=16):n.push(e)),a.child=t,a.memoizedState=null,t)}function Fr(e,a){return a=yn({mode:"visible",children:a},e.mode),a.return=e,e.child=a}function yn(e,a){return e=je(22,e,null,a),e.lanes=0,e}function Js(e,a,t){return Jt(a,e.child,null,t),e=Fr(a,a.pendingProps.children),e.flags|=2,a.memoizedState=null,e}function Vf(e,a,t){e.lanes|=a;var l=e.alternate;l!==null&&(l.lanes|=a),Mr(e.return,a,t)}function Ws(e,a,t,l,u,o){var n=e.memoizedState;n===null?e.memoizedState={isBackwards:a,rendering:null,renderingStartTime:0,last:l,tail:t,tailMode:u,treeForkCount:o}:(n.isBackwards=a,n.rendering=null,n.renderingStartTime=0,n.last=l,n.tail=t,n.tailMode=u,n.treeForkCount=o)}function np(e,a,t){var l=a.pendingProps,u=l.revealOrder,o=l.tail;l=l.children;var n=re.current,s=(n&2)!==0;if(s?(n=n&1|2,a.flags|=128):n&=1,Z(re,n),be(e,a,l,t),l=N?Pu:0,!s&&e!==null&&(e.flags&128)!==0)e:for(e=a.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Vf(e,t,a);else if(e.tag===19)Vf(e,t,a);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===a)break e;for(;e.sibling===null;){if(e.return===null||e.return===a)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(u){case"forwards":for(t=a.child,u=null;t!==null;)e=t.alternate,e!==null&&hn(e)===null&&(u=t),t=t.sibling;t=u,t===null?(u=a.child,a.child=null):(u=t.sibling,t.sibling=null),Ws(a,!1,u,t,o,l);break;case"backwards":case"unstable_legacy-backwards":for(t=null,u=a.child,a.child=null;u!==null;){if(e=u.alternate,e!==null&&hn(e)===null){a.child=u;break}e=u.sibling,u.sibling=t,t=u,u=e}Ws(a,!0,t,null,o,l);break;case"together":Ws(a,!1,null,null,void 0,l);break;default:a.memoizedState=null}return a.child}function Ya(e,a,t){if(e!==null&&(a.dependencies=e.dependencies),At|=a.lanes,(t&a.childLanes)===0)if(e!==null){if(Jl(e,a,t,!1),(t&a.childLanes)===0)return null}else return null;if(e!==null&&a.child!==e.child)throw Error(C(153));if(a.child!==null){for(e=a.child,t=Fa(e,e.pendingProps),a.child=t,t.return=a;e.sibling!==null;)e=e.sibling,t=t.sibling=Fa(e,e.pendingProps),t.return=a;t.sibling=null}return a.child}function Pi(e,a){return(e.lanes&a)!==0?!0:(e=e.dependencies,!!(e!==null&&mn(e)))}function qL(e,a,t){switch(a.tag){case 3:on(a,a.stateNode.containerInfo),ot(a,ce,e.memoizedState.cache),Zt();break;case 27:case 5:hr(a);break;case 4:on(a,a.stateNode.containerInfo);break;case 10:ot(a,a.type,a.memoizedProps.value);break;case 31:if(a.memoizedState!==null)return a.flags|=128,qr(a),null;break;case 13:var l=a.memoizedState;if(l!==null)return l.dehydrated!==null?(nt(a),a.flags|=128,null):(t&a.child.childLanes)!==0?op(e,a,t):(nt(a),e=Ya(e,a,t),e!==null?e.sibling:null);nt(a);break;case 19:var u=(e.flags&128)!==0;if(l=(t&a.childLanes)!==0,l||(Jl(e,a,t,!1),l=(t&a.childLanes)!==0),u){if(l)return np(e,a,t);a.flags|=128}if(u=a.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),Z(re,re.current),l)break;return null;case 22:return a.lanes=0,up(e,a,t,a.pendingProps);case 24:ot(a,ce,e.memoizedState.cache)}return Ya(e,a,t)}function sp(e,a,t){if(e!==null)if(e.memoizedProps!==a.pendingProps)me=!0;else{if(!Pi(e,t)&&(a.flags&128)===0)return me=!1,qL(e,a,t);me=(e.flags&131072)!==0}else me=!1,N&&(a.flags&1048576)!==0&&dm(a,Pu,a.index);switch(a.lanes=0,a.tag){case 16:e:{var l=a.pendingProps;if(e=Ft(a.elementType),a.type=e,typeof e=="function")Si(e)?(l=$t(e,l),a.tag=1,a=Ff(null,a,e,l,t)):(a.tag=0,a=Pr(null,a,e,l,t));else{if(e!=null){var u=e.$$typeof;if(u===oi){a.tag=11,a=Uf(null,a,e,l,t);break e}else if(u===ni){a.tag=14,a=zf(null,a,e,l,t);break e}}throw a=pr(e)||e,Error(C(306,a,""))}}return a;case 0:return Pr(e,a,a.type,a.pendingProps,t);case 1:return l=a.type,u=$t(l,a.pendingProps),Ff(e,a,l,u,t);case 3:e:{if(on(a,a.stateNode.containerInfo),e===null)throw Error(C(387));l=a.pendingProps;var o=a.memoizedState;u=o.element,Br(e,a),Du(a,l,null,t);var n=a.memoizedState;if(l=n.cache,ot(a,ce,l),l!==o.cache&&Dr(a,[ce],t,!0),Mu(),l=n.element,o.isDehydrated)if(o={element:l,isDehydrated:!1,cache:n.cache},a.updateQueue.baseState=o,a.memoizedState=o,a.flags&256){a=Gf(e,a,l,t);break e}else if(l!==u){u=ra(Error(C(424)),a),Fu(u),a=Gf(e,a,l,t);break e}else for(e=a.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,ae=fa(e.firstChild),Ie=a,N=!0,gt=null,ia=!0,t=hm(a,null,l,t),a.child=t;t;)t.flags=t.flags&-3|4096,t=t.sibling;else{if(Zt(),l===u){a=Ya(e,a,t);break e}be(e,a,l,t)}a=a.child}return a;case 26:return Wo(e,a),e===null?(t=cc(a.type,null,a.pendingProps,null))?a.memoizedState=t:N||(t=a.type,e=a.pendingProps,l=wn(pt.current).createElement(t),l[ve]=a,l[Ne]=e,Ae(l,t,e),ye(l),a.stateNode=l):a.memoizedState=cc(a.type,e.memoizedProps,a.pendingProps,e.memoizedState),null;case 27:return hr(a),e===null&&N&&(l=a.stateNode=Jp(a.type,a.pendingProps,pt.current),Ie=a,ia=!0,u=ae,wt(a.type)?(ti=u,ae=fa(l.firstChild)):ae=u),be(e,a,a.pendingProps.children,t),Wo(e,a),e===null&&(a.flags|=4194304),a.child;case 5:return e===null&&N&&((u=l=ae)&&(l=iS(l,a.type,a.pendingProps,ia),l!==null?(a.stateNode=l,Ie=a,ae=fa(l.firstChild),ia=!1,u=!0):u=!1),u||It(a)),hr(a),u=a.type,o=a.pendingProps,n=e!==null?e.memoizedProps:null,l=o.children,Wr(u,o)?l=null:n!==null&&Wr(u,n)&&(a.flags|=32),a.memoizedState!==null&&(u=wi(e,a,AL,null,null,t),Yu._currentValue=u),Wo(e,a),be(e,a,l,t),a.child;case 6:return e===null&&N&&((e=t=ae)&&(t=dS(t,a.pendingProps,ia),t!==null?(a.stateNode=t,Ie=a,ae=null,e=!0):e=!1),e||It(a)),null;case 13:return op(e,a,t);case 4:return on(a,a.stateNode.containerInfo),l=a.pendingProps,e===null?a.child=Jt(a,null,l,t):be(e,a,l,t),a.child;case 11:return Uf(e,a,a.type,a.pendingProps,t);case 7:return be(e,a,a.pendingProps,t),a.child;case 8:return be(e,a,a.pendingProps.children,t),a.child;case 12:return be(e,a,a.pendingProps.children,t),a.child;case 10:return l=a.pendingProps,ot(a,a.type,l.value),be(e,a,l.children,t),a.child;case 9:return u=a.type._context,l=a.pendingProps.children,Qt(a),u=ke(u),l=l(u),a.flags|=1,be(e,a,l,t),a.child;case 14:return zf(e,a,a.type,a.pendingProps,t);case 15:return lp(e,a,a.type,a.pendingProps,t);case 19:return np(e,a,t);case 31:return OL(e,a,t);case 22:return up(e,a,t,a.pendingProps);case 24:return Qt(a),l=ke(ce),e===null?(u=vi(),u===null&&(u=Y,o=bi(),u.pooledCache=o,o.refCount++,o!==null&&(u.pooledCacheLanes|=t),u=o),a.memoizedState={parent:l,cache:u},ki(a),ot(a,ce,u)):((e.lanes&t)!==0&&(Br(e,a),Du(a,null,null,t),Mu()),u=e.memoizedState,o=a.memoizedState,u.parent!==l?(u={parent:l,cache:l},a.memoizedState=u,a.lanes===0&&(a.memoizedState=a.updateQueue.baseState=u),ot(a,ce,l)):(l=o.cache,ot(a,ce,l),l!==u.cache&&Dr(a,[ce],t,!0))),be(e,a,a.pendingProps.children,t),a.child;case 29:throw a.pendingProps}throw Error(C(156,a.tag))}function Ea(e){e.flags|=4}function $s(e,a,t,l,u){if((a=(e.mode&32)!==0)&&(a=!1),a){if(e.flags|=16777216,(u&335544128)===u)if(e.stateNode.complete)e.flags|=8192;else if(Rp())e.flags|=8192;else throw Kt=pn,Ii}else e.flags&=-16777217}function Xf(e,a){if(a.type!=="stylesheet"||(a.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!eg(a))if(Rp())e.flags|=8192;else throw Kt=pn,Ii}function Ho(e,a){a!==null&&(e.flags|=4),e.flags&16384&&(a=e.tag!==22?Bc():536870912,e.lanes|=a,Vl|=a)}function gu(e,a){if(!N)switch(e.tailMode){case"hidden":a=e.tail;for(var t=null;a!==null;)a.alternate!==null&&(t=a),a=a.sibling;t===null?e.tail=null:t.sibling=null;break;case"collapsed":t=e.tail;for(var l=null;t!==null;)t.alternate!==null&&(l=t),t=t.sibling;l===null?a||e.tail===null?e.tail=null:e.tail.sibling=null:l.sibling=null}}function ee(e){var a=e.alternate!==null&&e.alternate.child===e.child,t=0,l=0;if(a)for(var u=e.child;u!==null;)t|=u.lanes|u.childLanes,l|=u.subtreeFlags&65011712,l|=u.flags&65011712,u.return=e,u=u.sibling;else for(u=e.child;u!==null;)t|=u.lanes|u.childLanes,l|=u.subtreeFlags,l|=u.flags,u.return=e,u=u.sibling;return e.subtreeFlags|=l,e.childLanes=t,a}function HL(e,a,t){var l=a.pendingProps;switch(Ci(a),a.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return ee(a),null;case 1:return ee(a),null;case 3:return t=a.stateNode,l=null,e!==null&&(l=e.memoizedState.cache),a.memoizedState.cache!==l&&(a.flags|=2048),Ga(ce),zl(),t.pendingContext&&(t.context=t.pendingContext,t.pendingContext=null),(e===null||e.child===null)&&(gl(a)?Ea(a):e===null||e.memoizedState.isDehydrated&&(a.flags&256)===0||(a.flags|=1024,Vs())),ee(a),null;case 26:var u=a.type,o=a.memoizedState;return e===null?(Ea(a),o!==null?(ee(a),Xf(a,o)):(ee(a),$s(a,u,null,l,t))):o?o!==e.memoizedState?(Ea(a),ee(a),Xf(a,o)):(ee(a),a.flags&=-16777217):(e=e.memoizedProps,e!==l&&Ea(a),ee(a),$s(a,u,e,l,t)),null;case 27:if(nn(a),t=pt.current,u=a.type,e!==null&&a.stateNode!=null)e.memoizedProps!==l&&Ea(a);else{if(!l){if(a.stateNode===null)throw Error(C(166));return ee(a),null}e=Ta.current,gl(a)?yf(a,e):(e=Jp(u,l,t),a.stateNode=e,Ea(a))}return ee(a),null;case 5:if(nn(a),u=a.type,e!==null&&a.stateNode!=null)e.memoizedProps!==l&&Ea(a);else{if(!l){if(a.stateNode===null)throw Error(C(166));return ee(a),null}if(o=Ta.current,gl(a))yf(a,o);else{var n=wn(pt.current);switch(o){case 1:o=n.createElementNS("http://www.w3.org/2000/svg",u);break;case 2:o=n.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;default:switch(u){case"svg":o=n.createElementNS("http://www.w3.org/2000/svg",u);break;case"math":o=n.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;case"script":o=n.createElement("div"),o.innerHTML="<script><\/script>",o=o.removeChild(o.firstChild);break;case"select":o=typeof l.is=="string"?n.createElement("select",{is:l.is}):n.createElement("select"),l.multiple?o.multiple=!0:l.size&&(o.size=l.size);break;default:o=typeof l.is=="string"?n.createElement(u,{is:l.is}):n.createElement(u)}}o[ve]=a,o[Ne]=l;e:for(n=a.child;n!==null;){if(n.tag===5||n.tag===6)o.appendChild(n.stateNode);else if(n.tag!==4&&n.tag!==27&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===a)break e;for(;n.sibling===null;){if(n.return===null||n.return===a)break e;n=n.return}n.sibling.return=n.return,n=n.sibling}a.stateNode=o;e:switch(Ae(o,u,l),u){case"button":case"input":case"select":case"textarea":l=!!l.autoFocus;break e;case"img":l=!0;break e;default:l=!1}l&&Ea(a)}}return ee(a),$s(a,a.type,e===null?null:e.memoizedProps,a.pendingProps,t),null;case 6:if(e&&a.stateNode!=null)e.memoizedProps!==l&&Ea(a);else{if(typeof l!="string"&&a.stateNode===null)throw Error(C(166));if(e=pt.current,gl(a)){if(e=a.stateNode,t=a.memoizedProps,l=null,u=Ie,u!==null)switch(u.tag){case 27:case 5:l=u.memoizedProps}e[ve]=a,e=!!(e.nodeValue===t||l!==null&&l.suppressHydrationWarning===!0||Kp(e.nodeValue,t)),e||It(a,!0)}else e=wn(e).createTextNode(l),e[ve]=a,a.stateNode=e}return ee(a),null;case 31:if(t=a.memoizedState,e===null||e.memoizedState!==null){if(l=gl(a),t!==null){if(e===null){if(!l)throw Error(C(318));if(e=a.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(C(557));e[ve]=a}else Zt(),(a.flags&128)===0&&(a.memoizedState=null),a.flags|=4;ee(a),e=!1}else t=Vs(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=t),e=!0;if(!e)return a.flags&256?(Xe(a),a):(Xe(a),null);if((a.flags&128)!==0)throw Error(C(558))}return ee(a),null;case 13:if(l=a.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(u=gl(a),l!==null&&l.dehydrated!==null){if(e===null){if(!u)throw Error(C(318));if(u=a.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(C(317));u[ve]=a}else Zt(),(a.flags&128)===0&&(a.memoizedState=null),a.flags|=4;ee(a),u=!1}else u=Vs(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=u),u=!0;if(!u)return a.flags&256?(Xe(a),a):(Xe(a),null)}return Xe(a),(a.flags&128)!==0?(a.lanes=t,a):(t=l!==null,e=e!==null&&e.memoizedState!==null,t&&(l=a.child,u=null,l.alternate!==null&&l.alternate.memoizedState!==null&&l.alternate.memoizedState.cachePool!==null&&(u=l.alternate.memoizedState.cachePool.pool),o=null,l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(o=l.memoizedState.cachePool.pool),o!==u&&(l.flags|=2048)),t!==e&&t&&(a.child.flags|=8192),Ho(a,a.updateQueue),ee(a),null);case 4:return zl(),e===null&&Yi(a.stateNode.containerInfo),ee(a),null;case 10:return Ga(a.type),ee(a),null;case 19:if(Ce(re),l=a.memoizedState,l===null)return ee(a),null;if(u=(a.flags&128)!==0,o=l.rendering,o===null)if(u)gu(l,!1);else{if(se!==0||e!==null&&(e.flags&128)!==0)for(e=a.child;e!==null;){if(o=hn(e),o!==null){for(a.flags|=128,gu(l,!1),e=o.updateQueue,a.updateQueue=e,Ho(a,e),a.subtreeFlags=0,e=t,t=a.child;t!==null;)rm(t,e),t=t.sibling;return Z(re,re.current&1|2),N&&Ua(a,l.treeForkCount),a.child}e=e.sibling}l.tail!==null&&Ye()>bn&&(a.flags|=128,u=!0,gu(l,!1),a.lanes=4194304)}else{if(!u)if(e=hn(o),e!==null){if(a.flags|=128,u=!0,e=e.updateQueue,a.updateQueue=e,Ho(a,e),gu(l,!0),l.tail===null&&l.tailMode==="hidden"&&!o.alternate&&!N)return ee(a),null}else 2*Ye()-l.renderingStartTime>bn&&t!==536870912&&(a.flags|=128,u=!0,gu(l,!1),a.lanes=4194304);l.isBackwards?(o.sibling=a.child,a.child=o):(e=l.last,e!==null?e.sibling=o:a.child=o,l.last=o)}return l.tail!==null?(e=l.tail,l.rendering=e,l.tail=e.sibling,l.renderingStartTime=Ye(),e.sibling=null,t=re.current,Z(re,u?t&1|2:t&1),N&&Ua(a,l.treeForkCount),e):(ee(a),null);case 22:case 23:return Xe(a),Ai(),l=a.memoizedState!==null,e!==null?e.memoizedState!==null!==l&&(a.flags|=8192):l&&(a.flags|=8192),l?(t&536870912)!==0&&(a.flags&128)===0&&(ee(a),a.subtreeFlags&6&&(a.flags|=8192)):ee(a),t=a.updateQueue,t!==null&&Ho(a,t.retryQueue),t=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(t=e.memoizedState.cachePool.pool),l=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(l=a.memoizedState.cachePool.pool),l!==t&&(a.flags|=2048),e!==null&&Ce(jt),null;case 24:return t=null,e!==null&&(t=e.memoizedState.cache),a.memoizedState.cache!==t&&(a.flags|=2048),Ga(ce),ee(a),null;case 25:return null;case 30:return null}throw Error(C(156,a.tag))}function UL(e,a){switch(Ci(a),a.tag){case 1:return e=a.flags,e&65536?(a.flags=e&-65537|128,a):null;case 3:return Ga(ce),zl(),e=a.flags,(e&65536)!==0&&(e&128)===0?(a.flags=e&-65537|128,a):null;case 26:case 27:case 5:return nn(a),null;case 31:if(a.memoizedState!==null){if(Xe(a),a.alternate===null)throw Error(C(340));Zt()}return e=a.flags,e&65536?(a.flags=e&-65537|128,a):null;case 13:if(Xe(a),e=a.memoizedState,e!==null&&e.dehydrated!==null){if(a.alternate===null)throw Error(C(340));Zt()}return e=a.flags,e&65536?(a.flags=e&-65537|128,a):null;case 19:return Ce(re),null;case 4:return zl(),null;case 10:return Ga(a.type),null;case 22:case 23:return Xe(a),Ai(),e!==null&&Ce(jt),e=a.flags,e&65536?(a.flags=e&-65537|128,a):null;case 24:return Ga(ce),null;case 25:return null;default:return null}}function rp(e,a){switch(Ci(a),a.tag){case 3:Ga(ce),zl();break;case 26:case 27:case 5:nn(a);break;case 4:zl();break;case 31:a.memoizedState!==null&&Xe(a);break;case 13:Xe(a);break;case 19:Ce(re);break;case 10:Ga(a.type);break;case 22:case 23:Xe(a),Ai(),e!==null&&Ce(jt);break;case 24:Ga(ce)}}function oo(e,a){try{var t=a.updateQueue,l=t!==null?t.lastEffect:null;if(l!==null){var u=l.next;t=u;do{if((t.tag&e)===e){l=void 0;var o=t.create,n=t.inst;l=o(),n.destroy=l}t=t.next}while(t!==u)}}catch(s){X(a,a.return,s)}}function kt(e,a,t){try{var l=a.updateQueue,u=l!==null?l.lastEffect:null;if(u!==null){var o=u.next;l=o;do{if((l.tag&e)===e){var n=l.inst,s=n.destroy;if(s!==void 0){n.destroy=void 0,u=a;var r=t,i=s;try{i()}catch(p){X(u,r,p)}}}l=l.next}while(l!==o)}}catch(p){X(a,a.return,p)}}function ip(e){var a=e.updateQueue;if(a!==null){var t=e.stateNode;try{Lm(a,t)}catch(l){X(e,e.return,l)}}}function dp(e,a,t){t.props=$t(e.type,e.memoizedProps),t.state=e.memoizedState;try{t.componentWillUnmount()}catch(l){X(e,a,l)}}function Bu(e,a){try{var t=e.ref;if(t!==null){switch(e.tag){case 26:case 27:case 5:var l=e.stateNode;break;case 30:l=e.stateNode;break;default:l=e.stateNode}typeof t=="function"?e.refCleanup=t(l):t.current=l}}catch(u){X(e,a,u)}}function Aa(e,a){var t=e.ref,l=e.refCleanup;if(t!==null)if(typeof l=="function")try{l()}catch(u){X(e,a,u)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof t=="function")try{t(null)}catch(u){X(e,a,u)}else t.current=null}function fp(e){var a=e.type,t=e.memoizedProps,l=e.stateNode;try{e:switch(a){case"button":case"input":case"select":case"textarea":t.autoFocus&&l.focus();break e;case"img":t.src?l.src=t.src:t.srcSet&&(l.srcset=t.srcSet)}}catch(u){X(e,e.return,u)}}function er(e,a,t){try{var l=e.stateNode;lS(l,e.type,t,a),l[Ne]=a}catch(u){X(e,e.return,u)}}function cp(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&wt(e.type)||e.tag===4}function ar(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||cp(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&wt(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Gr(e,a,t){var l=e.tag;if(l===5||l===6)e=e.stateNode,a?(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t).insertBefore(e,a):(a=t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,a.appendChild(e),t=t._reactRootContainer,t!=null||a.onclick!==null||(a.onclick=Na));else if(l!==4&&(l===27&&wt(e.type)&&(t=e.stateNode,a=null),e=e.child,e!==null))for(Gr(e,a,t),e=e.sibling;e!==null;)Gr(e,a,t),e=e.sibling}function Cn(e,a,t){var l=e.tag;if(l===5||l===6)e=e.stateNode,a?t.insertBefore(e,a):t.appendChild(e);else if(l!==4&&(l===27&&wt(e.type)&&(t=e.stateNode),e=e.child,e!==null))for(Cn(e,a,t),e=e.sibling;e!==null;)Cn(e,a,t),e=e.sibling}function mp(e){var a=e.stateNode,t=e.memoizedProps;try{for(var l=e.type,u=a.attributes;u.length;)a.removeAttributeNode(u[0]);Ae(a,l,t),a[ve]=e,a[Ne]=t}catch(o){X(e,e.return,o)}}var za=!1,fe=!1,tr=!1,jf=typeof WeakSet=="function"?WeakSet:Set,Se=null;function zL(e,a){if(e=e.containerInfo,Qr=Bn,e=em(e),hi(e)){if("selectionStart"in e)var t={start:e.selectionStart,end:e.selectionEnd};else e:{t=(t=e.ownerDocument)&&t.defaultView||window;var l=t.getSelection&&t.getSelection();if(l&&l.rangeCount!==0){t=l.anchorNode;var u=l.anchorOffset,o=l.focusNode;l=l.focusOffset;try{t.nodeType,o.nodeType}catch{t=null;break e}var n=0,s=-1,r=-1,i=0,p=0,g=e,f=null;a:for(;;){for(var c;g!==t||u!==0&&g.nodeType!==3||(s=n+u),g!==o||l!==0&&g.nodeType!==3||(r=n+l),g.nodeType===3&&(n+=g.nodeValue.length),(c=g.firstChild)!==null;)f=g,g=c;for(;;){if(g===e)break a;if(f===t&&++i===u&&(s=n),f===o&&++p===l&&(r=n),(c=g.nextSibling)!==null)break;g=f,f=g.parentNode}g=c}t=s===-1||r===-1?null:{start:s,end:r}}else t=null}t=t||{start:0,end:0}}else t=null;for(Jr={focusedElem:e,selectionRange:t},Bn=!1,Se=a;Se!==null;)if(a=Se,e=a.child,(a.subtreeFlags&1028)!==0&&e!==null)e.return=a,Se=e;else for(;Se!==null;){switch(a=Se,o=a.alternate,e=a.flags,a.tag){case 0:if((e&4)!==0&&(e=a.updateQueue,e=e!==null?e.events:null,e!==null))for(t=0;t<e.length;t++)u=e[t],u.ref.impl=u.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&o!==null){e=void 0,t=a,u=o.memoizedProps,o=o.memoizedState,l=t.stateNode;try{var S=$t(t.type,u);e=l.getSnapshotBeforeUpdate(S,o),l.__reactInternalSnapshotBeforeUpdate=e}catch(b){X(t,t.return,b)}}break;case 3:if((e&1024)!==0){if(e=a.stateNode.containerInfo,t=e.nodeType,t===9)$r(e);else if(t===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":$r(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(C(163))}if(e=a.sibling,e!==null){e.return=a.return,Se=e;break}Se=a.return}}function pp(e,a,t){var l=t.flags;switch(t.tag){case 0:case 11:case 15:qa(e,t),l&4&&oo(5,t);break;case 1:if(qa(e,t),l&4)if(e=t.stateNode,a===null)try{e.componentDidMount()}catch(n){X(t,t.return,n)}else{var u=$t(t.type,a.memoizedProps);a=a.memoizedState;try{e.componentDidUpdate(u,a,e.__reactInternalSnapshotBeforeUpdate)}catch(n){X(t,t.return,n)}}l&64&&ip(t),l&512&&Bu(t,t.return);break;case 3:if(qa(e,t),l&64&&(e=t.updateQueue,e!==null)){if(a=null,t.child!==null)switch(t.child.tag){case 27:case 5:a=t.child.stateNode;break;case 1:a=t.child.stateNode}try{Lm(e,a)}catch(n){X(t,t.return,n)}}break;case 27:a===null&&l&4&&mp(t);case 26:case 5:qa(e,t),a===null&&l&4&&fp(t),l&512&&Bu(t,t.return);break;case 12:qa(e,t);break;case 31:qa(e,t),l&4&&xp(e,t);break;case 13:qa(e,t),l&4&&Lp(e,t),l&64&&(e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(t=KL.bind(null,t),fS(e,t))));break;case 22:if(l=t.memoizedState!==null||za,!l){a=a!==null&&a.memoizedState!==null||fe,u=za;var o=fe;za=l,(fe=a)&&!o?Ha(e,t,(t.subtreeFlags&8772)!==0):qa(e,t),za=u,fe=o}break;case 30:break;default:qa(e,t)}}function gp(e){var a=e.alternate;a!==null&&(e.alternate=null,gp(a)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(a=e.stateNode,a!==null&&di(a)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var ue=null,Ue=!1;function Oa(e,a,t){for(t=t.child;t!==null;)hp(e,a,t),t=t.sibling}function hp(e,a,t){if(Ze&&typeof Ze.onCommitFiberUnmount=="function")try{Ze.onCommitFiberUnmount(Wu,t)}catch{}switch(t.tag){case 26:fe||Aa(t,a),Oa(e,a,t),t.memoizedState?t.memoizedState.count--:t.stateNode&&(t=t.stateNode,t.parentNode.removeChild(t));break;case 27:fe||Aa(t,a);var l=ue,u=Ue;wt(t.type)&&(ue=t.stateNode,Ue=!1),Oa(e,a,t),Hu(t.stateNode),ue=l,Ue=u;break;case 5:fe||Aa(t,a);case 6:if(l=ue,u=Ue,ue=null,Oa(e,a,t),ue=l,Ue=u,ue!==null)if(Ue)try{(ue.nodeType===9?ue.body:ue.nodeName==="HTML"?ue.ownerDocument.body:ue).removeChild(t.stateNode)}catch(o){X(t,a,o)}else try{ue.removeChild(t.stateNode)}catch(o){X(t,a,o)}break;case 18:ue!==null&&(Ue?(e=ue,sc(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,t.stateNode),Yl(e)):sc(ue,t.stateNode));break;case 4:l=ue,u=Ue,ue=t.stateNode.containerInfo,Ue=!0,Oa(e,a,t),ue=l,Ue=u;break;case 0:case 11:case 14:case 15:kt(2,t,a),fe||kt(4,t,a),Oa(e,a,t);break;case 1:fe||(Aa(t,a),l=t.stateNode,typeof l.componentWillUnmount=="function"&&dp(t,a,l)),Oa(e,a,t);break;case 21:Oa(e,a,t);break;case 22:fe=(l=fe)||t.memoizedState!==null,Oa(e,a,t),fe=l;break;default:Oa(e,a,t)}}function xp(e,a){if(a.memoizedState===null&&(e=a.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Yl(e)}catch(t){X(a,a.return,t)}}}function Lp(e,a){if(a.memoizedState===null&&(e=a.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Yl(e)}catch(t){X(a,a.return,t)}}function _L(e){switch(e.tag){case 31:case 13:case 19:var a=e.stateNode;return a===null&&(a=e.stateNode=new jf),a;case 22:return e=e.stateNode,a=e._retryCache,a===null&&(a=e._retryCache=new jf),a;default:throw Error(C(435,e.tag))}}function Uo(e,a){var t=_L(e);a.forEach(function(l){if(!t.has(l)){t.add(l);var u=YL.bind(null,e,l);l.then(u,u)}})}function qe(e,a){var t=a.deletions;if(t!==null)for(var l=0;l<t.length;l++){var u=t[l],o=e,n=a,s=n;e:for(;s!==null;){switch(s.tag){case 27:if(wt(s.type)){ue=s.stateNode,Ue=!1;break e}break;case 5:ue=s.stateNode,Ue=!1;break e;case 3:case 4:ue=s.stateNode.containerInfo,Ue=!0;break e}s=s.return}if(ue===null)throw Error(C(160));hp(o,n,u),ue=null,Ue=!1,o=u.alternate,o!==null&&(o.return=null),u.return=null}if(a.subtreeFlags&13886)for(a=a.child;a!==null;)Sp(a,e),a=a.sibling}var La=null;function Sp(e,a){var t=e.alternate,l=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:qe(a,e),He(e),l&4&&(kt(3,e,e.return),oo(3,e),kt(5,e,e.return));break;case 1:qe(a,e),He(e),l&512&&(fe||t===null||Aa(t,t.return)),l&64&&za&&(e=e.updateQueue,e!==null&&(l=e.callbacks,l!==null&&(t=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=t===null?l:t.concat(l))));break;case 26:var u=La;if(qe(a,e),He(e),l&512&&(fe||t===null||Aa(t,t.return)),l&4){var o=t!==null?t.memoizedState:null;if(l=e.memoizedState,t===null)if(l===null)if(e.stateNode===null){e:{l=e.type,t=e.memoizedProps,u=u.ownerDocument||u;a:switch(l){case"title":o=u.getElementsByTagName("title")[0],(!o||o[ao]||o[ve]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=u.createElement(l),u.head.insertBefore(o,u.querySelector("head > title"))),Ae(o,l,t),o[ve]=e,ye(o),l=o;break e;case"link":var n=pc("link","href",u).get(l+(t.href||""));if(n){for(var s=0;s<n.length;s++)if(o=n[s],o.getAttribute("href")===(t.href==null||t.href===""?null:t.href)&&o.getAttribute("rel")===(t.rel==null?null:t.rel)&&o.getAttribute("title")===(t.title==null?null:t.title)&&o.getAttribute("crossorigin")===(t.crossOrigin==null?null:t.crossOrigin)){n.splice(s,1);break a}}o=u.createElement(l),Ae(o,l,t),u.head.appendChild(o);break;case"meta":if(n=pc("meta","content",u).get(l+(t.content||""))){for(s=0;s<n.length;s++)if(o=n[s],o.getAttribute("content")===(t.content==null?null:""+t.content)&&o.getAttribute("name")===(t.name==null?null:t.name)&&o.getAttribute("property")===(t.property==null?null:t.property)&&o.getAttribute("http-equiv")===(t.httpEquiv==null?null:t.httpEquiv)&&o.getAttribute("charset")===(t.charSet==null?null:t.charSet)){n.splice(s,1);break a}}o=u.createElement(l),Ae(o,l,t),u.head.appendChild(o);break;default:throw Error(C(468,l))}o[ve]=e,ye(o),l=o}e.stateNode=l}else gc(u,e.type,e.stateNode);else e.stateNode=mc(u,l,e.memoizedProps);else o!==l?(o===null?t.stateNode!==null&&(t=t.stateNode,t.parentNode.removeChild(t)):o.count--,l===null?gc(u,e.type,e.stateNode):mc(u,l,e.memoizedProps)):l===null&&e.stateNode!==null&&er(e,e.memoizedProps,t.memoizedProps)}break;case 27:qe(a,e),He(e),l&512&&(fe||t===null||Aa(t,t.return)),t!==null&&l&4&&er(e,e.memoizedProps,t.memoizedProps);break;case 5:if(qe(a,e),He(e),l&512&&(fe||t===null||Aa(t,t.return)),e.flags&32){u=e.stateNode;try{Nl(u,"")}catch(S){X(e,e.return,S)}}l&4&&e.stateNode!=null&&(u=e.memoizedProps,er(e,u,t!==null?t.memoizedProps:u)),l&1024&&(tr=!0);break;case 6:if(qe(a,e),He(e),l&4){if(e.stateNode===null)throw Error(C(162));l=e.memoizedProps,t=e.stateNode;try{t.nodeValue=l}catch(S){X(e,e.return,S)}}break;case 3:if(an=null,u=La,La=Mn(a.containerInfo),qe(a,e),La=u,He(e),l&4&&t!==null&&t.memoizedState.isDehydrated)try{Yl(a.containerInfo)}catch(S){X(e,e.return,S)}tr&&(tr=!1,yp(e));break;case 4:l=La,La=Mn(e.stateNode.containerInfo),qe(a,e),He(e),La=l;break;case 12:qe(a,e),He(e);break;case 31:qe(a,e),He(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,Uo(e,l)));break;case 13:qe(a,e),He(e),e.child.flags&8192&&e.memoizedState!==null!=(t!==null&&t.memoizedState!==null)&&(Xn=Ye()),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,Uo(e,l)));break;case 22:u=e.memoizedState!==null;var r=t!==null&&t.memoizedState!==null,i=za,p=fe;if(za=i||u,fe=p||r,qe(a,e),fe=p,za=i,He(e),l&8192)e:for(a=e.stateNode,a._visibility=u?a._visibility&-2:a._visibility|1,u&&(t===null||r||za||fe||Gt(e)),t=null,a=e;;){if(a.tag===5||a.tag===26){if(t===null){r=t=a;try{if(o=r.stateNode,u)n=o.style,typeof n.setProperty=="function"?n.setProperty("display","none","important"):n.display="none";else{s=r.stateNode;var g=r.memoizedProps.style,f=g!=null&&g.hasOwnProperty("display")?g.display:null;s.style.display=f==null||typeof f=="boolean"?"":(""+f).trim()}}catch(S){X(r,r.return,S)}}}else if(a.tag===6){if(t===null){r=a;try{r.stateNode.nodeValue=u?"":r.memoizedProps}catch(S){X(r,r.return,S)}}}else if(a.tag===18){if(t===null){r=a;try{var c=r.stateNode;u?rc(c,!0):rc(r.stateNode,!1)}catch(S){X(r,r.return,S)}}}else if((a.tag!==22&&a.tag!==23||a.memoizedState===null||a===e)&&a.child!==null){a.child.return=a,a=a.child;continue}if(a===e)break e;for(;a.sibling===null;){if(a.return===null||a.return===e)break e;t===a&&(t=null),a=a.return}t===a&&(t=null),a.sibling.return=a.return,a=a.sibling}l&4&&(l=e.updateQueue,l!==null&&(t=l.retryQueue,t!==null&&(l.retryQueue=null,Uo(e,t))));break;case 19:qe(a,e),He(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,Uo(e,l)));break;case 30:break;case 21:break;default:qe(a,e),He(e)}}function He(e){var a=e.flags;if(a&2){try{for(var t,l=e.return;l!==null;){if(cp(l)){t=l;break}l=l.return}if(t==null)throw Error(C(160));switch(t.tag){case 27:var u=t.stateNode,o=ar(e);Cn(e,o,u);break;case 5:var n=t.stateNode;t.flags&32&&(Nl(n,""),t.flags&=-33);var s=ar(e);Cn(e,s,n);break;case 3:case 4:var r=t.stateNode.containerInfo,i=ar(e);Gr(e,i,r);break;default:throw Error(C(161))}}catch(p){X(e,e.return,p)}e.flags&=-3}a&4096&&(e.flags&=-4097)}function yp(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var a=e;yp(a),a.tag===5&&a.flags&1024&&a.stateNode.reset(),e=e.sibling}}function qa(e,a){if(a.subtreeFlags&8772)for(a=a.child;a!==null;)pp(e,a.alternate,a),a=a.sibling}function Gt(e){for(e=e.child;e!==null;){var a=e;switch(a.tag){case 0:case 11:case 14:case 15:kt(4,a,a.return),Gt(a);break;case 1:Aa(a,a.return);var t=a.stateNode;typeof t.componentWillUnmount=="function"&&dp(a,a.return,t),Gt(a);break;case 27:Hu(a.stateNode);case 26:case 5:Aa(a,a.return),Gt(a);break;case 22:a.memoizedState===null&&Gt(a);break;case 30:Gt(a);break;default:Gt(a)}e=e.sibling}}function Ha(e,a,t){for(t=t&&(a.subtreeFlags&8772)!==0,a=a.child;a!==null;){var l=a.alternate,u=e,o=a,n=o.flags;switch(o.tag){case 0:case 11:case 15:Ha(u,o,t),oo(4,o);break;case 1:if(Ha(u,o,t),l=o,u=l.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(i){X(l,l.return,i)}if(l=o,u=l.updateQueue,u!==null){var s=l.stateNode;try{var r=u.shared.hiddenCallbacks;if(r!==null)for(u.shared.hiddenCallbacks=null,u=0;u<r.length;u++)xm(r[u],s)}catch(i){X(l,l.return,i)}}t&&n&64&&ip(o),Bu(o,o.return);break;case 27:mp(o);case 26:case 5:Ha(u,o,t),t&&l===null&&n&4&&fp(o),Bu(o,o.return);break;case 12:Ha(u,o,t);break;case 31:Ha(u,o,t),t&&n&4&&xp(u,o);break;case 13:Ha(u,o,t),t&&n&4&&Lp(u,o);break;case 22:o.memoizedState===null&&Ha(u,o,t),Bu(o,o.return);break;case 30:break;default:Ha(u,o,t)}a=a.sibling}}function Fi(e,a){var t=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(t=e.memoizedState.cachePool.pool),e=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(e=a.memoizedState.cachePool.pool),e!==t&&(e!=null&&e.refCount++,t!=null&&lo(t))}function Gi(e,a){e=null,a.alternate!==null&&(e=a.alternate.memoizedState.cache),a=a.memoizedState.cache,a!==e&&(a.refCount++,e!=null&&lo(e))}function xa(e,a,t,l){if(a.subtreeFlags&10256)for(a=a.child;a!==null;)Cp(e,a,t,l),a=a.sibling}function Cp(e,a,t,l){var u=a.flags;switch(a.tag){case 0:case 11:case 15:xa(e,a,t,l),u&2048&&oo(9,a);break;case 1:xa(e,a,t,l);break;case 3:xa(e,a,t,l),u&2048&&(e=null,a.alternate!==null&&(e=a.alternate.memoizedState.cache),a=a.memoizedState.cache,a!==e&&(a.refCount++,e!=null&&lo(e)));break;case 12:if(u&2048){xa(e,a,t,l),e=a.stateNode;try{var o=a.memoizedProps,n=o.id,s=o.onPostCommit;typeof s=="function"&&s(n,a.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(r){X(a,a.return,r)}}else xa(e,a,t,l);break;case 31:xa(e,a,t,l);break;case 13:xa(e,a,t,l);break;case 23:break;case 22:o=a.stateNode,n=a.alternate,a.memoizedState!==null?o._visibility&2?xa(e,a,t,l):Eu(e,a):o._visibility&2?xa(e,a,t,l):(o._visibility|=2,xl(e,a,t,l,(a.subtreeFlags&10256)!==0||!1)),u&2048&&Fi(n,a);break;case 24:xa(e,a,t,l),u&2048&&Gi(a.alternate,a);break;default:xa(e,a,t,l)}}function xl(e,a,t,l,u){for(u=u&&((a.subtreeFlags&10256)!==0||!1),a=a.child;a!==null;){var o=e,n=a,s=t,r=l,i=n.flags;switch(n.tag){case 0:case 11:case 15:xl(o,n,s,r,u),oo(8,n);break;case 23:break;case 22:var p=n.stateNode;n.memoizedState!==null?p._visibility&2?xl(o,n,s,r,u):Eu(o,n):(p._visibility|=2,xl(o,n,s,r,u)),u&&i&2048&&Fi(n.alternate,n);break;case 24:xl(o,n,s,r,u),u&&i&2048&&Gi(n.alternate,n);break;default:xl(o,n,s,r,u)}a=a.sibling}}function Eu(e,a){if(a.subtreeFlags&10256)for(a=a.child;a!==null;){var t=e,l=a,u=l.flags;switch(l.tag){case 22:Eu(t,l),u&2048&&Fi(l.alternate,l);break;case 24:Eu(t,l),u&2048&&Gi(l.alternate,l);break;default:Eu(t,l)}a=a.sibling}}var vu=8192;function hl(e,a,t){if(e.subtreeFlags&vu)for(e=e.child;e!==null;)bp(e,a,t),e=e.sibling}function bp(e,a,t){switch(e.tag){case 26:hl(e,a,t),e.flags&vu&&e.memoizedState!==null&&vS(t,La,e.memoizedState,e.memoizedProps);break;case 5:hl(e,a,t);break;case 3:case 4:var l=La;La=Mn(e.stateNode.containerInfo),hl(e,a,t),La=l;break;case 22:e.memoizedState===null&&(l=e.alternate,l!==null&&l.memoizedState!==null?(l=vu,vu=16777216,hl(e,a,t),vu=l):hl(e,a,t));break;default:hl(e,a,t)}}function vp(e){var a=e.alternate;if(a!==null&&(e=a.child,e!==null)){a.child=null;do a=e.sibling,e.sibling=null,e=a;while(e!==null)}}function hu(e){var a=e.deletions;if((e.flags&16)!==0){if(a!==null)for(var t=0;t<a.length;t++){var l=a[t];Se=l,kp(l,e)}vp(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Ip(e),e=e.sibling}function Ip(e){switch(e.tag){case 0:case 11:case 15:hu(e),e.flags&2048&&kt(9,e,e.return);break;case 3:hu(e);break;case 12:hu(e);break;case 22:var a=e.stateNode;e.memoizedState!==null&&a._visibility&2&&(e.return===null||e.return.tag!==13)?(a._visibility&=-3,$o(e)):hu(e);break;default:hu(e)}}function $o(e){var a=e.deletions;if((e.flags&16)!==0){if(a!==null)for(var t=0;t<a.length;t++){var l=a[t];Se=l,kp(l,e)}vp(e)}for(e=e.child;e!==null;){switch(a=e,a.tag){case 0:case 11:case 15:kt(8,a,a.return),$o(a);break;case 22:t=a.stateNode,t._visibility&2&&(t._visibility&=-3,$o(a));break;default:$o(a)}e=e.sibling}}function kp(e,a){for(;Se!==null;){var t=Se;switch(t.tag){case 0:case 11:case 15:kt(8,t,a);break;case 23:case 22:if(t.memoizedState!==null&&t.memoizedState.cachePool!==null){var l=t.memoizedState.cachePool.pool;l!=null&&l.refCount++}break;case 24:lo(t.memoizedState.cache)}if(l=t.child,l!==null)l.return=t,Se=l;else e:for(t=e;Se!==null;){l=Se;var u=l.sibling,o=l.return;if(gp(l),l===t){Se=null;break e}if(u!==null){u.return=o,Se=u;break e}Se=o}}}var NL={getCacheForType:function(e){var a=ke(ce),t=a.data.get(e);return t===void 0&&(t=e(),a.data.set(e,t)),t},cacheSignal:function(){return ke(ce).controller.signal}},PL=typeof WeakMap=="function"?WeakMap:Map,P=0,Y=null,z=null,_=0,V=0,Ve=null,ft=!1,$l=!1,Vi=!1,Za=0,se=0,At=0,Yt=0,Xi=0,Ke=0,Vl=0,Ou=null,ze=null,Vr=!1,Xn=0,Ap=0,bn=1/0,vn=null,Lt=null,pe=0,St=null,Xl=null,Va=0,Xr=0,jr=null,Tp=null,qu=0,Kr=null;function Je(){return(P&2)!==0&&_!==0?_&-_:B.T!==null?Ki():Hc()}function wp(){if(Ke===0)if((_&536870912)===0||N){var e=To;To<<=1,(To&3932160)===0&&(To=262144),Ke=e}else Ke=536870912;return e=$e.current,e!==null&&(e.flags|=32),Ke}function _e(e,a,t){(e===Y&&(V===2||V===9)||e.cancelPendingCommit!==null)&&(jl(e,0),ct(e,_,Ke,!1)),eo(e,t),((P&2)===0||e!==Y)&&(e===Y&&((P&2)===0&&(Yt|=t),se===4&&ct(e,_,Ke,!1)),Ma(e))}function Mp(e,a,t){if((P&6)!==0)throw Error(C(327));var l=!t&&(a&127)===0&&(a&e.expiredLanes)===0||$u(e,a),u=l?VL(e,a):lr(e,a,!0),o=l;do{if(u===0){$l&&!l&&ct(e,a,0,!1);break}else{if(t=e.current.alternate,o&&!FL(t)){u=lr(e,a,!1),o=!1;continue}if(u===2){if(o=a,e.errorRecoveryDisabledLanes&o)var n=0;else n=e.pendingLanes&-536870913,n=n!==0?n:n&536870912?536870912:0;if(n!==0){a=n;e:{var s=e;u=Ou;var r=s.current.memoizedState.isDehydrated;if(r&&(jl(s,n).flags|=256),n=lr(s,n,!1),n!==2){if(Vi&&!r){s.errorRecoveryDisabledLanes|=o,Yt|=o,u=4;break e}o=ze,ze=u,o!==null&&(ze===null?ze=o:ze.push.apply(ze,o))}u=n}if(o=!1,u!==2)continue}}if(u===1){jl(e,0),ct(e,a,0,!0);break}e:{switch(l=e,o=u,o){case 0:case 1:throw Error(C(345));case 4:if((a&4194048)!==a)break;case 6:ct(l,a,Ke,!ft);break e;case 2:ze=null;break;case 3:case 5:break;default:throw Error(C(329))}if((a&62914560)===a&&(u=Xn+300-Ye(),10<u)){if(ct(l,a,Ke,!ft),On(l,0,!0)!==0)break e;Va=a,l.timeoutHandle=Zp(Kf.bind(null,l,t,ze,vn,Vr,a,Ke,Yt,Vl,ft,o,"Throttled",-0,0),u);break e}Kf(l,t,ze,vn,Vr,a,Ke,Yt,Vl,ft,o,null,-0,0)}}break}while(!0);Ma(e)}function Kf(e,a,t,l,u,o,n,s,r,i,p,g,f,c){if(e.timeoutHandle=-1,g=a.subtreeFlags,g&8192||(g&16785408)===16785408){g={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Na},bp(a,o,g);var S=(o&62914560)===o?Xn-Ye():(o&4194048)===o?Ap-Ye():0;if(S=IS(g,S),S!==null){Va=o,e.cancelPendingCommit=S(Zf.bind(null,e,a,o,t,l,u,n,s,r,p,g,null,f,c)),ct(e,o,n,!i);return}}Zf(e,a,o,t,l,u,n,s,r)}function FL(e){for(var a=e;;){var t=a.tag;if((t===0||t===11||t===15)&&a.flags&16384&&(t=a.updateQueue,t!==null&&(t=t.stores,t!==null)))for(var l=0;l<t.length;l++){var u=t[l],o=u.getSnapshot;u=u.value;try{if(!We(o(),u))return!1}catch{return!1}}if(t=a.child,a.subtreeFlags&16384&&t!==null)t.return=a,a=t;else{if(a===e)break;for(;a.sibling===null;){if(a.return===null||a.return===e)return!0;a=a.return}a.sibling.return=a.return,a=a.sibling}}return!0}function ct(e,a,t,l){a&=~Xi,a&=~Yt,e.suspendedLanes|=a,e.pingedLanes&=~a,l&&(e.warmLanes|=a),l=e.expirationTimes;for(var u=a;0<u;){var o=31-Qe(u),n=1<<o;l[o]=-1,u&=~n}t!==0&&Ec(e,t,a)}function jn(){return(P&6)===0?(no(0,!1),!1):!0}function ji(){if(z!==null){if(V===0)var e=z.return;else e=z,Pa=ul=null,Ri(e),ql=null,Gu=0,e=z;for(;e!==null;)rp(e.alternate,e),e=e.return;z=null}}function jl(e,a){var t=e.timeoutHandle;t!==-1&&(e.timeoutHandle=-1,nS(t)),t=e.cancelPendingCommit,t!==null&&(e.cancelPendingCommit=null,t()),Va=0,ji(),Y=e,z=t=Fa(e.current,null),_=a,V=0,Ve=null,ft=!1,$l=$u(e,a),Vi=!1,Vl=Ke=Xi=Yt=At=se=0,ze=Ou=null,Vr=!1,(a&8)!==0&&(a|=a&32);var l=e.entangledLanes;if(l!==0)for(e=e.entanglements,l&=a;0<l;){var u=31-Qe(l),o=1<<u;a|=e[u],l&=~o}return Za=a,zn(),t}function Dp(e,a){O=null,B.H=Xu,a===Wl||a===Nn?(a=kf(),V=3):a===Ii?(a=kf(),V=4):V=a===Ni?8:a!==null&&typeof a=="object"&&typeof a.then=="function"?6:1,Ve=a,z===null&&(se=1,Sn(e,ra(a,e.current)))}function Rp(){var e=$e.current;return e===null?!0:(_&4194048)===_?da===null:(_&62914560)===_||(_&536870912)!==0?e===da:!1}function Bp(){var e=B.H;return B.H=Xu,e===null?Xu:e}function Ep(){var e=B.A;return B.A=NL,e}function In(){se=4,ft||(_&4194048)!==_&&$e.current!==null||($l=!0),(At&134217727)===0&&(Yt&134217727)===0||Y===null||ct(Y,_,Ke,!1)}function lr(e,a,t){var l=P;P|=2;var u=Bp(),o=Ep();(Y!==e||_!==a)&&(vn=null,jl(e,a)),a=!1;var n=se;e:do try{if(V!==0&&z!==null){var s=z,r=Ve;switch(V){case 8:ji(),n=6;break e;case 3:case 2:case 9:case 6:$e.current===null&&(a=!0);var i=V;if(V=0,Ve=null,Dl(e,s,r,i),t&&$l){n=0;break e}break;default:i=V,V=0,Ve=null,Dl(e,s,r,i)}}GL(),n=se;break}catch(p){Dp(e,p)}while(!0);return a&&e.shellSuspendCounter++,Pa=ul=null,P=l,B.H=u,B.A=o,z===null&&(Y=null,_=0,zn()),n}function GL(){for(;z!==null;)Op(z)}function VL(e,a){var t=P;P|=2;var l=Bp(),u=Ep();Y!==e||_!==a?(vn=null,bn=Ye()+500,jl(e,a)):$l=$u(e,a);e:do try{if(V!==0&&z!==null){a=z;var o=Ve;a:switch(V){case 1:V=0,Ve=null,Dl(e,a,o,1);break;case 2:case 9:if(If(o)){V=0,Ve=null,Yf(a);break}a=function(){V!==2&&V!==9||Y!==e||(V=7),Ma(e)},o.then(a,a);break e;case 3:V=7;break e;case 4:V=5;break e;case 7:If(o)?(V=0,Ve=null,Yf(a)):(V=0,Ve=null,Dl(e,a,o,7));break;case 5:var n=null;switch(z.tag){case 26:n=z.memoizedState;case 5:case 27:var s=z;if(n?eg(n):s.stateNode.complete){V=0,Ve=null;var r=s.sibling;if(r!==null)z=r;else{var i=s.return;i!==null?(z=i,Kn(i)):z=null}break a}}V=0,Ve=null,Dl(e,a,o,5);break;case 6:V=0,Ve=null,Dl(e,a,o,6);break;case 8:ji(),se=6;break e;default:throw Error(C(462))}}XL();break}catch(p){Dp(e,p)}while(!0);return Pa=ul=null,B.H=l,B.A=u,P=t,z!==null?0:(Y=null,_=0,zn(),se)}function XL(){for(;z!==null&&!px();)Op(z)}function Op(e){var a=sp(e.alternate,e,Za);e.memoizedProps=e.pendingProps,a===null?Kn(e):z=a}function Yf(e){var a=e,t=a.alternate;switch(a.tag){case 15:case 0:a=Pf(t,a,a.pendingProps,a.type,void 0,_);break;case 11:a=Pf(t,a,a.pendingProps,a.type.render,a.ref,_);break;case 5:Ri(a);default:rp(t,a),a=z=rm(a,Za),a=sp(t,a,Za)}e.memoizedProps=e.pendingProps,a===null?Kn(e):z=a}function Dl(e,a,t,l){Pa=ul=null,Ri(a),ql=null,Gu=0;var u=a.return;try{if(EL(e,u,a,t,_)){se=1,Sn(e,ra(t,e.current)),z=null;return}}catch(o){if(u!==null)throw z=u,o;se=1,Sn(e,ra(t,e.current)),z=null;return}a.flags&32768?(N||l===1?e=!0:$l||(_&536870912)!==0?e=!1:(ft=e=!0,(l===2||l===9||l===3||l===6)&&(l=$e.current,l!==null&&l.tag===13&&(l.flags|=16384))),qp(a,e)):Kn(a)}function Kn(e){var a=e;do{if((a.flags&32768)!==0){qp(a,ft);return}e=a.return;var t=HL(a.alternate,a,Za);if(t!==null){z=t;return}if(a=a.sibling,a!==null){z=a;return}z=a=e}while(a!==null);se===0&&(se=5)}function qp(e,a){do{var t=UL(e.alternate,e);if(t!==null){t.flags&=32767,z=t;return}if(t=e.return,t!==null&&(t.flags|=32768,t.subtreeFlags=0,t.deletions=null),!a&&(e=e.sibling,e!==null)){z=e;return}z=e=t}while(e!==null);se=6,z=null}function Zf(e,a,t,l,u,o,n,s,r){e.cancelPendingCommit=null;do Yn();while(pe!==0);if((P&6)!==0)throw Error(C(327));if(a!==null){if(a===e.current)throw Error(C(177));if(o=a.lanes|a.childLanes,o|=xi,Ix(e,t,o,n,s,r),e===Y&&(z=Y=null,_=0),Xl=a,St=e,Va=t,Xr=o,jr=u,Tp=l,(a.subtreeFlags&10256)!==0||(a.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,ZL(sn,function(){return Np(),null})):(e.callbackNode=null,e.callbackPriority=0),l=(a.flags&13878)!==0,(a.subtreeFlags&13878)!==0||l){l=B.T,B.T=null,u=F.p,F.p=2,n=P,P|=4;try{zL(e,a,t)}finally{P=n,F.p=u,B.T=l}}pe=1,Hp(),Up(),zp()}}function Hp(){if(pe===1){pe=0;var e=St,a=Xl,t=(a.flags&13878)!==0;if((a.subtreeFlags&13878)!==0||t){t=B.T,B.T=null;var l=F.p;F.p=2;var u=P;P|=4;try{Sp(a,e);var o=Jr,n=em(e.containerInfo),s=o.focusedElem,r=o.selectionRange;if(n!==s&&s&&s.ownerDocument&&$c(s.ownerDocument.documentElement,s)){if(r!==null&&hi(s)){var i=r.start,p=r.end;if(p===void 0&&(p=i),"selectionStart"in s)s.selectionStart=i,s.selectionEnd=Math.min(p,s.value.length);else{var g=s.ownerDocument||document,f=g&&g.defaultView||window;if(f.getSelection){var c=f.getSelection(),S=s.textContent.length,b=Math.min(r.start,S),A=r.end===void 0?b:Math.min(r.end,S);!c.extend&&b>A&&(n=A,A=b,b=n);var h=xf(s,b),d=xf(s,A);if(h&&d&&(c.rangeCount!==1||c.anchorNode!==h.node||c.anchorOffset!==h.offset||c.focusNode!==d.node||c.focusOffset!==d.offset)){var m=g.createRange();m.setStart(h.node,h.offset),c.removeAllRanges(),b>A?(c.addRange(m),c.extend(d.node,d.offset)):(m.setEnd(d.node,d.offset),c.addRange(m))}}}}for(g=[],c=s;c=c.parentNode;)c.nodeType===1&&g.push({element:c,left:c.scrollLeft,top:c.scrollTop});for(typeof s.focus=="function"&&s.focus(),s=0;s<g.length;s++){var x=g[s];x.element.scrollLeft=x.left,x.element.scrollTop=x.top}}Bn=!!Qr,Jr=Qr=null}finally{P=u,F.p=l,B.T=t}}e.current=a,pe=2}}function Up(){if(pe===2){pe=0;var e=St,a=Xl,t=(a.flags&8772)!==0;if((a.subtreeFlags&8772)!==0||t){t=B.T,B.T=null;var l=F.p;F.p=2;var u=P;P|=4;try{pp(e,a.alternate,a)}finally{P=u,F.p=l,B.T=t}}pe=3}}function zp(){if(pe===4||pe===3){pe=0,gx();var e=St,a=Xl,t=Va,l=Tp;(a.subtreeFlags&10256)!==0||(a.flags&10256)!==0?pe=5:(pe=0,Xl=St=null,_p(e,e.pendingLanes));var u=e.pendingLanes;if(u===0&&(Lt=null),ii(t),a=a.stateNode,Ze&&typeof Ze.onCommitFiberRoot=="function")try{Ze.onCommitFiberRoot(Wu,a,void 0,(a.current.flags&128)===128)}catch{}if(l!==null){a=B.T,u=F.p,F.p=2,B.T=null;try{for(var o=e.onRecoverableError,n=0;n<l.length;n++){var s=l[n];o(s.value,{componentStack:s.stack})}}finally{B.T=a,F.p=u}}(Va&3)!==0&&Yn(),Ma(e),u=e.pendingLanes,(t&261930)!==0&&(u&42)!==0?e===Kr?qu++:(qu=0,Kr=e):qu=0,no(0,!1)}}function _p(e,a){(e.pooledCacheLanes&=a)===0&&(a=e.pooledCache,a!=null&&(e.pooledCache=null,lo(a)))}function Yn(){return Hp(),Up(),zp(),Np()}function Np(){if(pe!==5)return!1;var e=St,a=Xr;Xr=0;var t=ii(Va),l=B.T,u=F.p;try{F.p=32>t?32:t,B.T=null,t=jr,jr=null;var o=St,n=Va;if(pe=0,Xl=St=null,Va=0,(P&6)!==0)throw Error(C(331));var s=P;if(P|=4,Ip(o.current),Cp(o,o.current,n,t),P=s,no(0,!1),Ze&&typeof Ze.onPostCommitFiberRoot=="function")try{Ze.onPostCommitFiberRoot(Wu,o)}catch{}return!0}finally{F.p=u,B.T=l,_p(e,a)}}function Qf(e,a,t){a=ra(t,a),a=Nr(e.stateNode,a,2),e=xt(e,a,2),e!==null&&(eo(e,2),Ma(e))}function X(e,a,t){if(e.tag===3)Qf(e,e,t);else for(;a!==null;){if(a.tag===3){Qf(a,e,t);break}else if(a.tag===1){var l=a.stateNode;if(typeof a.type.getDerivedStateFromError=="function"||typeof l.componentDidCatch=="function"&&(Lt===null||!Lt.has(l))){e=ra(t,e),t=ap(2),l=xt(a,t,2),l!==null&&(tp(t,l,a,e),eo(l,2),Ma(l));break}}a=a.return}}function ur(e,a,t){var l=e.pingCache;if(l===null){l=e.pingCache=new PL;var u=new Set;l.set(a,u)}else u=l.get(a),u===void 0&&(u=new Set,l.set(a,u));u.has(t)||(Vi=!0,u.add(t),e=jL.bind(null,e,a,t),a.then(e,e))}function jL(e,a,t){var l=e.pingCache;l!==null&&l.delete(a),e.pingedLanes|=e.suspendedLanes&t,e.warmLanes&=~t,Y===e&&(_&t)===t&&(se===4||se===3&&(_&62914560)===_&&300>Ye()-Xn?(P&2)===0&&jl(e,0):Xi|=t,Vl===_&&(Vl=0)),Ma(e)}function Pp(e,a){a===0&&(a=Bc()),e=ll(e,a),e!==null&&(eo(e,a),Ma(e))}function KL(e){var a=e.memoizedState,t=0;a!==null&&(t=a.retryLane),Pp(e,t)}function YL(e,a){var t=0;switch(e.tag){case 31:case 13:var l=e.stateNode,u=e.memoizedState;u!==null&&(t=u.retryLane);break;case 19:l=e.stateNode;break;case 22:l=e.stateNode._retryCache;break;default:throw Error(C(314))}l!==null&&l.delete(a),Pp(e,t)}function ZL(e,a){return si(e,a)}var kn=null,Ll=null,Yr=!1,An=!1,or=!1,mt=0;function Ma(e){e!==Ll&&e.next===null&&(Ll===null?kn=Ll=e:Ll=Ll.next=e),An=!0,Yr||(Yr=!0,JL())}function no(e,a){if(!or&&An){or=!0;do for(var t=!1,l=kn;l!==null;){if(!a)if(e!==0){var u=l.pendingLanes;if(u===0)var o=0;else{var n=l.suspendedLanes,s=l.pingedLanes;o=(1<<31-Qe(42|e)+1)-1,o&=u&~(n&~s),o=o&201326741?o&201326741|1:o?o|2:0}o!==0&&(t=!0,Jf(l,o))}else o=_,o=On(l,l===Y?o:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),(o&3)===0||$u(l,o)||(t=!0,Jf(l,o));l=l.next}while(t);or=!1}}function QL(){Fp()}function Fp(){An=Yr=!1;var e=0;mt!==0&&oS()&&(e=mt);for(var a=Ye(),t=null,l=kn;l!==null;){var u=l.next,o=Gp(l,a);o===0?(l.next=null,t===null?kn=u:t.next=u,u===null&&(Ll=t)):(t=l,(e!==0||(o&3)!==0)&&(An=!0)),l=u}pe!==0&&pe!==5||no(e,!1),mt!==0&&(mt=0)}function Gp(e,a){for(var t=e.suspendedLanes,l=e.pingedLanes,u=e.expirationTimes,o=e.pendingLanes&-62914561;0<o;){var n=31-Qe(o),s=1<<n,r=u[n];r===-1?((s&t)===0||(s&l)!==0)&&(u[n]=vx(s,a)):r<=a&&(e.expiredLanes|=s),o&=~s}if(a=Y,t=_,t=On(e,e===a?t:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l=e.callbackNode,t===0||e===a&&(V===2||V===9)||e.cancelPendingCommit!==null)return l!==null&&l!==null&&Os(l),e.callbackNode=null,e.callbackPriority=0;if((t&3)===0||$u(e,t)){if(a=t&-t,a===e.callbackPriority)return a;switch(l!==null&&Os(l),ii(t)){case 2:case 8:t=Dc;break;case 32:t=sn;break;case 268435456:t=Rc;break;default:t=sn}return l=Vp.bind(null,e),t=si(t,l),e.callbackPriority=a,e.callbackNode=t,a}return l!==null&&l!==null&&Os(l),e.callbackPriority=2,e.callbackNode=null,2}function Vp(e,a){if(pe!==0&&pe!==5)return e.callbackNode=null,e.callbackPriority=0,null;var t=e.callbackNode;if(Yn()&&e.callbackNode!==t)return null;var l=_;return l=On(e,e===Y?l:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l===0?null:(Mp(e,l,a),Gp(e,Ye()),e.callbackNode!=null&&e.callbackNode===t?Vp.bind(null,e):null)}function Jf(e,a){if(Yn())return null;Mp(e,a,!0)}function JL(){sS(function(){(P&6)!==0?si(Mc,QL):Fp()})}function Ki(){if(mt===0){var e=Pl;e===0&&(e=Ao,Ao<<=1,(Ao&261888)===0&&(Ao=256)),mt=e}return mt}function Wf(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Vo(""+e)}function $f(e,a){var t=a.ownerDocument.createElement("input");return t.name=a.name,t.value=a.value,e.id&&t.setAttribute("form",e.id),a.parentNode.insertBefore(t,a),e=new FormData(e),t.parentNode.removeChild(t),e}function WL(e,a,t,l,u){if(a==="submit"&&t&&t.stateNode===u){var o=Wf((u[Ne]||null).action),n=l.submitter;n&&(a=(a=n[Ne]||null)?Wf(a.formAction):n.getAttribute("formAction"),a!==null&&(o=a,n=null));var s=new qn("action","action",null,l,u);e.push({event:s,listeners:[{instance:null,listener:function(){if(l.defaultPrevented){if(mt!==0){var r=n?$f(u,n):new FormData(u);zr(t,{pending:!0,data:r,method:u.method,action:o},null,r)}}else typeof o=="function"&&(s.preventDefault(),r=n?$f(u,n):new FormData(u),zr(t,{pending:!0,data:r,method:u.method,action:o},o,r))},currentTarget:u}]})}}for(zo=0;zo<Ar.length;zo++)_o=Ar[zo],ec=_o.toLowerCase(),ac=_o[0].toUpperCase()+_o.slice(1),Sa(ec,"on"+ac);var _o,ec,ac,zo;Sa(tm,"onAnimationEnd");Sa(lm,"onAnimationIteration");Sa(um,"onAnimationStart");Sa("dblclick","onDoubleClick");Sa("focusin","onFocus");Sa("focusout","onBlur");Sa(hL,"onTransitionRun");Sa(xL,"onTransitionStart");Sa(LL,"onTransitionCancel");Sa(om,"onTransitionEnd");_l("onMouseEnter",["mouseout","mouseover"]);_l("onMouseLeave",["mouseout","mouseover"]);_l("onPointerEnter",["pointerout","pointerover"]);_l("onPointerLeave",["pointerout","pointerover"]);el("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));el("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));el("onBeforeInput",["compositionend","keypress","textInput","paste"]);el("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));el("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));el("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var ju="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),$L=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(ju));function Xp(e,a){a=(a&4)!==0;for(var t=0;t<e.length;t++){var l=e[t],u=l.event;l=l.listeners;e:{var o=void 0;if(a)for(var n=l.length-1;0<=n;n--){var s=l[n],r=s.instance,i=s.currentTarget;if(s=s.listener,r!==o&&u.isPropagationStopped())break e;o=s,u.currentTarget=i;try{o(u)}catch(p){dn(p)}u.currentTarget=null,o=r}else for(n=0;n<l.length;n++){if(s=l[n],r=s.instance,i=s.currentTarget,s=s.listener,r!==o&&u.isPropagationStopped())break e;o=s,u.currentTarget=i;try{o(u)}catch(p){dn(p)}u.currentTarget=null,o=r}}}}function U(e,a){var t=a[Lr];t===void 0&&(t=a[Lr]=new Set);var l=e+"__bubble";t.has(l)||(jp(a,e,2,!1),t.add(l))}function nr(e,a,t){var l=0;a&&(l|=4),jp(t,e,l,a)}var No="_reactListening"+Math.random().toString(36).slice(2);function Yi(e){if(!e[No]){e[No]=!0,Uc.forEach(function(t){t!=="selectionchange"&&($L.has(t)||nr(t,!1,e),nr(t,!0,e))});var a=e.nodeType===9?e:e.ownerDocument;a===null||a[No]||(a[No]=!0,nr("selectionchange",!1,a))}}function jp(e,a,t,l){switch(og(a)){case 2:var u=TS;break;case 8:u=wS;break;default:u=Wi}t=u.bind(null,a,t,e),u=void 0,!vr||a!=="touchstart"&&a!=="touchmove"&&a!=="wheel"||(u=!0),l?u!==void 0?e.addEventListener(a,t,{capture:!0,passive:u}):e.addEventListener(a,t,!0):u!==void 0?e.addEventListener(a,t,{passive:u}):e.addEventListener(a,t,!1)}function sr(e,a,t,l,u){var o=l;if((a&1)===0&&(a&2)===0&&l!==null)e:for(;;){if(l===null)return;var n=l.tag;if(n===3||n===4){var s=l.stateNode.containerInfo;if(s===u)break;if(n===4)for(n=l.return;n!==null;){var r=n.tag;if((r===3||r===4)&&n.stateNode.containerInfo===u)return;n=n.return}for(;s!==null;){if(n=Cl(s),n===null)return;if(r=n.tag,r===5||r===6||r===26||r===27){l=o=n;continue e}s=s.parentNode}}l=l.return}Xc(function(){var i=o,p=ci(t),g=[];e:{var f=nm.get(e);if(f!==void 0){var c=qn,S=e;switch(e){case"keypress":if(jo(t)===0)break e;case"keydown":case"keyup":c=Yx;break;case"focusin":S="focus",c=_s;break;case"focusout":S="blur",c=_s;break;case"beforeblur":case"afterblur":c=_s;break;case"click":if(t.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":c=sf;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":c=Hx;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":c=Jx;break;case tm:case lm:case um:c=_x;break;case om:c=$x;break;case"scroll":case"scrollend":c=Ox;break;case"wheel":c=aL;break;case"copy":case"cut":case"paste":c=Px;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":c=df;break;case"toggle":case"beforetoggle":c=lL}var b=(a&4)!==0,A=!b&&(e==="scroll"||e==="scrollend"),h=b?f!==null?f+"Capture":null:f;b=[];for(var d=i,m;d!==null;){var x=d;if(m=x.stateNode,x=x.tag,x!==5&&x!==26&&x!==27||m===null||h===null||(x=zu(d,h),x!=null&&b.push(Ku(d,x,m))),A)break;d=d.return}0<b.length&&(f=new c(f,S,null,t,p),g.push({event:f,listeners:b}))}}if((a&7)===0){e:{if(f=e==="mouseover"||e==="pointerover",c=e==="mouseout"||e==="pointerout",f&&t!==br&&(S=t.relatedTarget||t.fromElement)&&(Cl(S)||S[Zl]))break e;if((c||f)&&(f=p.window===p?p:(f=p.ownerDocument)?f.defaultView||f.parentWindow:window,c?(S=t.relatedTarget||t.toElement,c=i,S=S?Cl(S):null,S!==null&&(A=Ju(S),b=S.tag,S!==A||b!==5&&b!==27&&b!==6)&&(S=null)):(c=null,S=i),c!==S)){if(b=sf,x="onMouseLeave",h="onMouseEnter",d="mouse",(e==="pointerout"||e==="pointerover")&&(b=df,x="onPointerLeave",h="onPointerEnter",d="pointer"),A=c==null?f:Cu(c),m=S==null?f:Cu(S),f=new b(x,d+"leave",c,t,p),f.target=A,f.relatedTarget=m,x=null,Cl(p)===i&&(b=new b(h,d+"enter",S,t,p),b.target=m,b.relatedTarget=A,x=b),A=x,c&&S)a:{for(b=eS,h=c,d=S,m=0,x=h;x;x=b(x))m++;x=0;for(var L=d;L;L=b(L))x++;for(;0<m-x;)h=b(h),m--;for(;0<x-m;)d=b(d),x--;for(;m--;){if(h===d||d!==null&&h===d.alternate){b=h;break a}h=b(h),d=b(d)}b=null}else b=null;c!==null&&tc(g,f,c,b,!1),S!==null&&A!==null&&tc(g,A,S,b,!0)}}e:{if(f=i?Cu(i):window,c=f.nodeName&&f.nodeName.toLowerCase(),c==="select"||c==="input"&&f.type==="file")var k=pf;else if(mf(f))if(Jc)k=mL;else{k=fL;var v=dL}else c=f.nodeName,!c||c.toLowerCase()!=="input"||f.type!=="checkbox"&&f.type!=="radio"?i&&fi(i.elementType)&&(k=pf):k=cL;if(k&&(k=k(e,i))){Qc(g,k,t,p);break e}v&&v(e,f,i),e==="focusout"&&i&&f.type==="number"&&i.memoizedProps.value!=null&&Cr(f,"number",f.value)}switch(v=i?Cu(i):window,e){case"focusin":(mf(v)||v.contentEditable==="true")&&(Il=v,Ir=i,Au=null);break;case"focusout":Au=Ir=Il=null;break;case"mousedown":kr=!0;break;case"contextmenu":case"mouseup":case"dragend":kr=!1,Lf(g,t,p);break;case"selectionchange":if(gL)break;case"keydown":case"keyup":Lf(g,t,p)}var y;if(gi)e:{switch(e){case"compositionstart":var I="onCompositionStart";break e;case"compositionend":I="onCompositionEnd";break e;case"compositionupdate":I="onCompositionUpdate";break e}I=void 0}else vl?Yc(e,t)&&(I="onCompositionEnd"):e==="keydown"&&t.keyCode===229&&(I="onCompositionStart");I&&(Kc&&t.locale!=="ko"&&(vl||I!=="onCompositionStart"?I==="onCompositionEnd"&&vl&&(y=jc()):(dt=p,mi="value"in dt?dt.value:dt.textContent,vl=!0)),v=Tn(i,I),0<v.length&&(I=new rf(I,e,null,t,p),g.push({event:I,listeners:v}),y?I.data=y:(y=Zc(t),y!==null&&(I.data=y)))),(y=oL?nL(e,t):sL(e,t))&&(I=Tn(i,"onBeforeInput"),0<I.length&&(v=new rf("onBeforeInput","beforeinput",null,t,p),g.push({event:v,listeners:I}),v.data=y)),WL(g,e,i,t,p)}Xp(g,a)})}function Ku(e,a,t){return{instance:e,listener:a,currentTarget:t}}function Tn(e,a){for(var t=a+"Capture",l=[];e!==null;){var u=e,o=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||o===null||(u=zu(e,t),u!=null&&l.unshift(Ku(e,u,o)),u=zu(e,a),u!=null&&l.push(Ku(e,u,o))),e.tag===3)return l;e=e.return}return[]}function eS(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function tc(e,a,t,l,u){for(var o=a._reactName,n=[];t!==null&&t!==l;){var s=t,r=s.alternate,i=s.stateNode;if(s=s.tag,r!==null&&r===l)break;s!==5&&s!==26&&s!==27||i===null||(r=i,u?(i=zu(t,o),i!=null&&n.unshift(Ku(t,i,r))):u||(i=zu(t,o),i!=null&&n.push(Ku(t,i,r)))),t=t.return}n.length!==0&&e.push({event:a,listeners:n})}var aS=/\r\n?/g,tS=/\u0000|\uFFFD/g;function lc(e){return(typeof e=="string"?e:""+e).replace(aS,`
`).replace(tS,"")}function Kp(e,a){return a=lc(a),lc(e)===a}function j(e,a,t,l,u,o){switch(t){case"children":typeof l=="string"?a==="body"||a==="textarea"&&l===""||Nl(e,l):(typeof l=="number"||typeof l=="bigint")&&a!=="body"&&Nl(e,""+l);break;case"className":Mo(e,"class",l);break;case"tabIndex":Mo(e,"tabindex",l);break;case"dir":case"role":case"viewBox":case"width":case"height":Mo(e,t,l);break;case"style":Vc(e,l,o);break;case"data":if(a!=="object"){Mo(e,"data",l);break}case"src":case"href":if(l===""&&(a!=="a"||t!=="href")){e.removeAttribute(t);break}if(l==null||typeof l=="function"||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(t);break}l=Vo(""+l),e.setAttribute(t,l);break;case"action":case"formAction":if(typeof l=="function"){e.setAttribute(t,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof o=="function"&&(t==="formAction"?(a!=="input"&&j(e,a,"name",u.name,u,null),j(e,a,"formEncType",u.formEncType,u,null),j(e,a,"formMethod",u.formMethod,u,null),j(e,a,"formTarget",u.formTarget,u,null)):(j(e,a,"encType",u.encType,u,null),j(e,a,"method",u.method,u,null),j(e,a,"target",u.target,u,null)));if(l==null||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(t);break}l=Vo(""+l),e.setAttribute(t,l);break;case"onClick":l!=null&&(e.onclick=Na);break;case"onScroll":l!=null&&U("scroll",e);break;case"onScrollEnd":l!=null&&U("scrollend",e);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(C(61));if(t=l.__html,t!=null){if(u.children!=null)throw Error(C(60));e.innerHTML=t}}break;case"multiple":e.multiple=l&&typeof l!="function"&&typeof l!="symbol";break;case"muted":e.muted=l&&typeof l!="function"&&typeof l!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(l==null||typeof l=="function"||typeof l=="boolean"||typeof l=="symbol"){e.removeAttribute("xlink:href");break}t=Vo(""+l),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",t);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(t,""+l):e.removeAttribute(t);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":l&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(t,""):e.removeAttribute(t);break;case"capture":case"download":l===!0?e.setAttribute(t,""):l!==!1&&l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(t,l):e.removeAttribute(t);break;case"cols":case"rows":case"size":case"span":l!=null&&typeof l!="function"&&typeof l!="symbol"&&!isNaN(l)&&1<=l?e.setAttribute(t,l):e.removeAttribute(t);break;case"rowSpan":case"start":l==null||typeof l=="function"||typeof l=="symbol"||isNaN(l)?e.removeAttribute(t):e.setAttribute(t,l);break;case"popover":U("beforetoggle",e),U("toggle",e),Go(e,"popover",l);break;case"xlinkActuate":Ba(e,"http://www.w3.org/1999/xlink","xlink:actuate",l);break;case"xlinkArcrole":Ba(e,"http://www.w3.org/1999/xlink","xlink:arcrole",l);break;case"xlinkRole":Ba(e,"http://www.w3.org/1999/xlink","xlink:role",l);break;case"xlinkShow":Ba(e,"http://www.w3.org/1999/xlink","xlink:show",l);break;case"xlinkTitle":Ba(e,"http://www.w3.org/1999/xlink","xlink:title",l);break;case"xlinkType":Ba(e,"http://www.w3.org/1999/xlink","xlink:type",l);break;case"xmlBase":Ba(e,"http://www.w3.org/XML/1998/namespace","xml:base",l);break;case"xmlLang":Ba(e,"http://www.w3.org/XML/1998/namespace","xml:lang",l);break;case"xmlSpace":Ba(e,"http://www.w3.org/XML/1998/namespace","xml:space",l);break;case"is":Go(e,"is",l);break;case"innerText":case"textContent":break;default:(!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(t=Bx.get(t)||t,Go(e,t,l))}}function Zr(e,a,t,l,u,o){switch(t){case"style":Vc(e,l,o);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(C(61));if(t=l.__html,t!=null){if(u.children!=null)throw Error(C(60));e.innerHTML=t}}break;case"children":typeof l=="string"?Nl(e,l):(typeof l=="number"||typeof l=="bigint")&&Nl(e,""+l);break;case"onScroll":l!=null&&U("scroll",e);break;case"onScrollEnd":l!=null&&U("scrollend",e);break;case"onClick":l!=null&&(e.onclick=Na);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!zc.hasOwnProperty(t))e:{if(t[0]==="o"&&t[1]==="n"&&(u=t.endsWith("Capture"),a=t.slice(2,u?t.length-7:void 0),o=e[Ne]||null,o=o!=null?o[t]:null,typeof o=="function"&&e.removeEventListener(a,o,u),typeof l=="function")){typeof o!="function"&&o!==null&&(t in e?e[t]=null:e.hasAttribute(t)&&e.removeAttribute(t)),e.addEventListener(a,l,u);break e}t in e?e[t]=l:l===!0?e.setAttribute(t,""):Go(e,t,l)}}}function Ae(e,a,t){switch(a){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":U("error",e),U("load",e);var l=!1,u=!1,o;for(o in t)if(t.hasOwnProperty(o)){var n=t[o];if(n!=null)switch(o){case"src":l=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(C(137,a));default:j(e,a,o,n,t,null)}}u&&j(e,a,"srcSet",t.srcSet,t,null),l&&j(e,a,"src",t.src,t,null);return;case"input":U("invalid",e);var s=o=n=u=null,r=null,i=null;for(l in t)if(t.hasOwnProperty(l)){var p=t[l];if(p!=null)switch(l){case"name":u=p;break;case"type":n=p;break;case"checked":r=p;break;case"defaultChecked":i=p;break;case"value":o=p;break;case"defaultValue":s=p;break;case"children":case"dangerouslySetInnerHTML":if(p!=null)throw Error(C(137,a));break;default:j(e,a,l,p,t,null)}}Pc(e,o,s,r,i,n,u,!1);return;case"select":U("invalid",e),l=n=o=null;for(u in t)if(t.hasOwnProperty(u)&&(s=t[u],s!=null))switch(u){case"value":o=s;break;case"defaultValue":n=s;break;case"multiple":l=s;default:j(e,a,u,s,t,null)}a=o,t=n,e.multiple=!!l,a!=null?Bl(e,!!l,a,!1):t!=null&&Bl(e,!!l,t,!0);return;case"textarea":U("invalid",e),o=u=l=null;for(n in t)if(t.hasOwnProperty(n)&&(s=t[n],s!=null))switch(n){case"value":l=s;break;case"defaultValue":u=s;break;case"children":o=s;break;case"dangerouslySetInnerHTML":if(s!=null)throw Error(C(91));break;default:j(e,a,n,s,t,null)}Gc(e,l,u,o);return;case"option":for(r in t)t.hasOwnProperty(r)&&(l=t[r],l!=null)&&(r==="selected"?e.selected=l&&typeof l!="function"&&typeof l!="symbol":j(e,a,r,l,t,null));return;case"dialog":U("beforetoggle",e),U("toggle",e),U("cancel",e),U("close",e);break;case"iframe":case"object":U("load",e);break;case"video":case"audio":for(l=0;l<ju.length;l++)U(ju[l],e);break;case"image":U("error",e),U("load",e);break;case"details":U("toggle",e);break;case"embed":case"source":case"link":U("error",e),U("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(i in t)if(t.hasOwnProperty(i)&&(l=t[i],l!=null))switch(i){case"children":case"dangerouslySetInnerHTML":throw Error(C(137,a));default:j(e,a,i,l,t,null)}return;default:if(fi(a)){for(p in t)t.hasOwnProperty(p)&&(l=t[p],l!==void 0&&Zr(e,a,p,l,t,void 0));return}}for(s in t)t.hasOwnProperty(s)&&(l=t[s],l!=null&&j(e,a,s,l,t,null))}function lS(e,a,t,l){switch(a){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,o=null,n=null,s=null,r=null,i=null,p=null;for(c in t){var g=t[c];if(t.hasOwnProperty(c)&&g!=null)switch(c){case"checked":break;case"value":break;case"defaultValue":r=g;default:l.hasOwnProperty(c)||j(e,a,c,null,l,g)}}for(var f in l){var c=l[f];if(g=t[f],l.hasOwnProperty(f)&&(c!=null||g!=null))switch(f){case"type":o=c;break;case"name":u=c;break;case"checked":i=c;break;case"defaultChecked":p=c;break;case"value":n=c;break;case"defaultValue":s=c;break;case"children":case"dangerouslySetInnerHTML":if(c!=null)throw Error(C(137,a));break;default:c!==g&&j(e,a,f,c,l,g)}}yr(e,n,s,r,i,p,o,u);return;case"select":c=n=s=f=null;for(o in t)if(r=t[o],t.hasOwnProperty(o)&&r!=null)switch(o){case"value":break;case"multiple":c=r;default:l.hasOwnProperty(o)||j(e,a,o,null,l,r)}for(u in l)if(o=l[u],r=t[u],l.hasOwnProperty(u)&&(o!=null||r!=null))switch(u){case"value":f=o;break;case"defaultValue":s=o;break;case"multiple":n=o;default:o!==r&&j(e,a,u,o,l,r)}a=s,t=n,l=c,f!=null?Bl(e,!!t,f,!1):!!l!=!!t&&(a!=null?Bl(e,!!t,a,!0):Bl(e,!!t,t?[]:"",!1));return;case"textarea":c=f=null;for(s in t)if(u=t[s],t.hasOwnProperty(s)&&u!=null&&!l.hasOwnProperty(s))switch(s){case"value":break;case"children":break;default:j(e,a,s,null,l,u)}for(n in l)if(u=l[n],o=t[n],l.hasOwnProperty(n)&&(u!=null||o!=null))switch(n){case"value":f=u;break;case"defaultValue":c=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(C(91));break;default:u!==o&&j(e,a,n,u,l,o)}Fc(e,f,c);return;case"option":for(var S in t)f=t[S],t.hasOwnProperty(S)&&f!=null&&!l.hasOwnProperty(S)&&(S==="selected"?e.selected=!1:j(e,a,S,null,l,f));for(r in l)f=l[r],c=t[r],l.hasOwnProperty(r)&&f!==c&&(f!=null||c!=null)&&(r==="selected"?e.selected=f&&typeof f!="function"&&typeof f!="symbol":j(e,a,r,f,l,c));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var b in t)f=t[b],t.hasOwnProperty(b)&&f!=null&&!l.hasOwnProperty(b)&&j(e,a,b,null,l,f);for(i in l)if(f=l[i],c=t[i],l.hasOwnProperty(i)&&f!==c&&(f!=null||c!=null))switch(i){case"children":case"dangerouslySetInnerHTML":if(f!=null)throw Error(C(137,a));break;default:j(e,a,i,f,l,c)}return;default:if(fi(a)){for(var A in t)f=t[A],t.hasOwnProperty(A)&&f!==void 0&&!l.hasOwnProperty(A)&&Zr(e,a,A,void 0,l,f);for(p in l)f=l[p],c=t[p],!l.hasOwnProperty(p)||f===c||f===void 0&&c===void 0||Zr(e,a,p,f,l,c);return}}for(var h in t)f=t[h],t.hasOwnProperty(h)&&f!=null&&!l.hasOwnProperty(h)&&j(e,a,h,null,l,f);for(g in l)f=l[g],c=t[g],!l.hasOwnProperty(g)||f===c||f==null&&c==null||j(e,a,g,f,l,c)}function uc(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function uS(){if(typeof performance.getEntriesByType=="function"){for(var e=0,a=0,t=performance.getEntriesByType("resource"),l=0;l<t.length;l++){var u=t[l],o=u.transferSize,n=u.initiatorType,s=u.duration;if(o&&s&&uc(n)){for(n=0,s=u.responseEnd,l+=1;l<t.length;l++){var r=t[l],i=r.startTime;if(i>s)break;var p=r.transferSize,g=r.initiatorType;p&&uc(g)&&(r=r.responseEnd,n+=p*(r<s?1:(s-i)/(r-i)))}if(--l,a+=8*(o+n)/(u.duration/1e3),e++,10<e)break}}if(0<e)return a/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Qr=null,Jr=null;function wn(e){return e.nodeType===9?e:e.ownerDocument}function oc(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Yp(e,a){if(e===0)switch(a){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&a==="foreignObject"?0:e}function Wr(e,a){return e==="textarea"||e==="noscript"||typeof a.children=="string"||typeof a.children=="number"||typeof a.children=="bigint"||typeof a.dangerouslySetInnerHTML=="object"&&a.dangerouslySetInnerHTML!==null&&a.dangerouslySetInnerHTML.__html!=null}var rr=null;function oS(){var e=window.event;return e&&e.type==="popstate"?e===rr?!1:(rr=e,!0):(rr=null,!1)}var Zp=typeof setTimeout=="function"?setTimeout:void 0,nS=typeof clearTimeout=="function"?clearTimeout:void 0,nc=typeof Promise=="function"?Promise:void 0,sS=typeof queueMicrotask=="function"?queueMicrotask:typeof nc<"u"?function(e){return nc.resolve(null).then(e).catch(rS)}:Zp;function rS(e){setTimeout(function(){throw e})}function wt(e){return e==="head"}function sc(e,a){var t=a,l=0;do{var u=t.nextSibling;if(e.removeChild(t),u&&u.nodeType===8)if(t=u.data,t==="/$"||t==="/&"){if(l===0){e.removeChild(u),Yl(a);return}l--}else if(t==="$"||t==="$?"||t==="$~"||t==="$!"||t==="&")l++;else if(t==="html")Hu(e.ownerDocument.documentElement);else if(t==="head"){t=e.ownerDocument.head,Hu(t);for(var o=t.firstChild;o;){var n=o.nextSibling,s=o.nodeName;o[ao]||s==="SCRIPT"||s==="STYLE"||s==="LINK"&&o.rel.toLowerCase()==="stylesheet"||t.removeChild(o),o=n}}else t==="body"&&Hu(e.ownerDocument.body);t=u}while(t);Yl(a)}function rc(e,a){var t=e;e=0;do{var l=t.nextSibling;if(t.nodeType===1?a?(t._stashedDisplay=t.style.display,t.style.display="none"):(t.style.display=t._stashedDisplay||"",t.getAttribute("style")===""&&t.removeAttribute("style")):t.nodeType===3&&(a?(t._stashedText=t.nodeValue,t.nodeValue=""):t.nodeValue=t._stashedText||""),l&&l.nodeType===8)if(t=l.data,t==="/$"){if(e===0)break;e--}else t!=="$"&&t!=="$?"&&t!=="$~"&&t!=="$!"||e++;t=l}while(t)}function $r(e){var a=e.firstChild;for(a&&a.nodeType===10&&(a=a.nextSibling);a;){var t=a;switch(a=a.nextSibling,t.nodeName){case"HTML":case"HEAD":case"BODY":$r(t),di(t);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(t.rel.toLowerCase()==="stylesheet")continue}e.removeChild(t)}}function iS(e,a,t,l){for(;e.nodeType===1;){var u=t;if(e.nodeName.toLowerCase()!==a.toLowerCase()){if(!l&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(l){if(!e[ao])switch(a){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(o=e.getAttribute("rel"),o==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(o!==u.rel||e.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||e.getAttribute("title")!==(u.title==null?null:u.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(o=e.getAttribute("src"),(o!==(u.src==null?null:u.src)||e.getAttribute("type")!==(u.type==null?null:u.type)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(a==="input"&&e.type==="hidden"){var o=u.name==null?null:""+u.name;if(u.type==="hidden"&&e.getAttribute("name")===o)return e}else return e;if(e=fa(e.nextSibling),e===null)break}return null}function dS(e,a,t){if(a==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=fa(e.nextSibling),e===null))return null;return e}function Qp(e,a){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!a||(e=fa(e.nextSibling),e===null))return null;return e}function ei(e){return e.data==="$?"||e.data==="$~"}function ai(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function fS(e,a){var t=e.ownerDocument;if(e.data==="$~")e._reactRetry=a;else if(e.data!=="$?"||t.readyState!=="loading")a();else{var l=function(){a(),t.removeEventListener("DOMContentLoaded",l)};t.addEventListener("DOMContentLoaded",l),e._reactRetry=l}}function fa(e){for(;e!=null;e=e.nextSibling){var a=e.nodeType;if(a===1||a===3)break;if(a===8){if(a=e.data,a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"||a==="F!"||a==="F")break;if(a==="/$"||a==="/&")return null}}return e}var ti=null;function ic(e){e=e.nextSibling;for(var a=0;e;){if(e.nodeType===8){var t=e.data;if(t==="/$"||t==="/&"){if(a===0)return fa(e.nextSibling);a--}else t!=="$"&&t!=="$!"&&t!=="$?"&&t!=="$~"&&t!=="&"||a++}e=e.nextSibling}return null}function dc(e){e=e.previousSibling;for(var a=0;e;){if(e.nodeType===8){var t=e.data;if(t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"){if(a===0)return e;a--}else t!=="/$"&&t!=="/&"||a++}e=e.previousSibling}return null}function Jp(e,a,t){switch(a=wn(t),e){case"html":if(e=a.documentElement,!e)throw Error(C(452));return e;case"head":if(e=a.head,!e)throw Error(C(453));return e;case"body":if(e=a.body,!e)throw Error(C(454));return e;default:throw Error(C(451))}}function Hu(e){for(var a=e.attributes;a.length;)e.removeAttributeNode(a[0]);di(e)}var ca=new Map,fc=new Set;function Mn(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var Qa=F.d;F.d={f:cS,r:mS,D:pS,C:gS,L:hS,m:xS,X:SS,S:LS,M:yS};function cS(){var e=Qa.f(),a=jn();return e||a}function mS(e){var a=Ql(e);a!==null&&a.tag===5&&a.type==="form"?Vm(a):Qa.r(e)}var eu=typeof document>"u"?null:document;function Wp(e,a,t){var l=eu;if(l&&typeof a=="string"&&a){var u=sa(a);u='link[rel="'+e+'"][href="'+u+'"]',typeof t=="string"&&(u+='[crossorigin="'+t+'"]'),fc.has(u)||(fc.add(u),e={rel:e,crossOrigin:t,href:a},l.querySelector(u)===null&&(a=l.createElement("link"),Ae(a,"link",e),ye(a),l.head.appendChild(a)))}}function pS(e){Qa.D(e),Wp("dns-prefetch",e,null)}function gS(e,a){Qa.C(e,a),Wp("preconnect",e,a)}function hS(e,a,t){Qa.L(e,a,t);var l=eu;if(l&&e&&a){var u='link[rel="preload"][as="'+sa(a)+'"]';a==="image"&&t&&t.imageSrcSet?(u+='[imagesrcset="'+sa(t.imageSrcSet)+'"]',typeof t.imageSizes=="string"&&(u+='[imagesizes="'+sa(t.imageSizes)+'"]')):u+='[href="'+sa(e)+'"]';var o=u;switch(a){case"style":o=Kl(e);break;case"script":o=au(e)}ca.has(o)||(e=te({rel:"preload",href:a==="image"&&t&&t.imageSrcSet?void 0:e,as:a},t),ca.set(o,e),l.querySelector(u)!==null||a==="style"&&l.querySelector(so(o))||a==="script"&&l.querySelector(ro(o))||(a=l.createElement("link"),Ae(a,"link",e),ye(a),l.head.appendChild(a)))}}function xS(e,a){Qa.m(e,a);var t=eu;if(t&&e){var l=a&&typeof a.as=="string"?a.as:"script",u='link[rel="modulepreload"][as="'+sa(l)+'"][href="'+sa(e)+'"]',o=u;switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=au(e)}if(!ca.has(o)&&(e=te({rel:"modulepreload",href:e},a),ca.set(o,e),t.querySelector(u)===null)){switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(t.querySelector(ro(o)))return}l=t.createElement("link"),Ae(l,"link",e),ye(l),t.head.appendChild(l)}}}function LS(e,a,t){Qa.S(e,a,t);var l=eu;if(l&&e){var u=Rl(l).hoistableStyles,o=Kl(e);a=a||"default";var n=u.get(o);if(!n){var s={loading:0,preload:null};if(n=l.querySelector(so(o)))s.loading=5;else{e=te({rel:"stylesheet",href:e,"data-precedence":a},t),(t=ca.get(o))&&Zi(e,t);var r=n=l.createElement("link");ye(r),Ae(r,"link",e),r._p=new Promise(function(i,p){r.onload=i,r.onerror=p}),r.addEventListener("load",function(){s.loading|=1}),r.addEventListener("error",function(){s.loading|=2}),s.loading|=4,en(n,a,l)}n={type:"stylesheet",instance:n,count:1,state:s},u.set(o,n)}}}function SS(e,a){Qa.X(e,a);var t=eu;if(t&&e){var l=Rl(t).hoistableScripts,u=au(e),o=l.get(u);o||(o=t.querySelector(ro(u)),o||(e=te({src:e,async:!0},a),(a=ca.get(u))&&Qi(e,a),o=t.createElement("script"),ye(o),Ae(o,"link",e),t.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},l.set(u,o))}}function yS(e,a){Qa.M(e,a);var t=eu;if(t&&e){var l=Rl(t).hoistableScripts,u=au(e),o=l.get(u);o||(o=t.querySelector(ro(u)),o||(e=te({src:e,async:!0,type:"module"},a),(a=ca.get(u))&&Qi(e,a),o=t.createElement("script"),ye(o),Ae(o,"link",e),t.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},l.set(u,o))}}function cc(e,a,t,l){var u=(u=pt.current)?Mn(u):null;if(!u)throw Error(C(446));switch(e){case"meta":case"title":return null;case"style":return typeof t.precedence=="string"&&typeof t.href=="string"?(a=Kl(t.href),t=Rl(u).hoistableStyles,l=t.get(a),l||(l={type:"style",instance:null,count:0,state:null},t.set(a,l)),l):{type:"void",instance:null,count:0,state:null};case"link":if(t.rel==="stylesheet"&&typeof t.href=="string"&&typeof t.precedence=="string"){e=Kl(t.href);var o=Rl(u).hoistableStyles,n=o.get(e);if(n||(u=u.ownerDocument||u,n={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},o.set(e,n),(o=u.querySelector(so(e)))&&!o._p&&(n.instance=o,n.state.loading=5),ca.has(e)||(t={rel:"preload",as:"style",href:t.href,crossOrigin:t.crossOrigin,integrity:t.integrity,media:t.media,hrefLang:t.hrefLang,referrerPolicy:t.referrerPolicy},ca.set(e,t),o||CS(u,e,t,n.state))),a&&l===null)throw Error(C(528,""));return n}if(a&&l!==null)throw Error(C(529,""));return null;case"script":return a=t.async,t=t.src,typeof t=="string"&&a&&typeof a!="function"&&typeof a!="symbol"?(a=au(t),t=Rl(u).hoistableScripts,l=t.get(a),l||(l={type:"script",instance:null,count:0,state:null},t.set(a,l)),l):{type:"void",instance:null,count:0,state:null};default:throw Error(C(444,e))}}function Kl(e){return'href="'+sa(e)+'"'}function so(e){return'link[rel="stylesheet"]['+e+"]"}function $p(e){return te({},e,{"data-precedence":e.precedence,precedence:null})}function CS(e,a,t,l){e.querySelector('link[rel="preload"][as="style"]['+a+"]")?l.loading=1:(a=e.createElement("link"),l.preload=a,a.addEventListener("load",function(){return l.loading|=1}),a.addEventListener("error",function(){return l.loading|=2}),Ae(a,"link",t),ye(a),e.head.appendChild(a))}function au(e){return'[src="'+sa(e)+'"]'}function ro(e){return"script[async]"+e}function mc(e,a,t){if(a.count++,a.instance===null)switch(a.type){case"style":var l=e.querySelector('style[data-href~="'+sa(t.href)+'"]');if(l)return a.instance=l,ye(l),l;var u=te({},t,{"data-href":t.href,"data-precedence":t.precedence,href:null,precedence:null});return l=(e.ownerDocument||e).createElement("style"),ye(l),Ae(l,"style",u),en(l,t.precedence,e),a.instance=l;case"stylesheet":u=Kl(t.href);var o=e.querySelector(so(u));if(o)return a.state.loading|=4,a.instance=o,ye(o),o;l=$p(t),(u=ca.get(u))&&Zi(l,u),o=(e.ownerDocument||e).createElement("link"),ye(o);var n=o;return n._p=new Promise(function(s,r){n.onload=s,n.onerror=r}),Ae(o,"link",l),a.state.loading|=4,en(o,t.precedence,e),a.instance=o;case"script":return o=au(t.src),(u=e.querySelector(ro(o)))?(a.instance=u,ye(u),u):(l=t,(u=ca.get(o))&&(l=te({},t),Qi(l,u)),e=e.ownerDocument||e,u=e.createElement("script"),ye(u),Ae(u,"link",l),e.head.appendChild(u),a.instance=u);case"void":return null;default:throw Error(C(443,a.type))}else a.type==="stylesheet"&&(a.state.loading&4)===0&&(l=a.instance,a.state.loading|=4,en(l,t.precedence,e));return a.instance}function en(e,a,t){for(var l=t.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=l.length?l[l.length-1]:null,o=u,n=0;n<l.length;n++){var s=l[n];if(s.dataset.precedence===a)o=s;else if(o!==u)break}o?o.parentNode.insertBefore(e,o.nextSibling):(a=t.nodeType===9?t.head:t,a.insertBefore(e,a.firstChild))}function Zi(e,a){e.crossOrigin==null&&(e.crossOrigin=a.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=a.referrerPolicy),e.title==null&&(e.title=a.title)}function Qi(e,a){e.crossOrigin==null&&(e.crossOrigin=a.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=a.referrerPolicy),e.integrity==null&&(e.integrity=a.integrity)}var an=null;function pc(e,a,t){if(an===null){var l=new Map,u=an=new Map;u.set(t,l)}else u=an,l=u.get(t),l||(l=new Map,u.set(t,l));if(l.has(e))return l;for(l.set(e,null),t=t.getElementsByTagName(e),u=0;u<t.length;u++){var o=t[u];if(!(o[ao]||o[ve]||e==="link"&&o.getAttribute("rel")==="stylesheet")&&o.namespaceURI!=="http://www.w3.org/2000/svg"){var n=o.getAttribute(a)||"";n=e+n;var s=l.get(n);s?s.push(o):l.set(n,[o])}}return l}function gc(e,a,t){e=e.ownerDocument||e,e.head.insertBefore(t,a==="title"?e.querySelector("head > title"):null)}function bS(e,a,t){if(t===1||a.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof a.precedence!="string"||typeof a.href!="string"||a.href==="")break;return!0;case"link":if(typeof a.rel!="string"||typeof a.href!="string"||a.href===""||a.onLoad||a.onError)break;return a.rel==="stylesheet"?(e=a.disabled,typeof a.precedence=="string"&&e==null):!0;case"script":if(a.async&&typeof a.async!="function"&&typeof a.async!="symbol"&&!a.onLoad&&!a.onError&&a.src&&typeof a.src=="string")return!0}return!1}function eg(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function vS(e,a,t,l){if(t.type==="stylesheet"&&(typeof l.media!="string"||matchMedia(l.media).matches!==!1)&&(t.state.loading&4)===0){if(t.instance===null){var u=Kl(l.href),o=a.querySelector(so(u));if(o){a=o._p,a!==null&&typeof a=="object"&&typeof a.then=="function"&&(e.count++,e=Dn.bind(e),a.then(e,e)),t.state.loading|=4,t.instance=o,ye(o);return}o=a.ownerDocument||a,l=$p(l),(u=ca.get(u))&&Zi(l,u),o=o.createElement("link"),ye(o);var n=o;n._p=new Promise(function(s,r){n.onload=s,n.onerror=r}),Ae(o,"link",l),t.instance=o}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(t,a),(a=t.state.preload)&&(t.state.loading&3)===0&&(e.count++,t=Dn.bind(e),a.addEventListener("load",t),a.addEventListener("error",t))}}var ir=0;function IS(e,a){return e.stylesheets&&e.count===0&&tn(e,e.stylesheets),0<e.count||0<e.imgCount?function(t){var l=setTimeout(function(){if(e.stylesheets&&tn(e,e.stylesheets),e.unsuspend){var o=e.unsuspend;e.unsuspend=null,o()}},6e4+a);0<e.imgBytes&&ir===0&&(ir=62500*uS());var u=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&tn(e,e.stylesheets),e.unsuspend)){var o=e.unsuspend;e.unsuspend=null,o()}},(e.imgBytes>ir?50:800)+a);return e.unsuspend=t,function(){e.unsuspend=null,clearTimeout(l),clearTimeout(u)}}:null}function Dn(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)tn(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var Rn=null;function tn(e,a){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Rn=new Map,a.forEach(kS,e),Rn=null,Dn.call(e))}function kS(e,a){if(!(a.state.loading&4)){var t=Rn.get(e);if(t)var l=t.get(null);else{t=new Map,Rn.set(e,t);for(var u=e.querySelectorAll("link[data-precedence],style[data-precedence]"),o=0;o<u.length;o++){var n=u[o];(n.nodeName==="LINK"||n.getAttribute("media")!=="not all")&&(t.set(n.dataset.precedence,n),l=n)}l&&t.set(null,l)}u=a.instance,n=u.getAttribute("data-precedence"),o=t.get(n)||l,o===l&&t.set(null,u),t.set(n,u),this.count++,l=Dn.bind(this),u.addEventListener("load",l),u.addEventListener("error",l),o?o.parentNode.insertBefore(u,o.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(u,e.firstChild)),a.state.loading|=4}}var Yu={$$typeof:_a,Provider:null,Consumer:null,_currentValue:Vt,_currentValue2:Vt,_threadCount:0};function AS(e,a,t,l,u,o,n,s,r){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=qs(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=qs(0),this.hiddenUpdates=qs(null),this.identifierPrefix=l,this.onUncaughtError=u,this.onCaughtError=o,this.onRecoverableError=n,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=r,this.incompleteTransitions=new Map}function ag(e,a,t,l,u,o,n,s,r,i,p,g){return e=new AS(e,a,t,n,r,i,p,g,s),a=1,o===!0&&(a|=24),o=je(3,null,null,a),e.current=o,o.stateNode=e,a=bi(),a.refCount++,e.pooledCache=a,a.refCount++,o.memoizedState={element:l,isDehydrated:t,cache:a},ki(o),e}function tg(e){return e?(e=Tl,e):Tl}function lg(e,a,t,l,u,o){u=tg(u),l.context===null?l.context=u:l.pendingContext=u,l=ht(a),l.payload={element:t},o=o===void 0?null:o,o!==null&&(l.callback=o),t=xt(e,l,a),t!==null&&(_e(t,e,a),wu(t,e,a))}function hc(e,a){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var t=e.retryLane;e.retryLane=t!==0&&t<a?t:a}}function Ji(e,a){hc(e,a),(e=e.alternate)&&hc(e,a)}function ug(e){if(e.tag===13||e.tag===31){var a=ll(e,67108864);a!==null&&_e(a,e,67108864),Ji(e,67108864)}}function xc(e){if(e.tag===13||e.tag===31){var a=Je();a=ri(a);var t=ll(e,a);t!==null&&_e(t,e,a),Ji(e,a)}}var Bn=!0;function TS(e,a,t,l){var u=B.T;B.T=null;var o=F.p;try{F.p=2,Wi(e,a,t,l)}finally{F.p=o,B.T=u}}function wS(e,a,t,l){var u=B.T;B.T=null;var o=F.p;try{F.p=8,Wi(e,a,t,l)}finally{F.p=o,B.T=u}}function Wi(e,a,t,l){if(Bn){var u=li(l);if(u===null)sr(e,a,l,En,t),Lc(e,l);else if(DS(u,e,a,t,l))l.stopPropagation();else if(Lc(e,l),a&4&&-1<MS.indexOf(e)){for(;u!==null;){var o=Ql(u);if(o!==null)switch(o.tag){case 3:if(o=o.stateNode,o.current.memoizedState.isDehydrated){var n=Pt(o.pendingLanes);if(n!==0){var s=o;for(s.pendingLanes|=2,s.entangledLanes|=2;n;){var r=1<<31-Qe(n);s.entanglements[1]|=r,n&=~r}Ma(o),(P&6)===0&&(bn=Ye()+500,no(0,!1))}}break;case 31:case 13:s=ll(o,2),s!==null&&_e(s,o,2),jn(),Ji(o,2)}if(o=li(l),o===null&&sr(e,a,l,En,t),o===u)break;u=o}u!==null&&l.stopPropagation()}else sr(e,a,l,null,t)}}function li(e){return e=ci(e),$i(e)}var En=null;function $i(e){if(En=null,e=Cl(e),e!==null){var a=Ju(e);if(a===null)e=null;else{var t=a.tag;if(t===13){if(e=Ic(a),e!==null)return e;e=null}else if(t===31){if(e=kc(a),e!==null)return e;e=null}else if(t===3){if(a.stateNode.current.memoizedState.isDehydrated)return a.tag===3?a.stateNode.containerInfo:null;e=null}else a!==e&&(e=null)}}return En=e,null}function og(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(hx()){case Mc:return 2;case Dc:return 8;case sn:case xx:return 32;case Rc:return 268435456;default:return 32}default:return 32}}var ui=!1,yt=null,Ct=null,bt=null,Zu=new Map,Qu=new Map,rt=[],MS="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Lc(e,a){switch(e){case"focusin":case"focusout":yt=null;break;case"dragenter":case"dragleave":Ct=null;break;case"mouseover":case"mouseout":bt=null;break;case"pointerover":case"pointerout":Zu.delete(a.pointerId);break;case"gotpointercapture":case"lostpointercapture":Qu.delete(a.pointerId)}}function xu(e,a,t,l,u,o){return e===null||e.nativeEvent!==o?(e={blockedOn:a,domEventName:t,eventSystemFlags:l,nativeEvent:o,targetContainers:[u]},a!==null&&(a=Ql(a),a!==null&&ug(a)),e):(e.eventSystemFlags|=l,a=e.targetContainers,u!==null&&a.indexOf(u)===-1&&a.push(u),e)}function DS(e,a,t,l,u){switch(a){case"focusin":return yt=xu(yt,e,a,t,l,u),!0;case"dragenter":return Ct=xu(Ct,e,a,t,l,u),!0;case"mouseover":return bt=xu(bt,e,a,t,l,u),!0;case"pointerover":var o=u.pointerId;return Zu.set(o,xu(Zu.get(o)||null,e,a,t,l,u)),!0;case"gotpointercapture":return o=u.pointerId,Qu.set(o,xu(Qu.get(o)||null,e,a,t,l,u)),!0}return!1}function ng(e){var a=Cl(e.target);if(a!==null){var t=Ju(a);if(t!==null){if(a=t.tag,a===13){if(a=Ic(t),a!==null){e.blockedOn=a,ef(e.priority,function(){xc(t)});return}}else if(a===31){if(a=kc(t),a!==null){e.blockedOn=a,ef(e.priority,function(){xc(t)});return}}else if(a===3&&t.stateNode.current.memoizedState.isDehydrated){e.blockedOn=t.tag===3?t.stateNode.containerInfo:null;return}}}e.blockedOn=null}function ln(e){if(e.blockedOn!==null)return!1;for(var a=e.targetContainers;0<a.length;){var t=li(e.nativeEvent);if(t===null){t=e.nativeEvent;var l=new t.constructor(t.type,t);br=l,t.target.dispatchEvent(l),br=null}else return a=Ql(t),a!==null&&ug(a),e.blockedOn=t,!1;a.shift()}return!0}function Sc(e,a,t){ln(e)&&t.delete(a)}function RS(){ui=!1,yt!==null&&ln(yt)&&(yt=null),Ct!==null&&ln(Ct)&&(Ct=null),bt!==null&&ln(bt)&&(bt=null),Zu.forEach(Sc),Qu.forEach(Sc)}function Po(e,a){e.blockedOn===a&&(e.blockedOn=null,ui||(ui=!0,ge.unstable_scheduleCallback(ge.unstable_NormalPriority,RS)))}var Fo=null;function yc(e){Fo!==e&&(Fo=e,ge.unstable_scheduleCallback(ge.unstable_NormalPriority,function(){Fo===e&&(Fo=null);for(var a=0;a<e.length;a+=3){var t=e[a],l=e[a+1],u=e[a+2];if(typeof l!="function"){if($i(l||t)===null)continue;break}var o=Ql(t);o!==null&&(e.splice(a,3),a-=3,zr(o,{pending:!0,data:u,method:t.method,action:l},l,u))}}))}function Yl(e){function a(r){return Po(r,e)}yt!==null&&Po(yt,e),Ct!==null&&Po(Ct,e),bt!==null&&Po(bt,e),Zu.forEach(a),Qu.forEach(a);for(var t=0;t<rt.length;t++){var l=rt[t];l.blockedOn===e&&(l.blockedOn=null)}for(;0<rt.length&&(t=rt[0],t.blockedOn===null);)ng(t),t.blockedOn===null&&rt.shift();if(t=(e.ownerDocument||e).$$reactFormReplay,t!=null)for(l=0;l<t.length;l+=3){var u=t[l],o=t[l+1],n=u[Ne]||null;if(typeof o=="function")n||yc(t);else if(n){var s=null;if(o&&o.hasAttribute("formAction")){if(u=o,n=o[Ne]||null)s=n.formAction;else if($i(u)!==null)continue}else s=n.action;typeof s=="function"?t[l+1]=s:(t.splice(l,3),l-=3),yc(t)}}}function sg(){function e(o){o.canIntercept&&o.info==="react-transition"&&o.intercept({handler:function(){return new Promise(function(n){return u=n})},focusReset:"manual",scroll:"manual"})}function a(){u!==null&&(u(),u=null),l||setTimeout(t,20)}function t(){if(!l&&!navigation.transition){var o=navigation.currentEntry;o&&o.url!=null&&navigation.navigate(o.url,{state:o.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var l=!1,u=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",a),navigation.addEventListener("navigateerror",a),setTimeout(t,100),function(){l=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",a),navigation.removeEventListener("navigateerror",a),u!==null&&(u(),u=null)}}}function ed(e){this._internalRoot=e}Zn.prototype.render=ed.prototype.render=function(e){var a=this._internalRoot;if(a===null)throw Error(C(409));var t=a.current,l=Je();lg(t,l,e,a,null,null)};Zn.prototype.unmount=ed.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var a=e.containerInfo;lg(e.current,2,null,e,null,null),jn(),a[Zl]=null}};function Zn(e){this._internalRoot=e}Zn.prototype.unstable_scheduleHydration=function(e){if(e){var a=Hc();e={blockedOn:null,target:e,priority:a};for(var t=0;t<rt.length&&a!==0&&a<rt[t].priority;t++);rt.splice(t,0,e),t===0&&ng(e)}};var Cc=bc.version;if(Cc!=="19.2.8")throw Error(C(527,Cc,"19.2.8"));F.findDOMNode=function(e){var a=e._reactInternals;if(a===void 0)throw typeof e.render=="function"?Error(C(188)):(e=Object.keys(e).join(","),Error(C(268,e)));return e=ix(a),e=e!==null?Ac(e):null,e=e===null?null:e.stateNode,e};var BS={bundleType:0,version:"19.2.8",rendererPackageName:"react-dom",currentDispatcherRef:B,reconcilerVersion:"19.2.8"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(Lu=__REACT_DEVTOOLS_GLOBAL_HOOK__,!Lu.isDisabled&&Lu.supportsFiber))try{Wu=Lu.inject(BS),Ze=Lu}catch{}var Lu;Qn.createRoot=function(e,a){if(!vc(e))throw Error(C(299));var t=!1,l="",u=Wm,o=$m,n=ep;return a!=null&&(a.unstable_strictMode===!0&&(t=!0),a.identifierPrefix!==void 0&&(l=a.identifierPrefix),a.onUncaughtError!==void 0&&(u=a.onUncaughtError),a.onCaughtError!==void 0&&(o=a.onCaughtError),a.onRecoverableError!==void 0&&(n=a.onRecoverableError)),a=ag(e,1,!1,null,null,t,l,null,u,o,n,sg),e[Zl]=a.current,Yi(e),new ed(a)};Qn.hydrateRoot=function(e,a,t){if(!vc(e))throw Error(C(299));var l=!1,u="",o=Wm,n=$m,s=ep,r=null;return t!=null&&(t.unstable_strictMode===!0&&(l=!0),t.identifierPrefix!==void 0&&(u=t.identifierPrefix),t.onUncaughtError!==void 0&&(o=t.onUncaughtError),t.onCaughtError!==void 0&&(n=t.onCaughtError),t.onRecoverableError!==void 0&&(s=t.onRecoverableError),t.formState!==void 0&&(r=t.formState)),a=ag(e,1,!0,a,t??null,l,u,r,o,n,s,sg),a.context=tg(null),t=a.current,l=Je(),l=ri(l),u=ht(l),u.callback=null,xt(t,u,l),t=l,a.current.lanes=t,eo(a,t),Ma(a),e[Zl]=a.current,Yi(e),new Zn(a)};Qn.version="19.2.8"});var fg=ba((qC,dg)=>{"use strict";function ig(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(ig)}catch(e){console.error(e)}}ig(),dg.exports=rg()});var Wg=ba(ls=>{"use strict";var jy=Symbol.for("react.transitional.element"),Ky=Symbol.for("react.fragment");function Jg(e,a,t){var l=null;if(t!==void 0&&(l=""+t),a.key!==void 0&&(l=""+a.key),"key"in a){t={};for(var u in a)u!=="key"&&(t[u]=a[u])}else t=a;return a=t.ref,{$$typeof:jy,type:e,key:l,ref:a!==void 0?a:null,props:t}}ls.Fragment=Ky;ls.jsx=Jg;ls.jsxs=Jg});var G=ba((KC,$g)=>{"use strict";$g.exports=Wg()});function nC(){return rs||(rs=new CSSStyleSheet,rs.replaceSync(oC)),rs}function sC(){if(yh||document.getElementById("ext-pjs-font"))return;yh=!0;let e=document.createElement("link");e.id="ext-pjs-font",e.rel="stylesheet",e.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(e)}function is(e,a="open"){let t=e.attachShadow({mode:a});return t.adoptedStyleSheets=[nC()],sC(),t}var uC,oC,rs,yh,dd=So(()=>{"use strict";uC='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',oC=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${uC};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,rs=null;yh=!1});var rC,fd,Ch=So(()=>{"use strict";dd();rC=`
  :host { display: none; }
  :host([open]) { display: block; }
  .overlay {
    position: fixed;
    inset: 0;
    z-index: 2147483000;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(15, 23, 42, 0.55);
    backdrop-filter: blur(2px);
    animation: ext-fade var(--ext-duration-normal) var(--ext-ease);
    padding: var(--ext-space-6);
  }
  .modal {
    width: 520px;
    max-width: 100%;
    background: var(--ext-surface);
    border-radius: var(--ext-radius-lg);
    box-shadow: var(--ext-shadow-lg);
    overflow: hidden;
    animation: ext-slide-up var(--ext-duration-normal) var(--ext-ease);
  }
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--ext-space-4);
    padding: var(--ext-space-5) var(--ext-space-6);
    border-bottom: 1px solid var(--ext-border);
  }
  .title {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-lg);
    font-weight: 700;
    color: var(--ext-text);
    margin: 0;
  }
  .close {
    appearance: none;
    border: none;
    background: var(--ext-surface-2);
    color: var(--ext-text-secondary);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    font-size: 22px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color var(--ext-duration-fast) var(--ext-ease), color var(--ext-duration-fast) var(--ext-ease);
  }
  .close:hover { background: var(--ext-danger-soft); color: var(--ext-danger); }
  .close:focus-visible { outline: none; box-shadow: var(--ext-ring); }

  .body {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text-secondary);
    padding: var(--ext-space-6);
  }
  .footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--ext-space-3);
    padding: 0 var(--ext-space-6) var(--ext-space-6);
  }
  /* tombol utama di dalam modal memakai komponen ext-btn \u2014 styling via atribut host */
  ::slotted(*) { font-family: var(--ext-font-family); }

  /* variant accent line */
  :host([variant='danger']) .header { box-shadow: inset 4px 0 0 var(--ext-danger); }
  :host([variant='success']) .header { box-shadow: inset 4px 0 0 var(--ext-success); }
  :host([variant='info']) .header { box-shadow: inset 4px 0 0 var(--ext-info); }
  :host([variant='warning']) .header { box-shadow: inset 4px 0 0 var(--ext-warning); }

  @keyframes ext-fade { from { opacity: 0; } }
  @keyframes ext-slide-up {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
  }
`,fd=class extends HTMLElement{constructor(){super();this.handleKey=t=>{t.key==="Escape"&&this.hasAttribute("open")&&this.cancel()};this.root=is(this),this.root.innerHTML=`
      <style>${rC}</style>
      <div class="overlay">
        <div class="modal" role="dialog" aria-modal="true">
          <div class="header">
            <h3 class="title"><slot name="title"></slot></h3>
            <button class="close" part="close" aria-label="Tutup">&times;</button>
          </div>
          <div class="body"><slot></slot></div>
          <div class="footer">
            <slot name="footer"></slot>
          </div>
        </div>
      </div>
    `}connectedCallback(){let t=this.root.querySelector(".overlay");this.root.querySelector(".close").addEventListener("click",()=>this.cancel()),t.addEventListener("click",u=>{u.target===t&&this.cancel()}),document.addEventListener("keydown",this.handleKey)}disconnectedCallback(){document.removeEventListener("keydown",this.handleKey)}get titleSlot(){return this.querySelector('[slot="title"]')}get footerSlot(){return this.querySelector('[slot="footer"]')}open(){this.setAttribute("open","")}close(){this.removeAttribute("open")}cancel(){this.dispatchEvent(new CustomEvent("ext-cancel")),this.close()}ok(){this.dispatchEvent(new CustomEvent("ext-ok"))}};customElements.get("ext-modal")||customElements.define("ext-modal",fd)});var iC,cd,bh=So(()=>{"use strict";dd();iC=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,cd=class extends HTMLElement{constructor(){super();let a=is(this);a.innerHTML=`
      <style>${iC}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=a.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",a=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){a.stopPropagation(),a.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(a){(a==="disabled"||a==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}};customElements.get("ext-btn")||customElements.define("ext-btn",cd)});var vh={};Nh(vh,{confirmExt:()=>dC});function dC(e){return new Promise(a=>{let t=document.createElement("ext-modal");t.setAttribute("variant",e.variant??"warning"),e.okLabel&&t.setAttribute("ok-label",e.okLabel),e.cancelLabel&&t.setAttribute("cancel-label",e.cancelLabel),e.hideCancel&&t.setAttribute("hide-cancel",""),t.innerHTML=`<h3 slot="title"></h3><div class="ext-confirm-body"></div><div slot="footer">
         <ext-btn data-ext-confirm-cancel variant="secondary"></ext-btn>
         <ext-btn data-ext-confirm-ok></ext-btn>
       </div>`;let l=t.querySelector('[slot="title"]');l.textContent=e.title;let u=t.querySelector(".ext-confirm-body");if(e.icon){let s=document.createElement("div");s.className="ext-confirm-icon",s.textContent=e.icon,u.appendChild(s)}e.message&&e.message.split(`
`).forEach((r,i)=>{i>0&&u.appendChild(document.createElement("br")),u.appendChild(document.createTextNode(r))}),t.querySelector("[data-ext-confirm-ok]").textContent=e.okLabel??"Lanjut";let o=t.querySelector("[data-ext-confirm-ok]");o.setAttribute("variant",e.variant==="danger"?"danger":"primary"),e.hideCancel?t.querySelector("[data-ext-confirm-cancel]")?.remove():t.querySelector("[data-ext-confirm-cancel]").textContent=e.cancelLabel??"Batal",o.addEventListener("click",()=>t.ok()),e.hideCancel||t.querySelector("[data-ext-confirm-cancel]").addEventListener("click",()=>t.cancel());let n=s=>{t.remove(),a(s)};t.addEventListener("ext-ok",()=>n(!0)),t.addEventListener("ext-cancel",()=>n(!1)),document.body.appendChild(t),t.open()})}var Ih=So(()=>{"use strict";Ch();bh()});var AC={},Eh=q(fg(),1);var ea=q(Ge(),1);function Ja(e){let a=e.trim();return a===""||/^[-–—]+$/.test(a)}var ES="http://dev.rsudkotajambi.id/rs",OS="ext-farmasi-app-base";var qS=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],HS=".rsudkotajambi.id";var US=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],cg="Fitur nonaktif: server Reports menggunakan HTTP (belum mendukung HTTPS)";function Jn(e){try{let a=new URL(e??Wn());if(a.protocol==="https:")return null;let t=a.hostname.toLowerCase();return US.includes(t)?null:cg}catch{return cg}}function zS(e){try{let a=new URL(e);if(a.protocol!=="http:"&&a.protocol!=="https:")return!1;let t=a.hostname.toLowerCase();return qS.includes(t)?!0:t.endsWith(HS)}catch{return!1}}function Wn(){try{let e=localStorage.getItem(OS);if(e&&zS(e))return e.replace(/\/+$/,"")}catch{}return ES}async function _S(e,a,t=fetch){let l=new AbortController,u=globalThis.setTimeout(()=>l.abort(),25e3);try{return await t(e,{...a,signal:l.signal})}finally{globalThis.clearTimeout(u)}}async function NS(e,a=fetch){try{let t=Wn(),l=Jn(t);if(l)return console.warn("[casemixApi]",l,"\u2014 baca pusat dilewati:",e),null;let u=await _S(t+e,{cache:"no-store",credentials:"omit",headers:{Accept:"application/json"}},a);return u.ok?await u.json():null}catch{return null}}async function mg(e,a,t=fetch){if(!e)return[];let l="/api/reports/resume-history?id_visit="+encodeURIComponent(e)+(a?"&tipe="+a:""),u=await NS(l,t);return!u?.ok||!Array.isArray(u.data)?[]:u.data}function PS(){try{let e=globalThis.crypto;if(e&&typeof e.randomUUID=="function")return e.randomUUID()}catch{}return`${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`}function ol(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}var yg="ext_rv_history_",FS=yg,Cg="ext_rv_lastform_",GS="ext_migrated_rv_",bg=50;function td(e,a){return`${yg}${a==="ranap"?"ri":"rj"}_${e||"unknown"}`}function vg(e,a){return`${Cg}${a==="ranap"?"ri":"rj"}_${e||"unknown"}`}function $n(e,a){if(!e)return null;try{let t=e.getItem(a);return t?JSON.parse(t):null}catch{return null}}function ld(e,a,t){if(e)try{e.setItem(a,JSON.stringify(t))}catch{}}function VS(e,a){return JSON.stringify(e??null)===JSON.stringify(a??null)}function Ig(e,a){let t={};return Object.keys(e).forEach(l=>t[l]=!0),Object.keys(a).forEach(l=>t[l]=!0),Object.keys(t).filter(l=>!VS(e[l],a[l]))}function pg(e){let a=e===void 0?"-":JSON.stringify(e);return a.length>60?a.slice(0,60)+"\u2026":a}function ad(e,a,t=ol()){let l=$n(t,td(e,a)),u=Array.isArray(l)?l:[];if(a==="ranap"){let o=$n(t,FS+e);if(Array.isArray(o)&&o.length>0&&u.length===0){let n=o.map(s=>({...s,tipe:"ranap"}));return ud(n,e,"ranap",t),n}}return u}function ud(e,a,t,l=ol()){ld(l,td(a,t),e.slice(-bg))}function kg(e,a,t=ol()){let l=$n(t,vg(e,a));return l||(a==="ranap"?$n(t,Cg+e):null)}function gg(e,a,t,l=ol()){ld(l,vg(a,t),e)}function XS(){try{let e=document.getElementById("userpanel");if(e){let o="",n="";if(e.querySelectorAll(".subgroup").forEach(i=>{let p=(i.querySelector(".subtitle")?.textContent||"").trim().toLowerCase(),g=(i.querySelector(".subcontent")?.textContent||"").trim();p==="username"&&g&&(o=g),p==="role"&&g&&(n=g)}),o)return`${o}${n?` (${n})`:""}`;let r=(e.querySelector("a")?.textContent||"").trim();if(r&&r!=="Petugas Rumah Sakit")return r}let t=(document.querySelector("#petugas, .petugas, .username, #username, .user-name")?.textContent||"").trim();if(t)return t.slice(0,80);let l=document.querySelector('input[name="dokter"], #dokter, input[name="nama_dokter"]')?.value?.trim();if(l)return l.slice(0,80);let u=document.querySelector('input[name="id_user"], #id_user')?.value?.trim();if(u)return`User #${u}`}catch{}return"petugas"}var jS="/api/reports/resume-history";function KS(){return Wn()}function YS(e){return GS+e}function ZS(e,a){if(!e)return 0;try{let t=e.getItem(a);if(t===null)return 0;let l=Number(JSON.parse(t));return Number.isFinite(l)?l:0}catch{return 0}}function QS(e,a,t,l){if(!(!e||!a))try{let u=YS(td(a,t));l>ZS(e,u)&&ld(e,u,l)}catch{}}function JS(e,a,t=fetch,l=ol(),u=e.tipe){let o={client_id:e.client_id??null,id_visit:a,id_resume:e.id_resume,aksi:e.aksi,tipe:e.tipe,waktu:new Date(e.at).toISOString(),user:e.user,before:e.before,after:e.after,changed:e.changed},n=async()=>{try{let s=KS(),r=Jn(s);return r?(console.warn("[resumeHistory]",r,"\u2014 kirim resume dilewati:",a),!1):(await t(s+jS,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(o),keepalive:!0,credentials:"omit"})).ok?(QS(l,a,u,e.at),!0):!1}catch{return!1}};try{return n()}catch{return Promise.resolve(!1)}}var hg=null,xg=0;function Ag(e){if(!e.idVisit)return null;let a=e.now??Date.now(),t=e.store??ol();gg(e.after,e.idVisit,e.tipe,t);let l=JSON.stringify([e.idVisit,e.aksi,e.after]);if(hg===l&&a-xg<5e3)return null;hg=l,xg=a;let u={at:a,aksi:e.aksi,id_resume:e.idResume??"",user:e.user??XS(),tipe:e.tipe,before:e.before??{},after:e.after,changed:Ig(e.before??{},e.after),client_id:PS()},o=ad(e.idVisit,e.tipe,t);o.push(u),ud(o,e.idVisit,e.tipe,t),gg(e.after,e.idVisit,e.tipe,t);try{JS(u,e.idVisit,e.fetcher??fetch,t,e.tipe)}catch{}return u}function WS(e){if(e!=null){if(typeof e=="string")return e;if(typeof e=="number"||typeof e=="boolean")return String(e);if(Array.isArray(e))return e.map(a=>{if(typeof a=="string")return a;try{return JSON.stringify(a)??""}catch{return""}});try{return JSON.stringify(e)??""}catch{return""}}}function Lg(e){let a={};if(!e||typeof e!="object"||Array.isArray(e))return a;for(let t of Object.keys(e)){let l=WS(e[t]);l!==void 0&&(a[t]=l)}return a}function $S(e,a){try{if(!e||typeof e!="object")return null;let t=e.waktu?Date.parse(e.waktu):NaN;if(!Number.isFinite(t))return null;let l=Lg(e.after),u=Lg(e.before),o=e.tipe==="rajal"?"rajal":e.tipe==="ranap"?"ranap":a,n=Array.isArray(e.changed)?e.changed.filter(r=>typeof r=="string"):Ig(u,l),s=typeof e.client_id=="string"&&e.client_id?e.client_id:void 0;return{at:t,aksi:e.aksi==="buat"?"buat":"ubah",id_resume:typeof e.id_resume=="string"?e.id_resume:"",user:typeof e.user=="string"&&e.user?e.user:"petugas",tipe:o,before:u,after:l,changed:n,...s?{client_id:s}:{}}}catch{return null}}function Sg(e){if(e.client_id)return"cid:"+e.client_id;try{return"h:"+e.at+"|"+e.user+"|"+e.aksi+"|"+JSON.stringify(e.after)}catch{return"h:"+e.at+"|"+e.user+"|"+e.aksi}}function ey(e,a){let t=new Set(e.map(Sg)),l=e.slice();for(let u of a){let o=Sg(u);t.has(o)||(t.add(o),l.push(u))}return l.sort((u,o)=>u.at-o.at),l.slice(-bg)}var ay="'Roboto','Segoe UI',system-ui,-apple-system,Arial,sans-serif";function Tg(e){try{document.querySelector("#ext-rv-history-overlay")?.remove()}catch{}let a=e.store??ol(),t=ad(e.idVisit,e.tipe,a).slice().reverse(),l=e.zIndex??99998,u=document.createElement("div");u.id="ext-rv-history-overlay",u.style.cssText=`position:fixed;inset:0;z-index:${l};background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:24px;`,u.addEventListener("click",function(g){g.target===u&&u.remove()});let o=document.createElement("div");o.style.cssText="background:#fff;border-radius:12px;max-width:680px;width:100%;max-height:82vh;display:flex;flex-direction:column;overflow:hidden;font-size:16px!important;line-height:1.6!important;color:#1c2530;font-family:"+ay+"!important;",u.appendChild(o);let n=document.createElement("div");n.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #d0d5dd;font-weight:700;";let s=document.createElement("span");s.textContent=`${e.title??"Riwayat Resume"} (${t.length})`,n.appendChild(s);let r=document.createElement("button");r.type="button",r.textContent="\xD7",r.style.cssText="border:none;background:#f8fafc;width:32px;height:32px;border-radius:50%;font-family:inherit!important;font-size:16px!important;line-height:1!important;cursor:pointer;",r.onclick=function(){u.remove()},n.appendChild(r),o.appendChild(n);let i=document.createElement("div");i.style.cssText="padding:14px 18px;overflow-y:auto;",o.appendChild(i);let p=g=>{if(t=g,s.textContent=`${e.title??"Riwayat Resume"} (${t.length})`,i.replaceChildren(),!t.length){i.textContent="Belum ada riwayat untuk kunjungan ini. Riwayat tercatat otomatis setiap kali Simpan ditekan.";return}t.forEach(function(f,c){let S=t.length-c,b=document.createElement("div");b.style.cssText="border:1px solid #d0d5dd;border-radius:8px;padding:10px 12px;margin-bottom:10px;";let A=document.createElement("div");A.style.fontWeight="600";let h=f.user?` \u2014 oleh ${f.user}`:"";A.textContent=`#${S} \u2014 ${new Date(f.at).toLocaleString("id-ID")} \u2014 ${f.aksi==="buat"?"Buat baru":"Ubah"}${h} \u2014 ${f.changed.length} field berubah`,b.appendChild(A);let d=document.createElement("div");d.style.cssText="display:none;margin-top:8px;background:#f8fafc;border-radius:6px;padding:8px 10px;font-size:13px;line-height:1.6;max-height:180px;overflow-y:auto;white-space:pre-wrap;",f.changed.length?d.textContent=f.changed.map(function(k){return k+": "+pg(f.before[k])+" \u2192 "+pg(f.after[k])}).join(`
`):d.textContent="Tidak ada perbedaan field.",b.appendChild(d);let m=document.createElement("div");m.style.cssText="margin-top:8px;display:flex;gap:8px;";let x=document.createElement("button");x.type="button",x.textContent="Lihat",x.style.cssText="border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",x.onclick=function(){d.style.display=d.style.display==="none"?"block":"none"},m.appendChild(x);let L=document.createElement("button");L.type="button",L.textContent="Salin ke Form",L.style.cssText="background:#00875a;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",L.onclick=function(){try{e.onApply(f.after),u.remove()}catch{}},m.appendChild(L),b.appendChild(m),i.appendChild(b)})};p(t);try{document.body.appendChild(u)}catch{}if(e.idVisit){let g=Jn();if(g)try{let f=document.createElement("div");f.textContent=g+" \u2014 riwayat hanya dari PC ini.",f.style.cssText="margin-top:10px;padding:8px 10px;background:#fef3c7;color:#92400e;border-radius:6px;font-size:13px;line-height:1.5;",i.appendChild(f)}catch{}else try{mg(e.idVisit,e.tipe).then(f=>{try{if(!f.length||!u.isConnected)return;let c=[];for(let A of f){let h=$S(A,e.tipe);h&&c.push(h)}if(!c.length)return;let S=ad(e.idVisit,e.tipe,a),b=ey(S,c);if(b.length===S.length)return;ud(b,e.idVisit,e.tipe,a),p(b.slice().reverse());try{document.dispatchEvent(new CustomEvent("ext-rv-history-merged",{detail:{idVisit:e.idVisit,tipe:e.tipe,count:b.length}}))}catch{}}catch{}})}catch{}}}function Me(e,a){let t=e[a];return Array.isArray(t)?t:t===void 0?[]:[t]}function Fe(e,a){let t=e[a];return typeof t=="string"?t:Array.isArray(t)?t[0]??"":""}function wg(e){let a=e.clinicalNotes,t=e.vitalSigns,l={anamnesa:a.anamnesa,pemeriksaan_fisik:a.pemeriksaan_fisik,catatan:a.catatan,tindakan:a.tindakan,terapi_pengobatan:a.terapi_pengobatan,tensi:t.tensi,nadi:t.nadi,suhu:t.suhu,nafas:t.nafas,tinggi:t.tinggi,berat:t.berat},u=a;for(let o of["jenis_kasus","status_kasus","tindak_lanjut"])u[o]&&(l[o]=u[o]);return l["kode10[]"]=e.diagnosa.map(o=>o.kode10),l["idicd[]"]=e.diagnosa.map(o=>o.idicd),l["nama[]"]=e.diagnosa.map(o=>o.namaDiagnosa),l["kasus_diagnosa[]"]=e.diagnosa.map(o=>o.kasus),l["komplikasi[]"]=e.diagnosa.map(o=>o.komplikasi),l["kode9[]"]=e.tindakan.map(o=>o.kode9),l["idicdTindakan[]"]=e.tindakan.map(o=>o.idicdTindakan),l["namaTindakan[]"]=e.tindakan.map(o=>o.namaTindakan),l["komorbid[]"]=e.tindakan.map(o=>o.komorbid),l["kategoriProsedur[]"]=e.tindakan.map(o=>o.kategoriProsedur),l}function Mg(e,a){let t=Math.max(Me(e,"kode10[]").length,Me(e,"idicd[]").length,Me(e,"nama[]").length),l=[];for(let n=0;n<t;n++){let s=Me(e,"idicd[]")[n]??"",r=Me(e,"kode10[]")[n]??"",i=Me(e,"nama[]")[n]??"";!s&&!r&&!i||l.push({idicd:s,kode10:r,namaDiagnosa:i,kasus:Me(e,"kasus_diagnosa[]")[n]??"",komplikasi:Me(e,"komplikasi[]")[n]??""})}let u=Math.max(Me(e,"kode9[]").length,Me(e,"idicdTindakan[]").length,Me(e,"namaTindakan[]").length),o=[];for(let n=0;n<u;n++){let s=Me(e,"idicdTindakan[]")[n]??"",r=Me(e,"kode9[]")[n]??"",i=Me(e,"namaTindakan[]")[n]??"";!s&&!r&&!i||o.push({idicdTindakan:s,kode9:r,namaTindakan:i,komorbid:Me(e,"komorbid[]")[n]??"",kategoriProsedur:Me(e,"kategoriProsedur[]")[n]??"",snomedProsedur:"",codeProsedur:""})}return{patientInfo:a.patientInfo,clinicalNotes:{anamnesa:Fe(e,"anamnesa"),pemeriksaan_fisik:Fe(e,"pemeriksaan_fisik"),catatan:Fe(e,"catatan"),tindakan:Fe(e,"tindakan"),terapi_pengobatan:Fe(e,"terapi_pengobatan"),jenis_kasus:Fe(e,"jenis_kasus"),status_kasus:Fe(e,"status_kasus"),tindak_lanjut:Fe(e,"tindak_lanjut")},vitalSigns:{tensi:Fe(e,"tensi"),nadi:Fe(e,"nadi"),suhu:Fe(e,"suhu"),nafas:Fe(e,"nafas"),tinggi:Fe(e,"tinggi"),berat:Fe(e,"berat")},diagnosa:l,tindakan:o}}var tu=q(Ge(),1);function Dg(e){var a,t,l="";if(typeof e=="string"||typeof e=="number")l+=e;else if(typeof e=="object")if(Array.isArray(e)){var u=e.length;for(a=0;a<u;a++)e[a]&&(t=Dg(e[a]))&&(l&&(l+=" "),l+=t)}else for(t in e)e[t]&&(l&&(l+=" "),l+=t);return l}function es(){for(var e,a,t=0,l="",u=arguments.length;t<u;t++)(e=arguments[t])&&(a=Dg(e))&&(l&&(l+=" "),l+=a);return l}var ty=(e,a)=>{let t=new Array(e.length+a.length);for(let l=0;l<e.length;l++)t[l]=e[l];for(let l=0;l<a.length;l++)t[e.length+l]=a[l];return t},ly=(e,a)=>({classGroupId:e,validator:a}),Hg=(e=new Map,a=null,t)=>({nextPart:e,validators:a,classGroupId:t});var Rg=[],uy="arbitrary..",oy=e=>{let a=sy(e),{conflictingClassGroups:t,conflictingClassGroupModifiers:l}=e;return{getClassGroupId:n=>{if(n.startsWith("[")&&n.endsWith("]"))return ny(n);let s=n.split("-"),r=s[0]===""&&s.length>1?1:0;return Ug(s,r,a)},getConflictingClassGroupIds:(n,s)=>{if(s){let r=l[n],i=t[n];return r?i?ty(i,r):r:i||Rg}return t[n]||Rg}}},Ug=(e,a,t)=>{if(e.length-a===0)return t.classGroupId;let u=e[a],o=t.nextPart.get(u);if(o){let i=Ug(e,a+1,o);if(i)return i}let n=t.validators;if(n===null)return;let s=a===0?e.join("-"):e.slice(a).join("-"),r=n.length;for(let i=0;i<r;i++){let p=n[i];if(p.validator(s))return p.classGroupId}},ny=e=>e.slice(1,-1).indexOf(":")===-1?void 0:(()=>{let a=e.slice(1,-1),t=a.indexOf(":"),l=a.slice(0,t);return l?uy+l:void 0})(),sy=e=>{let{theme:a,classGroups:t}=e;return ry(t,a)},ry=(e,a)=>{let t=Hg();for(let l in e){let u=e[l];nd(u,t,l,a)}return t},nd=(e,a,t,l)=>{let u=e.length;for(let o=0;o<u;o++){let n=e[o];iy(n,a,t,l)}},iy=(e,a,t,l)=>{if(typeof e=="string"){dy(e,a,t);return}if(typeof e=="function"){fy(e,a,t,l);return}cy(e,a,t,l)},dy=(e,a,t)=>{let l=e===""?a:zg(a,e);l.classGroupId=t},fy=(e,a,t,l)=>{if(my(e)){nd(e(l),a,t,l);return}a.validators===null&&(a.validators=[]),a.validators.push(ly(t,e))},cy=(e,a,t,l)=>{let u=Object.entries(e),o=u.length;for(let n=0;n<o;n++){let[s,r]=u[n];nd(r,zg(a,s),t,l)}},zg=(e,a)=>{let t=e,l=a.split("-"),u=l.length;for(let o=0;o<u;o++){let n=l[o],s=t.nextPart.get(n);s||(s=Hg(),t.nextPart.set(n,s)),t=s}return t},my=e=>"isThemeGetter"in e&&e.isThemeGetter===!0,py=e=>{if(e<1)return{get:()=>{},set:()=>{}};let a=0,t=Object.create(null),l=Object.create(null),u=(o,n)=>{t[o]=n,a++,a>e&&(a=0,l=t,t=Object.create(null))};return{get(o){let n=t[o];if(n!==void 0)return n;if((n=l[o])!==void 0)return u(o,n),n},set(o,n){o in t?t[o]=n:u(o,n)}}};var gy=[],Bg=(e,a,t,l,u)=>({modifiers:e,hasImportantModifier:a,baseClassName:t,maybePostfixModifierPosition:l,isExternal:u}),hy=e=>{let{prefix:a,experimentalParseClassName:t}=e,l=u=>{let o=[],n=0,s=0,r=0,i,p=u.length;for(let b=0;b<p;b++){let A=u[b];if(n===0&&s===0){if(A===":"){o.push(u.slice(r,b)),r=b+1;continue}if(A==="/"){i=b;continue}}A==="["?n++:A==="]"?n--:A==="("?s++:A===")"&&s--}let g=o.length===0?u:u.slice(r),f=g,c=!1;g.endsWith("!")?(f=g.slice(0,-1),c=!0):g.startsWith("!")&&(f=g.slice(1),c=!0);let S=i&&i>r?i-r:void 0;return Bg(o,c,f,S)};if(a){let u=a+":",o=l;l=n=>n.startsWith(u)?o(n.slice(u.length)):Bg(gy,!1,n,void 0,!0)}if(t){let u=l;l=o=>t({className:o,parseClassName:u})}return l},xy=e=>{let a=new Map;return e.orderSensitiveModifiers.forEach((t,l)=>{a.set(t,1e6+l)}),t=>{let l=[],u=[];for(let o=0;o<t.length;o++){let n=t[o],s=n[0]==="[",r=a.has(n);s||r?(u.length>0&&(u.sort(),l.push(...u),u=[]),l.push(n)):u.push(n)}return u.length>0&&(u.sort(),l.push(...u)),l}},Ly=e=>({cache:py(e.cacheSize),parseClassName:hy(e),sortModifiers:xy(e),postfixLookupClassGroupIds:Sy(e),...oy(e)}),Sy=e=>{let a=Object.create(null),t=e.postfixLookupClassGroups;if(t)for(let l=0;l<t.length;l++)a[t[l]]=!0;return a},yy=/\s+/,Cy=(e,a)=>{let{parseClassName:t,getClassGroupId:l,getConflictingClassGroupIds:u,sortModifiers:o,postfixLookupClassGroupIds:n}=a,s=[],r=e.trim().split(yy),i="";for(let p=r.length-1;p>=0;p-=1){let g=r[p],{isExternal:f,modifiers:c,hasImportantModifier:S,baseClassName:b,maybePostfixModifierPosition:A}=t(g);if(f){i=g+(i.length>0?" "+i:i);continue}let h=!!A,d;if(h){let v=b.substring(0,A);d=l(v);let y=d&&n[d]?l(b):void 0;y&&y!==d&&(d=y,h=!1)}else d=l(b);if(!d){if(!h){i=g+(i.length>0?" "+i:i);continue}if(d=l(b),!d){i=g+(i.length>0?" "+i:i);continue}h=!1}let m=c.length===0?"":c.length===1?c[0]:o(c).join(":"),x=S?m+"!":m,L=x+d;if(s.indexOf(L)>-1)continue;s.push(L);let k=u(d,h);for(let v=0;v<k.length;++v){let y=k[v];s.push(x+y)}i=g+(i.length>0?" "+i:i)}return i},by=(...e)=>{let a=0,t,l,u="";for(;a<e.length;)(t=e[a++])&&(l=_g(t))&&(u&&(u+=" "),u+=l);return u},_g=e=>{if(typeof e=="string")return e;let a,t="";for(let l=0;l<e.length;l++)e[l]&&(a=_g(e[l]))&&(t&&(t+=" "),t+=a);return t},vy=(e,...a)=>{let t,l,u,o,n=r=>{let i=a.reduce((p,g)=>g(p),e());return t=Ly(i),l=t.cache.get,u=t.cache.set,o=s,s(r)},s=r=>{let i=l(r);if(i)return i;let p=Cy(r,t);return u(r,p),p};return o=n,(...r)=>o(by(...r))},Iy=[],he=e=>{let a=t=>t[e]||Iy;return a.isThemeGetter=!0,a},Ng=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,Pg=/^\((?:(\w[\w-]*):)?(.+)\)$/i,ky=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,Ay=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,Ty=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,wy=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,My=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,Dy=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,Mt=e=>ky.test(e),H=e=>!!e&&!Number.isNaN(Number(e)),Da=e=>!!e&&Number.isInteger(Number(e)),od=e=>e.endsWith("%")&&H(e.slice(0,-1)),Wa=e=>Ay.test(e),Fg=()=>!0,Ry=e=>Ty.test(e)&&!wy.test(e),sd=()=>!1,By=e=>My.test(e),Ey=e=>Dy.test(e),Oy=e=>!T(e)&&!w(e),qy=e=>e.startsWith("@container")&&(e[10]==="/"&&e[11]!==void 0||e[11]==="s"&&e[16]!==void 0&&e.startsWith("-size/",10)||e[11]==="n"&&e[18]!==void 0&&e.startsWith("-normal/",10)),Hy=e=>Dt(e,Xg,sd),T=e=>Ng.test(e),nl=e=>Dt(e,jg,Ry),Eg=e=>Dt(e,Vy,H),Uy=e=>Dt(e,Yg,Fg),zy=e=>Dt(e,Kg,sd),Og=e=>Dt(e,Gg,sd),_y=e=>Dt(e,Vg,Ey),as=e=>Dt(e,Zg,By),w=e=>Pg.test(e),io=e=>sl(e,jg),Ny=e=>sl(e,Kg),qg=e=>sl(e,Gg),Py=e=>sl(e,Xg),Fy=e=>sl(e,Vg),ts=e=>sl(e,Zg,!0),Gy=e=>sl(e,Yg,!0),Dt=(e,a,t)=>{let l=Ng.exec(e);return l?l[1]?a(l[1]):t(l[2]):!1},sl=(e,a,t=!1)=>{let l=Pg.exec(e);return l?l[1]?a(l[1]):t:!1},Gg=e=>e==="position"||e==="percentage",Vg=e=>e==="image"||e==="url",Xg=e=>e==="length"||e==="size"||e==="bg-size",jg=e=>e==="length",Vy=e=>e==="number",Kg=e=>e==="family-name",Yg=e=>e==="number"||e==="weight",Zg=e=>e==="shadow";var Xy=()=>{let e=he("color"),a=he("font"),t=he("text"),l=he("font-weight"),u=he("tracking"),o=he("leading"),n=he("breakpoint"),s=he("container"),r=he("spacing"),i=he("radius"),p=he("shadow"),g=he("inset-shadow"),f=he("text-shadow"),c=he("drop-shadow"),S=he("blur"),b=he("perspective"),A=he("aspect"),h=he("ease"),d=he("animate"),m=()=>["auto","avoid","all","avoid-page","page","left","right","column"],x=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],L=()=>[...x(),w,T],k=()=>["auto","hidden","clip","visible","scroll"],v=()=>["auto","contain","none"],y=()=>[w,T,r],I=()=>[Mt,"full","auto",...y()],M=()=>[Da,"none","subgrid",w,T],oe=()=>["auto",{span:["full",Da,w,T]},Da,w,T],aa=()=>[Da,"auto",w,T],rl=()=>["auto","min","max","fr",w,T],fs=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],il=()=>["start","end","center","stretch","center-safe","end-safe"],ha=()=>["auto",...y()],zt=()=>[Mt,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...y()],cs=()=>[Mt,"screen","full","dvw","lvw","svw","min","max","fit",...y()],ms=()=>[Mt,"screen","full","lh","dvh","lvh","svh","min","max","fit",...y()],D=()=>[e,w,T],gd=()=>[...x(),qg,Og,{position:[w,T]}],hd=()=>["no-repeat",{repeat:["","x","y","space","round"]}],xd=()=>["auto","cover","contain",Py,Hy,{size:[w,T]}],ps=()=>[od,io,nl],De=()=>["","none","full",i,w,T],Re=()=>["",H,io,nl],po=()=>["solid","dashed","dotted","double"],Ld=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],Le=()=>[H,od,qg,Og],Sd=()=>["","none",S,w,T],go=()=>["none",H,w,T],ho=()=>["none",H,w,T],gs=()=>[H,w,T],xo=()=>[Mt,"full",...y()];return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[Wa],breakpoint:[Wa],color:[Fg],container:[Wa],"drop-shadow":[Wa],ease:["in","out","in-out"],font:[Oy],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[Wa],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[Wa],shadow:[Wa],spacing:["px",H],text:[Wa],"text-shadow":[Wa],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",Mt,T,w,A]}],container:["container"],"container-type":[{"@container":["","normal","size",w,T]}],"container-named":[qy],columns:[{columns:[H,T,w,s]}],"break-after":[{"break-after":m()}],"break-before":[{"break-before":m()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:L()}],overflow:[{overflow:k()}],"overflow-x":[{"overflow-x":k()}],"overflow-y":[{"overflow-y":k()}],overscroll:[{overscroll:v()}],"overscroll-x":[{"overscroll-x":v()}],"overscroll-y":[{"overscroll-y":v()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:I()}],"inset-x":[{"inset-x":I()}],"inset-y":[{"inset-y":I()}],start:[{"inset-s":I(),start:I()}],end:[{"inset-e":I(),end:I()}],"inset-bs":[{"inset-bs":I()}],"inset-be":[{"inset-be":I()}],top:[{top:I()}],right:[{right:I()}],bottom:[{bottom:I()}],left:[{left:I()}],visibility:["visible","invisible","collapse"],z:[{z:[Da,"auto",w,T]}],basis:[{basis:[Mt,"full","auto",s,...y()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[H,Mt,"auto","initial","none",T]}],grow:[{grow:["",H,w,T]}],shrink:[{shrink:["",H,w,T]}],order:[{order:[Da,"first","last","none",w,T]}],"grid-cols":[{"grid-cols":M()}],"col-start-end":[{col:oe()}],"col-start":[{"col-start":aa()}],"col-end":[{"col-end":aa()}],"grid-rows":[{"grid-rows":M()}],"row-start-end":[{row:oe()}],"row-start":[{"row-start":aa()}],"row-end":[{"row-end":aa()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":rl()}],"auto-rows":[{"auto-rows":rl()}],gap:[{gap:y()}],"gap-x":[{"gap-x":y()}],"gap-y":[{"gap-y":y()}],"justify-content":[{justify:[...fs(),"normal"]}],"justify-items":[{"justify-items":[...il(),"normal"]}],"justify-self":[{"justify-self":["auto",...il()]}],"align-content":[{content:["normal",...fs()]}],"align-items":[{items:[...il(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...il(),{baseline:["","last"]}]}],"place-content":[{"place-content":fs()}],"place-items":[{"place-items":[...il(),"baseline"]}],"place-self":[{"place-self":["auto",...il()]}],p:[{p:y()}],px:[{px:y()}],py:[{py:y()}],ps:[{ps:y()}],pe:[{pe:y()}],pbs:[{pbs:y()}],pbe:[{pbe:y()}],pt:[{pt:y()}],pr:[{pr:y()}],pb:[{pb:y()}],pl:[{pl:y()}],m:[{m:ha()}],mx:[{mx:ha()}],my:[{my:ha()}],ms:[{ms:ha()}],me:[{me:ha()}],mbs:[{mbs:ha()}],mbe:[{mbe:ha()}],mt:[{mt:ha()}],mr:[{mr:ha()}],mb:[{mb:ha()}],ml:[{ml:ha()}],"space-x":[{"space-x":y()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":y()}],"space-y-reverse":["space-y-reverse"],size:[{size:zt()}],"inline-size":[{inline:["auto",...cs()]}],"min-inline-size":[{"min-inline":["auto",...cs()]}],"max-inline-size":[{"max-inline":["none",...cs()]}],"block-size":[{block:["auto",...ms()]}],"min-block-size":[{"min-block":["auto",...ms()]}],"max-block-size":[{"max-block":["none",...ms()]}],w:[{w:[s,"screen",...zt()]}],"min-w":[{"min-w":[s,"screen","none",...zt()]}],"max-w":[{"max-w":[s,"screen","none","prose",{screen:[n]},...zt()]}],h:[{h:["screen","lh",...zt()]}],"min-h":[{"min-h":["screen","lh","none",...zt()]}],"max-h":[{"max-h":["screen","lh",...zt()]}],"font-size":[{text:["base",t,io,nl]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[l,Gy,Uy]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",od,T]}],"font-family":[{font:[Ny,zy,a]}],"font-features":[{"font-features":[T]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[u,w,T]}],"line-clamp":[{"line-clamp":[H,"none",w,Eg]}],leading:[{leading:[o,...y()]}],"list-image":[{"list-image":["none",w,T]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",w,T]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:D()}],"text-color":[{text:D()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...po(),"wavy"]}],"text-decoration-thickness":[{decoration:[H,"from-font","auto",w,nl]}],"text-decoration-color":[{decoration:D()}],"underline-offset":[{"underline-offset":[H,"auto",w,T]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:y()}],"tab-size":[{tab:[Da,w,T]}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",w,T]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",w,T]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:gd()}],"bg-repeat":[{bg:hd()}],"bg-size":[{bg:xd()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},Da,w,T],radial:["",w,T],conic:[Da,w,T]},Fy,_y]}],"bg-color":[{bg:D()}],"gradient-from-pos":[{from:ps()}],"gradient-via-pos":[{via:ps()}],"gradient-to-pos":[{to:ps()}],"gradient-from":[{from:D()}],"gradient-via":[{via:D()}],"gradient-to":[{to:D()}],rounded:[{rounded:De()}],"rounded-s":[{"rounded-s":De()}],"rounded-e":[{"rounded-e":De()}],"rounded-t":[{"rounded-t":De()}],"rounded-r":[{"rounded-r":De()}],"rounded-b":[{"rounded-b":De()}],"rounded-l":[{"rounded-l":De()}],"rounded-ss":[{"rounded-ss":De()}],"rounded-se":[{"rounded-se":De()}],"rounded-ee":[{"rounded-ee":De()}],"rounded-es":[{"rounded-es":De()}],"rounded-tl":[{"rounded-tl":De()}],"rounded-tr":[{"rounded-tr":De()}],"rounded-br":[{"rounded-br":De()}],"rounded-bl":[{"rounded-bl":De()}],"border-w":[{border:Re()}],"border-w-x":[{"border-x":Re()}],"border-w-y":[{"border-y":Re()}],"border-w-s":[{"border-s":Re()}],"border-w-e":[{"border-e":Re()}],"border-w-bs":[{"border-bs":Re()}],"border-w-be":[{"border-be":Re()}],"border-w-t":[{"border-t":Re()}],"border-w-r":[{"border-r":Re()}],"border-w-b":[{"border-b":Re()}],"border-w-l":[{"border-l":Re()}],"divide-x":[{"divide-x":Re()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":Re()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...po(),"hidden","none"]}],"divide-style":[{divide:[...po(),"hidden","none"]}],"border-color":[{border:D()}],"border-color-x":[{"border-x":D()}],"border-color-y":[{"border-y":D()}],"border-color-s":[{"border-s":D()}],"border-color-e":[{"border-e":D()}],"border-color-bs":[{"border-bs":D()}],"border-color-be":[{"border-be":D()}],"border-color-t":[{"border-t":D()}],"border-color-r":[{"border-r":D()}],"border-color-b":[{"border-b":D()}],"border-color-l":[{"border-l":D()}],"divide-color":[{divide:D()}],"outline-style":[{outline:[...po(),"none","hidden"]}],"outline-offset":[{"outline-offset":[H,w,T]}],"outline-w":[{outline:["",H,io,nl]}],"outline-color":[{outline:D()}],shadow:[{shadow:["","none",p,ts,as]}],"shadow-color":[{shadow:D()}],"inset-shadow":[{"inset-shadow":["none",g,ts,as]}],"inset-shadow-color":[{"inset-shadow":D()}],"ring-w":[{ring:Re()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:D()}],"ring-offset-w":[{"ring-offset":[H,nl]}],"ring-offset-color":[{"ring-offset":D()}],"inset-ring-w":[{"inset-ring":Re()}],"inset-ring-color":[{"inset-ring":D()}],"text-shadow":[{"text-shadow":["none",f,ts,as]}],"text-shadow-color":[{"text-shadow":D()}],opacity:[{opacity:[H,w,T]}],"mix-blend":[{"mix-blend":[...Ld(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":Ld()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[H]}],"mask-image-linear-from-pos":[{"mask-linear-from":Le()}],"mask-image-linear-to-pos":[{"mask-linear-to":Le()}],"mask-image-linear-from-color":[{"mask-linear-from":D()}],"mask-image-linear-to-color":[{"mask-linear-to":D()}],"mask-image-t-from-pos":[{"mask-t-from":Le()}],"mask-image-t-to-pos":[{"mask-t-to":Le()}],"mask-image-t-from-color":[{"mask-t-from":D()}],"mask-image-t-to-color":[{"mask-t-to":D()}],"mask-image-r-from-pos":[{"mask-r-from":Le()}],"mask-image-r-to-pos":[{"mask-r-to":Le()}],"mask-image-r-from-color":[{"mask-r-from":D()}],"mask-image-r-to-color":[{"mask-r-to":D()}],"mask-image-b-from-pos":[{"mask-b-from":Le()}],"mask-image-b-to-pos":[{"mask-b-to":Le()}],"mask-image-b-from-color":[{"mask-b-from":D()}],"mask-image-b-to-color":[{"mask-b-to":D()}],"mask-image-l-from-pos":[{"mask-l-from":Le()}],"mask-image-l-to-pos":[{"mask-l-to":Le()}],"mask-image-l-from-color":[{"mask-l-from":D()}],"mask-image-l-to-color":[{"mask-l-to":D()}],"mask-image-x-from-pos":[{"mask-x-from":Le()}],"mask-image-x-to-pos":[{"mask-x-to":Le()}],"mask-image-x-from-color":[{"mask-x-from":D()}],"mask-image-x-to-color":[{"mask-x-to":D()}],"mask-image-y-from-pos":[{"mask-y-from":Le()}],"mask-image-y-to-pos":[{"mask-y-to":Le()}],"mask-image-y-from-color":[{"mask-y-from":D()}],"mask-image-y-to-color":[{"mask-y-to":D()}],"mask-image-radial":[{"mask-radial":[w,T]}],"mask-image-radial-from-pos":[{"mask-radial-from":Le()}],"mask-image-radial-to-pos":[{"mask-radial-to":Le()}],"mask-image-radial-from-color":[{"mask-radial-from":D()}],"mask-image-radial-to-color":[{"mask-radial-to":D()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":x()}],"mask-image-conic-pos":[{"mask-conic":[H]}],"mask-image-conic-from-pos":[{"mask-conic-from":Le()}],"mask-image-conic-to-pos":[{"mask-conic-to":Le()}],"mask-image-conic-from-color":[{"mask-conic-from":D()}],"mask-image-conic-to-color":[{"mask-conic-to":D()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:gd()}],"mask-repeat":[{mask:hd()}],"mask-size":[{mask:xd()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",w,T]}],filter:[{filter:["","none",w,T]}],blur:[{blur:Sd()}],brightness:[{brightness:[H,w,T]}],contrast:[{contrast:[H,w,T]}],"drop-shadow":[{"drop-shadow":["","none",c,ts,as]}],"drop-shadow-color":[{"drop-shadow":D()}],grayscale:[{grayscale:["",H,w,T]}],"hue-rotate":[{"hue-rotate":[H,w,T]}],invert:[{invert:["",H,w,T]}],saturate:[{saturate:[H,w,T]}],sepia:[{sepia:["",H,w,T]}],"backdrop-filter":[{"backdrop-filter":["","none",w,T]}],"backdrop-blur":[{"backdrop-blur":Sd()}],"backdrop-brightness":[{"backdrop-brightness":[H,w,T]}],"backdrop-contrast":[{"backdrop-contrast":[H,w,T]}],"backdrop-grayscale":[{"backdrop-grayscale":["",H,w,T]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[H,w,T]}],"backdrop-invert":[{"backdrop-invert":["",H,w,T]}],"backdrop-opacity":[{"backdrop-opacity":[H,w,T]}],"backdrop-saturate":[{"backdrop-saturate":[H,w,T]}],"backdrop-sepia":[{"backdrop-sepia":["",H,w,T]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":y()}],"border-spacing-x":[{"border-spacing-x":y()}],"border-spacing-y":[{"border-spacing-y":y()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",w,T]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[H,"initial",w,T]}],ease:[{ease:["linear","initial",h,w,T]}],delay:[{delay:[H,w,T]}],animate:[{animate:["none",d,w,T]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[b,w,T]}],"perspective-origin":[{"perspective-origin":L()}],rotate:[{rotate:go()}],"rotate-x":[{"rotate-x":go()}],"rotate-y":[{"rotate-y":go()}],"rotate-z":[{"rotate-z":go()}],scale:[{scale:ho()}],"scale-x":[{"scale-x":ho()}],"scale-y":[{"scale-y":ho()}],"scale-z":[{"scale-z":ho()}],"scale-3d":["scale-3d"],skew:[{skew:gs()}],"skew-x":[{"skew-x":gs()}],"skew-y":[{"skew-y":gs()}],transform:[{transform:[w,T,"","none","gpu","cpu"]}],"transform-origin":[{origin:L()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:xo()}],"translate-x":[{"translate-x":xo()}],"translate-y":[{"translate-y":xo()}],"translate-z":[{"translate-z":xo()}],"translate-none":["translate-none"],zoom:[{zoom:[Da,w,T]}],accent:[{accent:D()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:D()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",w,T]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scrollbar-thumb-color":[{"scrollbar-thumb":D()}],"scrollbar-track-color":[{"scrollbar-track":D()}],"scrollbar-gutter":[{"scrollbar-gutter":["auto","stable","both"]}],"scrollbar-w":[{scrollbar:["auto","thin","none"]}],"scroll-m":[{"scroll-m":y()}],"scroll-mx":[{"scroll-mx":y()}],"scroll-my":[{"scroll-my":y()}],"scroll-ms":[{"scroll-ms":y()}],"scroll-me":[{"scroll-me":y()}],"scroll-mbs":[{"scroll-mbs":y()}],"scroll-mbe":[{"scroll-mbe":y()}],"scroll-mt":[{"scroll-mt":y()}],"scroll-mr":[{"scroll-mr":y()}],"scroll-mb":[{"scroll-mb":y()}],"scroll-ml":[{"scroll-ml":y()}],"scroll-p":[{"scroll-p":y()}],"scroll-px":[{"scroll-px":y()}],"scroll-py":[{"scroll-py":y()}],"scroll-ps":[{"scroll-ps":y()}],"scroll-pe":[{"scroll-pe":y()}],"scroll-pbs":[{"scroll-pbs":y()}],"scroll-pbe":[{"scroll-pbe":y()}],"scroll-pt":[{"scroll-pt":y()}],"scroll-pr":[{"scroll-pr":y()}],"scroll-pb":[{"scroll-pb":y()}],"scroll-pl":[{"scroll-pl":y()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",w,T]}],fill:[{fill:["none",...D()]}],"stroke-w":[{stroke:[H,io,nl,Eg]}],stroke:[{stroke:["none",...D()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{"container-named":["container-type"],overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},postfixLookupClassGroups:["container-type"],orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}};var Qg=vy(Xy);function ma(...e){return Qg(es(e))}var eh=q(G(),1),Rt=(0,tu.forwardRef)(({className:e,autoResize:a=!0,onChange:t,...l},u)=>{let o=(0,tu.useRef)(null),n=u||o;(0,tu.useEffect)(()=>{a&&n.current&&(n.current.style.height="auto",n.current.style.height=n.current.scrollHeight+"px")},[l.value,a,n]);let s=r=>{a&&(r.target.style.height="auto",r.target.style.height=r.target.scrollHeight+"px"),t?.(r)};return(0,eh.jsx)("textarea",{ref:n,className:ma("flex w-full rounded-lg border-2 border-input bg-background px-3.5 py-3 text-base text-foreground leading-[1.7]","placeholder:text-muted-foreground","focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 border-primary/50","disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted","resize-y min-h-[80px]",e),onChange:s,...l})});Rt.displayName="Textarea";var us=q(G(),1);function $a({className:e,required:a,helperText:t,children:l,...u}){return(0,us.jsxs)("label",{className:ma("block text-base font-semibold text-foreground uppercase tracking-[0.03em] mb-1.5",e),...u,children:[l,a&&(0,us.jsx)("span",{className:"text-destructive ml-1","aria-hidden":"true",children:"*"})]})}var lu=q(G(),1);function uu({title:e,children:a,className:t}){return(0,lu.jsxs)("div",{className:ma("bg-background border-2 border-border rounded-xl mb-4 overflow-hidden shadow-sm",t),children:[(0,lu.jsxs)("div",{className:"px-4 py-3 bg-primary/5 border-b border-primary/20 text-base font-bold text-primary flex items-center gap-2",children:[(0,lu.jsx)("span",{className:"text-base","aria-hidden":"true",children:"\u25CF"}),e]}),(0,lu.jsx)("div",{className:"p-4 space-y-4",children:a})]})}var ss=q(Ge(),1);var os=(...e)=>e.filter((a,t,l)=>!!a&&a.trim()!==""&&l.indexOf(a)===t).join(" ").trim();var ah=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();var th=e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(a,t,l)=>l?l.toUpperCase():t.toLowerCase());var rd=e=>{let a=th(e);return a.charAt(0).toUpperCase()+a.slice(1)};var fo=q(Ge(),1);var ns={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};var lh=e=>{for(let a in e)if(a.startsWith("aria-")||a==="role"||a==="title")return!0;return!1};var ou=q(Ge(),1);var Yy=(0,ou.createContext)({});var uh=()=>(0,ou.useContext)(Yy);var oh=(0,fo.forwardRef)(({color:e,size:a,strokeWidth:t,absoluteStrokeWidth:l,className:u="",children:o,iconNode:n,...s},r)=>{let{size:i=24,strokeWidth:p=2,absoluteStrokeWidth:g=!1,color:f="currentColor",className:c=""}=uh()??{},S=l??g?Number(t??p)*24/Number(a??i):t??p;return(0,fo.createElement)("svg",{ref:r,...ns,width:a??i??ns.width,height:a??i??ns.height,stroke:e??f,strokeWidth:S,className:os("lucide",c,u),...!o&&!lh(s)&&{"aria-hidden":"true"},...s},[...n.map(([b,A])=>(0,fo.createElement)(b,A)),...Array.isArray(o)?o:[o]])});var Bt=(e,a)=>{let t=(0,ss.forwardRef)(({className:l,...u},o)=>(0,ss.createElement)(oh,{ref:o,iconNode:a,className:os(`lucide-${ah(rd(e))}`,`lucide-${e}`,l),...u}));return t.displayName=rd(e),t};var Zy=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],co=Bt("check",Zy);var Qy=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],mo=Bt("info",Qy);var Jy=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],ya=Bt("triangle-alert",Jy);var Wy=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Et=Bt("x",Wy);var Te=q(G(),1);function nh({title:e,subtitle:a,onClose:t,patientInfo:l}){return(0,Te.jsxs)("div",{className:"flex items-center justify-between px-5 py-4 bg-primary text-white shrink-0",children:[(0,Te.jsxs)("div",{className:"flex items-center gap-3 min-w-0",children:[(0,Te.jsx)("div",{className:"flex items-center justify-center w-11 h-11 rounded-xl bg-white/15 flex-shrink-0",children:(0,Te.jsxs)("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[(0,Te.jsx)("path",{d:"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"}),(0,Te.jsx)("polyline",{points:"14 2 14 8 20 8"}),(0,Te.jsx)("line",{x1:"16",y1:"13",x2:"8",y2:"13"}),(0,Te.jsx)("line",{x1:"16",y1:"17",x2:"8",y2:"17"}),(0,Te.jsx)("polyline",{points:"10 9 9 9 8 9"})]})}),(0,Te.jsxs)("div",{className:"min-w-0",children:[(0,Te.jsx)("h2",{className:"text-base font-bold",children:e}),a?(0,Te.jsx)("p",{className:"text-base text-white/80 mt-0.5",children:a}):null,l&&(l.norm||l.pasien||l.nama_dokter)&&(0,Te.jsxs)("div",{className:"text-base text-white/90 mt-1",children:["RM ",l.norm||"\u2014"," \xB7 ",l.pasien||"\u2014"," \xB7"," ",l.nama_dokter||"\u2014"]})]})]}),(0,Te.jsx)("button",{type:"button",onClick:t,className:"bg-white/15 hover:bg-white/25 border-none text-white w-12 h-12 rounded-lg text-xl flex items-center justify-center cursor-pointer transition-colors flex-shrink-0","aria-label":"Tutup modal",children:(0,Te.jsx)(Et,{className:"size-6"})})]})}var Ca=q(G(),1);function sh({anamnesa:e,pemeriksaan:a,onChange:t}){return(0,Ca.jsxs)("div",{className:"space-y-5",children:[(0,Ca.jsxs)("div",{children:[(0,Ca.jsx)($a,{children:"Anamnesa"}),(0,Ca.jsx)(Rt,{value:e,onChange:l=>t("anamnesa",l.target.value),placeholder:"Keluhan pasien...",rows:5,"aria-describedby":"anamnesa-help"}),(0,Ca.jsx)("p",{id:"anamnesa-help",className:"text-base text-muted-foreground mt-1",children:"Tuliskan keluhan utama, riwayat penyakit sekarang, dan riwayat penyakit dahulu"})]}),(0,Ca.jsxs)("div",{children:[(0,Ca.jsx)($a,{children:"Pemeriksaan Fisik"}),(0,Ca.jsx)(Rt,{value:a,onChange:l=>t("pemeriksaan",l.target.value),placeholder:"Hasil pemeriksaan fisik...",rows:5,"aria-describedby":"pemeriksaan-help"}),(0,Ca.jsx)("p",{id:"pemeriksaan-help",className:"text-base text-muted-foreground mt-1",children:"Catat hasil pemeriksaan umum dan sistemik"})]})]})}var rh=q(Ge(),1);var ih=q(G(),1),et=(0,rh.forwardRef)(({className:e,type:a,...t},l)=>(0,ih.jsx)("input",{type:a,className:ma("flex h-11 w-full rounded-lg border-2 border-input bg-background px-3.5 py-2.5 text-base text-foreground leading-normal","placeholder:text-muted-foreground","focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 border-primary/50","disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted",e),ref:l,...t}));et.displayName="Input";var Ot=q(G(),1);function dh({vitals:e,onChange:a}){return(0,Ot.jsx)("div",{className:"grid grid-cols-2 sm:grid-cols-3 gap-4",children:[{key:"tensi",label:"Tekanan Darah",unit:"mmHg",placeholder:"120/80"},{key:"nadi",label:"Nadi",unit:"x/menit",placeholder:"80"},{key:"suhu",label:"Suhu Tubuh",unit:"\xB0C",placeholder:"36.5"},{key:"nafas",label:"Respirasi",unit:"x/menit",placeholder:"20"},{key:"berat",label:"Berat Badan",unit:"kg",placeholder:"60"},{key:"tinggi",label:"Tinggi Badan",unit:"cm",placeholder:"165"}].map(l=>(0,Ot.jsxs)("div",{className:"space-y-1.5",children:[(0,Ot.jsx)($a,{children:l.label}),(0,Ot.jsxs)("div",{className:"relative",children:[(0,Ot.jsx)(et,{value:e[l.key],onChange:u=>a(l.key,u.target.value),placeholder:l.placeholder,className:"pr-20 font-mono font-semibold","aria-label":l.label}),(0,Ot.jsx)("span",{className:"absolute right-4 top-1/2 -translate-y-1/2 text-base font-semibold text-muted-foreground pointer-events-none",children:l.unit})]})]},l.key))})}var qt=q(Ge(),1);var ph=q(Ge(),1);var fh=e=>typeof e=="boolean"?`${e}`:e===0?"0":e,ch=es,mh=(e,a)=>t=>{var l;if(a?.variants==null)return ch(e,t?.class,t?.className);let{variants:u,defaultVariants:o}=a,n=Object.keys(u).map(i=>{let p=t?.[i],g=o?.[i];if(p===null)return null;let f=fh(p)||fh(g);return u[i][f]}),s=t&&Object.entries(t).reduce((i,p)=>{let[g,f]=p;return f===void 0||(i[g]=f),i},{}),r=a==null||(l=a.compoundVariants)===null||l===void 0?void 0:l.reduce((i,p)=>{let{class:g,className:f,...c}=p;return Object.entries(c).every(S=>{let[b,A]=S;return Array.isArray(A)?A.includes({...o,...s}[b]):{...o,...s}[b]===A})?[...i,g,f]:i},[]);return ch(e,n,r,t?.class,t?.className)};var gh=q(G(),1),$y=mh("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-base font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-5 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground shadow-sm hover:bg-primary/90 active:bg-primary",destructive:"bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90 active:bg-destructive",outline:"border-2 border-border bg-background shadow-sm hover:bg-accent hover:text-accent-foreground active:bg-accent",secondary:"bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80 active:bg-secondary",success:"bg-green-600 text-green-50 shadow-sm hover:bg-green-600/90 active:bg-green-600",dark:"bg-neutral-950 text-white shadow-sm hover:bg-neutral-900 active:bg-neutral-950",ghost:"hover:bg-accent hover:text-accent-foreground active:bg-accent",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-11 px-5 min-w-[90px]",sm:"h-9 px-3.5 min-w-[80px]",xs:"h-7 px-2.5 min-w-0 gap-1.5 text-xs font-medium [&_svg]:size-3.5",lg:"h-12 px-6 text-base min-w-[100px]",xl:"h-13 px-7 text-lg min-w-[110px]",icon:"h-11 w-11"}},defaultVariants:{variant:"default",size:"default"}}),pa=(0,ph.forwardRef)(({className:e,variant:a,size:t,...l},u)=>(0,gh.jsx)("button",{className:ma($y({variant:a,size:t,className:e})),ref:u,...l}));pa.displayName="Button";var Q=q(G(),1),eC="/rekam-medik/search?opsi=kodeicd10&q=";function hh({rows:e,onChange:a}){let[t,l]=(0,qt.useState)([]),[u,o]=(0,qt.useState)(-1),[n,s]=(0,qt.useState)({top:0,left:0,width:0}),[r,i]=(0,qt.useState)(""),p=(0,qt.useRef)(null),g=(0,qt.useRef)(null),f=(d,m)=>a(e.map((x,L)=>L===d?{...x,...m}:x)),c=d=>a(e.filter((m,x)=>x!==d)),S=(d,m,x)=>{if(i(""),clearTimeout(p.current??void 0),g.current?.abort(),d.length<3){l([]),o(-1);return}let L=x.getBoundingClientRect();s({top:L.bottom+4,left:L.left,width:L.width}),p.current=setTimeout(async()=>{let k=new AbortController;g.current=k;try{let v=await fetch(`${eC}${encodeURIComponent(d)}`,{signal:k.signal});if(!v.ok){i("HTTP "+v.status);return}let y=await v.text();if(!y||y==="[]"){i("Data tidak ditemukan");return}let I;try{if(I=JSON.parse(y),!Array.isArray(I))throw new Error("not array")}catch{I=y.split(`
`).filter(M=>M.includes("|")).map(M=>{let[oe,aa,rl]=M.split("|");return{NAMA:oe.trim(),KODE:aa.trim(),ID:rl.trim()}}).filter(M=>M.KODE)}I.length>0?(l(I.slice(0,15)),o(m)):i("Data tidak ditemukan")}catch(v){i(String(v))}},300)},b=(d,m)=>{f(d,{idicd:m.ID,kode10:m.KODE,namaDiagnosa:m.NAMA}),l([]),o(-1)},A=d=>m=>{f(d,{namaDiagnosa:m.target.value}),S(m.target.value,d,m.currentTarget)},h=d=>m=>{f(d,{kode10:m.target.value})};return(0,Q.jsxs)("div",{className:"space-y-2",children:[e.length>0&&(0,Q.jsxs)("div",{className:"flex gap-2 text-base font-bold text-muted-foreground px-1",children:[(0,Q.jsx)("span",{className:"flex-1",children:"Nama Diagnosa"}),(0,Q.jsx)("span",{className:"w-28",children:"Kode ICD"}),(0,Q.jsx)("span",{className:"w-[76px] text-right",children:"Aksi"})]}),e.length===0?(0,Q.jsx)("div",{className:"border-2 border-dashed border-border rounded-xl py-6 text-center bg-background",children:(0,Q.jsx)("p",{className:"text-base text-muted-foreground",children:"Belum ada diagnosa"})}):(0,Q.jsx)("div",{className:"space-y-2",children:e.map((d,m)=>{let x=m+1;return(0,Q.jsxs)("div",{className:"flex gap-2 items-center",children:[(0,Q.jsxs)("div",{className:"flex-1 min-w-0 relative",children:[(0,Q.jsx)(et,{id:`rj-nama${x}`,name:"nama[]",value:d.namaDiagnosa,placeholder:"Cari diagnosa...",autoComplete:"off",onChange:A(m),"aria-label":`Nama diagnosa ${x}`,"aria-describedby":`rj-nama-help-${x}`}),(0,Q.jsx)("p",{id:`rj-nama-help-${x}`,className:"sr-only",children:"Ketik minimal 3 karakter untuk mencari diagnosis ICD-10"}),(0,Q.jsx)("input",{type:"hidden",id:`rj-idicd${x}`,name:"idicd[]",value:d.idicd}),t.length>0&&u===m&&(0,Q.jsx)("div",{className:"fixed z-[2147483647] bg-background border-2 border-border rounded-xl shadow-lg max-h-[420px] overflow-auto",style:{top:n.top,left:n.left,width:n.width},role:"listbox","aria-label":"Hasil pencarian ICD-10",children:t.map((L,k)=>(0,Q.jsxs)("div",{onClick:()=>b(m,L),role:"option",className:"px-4 py-4 cursor-pointer text-lg border-b border-border hover:bg-accent transition-colors",children:[(0,Q.jsx)("div",{className:"rj-icd-hit-nama font-semibold text-foreground leading-snug",children:L.NAMA}),(0,Q.jsx)("div",{className:"rj-icd-hit-kode text-muted-foreground text-xxl leading-tight",children:L.KODE})]},L.ID||k))}),r&&u===m&&(0,Q.jsx)("div",{className:"fixed z-[2147483647] bg-destructive/10 border-2 border-destructive rounded-xl px-3 py-2.5 text-base text-destructive",style:{top:n.top,left:n.left},role:"alert",children:r})]}),(0,Q.jsxs)("div",{className:"w-28 shrink-0",children:[(0,Q.jsx)(et,{id:`rj-kode${x}`,name:"kode10[]",value:d.kode10,placeholder:"Kode",onChange:h(m),className:"font-mono text-base","aria-label":`Kode ICD-10 ${x}`}),(0,Q.jsx)("input",{type:"hidden",name:"kasus[]",value:d.kasus}),(0,Q.jsx)("input",{type:"hidden",name:"komplikasi[]",value:d.komplikasi})]}),(0,Q.jsx)(pa,{variant:"destructive",size:"default",onClick:()=>c(m),className:"w-[76px] shrink-0","aria-label":`Hapus diagnosa ${x}`,children:"Hapus"})]},m)})}),(0,Q.jsx)(pa,{variant:"default",size:"default",className:"gap-2 w-full",onClick:()=>a([...e,{idicd:"",kode10:"",namaDiagnosa:"",kasus:"LAMA",komplikasi:"TIDAK"}]),children:"\uFF0B Tambah Diagnosa"})]})}var Ht=q(Ge(),1);var J=q(G(),1),aC="/rekam-medik/search?opsi=clauseDiagnose_icd9&q=";function xh({rows:e,onChange:a}){let[t,l]=(0,Ht.useState)([]),[u,o]=(0,Ht.useState)(-1),[n,s]=(0,Ht.useState)({top:0,left:0,width:0}),[r,i]=(0,Ht.useState)(""),p=(0,Ht.useRef)(null),g=(0,Ht.useRef)(null),f=(d,m)=>a(e.map((x,L)=>L===d?{...x,...m}:x)),c=d=>a(e.filter((m,x)=>x!==d)),S=(d,m,x)=>{if(i(""),clearTimeout(p.current??void 0),g.current?.abort(),d.length<3){l([]),o(-1);return}let L=x.getBoundingClientRect();s({top:L.bottom+4,left:L.left,width:L.width}),p.current=setTimeout(async()=>{let k=new AbortController;g.current=k;try{let v=await fetch(`${aC}${encodeURIComponent(d)}`,{signal:k.signal});if(!v.ok){i("HTTP "+v.status);return}let y=await v.text();if(!y||y==="[]"){i("Data tidak ditemukan");return}let I;try{if(I=JSON.parse(y),!Array.isArray(I))throw new Error("not array")}catch{I=y.split(`
`).filter(M=>M.includes("|")).map(M=>{let[oe,aa,rl]=M.split("|");return{NAMA:oe.trim(),KODE:aa.trim(),ID:rl.trim()}}).filter(M=>M.KODE)}I.length>0?(l(I.slice(0,15)),o(m)):i("Data tidak ditemukan")}catch(v){i(String(v))}},300)},b=(d,m)=>{f(d,{idicdTindakan:m.ID,kode9:m.KODE,namaTindakan:m.NAMA}),l([]),o(-1)},A=d=>m=>{f(d,{namaTindakan:m.target.value}),S(m.target.value,d,m.currentTarget)},h=d=>m=>{f(d,{kode9:m.target.value})};return(0,J.jsxs)("div",{className:"space-y-2",children:[e.length>0&&(0,J.jsxs)("div",{className:"flex gap-2 text-base font-bold text-muted-foreground px-1",children:[(0,J.jsx)("span",{className:"flex-1",children:"Nama Tindakan"}),(0,J.jsx)("span",{className:"w-28",children:"Kode ICD"}),(0,J.jsx)("span",{className:"w-[76px] text-right",children:"Aksi"})]}),e.length===0?(0,J.jsx)("div",{className:"border-2 border-dashed border-border rounded-xl py-6 text-center bg-background",children:(0,J.jsx)("p",{className:"text-base text-muted-foreground",children:"Belum ada tindakan"})}):(0,J.jsx)("div",{className:"space-y-2",children:e.map((d,m)=>{let x=m+1;return(0,J.jsxs)("div",{className:"flex gap-2 items-center",children:[(0,J.jsxs)("div",{className:"flex-1 min-w-0 relative",children:[(0,J.jsx)(et,{id:`rj-nama-tindakan${x}`,name:"nama_tindakan[]",value:d.namaTindakan,placeholder:"Cari tindakan...",autoComplete:"off",onChange:A(m),"aria-label":`Nama tindakan ${x}`,"aria-describedby":`rj-tindakan-help-${x}`}),(0,J.jsx)("p",{id:`rj-tindakan-help-${x}`,className:"sr-only",children:"Ketik minimal 3 karakter untuk mencari tindakan ICD-9"}),(0,J.jsx)("input",{type:"hidden",id:`rj-idicd-tindakan${x}`,name:"idicd_tindakan[]",value:d.idicdTindakan,autoComplete:"off"}),t.length>0&&u===m&&(0,J.jsx)("div",{className:"fixed z-[2147483647] bg-background border-2 border-border rounded-xl shadow-lg max-h-[420px] overflow-auto",style:{top:n.top,left:n.left,width:n.width},role:"listbox","aria-label":"Hasil pencarian ICD-9",children:t.map((L,k)=>(0,J.jsxs)("div",{onClick:()=>b(m,L),role:"option",className:"px-4 py-4 cursor-pointer text-lg border-b border-border hover:bg-accent transition-colors",children:[(0,J.jsx)("div",{className:"rj-icd-hit-nama font-semibold text-foreground leading-snug",children:L.NAMA}),(0,J.jsx)("div",{className:"rj-icd-hit-kode text-muted-foreground text-xxl leading-tight",children:L.KODE})]},L.ID||k))}),r&&u===m&&(0,J.jsx)("div",{className:"fixed z-[2147483647] bg-destructive/10 border-2 border-destructive rounded-xl px-3 py-2.5 text-base text-destructive",style:{top:n.top,left:n.left},role:"alert",children:r})]}),(0,J.jsxs)("div",{className:"w-28 shrink-0",children:[(0,J.jsx)(et,{id:`rj-kode9${x}`,name:"kode9[]",value:d.kode9,placeholder:"Kode",onChange:h(m),className:"font-mono text-base","aria-label":`Kode ICD-9 ${x}`}),(0,J.jsx)("input",{type:"hidden",name:"jenis[]",value:d.jenis||"Primer"}),(0,J.jsx)("input",{type:"hidden",name:"kategoriProsedur[]",value:d.kategoriProsedur})]}),(0,J.jsx)(pa,{variant:"destructive",size:"default",onClick:()=>c(m),className:"w-[76px] shrink-0","aria-label":`Hapus tindakan ${x}`,children:"Hapus"})]},m)})}),(0,J.jsx)(pa,{variant:"default",size:"default",className:"gap-2 w-full",onClick:()=>a([...e,{idicdTindakan:"",kode9:"",namaTindakan:"",jenis:e.length===0?"Primer":"Sekunder",komorbid:"",kategoriProsedur:"410606002",snomedProsedur:"",codeProsedur:""}]),children:"\uFF0B Tambah Tindakan"})]})}var xe=q(G(),1);function Lh({errors:e,warnings:a=[]}){return e.length>0||a.length>0?(0,xe.jsxs)(xe.Fragment,{children:[a.length>0&&(0,xe.jsx)("div",{className:"px-6 py-4 border-t-2 border-border bg-yellow-50 dark:bg-yellow-950/30",role:"alert",children:(0,xe.jsxs)("div",{className:"flex items-start gap-3",children:[(0,xe.jsx)(ya,{className:"size-5 text-yellow-600 dark:text-yellow-500 shrink-0 mt-0.5"}),(0,xe.jsxs)("div",{children:[(0,xe.jsx)("p",{className:"text-base font-bold text-yellow-800 dark:text-yellow-300 mb-1",children:"Perhatian"}),(0,xe.jsx)("ul",{className:"space-y-1",children:a.map((l,u)=>(0,xe.jsxs)("li",{className:"text-base text-yellow-700 dark:text-yellow-400",children:[l.section,": ",l.message]},u))})]})]})}),e.length>0&&(0,xe.jsx)("div",{className:"px-6 py-4 border-t-2 border-border bg-destructive/5",role:"alert",children:(0,xe.jsxs)("div",{className:"flex items-start gap-3",children:[(0,xe.jsx)(ya,{className:"size-5 text-destructive shrink-0 mt-0.5"}),(0,xe.jsxs)("div",{children:[(0,xe.jsxs)("p",{className:"text-base font-bold text-destructive mb-1",children:["Terdapat ",e.length," kesalahan"]}),(0,xe.jsx)("ul",{className:"space-y-1",children:e.map((l,u)=>(0,xe.jsxs)("li",{className:"text-base text-destructive/80",children:[l.section,": ",l.message]},u))})]})]})})]}):null}var nu=q(G(),1),tC={default:"bg-primary/10 text-primary border-primary/20",success:"bg-green-50 dark:bg-green-950/20 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800",warning:"bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800",danger:"bg-destructive/10 text-destructive border-destructive/20"},lC={default:mo,success:co,warning:ya,danger:Et};function id({variant:e="default",icon:a,children:t,className:l,onDismiss:u}){let o=lC[e];return(0,nu.jsxs)("span",{className:ma("inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-base font-semibold",tC[e],l),children:[a&&(0,nu.jsx)(o,{className:"size-3.5"}),t,u&&(0,nu.jsx)("button",{onClick:u,className:"ml-1 hover:opacity-70 p-0.5","aria-label":"Dismiss",children:(0,nu.jsx)(Et,{className:"size-3.5"})})]})}var ga=q(G(),1);function Sh({onCancel:e,onSave:a,onRefresh:t,onReset:l,onHistory:u,saving:o,hasErrors:n,lastSaved:s}){let r=l??t;return(0,ga.jsxs)("div",{className:"flex items-center justify-between px-6 py-4 border-t-2 border-border bg-background/60 backdrop-blur supports-[backdrop-filter]:bg-background/60 shrink-0 sticky bottom-0 z-[1]",children:[(0,ga.jsxs)("div",{className:"flex items-center gap-3 min-w-0",children:[n&&(0,ga.jsx)(id,{variant:"danger",icon:!0,children:"Validasi gagal"}),s&&(0,ga.jsxs)("span",{className:"text-base text-muted-foreground truncate",children:["Tersimpan ",s]}),o&&(0,ga.jsx)(id,{variant:"default",icon:!0,children:"Menyimpan..."})]}),(0,ga.jsxs)("div",{className:"flex items-center gap-3",children:[u&&(0,ga.jsx)(pa,{type:"button",variant:"success",size:"default",onClick:u,className:"gap-2",children:"Riwayat"}),r&&(0,ga.jsx)(pa,{type:"button",variant:"outline",size:"default",onClick:r,className:"gap-2",children:"Reset Formulir"}),(0,ga.jsx)(pa,{type:"button",variant:"dark",size:"default",onClick:e,children:"Batal"}),(0,ga.jsx)(pa,{type:"button",variant:"default",size:"lg",onClick:a,disabled:o||n,className:"gap-2 px-7 min-h-11","aria-label":"Simpan resume",children:o?"Menyimpan...":"Simpan"})]})]})}var W=q(G(),1);function kh(e){let a=[];return e.diagnosa.forEach((t,l)=>{Ja(t.kode10)&&Ja(t.namaDiagnosa)||(!Ja(t.kode10)&&Ja(t.namaDiagnosa)&&a.push({section:`Diagnosa #${l+1}`,message:"Nama diagnosa kosong"}),!Ja(t.namaDiagnosa)&&Ja(t.kode10)&&a.push({section:`Diagnosa #${l+1}`,message:"Kode ICD-10 kosong"}))}),e.tindakan.forEach((t,l)=>{Ja(t.kode9)||Ja(t.namaTindakan)&&a.push({section:`Tindakan #${l+1}`,message:"Nama tindakan kosong"})}),a}function Ah({data:e,onSave:a,onClose:t}){let[l,u]=(0,ea.useState)(e),[o,n]=(0,ea.useState)(!1),[s,r]=(0,ea.useState)(null),[i,p]=(0,ea.useState)(!1),[g,f]=(0,ea.useState)([]),[c,S]=(0,ea.useState)([]),b=(0,ea.useRef)(l.diagnosa.some(I=>I.idicd?.trim()));(0,ea.useEffect)(()=>{p(!1)},[l]);let A=i?kh(l):[],h=[...A,...c],d=A.length>0,m=(0,ea.useCallback)(async()=>{if(p(!0),f([]),S([]),kh(l).length>0)return;let M=l.diagnosa.filter(oe=>oe.idicd?.trim()&&oe.kode10?.trim()&&oe.namaDiagnosa?.trim());b.current&&M.length===0&&f([{section:"Diagnosa",message:"Semua diagnosa telah dihapus. Sistem Morbis biasanya tidak menghapus ICD yang sudah tersimpan ketika daftar diagnosa dikosongkan."}]),n(!0);try{await a(l),r(new Date().toLocaleTimeString()),window.setTimeout(()=>window.location.reload(),900)}catch(oe){let aa=oe instanceof Error?oe.message:String(oe);S([{section:"Server",message:aa}])}finally{n(!1)}},[l,a]),x=(I,M)=>u({...l,clinicalNotes:{...l.clinicalNotes,[I]:M}}),L=async()=>{let{confirmExt:I}=await Promise.resolve().then(()=>(Ih(),vh));return I({title:"Reset semua data?",message:"Semua data yang sudah dimasukkan akan dihapus. Tindakan ini tidak dapat dibatalkan.",variant:"danger",cancelLabel:"Kembali",okLabel:"Reset"})},k=async()=>{await L()&&location.reload()},v=async()=>{if(A.length>0){p(!0);return}await m()},y=()=>{Tg({idVisit:l.patientInfo.id_visit||new URLSearchParams(location.search).get("id_visit")||"",tipe:"rajal",title:"Riwayat Resume Rajal",zIndex:2147483647,onApply:I=>u(Mg(I,l))})};return(0,W.jsxs)("div",{className:"resume-modal",children:[(0,W.jsx)(nh,{title:"Resume Rawat Jalan",onClose:t,patientInfo:l.patientInfo}),(0,W.jsxs)("div",{className:"flex-1 overflow-y-auto px-5 py-4 space-y-3",children:[(0,W.jsx)(uu,{title:"Data Klinis",children:(0,W.jsx)(sh,{anamnesa:l.clinicalNotes.anamnesa,pemeriksaan:l.clinicalNotes.pemeriksaan_fisik,onChange:(I,M)=>x(I==="pemeriksaan"?"pemeriksaan_fisik":I,M)})}),(0,W.jsx)(uu,{title:"Tanda Vital",children:(0,W.jsx)(dh,{vitals:l.vitalSigns,onChange:(I,M)=>u({...l,vitalSigns:{...l.vitalSigns,[I]:M}})})}),(0,W.jsx)(uu,{title:"Catatan Medis",children:(0,W.jsxs)("div",{className:"space-y-3",children:[(0,W.jsxs)("div",{children:[(0,W.jsx)($a,{children:"Catatan Diagnosis"}),(0,W.jsx)(Rt,{value:l.clinicalNotes.catatan,onChange:I=>x("catatan",I.target.value),placeholder:"Catatan diagnosa...",rows:3})]}),(0,W.jsxs)("div",{children:[(0,W.jsx)($a,{children:"Tindakan"}),(0,W.jsx)(Rt,{value:l.clinicalNotes.tindakan,onChange:I=>x("tindakan",I.target.value),placeholder:"Tindakan...",rows:3})]}),(0,W.jsxs)("div",{children:[(0,W.jsx)($a,{children:"Terapi Pengobatan"}),(0,W.jsx)(Rt,{value:l.clinicalNotes.terapi_pengobatan,onChange:I=>x("terapi_pengobatan",I.target.value),placeholder:"Terapi pengobatan...",rows:3})]})]})}),(0,W.jsx)(uu,{title:`Diagnosis (ICD-10)${l.diagnosa.length>0?` (${l.diagnosa.length})`:""}`,children:(0,W.jsx)(hh,{rows:l.diagnosa,onChange:I=>u({...l,diagnosa:I})})}),(0,W.jsx)(uu,{title:`Tindakan (ICD-9)${l.tindakan.length>0?` (${l.tindakan.length})`:""}`,children:(0,W.jsx)(xh,{rows:l.tindakan,onChange:I=>u({...l,tindakan:I})})})]}),(0,W.jsx)(Lh,{errors:h,warnings:g}),(0,W.jsx)(Sh,{saving:o,hasErrors:d,lastSaved:s,onSave:v,onCancel:t,onRefresh:k,onHistory:y})]})}var Th=q(Ge(),1),ds=class extends Th.Component{constructor(){super(...arguments);this.state={hasError:!1}}static getDerivedStateFromError(){return{hasError:!0}}componentDidCatch(){this.props.onError()}render(){return this.state.hasError?null:this.props.children}};var pd=q(G(),1),fC=[{pattern:"periksa.*dokter",weight:1},{pattern:"konsultasi",weight:2},{pattern:"tindakan utama",weight:3},{pattern:"lab",weight:10},{pattern:"glukosa",weight:11},{pattern:"hba1c",weight:12},{pattern:"hb a1c",weight:12}];function wh(e){let a=new Map;return[...e].sort((t,l)=>{let u=o=>{let n=o.toLowerCase().trim();for(let s of fC)if(a.has(s.pattern)||a.set(s.pattern,new RegExp(s.pattern,"i")),a.get(s.pattern).test(n))return s.weight;return 999};return u(t)-u(l)})}function cC(e){if(!e)return"";let a=e.trim();return a?a.charAt(0).toUpperCase()+a.slice(1):""}function Mh(e){return e.map(cC).join(`
`)}function Bh(){let e=document.getElementById("pembayaran-gabung")||document.body,a=[],t=[],l=e.querySelectorAll("tr"),u=!1;for(let r of l){let i=r.textContent?.trim()||"";if(r.querySelector("b")&&!i.match(/^\d/)){u=!0;continue}if(u&&(i.includes("Total")||i.includes("Sub Total"))){u=!1;continue}if(u){let g=Array.from(r.querySelectorAll("td"));if(g.length>=5&&g[0]?.textContent?.trim().match(/^\d+\.?$/)){let f=g[2]?.textContent?.trim()||"",c=g[4]?.textContent?.trim()||"1";a.push(c&&c!=="1"?`${f} (${c})`:f)}}}let o=Array.from(e.querySelectorAll("b")).find(r=>r.textContent?.includes("Biaya Resep"));if(o){let r=o.closest("tr")?.nextElementSibling;for(;r&&!r.textContent?.includes("Sub Total");){if(r.getAttribute("valign")==="top"){let i=Array.from(r.querySelectorAll("td")),p=i[1]?.textContent?.trim()||"",g=p.match(/^\d+\s+(.*)/),f=g?g[1]:p,c=i[2]?.textContent?.trim()||"";t.push(c?`${f} Jml: ${c}`:f)}r=r.nextElementSibling}}let n=wh(a),s=wh(t);return{tindakan:Mh(n),terapiPengobatan:Mh(s)}}var Bv=location.pathname.includes("rm-rawat-jalan-new");var mC="/admisi/pelaksanaan_pelayanan/control/rm-rawat-jalan-refaktor?sub=simpan",Ut=null,su=null;function pC(){let e=document.getElementById("resume-view");if(!e)return null;let a=s=>{let r=e.querySelectorAll("table table tr, fieldset table tr");for(let i of r){let p=i.querySelectorAll("td");for(let g=0;g<p.length;g++)if(p[g].textContent?.trim()===s&&p[g+1]){let f=p[g+1];return(f.textContent?.trim()===":"?p[g+2]:f)?.textContent?.trim()||""}}return""},t=()=>{let s=Array.from(e.querySelectorAll("tr")).find(g=>g.textContent?.includes("Hasil Pemeriksaan Fisik"));if(!s)return"";let r=s.querySelector("td:last-child table, td[colspan] table");if(!r)return"";let i=Array.from(r.querySelectorAll("tr")).find(g=>{let f=g.querySelectorAll("td");return Array.from(f).some(c=>c.textContent?.trim()==="Lainnya")});if(!i)return"";let p=i.querySelectorAll("td");for(let g=0;g<p.length;g++)if(p[g].textContent?.trim()==="Lainnya"&&g+2<p.length){let f=p[g+2]?.textContent?.trim()||"",c=["Tensi:","Nadi:","Suhu:","Nafas:","Tinggi:","Berat:","Lainnya:"];return f.split(`
`).filter(S=>{let b=S.trim();return b&&!c.some(A=>b.startsWith(A))}).join(`
`)}return""},l=s=>{let r=Array.from(e.querySelectorAll("tr")).find(g=>g.textContent?.includes("Hasil Pemeriksaan Fisik"));if(!r)return"";let i=r.querySelector("td:last-child table, td[colspan] table");if(!i)return"";let p=i.querySelectorAll("tr");for(let g of p){let f=g.querySelectorAll("td");for(let c=0;c<f.length;c++)if(f[c].textContent?.trim()===s&&f[c+1]){let S=f[c+1];return(S.textContent?.trim()===":"?f[c+2]:S)?.textContent?.trim()||""}}return""},u=[],o=Array.from(e.querySelectorAll("tr")).find(s=>s.textContent?.includes("ICD X"));if(o){let s=o.querySelector("td:last-child table, td[colspan] table");if(s){let r=s.querySelectorAll("tr");for(let i of r){let g=(i.textContent?.trim()||"").match(/-\s*(.+?)\s*\(([^)]+)\)\s*-/);g&&u.push({idicd:"",kode10:g[2],namaDiagnosa:g[1],kasus:"",komplikasi:""})}}}let n=[];return{patientInfo:{norm:a("No. Rekam Medis"),pasien:a("Nama Pasien"),nama_dokter:""},clinicalNotes:{anamnesa:a("Anamnesa"),pemeriksaan_fisik:t(),catatan:a("Diagnosa"),tindakan:a("Tindakan"),terapi_pengobatan:a("Terapi Pengobatan")},vitalSigns:{tensi:l("Tensi"),nadi:l("Nadi"),suhu:l("Suhu"),nafas:l("Nafas"),tinggi:l("Tinggi"),berat:l("Berat")},diagnosa:u,tindakan:n}}function gC(){let e=pC(),a=document,t=f=>a.getElementById(f)?.value||"",l=f=>{let c=a.querySelector(`textarea[name="${f}"], input[name="${f}"], #${f}, select[name="${f}"]`);return c?"tagName"in c&&c.tagName==="SELECT"?c.value:c.value||"":""},u=f=>a.querySelector(`input[name="${f}"]:checked`)?.value||"",o={norm:t("norm")||t("no_rm"),pasien:t("pasien")||t("nama_pasien"),nama_dokter:t("nama_dokter")||t("dokter"),id_visit:t("id_visit")||new URLSearchParams(location.search).get("id_visit")||(typeof R?.id_visit=="string"?R.id_visit:""),id_rawat_jalan:t("id_rawat_jalan")||new URLSearchParams(location.search).get("id")||(typeof R?.id_rawat_jalan=="string"?R.id_rawat_jalan:""),id_user:t("id_user")||(typeof R?.id_user=="string"?R.id_user:"")||"1",id_dokter:t("id_dokter")||(typeof R?.id_dokter=="string"?R.id_dokter:""),id_bed:t("id_bed")||(typeof R?.id_bed=="string"?R.id_bed:""),noregis:t("noregis")||(typeof R?.noregis=="string"?R.noregis:"")},n={anamnesa:l("anamnesa"),pemeriksaan_fisik:l("pemeriksaan_fisik")||l("pemeriksaan")||l("fisik")||"",catatan:l("catatan")||"",tindakan:l("tindakan")||l("namaTindakan"),terapi_pengobatan:l("terapi_pengobatan")||"",jenis_kasus:l("jenis_kasus"),status_kasus:u("status_kasus"),tindak_lanjut:l("tindak_lanjut")},s={tensi:t("tensi"),nadi:t("nadi"),suhu:t("suhu"),nafas:t("nafas"),tinggi:t("tinggi"),berat:t("berat")},r=[],i=a.querySelectorAll('input[name="kode10[]"], input[name="kode[]"]');if(i.length===0){let f=1;for(;a.getElementById(`kode${f}`)||a.querySelector(`input[name="kode10[]"]:nth-child(${f})`);){let c=t(`idicd${f}`)||"",S=t(`kode${f}`)||"",b=t(`nama${f}`)||"";(S||b)&&r.push({idicd:c,kode10:S,namaDiagnosa:b,kasus:"",komplikasi:""}),f++}}else i.forEach(f=>{let c=f.closest("tr");if(!c)return;let S=c.querySelector('input[name="idicd[]"], input[name="idicd"]')?.value||"",b=f.value||"",A=c.querySelector('input[name="namaDiagnosa[]"], input[name="nama[]"]')?.value||"",h=c.querySelector('select[name="kasus_diagnosa[]"], select[name="kasus[]"]')?.value||"",d=c.querySelector('select[name="komplikasi[]"]')?.value||"";(b||A)&&r.push({idicd:S,kode10:b,namaDiagnosa:A,kasus:h,komplikasi:d})});if(r.length===0&&R){let f=Array.isArray(R["kode10[]"])?R["kode10[]"]:[],c=Array.isArray(R["nama[]"])?R["nama[]"]:[],S=Array.isArray(R["idicd[]"])?R["idicd[]"]:[],b=Array.isArray(R["kasus_diagnosa[]"])?R["kasus_diagnosa[]"]:[],A=Array.isArray(R["komplikasi[]"])?R["komplikasi[]"]:[];f.forEach((h,d)=>{h&&r.push({idicd:S[d]||"",kode10:h,namaDiagnosa:c[d]||"",kasus:b[d]||"",komplikasi:A[d]||""})})}let p=[];if(a.querySelectorAll('input[name="kode9[]"]').forEach(f=>{let c=f.closest("tr");if(!c)return;let S=f.value||"";if(!S)return;let b=c.querySelector('input[name="idicdTindakan[]"]')?.value||"",A=c.querySelector('input[name="namaTindakan[]"]')?.value||"",h=c.querySelector('select[name="komorbid[]"]')?.value||"",d=c.querySelector('select[name="kategoriProsedur[]"]')?.value||"";p.push({idicdTindakan:b,kode9:S,namaTindakan:A,komorbid:h,kategoriProsedur:d,snomedProsedur:"",codeProsedur:""})}),p.length===0&&R){let f=Array.isArray(R["kode9[]"])?R["kode9[]"]:[],c=Array.isArray(R["namaTindakan[]"])?R["namaTindakan[]"]:[],S=Array.isArray(R["idicdTindakan[]"])?R["idicdTindakan[]"]:[],b=Array.isArray(R["komorbid[]"])?R["komorbid[]"]:[],A=Array.isArray(R["kategoriProsedur[]"])?R["kategoriProsedur[]"]:[];f.forEach((h,d)=>{h&&p.push({idicdTindakan:S[d]||"",kode9:h,namaTindakan:c[d]||"",komorbid:b[d]||"",kategoriProsedur:A[d]||""})})}if(e&&(o.norm=o.norm||e.patientInfo.norm,o.pasien=o.pasien||e.patientInfo.pasien,o.nama_dokter=o.nama_dokter||e.patientInfo.nama_dokter,n.anamnesa=n.anamnesa||e.clinicalNotes.anamnesa,n.pemeriksaan_fisik=n.pemeriksaan_fisik||e.clinicalNotes.pemeriksaan_fisik,n.catatan=n.catatan||e.clinicalNotes.catatan,n.tindakan=n.tindakan||e.clinicalNotes.tindakan,n.terapi_pengobatan=n.terapi_pengobatan||e.clinicalNotes.terapi_pengobatan,s.tensi=s.tensi||e.vitalSigns.tensi,s.nadi=s.nadi||e.vitalSigns.nadi,s.suhu=s.suhu||e.vitalSigns.suhu,s.nafas=s.nafas||e.vitalSigns.nafas,s.tinggi=s.tinggi||e.vitalSigns.tinggi,s.berat=s.berat||e.vitalSigns.berat,r.length===0&&r.push(...e.diagnosa),p.length===0&&p.push(...e.tindakan)),!n.tindakan||n.tindakan==="-"||!n.terapi_pengobatan||n.terapi_pengobatan==="-"){let f=Bh();f.tindakan&&(!n.tindakan||n.tindakan==="-")&&(n.tindakan=f.tindakan),f.terapiPengobatan&&(!n.terapi_pengobatan||n.terapi_pengobatan==="-")&&(n.terapi_pengobatan=f.terapiPengobatan)}if(R){let f={anamnesa:n.anamnesa,pemeriksaan_fisik:n.pemeriksaan_fisik,catatan:n.catatan,tindakan:n.tindakan,terapi_pengobatan:n.terapi_pengobatan};for(let[c,S]of Object.entries(f))if(!S||S==="-"){let b=R[c];typeof b=="string"&&b&&(n[c]=b)}}return{patientInfo:o,clinicalNotes:n,vitalSigns:s,diagnosa:r,tindakan:p}}function hC(e){let a=new URLSearchParams,t=document.getElementById("formdata");if(t)new FormData(t).forEach((k,v)=>{typeof k=="string"&&a.append(v,k)});else if(R)for(let[L,k]of Object.entries(R))if(Array.isArray(k))for(let v of k)a.append(L,v);else a.set(L,k);let l=(L,k)=>{k&&(a.get(L)||a.set(L,k))},u=L=>e.patientInfo?.[L]||"",o=L=>document.querySelector(`[name="${L}"]`)?.value||"",n=L=>typeof R?.[L]=="string"?R[L]:"",s=e.patientInfo.id_visit||new URLSearchParams(location.search).get("id_visit")||"",r=e.patientInfo.id_rawat_jalan||new URLSearchParams(location.search).get("id")||"";l("id_visit",s),l("id_rawat_jalan",r),l("id_user",n("id_user")||"1"),a.get("id_kunjungan")||a.set("id_kunjungan",o("id_kunjungan")||n("id_kunjungan")||r||s);for(let L of["norm","ihs_number","ihs_number_dokter","waktu_visit","nama_pasien","id_bed","id_dokter","nama_dokter","planning","pasien","noregis"]){if(a.get(L))continue;let k=u(L)||o(L)||n(L);k&&a.set(L,k)}if(!a.get("waktu")){let L=new Date,k=v=>String(v).padStart(2,"0");a.set("waktu",`${k(L.getDate())}/${k(L.getMonth()+1)}/${L.getFullYear()} ${k(L.getHours())}:${k(L.getMinutes())}:${k(L.getSeconds())}`)}for(let L of["nama_pasien","planning","waktu_visit"])a.has(L)||a.set(L,u(L)||n(L)||"");let i=["kode10[]","idicd[]","nama[]","keterangan10[]","kasus_diagnosa[]","komplikasi[]","namaTindakan[]","kode9[]","idicdTindakan[]","komorbid[]","kategoriProsedur[]","snomedProsedur[]","codeProsedur[]"];for(let L of i)a.delete(L);for(let L=1;L<=50;L++)a.delete(`ic${L}`);let p=L=>(L||"").replace(/\n/g,"<br/>");a.set("anamnesa",p(e.clinicalNotes.anamnesa)),a.set("pemeriksaan_fisik",p(e.clinicalNotes.pemeriksaan_fisik)),a.set("catatan",p(e.clinicalNotes.catatan)),a.set("tindakan",p(e.clinicalNotes.tindakan)),a.set("terapi_pengobatan",p(e.clinicalNotes.terapi_pengobatan));let g=L=>(L||"").match(/^([\d/.]+)/)?.[0]||"";a.set("tensi",g(e.vitalSigns.tensi)),a.set("nadi",g(e.vitalSigns.nadi)),a.set("suhu",g(e.vitalSigns.suhu)),a.set("nafas",g(e.vitalSigns.nafas)),a.set("spo2",g(e.vitalSigns.spo2)),a.set("tinggi",g(e.vitalSigns.tinggi)),a.set("berat",g(e.vitalSigns.berat));let f=Array.isArray(R?.["kode10[]"])?R["kode10[]"]:[],c=Array.isArray(R?.["idicd[]"])?R["idicd[]"]:[],S=Array.isArray(R?.["keterangan10[]"])?R["keterangan10[]"]:[];e.diagnosa.filter(L=>L.idicd?.trim()&&L.kode10?.trim()&&L.namaDiagnosa?.trim()).filter((L,k,v)=>v.findIndex(y=>y.idicd===L.idicd)===k).forEach(L=>{let k=L.idicd;if(!k&&L.kode10){let I=f.indexOf(L.kode10);I>=0&&c[I]&&(k=c[I])}let v=c.indexOf(k),y=v>=0&&S[v]||"";a.append("nama[]",L.namaDiagnosa),a.append("idicd[]",k),a.append("kode10[]",L.kode10),a.append("keterangan10[]",y),a.append("kasus_diagnosa[]",L.kasus||""),a.append("komplikasi[]",L.komplikasi||"")});let A=Array.isArray(R?.["idicdTindakan[]"])?R["idicdTindakan[]"]:[],h=e.tindakan.filter(L=>L.idicdTindakan?.trim()&&L.kode9?.trim()&&L.namaTindakan?.trim()).filter((L,k,v)=>v.findIndex(y=>y.idicdTindakan===L.idicdTindakan&&y.kode9===L.kode9)===k),d=L=>{let k=A.indexOf(L);return k>=0?n(`ic${k+1}`):""};h.forEach(L=>{a.append("namaTindakan[]",L.namaTindakan),a.append("kode9[]",L.kode9),a.append("idicdTindakan[]",L.idicdTindakan),a.append("komorbid[]",L.komorbid||"");let k=d(L.idicdTindakan);k&&a.append(`ic${A.indexOf(L.idicdTindakan)+1}`,k)});let m={};for(let L of["id_visit","id_rawat_jalan","id_kunjungan","id_user","norm","ihs_number","ihs_number_dokter","waktu_visit","nama_pasien","waktu","id_bed","id_dokter","nama_dokter","planning","jenis_kasus","save"])m[L]=a.get(L)||"(missing)";let x=Object.entries(m).filter(([,L])=>L==="(missing)").map(([L])=>L);return console.log(`[RJ] payload: ${a.size} key, ${Oh.length} dari form,`,x.length?`MISSING: ${x.join(", ")}`:"semua field wajib ada"),console.debug("[RJ] key values:",m),a.toString()}function xC(e){return hC(e)}function md(e){Ut&&(Ut.unmount(),Ut=null);try{e.innerHTML="",e.style.display="none"}catch{}let t=document.getElementById("morbis-manap-root")?.shadowRoot?.getElementById("ext-resume-shadow-container");if(t){try{t._reactRoot?.unmount?.()}catch{}t.remove()}document.body.classList.remove("ext-resume-open"),su&&(su.disabled=!1,su.style.display="");let l=document.querySelector("[data-scroll-buttons]");l&&(l.style.display="")}function LC(e,a){if(Ut){try{Ut.unmount()}catch{}Ut=null}try{e.innerHTML=""}catch{}if(!document.getElementById("morbis-resume-fonts")){let i=document.createElement("link");i.id="morbis-resume-fonts",i.rel="stylesheet",i.href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400;1,700&family=Lexend:wght@400;500;600;700&family=Roboto:wght@400;500;600;700&display=swap",document.head.appendChild(i)}let l=(()=>{let i=document.getElementById("morbis-manap-root");if(i?.shadowRoot)return i.shadowRoot;if(i&&!i.shadowRoot)return null;i=document.createElement("div"),i.id="morbis-manap-root",i.style.cssText="position:fixed;inset:0;z-index:2147483647;pointer-events:none;display:block",document.body.appendChild(i);let p=i.attachShadow({mode:"open"}),g=document.createElement("div");g.id="app",p.appendChild(g);let f=document.createElement("style");f.id="morbis-shadow-reset",f.textContent=":host{display:block}#app{isolation:isolate;color-scheme:light}",p.appendChild(f);try{let c=`/* shadow-dom base */
*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
/* ! tailwindcss v3.4.19 | MIT License | https://tailwindcss.com *//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  /* ponytail: senior preset \u2014 :root for popup/sidepanel, :host+#app for Shadow DOM (resume modals).
     Keep in sync: edit :root. */
  :root,
  :host,
  #app {
    --background: 0 0% 100%;
    --foreground: 222.2 47% 11%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 47% 11%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 47% 11%;
    --primary: 221.2 83% 53%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 47% 11%;
    --muted: 210 40% 96%;
    --muted-foreground: 215 20% 35%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 47% 11%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 210 40% 98%;
    --border: 214 32% 72%;
    --input: 214 32% 72%;
    --ring: 221 83% 53%;
    --radius: 0.75rem;
    --warning: 38 92% 50%;
    --warning-foreground: 48 96% 12%;
  }

  /* ponytail: Shadow DOM needs its own color-scheme + base reset; :host isolates from page CSS */
  :host {
    all: initial;
  }
  #app {
    color-scheme: light;
    isolation: isolate;
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    box-sizing: border-box;
  }
  #app *,
  #app *::before,
  #app *::after {
    box-sizing: border-box;
  }

  @theme inline {
    --color-warning: var(--warning);
    --color-warning-foreground: var(--warning-foreground);
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 48%;
    --md-scrollbar: #484d54;
  }

  ::-moz-selection {
    background: #2469f0;
    color: white;
  }

  ::selection {
    background: #2469f0;
    color: white;
  }

  * {
    scrollbar-width: thin;
    scrollbar-color: #c9cdd4 transparent;
  }

  .dark * {
    scrollbar-color: var(--md-scrollbar) transparent;
  }

  *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  *::-webkit-scrollbar-track {
    background: transparent;
  }

  *::-webkit-scrollbar-thumb {
    background: #c9cdd4;
    border-radius: 3px;
  }

  .dark *::-webkit-scrollbar-thumb {
    background: var(--md-scrollbar);
  }

  *::-webkit-scrollbar-thumb:hover {
    background: #a4a9b3;
  }

  .dark *::-webkit-scrollbar-thumb:hover {
    background: #636971;
  }
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {
  .\\!container {
    max-width: 640px !important;
  }
  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {
  .\\!container {
    max-width: 768px !important;
  }
  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {
  .\\!container {
    max-width: 1024px !important;
  }
  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {
  .\\!container {
    max-width: 1280px !important;
  }
  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {
  .\\!container {
    max-width: 1536px !important;
  }
  .container {
    max-width: 1536px;
  }
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.pointer-events-none {
  pointer-events: none;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.collapse {
  visibility: collapse;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-4 {
  bottom: 1rem;
}
.left-1\\/2 {
  left: 50%;
}
.right-4 {
  right: 1rem;
}
.top-1\\/2 {
  top: 50%;
}
.z-10 {
  z-index: 10;
}
.z-50 {
  z-index: 50;
}
.z-\\[1\\] {
  z-index: 1;
}
.z-\\[2147483647\\] {
  z-index: 2147483647;
}
.col-span-full {
  grid-column: 1 / -1;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.-mb-\\[1px\\] {
  margin-bottom: -1px;
}
.mb-1 {
  margin-bottom: 0.25rem;
}
.mb-1\\.5 {
  margin-bottom: 0.375rem;
}
.mb-2 {
  margin-bottom: 0.5rem;
}
.mb-3 {
  margin-bottom: 0.75rem;
}
.mb-4 {
  margin-bottom: 1rem;
}
.ml-1 {
  margin-left: 0.25rem;
}
.mr-1 {
  margin-right: 0.25rem;
}
.mr-2 {
  margin-right: 0.5rem;
}
.mr-3 {
  margin-right: 0.75rem;
}
.mr-auto {
  margin-right: auto;
}
.mt-0\\.5 {
  margin-top: 0.125rem;
}
.mt-1 {
  margin-top: 0.25rem;
}
.mt-2 {
  margin-top: 0.5rem;
}
.mt-3 {
  margin-top: 0.75rem;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.\\!contents {
  display: contents !important;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-1\\.5 {
  width: 0.375rem;
  height: 0.375rem;
}
.size-10 {
  width: 2.5rem;
  height: 2.5rem;
}
.size-3 {
  width: 0.75rem;
  height: 0.75rem;
}
.size-3\\.5 {
  width: 0.875rem;
  height: 0.875rem;
}
.size-4 {
  width: 1rem;
  height: 1rem;
}
.size-5 {
  width: 1.25rem;
  height: 1.25rem;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.h-1 {
  height: 0.25rem;
}
.h-10 {
  height: 2.5rem;
}
.h-11 {
  height: 2.75rem;
}
.h-12 {
  height: 3rem;
}
.h-2 {
  height: 0.5rem;
}
.h-24 {
  height: 6rem;
}
.h-4 {
  height: 1rem;
}
.h-5 {
  height: 1.25rem;
}
.h-6 {
  height: 1.5rem;
}
.h-7 {
  height: 1.75rem;
}
.h-8 {
  height: 2rem;
}
.h-9 {
  height: 2.25rem;
}
.h-\\[300px\\] {
  height: 300px;
}
.h-\\[var\\(--radix-select-trigger-height\\)\\] {
  height: var(--radix-select-trigger-height);
}
.h-full {
  height: 100%;
}
.max-h-60 {
  max-height: 15rem;
}
.max-h-\\[220px\\] {
  max-height: 220px;
}
.max-h-\\[280px\\] {
  max-height: 280px;
}
.max-h-\\[360px\\] {
  max-height: 360px;
}
.max-h-\\[420px\\] {
  max-height: 420px;
}
.max-h-\\[600px\\] {
  max-height: 600px;
}
.min-h-11 {
  min-height: 2.75rem;
}
.min-h-\\[200px\\] {
  min-height: 200px;
}
.min-h-\\[80px\\] {
  min-height: 80px;
}
.w-10 {
  width: 2.5rem;
}
.w-11 {
  width: 2.75rem;
}
.w-12 {
  width: 3rem;
}
.w-2 {
  width: 0.5rem;
}
.w-28 {
  width: 7rem;
}
.w-4 {
  width: 1rem;
}
.w-5 {
  width: 1.25rem;
}
.w-6 {
  width: 1.5rem;
}
.w-7 {
  width: 1.75rem;
}
.w-9 {
  width: 2.25rem;
}
.w-\\[100px\\] {
  width: 100px;
}
.w-\\[120px\\] {
  width: 120px;
}
.w-\\[340px\\] {
  width: 340px;
}
.w-\\[76px\\] {
  width: 76px;
}
.w-\\[90px\\] {
  width: 90px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-0 {
  min-width: 0px;
}
.min-w-\\[100px\\] {
  min-width: 100px;
}
.min-w-\\[110px\\] {
  min-width: 110px;
}
.min-w-\\[12rem\\] {
  min-width: 12rem;
}
.min-w-\\[80px\\] {
  min-width: 80px;
}
.min-w-\\[90px\\] {
  min-width: 90px;
}
.min-w-\\[var\\(--radix-select-trigger-width\\)\\] {
  min-width: var(--radix-select-trigger-width);
}
.max-w-\\[120px\\] {
  max-width: 120px;
}
.max-w-\\[140px\\] {
  max-width: 140px;
}
.max-w-\\[200px\\] {
  max-width: 200px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-90 {
  --tw-scale-x: .9;
  --tw-scale-y: .9;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes pulse {
  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes slide-up {
  0% {
    opacity: 0;
    transform: translateY(8px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
.animate-slide-up {
  animation: slide-up 0.15s ease-out;
}
.cursor-default {
  cursor: default;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize-y {
  resize: vertical;
}
.resize {
  resize: both;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-center {
  align-items: center;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0 {
  gap: 0px;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-1\\.5 {
  gap: 0.375rem;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-2\\.5 {
  gap: 0.625rem;
}
.gap-3 {
  gap: 0.75rem;
}
.gap-4 {
  gap: 1rem;
}
.gap-x-8 {
  -moz-column-gap: 2rem;
       column-gap: 2rem;
}
.gap-y-3 {
  row-gap: 0.75rem;
}
.space-y-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.125rem * var(--tw-space-y-reverse));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}
.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.5rem * var(--tw-space-y-reverse));
}
.space-y-2\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.625rem * var(--tw-space-y-reverse));
}
.space-y-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}
.space-y-5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1.25rem * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.divide-border > :not([hidden]) ~ :not([hidden]) {
  border-color: hsl(var(--border));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-y-auto {
  overflow-y: auto;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.break-words {
  overflow-wrap: break-word;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 0.5rem;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.rounded-b-2xl {
  border-bottom-right-radius: 1rem;
  border-bottom-left-radius: 1rem;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l-2 {
  border-left-width: 2px;
}
.border-t {
  border-top-width: 1px;
}
.border-t-2 {
  border-top-width: 2px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-\\[\\#2469f0\\] {
  --tw-border-opacity: 1;
  border-color: rgb(36 105 240 / var(--tw-border-opacity, 1));
}
.border-amber-200 {
  --tw-border-opacity: 1;
  border-color: rgb(253 230 138 / var(--tw-border-opacity, 1));
}
.border-border {
  border-color: hsl(var(--border));
}
.border-destructive {
  border-color: hsl(var(--destructive));
}
.border-destructive\\/20 {
  border-color: hsl(var(--destructive) / 0.2);
}
.border-foreground {
  border-color: hsl(var(--foreground));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-input {
  border-color: hsl(var(--input));
}
.border-primary {
  border-color: hsl(var(--primary));
}
.border-primary\\/20 {
  border-color: hsl(var(--primary) / 0.2);
}
.border-primary\\/50 {
  border-color: hsl(var(--primary) / 0.5);
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.bg-\\[\\#2469f0\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(36 105 240 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  background-color: hsl(var(--accent));
}
.bg-accent\\/20 {
  background-color: hsl(var(--accent) / 0.2);
}
.bg-accent\\/40 {
  background-color: hsl(var(--accent) / 0.4);
}
.bg-accent\\/50 {
  background-color: hsl(var(--accent) / 0.5);
}
.bg-amber-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}
.bg-amber-50\\/50 {
  background-color: rgb(255 251 235 / 0.5);
}
.bg-background {
  background-color: hsl(var(--background));
}
.bg-background\\/60 {
  background-color: hsl(var(--background) / 0.6);
}
.bg-blue-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}
.bg-border {
  background-color: hsl(var(--border));
}
.bg-card {
  background-color: hsl(var(--card));
}
.bg-destructive {
  background-color: hsl(var(--destructive));
}
.bg-destructive\\/10 {
  background-color: hsl(var(--destructive) / 0.1);
}
.bg-destructive\\/5 {
  background-color: hsl(var(--destructive) / 0.05);
}
.bg-foreground {
  background-color: hsl(var(--foreground));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}
.bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}
.bg-green-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}
.bg-green-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));
}
.bg-green-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.bg-muted {
  background-color: hsl(var(--muted));
}
.bg-muted-foreground {
  background-color: hsl(var(--muted-foreground));
}
.bg-muted\\/40 {
  background-color: hsl(var(--muted) / 0.4);
}
.bg-neutral-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.bg-popover {
  background-color: hsl(var(--popover));
}
.bg-primary {
  background-color: hsl(var(--primary));
}
.bg-primary\\/10 {
  background-color: hsl(var(--primary) / 0.1);
}
.bg-primary\\/5 {
  background-color: hsl(var(--primary) / 0.05);
}
.bg-red-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}
.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}
.bg-red-500\\/5 {
  background-color: rgb(239 68 68 / 0.05);
}
.bg-red-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}
.bg-secondary {
  background-color: hsl(var(--secondary));
}
.bg-white\\/15 {
  background-color: rgb(255 255 255 / 0.15);
}
.bg-yellow-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}
.bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}
.from-muted {
  --tw-gradient-from: hsl(var(--muted)) var(--tw-gradient-from-position);
  --tw-gradient-to: hsl(var(--muted) / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.to-muted\\/50 {
  --tw-gradient-to: hsl(var(--muted) / 0.5) var(--tw-gradient-to-position);
}
.p-0\\.5 {
  padding: 0.125rem;
}
.p-1 {
  padding: 0.25rem;
}
.p-1\\.5 {
  padding: 0.375rem;
}
.p-2 {
  padding: 0.5rem;
}
.p-2\\.5 {
  padding: 0.625rem;
}
.p-3 {
  padding: 0.75rem;
}
.p-4 {
  padding: 1rem;
}
.p-5 {
  padding: 1.25rem;
}
.p-8 {
  padding: 2rem;
}
.px-1 {
  padding-left: 0.25rem;
  padding-right: 0.25rem;
}
.px-1\\.5 {
  padding-left: 0.375rem;
  padding-right: 0.375rem;
}
.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}
.px-2\\.5 {
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}
.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}
.px-3\\.5 {
  padding-left: 0.875rem;
  padding-right: 0.875rem;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-5 {
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}
.px-7 {
  padding-left: 1.75rem;
  padding-right: 1.75rem;
}
.py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}
.py-0\\.5 {
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
}
.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}
.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}
.py-12 {
  padding-top: 3rem;
  padding-bottom: 3rem;
}
.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
.py-2\\.5 {
  padding-top: 0.625rem;
  padding-bottom: 0.625rem;
}
.py-3 {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}
.py-3\\.5 {
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
}
.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}
.py-6 {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}
.pb-1\\.5 {
  padding-bottom: 0.375rem;
}
.pb-2 {
  padding-bottom: 0.5rem;
}
.pr-20 {
  padding-right: 5rem;
}
.pt-3 {
  padding-top: 0.75rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.font-\\[\\'Roboto\\'\\2c \\'Segoe_UI\\'\\2c system-ui\\2c sans-serif\\] {
  font-family: 'Roboto','Segoe UI',system-ui,sans-serif;
}
.font-mono {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace;
}
.text-\\[10px\\] {
  font-size: 10px;
}
.text-\\[11px\\] {
  font-size: 11px;
}
.text-\\[8px\\] {
  font-size: 8px;
}
.text-\\[9px\\] {
  font-size: 9px;
}
.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-md-sm {
  font-size: 12px;
  line-height: 18px;
}
.text-md-xs {
  font-size: 11px;
  line-height: 16px;
}
.text-xl {
  font-size: 1.25rem;
  line-height: 1.75rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.text-xxl {
  font-size: 22px;
  line-height: 28px;
}
.font-bold {
  font-weight: 700;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.italic {
  font-style: italic;
}
.leading-\\[1\\.6\\] {
  line-height: 1.6;
}
.leading-\\[1\\.7\\] {
  line-height: 1.7;
}
.leading-normal {
  line-height: 1.5;
}
.leading-relaxed {
  line-height: 1.625;
}
.leading-snug {
  line-height: 1.375;
}
.leading-tight {
  line-height: 1.25;
}
.tracking-\\[0\\.03em\\] {
  letter-spacing: 0.03em;
}
.tracking-tight {
  letter-spacing: -0.025em;
}
.tracking-wide {
  letter-spacing: 0.025em;
}
.tracking-wider {
  letter-spacing: 0.05em;
}
.text-\\[\\#2469f0\\] {
  --tw-text-opacity: 1;
  color: rgb(36 105 240 / var(--tw-text-opacity, 1));
}
.text-amber-700 {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}
.text-background {
  color: hsl(var(--background));
}
.text-blue-700 {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}
.text-card-foreground {
  color: hsl(var(--card-foreground));
}
.text-destructive {
  color: hsl(var(--destructive));
}
.text-destructive-foreground {
  color: hsl(var(--destructive-foreground));
}
.text-destructive\\/80 {
  color: hsl(var(--destructive) / 0.8);
}
.text-foreground {
  color: hsl(var(--foreground));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}
.text-green-50 {
  --tw-text-opacity: 1;
  color: rgb(240 253 244 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-700 {
  --tw-text-opacity: 1;
  color: rgb(21 128 61 / var(--tw-text-opacity, 1));
}
.text-muted-foreground {
  color: hsl(var(--muted-foreground));
}
.text-popover-foreground {
  color: hsl(var(--popover-foreground));
}
.text-primary {
  color: hsl(var(--primary));
}
.text-primary-foreground {
  color: hsl(var(--primary-foreground));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity, 1));
}
.text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity, 1));
}
.text-red-900 {
  --tw-text-opacity: 1;
  color: rgb(127 29 29 / var(--tw-text-opacity, 1));
}
.text-secondary-foreground {
  color: hsl(var(--secondary-foreground));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-white\\/80 {
  color: rgb(255 255 255 / 0.8);
}
.text-white\\/90 {
  color: rgb(255 255 255 / 0.9);
}
.text-yellow-600 {
  --tw-text-opacity: 1;
  color: rgb(202 138 4 / var(--tw-text-opacity, 1));
}
.text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity, 1));
}
.text-yellow-800 {
  --tw-text-opacity: 1;
  color: rgb(133 77 14 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.underline-offset-4 {
  text-underline-offset: 4px;
}
.antialiased {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.opacity-0 {
  opacity: 0;
}
.opacity-30 {
  opacity: 0.3;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-60 {
  opacity: 0.6;
}
.opacity-85 {
  opacity: 0.85;
}
.opacity-90 {
  opacity: 0.9;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.grayscale {
  --tw-grayscale: grayscale(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.duration-300 {
  transition-duration: 300ms;
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
@keyframes enter {
  from {
    opacity: var(--tw-enter-opacity, 1);
    transform: translate3d(var(--tw-enter-translate-x, 0), var(--tw-enter-translate-y, 0), 0) scale3d(var(--tw-enter-scale, 1), var(--tw-enter-scale, 1), var(--tw-enter-scale, 1)) rotate(var(--tw-enter-rotate, 0));
  }
}
@keyframes exit {
  to {
    opacity: var(--tw-exit-opacity, 1);
    transform: translate3d(var(--tw-exit-translate-x, 0), var(--tw-exit-translate-y, 0), 0) scale3d(var(--tw-exit-scale, 1), var(--tw-exit-scale, 1), var(--tw-exit-scale, 1)) rotate(var(--tw-exit-rotate, 0));
  }
}
.animate-in {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.fade-in {
  --tw-enter-opacity: 0;
}
.fade-out {
  --tw-exit-opacity: 0;
}
.duration-200 {
  animation-duration: 200ms;
}
.duration-300 {
  animation-duration: 300ms;
}
.ease-in-out {
  animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.running {
  animation-play-state: running;
}
.placeholder\\:text-muted-foreground::-moz-placeholder {
  color: hsl(var(--muted-foreground));
}
.placeholder\\:text-muted-foreground::placeholder {
  color: hsl(var(--muted-foreground));
}
.last\\:border-b-0:last-child {
  border-bottom-width: 0px;
}
.hover\\:bg-accent:hover {
  background-color: hsl(var(--accent));
}
.hover\\:bg-amber-100\\/50:hover {
  background-color: rgb(254 243 199 / 0.5);
}
.hover\\:bg-destructive\\/10:hover {
  background-color: hsl(var(--destructive) / 0.1);
}
.hover\\:bg-destructive\\/20:hover {
  background-color: hsl(var(--destructive) / 0.2);
}
.hover\\:bg-destructive\\/90:hover {
  background-color: hsl(var(--destructive) / 0.9);
}
.hover\\:bg-green-600\\/90:hover {
  background-color: rgb(22 163 74 / 0.9);
}
.hover\\:bg-green-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(21 128 61 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-neutral-900:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(23 23 23 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-primary\\/5:hover {
  background-color: hsl(var(--primary) / 0.05);
}
.hover\\:bg-primary\\/90:hover {
  background-color: hsl(var(--primary) / 0.9);
}
.hover\\:bg-red-500\\/10:hover {
  background-color: rgb(239 68 68 / 0.1);
}
.hover\\:bg-red-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-secondary\\/80:hover {
  background-color: hsl(var(--secondary) / 0.8);
}
.hover\\:bg-white\\/25:hover {
  background-color: rgb(255 255 255 / 0.25);
}
.hover\\:text-accent-foreground:hover {
  color: hsl(var(--accent-foreground));
}
.hover\\:text-destructive:hover {
  color: hsl(var(--destructive));
}
.hover\\:text-foreground:hover {
  color: hsl(var(--foreground));
}
.hover\\:text-red-600:hover {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.hover\\:underline:hover {
  text-decoration-line: underline;
}
.hover\\:opacity-70:hover {
  opacity: 0.7;
}
.focus\\:bg-accent:focus {
  background-color: hsl(var(--accent));
}
.focus\\:text-accent-foreground:focus {
  color: hsl(var(--accent-foreground));
}
.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-primary:focus {
  --tw-ring-color: hsl(var(--primary));
}
.focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity, 1));
}
.focus\\:ring-ring:focus {
  --tw-ring-color: hsl(var(--ring));
}
.focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}
.focus-visible\\:outline-none:focus-visible {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus-visible\\:ring-primary:focus-visible {
  --tw-ring-color: hsl(var(--primary));
}
.focus-visible\\:ring-ring:focus-visible {
  --tw-ring-color: hsl(var(--ring));
}
.focus-visible\\:ring-offset-1:focus-visible {
  --tw-ring-offset-width: 1px;
}
.focus-visible\\:ring-offset-2:focus-visible {
  --tw-ring-offset-width: 2px;
}
.active\\:bg-accent:active {
  background-color: hsl(var(--accent));
}
.active\\:bg-destructive:active {
  background-color: hsl(var(--destructive));
}
.active\\:bg-green-600:active {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.active\\:bg-neutral-950:active {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.active\\:bg-primary:active {
  background-color: hsl(var(--primary));
}
.active\\:bg-secondary:active {
  background-color: hsl(var(--secondary));
}
.disabled\\:pointer-events-none:disabled {
  pointer-events: none;
}
.disabled\\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}
.disabled\\:bg-muted:disabled {
  background-color: hsl(var(--muted));
}
.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}
.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}
.data-\\[disabled\\]\\:pointer-events-none[data-disabled] {
  pointer-events: none;
}
.data-\\[side\\=bottom\\]\\:translate-y-1[data-side="bottom"] {
  --tw-translate-y: 0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[side\\=top\\]\\:-translate-y-1[data-side="top"] {
  --tw-translate-y: -0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:translate-x-4[data-state="checked"] {
  --tw-translate-x: 1rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=unchecked\\]\\:translate-x-0[data-state="unchecked"] {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:bg-primary[data-state="checked"] {
  background-color: hsl(var(--primary));
}
.data-\\[state\\=unchecked\\]\\:bg-input[data-state="unchecked"] {
  background-color: hsl(var(--input));
}
.data-\\[disabled\\]\\:opacity-50[data-disabled] {
  opacity: 0.5;
}
.data-\\[state\\=open\\]\\:animate-in[data-state="open"] {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:animate-out[data-state="closed"] {
  animation-name: exit;
  animation-duration: 150ms;
  --tw-exit-opacity: initial;
  --tw-exit-scale: initial;
  --tw-exit-rotate: initial;
  --tw-exit-translate-x: initial;
  --tw-exit-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:fade-out-0[data-state="closed"] {
  --tw-exit-opacity: 0;
}
.data-\\[state\\=open\\]\\:fade-in-0[data-state="open"] {
  --tw-enter-opacity: 0;
}
.data-\\[state\\=closed\\]\\:zoom-out-95[data-state="closed"] {
  --tw-exit-scale: .95;
}
.data-\\[state\\=open\\]\\:zoom-in-95[data-state="open"] {
  --tw-enter-scale: .95;
}
@supports (backdrop-filter: var(--tw)) {
  .supports-\\[backdrop-filter\\]\\:bg-background\\/60 {
    background-color: hsl(var(--background) / 0.6);
  }
}
.dark\\:border-amber-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(146 64 14 / var(--tw-border-opacity, 1));
}
.dark\\:border-green-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 101 52 / var(--tw-border-opacity, 1));
}
.dark\\:border-red-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(127 29 29 / var(--tw-border-opacity, 1));
}
.dark\\:bg-amber-900\\/30:is(.dark *) {
  background-color: rgb(120 53 15 / 0.3);
}
.dark\\:bg-amber-950\\/20:is(.dark *) {
  background-color: rgb(69 26 3 / 0.2);
}
.dark\\:bg-blue-900\\/30:is(.dark *) {
  background-color: rgb(30 58 138 / 0.3);
}
.dark\\:bg-blue-950\\/20:is(.dark *) {
  background-color: rgb(23 37 84 / 0.2);
}
.dark\\:bg-green-950\\/20:is(.dark *) {
  background-color: rgb(5 46 22 / 0.2);
}
.dark\\:bg-red-950\\/20:is(.dark *) {
  background-color: rgb(69 10 10 / 0.2);
}
.dark\\:bg-yellow-950\\/30:is(.dark *) {
  background-color: rgb(66 32 6 / 0.3);
}
.dark\\:text-amber-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}
.dark\\:text-blue-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.dark\\:text-green-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 202 202 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
@media (min-width: 640px) {
  .sm\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
@media (min-width: 768px) {
  .md\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .md\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .md\\:text-left {
    text-align: left;
  }
}
@media (min-width: 1024px) {
  .lg\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
.\\[\\&\\>span\\]\\:line-clamp-1>span {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.\\[\\&\\>span\\]\\:h-3>span {
  height: 0.75rem;
}
.\\[\\&\\>span\\]\\:w-3>span {
  width: 0.75rem;
}
.data-\\[state\\=checked\\]\\:\\[\\&\\>span\\]\\:translate-x-3>span[data-state="checked"] {
  --tw-translate-x: 0.75rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.\\[\\&_svg\\]\\:pointer-events-none svg {
  pointer-events: none;
}
.\\[\\&_svg\\]\\:size-3\\.5 svg {
  width: 0.875rem;
  height: 0.875rem;
}
.\\[\\&_svg\\]\\:size-5 svg {
  width: 1.25rem;
  height: 1.25rem;
}
.\\[\\&_svg\\]\\:shrink-0 svg {
  flex-shrink: 0;
}
`;if(c=c.replace(/@import[^;]+;/g,""),c&&"adoptedStyleSheets"in p&&"CSSStyleSheet"in window)try{let S=new window.CSSStyleSheet;S.replaceSync(c),p.adoptedStyleSheets=[...p.adoptedStyleSheets,S]}catch{let S=document.createElement("style");S.textContent=c,p.appendChild(S)}else if(c){let S=document.createElement("style");S.textContent=c,p.appendChild(S)}}catch{}return p})(),o=`/* shadow-dom base */
*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
/* ! tailwindcss v3.4.19 | MIT License | https://tailwindcss.com *//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  /* ponytail: senior preset \u2014 :root for popup/sidepanel, :host+#app for Shadow DOM (resume modals).
     Keep in sync: edit :root. */
  :root,
  :host,
  #app {
    --background: 0 0% 100%;
    --foreground: 222.2 47% 11%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 47% 11%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 47% 11%;
    --primary: 221.2 83% 53%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 47% 11%;
    --muted: 210 40% 96%;
    --muted-foreground: 215 20% 35%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 47% 11%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 210 40% 98%;
    --border: 214 32% 72%;
    --input: 214 32% 72%;
    --ring: 221 83% 53%;
    --radius: 0.75rem;
    --warning: 38 92% 50%;
    --warning-foreground: 48 96% 12%;
  }

  /* ponytail: Shadow DOM needs its own color-scheme + base reset; :host isolates from page CSS */
  :host {
    all: initial;
  }
  #app {
    color-scheme: light;
    isolation: isolate;
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    box-sizing: border-box;
  }
  #app *,
  #app *::before,
  #app *::after {
    box-sizing: border-box;
  }

  @theme inline {
    --color-warning: var(--warning);
    --color-warning-foreground: var(--warning-foreground);
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 48%;
    --md-scrollbar: #484d54;
  }

  ::-moz-selection {
    background: #2469f0;
    color: white;
  }

  ::selection {
    background: #2469f0;
    color: white;
  }

  * {
    scrollbar-width: thin;
    scrollbar-color: #c9cdd4 transparent;
  }

  .dark * {
    scrollbar-color: var(--md-scrollbar) transparent;
  }

  *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  *::-webkit-scrollbar-track {
    background: transparent;
  }

  *::-webkit-scrollbar-thumb {
    background: #c9cdd4;
    border-radius: 3px;
  }

  .dark *::-webkit-scrollbar-thumb {
    background: var(--md-scrollbar);
  }

  *::-webkit-scrollbar-thumb:hover {
    background: #a4a9b3;
  }

  .dark *::-webkit-scrollbar-thumb:hover {
    background: #636971;
  }
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {
  .\\!container {
    max-width: 640px !important;
  }
  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {
  .\\!container {
    max-width: 768px !important;
  }
  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {
  .\\!container {
    max-width: 1024px !important;
  }
  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {
  .\\!container {
    max-width: 1280px !important;
  }
  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {
  .\\!container {
    max-width: 1536px !important;
  }
  .container {
    max-width: 1536px;
  }
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.pointer-events-none {
  pointer-events: none;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.collapse {
  visibility: collapse;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-4 {
  bottom: 1rem;
}
.left-1\\/2 {
  left: 50%;
}
.right-4 {
  right: 1rem;
}
.top-1\\/2 {
  top: 50%;
}
.z-10 {
  z-index: 10;
}
.z-50 {
  z-index: 50;
}
.z-\\[1\\] {
  z-index: 1;
}
.z-\\[2147483647\\] {
  z-index: 2147483647;
}
.col-span-full {
  grid-column: 1 / -1;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.-mb-\\[1px\\] {
  margin-bottom: -1px;
}
.mb-1 {
  margin-bottom: 0.25rem;
}
.mb-1\\.5 {
  margin-bottom: 0.375rem;
}
.mb-2 {
  margin-bottom: 0.5rem;
}
.mb-3 {
  margin-bottom: 0.75rem;
}
.mb-4 {
  margin-bottom: 1rem;
}
.ml-1 {
  margin-left: 0.25rem;
}
.mr-1 {
  margin-right: 0.25rem;
}
.mr-2 {
  margin-right: 0.5rem;
}
.mr-3 {
  margin-right: 0.75rem;
}
.mr-auto {
  margin-right: auto;
}
.mt-0\\.5 {
  margin-top: 0.125rem;
}
.mt-1 {
  margin-top: 0.25rem;
}
.mt-2 {
  margin-top: 0.5rem;
}
.mt-3 {
  margin-top: 0.75rem;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.\\!contents {
  display: contents !important;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-1\\.5 {
  width: 0.375rem;
  height: 0.375rem;
}
.size-10 {
  width: 2.5rem;
  height: 2.5rem;
}
.size-3 {
  width: 0.75rem;
  height: 0.75rem;
}
.size-3\\.5 {
  width: 0.875rem;
  height: 0.875rem;
}
.size-4 {
  width: 1rem;
  height: 1rem;
}
.size-5 {
  width: 1.25rem;
  height: 1.25rem;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.h-1 {
  height: 0.25rem;
}
.h-10 {
  height: 2.5rem;
}
.h-11 {
  height: 2.75rem;
}
.h-12 {
  height: 3rem;
}
.h-2 {
  height: 0.5rem;
}
.h-24 {
  height: 6rem;
}
.h-4 {
  height: 1rem;
}
.h-5 {
  height: 1.25rem;
}
.h-6 {
  height: 1.5rem;
}
.h-7 {
  height: 1.75rem;
}
.h-8 {
  height: 2rem;
}
.h-9 {
  height: 2.25rem;
}
.h-\\[300px\\] {
  height: 300px;
}
.h-\\[var\\(--radix-select-trigger-height\\)\\] {
  height: var(--radix-select-trigger-height);
}
.h-full {
  height: 100%;
}
.max-h-60 {
  max-height: 15rem;
}
.max-h-\\[220px\\] {
  max-height: 220px;
}
.max-h-\\[280px\\] {
  max-height: 280px;
}
.max-h-\\[360px\\] {
  max-height: 360px;
}
.max-h-\\[420px\\] {
  max-height: 420px;
}
.max-h-\\[600px\\] {
  max-height: 600px;
}
.min-h-11 {
  min-height: 2.75rem;
}
.min-h-\\[200px\\] {
  min-height: 200px;
}
.min-h-\\[80px\\] {
  min-height: 80px;
}
.w-10 {
  width: 2.5rem;
}
.w-11 {
  width: 2.75rem;
}
.w-12 {
  width: 3rem;
}
.w-2 {
  width: 0.5rem;
}
.w-28 {
  width: 7rem;
}
.w-4 {
  width: 1rem;
}
.w-5 {
  width: 1.25rem;
}
.w-6 {
  width: 1.5rem;
}
.w-7 {
  width: 1.75rem;
}
.w-9 {
  width: 2.25rem;
}
.w-\\[100px\\] {
  width: 100px;
}
.w-\\[120px\\] {
  width: 120px;
}
.w-\\[340px\\] {
  width: 340px;
}
.w-\\[76px\\] {
  width: 76px;
}
.w-\\[90px\\] {
  width: 90px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-0 {
  min-width: 0px;
}
.min-w-\\[100px\\] {
  min-width: 100px;
}
.min-w-\\[110px\\] {
  min-width: 110px;
}
.min-w-\\[12rem\\] {
  min-width: 12rem;
}
.min-w-\\[80px\\] {
  min-width: 80px;
}
.min-w-\\[90px\\] {
  min-width: 90px;
}
.min-w-\\[var\\(--radix-select-trigger-width\\)\\] {
  min-width: var(--radix-select-trigger-width);
}
.max-w-\\[120px\\] {
  max-width: 120px;
}
.max-w-\\[140px\\] {
  max-width: 140px;
}
.max-w-\\[200px\\] {
  max-width: 200px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-90 {
  --tw-scale-x: .9;
  --tw-scale-y: .9;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes pulse {
  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes slide-up {
  0% {
    opacity: 0;
    transform: translateY(8px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
.animate-slide-up {
  animation: slide-up 0.15s ease-out;
}
.cursor-default {
  cursor: default;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize-y {
  resize: vertical;
}
.resize {
  resize: both;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-center {
  align-items: center;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0 {
  gap: 0px;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-1\\.5 {
  gap: 0.375rem;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-2\\.5 {
  gap: 0.625rem;
}
.gap-3 {
  gap: 0.75rem;
}
.gap-4 {
  gap: 1rem;
}
.gap-x-8 {
  -moz-column-gap: 2rem;
       column-gap: 2rem;
}
.gap-y-3 {
  row-gap: 0.75rem;
}
.space-y-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.125rem * var(--tw-space-y-reverse));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}
.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.5rem * var(--tw-space-y-reverse));
}
.space-y-2\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.625rem * var(--tw-space-y-reverse));
}
.space-y-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}
.space-y-5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1.25rem * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.divide-border > :not([hidden]) ~ :not([hidden]) {
  border-color: hsl(var(--border));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-y-auto {
  overflow-y: auto;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.break-words {
  overflow-wrap: break-word;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 0.5rem;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.rounded-b-2xl {
  border-bottom-right-radius: 1rem;
  border-bottom-left-radius: 1rem;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l-2 {
  border-left-width: 2px;
}
.border-t {
  border-top-width: 1px;
}
.border-t-2 {
  border-top-width: 2px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-\\[\\#2469f0\\] {
  --tw-border-opacity: 1;
  border-color: rgb(36 105 240 / var(--tw-border-opacity, 1));
}
.border-amber-200 {
  --tw-border-opacity: 1;
  border-color: rgb(253 230 138 / var(--tw-border-opacity, 1));
}
.border-border {
  border-color: hsl(var(--border));
}
.border-destructive {
  border-color: hsl(var(--destructive));
}
.border-destructive\\/20 {
  border-color: hsl(var(--destructive) / 0.2);
}
.border-foreground {
  border-color: hsl(var(--foreground));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-input {
  border-color: hsl(var(--input));
}
.border-primary {
  border-color: hsl(var(--primary));
}
.border-primary\\/20 {
  border-color: hsl(var(--primary) / 0.2);
}
.border-primary\\/50 {
  border-color: hsl(var(--primary) / 0.5);
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.bg-\\[\\#2469f0\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(36 105 240 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  background-color: hsl(var(--accent));
}
.bg-accent\\/20 {
  background-color: hsl(var(--accent) / 0.2);
}
.bg-accent\\/40 {
  background-color: hsl(var(--accent) / 0.4);
}
.bg-accent\\/50 {
  background-color: hsl(var(--accent) / 0.5);
}
.bg-amber-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}
.bg-amber-50\\/50 {
  background-color: rgb(255 251 235 / 0.5);
}
.bg-background {
  background-color: hsl(var(--background));
}
.bg-background\\/60 {
  background-color: hsl(var(--background) / 0.6);
}
.bg-blue-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}
.bg-border {
  background-color: hsl(var(--border));
}
.bg-card {
  background-color: hsl(var(--card));
}
.bg-destructive {
  background-color: hsl(var(--destructive));
}
.bg-destructive\\/10 {
  background-color: hsl(var(--destructive) / 0.1);
}
.bg-destructive\\/5 {
  background-color: hsl(var(--destructive) / 0.05);
}
.bg-foreground {
  background-color: hsl(var(--foreground));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}
.bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}
.bg-green-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}
.bg-green-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));
}
.bg-green-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.bg-muted {
  background-color: hsl(var(--muted));
}
.bg-muted-foreground {
  background-color: hsl(var(--muted-foreground));
}
.bg-muted\\/40 {
  background-color: hsl(var(--muted) / 0.4);
}
.bg-neutral-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.bg-popover {
  background-color: hsl(var(--popover));
}
.bg-primary {
  background-color: hsl(var(--primary));
}
.bg-primary\\/10 {
  background-color: hsl(var(--primary) / 0.1);
}
.bg-primary\\/5 {
  background-color: hsl(var(--primary) / 0.05);
}
.bg-red-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}
.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}
.bg-red-500\\/5 {
  background-color: rgb(239 68 68 / 0.05);
}
.bg-red-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}
.bg-secondary {
  background-color: hsl(var(--secondary));
}
.bg-white\\/15 {
  background-color: rgb(255 255 255 / 0.15);
}
.bg-yellow-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}
.bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}
.from-muted {
  --tw-gradient-from: hsl(var(--muted)) var(--tw-gradient-from-position);
  --tw-gradient-to: hsl(var(--muted) / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.to-muted\\/50 {
  --tw-gradient-to: hsl(var(--muted) / 0.5) var(--tw-gradient-to-position);
}
.p-0\\.5 {
  padding: 0.125rem;
}
.p-1 {
  padding: 0.25rem;
}
.p-1\\.5 {
  padding: 0.375rem;
}
.p-2 {
  padding: 0.5rem;
}
.p-2\\.5 {
  padding: 0.625rem;
}
.p-3 {
  padding: 0.75rem;
}
.p-4 {
  padding: 1rem;
}
.p-5 {
  padding: 1.25rem;
}
.p-8 {
  padding: 2rem;
}
.px-1 {
  padding-left: 0.25rem;
  padding-right: 0.25rem;
}
.px-1\\.5 {
  padding-left: 0.375rem;
  padding-right: 0.375rem;
}
.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}
.px-2\\.5 {
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}
.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}
.px-3\\.5 {
  padding-left: 0.875rem;
  padding-right: 0.875rem;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-5 {
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}
.px-7 {
  padding-left: 1.75rem;
  padding-right: 1.75rem;
}
.py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}
.py-0\\.5 {
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
}
.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}
.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}
.py-12 {
  padding-top: 3rem;
  padding-bottom: 3rem;
}
.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
.py-2\\.5 {
  padding-top: 0.625rem;
  padding-bottom: 0.625rem;
}
.py-3 {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}
.py-3\\.5 {
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
}
.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}
.py-6 {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}
.pb-1\\.5 {
  padding-bottom: 0.375rem;
}
.pb-2 {
  padding-bottom: 0.5rem;
}
.pr-20 {
  padding-right: 5rem;
}
.pt-3 {
  padding-top: 0.75rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.font-\\[\\'Roboto\\'\\2c \\'Segoe_UI\\'\\2c system-ui\\2c sans-serif\\] {
  font-family: 'Roboto','Segoe UI',system-ui,sans-serif;
}
.font-mono {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace;
}
.text-\\[10px\\] {
  font-size: 10px;
}
.text-\\[11px\\] {
  font-size: 11px;
}
.text-\\[8px\\] {
  font-size: 8px;
}
.text-\\[9px\\] {
  font-size: 9px;
}
.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-md-sm {
  font-size: 12px;
  line-height: 18px;
}
.text-md-xs {
  font-size: 11px;
  line-height: 16px;
}
.text-xl {
  font-size: 1.25rem;
  line-height: 1.75rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.text-xxl {
  font-size: 22px;
  line-height: 28px;
}
.font-bold {
  font-weight: 700;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.italic {
  font-style: italic;
}
.leading-\\[1\\.6\\] {
  line-height: 1.6;
}
.leading-\\[1\\.7\\] {
  line-height: 1.7;
}
.leading-normal {
  line-height: 1.5;
}
.leading-relaxed {
  line-height: 1.625;
}
.leading-snug {
  line-height: 1.375;
}
.leading-tight {
  line-height: 1.25;
}
.tracking-\\[0\\.03em\\] {
  letter-spacing: 0.03em;
}
.tracking-tight {
  letter-spacing: -0.025em;
}
.tracking-wide {
  letter-spacing: 0.025em;
}
.tracking-wider {
  letter-spacing: 0.05em;
}
.text-\\[\\#2469f0\\] {
  --tw-text-opacity: 1;
  color: rgb(36 105 240 / var(--tw-text-opacity, 1));
}
.text-amber-700 {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}
.text-background {
  color: hsl(var(--background));
}
.text-blue-700 {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}
.text-card-foreground {
  color: hsl(var(--card-foreground));
}
.text-destructive {
  color: hsl(var(--destructive));
}
.text-destructive-foreground {
  color: hsl(var(--destructive-foreground));
}
.text-destructive\\/80 {
  color: hsl(var(--destructive) / 0.8);
}
.text-foreground {
  color: hsl(var(--foreground));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}
.text-green-50 {
  --tw-text-opacity: 1;
  color: rgb(240 253 244 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-700 {
  --tw-text-opacity: 1;
  color: rgb(21 128 61 / var(--tw-text-opacity, 1));
}
.text-muted-foreground {
  color: hsl(var(--muted-foreground));
}
.text-popover-foreground {
  color: hsl(var(--popover-foreground));
}
.text-primary {
  color: hsl(var(--primary));
}
.text-primary-foreground {
  color: hsl(var(--primary-foreground));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity, 1));
}
.text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity, 1));
}
.text-red-900 {
  --tw-text-opacity: 1;
  color: rgb(127 29 29 / var(--tw-text-opacity, 1));
}
.text-secondary-foreground {
  color: hsl(var(--secondary-foreground));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-white\\/80 {
  color: rgb(255 255 255 / 0.8);
}
.text-white\\/90 {
  color: rgb(255 255 255 / 0.9);
}
.text-yellow-600 {
  --tw-text-opacity: 1;
  color: rgb(202 138 4 / var(--tw-text-opacity, 1));
}
.text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity, 1));
}
.text-yellow-800 {
  --tw-text-opacity: 1;
  color: rgb(133 77 14 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.underline-offset-4 {
  text-underline-offset: 4px;
}
.antialiased {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.opacity-0 {
  opacity: 0;
}
.opacity-30 {
  opacity: 0.3;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-60 {
  opacity: 0.6;
}
.opacity-85 {
  opacity: 0.85;
}
.opacity-90 {
  opacity: 0.9;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.grayscale {
  --tw-grayscale: grayscale(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.duration-300 {
  transition-duration: 300ms;
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
@keyframes enter {
  from {
    opacity: var(--tw-enter-opacity, 1);
    transform: translate3d(var(--tw-enter-translate-x, 0), var(--tw-enter-translate-y, 0), 0) scale3d(var(--tw-enter-scale, 1), var(--tw-enter-scale, 1), var(--tw-enter-scale, 1)) rotate(var(--tw-enter-rotate, 0));
  }
}
@keyframes exit {
  to {
    opacity: var(--tw-exit-opacity, 1);
    transform: translate3d(var(--tw-exit-translate-x, 0), var(--tw-exit-translate-y, 0), 0) scale3d(var(--tw-exit-scale, 1), var(--tw-exit-scale, 1), var(--tw-exit-scale, 1)) rotate(var(--tw-exit-rotate, 0));
  }
}
.animate-in {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.fade-in {
  --tw-enter-opacity: 0;
}
.fade-out {
  --tw-exit-opacity: 0;
}
.duration-200 {
  animation-duration: 200ms;
}
.duration-300 {
  animation-duration: 300ms;
}
.ease-in-out {
  animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.running {
  animation-play-state: running;
}
.placeholder\\:text-muted-foreground::-moz-placeholder {
  color: hsl(var(--muted-foreground));
}
.placeholder\\:text-muted-foreground::placeholder {
  color: hsl(var(--muted-foreground));
}
.last\\:border-b-0:last-child {
  border-bottom-width: 0px;
}
.hover\\:bg-accent:hover {
  background-color: hsl(var(--accent));
}
.hover\\:bg-amber-100\\/50:hover {
  background-color: rgb(254 243 199 / 0.5);
}
.hover\\:bg-destructive\\/10:hover {
  background-color: hsl(var(--destructive) / 0.1);
}
.hover\\:bg-destructive\\/20:hover {
  background-color: hsl(var(--destructive) / 0.2);
}
.hover\\:bg-destructive\\/90:hover {
  background-color: hsl(var(--destructive) / 0.9);
}
.hover\\:bg-green-600\\/90:hover {
  background-color: rgb(22 163 74 / 0.9);
}
.hover\\:bg-green-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(21 128 61 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-neutral-900:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(23 23 23 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-primary\\/5:hover {
  background-color: hsl(var(--primary) / 0.05);
}
.hover\\:bg-primary\\/90:hover {
  background-color: hsl(var(--primary) / 0.9);
}
.hover\\:bg-red-500\\/10:hover {
  background-color: rgb(239 68 68 / 0.1);
}
.hover\\:bg-red-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-secondary\\/80:hover {
  background-color: hsl(var(--secondary) / 0.8);
}
.hover\\:bg-white\\/25:hover {
  background-color: rgb(255 255 255 / 0.25);
}
.hover\\:text-accent-foreground:hover {
  color: hsl(var(--accent-foreground));
}
.hover\\:text-destructive:hover {
  color: hsl(var(--destructive));
}
.hover\\:text-foreground:hover {
  color: hsl(var(--foreground));
}
.hover\\:text-red-600:hover {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.hover\\:underline:hover {
  text-decoration-line: underline;
}
.hover\\:opacity-70:hover {
  opacity: 0.7;
}
.focus\\:bg-accent:focus {
  background-color: hsl(var(--accent));
}
.focus\\:text-accent-foreground:focus {
  color: hsl(var(--accent-foreground));
}
.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-primary:focus {
  --tw-ring-color: hsl(var(--primary));
}
.focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity, 1));
}
.focus\\:ring-ring:focus {
  --tw-ring-color: hsl(var(--ring));
}
.focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}
.focus-visible\\:outline-none:focus-visible {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus-visible\\:ring-primary:focus-visible {
  --tw-ring-color: hsl(var(--primary));
}
.focus-visible\\:ring-ring:focus-visible {
  --tw-ring-color: hsl(var(--ring));
}
.focus-visible\\:ring-offset-1:focus-visible {
  --tw-ring-offset-width: 1px;
}
.focus-visible\\:ring-offset-2:focus-visible {
  --tw-ring-offset-width: 2px;
}
.active\\:bg-accent:active {
  background-color: hsl(var(--accent));
}
.active\\:bg-destructive:active {
  background-color: hsl(var(--destructive));
}
.active\\:bg-green-600:active {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.active\\:bg-neutral-950:active {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.active\\:bg-primary:active {
  background-color: hsl(var(--primary));
}
.active\\:bg-secondary:active {
  background-color: hsl(var(--secondary));
}
.disabled\\:pointer-events-none:disabled {
  pointer-events: none;
}
.disabled\\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}
.disabled\\:bg-muted:disabled {
  background-color: hsl(var(--muted));
}
.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}
.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}
.data-\\[disabled\\]\\:pointer-events-none[data-disabled] {
  pointer-events: none;
}
.data-\\[side\\=bottom\\]\\:translate-y-1[data-side="bottom"] {
  --tw-translate-y: 0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[side\\=top\\]\\:-translate-y-1[data-side="top"] {
  --tw-translate-y: -0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:translate-x-4[data-state="checked"] {
  --tw-translate-x: 1rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=unchecked\\]\\:translate-x-0[data-state="unchecked"] {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:bg-primary[data-state="checked"] {
  background-color: hsl(var(--primary));
}
.data-\\[state\\=unchecked\\]\\:bg-input[data-state="unchecked"] {
  background-color: hsl(var(--input));
}
.data-\\[disabled\\]\\:opacity-50[data-disabled] {
  opacity: 0.5;
}
.data-\\[state\\=open\\]\\:animate-in[data-state="open"] {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:animate-out[data-state="closed"] {
  animation-name: exit;
  animation-duration: 150ms;
  --tw-exit-opacity: initial;
  --tw-exit-scale: initial;
  --tw-exit-rotate: initial;
  --tw-exit-translate-x: initial;
  --tw-exit-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:fade-out-0[data-state="closed"] {
  --tw-exit-opacity: 0;
}
.data-\\[state\\=open\\]\\:fade-in-0[data-state="open"] {
  --tw-enter-opacity: 0;
}
.data-\\[state\\=closed\\]\\:zoom-out-95[data-state="closed"] {
  --tw-exit-scale: .95;
}
.data-\\[state\\=open\\]\\:zoom-in-95[data-state="open"] {
  --tw-enter-scale: .95;
}
@supports (backdrop-filter: var(--tw)) {
  .supports-\\[backdrop-filter\\]\\:bg-background\\/60 {
    background-color: hsl(var(--background) / 0.6);
  }
}
.dark\\:border-amber-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(146 64 14 / var(--tw-border-opacity, 1));
}
.dark\\:border-green-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 101 52 / var(--tw-border-opacity, 1));
}
.dark\\:border-red-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(127 29 29 / var(--tw-border-opacity, 1));
}
.dark\\:bg-amber-900\\/30:is(.dark *) {
  background-color: rgb(120 53 15 / 0.3);
}
.dark\\:bg-amber-950\\/20:is(.dark *) {
  background-color: rgb(69 26 3 / 0.2);
}
.dark\\:bg-blue-900\\/30:is(.dark *) {
  background-color: rgb(30 58 138 / 0.3);
}
.dark\\:bg-blue-950\\/20:is(.dark *) {
  background-color: rgb(23 37 84 / 0.2);
}
.dark\\:bg-green-950\\/20:is(.dark *) {
  background-color: rgb(5 46 22 / 0.2);
}
.dark\\:bg-red-950\\/20:is(.dark *) {
  background-color: rgb(69 10 10 / 0.2);
}
.dark\\:bg-yellow-950\\/30:is(.dark *) {
  background-color: rgb(66 32 6 / 0.3);
}
.dark\\:text-amber-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}
.dark\\:text-blue-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.dark\\:text-green-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 202 202 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
@media (min-width: 640px) {
  .sm\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
@media (min-width: 768px) {
  .md\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .md\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .md\\:text-left {
    text-align: left;
  }
}
@media (min-width: 1024px) {
  .lg\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
.\\[\\&\\>span\\]\\:line-clamp-1>span {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.\\[\\&\\>span\\]\\:h-3>span {
  height: 0.75rem;
}
.\\[\\&\\>span\\]\\:w-3>span {
  width: 0.75rem;
}
.data-\\[state\\=checked\\]\\:\\[\\&\\>span\\]\\:translate-x-3>span[data-state="checked"] {
  --tw-translate-x: 0.75rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.\\[\\&_svg\\]\\:pointer-events-none svg {
  pointer-events: none;
}
.\\[\\&_svg\\]\\:size-3\\.5 svg {
  width: 0.875rem;
  height: 0.875rem;
}
.\\[\\&_svg\\]\\:size-5 svg {
  width: 1.25rem;
  height: 1.25rem;
}
.\\[\\&_svg\\]\\:shrink-0 svg {
  flex-shrink: 0;
}
`.replace(/@import[^;]+;/g,""),n=`
      .resume-modal {
        background: #f8f6f3;
        border-radius: 20px;
        box-shadow: 0 25px 60px rgba(0,0,0,.3);
        width: 94%;
        max-width: 900px;
        max-height: 90vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: resume-slideup .3s ease;
        font-size: 16px;
        line-height: 1.6;
        color: #1a1d23;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
      }
      /* Paksa Roboto 16px/1.6 di atas CSS host (termasuk yang !important):
         menang di light-DOM fallback & elemen yang tidak inherit font
         (button native). Kode ICD (.font-mono) dikecualikan. */
      .resume-modal,
      .resume-modal *:not(.font-mono) {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
        line-height: 1.6 !important;
      }
      /* Dropdown bawaan browser (option/optgroup): render native, paksa eksplisit. */
      .resume-modal option,
      .resume-modal optgroup {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
      }
      .resume-modal *,
      .resume-modal *::before,
      .resume-modal *::after {
        box-sizing: border-box;
      }
      .resume-modal input,
      .resume-modal select,
      .resume-modal textarea {
        all: unset;
        box-sizing: border-box;
        font-family: inherit;
        font-size: inherit;
        color: inherit;
        cursor: default;
        height: auto;
        min-height: 32px;
        width: 100%;
        border: 1px solid hsl(214.3 31.8% 91.4%);
        border-radius: 6px;
        background: white;
        padding: 4px 10px;
        outline: none;
        transition: border-color 0.15s, box-shadow 0.15s;
      }
      .resume-modal input:focus,
      .resume-modal select:focus,
      .resume-modal textarea:focus {
        border-color: hsl(221.2 83.2% 53.3%);
        box-shadow: 0 0 0 2px hsl(221.2 83.2% 53.3% / 0.15);
      }
      .resume-modal textarea {
        resize: vertical;
        min-height: 80px;
        padding: 8px 10px;
      }
      .resume-modal select {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 8px center;
        padding-right: 28px;
      }
      .resume-modal h1,
      .resume-modal h2,
      .resume-modal h3 {
        font-family: 'Lexend', system-ui, sans-serif;
      }
    `;if(l&&!l.getElementById("morbis-resume-shadow-css")){let i=document.createElement("style");i.id="morbis-resume-shadow-css",i.textContent=o+n,l.appendChild(i)}if(!document.getElementById("morbis-resume-css")){let i=document.createElement("style");i.id="morbis-resume-css",i.textContent=o+`
      /* \u2500\u2500 Reset host-page overrides inside the modal \u2500\u2500 */
      /* ponytail: specificity 0-2-0 beats most host styles without !important */
      .resume-modal .resume-modal {
        background: #f8f6f3;
        border-radius: 20px;
        box-shadow: 0 25px 60px rgba(0,0,0,.3);
        width: 94%;
        max-width: 900px;
        max-height: 90vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: resume-slideup .3s ease;
        font-size: 16px;
        line-height: 1.6;
        color: #1a1d23;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
      }
      /* Paksa Roboto 16px/1.6 di atas CSS host (termasuk yang !important):
         menang di light-DOM fallback & elemen yang tidak inherit font
         (button native). Kode ICD (.font-mono) dikecualikan. */
      .resume-modal,
      .resume-modal *:not(.font-mono) {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
        line-height: 1.6 !important;
      }
      /* Dropdown bawaan browser (option/optgroup): render native, paksa eksplisit. */
      .resume-modal option,
      .resume-modal optgroup {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
      }

      /* \u2500\u2500 Dropdown autocomplete ICD \u2500\u2500
         Aturan .resume-modal *:not(.font-mono) di atas memaksa
         font-size 16px !important untuk SELURUH isi modal, sehingga
         class Tailwind apa pun (text-lg/text-xl/text-xxl) ikut
         tertimpa. Baris nama & kode pada dropdown dikecualikan lalu
         diberi ukuran eksplisit di sini, setelah aturan itu, dengan
         !important yang sama supaya benar-benar menang.
         Kode sengaja TANPA font-mono: JetBrains Mono punya x-height
         jauh lebih rendah sehingga kode terlihat kecil dibanding nama.
         Catatan: jangan pakai backtick di dalam template literal ini. */
      .resume-modal .rj-icd-hit-nama,
      .resume-modal .rj-icd-hit-kode {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
      }
      .resume-modal .rj-icd-hit-nama {
        font-size: 18px !important;
        line-height: 1.4 !important;
      }
      .resume-modal .rj-icd-hit-kode {
        font-size: 22px !important;
        line-height: 1.25 !important;
      }
      .resume-modal .resume-modal *,
      .resume-modal .resume-modal *::before,
      .resume-modal .resume-modal *::after {
        box-sizing: border-box;
      }
      /* Neutralize host page input/select/textarea defaults.
         No reset on buttons \u2014 our Button component owns its own styling via Tailwind. */
      .resume-modal .resume-modal input,
      .resume-modal .resume-modal select,
      .resume-modal .resume-modal textarea {
        all: unset;
        box-sizing: border-box;
        font-family: inherit;
        font-size: inherit;
        color: inherit;
        cursor: default;
      }
      .resume-modal .resume-modal input,
      .resume-modal .resume-modal select,
      .resume-modal .resume-modal textarea {
        height: auto;
        min-height: 32px;
        width: 100%;
        border: 1px solid hsl(214.3 31.8% 91.4%);
        border-radius: 6px;
        background: white;
        padding: 4px 10px;
        outline: none;
        transition: border-color 0.15s, box-shadow 0.15s;
      }
      .resume-modal .resume-modal input:focus,
      .resume-modal .resume-modal select:focus,
      .resume-modal .resume-modal textarea:focus {
        border-color: hsl(221.2 83.2% 53.3%);
        box-shadow: 0 0 0 2px hsl(221.2 83.2% 53.3% / 0.15);
      }
      .resume-modal .resume-modal textarea {
        resize: vertical;
        min-height: 80px;
        padding: 8px 10px;
      }
      .resume-modal .resume-modal select {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 8px center;
        padding-right: 28px;
      }
      .resume-modal .resume-modal h1,
      .resume-modal .resume-modal h2,
      .resume-modal .resume-modal h3 {
        font-family: 'Lexend', system-ui, sans-serif;
      }
      /* \u2500\u2500 Radix Select portal (renders outside .resume-modal) \u2500\u2500 */
      [data-radix-select-viewport] {
        padding: 4px;
      }
      [data-radix-select-viewport] [role="option"] {
        all: unset;
        display: flex;
        align-items: center;
        padding: 6px 8px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
        line-height: 18px;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
        color: #1a1d23;
      }
      [data-radix-select-viewport] [role="option"]:focus,
      [data-radix-select-viewport] [role="option"][data-highlighted] {
        background: hsl(210 40% 96.1%);
        color: hsl(222.2 47.4% 11.2%);
      }
      [data-radix-popper-content-wrapper] {
        z-index: 2147483646 !important;
      }
      @keyframes resume-slideup { from { opacity: 0; transform: translateY(24px) } to { opacity: 1; transform: translateY(0) } }
    `,document.head.appendChild(i)}let s=(()=>{if(!l)return e;e.style.display="none";let i=l.getElementById("app"),p=l.getElementById("ext-resume-shadow-container");p||(p=document.createElement("div"),p.id="ext-resume-shadow-container",p.style.cssText="position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;pointer-events:auto",(i??l).appendChild(p)),p.style.display="flex",su&&(su.style.display="none");let g=document.querySelector("[data-scroll-buttons]");return g&&(g.style.display="none"),p})();Ut=(0,Eh.createRoot)(s);let r=async i=>{let p=xC(i),g=await fetch(mC,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:p,credentials:"same-origin"}),f=await g.text();if(!g.ok)throw console.error("[RJ] save failed:",g.status,f),new Error("HTTP "+g.status);let c=null;try{c=JSON.parse(f)}catch{c=null}if(c){if(Number(c.status)!==200)throw console.error("[RJ] server reject:",c),new Error(c.msg||"Gagal simpan (status "+c.status+")")}else{let A=/(?:<b>)?(?:Notice|Warning|Fatal error|Parse error|Catchable fatal error)(?:<\/b>)?\s*:\s*[^<]*/gi,h=[],d;for(;(d=A.exec(f))!==null;){let m=d[0].trim().replace(/<[^>]+>/g,"");m&&(/github\.com\/newrelic|newrelic-browser|google-analytics|googletagmanager/i.test(m)||h.push(m))}if(h.length>0)throw console.error("[RJ] PHP errors:",h),new Error(h.join(`
`))}R=null;let S=i.patientInfo.id_visit||new URLSearchParams(location.search).get("id_visit")||"",b=i.patientInfo.id_rawat_jalan||new URLSearchParams(location.search).get("id")||"";Ag({idVisit:S,idResume:b,tipe:"rajal",aksi:b?"ubah":"buat",before:kg(S,"rajal")??{},after:wg(i)})};Ut.render((0,pd.jsx)(ds,{onError:()=>setTimeout(()=>md(e),0),children:(0,pd.jsx)(Ah,{data:a,onSave:r,onClose:()=>md(e)})})),document.body.classList.add("ext-resume-open"),setTimeout(()=>{(l?.getElementById("ext-resume-shadow-container")??e).querySelectorAll("textarea").forEach(p=>{let g=p;g.addEventListener("input",()=>{g.style.height="auto",g.style.height=g.scrollHeight+"px"}),g.dispatchEvent(new Event("input"))})},50)}var R=null;function SC(e){let a={},t=(l,u)=>{l&&(l.endsWith("[]")?(Array.isArray(a[l])||(a[l]=[]),a[l].push(u)):a[l]=u)};return e.querySelectorAll("input[name]").forEach(l=>{let u=(l.getAttribute("type")||"text").toLowerCase();(u==="radio"||u==="checkbox")&&!l.checked||u==="submit"||u==="button"||u==="file"||u==="image"||t(l.name,l.value??"")}),e.querySelectorAll("textarea[name]").forEach(l=>{t(l.name,l.value??"")}),e.querySelectorAll("select").forEach(l=>{l.id&&(a[l.id]=l.value??""),l.name&&t(l.name,l.value??"")}),a}var Oh=[];async function yC(){let e=new URLSearchParams(location.search).get("id_visit");if(!e)return{};let a=[`${location.origin}/admisi/pelaksanaan_pelayanan/rm-rawat-jalan-new?id_visit=${e}&page=6`,`${location.origin}/admisi/pelaksanaan_pelayanan/rm-rawat-jalan-new?id_visit=${e}`,`${location.origin}/admisi/pelaksanaan_pelayanan/rj?id_visit=${e}`];for(let t of a)for(let l=0;l<3;l++){l>0&&await new Promise(u=>setTimeout(u,350));try{let u=await fetch(t,{credentials:"same-origin",cache:"no-store",headers:{Referer:location.origin+"/admisi/pelaksanaan_pelayanan/"}});if(!u.ok)continue;let o=await u.text(),n=new DOMParser().parseFromString(o,"text/html");if(n.querySelector('form, input[name="id_kunjungan"]')===null)break;let s=SC(n);if(s.id_kunjungan)return Oh=Object.keys(s),s;break}catch(u){console.warn("[RJ] fetchFormState gagal untuk",t,u)}}return console.warn("[RJ] fetchFormState: tidak menemukan form RJ untuk id_visit",e),{}}function CC(){let e=[];for(let a of document.querySelectorAll("p, td")){let t=a.textContent?.trim().match(/No Resep\s*:\s*(\d+)/i);t&&!e.includes(t[1])&&e.push(t[1])}return e}async function bC(e){let t=await(await fetch(e,{credentials:"same-origin"})).text(),u=new DOMParser().parseFromString(t,"text/html").querySelectorAll("h5"),o=null;for(let i of u)if(i.textContent?.trim()==="Resep yang ditebus"){o=i;break}if(!o)return[];let n=o.nextElementSibling;for(;n&&n.tagName!=="TABLE";)n=n.nextElementSibling;if(!n)return[];let s=[],r=n.querySelectorAll("tr");for(let i=1;i<r.length;i++){let p=r[i].querySelectorAll("td");if(p.length<8)continue;let g=p[1]?.textContent?.trim(),f=p[7]?.textContent?.trim(),c=p[5]?.textContent?.trim();g&&s.push(`${g} - ${f||"-"}`)}return s}async function vC(){let e=CC();if(!e.length)return null;let a=await Promise.all(e.map(u=>{let o=`${location.origin}/admisi/pelaksanaan_pelayanan/history/resep?id=${u}`;return bC(o)})),t=new Set,l=[];for(let u of a)for(let o of u){let n=o.split(" - ")[0];t.has(n)||(t.add(n),l.push(o))}return l.length?l.join(`
`):null}function Dh(){if(!location.href.startsWith(location.origin+"/v2/m-klaim/detail-v2-refaktor")||!new URLSearchParams(location.search).has("id_visit")||(document.querySelector("input[name=jenis]")?.value??document.querySelector("select[name=jenis]")?.value??"").toUpperCase().includes("INAP")||document.getElementById("ext-resume-float-btn"))return;let l=document.createElement("div");l.id="ext-resume-container",l.className="resume-modal",l.style.cssText="position: fixed; inset: 0; z-index: 2147483647; display: none; background: rgba(0,0,0,.4); align-items: center; justify-content: center;",document.body.appendChild(l);let u=document.createElement("button");su=u,u.id="ext-resume-float-btn",u.textContent="RJ",u.title="Resume Rajal",u.style.cssText="position:fixed;right:16px;top:50%;transform:translateY(-50%);z-index:2147483645;width:48px;height:48px;border-radius:12px;border:none;background:#2b5f8a;color:white;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.2);transition:transform .15s,box-shadow .15s;",u.onmouseenter=()=>{u.style.transform="translateY(-50%) scale(1.05)",u.style.boxShadow="0 4px 16px rgba(43,95,138,.35)"},u.onmouseleave=()=>{u.style.transform="translateY(-50%)",u.style.boxShadow="0 2px 8px rgba(0,0,0,.2)"},u.addEventListener("click",async()=>{if(!u.disabled){u.disabled=!0;try{R||(R=await yC());let o=await vC(),n=gC();o&&(n.clinicalNotes.terapi_pengobatan=o);let s=!n.clinicalNotes.tindakan||n.clinicalNotes.tindakan==="-",r=!n.clinicalNotes.terapi_pengobatan||n.clinicalNotes.terapi_pengobatan==="-";if(s||r){let i=Bh();i.tindakan&&s&&(n.clinicalNotes.tindakan=i.tindakan),i.terapiPengobatan&&r&&(n.clinicalNotes.terapi_pengobatan=i.terapiPengobatan)}l.style.display="flex",LC(l,n)}catch(o){console.error("[RJ] click error:",o),l.style.display="none",u.disabled=!1}}}),document.body.appendChild(u),document.addEventListener("keydown",o=>{o.key==="Escape"&&l.style.display!=="none"&&md(l)})}function Rh(){return document.documentElement.getAttribute("data-ext-resume-modal")==="1"}function IC(){return["/login","/auth","/signin","/masuk","/keluar","/logout"].some(a=>location.pathname.toLowerCase().includes(a))||document.querySelectorAll('input[type="password"]').length>0}function kC(e=5e3){return Rh()?Promise.resolve(!0):new Promise(a=>{let t=Date.now(),l=setInterval(()=>{Rh()?(clearInterval(l),a(!0)):Date.now()-t>e&&(clearInterval(l),a(!1))},200)})}(async()=>IC()||await kC()&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Dh):Dh()))();return Ph(AC);})();
/*! Bundled license information:

scheduler/cjs/scheduler.production.js:
  (**
   * @license React
   * scheduler.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react.production.js:
  (**
   * @license React
   * react.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.js:
  (**
   * @license React
   * react-dom.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom-client.production.js:
  (**
   * @license React
   * react-dom-client.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react-jsx-runtime.production.js:
  (**
   * @license React
   * react-jsx-runtime.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs:
lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs:
lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs:
lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs:
lucide-react/dist/esm/defaultAttributes.mjs:
lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs:
lucide-react/dist/esm/context.mjs:
lucide-react/dist/esm/Icon.mjs:
lucide-react/dist/esm/createLucideIcon.mjs:
lucide-react/dist/esm/icons/check.mjs:
lucide-react/dist/esm/icons/info.mjs:
lucide-react/dist/esm/icons/triangle-alert.mjs:
lucide-react/dist/esm/icons/x.mjs:
lucide-react/dist/esm/lucide-react.mjs:
  (**
   * @license lucide-react v1.38.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
