"use strict";var __morbis_feature=(()=>{var P="http://dev.rsudkotajambi.id/rs",K="ext-farmasi-app-base",B=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],q=".rsudkotajambi.id";function O(t){try{let e=new URL(t);if(e.protocol!=="http:"&&e.protocol!=="https:")return!1;let a=e.hostname.toLowerCase();return B.includes(a)?!0:a.endsWith(q)}catch{return!1}}function H(){try{let t=localStorage.getItem(K);if(t&&O(t))return t.replace(/\/+$/,"")}catch{}return P}function U(){return H()}function V(t,e=8e3){try{let a=window.requestIdleCallback;if(typeof a=="function"){a.call(window,t,{timeout:e});return}}catch{}window.setTimeout(t,Math.min(e,1500))}function G(){return window}var J='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',S=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${J};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,w=null;function W(){return w||(w=new CSSStyleSheet,w.replaceSync(S)),w}var j=!1;function Y(){if(j||document.getElementById("ext-pjs-font"))return;j=!0;let t=document.createElement("link");t.id="ext-pjs-font",t.rel="stylesheet",t.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(t)}function T(t,e="open"){let a=t.attachShadow({mode:e});return a.adoptedStyleSheets=[W()],Y(),a}var L=!1;function F(){if(L)return;L=!0;let t=document.createElement("style");t.id="ext-token-css",t.textContent=S.replace(":host",":root"),document.head.appendChild(t)}var Q=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,X=class extends HTMLElement{constructor(){super();let t=T(this);t.innerHTML=`
      <style>${Q}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=t.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",t=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){t.stopPropagation(),t.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(t){(t==="disabled"||t==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}},z=typeof window<"u"?window.customElements:null;if(z)try{z.get("ext-btn")||z.define("ext-btn",X)}catch(t){console.warn("[MORBIS Ext] gagal registrasi ext-btn:",t)}var Z=`
  :host { display: block; }
  input {
    width: 100%;
    box-sizing: border-box;
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text);
    background: var(--ext-surface);
    border: 1px solid var(--ext-border);
    border-radius: var(--ext-radius-md);
    padding: 9px 12px;
    min-height: 42px;
    transition: border-color var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
  }
  input::placeholder { color: var(--ext-text-muted); }
  input:focus { outline: none; border-color: var(--ext-primary); box-shadow: var(--ext-ring); }
  input:disabled { background: var(--ext-surface-2); color: var(--ext-text-muted); cursor: not-allowed; }
  :host([invalid]) input { border-color: var(--ext-danger); }

  :host([size='sm']) input {
    font-size: var(--ext-font-size-sm);
    padding: 6px 10px;
    min-height: 32px;
    border-radius: var(--ext-radius-sm);
  }
  :host([size='lg']) input {
    font-size: var(--ext-font-size-lg);
    padding: 12px 14px;
    min-height: 50px;
  }
`,tt=class extends HTMLElement{constructor(){super();let t=T(this);t.innerHTML=`<style>${Z}</style><input />`,this.input=t.querySelector("input");for(let e of["change","focus","blur"])this.input.addEventListener(e,()=>this.dispatchEvent(new Event(e)))}static get observedAttributes(){return["type","placeholder","value","disabled","invalid"]}connectedCallback(){this.sync()}attributeChangedCallback(){this.sync()}sync(){let{input:t}=this;if(!t)return;t.type=this.getAttribute("type")||"text",t.placeholder=this.getAttribute("placeholder")||"",t.disabled=this.hasAttribute("disabled"),t.setAttribute("aria-invalid",this.hasAttribute("invalid")?"true":"false");let e=this.getAttribute("value");e!==null&&t.value!==e&&(t.value=e)}get value(){return this.input.value}set value(t){this.input.value=t??""}focus(){this.input.focus()}},A=typeof window<"u"?window.customElements:null;if(A)try{A.get("ext-input")||A.define("ext-input",tt)}catch(t){console.warn("[MORBIS Ext] gagal registrasi ext-input:",t)}var g="[MORBIS Ext] visiteKonsul",C=G();function I(){try{let t=new URLSearchParams(location.search).get("id_visit");return t&&t.trim()?t.trim():null}catch{return null}}var et=U(),E=et+"/api/visite-konsul";function M(t,e){return t?.message||(e?`HTTP ${e.status}`:"gagal menghubungi server")}async function at(t){let e=await fetch(`${E}/list?id_visit=${encodeURIComponent(t)}`,{credentials:"omit"}),a=await e.json().catch(()=>null);return a?.ok?{rows:(a.data||[]).map(r=>({id:r.id,jenis:r.jenis,nama_dokter:r.nama_dokter,id_dokter:r.id_dokter,saving:!1}))}:{rows:[],error:M(a,e)}}async function nt(t,e,a){let r=await(await fetch(`${E}/save`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"omit",body:JSON.stringify({id:e.id,id_visit:Number(t),jenis:e.jenis,id_dokter:e.id_dokter,nama_dokter:e.nama_dokter,user:a})})).json();return r?.ok?{id:r.data.id,jenis:r.data.jenis,nama_dokter:r.data.nama_dokter,id_dokter:r.data.id_dokter,saving:!1}:null}async function rt(t,e){return!!(await(await fetch(`${E}/delete`,{method:"DELETE",headers:{"Content-Type":"application/json"},credentials:"omit",body:JSON.stringify({id:t,id_visit:Number(e)})})).json())?.ok}async function it(t){let e=await fetch(`${E}/dokter?q=${encodeURIComponent(t)}`,{credentials:"omit"}),a=await e.json().catch(()=>null);return a?.ok?{items:a.data||[]}:{items:[],error:M(a,e)}}function ot(){try{let t=document.querySelector('input[name="id_user"], #id_user');if(t?.value?.trim())return t.value.trim()}catch{}return"petugas"}function st(){let t=document.createElement("style");t.textContent=`
    .ext-vk-card { margin: 12px 0; padding: 12px; border: 1px solid var(--ext-border); border-radius: var(--ext-radius-md); background: var(--ext-surface); font-family: var(--ext-font-family); }
    .ext-vk-card h2, .ext-vk-card h3 { margin: 0 0 8px; font-size: var(--ext-font-size-md); font-weight: 700; color: var(--ext-text); }
    .ext-vk-card > ext-btn { margin-right: 6px; }
    .ext-vk-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
    .ext-vk-table th, .ext-vk-table td { border: 1px solid var(--ext-border); padding: 4px 6px; font-size: var(--ext-font-size-sm); color: var(--ext-text); }
    .ext-vk-table th { background: var(--ext-surface-2); }
    .ext-vk-autocomplete { position: relative; }
    .ext-vk-input { width: 100%; box-sizing: border-box; padding: 6px 10px; font-size: var(--ext-font-size-sm); border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); font-family: var(--ext-font-family); color: var(--ext-text); background: var(--ext-surface); }
    .ext-vk-suggest { position: absolute; top: 100%; left: 0; right: 0; background: var(--ext-surface); border: 1px solid var(--ext-border); border-radius: var(--ext-radius-sm); max-height: 160px; overflow-y: auto; z-index: 9999; box-shadow: var(--ext-shadow-md); }
    .ext-vk-suggest div { padding: 6px 8px; font-size: var(--ext-font-size-sm); color: var(--ext-text); cursor: pointer; }
    .ext-vk-suggest div:hover { background: var(--ext-surface-2); }
    .ext-vk-status { font-size: var(--ext-font-size-xs); color: var(--ext-text-muted); margin-left: 6px; }
    .ext-vk-warn { margin: 0 0 8px; padding: 8px 10px; font-size: var(--ext-font-size-sm); border-radius: var(--ext-radius-sm); background: var(--ext-danger-soft); border: 1px solid #f3c1be; color: var(--ext-danger); }
  `,document.head.appendChild(t)}function dt(t,e,a){let r=()=>{let s=t.value;return typeof s=="string"?s:t.getAttribute("value")??""},b=s=>{let m=t;try{m.value=s}catch{}t.setAttribute("value",s)},v=t.parentElement,i=null,x=null;function d(){i&&(i.remove(),i=null)}t.addEventListener("input",()=>{x&&window.clearTimeout(x),x=window.setTimeout(async()=>{let s=r().trim();if(s.length<2){d();return}let{items:m,error:h}=await it(s);if(d(),!(!m.length&&!h)){if(i=document.createElement("div"),i.className="ext-vk-suggest",h&&!m.length){let o=document.createElement("div");o.textContent=`Pencarian dokter gagal: ${h}`,o.style.color="var(--ext-danger)",i.appendChild(o),v.appendChild(i);return}for(let o of m){let l=document.createElement("div");l.textContent=o.nama,l.addEventListener("mousedown",k=>{k.preventDefault(),b(o.nama),a(o.id,o.nama),d()}),i.appendChild(l)}v.appendChild(i)}},250)}),t.addEventListener("blur",()=>window.setTimeout(d,150))}function $(t,e,a,r,b,v){let i=document.createElement("div");i.className="ext-vk-card";let x=document.createElement("h3");x.textContent=t,i.appendChild(x);let d=document.createElement("table");d.className="ext-vk-table";let s=document.createElement("thead");s.innerHTML='<tr><th style="width:40px">No</th><th>Dokter</th><th style="width:60px">Aksi</th></tr>',d.appendChild(s);let m=document.createElement("tbody");d.appendChild(m),i.appendChild(d);let h=document.createElement("ext-btn");h.setAttribute("variant","secondary"),h.setAttribute("size","sm"),h.textContent="+ Tambah",i.appendChild(h);let o=document.createElement("ext-btn");o.setAttribute("variant","primary"),o.setAttribute("size","sm"),o.textContent="Simpan",i.appendChild(o);let l=document.createElement("span");l.className="ext-vk-status",i.appendChild(l);function k(){m.innerHTML="",a.filter(n=>n.jenis===e).forEach((n,c)=>{let f=document.createElement("tr"),N=document.createElement("td");N.textContent=String(c+1),f.appendChild(N);let D=document.createElement("td"),_=document.createElement("div");_.className="ext-vk-autocomplete";let p;if(window.customElements?.get?.("ext-input")){p=document.createElement("ext-input"),p.setAttribute("type","text"),p.setAttribute("size","sm"),p.setAttribute("placeholder","Ketik nama dokter...");try{p.value=n.nama_dokter}catch{}p.setAttribute("value",n.nama_dokter)}else{let u=document.createElement("input");u.type="text",u.placeholder="Ketik nama dokter...",u.value=n.nama_dokter,u.className="ext-vk-input",p=u}_.appendChild(p),D.appendChild(_),dt(p,n,(u,xt)=>{n.id_dokter=u,n.nama_dokter=xt,l.textContent="Belum disimpan"}),p.addEventListener("change",()=>{let u=p.value;n.nama_dokter=(typeof u=="string"?u:p.getAttribute("value")??"").trim(),l.textContent="Belum disimpan"}),f.appendChild(D);let R=document.createElement("td"),y=document.createElement("ext-btn");y.setAttribute("variant","danger"),y.setAttribute("size","sm"),y.textContent="Hapus",y.addEventListener("click",async()=>{if(n.id&&!await rt(n.id,r)){l.textContent="Gagal hapus";return}let u=a.indexOf(n);u>=0&&a.splice(u,1),k(),l.textContent="Dihapus"}),R.appendChild(y),f.appendChild(R),m.appendChild(f)})}async function pt(n){if(!n.nama_dokter.trim()||n.saving)return!1;n.saving=!0;let c=await nt(r,n,b);return n.saving=!1,c?(n.id=c.id,n.id_dokter=c.id_dokter,n.nama_dokter=c.nama_dokter,!0):!1}o.addEventListener("click",async()=>{let n=a.filter(f=>f.jenis===e&&f.nama_dokter.trim());if(!n.length){l.textContent="Belum ada data";return}o.setAttribute("loading",""),l.textContent="Menyimpan...";let c=0;for(let f of n)await pt(f)&&c++;o.removeAttribute("loading"),l.textContent=c===n.length?"Tersimpan":`Tersimpan ${c}/${n.length}`,c!==n.length&&console.warn(g,"gagal simpan",e,c,"/",n.length)}),h.addEventListener("click",()=>{a.push({id:null,jenis:e,nama_dokter:"",id_dokter:null,saving:!1}),k()}),k(),v.appendChild(i)}function lt(){return Array.from(document.querySelectorAll("h2.judul")).find(e=>/halaman\s+utama/i.test(e.textContent||""))||Array.from(document.querySelectorAll("h1, h2, h3")).find(e=>/halaman\s+utama/i.test(e.textContent||""))||null}async function ut(t=5e3){let e=Date.now()+t;for(;;){let a=lt();if(a||Date.now()>e)return a;await new Promise(r=>setTimeout(r,250))}}async function ct(){let t=I();if(!t||C.__extVisiteKonsul)return;C.__extVisiteKonsul=!0,F(),st();let e=ot(),a=document.querySelector("#main-content, .content, main, #content");a||(a=document.body);let r=document.createElement("div");r.className="ext-vk-card";let b=document.createElement("h2");b.textContent="Visite & Konsul Dokter Spesialis IGD (input manual)",r.appendChild(b);let v=await ut();v?v.insertAdjacentElement("afterend",r):a.insertBefore(r,a.firstChild);let{rows:i,error:x}=await at(t);if(x){let s=document.createElement("div");s.className="ext-vk-warn",s.textContent=`API visite-konsul tidak aktif (${x}). Pencarian & simpan dokter akan gagal sampai admin Reports mengaktifkan grup API ini.`,r.appendChild(s),console.warn(g,"api list gagal:",x)}let d=i;$("VISITE","visite",d,t,e,r),$("KONSUL","konsul",d,t,e,r),console.log(g,"loaded",d.length,"rows for visit",t)}typeof C.featureModules<"u"?C.featureModules.visiteKonsul={id:"visiteKonsul",name:"Visite & Konsul Dokter (IGD)",description:"Input manual visite & konsul dokter spesialis IGD di halaman utama pelayanan (data di Reports SIMRS)",match:{pathname:"/admisi/pelaksanaan_pelayanan/halaman-utama"},enabledWhen:()=>!!I(),run:()=>V(()=>{ct().catch(t=>console.error(g,t))},500)}:console.warn(g,"featureModules not defined, registration skipped")})();
