"use strict";var __morbis_feature=(()=>{var C="extensionConfig";function at(g,u,w){let f=u?.features?.[g];if(!f)return!0;if(f.enabled===!1)return!1;let S=w??u?.currentRole??"admin";if(S==="admin")return!0;let x=f.allowedRoles;return!Array.isArray(x)||x.length===0?!0:x.includes(S)}async function et(g){try{let u=(await chrome.storage.sync.get(C))?.[C]??null;return at(g,u)}catch{return!0}}function nt(g,u){et(g).then(w=>{if(w)try{u()}catch(f){console.error(`[featureGate:${g}] gagal jalan:`,f)}})}nt("telaahResep",function(){"use strict";async function g(){let S="ext-telaah-proc",x=document.querySelector(".halaman");if(!x||x.getAttribute(S))return;let d=x;d.setAttribute(S,"1");let p=t=>(t?.textContent||"").replace(/\s+/g," ").trim();function o(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let it=t=>t?o(t.replace(/^(.*?)(\d+)$/,`$1
$2`)):"-",rt=d.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",R="RSUD H. ABDUL MANAP",L=[],M=d.querySelector("#head-cetak-logo");if(M){let t=M.querySelector("b");R=t?p(t):R;let e=document.createElement("div");e.innerHTML=M.innerHTML.replace(/<br\s*\/?>/gi,`
`),L=(e.textContent||"").split(`
`).map(a=>a.trim()).filter(Boolean).filter(a=>a!==R)}let _=new Map,q=[];d.querySelectorAll(".halaman > table:first-of-type table").forEach(t=>{t.querySelectorAll("tr").forEach(e=>{let a=e.querySelectorAll("td");if(a.length<2)return;let n=p(a[0]),l=p(a[1]).replace(/^:\s*/,"");if(n&&!_.has(n)&&_.set(n,l),/^diagnosa$/i.test(n)){let i=(a[1].innerHTML||"").replace(/<br\s*\/?>/gi,`
`),r=document.createElement("div");r.innerHTML=i,q=(r.textContent||"").split(`
`).map(s=>s.trim()).filter(s=>s&&!/^:/.test(s)&&!/tidak ada/i.test(s))}})});let lt=t=>_.get(t)??"",N=[],U=Array.from(d.querySelectorAll("table.resep-item"))[1],D="",K="",A=[],E=[],ot="",P="",v="";async function st(){let t=new URLSearchParams(window.location.search),e=t.get("id_resep")||t.get("id")||t.get("penjualan")||"";if(!e)return;let a="/inventory/resep/penerimaan/detail?id="+e;try{let n=await fetch(a,{credentials:"include"});if(!n.ok)return;let l=await n.text(),i=new DOMParser().parseFromString(l,"text/html"),r=m=>(i.querySelector("#"+m)||i.querySelector('input[name="'+m+'"]')||i.querySelector('input[id*="'+m+'"]')||i.querySelector("textarea#"+m)||i.querySelector('textarea[name="'+m+'"]'))?.value?.trim()||"";D=r("id_visit")||t.get("visit")||D,K=r("id_kunjungan")||K,P=r("no_sep")||P,v=r("catatan")||v;let s=Array.from(i.querySelectorAll("fieldset#perhatian")).find(m=>{let h=m.querySelector("legend");return h&&/riwayat\s*diagnosa\s*pasien/i.test(p(h))});if(s){let m=Array.from(s.querySelectorAll("li")).map(b=>p(b)).filter(Boolean),h=-1,Mt=Array.from(s.querySelectorAll("strong, b"));for(let b of Mt)if(/diagnosa\s*sekunder/i.test(p(b))){let X=b.closest("li");if(X){let k=Array.from(s.querySelectorAll("li")).indexOf(X);k>=0&&(h=k)}else{let k=b.nextElementSibling;if(k&&k.tagName==="OL"){let Z=k.querySelector("li");if(Z){let tt=Array.from(s.querySelectorAll("li")).indexOf(Z);tt>=0&&(h=tt)}}}break}h>=0&&h<m.length?(A=m.slice(0,h),E=m.slice(h).filter(b=>b&&!/tidak ada/i.test(b))):m.length&&(A=m)}}catch{}}function mt(t){let e=i=>typeof i=="string"?i.trim():"",a=e(t.nama_barang),n=e(t.sediaan);if(!n)return a;let l=n.charAt(0).toUpperCase()+n.slice(1).toLowerCase();return a.toLowerCase().includes(l.toLowerCase())?a:a?a+", "+l:l}function dt(t){return{NO_R:t.no_r,JENIS_R:t.jenis_r,JENIS_RSP:t.jenis_r,NAMA_RACIKAN:t.nama_racikan,ATURAN_PAKAI_MANUAL:t.aturan_pakai_manual,JUMLAH_RACIKAN:t.jumlah_racikan,NAMA:mt(t),KEKUATAN_R_RACIK:t.kekuatan_r_racik,KEKUATAN:t.kekuatan,JUMLAH_R_PAKAI:t.jumlah_r_pakai,SEDIAAN:t.sediaan,JUMLAH_R_RESEP:t.jumlah_r_resep}}async function ct(t){try{let e=await fetch("/inventory/search?opsi=tabel_penjualan_lama&id_penjualan="+encodeURIComponent(t),{credentials:"include",cache:"no-store"});if(!e.ok)return[];let a=await e.json(),n=Array.isArray(a)?a:Object.values(a??{}),l=i=>Number(i.id_detail_penjualan_resep??i.id_detail_penjualan??i.ID??0)||0;return n.filter(i=>typeof i=="object"&&i!==null).sort((i,r)=>l(i)-l(r)).map(dt).filter(i=>String(i.NO_R??"").trim()!=="")}catch{return[]}}async function pt(){let t=y.get("id_resep")||y.get("id")||y.get("penjualan")||"";if(!t)return[];try{let e=await fetch("/inventory/resep/akses/penerimaan?type=ajax&opsi=data-resep-new&q=1&id="+encodeURIComponent(t),{credentials:"include",cache:"no-store"});if(!e.ok)return[];let a=await e.json(),n=String(a?.CATATAN??"").trim();n!==""&&(v=n);let l=Array.isArray(a?.resep)?a.resep:[];if(l.some(r=>String(r.JENIS_R??"").trim()!==""))return l;let i=String(a?.ID_PENJUALAN??"").trim();if(i&&i!=="0"){let r=await ct(i);if(r.length)return r}return l}catch{return[]}}function ht(t){try{let e=new URL(t);if(e.protocol!=="http:"&&e.protocol!=="https:")return!1;let a=e.hostname.toLowerCase();return["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"].includes(a)?!0:a.endsWith(".rsudkotajambi.id")||a.endsWith(".ddev.site")}catch{return!1}}async function gt(t){try{let e="http://dev.rsudkotajambi.id/rs";try{let l=localStorage.getItem("ext-farmasi-app-base");l&&ht(l)&&(e=l.replace(/\/+$/,""))}catch{}let a=await fetch(e+"/api/queue/lookup?resep_id="+encodeURIComponent(t),{cache:"no-store",credentials:"omit",signal:AbortSignal.timeout(8e3)});if(!a.ok)return"";let n=await a.json();if(n.ok&&n.found&&n.queue?.queue_number)return n.queue.queue_number}catch{}return""}let y=new URLSearchParams(window.location.search),J=y.get("id_resep")||y.get("id")||y.get("penjualan")||"";await st();let H=await pt();if(H.length){N.length=0;let t=new Map;for(let e of H){let a=String(e.NO_R??"").trim();a&&(t.has(a)||t.set(a,[]),t.get(a).push(e))}for(let[e,a]of t){let n=a[0],l=String(n.JENIS_R??"").toLowerCase()==="racikan"||String(n.JENIS_RSP??"").toLowerCase()==="racikan"||Number(n.JUMLAH_RACIKAN??0)>0||String(n.NAMA_RACIKAN??"").trim()!=="",i=String(n.NAMA_RACIKAN??"").trim(),r=String(n.ATURAN_PAKAI_MANUAL??"").trim().replace(/^-\s*/,"").trim();if(l||a.length>1){let s={no:"R/"+e,name:i||"",jml:"",jumlahJadi:String(n.JUMLAH_RACIKAN??"").trim()||"",sediaan:i,aturan:r?[r]:[],subMeds:a.map(m=>({name:String(m.NAMA??"").trim(),strength:String(m.KEKUATAN_R_RACIK??m.KEKUATAN??"").trim(),dose:"",jmlPerR:String(m.JUMLAH_R_PAKAI??"").trim(),sediaan:String(m.SEDIAAN??"").trim()}))};N.push(s)}else{let s={no:"R/"+e,name:String(n.NAMA??"").trim(),jml:String(n.JUMLAH_R_RESEP??n.JUMLAH_R_PAKAI??"").trim(),jumlahJadi:"",sediaan:String(n.SEDIAAN??"").trim(),aturan:r?[r]:[],subMeds:[]};N.push(s)}}}!A.length&&q.length&&(A=q);let O=d.querySelector("#form_checklist_telaah_resep"),B=t=>{let e=[];if(!O)return e;let a=Array.from(O.querySelectorAll("table")).find(n=>p(n.querySelector("tr td"))===t);return a&&a.querySelectorAll("tr").forEach((n,l)=>{if(l===0)return;let i=n.querySelectorAll("td");if(i.length<2)return;let r=p(i[0]),s=p(i[1]);r&&s&&s!==t&&e.push([r,s])}),e},ut=B("Telaah Resep"),ft=B("Telaah Obat"),$=Array.from(d.querySelectorAll("center, strong")).find(t=>/Obat tidak boleh diganti/i.test(p(t))),bt=$?p($):"Obat tidak boleh diganti tanpa sepengetahuan Dokter",z=(t,e,a="",n="")=>'<div class="tm-row'+(n?" "+n:"")+'"><span class="tm-label">'+o(t)+':</span><span class="tm-val'+(a?" "+a:"")+'">'+(e&&e.trim()?o(e):"-")+"</span></div>",F=[...A.length?[A.join(", ")]:[],...E.length?[E.join(", ")]:[]],c=t=>lt(t),T=c("Jenis Kelamin"),xt=/^perempuan$/i.test(T)?"P":/^laki-laki$/i.test(T)?"L":T,At=(c("Nama Pasien")||"-")+(T?" ("+xt+")":""),yt=(c("Dokter")||"-")+(c("Ruangan/Poli")?" / "+c("Ruangan/Poli"):""),W=t=>{for(let e of _.keys())if(t.test(e))return _.get(e)||"";return""},kt=W(/alergi/i),j=W(/berat|\bbb\b/i),Y=j?/\bkg\b/i.test(j)?j:j+" kg":"- kg",wt=(kt||"-")+" / "+(j?"BB "+Y:Y),St=[["Pasien",At,""],["No. RM",c("No. RM"),""],["Tgl. Lahir",c("Tgl. Lahir/Umur"),""],["Alergi & BB",wt,""],["Alamat",c("Alamat"),"long"],["No HP",c("No HP"),""]],_t=[["Dokter",yt,""],["SIP Dokter",c("SIP Dokter"),""],["No Resep",c("No Resep"),""],["No SEP",P||"-",""],["Tanggal",c("Tanggal & Jam"),""],["Penjamin",c("Penjamin"),""]],vt=z("Diagnosa",F.length?F.join(", "):"-","","long"),jt='<section class="tm-card tm-card--small tm-card--left"><div class="tm-col">'+St.map(([t,e,a])=>z(t,e,"",a)).join("")+vt+"</div></section>",Rt='<section class="tm-card tm-card--right"><div class="tm-col">'+_t.map(([t,e,a])=>z(t,e,"",a)).join("")+"</div></section>",Nt=N.map(t=>{if(t.subMeds.length){let a=t.subMeds.map((i,r)=>{let s=i.jmlPerR||"";return'<div class="med-line'+(r>0?" indent":"")+'">'+(r===0?'<span class="med-no">'+o(t.no)+"</span> ":"")+'<span class="med-name">'+o(i.name)+"</span>"+(s?', <span class="med-jml">Jml: '+o(s)+"</span>":"")+"</div>"}).join(""),n=t.jumlahJadi?'<div class="med-line indent"><span class="med-name">Sediaan Racikan: '+o(t.sediaan||"Racikan")+'</span>, <span class="med-jml">Jml: '+o(t.jumlahJadi)+"</span></div>":"",l=t.aturan.length?'<div class="med-aturan">Aturan pakai: '+t.aturan.map(i=>o(i.replace(/^\(|\)$/g,""))).join(" ")+"</div>":"";return'<div class="med">'+a+n+l+"</div>"}let e=t.jml||"";return'<div class="med"><div class="med-line"><span class="med-no">'+o(t.no)+'</span> <span class="med-name">'+o(t.name)+"</span>"+(e?', <span class="med-jml">Jml: '+o(e)+"</span>":"")+"</div>"+(t.aturan.length?'<div class="med-aturan">'+t.aturan.map(a=>o(a)).join("<br/>")+"</div>":"")+"</div>"}).join(""),I=U?Array.from(U.querySelectorAll("tr:first-child td")).map(t=>p(t)).filter(Boolean):["Hitung","Timbang","Kemas"];I.some(t=>/paraf/i.test(t))||I.push("Paraf");let Tt=I.length,It='<table class="t-admin"><thead><tr>'+I.map(t=>'<th class="c">'+o(t)+"</th>").join("")+"</tr></thead><tbody><tr>"+Array.from({length:Tt}).map(()=>'<td class="blk"></td>').join("")+"</tr></tbody></table>",G=(t,e)=>'<table class="t-check"><thead><tr><th class="l" colspan="2">'+o(t)+'</th><th class="yt">Y/T</th></tr></thead><tbody>'+e.map(([a,n])=>'<tr><td class="num">'+o(a)+"</td><td>"+o(n)+'</td><td class="yt"></td></tr>').join("")+"</tbody></table>",Lt='<header class="t-head"><img class="t-logo" alt="Logo" src="'+o(rt)+'"/><div class="t-bhead"><h1 class="t-hname">'+o(R)+"</h1>"+(L[0]?'<div class="t-hsub">'+o(L[0])+"</div>":"")+'</div><div class="t-antrian">'+it(ot)+'</div></header><main class="t-main"><section class="t-left">'+jt+'<div class="t-meds">'+Nt+"</div>"+(v.trim()!==""?'<div class="t-catatan"><div class="t-catatan-title">Catatan</div><div class="t-catatan-body">'+o(v).split(`
`).map(t=>t.trim()).filter(Boolean).join("<br/>")+"</div></div>":"")+It+'<table class="t-admin t-lampiran"><thead><tr><th class="c third">Srt. Rujuk Balik</th><th class="c third">Surat Iter</th><th class="c third">Hasil Lab</th></tr></thead><tbody><tr><td class="blk"></td><td class="blk"></td><td class="blk"></td></tr></tbody></table></section><section class="t-right">'+Rt+G("Telaah Resep",ut)+G("Telaah Obat",ft)+'<table class="t-check"><thead><tr><th class="c" colspan="2">Perubahan resep</th></tr><tr><th class="c half">Tertulis</th><th class="c half">Menjadi</th></tr></thead><tbody><tr><td class="blk4"></td><td class="blk4"></td></tr><tr><td class="c">Apoteker</td><td class="c">Disetujui Dokter</td></tr><tr><td class="blk4"></td><td class="blk4"></td></tr><tr><td class="c" colspan="2">Waktu Tunggu</td></tr><tr><td class="third">Masuk</td><td></td></tr><tr><td>Diserahkan</td><td></td></tr><tr><td class="twothird">Paraf Pasien/Keluarga</td><td class="blk3"></td></tr></tbody></table></section></main><footer class="t-footer">'+o(bt)+'</footer><div class="t-print no-print"><button type="button" class="t-btn" onclick="window.print()">Cetak</button></div>';if(d.innerHTML=Lt,J){let t=d.querySelector(".t-antrian");gt(J).then(e=>{e&&t&&t.isConnected&&(t.textContent=e.replace(/^(.*?)(\d+)$/,`$1
$2`))})}let V=866;d.scrollHeight>V&&(d.classList.add("compact"),d.offsetHeight,d.scrollHeight>V&&(d.classList.remove("compact"),d.classList.add("ultra")));let Q="ext-telaah-style";if(!document.getElementById(Q)){let t=document.createElement("style");t.id=Q,t.textContent=`
        /* === PRINT CONTRACT: 105mm \xD7 241mm === */
        .halaman{box-sizing:border-box;width:105mm!important;height:auto!important;max-height:241mm;margin:0!important;padding:0 3mm}
        @page{size:105mm 241mm;margin:0}
        .halaman *{box-sizing:border-box;font-size:11px!important}
        .halaman{font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.25;color:#000;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}

        /* HEADER 3 kolom: logo | brand & alamat | no antrian */
        .t-head{display:flex;align-items:center;padding-bottom:6px;border-bottom:1.5px solid #000;margin-bottom:8px;gap:10px}
        .t-logo{width:50px;height:50px;object-fit:contain;object-position:left top;flex:none}
        .t-bhead{flex:1;font-size:11px;min-width:0}
        .t-hname{font-size:12px;font-weight:800;margin:0 0 2px;letter-spacing:-.01em}
        .t-hsub{line-height:1.2;font-size:10px}
        .t-antrian{flex:none;text-align:right;font-size:36px!important;font-weight:800;color:#198754;letter-spacing:-.02em;font-variant-numeric:tabular-nums;min-width:0;overflow-wrap:anywhere;line-height:1;white-space:pre-line}

        /* METADATA \u2014 grid: label kiri, nilai kanan (efisien tinggi) */
        .tm-card{background:#fff;padding:2px 0 4px;margin-bottom:4px;font-size:11px;border-bottom:0.5pt solid #333}
        .tm-card--small .tm-label{font-size:9px!important}
        .tm-card--small .tm-val{font-size:10px!important}
        .tm-col{display:flex;flex-direction:column;gap:3px}
        .tm-row{display:grid;grid-template-columns:35% 65%;column-gap:4px;align-items:start}
        .tm-card--left .tm-row{grid-template-columns:20% 65%}
        .tm-card--right .tm-row{grid-template-columns:30% 65%}
        .tm-label{color:#5b6470;font-size:10px;line-height:1.25;text-align:left}
        .tm-val{color:#000;line-height:1.25;word-wrap:break-word;overflow-wrap:anywhere}
        /* field panjang (alamat, diagnosa) tetap di grid 2 kolom biar wrap di kanan */
        .tm-row.long{display:grid}
        .tm-row.long .tm-label{display:block}

        /* MAIN 2 kolom \u2014 kiri lebih lebar utk nama obat */
        .t-main{display:grid;grid-template-columns:62% 38%;gap:6px;align-items:start}
        .t-left,.t-right{display:flex;flex-direction:column;gap:5px;min-width:0}
        .t-right .t-check{margin-bottom:0}
        .t-meds{margin-bottom:8px;font-size:11px;min-width:0}

        /* DAFTAR OBAT */
        .med{margin-bottom:6px}        .med-line{font-size:11px;line-height:1.35;text-align:left}
        .med-line.indent{margin-left:0}
        .med-no{font-weight:400}
        .med-name{font-weight:600}
        .med-sep{color:#374151}
        .med-jml{white-space:nowrap;font-weight:600;color:#047857}
        .med-aturan{margin-left:0;font-size:10px;color:#374151;margin-top:1px}

        /* CATATAN resep (dari textarea #catatan halaman detail) */
        .t-catatan{margin-bottom:8px;border:1px solid #f87171;border-radius:4px;padding:4px 6px;background:#fef2f2}
        .t-catatan-title{font-weight:700;font-size:10px;color:#b91c1c;margin-bottom:2px}
        .t-catatan-body{font-size:11px;color:#7f1d1d;line-height:1.35;white-space:normal}

        /* TABEL \u2014 checklist (font sama dengan info pasien & dokter = 10px) */
        table{width:100%;border-collapse:collapse;font-size:10px}
        .halaman th,.halaman td{border:0.5pt solid #333;padding:1px 3px;font-weight:400;font-size:10px!important;line-height:1.2}
        thead th{font-weight:400}
        .yt{width:32px;text-align:center}
        .num{width:16px;text-align:center}
        .l{text-align:left}
        .c{text-align:center}
        .half{width:50%}
        .third{width:33.333%}
        .twothird{width:66.667%}
        .blk{height:40px;padding:.5pt 3px}
        .blk2{min-height:10px}
        .blk3{min-height:35px}
        .blk4{height:40px;padding:.5pt 3px}
        .t-lampiran{margin-top:0}
        .t-sub{text-align:center;font-size:10px!important;margin:3px 0}

        /* FOOTER + BUTTON */
        .t-footer{margin-top:10px;text-align:center;font-weight:700;font-style:italic;font-size:11px}
        .t-print{margin-top:24px;display:flex;gap:8px}
        .t-btn{border:1px solid #d1d5db;background:#fff;border-radius:6px;padding:6px 14px;font-size:11px;cursor:pointer}
        .t-btn:hover{background:#f9fafb}
        @media print{.no-print{display:none!important}}

        /* === ADAPTIVE DENSITY (gentle fallback) === */
        .halaman.compact .t-head{padding-bottom:4px;margin-bottom:6px;gap:8px}
        .halaman.compact .t-logo{width:45px;height:45px}
        .halaman.compact .t-hname{font-size:11px!important}
        .halaman.compact .t-antrian{font-size:30px!important}
        .halaman.compact .tm-card{padding:1px 0 2px;margin-bottom:2px}
        .halaman.compact .tm-col{gap:2px}
        .halaman.compact .tm-label{font-size:9px!important}
        .halaman.compact .tm-val{font-size:10px!important}
        .halaman.compact .t-main{gap:4px}
        .halaman.compact .t-left,.halaman.compact .t-right{gap:3px}
        .halaman.compact .t-meds{margin-bottom:4px}
        .halaman.compact .med{margin-bottom:3px}
        .halaman.compact .blk{height:30px}
        .halaman.compact .blk3{min-height:25px}
        .halaman.compact .blk4{height:30px}
        .halaman.compact .t-lampiran{margin-top:0}
        .halaman.compact .t-footer{margin-top:6px}

        .halaman.ultra .t-head{padding-bottom:3px;margin-bottom:4px;gap:6px}
        .halaman.ultra .t-logo{width:40px;height:40px}
        .halaman.ultra .t-hname{font-size:10px!important}
        .halaman.ultra .t-antrian{font-size:26px!important}
        .halaman.ultra .tm-card{padding:1px 0;margin-bottom:1px}
        .halaman.ultra .tm-col{gap:1px}
        .halaman.ultra .tm-label{font-size:8px!important}
        .halaman.ultra .tm-val{font-size:9px!important}
        .halaman.ultra .t-main{gap:3px}
        .halaman.ultra .t-left,.halaman.ultra .t-right{gap:2px}
        .halaman.ultra .t-meds{margin-bottom:2px}
        .halaman.ultra .med{margin-bottom:2px}
        .halaman.ultra .med-line{font-size:10px!important}
        .halaman.ultra .blk{height:30px}
        .halaman.ultra .blk3{min-height:20px}
        .halaman.ultra .blk4{height:30px}
        .halaman.ultra .t-lampiran{margin-top:0}
        .halaman.ultra .t-footer{margin-top:4px;font-size:10px!important}
      `,document.head.appendChild(t)}}let u=g,w=Date.now(),f=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-telaah")==="1"?(window.clearInterval(f),u()):Date.now()-w>5e3&&window.clearInterval(f)},200)})})();
