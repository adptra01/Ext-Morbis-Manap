"use strict";var __morbis_feature=(()=>{function Ot(){return window}var St="RSUD H. Abdul Manap";function $t(i){let u=()=>{try{i.focus(),i.print()}catch{}},a=i.document;a.getElementById("btnPrintPdf")?.addEventListener("click",u);let e=Array.from(a.querySelectorAll(".rm-page")),n=a.getElementById("rmSectionSelect"),L=Array.from(a.querySelectorAll(".tab-btn")),s=y=>{n&&(n.value=y),L.forEach(C=>C.classList.toggle("active",C.dataset.target===y)),e.forEach(C=>{let N=y==="all"||C.id===y||C.id.startsWith(`${y}-`);C.classList.toggle("hidden-section",!N)}),i.scrollTo({top:0,behavior:"smooth"})};n?.addEventListener("change",y=>s(y.target.value)),L.forEach(y=>y.addEventListener("click",()=>s(y.dataset.target||"all")));let l=a.getElementById("checkCounter"),d=Array.from(a.querySelectorAll(".rm-checkbox, .vbox")),x=()=>{l&&(l.textContent=`${d.filter(y=>y.checked).length} / ${d.length}`)};d.forEach(y=>y.addEventListener("change",x)),a.getElementById("btnCheckAll")?.addEventListener("click",()=>{d.forEach(y=>y.checked=!0),x()}),a.getElementById("btnResetChecks")?.addEventListener("click",()=>{d.forEach(y=>y.checked=!1),x()}),x();let z=(y,C)=>{let N=a.createElement("button");return N.type="button",N.className="ext-scroll-btn no-print",N.textContent=y,N.addEventListener("click",C),N},p=z("\u2191",()=>i.scrollTo({top:0,behavior:"smooth"})),P=z("\u2193",()=>i.scrollTo({top:a.documentElement.scrollHeight,behavior:"smooth"})),k=a.createElement("style");k.textContent=".ext-scroll-btn{position:fixed;right:14px;width:34px;height:34px;border:1px solid #000;background:#fff;font-size:16px;font-weight:bold;cursor:pointer;z-index:9999;display:flex;align-items:center;justify-content:center}.ext-scroll-btn:first-of-type{bottom:56px}.ext-scroll-btn:last-of-type{bottom:14px}",a.head.appendChild(k),a.body.appendChild(p),a.body.appendChild(P),i.addEventListener("afterprint",()=>{i.confirm("Apakah menu print ini akan ditutup?")&&i.close()})}var yt=Ot(),Pt=["script","style",'link[rel="stylesheet"]',".no-print",".hilang-saat-print","button","input","select","textarea",'label:has(input[type="checkbox"])',".btn","[data-shortcut-buttons]","[data-back-to-detail-klaim]","[data-bpjs-revision-history]","[onclick]",'a[href^="javascript:"]'],nt=i=>document.getElementById(i)?.value?.trim()||"",M=(...i)=>{for(let u of i){let a=nt(u).replace(/^\s*:\s*/,"").trim();if(a)return a}return"-"};function Ut(i){let u=a=>{let e=document.createElement("span");return e.className="fv",e.textContent=a,e};i.querySelectorAll("input").forEach(a=>{let e=(a.type||"text").toLowerCase();if(e==="hidden"){a.remove();return}if(e==="radio"||e==="checkbox"){if(!a.checked){a.remove();return}if(e==="radio"){a.replaceWith(u("\u2713"));return}let L=(a.value||"").trim().replace(/[_-]+/g," ").replace(/\s+/g," ").trim().replace(/\b\w/g,s=>s.toUpperCase());a.replaceWith(u(L?"\u2713 "+L:"\u2713"));return}let n=(a.value||"").trim();n?a.replaceWith(u(n)):a.remove()}),i.querySelectorAll("textarea").forEach(a=>{let e=(a.value||"").trim();e?a.replaceWith(u(e)):a.remove()}),i.querySelectorAll("select").forEach(a=>{let e=(a.options[a.selectedIndex]?.textContent||a.value||"").trim();e?a.replaceWith(u(e)):a.remove()})}function Rt(i){try{if(!i.width||!i.height)return!0;let u=64,a=document.createElement("canvas");a.width=u,a.height=u;let e=a.getContext("2d",{willReadFrequently:!0});if(!e)return!1;e.drawImage(i,0,0,u,u);let n=e.getImageData(0,0,u,u).data,L=0;for(let l=0;l<n.length;l+=4)L+=(n[l]+n[l+1]+n[l+2])/3;let s=L/(u*u);return s<8||s>250}catch{return!1}}function Yt(i){i.querySelectorAll("table").forEach(u=>{if(u.parentElement?.closest("table"))return;let a=Array.from(u.rows),e=a[0]?.cells.length||0;a.length<6||e<4||u.querySelector(".vcol")||a.forEach((n,L)=>{let s=Array.from(n.cells);if(!(!s.length||s.some(l=>l.colSpan>=3)))if(L===0){let l=document.createElement("th");l.className="vcol",l.textContent="Ver",n.appendChild(l)}else{let l=document.createElement("td");l.className="vcol";let d=document.createElement("input");d.type="checkbox",d.className="vbox",l.appendChild(d),n.appendChild(l)}})})}var Qt=/Rincian Biaya|Resume|Telaah|Laboratorium|Radiologi|SPRI|SBPK/i;function Kt(i){i.querySelectorAll(".tabel-juduls").forEach(a=>a.remove()),i.querySelectorAll("h1,h2,td").forEach(a=>{let e=(a.textContent||"").replace(/\s+/g," ").trim();/^RSUD H\.? ABDUL MANAP$/i.test(e)&&a.remove()}),i.querySelectorAll("tr").forEach(a=>{let e=(a.textContent||"").replace(/\s+/g," ").trim();(/^(RSUD H\.? ABDUL MANAP|PEMERINTAH KOTA JAMBI|Jl\. Sk\. Rd\. Syahbudin)/i.test(e)||/^(RINCIAN\s+BIAYA|LAPORAN|FORMULIR)/i.test(e)&&a.querySelector("u,b,strong"))&&a.remove()});let u=i.querySelector("table");u&&Array.from(i.querySelectorAll("hr")).forEach(a=>{u.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_PRECEDING&&a.remove()})}function Dt(i,u=!1){let a=i.cloneNode(!0),e=Array.from(i.querySelectorAll("canvas")),n=Array.from(a.querySelectorAll("canvas"));return e.forEach((L,s)=>{let l=n[s];if(l){if(Rt(L)){l.remove();return}try{let d=document.createElement("img");d.src=L.toDataURL("image/png"),d.style.cssText="max-width:100%;height:auto;",l.replaceWith(d)}catch{let d=document.createElement("div");d.className="fv",d.textContent="[Berkas PDF \u2014 silakan buka di halaman asli]",l.replaceWith(d)}}}),Ut(a),Pt.forEach(L=>a.querySelectorAll(L).forEach(s=>s.remove())),a.querySelectorAll("tr").forEach(L=>{let s=Array.from(L.cells);for(let l=s.length-1;l>=0;l--){let d=s[l];if(!(!(d.textContent||"").trim()&&!d.querySelector("img,table,input")))break;d.remove()}}),a.querySelectorAll("[style]").forEach(L=>{let s=((L.getAttribute("style")||"").match(/(?:text-align|width|vertical-align|white-space)\s*:[^;]+/gi)||[]).join(";");s?L.setAttribute("style",s):L.removeAttribute("style")}),a.removeAttribute("id"),a.removeAttribute("class"),a.removeAttribute("style"),a.querySelectorAll("div").forEach(L=>{!L.children.length&&!(L.textContent||"").trim()&&L.remove()}),Kt(a),u&&Yt(a),a.innerHTML.trim()}function Bt(i,u){let a=(i.querySelector(".panel-heading, .panel-title, legend, h4")?.textContent||"").replace(/\s+/g," ").trim();return a=a.replace(/^Cetak\s+/i,"").replace(/^[\d.,\s-]+/,""),a||`Berkas ${String(u+1).padStart(2,"0")}`}var Ft=/^(Konsul|Radiologi)/i;function xt(){let i=Array.from(document.querySelectorAll(".isidalam")),u=new Set,a=[],e=[];if(i.forEach((n,L)=>{let s=Bt(n,L);if(!Ft.test(s)&&u.has(s))return;u.add(s);let l=Dt(n,Qt.test(s));if(l.length<20){e.push({title:s,docNo:null});return}a.push({title:s,html:l}),e.push({title:s,docNo:a.length})}),!a.length){let n=document.querySelector("#section-to-print");if(n){let L="Detail Klaim";a.push({title:L,html:Dt(n)}),e.push({title:L,docNo:1})}}return{sections:a,inventory:e}}var t=i=>ot(i).replace(/[&<>"']/g,u=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[u]),F=i=>t(i).replace(/\r\n/g,`
`).replace(/\n{3,}/g,`

`).replace(/\n/g,"<br/>"),Nt=i=>(new DOMParser().parseFromString(i.replace(/src="data:[^"]*"/g,""),"text/html").body.textContent||"").replace(/\s+/g," ").trim(),Gt=i=>{let u=i.split(/[-/]/).map(L=>L.trim());if(u.length!==3)return i;let[a,e,n]=u;return a.length===4?`${a}-${e.padStart(2,"0")}-${n.padStart(2,"0")}`:`${n}-${e.padStart(2,"0")}-${a.padStart(2,"0")}`},Jt=/(?:Tgl|Tanggal)\.?\s*Masuk(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,Ht=/(?:Tgl|Tanggal)\.?\s*(?:Keluar|Pulang)(?:\s*RS)?\s*[:.]?\s*(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})/gi,Et=/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]{8,})/gi;function Wt(i,u){let a=[],e=i.map(p=>({t:p.title,x:Nt(p.html)})),n=p=>{let P=[],k=new Set;return e.forEach(y=>{let C=new RegExp(p.source,p.flags),N;for(;N=C.exec(y.x);){let h=y.t+"|"+N[1];k.has(h)||(k.add(h),P.push({t:y.t,d:p===Et?N[1]:Gt(N[1])}))}}),P},L=n(Jt);new Set(L.map(p=>p.d)).size>1&&a.push({level:"warn",title:"Tanggal masuk berbeda antar berkas",detail:L.map(p=>`${p.t} ${p.d}`).join(" \xB7 ")+" \u2014 samakan sebelum berkas dikirim ke verifikator."});let s=n(Ht);if(L.length&&s.length){let p=L.map(k=>k.d).sort()[0],P=s.map(k=>k.d).sort().pop();P<p&&a.push({level:"warn",title:"Tanggal keluar lebih awal dari tanggal masuk",detail:`Masuk ${p} \xB7 Keluar ${P}.`})}let l=n(Et);new Set(l.map(p=>p.d)).size>1&&a.push({level:"warn",title:"Nomor SEP berbeda antar lembar",detail:l.map(p=>`${p.t} ${p.d}`).join(" \xB7 ")});let d=[/^SEP$/i,/SBPK/i,/Resume/i,/Rincian Biaya/i],x=u.filter(p=>p.docNo===null&&d.some(P=>P.test(p.title)));x.length&&a.push({level:"warn",title:"Berkas inti belum terisi",detail:x.map(p=>p.title).join(", ")+"."});let z=e.find(p=>/Rincian Biaya/i.test(p.t));return z&&!/Total\s+(Biaya|Transaksi|Resep|Jasa)/i.test(z.x)&&a.push({level:"warn",title:"Rincian biaya tanpa baris total",detail:"Tidak ditemukan Total Biaya/Transaksi/Resep pada lembar Rincian Biaya."}),["Laboratorium","Radiologi"].forEach(p=>{let P=e.find(k=>new RegExp(p,"i").test(k.t));P&&P.x.length<60&&a.push({level:"info",title:`Lembar ${p} hanya lampiran gambar`,detail:"Tidak ada teks hasil yang bisa dicocokkan otomatis \u2014 cocokkan manual dengan Resume dan Rincian Biaya."})}),a}var _t="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAIAAAABc2X6AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAb0klEQVR4nOV7d3gUVdv+MzM72zebLdnNJtn03kgIJQQIHRN6AAEVBHn15QWliSIoiqIiIKDYX6VbEJCOdOkkhJJCIL1v+ibZXmZ3yu+PVX4ImLKU77uu7772n/Oc8zznvvfMmVMHYRgGHgaHwzFp/Jjeffo+NPd/M3Jzcg4c+f2fclkdeCb16vPeBx8+AUpPFqtWvttBLvrUePwvQUct7MK3BQd/K7/wFKg8Ot7pNX2oOqnjMp0LLtfXn63LvdeCAMLAw3v+/yxejh7VaZnOBT+Iwb49Kgz1tWatKznUNyFaFnSy5tr8HhO/KzgUKwvKCB64vfiEkyYnBA90lVl65btlSc/naEsPV2XdjfNs6CAUkN3l51f2eTFPW36oKvPtpOfNTtuR6qzFCc9uLzoxPWIEC8WaLG1rbu5anfLK1sJjpfo6l2+af+8TtdfdIO9OH54YknpXCQAkeIVlBA/8uN/LA1RxDDA/P/NekjJi/+iPUn3i/xUz+tX4iTOj0pQ88Yo+M+fEjrs3ziDfhCF+iWI2/70+s+bGjQeA5yNGLE6ckqyMnt9jUpin79z4CQny0PeTZw/0if137Fi1UHHXd0ni1AR5iBvku9HCCp54SeJULsaeGj5ET5hDxD7tduP63N0AECn1V/FlIw8uGeKXWNBa0XvPHM1Le3O15ZN/f++HYW/6bZ08KrBvub4u2TsGQxDq7wNhsnd0ub6ur3cMhiAAIMB5vRThesLsyv255HSkxN9OOlzJWGngcHUSiiCD/BLe6zPzYn1+m83wc9kf9D8Mrg+iGy3cYjP8XHJ6hH8vL54kzFOd6BW2teiYhSQAwEcgRxAkWKwSswUNllaKYVqsOg+2ABAAAECgvyruWFUWzTBRkoD7wvZXxR2vyXZQzhhpEABU6OvGBKWU6WpduZsGLeCy2K02vSt5p72aYqjVKf/GUVZGSOr44AFn63O7rrZ7ggHgVlvVkapMmqEBYGfxSY251WXXE6Yfi07MjEpvtRkDPbzZKOYj9GqzG+86pqhiZ0Slidj8/qpYABjkE//NoIVcDHfQZH9V7AsRI8UcoSurWFcbLPYtN/zZV4ftW5irLcsISXUlGYAvbx08U3vDlZx3fmO9pa1bErrdh5O9o4cfWPz8iVUj7hkAclrKfrhztJ8qtsrYECL2a/zXAQxBLzfccuXiCNbHO2pb0bErDQUuVXbK8e+48S9EjizV1fbxjtpedPxyw62/BNdUGuodNOXy3TNqVX+f+Pq/XpAAIMJ5ERL/UYfe/LHoxPjgAd3l3723NJ/FmXx8pdZmAIDMxtsu4+WGW42W1symwrcuf6MjzKMOvzkqsN+vpX8YnbYSneaTGz+J2PxV2ds/y/stVhYULwsGgOzm4rlnN3jxPfeUXxDivI15v8VIAxPkIefrcrOa7tSYmk0OW6Wx8d2sHzAEa7C07am4oBBIyw31ACDlivrtnddqNx6vvZ7kFdpdwUgHc+nVH656/8OPllz6emPe3kR5iIjN7270p4bbbdXthOmXke88FzFi1cp3O5gRd7WFvx78ej9VzGOi9/gx+vDSYzXXulKye490iZ5ss9NuUXpS8OajwR7dUNE9wdeaHQVtzm5SerJI9mZ3S/D/udWS+4JJu5UkbO75tpXlW7X1blf9KHBn8QAATotR/+18hs1DU59jaIqhaYahgWEYmmZoyvUDmmEY6q7lr1zaqCmz6Zrs+jZ5RE+Oh9TlDjTFMHd9GVwoDp+y+PFKdcFNwY72JtRTAQDIjaP3mBFAALHolZbmu8mHAwWQYnRzXn5+W4JKhiDIPSEAAOhmxnYYYeRqp8QP9Q7iShT/EKjbcFOwQB0uePnTh2Y5dC2GK3tFrdV/NzMAYGlt5Mu875UXLAss1lRGhEa4yvCMzYh3MGNsxXSNXhWXoQIAwEFRJpbAoQpzqCId6hi+fxSCYe7RBrcFdwC2RAFjXiUfsDstxspTv0Rl/OdeIw9AdCdbQ9hUPQcDQGt5Ln7xJ5LGHc8s5ub8jvI9vDU5bAyTMXZoKICGAubGXj2wzL6xMPFNDOe4Qe/xC/4nlJ/8OXz0rAftipi+JYc3y8IT2EJPTmgihCSwEWADAvGpAFBTliM6t0XxZx8BBAEJkJKGvDJNiSA43g0aT0lwe0WB2D+CMOm157apuVdkHA0gtJ7wrbEmS3pMCE2bXnp0e9TE/wAAIH/r97ywns7gHpXZh+XX9nowjrt2zNzuHpOnJLju6gm5hBggmTlhsZnLuTt7v02SJ4+fWvfbqRlcSV99dZFnYNSDvgiGcVMydPFDDOd2KEovclAE4P7/pet4GhOPloIsWduWL+dtnDbJ5FJLUiKSEgEAiwVjR9m+ff2HQPtX5ad+6SAILvTExi6sn7q60TOQpGlG5ucemSfewgzDMAWfbv6mmcdlKJrX1DxWp+9PUh4ACAszSCVXlIojfL5tzdLc2XOqdZXTJMEdLVG4fhHMS+srS28KfdzZ0IKn0MI15w/Mn3aJx2UcTmlZ2XKjoS+XY/QQVXqIKjgck16fUlb2jtPpiWGwYa2h6fKOrsQUhney+dwBnrhgr/avevV0AiDVNa8iCC4UaDzZ+TLjcZnudwlyVSjQoAhSXTsHAJHL6NTA/ZS709Uu4skKNjVUjR90BwAMxgSHQ8XhGoVIMTsnl7zEcV7i49mVHtYsNtdIEAEGUxwAPDPU0FLozm5z1/FkBetrS2OiSQAwmuIxFsFmm1n1lUSFj+2WyJYrslcoscpGNm7GWHaTKR4AoiJIc2P1E6X0ZF9aTqtFJKIBgKRECEqhqBPsFGNnUW0oYwVahTE2FAUCQWiS9AAAnM2gtOWJUnqyLcz18GxrQwEAx3UMjVEUjsg5LC8LO8LBiXXiSjuiQCjgMwwLx3UAYLUiwJbcF6ROm/uQ0O7iyQqWBMfm5eMA4OlxkyS5TgefUMSyE9oFCTX8nhpujzpHcJzDISKdXLH4BgDk5eOSkPuHpQuNOw3mx7Z4fjyPNEORDEOjLPY9JpomSZ5UcenmgAw4IxQUC/l3CLsfIIzTX4Kr2xGasqEygvAg7GKBoFDILwOA01fDpINj742MIIieaDISLWKh72Oh+hgEMxRpObguwFuu9U9B1X/S1R3eFCLltqqS2rwXZ169mJLs8FdvraxeaLH4OxxmFPMFAJrCnU4+l1Mb4P8DAJSUsUrwN/wAqW+/VabPJmnCTxQdqRhCMxQA1LblFOsuMwydoEhXiiPcZvsYHmnSakwID+w1cChLk++yMAydFOQdk5QsaS9Txvb75sy8xiYMw6yhIWuVin2AWK02pdWmAMSqVB4IDv4MQ20GI/rJz5P9+k+obsoq0WVSjLPBWnpUs2lX/iIOar5Q/dmeyg8Mpjqadv5esUGjy3ObrfstbG2uJW1mnkKNi6QWvtfPWaUUS4bmnfcMS8QFYtI7Ys+V2x4x/RlNmWrUu0u/t741eWtsNCmXnZPLzt0XqroG+2DrBNnozwGQQGVyXXVJpfEGQVowJ+IrvhPtQWBc86/F4hZS02puGOI3W4RJn65ghsHtej99cfaBHU6ng5IHOtOnK1pPOz19ay+fajywCWT+5mdeCGFbtBadMCwJAFTj1n1yfkDUmY8njqyIiiDvLnUqq1gHTvrcsL2pnjDdtQBq1BXqHU1x4iE1xjwexRNQRRRBoxiK0iiDIhyKc6l626zE/z5VwX5MexK3IVNbKZfLRqaPriwvKz21OSw8vLH2lpDPGztuXJtWW5q1u0XqI9CdsIm9eAp/APBNGWegRn2SlUkdyJZyNAhl0ZEhjKy3d1Kq+p69C6U4IoaxnKr9dpjPv260HHJgE49qj4fwElhc7VDv6fW24or2awjifk/snmAMAQCoQ2UOGsPEXoBgZ06e6D9wYEN9PY/PDw+PqKquzrpypV+/FIDiHgFKs9msuXmAHvkqirEAAMFYqsRUgFQOofFiSuu4wx6sAsVYpdpLUyM+ymv6PUI6gKCs7YCHcIMmBczL0uxKj3xTzY9m4dzHLxhBENfO270LbSH+51/bi2cUpvTFSDuLdko8JSPT0m4XFMTGxYeGhVVXV4s8RJOnTrt0/nz/gakRBJFvqDZI/3bMx2UM/nC1Dh4iGAAGB73C4XiEi/v5yOKKmv4AAItT5ynwS/aZAgAh3gPvLcx6YCfgn44HOxGM4zhBOABAzvMEAKPDDABS7p/R8xySUWL72PRnjEajSCRCUTQ4OMRVj1zuJRSJ2Gy22k9NEATGwjCCc+7vSyAT4hNLH8xk3n7oxgWH4wEAPrI4ABio7j0mYCGJhNfYQeJx/+0BAPBgIwCgI8wAoBLIAcBut7sjGP76q6KlAQBwq7XymYC+fBZyRuOa66L7q5GxXnYpm92kdZzRYmaK44E6+4usvnzMaqROtTjanJgI48pxyglU9f0zZO5imUZC5Ou4CR0QAACFSDorMuNCPVFT83AZCh5KMfTttkoAiJYGAkDHFyA6EiwUCU0mU6JXOABcbboDAFESvERHWElXSORSG+/vHpyzuvu2TjEAHAAA/kaXQ9t5SqeYbtBBJ4I7hb+IVdBabnLa/YVeCr6kVauVy+UdlO9IcGJiz9ycm6mDBquFXufr8ymG5rHQncMVbXbqEVmKW7dYQF6LD3rEOD4CTIgjZzU5AJCiigOAG9evJfXu3YFLR+/3vsn9rmZmAsBQv8R2wnSl4RYAqIWsNjv9iL9IOKmnlDQmeETB8TIcAI5UZwLAcHVPALiWfbXjG8AdtbDcy0urbQGA0YH9dhSf2l12LtU3QcZD381upx7t5iEhC1imPqkkMps5KW4HQRFIUuD1Zu2lhgIMQdIDkxmGMZlMQqGwA69OxuGAgMCqqsr0wGQhi/tr6R+fDpgbIuZa5wa5zdIFa+vLSOn30fSRZnBfcJwMF7PRr/NPUAw9yCfeRyC/lZ8XG9fJcUQngseOn3Bg/75Fry+ZGJq6s/jUj0Un58SNr9A7p55ocZsoALwm+nmmBBqROLcjIADD/DhOmvzu9mEAmBWVBgBHDh2aM+/Vjh07a+HAQE1tDUVR8+Im7Cw+9WnOr7NjRkdJ2cPUvAqDu3cfHKYpom8dFFbEmuTm8QFALwXbm49tKzymMWvlXI8p4cNsNpvJZOr4FQ1dmVqmpY86dvTI2PETUn3iLjYUbL59ZG58xsaBskYLSbt1v8XpFNAFXB5mDCWWNaCqjgsbLezz1R61JhvvnpGcwxKnBSyxU44Pr+0EgPnxE/kszs6ftk169tlOa+9c8LARIxfNf3X02HEf9J095MDi97K3PRs2VM4T//e2adV1XafuD8X7smnL1N/HMftaGWXHJU1WuGIFALhnMwXGBK0T4dgn13+pMjXJuKIFCZMdDkduzs0XZ73UadX/eDHtXpw8fsxqtWZMmjz+6NuHqzJnRAzfOXKFk2ZyWhyd+j4UgoZPw6zv1gmeI/ymd9dXxFGqPZLK9fU9ds22ksSmga8tSJi8dfMPsbFxfZKTO3Xv0mppZFr64gWvjUxL25Q6/2xdzo8lZ8YEpkwJH9pbyVl7U+/GPOQV+g8Ggf1tVx3mG91ylPNDZiXsJWlq1unVVpLo6RU6Lz6jrbW1tKR49suvdCVClwQjCPLagkWfb1j/znvvb+g/b875ja+cXR8vD4mUBvT15ryT1f6PdzkeBj/isr//BQAIlw1ni7y74QnQ1/dfHEy47Mp3V5rucDF82/DlLBTb8Onaha8v6WKELj3SLnz/3beRUVEDBw2aevz9veUXwsS+V5792ovnyQB0/QsIwlxBFgzE6UYAMKPB1/EELadLi1sOSzQ67GMBLvul5PT0Ux8zAN8MWjQ3fsLhgwftdtuUac91kUA3BNM0/cbihW8uWy6SSwb+9lpea0UfZeSpCRvEbMGxauuM0y1EZ/OvcCjc5LOsgfIyEtxJXiduOcXBbFsBLcrnyDp25LJE02K3+Iji/9DcGH1kOUE5X4ke9f2wpZUVFZu//2712odfr3kouiEYAPR63Yrly9at36hnbAP2vVZlbErxjj42bp2YI7zWTJToHP98UeluhQAMhDe93IO1u1S5EfEIcRAmDk/cgYeQrQgQ9wZAzmlyxh5dbiGJ9IA+h8asthrN7yxbum7jZ3x+N+bk3RMMAJWVFV9t+nzt+o0aq3bI/kW15pZEecjRcWt9BHKagUsNtjL9gzd47oe3ds0I1uoddj8th9dxSbW418TITUK21+HKy8+d/NBKEsP8Eg+P/QQlYenri5etWOHj070N+m4LBoA7twu2bdm8eu2nTYQu/dDSQl2NWijfN+rD3sooi5N+/VLbbxX/eCCG0s5e9JkFqi1D5TfzZStRcUc3vHGMG6eYgCCsTbl73rjyHcXQ44NSdqWtREhm+dI3Xp2/MDQsrLvkuyo48/wBX/+ogOBIV/LO7dubv//uo0/WOFjM1OPvn9bc5GL4+gFz58VPRABIGgCA9bClp9Nht2fJ2JgVAA45Q+u4ng+tTiGIGBmyQiGINDos/zm7flfZOQBYEJ+xYeBrNov1nWVL5y9cHBYeDgAkSZ469EXv1BleXl6PU/D1S7tl7S81sN/tO/wNHMcBoKa6+tM1q5eveM/b12fl1a1rbv5CMXS6f+//Dn1DLVLSDPyhsa3L0bc+MErHOg9OEv3qrWAKcTGFPfivoAnek5JU01EEO1+XM/vM2ipTs4DF/XrwoplRaRpN7ZqPP1q+4l0/PzUAVFcU1mXPRsm6fjM0SNfu9XRVsMloqjqmDvM13NQk+6fs8A8MB4DqqqovN302fsLE1MGDL9TnzT6zptLYJMJ5K/vMnN9jEhvDDQ568x1Tq51io39jwzB0qvKn+4w83DNOkcFliQCg2dq+PPP7HUUnaWB6KyJ2jng7Uhpw8cL5Qwf2L1j0ekBgIMMwWX98qzQv9ZNbcg2vJ4/e0BUV3RAMAFePzEuUfAsANVqRXvoV38PXdGsKov40r8hqMBgWLVlCosz72du+yN/voMkwsc+q5NnPhg3FEJRiIKvRvqXQlN1sd9WGIMwL/sPvRlYJ4xJVU2MV43CUa3JYvsjft+7mLqPTJsS5K/vMXJQwhSapLz7bwGZz4oPbmNYd/oPO1t54u5f3fjaL0ZlQc8it0PCufp7QJcHNzc31NSWakv1pQZtclsY2rKZFmBxlsDuQXO1ERDFv757dM16c1bdfv6L2mrcyvztSlQUAURL/NxKnPh85gouxAaBc7zxYaTlea7vebFsWM0oljAuTDomUp8n5wQDQYtV9W3Dwq1sHWu1GFEGeDx/2Scq//YSK3JycLT/8N33USLFpYy91JoLA0avCMcl/frqWXyVBQ7aLpOEhoSEsFv5IgimK2rfjbX/Obwp+ja/X37ri5QL2gDgHw0BBJR4f4ixu8HH6fZVb0FRdXf3qawt8fH2zGu+surb9ZO0NBhgvrvilqLRZ0elR0kCXO0kzJG12Pb00Q1+oy9tadOy38gt2yokiyLjAlPeTX+ohD21rbf3qy01SqTQxWiQ3vaEUG/kcBgBMVqSqkRUf8v8X5BY7UtkosuLJ3MC3+yR3tDfYSQvr9fo7WZskls9CvA13jXnleKgvKeQxDANz13uO6W9P62u3Eegd0yyfuLd2/fwjh8N9Zc5/pDJZnrZsY+6ePeXnCcqJACTIQyeHDhoX3D9GFkzS5JWGgkOVl/dVXNSYtQDAxfBpYUOX9JwaKwu2WMzbtmxubGiY+tzz7SVrE2S7a5sxsw2pbWZlpNoAoKASD/AmPfh/kqcZyNNEsQM/SkyegKId7Ux26ZFuaWkuyVwZjG+Ri0mdGa2oZ/WKcADAkStcXy/q8i2OB59OSya8pVRhvZoJ+EKq7LFl8/cCPn/GrJd8ff20Nt32whPbi44X/vVFoa9AZnJYjc4/zyOiJP4vRafPikr34nnq9bqfdu6oramZ+dK/HOYKpPbVKJ/6Q5e4UUHkN/sEFI3MzTBHB5Lw11MGAOVNMoP4/d6D57iGj47RjZdWaeF1bd5cFT+vphnzkVEBSmrPOd6NInZTG/ryOOvRy9xxqfaB8YTFjtxunxCcvAHB8J92bNfr9eMmZCT3SwEEclpKfi09+1v5hWpTMwD4C70mhw6aFj6slzISAaSkuHj3rl9I0vn8jBc9xR6ll1+P8dzLwWHfBa6TRAqrWBEBpLeUFvHp/nGO8npWaR0rNZ64rX8+etAGL0UnGwnuCAYAp9N59dQ6c9WaEJVNq8eiApwUhazfJRTwmMIq1svjLCeyuO/NNuEspr6V34QviEl5k8PlHjl0MPtqVkhI6LiMDLXanwHI15ZRDN1TEY4AYjDofz9y5Mb1a2Fh4VOmPcfl8fIufSGzrJGJTD8cFtgIJL2f/U4lfuIqZ2QfYkgS4a+grhayVTK6uEHp3+erxOQJXeffbcEuFORfL7nwSvSAD5srDvaQbKvXYtVN2NkbHMKJyD1pfwXVO9rBwSFIRZY2SE2ieSGJ85Teqory8sOHDtRpNJGRUSPT0j3E4j9On7qWnS0UCkaNHpvUu7fRaCy8tpXdtiHat37fOV5NM0bRSEaq7fhVbmMrOm6gPSXW0WZklZFvCensW+XYqBlblUqf7pJ3RzAAMDSNoCgA3Li8m988z1+uO5fDbjeitU2s4hqWxINeOdu0abdgepo1SEXVtnBbkTEsr6mhMcMkEklJcfGpkyeMRsOwYSN69+1LEERxwWVHy16BdW+4r+FSPvvyLY7Bgqhk9Mx069aj/PED7c06NCXWcbsuiBe1LbrHIJvNhuM4i+XOab6bgu9FY4Om9OKcnt4n9GbkZDY3XE0aLYjZimoN6MVcdnoKMWWIjcViAKC6kWOgIhBeBMJWACCMs52xlXPpO2G+FgyFAxd5PcMdJ65yWw0oAyDiM1IPOrUHoVZSJitaZJ6dMHy9WNzRQvIpCQYAhmGuXdjB1y4NV2kr6llqJfX5bkGoH1Vcy+KxmVfGWRZ87rnqZaPNjnhJaLGQdh22MwBaHeogkXotllnA5nEZnRGdm2HZtEdgsKCDE4mEMKe/ksrXhPLCv4lLGvHoPOFxCXahtVVbdGlFEHurzIO0E0hJLevwFe6ofkRFHXb6OjdcTY4ZYP9yj0CrRwNVFADgLCbYh2KzmSOXuNNG2KoaWMmxDg7O2AlELKQTwpy1Wn4z+42eQ97i8x/bl7yPU7AL5SX5TfkrwsXHPPj0nSr8+FUOGwcMZdoM6PxnLfM3irk4SDzoUD+yrI6llNBFNSyZBx0RQCIINLWiC6eYRXymRY/XOJ4L6v2Brzrw8dJ7/IJdKLqdrStd74MdUsmchBMx25BbFbhESNsdiNmGVDWwKAZ0RlTTjC2aaj6Xw5k6zMZlM1w2U9vC1aJTvWOXBodGPwliT0qwC3WamrrCnUzbr0GSYonoz4MZowWtbsRUcqrNgIb7k641YrsJrdbFIF4vBMa96O3dyfnLo+DJCnaBYZjKirL2uvOM+RpjKwJCA5QRgAHMA9h+CD8aEfaVqYcEh4RCtza43cL/A+p9uOR8npnAAAAAAElFTkSuQmCC",qt=[[/^Triage/i,{id:"triage",code:"TRIAGE",tab:"Triage IGD",option:"Triage \u2014 Pengkajian Awal IGD"}],[/PENGKAJIAN INSTALASI GAWAT DARURAT/i,{id:"pengkajian-igd",code:"PENGKAJIAN IGD",tab:"Pengkajian IGD",option:"Pengkajian IGD \u2014 Lembar Pengkajian Instalasi Gawat Darurat"}],[/^SEP$/i,{id:"rm-01",code:"RM. 01",tab:"RM. 01 SEP/CBG",option:"RM. 01 \u2014 SEP &amp; Berkas Klaim Individual (INA-CBG)"}],[/^Surat (?:Rencana )?Kontrol/i,{id:"surat-kontrol",code:"SURAT KONTROL",tab:"Surat Rencana Kontrol",option:"Surat Rencana Kontrol \u2014 BPJS VClaim"}],[/^SBPK$/i,{id:"rm-02",code:"RM. 02",tab:"RM. 02 SBPK",option:"RM. 02 \u2014 Surat Bukti Pelayanan Kesehatan (SBPK)"}],[/^SPRI$/i,{id:"rm-03",code:"RM. 03",tab:"RM. 03 SPRI",option:"RM. 03 \u2014 Surat Pengantar Rawat Inap (SPRI)"}],[/^Rincian Biaya/i,{id:"rm-05",code:"RM. 05",tab:"RM. 05 Billing",option:"RM. 05 \u2014 Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi"}],[/^Resume/i,{id:"rm-06",code:"RM. 06",tab:"RM. 06 Resume",option:"RM. 06 \u2014 Ringkasan Pulang (Discharge Summary)"}],[/^Telaah/i,{id:"rm-07",code:"RM. 07",tab:"RM. 07 Telaah",option:"RM. 07 \u2014 Formulir Telaah Resep, Obat &amp; Edukasi"}],[/^Radiologi/i,{id:"rm-08",code:"RM. 08",tab:"RM. 08 Radiologi",option:"RM. 08 \u2014 Hasil Pemeriksaan Radiologi"}],[/^Laboratorium/i,{id:"rm-09",code:"RM. 09",tab:"RM. 09 Lab",option:"RM. 09 \u2014 Hasil Pemeriksaan Laboratorium Patologi Klinik"}],[/Konsul/i,{id:"rm-10",code:"RM. 10",tab:"RM. 10 Konsul",option:"RM. 10 \u2014 Lembar Konsultasi Antar-Spesialis"}],[/^Persetujuan Tindakan/i,{id:"form-konsent",code:"RM. 19A",tab:"RM. 19A Persetujuan",option:"RM. 19A \u2014 Persetujuan Tindakan Kedokteran"}],[/^Anestesi/i,{id:"form-anestesi",code:"RM. 21",tab:"RM. 21 Anestesi",option:"RM. 21 \u2014 Laporan Anestesi"}],[/^Fisioterapi/i,{id:"form-fisioterapi",code:"FISIOTERAPI",tab:"Fisioterapi",option:"Fisioterapi \u2014 Assesmen &amp; Terapi"}],[/^Pengkajian Hemodialisa/i,{id:"form-hemodialisa",code:"HEMODIALISA",tab:"Hemodialisa",option:"Hemodialisa \u2014 Pengkajian &amp; Sesi"}],[/^Operasi/i,{id:"form-operasi",code:"RM. 20",tab:"RM. 20 Operasi",option:"RM. 20 \u2014 Laporan Pelaksanaan Operasi"}],[/^Surat Kematian/i,{id:"form-kematian",code:"KEMATIAN",tab:"Surat Kematian",option:"Surat Kematian \u2014 Surat Keterangan"}],[/^Permintaan Terapi/i,{id:"form-terapi",code:"TERAPI",tab:"Permintaan Terapi",option:"Permintaan Terapi \u2014 Rehabilitasi Medik"}],[/^Uji Fungsi/i,{id:"form-uji-fungsi",code:"UJI FUNGSI",tab:"Uji Fungsi",option:"Uji Fungsi \u2014 Lembar Uji Fungsi"}],[/^Partograf/i,{id:"form-partograf",code:"PARTOGRAF",tab:"Partograf",option:"Partograf \u2014 Pemantauan Persalinan"}],[/^Laporan Tindakan/i,{id:"form-laporan-tindakan",code:"LAPORAN TINDAKAN",tab:"Laporan Tindakan",option:"Laporan Tindakan \u2014 Pelaksanaan Tindakan"}],[/^Bon Makan/i,{id:"form-bon-makan",code:"BON MAKAN",tab:"Bon Makan",option:"Bon Makan \u2014 Pasien / Pendamping"}],[/^PEMERIKSAAN$/i,{id:"form-pemeriksaan",code:"PEMERIKSAAN",tab:"Pemeriksaan",option:"Pemeriksaan \u2014 Hasil Diagnostik"}]],Xt=(i,u)=>qt.find(([a])=>a.test(i))?.[1]??{id:`doc-${u+1}`,code:"FORMULIR RM KLAIM JKN",tab:`RM. ${String(u+1).padStart(2,"0")} ${i}`,option:`RM. ${String(u+1).padStart(2,"0")} \u2014 ${i}`},J=i=>`<div class="rm-code-top">${i}</div>
<div class="kop-surat"><img class="kop-logo" src="${_t}" alt="Logo Kota Jambi"><div class="kop-text">
<div class="kop-line-1">PEMERINTAH KOTA JAMBI</div>
<div class="kop-line-2">DINAS KESEHATAN</div>
<div class="kop-line-3">RUMAH SAKIT UMUM DAERAH H. ABDUL MANAP</div>
<div class="kop-line-4">Alamat : Jl. Sk. Rd. Syahbuddin Kel. Mayang Mangurai Kec. Alam Barajo Kota Jambi 36129 &#9742; (0741) 670459</div>
<div class="kop-line-5">email : rsud_ham.jambi@yahoo.co.id, rsud@jambikota.go.id, website : rsud.jambikota.go.id</div>
</div></div><div class="kop-double-rule"></div>`,r=(i,u,a=!1)=>`<tr><td class="lbl">${i}</td><td class="col">:</td><td class="val">${a?`<strong>${F(u)}</strong>`:F(u)}</td></tr>`,It="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDEuNjMgMzEuMDIiPgogIDxkZWZzPgogICAgPHN0eWxlPgogICAgICAuY2xzLTEsIC5jbHMtMiB7CiAgICAgICAgZmlsbDogIzAwYTU1MTsKICAgICAgfQoKICAgICAgLmNscy0zLCAuY2xzLTQgewogICAgICAgIGZpbGw6ICMwMjNmODc7CiAgICAgIH0KCiAgICAgIC5jbHMtNSB7CiAgICAgICAgZmlsbDogI2ZmZjsKICAgICAgfQoKICAgICAgLmNscy01LCAuY2xzLTQsIC5jbHMtMiB7CiAgICAgICAgZmlsbC1ydWxlOiBldmVub2RkOwogICAgICB9CiAgICA8L3N0eWxlPgogIDwvZGVmcz4KICA8ZyBpZD0iTGF5ZXJfMS0yIiBkYXRhLW5hbWU9IkxheWVyIDEiPgogICAgPGc+CiAgICAgIDxnPgogICAgICAgIDxnPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTAyLjkxLDE1LjFjLS44Mi0yLjQtMS42NS00LjgtMi40Ny03LjJsLTEuODYsMi4zMnY0Ljg5YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjksMC0xMS4zNywwLTE3LjA2aC42NGMuMzEsMCwuNTcsMCwuODcuMDUsMS4wMi4xOSwxLjQ5LjksMS40OSwxLjl2NS4zMmw1LjMxLTYuMzlDMTA0LjY0LDAsMTA1LjA3LDAsMTA2LjI5LDBoLjQxYy0xLjQsMS44LTIuOCwzLjU5LTQuMiw1LjM5LDEuNDMsMy44OSwyLjg3LDcuNzgsNC4zLDExLjY3aC0uNDdjLS42OSwwLTEuMzUuMDMtMS45OC0uMjYtLjQzLS4yLS43OC0uNS0xLjA0LS44OC0uMTgtLjI2LS4yOS0uNTMtLjM5LS44MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTExNy45NCwxNC44NmMtLjc1LDEuNjItMi41MywyLjIzLTQuNDMsMi4yMy0yLjk0LDAtNC41NS0xLjYxLTUuMjctMy43Mi0uNS0xLjQ2LS42Ni0zLjI4LS4zOS00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjcxLTMuMTUtMy45OC0yLjgyLTQuNzQtLjAyLS4xNS41NS0uMjQsMS4yNC0uMjYsMi4wNWg1LjI3WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTIyLjkxLDE1LjAzYy41My4zNSwxLjE3LjUzLDEuOTEuNTNzMS4zNS0uMTgsMS43My0uNTVjLjM4LS4zNi41Ny0uODMuNTctMS40LDAtLjQtLjA2LS43My0uMTktMS0uMTMtLjI3LS4yOS0uNS0uNS0uNjktLjItLjE5LS40NC0uMzUtLjctLjQ3LS4yNy0uMTItLjUzLS4yNC0uODEtLjM0LS42MS0uMjItMS4xNy0uNDYtMS42OC0uNzEtLjUxLS4yNi0uOTUtLjU1LTEuMzItLjg3LS4zNy0uMzItLjY2LS42OS0uODctMS4xMS0uMjEtLjQyLS4zMS0uOS0uMzEtMS40NiwwLS42Ni4xMi0xLjI0LjM1LTEuNzMuMjMtLjUuNTYtLjkxLjk4LTEuMjQuNDItLjMzLjkxLS41OCwxLjQ5LS43NS41Ny0uMTcsMS4yLS4yNSwxLjg3LS4yNS44MiwwLDEuNTkuMTMsMi4zMS40MS43Mi4yNywxLjI0Ljc3LDEuNTgsMS41LS45Ny42OC0xLjYuMTktMi4yMS0uMDMtLjExLS4wNi0uMjMtLjExLS4zNS0uMTYtLjM0LS4xMi0uNzEtLjE4LTEuMTEtLjE4LS4zMiwwLS42My4wNC0uOTMuMTEtLjMuMDctLjU2LjE5LS43OS4zNC0uMjMuMTUtLjQuMzUtLjUzLjU4LS4xMy4yMy0uMTkuNTItLjE5Ljg1LDAsLjU1LjE3Ljk5LjUxLDEuMjkuMzQuMzEuNzYuNTYsMS4yNy43Ny41MS4yLDEuMDYuNCwxLjY0LjU4LjU5LjE4LDEuMTQuNDMsMS42NC43My41MS4zMS45My43MSwxLjI3LDEuMjEuMzQuNS41MSwxLjE3LjUxLDIuMDIsMCwuNjQtLjEzLDEuMjItLjM3LDEuNzMtLjI1LjUxLS41OS45NC0xLjAzLDEuMjktLjQzLjM1LS45NS42Mi0xLjU2LjgxLS42LjE5LTEuMjUuMjgtMS45NC4yOC0xLjE2LDAtMi4xNS0uMjEtMi45Ny0uNjQtLjgyLS40Mi0xLjQzLTEuMDctMS44MS0xLjk1LjMyLS4yLjgzLS41LDEuNDktLjI2LjQ0LjE2LjcuNDksMS4wNy43NFoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE1Mi43MSw2LjcyYzAtLjctLjE2LTEuMTctLjUtMS40My0uMzMtLjI1LS44NS0uMzgtMS41Ni0uMzgtLjU4LDAtMS4xMi4xMy0xLjYyLjM4LS41LjI1LS44Ni41My0xLjA5Ljg1djkuMDZjMCwuOTUtLjQ1LDEuNjItMS40MiwxLjgxLS4yOS4wNS0uNTMuMDUtLjgzLjA1aC0uNjFWMGguNjFjLjMsMCwuNTQsMCwuODMuMDUuOTcuMTgsMS40Mi44NSwxLjQyLDEuODF2MS4yNmgwdjEuNThjLjM3LS40NS45Mi0uODQsMS42NC0xLjE4LjczLS4zNCwxLjU3LS41MSwyLjU0LS41MSwxLjE2LDAsMi4wMi4yOSwyLjU5Ljg2LjU2LjU3Ljg1LDEuNDYuODUsMi42NnYxMC41NGgtLjYxYy0uMywwLS41NCwwLS44My0uMDUtLjk3LS4xOC0xLjQyLS44NS0xLjQyLTEuODFWNi43MloiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE2NC44Nyw5LjI5Yy0uMzIuMTYtLjcuMjktMS4xNC4zOC0uNDMuMDktLjg1LjItMS4yNi4zMi0uODEuMjMtMS4zOC41OS0xLjc0LDEuMDctLjM1LjQ4LS41MywxLjExLS41MywxLjg4LDAsLjg3LjE3LDEuNTEuNTIsMS45MS4zNS40Ljg5LjYsMS42My42LjU2LDAsMS4wNi0uMTMsMS41LS4zOS40My0uMjYuNzctLjYzLDEuMDEtMS4wOXYtNC42N2gwWm0uMjIsNS44N2MtLjMyLjYtLjgxLDEuMDYtMS40NSwxLjQxLS42NC4zNC0xLjQuNTEtMi4yNy41MS0xLjMyLDAtMi4zMS0uMzMtMi45Ni0uOTktLjY1LS42Ni0uOTgtMS41OC0uOTgtMi43NnMuMjYtMi4wOC43Ny0yLjcxYy41MS0uNjMsMS4zMS0xLjExLDIuMzktMS40NC4zNS0uMTIuNzMtLjIxLDEuMTItLjI3LjM5LS4wNy43OC0uMTMsMS4xNi0uMi4zOC0uMDYuNzQtLjE0LDEuMDktLjI0Ljc5LS4yMi44Ny0uNDIuODgtLjk4LDAtLjI2LDAtLjUyLDAtLjc3LDAtLjcxLS4xNi0xLjI1LS40OC0xLjYxLS4zMi0uMzYtLjkzLS41NS0xLjg0LS41NS0uNjgsMC0xLjI2LjEzLTEuNzUuNC0uOTUuNTItMS4zNy45NC0yLjYuMzQuNDctLjgxLDEuMTEtMS40LDEuOTItMS43Ni44MS0uMzYsMS42OS0uNTMsMi42NC0uNTMuNjgsMCwxLjMyLjA1LDEuOTIuMTQuNi4wOSwxLjEzLjI4LDEuNTcuNTQuNDQuMjcuNzkuNjUsMS4wNSwxLjEzLjI2LjQ5LjM5LDEuMTIuMzksMS45MXYxMC4zM2MtLjA3LDAtLjQ1LDAtLjc3LDAtMS4zNiwwLTEuNzgtLjcyLTEuODEtMS45MVoiLz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMSIgZD0ibTE3Ny43OSwxNi4xNmMtLjQ1LjMzLS45MS41Ni0xLjM5LjctLjQ4LjE0LTEuMS4yMS0xLjg3LjIxLTEuMjIsMC0yLjE4LS4zNS0yLjg3LTEuMDQtLjY5LS42OS0xLjA0LTEuNjUtMS4wNC0yLjg4VjQuMzloLS40NmMtLjc5LS4wMi0xLjIxLS4xNS0xLjIxLTEuMzhoMS42N1YwaC42MWMuMywwLC41NCwwLC44My4wNS45Ny4xOCwxLjQyLjg1LDEuNDIsMS44MXYxLjE1aDEuNjdjLjc5LjAyLDEuMjEuMTUsMS4yMSwxLjM4aC0yLjl2OC43N2MwLC43Ni4xNywxLjM1LjUsMS43Ny4zMy40Mi44Ni42NCwxLjU4LjY0LjI2LDAsLjUtLjAyLjctLjA1Ljg0LS4xMywxLjI1LS4wMSwxLjU3LjY1WiIvPgogICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJtMTk4Ljc4LDYuNzJjMC0uNy0uMTctMS4xNy0uNS0xLjQzLS4zMy0uMjUtLjg1LS4zOC0xLjU2LS4zOC0uNTgsMC0xLjEyLjEzLTEuNjIuMzgtLjUuMjUtLjg2LjUzLTEuMDkuODV2OS4wNmMwLC45NS0uNDUsMS42Mi0xLjQyLDEuODEtLjI5LjA1LS41My4wNS0uODMuMDVoLS42MVYzaC42MWMuMywwLC41NCwwLC44My4wNS45MS4xNywxLjM2Ljc4LDEuNDEsMS42NGgwYy4zNy0uNDUuOTItLjg0LDEuNjQtMS4xOC43Mi0uMzQsMS41Ny0uNTEsMi41NC0uNTEsMS4xNiwwLDIuMDIuMjksMi41OS44Ni41Ni41Ny44NSwxLjQ2Ljg1LDIuNjZ2MTAuNTRoLS42MWMtLjMsMC0uNTQsMC0uODMtLjA1LS45Ny0uMTgtMS40Mi0uODUtMS40Mi0xLjgxVjYuNzJaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xNDIuMTEsMTQuODZjLS43NSwxLjYyLTIuNTMsMi4yMy00LjQzLDIuMjMtMi45NCwwLTQuNTUtMS42MS01LjI3LTMuNzItLjUtMS40Ni0uNjYtMy4yOC0uNC00Ljk5LjQxLTIuNjEsMi01LjM4LDUuMjktNS4zOCw0Ljc2LDAsNS4zLDMuNjgsNS40Niw2Ljk5aC03Ljk3Yy0uMDksMS45OC4zMiw1LjYxLDMuMjksNS42MS43OSwwLDEuMzktLjE0LDEuNzktLjQyLjcyLS40MiwxLjMxLS43OSwyLjIzLS4zM2gwWm0tMi4wNi02LjA5Yy0uMDYtLjgtLjE1LTEuNDgtLjI3LTIuMDMtLjctMy4xNS0zLjk4LTIuODItNC43NC0uMDItLjE1LjU1LS4yNCwxLjI0LS4yNiwyLjA1aDUuMjdaIi8+CiAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Im0xODYuMjYsOS4yOWMtLjMyLjE2LS43LjI5LTEuMTQuMzgtLjQzLjA5LS44NS4yLTEuMjYuMzItLjgxLjIzLTEuMzkuNTktMS43NCwxLjA3LS4zNS40OC0uNTMsMS4xMS0uNTMsMS44OCwwLC44Ny4xNywxLjUxLjUyLDEuOTEuMzUuNC44OS42LDEuNjMuNi41NiwwLDEuMDYtLjEzLDEuNS0uMzkuNDQtLjI2Ljc3LS42MywxLjAyLTEuMDl2LTQuNjdoMFptLjIyLDUuODdjLS4zMi42LS44MSwxLjA2LTEuNDUsMS40MS0uNjQuMzQtMS40LjUxLTIuMjcuNTEtMS4zMiwwLTIuMzEtLjMzLTIuOTYtLjk5LS42NS0uNjYtLjk4LTEuNTgtLjk4LTIuNzZzLjI2LTIuMDguNzctMi43MWMuNTItLjYzLDEuMzEtMS4xMSwyLjM5LTEuNDQuMzUtLjEyLjczLS4yMSwxLjEyLS4yNy4zOS0uMDcuNzgtLjEzLDEuMTYtLjIuMzgtLjA2Ljc0LS4xNCwxLjA5LS4yNC43OS0uMjIuODctLjQyLjg4LS45OCwwLS4yNiwwLS41MiwwLS43NywwLS43MS0uMTYtMS4yNS0uNDgtMS42MS0uMzItLjM2LS45My0uNTUtMS44NC0uNTUtLjY4LDAtMS4yNi4xMy0xLjc1LjQtLjk1LjUyLTEuMzcuOTQtMi42LjM0LjQ3LS44MSwxLjExLTEuNCwxLjkyLTEuNzYuODEtLjM2LDEuNjktLjUzLDIuNjQtLjUzLjY4LDAsMS4zMi4wNSwxLjkyLjE0LjYuMDksMS4xMy4yOCwxLjU3LjU0LjQ0LjI3Ljc5LjY1LDEuMDUsMS4xMy4yNi40OS4zOSwxLjEyLjM5LDEuOTF2MTAuMzNjLS4wNywwLS40NSwwLS43NywwLTEuMzYsMC0xLjc4LS43Mi0xLjgxLTEuOTFaIi8+CiAgICAgICAgPC9nPgogICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTUxLjczLDcuNzJjMS44OC0uMDYsMi40MS0xLjcsMi40MS0zLjA3LDAtMS40NC0uMTUtMy4wNy0yLjEtMy4wN2gtMi41MXY2LjE0aDIuMlptLS4wMyw3LjljLjkzLDAsMS42Mi0uMjYsMi4wNi0uNzguNDQtLjUyLjY2LTEuMzYuNjYtMi41MiwwLTEuNDctLjItMi45Ny0yLjIyLTMuMjdoLTIuNjh2Ni41N2gyLjE3Wm0tNS4xNywxLjQ3Vi4wNGg1Ljg2YzMuMzEsMCw0Ljc5LDIuMTIsNC40OSw0LjktLjE0LDEuMjgtLjYyLDIuNi0xLjkxLDMuMjksMy4xNi45NiwzLjE2LDUuNTgsMS4zLDcuNTgtLjguODUtMi4wNywxLjI4LTMuODMsMS4yOGgtNS45MVoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im02MC42Ni4wNGg1Ljc5Yy44NywwLDEuNjEuMDksMi4yMi4yNy42MS4xOCwxLjEuNDQsMS40Ny44LjM3LjM2LjY0LjgxLjgxLDEuMzUuMTcuNTQuMjUsMS4xOC4yNSwxLjksMCwxLjE2LS4wOSwyLjEzLS4yNywyLjktLjE4Ljc4LS40NywxLjQxLS44OSwxLjg4LS40Mi40Ny0uOTcuODItMS42NSwxLjAyLS42OC4yMS0xLjUzLjMxLTIuNTUuMzFoLTIuMnY0LjY2YzAsMS4xOS0uNjcsMS45Ni0yLjEyLDEuOTVoLS44N2MwLTUuNjgsMC0xMS4zNywwLTE3LjA1aDBabTQuODgsOC45M2MuNDgsMCwuODktLjA2LDEuMjItLjE5LjMzLS4xMy42LS4zNC44Mi0uNjMuMjItLjMuMzctLjY5LjQ3LTEuMTguMS0uNDkuMTQtMS4xLjE0LTEuODNzLS4wNC0xLjMtLjEyLTEuNzZjLS4wOC0uNDYtLjIxLS44Mi0uMzctMS4wOS0uMTctLjI3LS4zOS0uNDUtLjY2LS41Ni0uMjctLjEtLjYxLS4xNi0xLjAxLS4xNmgtMi4zN3Y3LjM5aDEuODhaIi8+CiAgICAgICAgPHBhdGggY2xhc3M9ImNscy0zIiBkPSJtNzQuNC4wNGguNjNjLjMxLDAsLjU2LDAsLjg2LjA1LDEuMDEuMTksMS40OC44OSwxLjQ4LDEuODh2MTAuODhjMCwyLjgzLTEuNjcsNC4yNS01LjAyLDQuMjUtLjE2LDAtLjMxLDAtLjQ2LDAtMS4wOS0uMDItMi4wNi0uMjctMi44OS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxLjMuMi42NC4zNSwxLjAyLjQ0LjgxLjIsMS45Ni4yMSwyLjc0LS4yMi43OS0uNDQuODYtMS4yNy44Ni0yLjA1Vi4wNFoiLz4KICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Im04Mi41OSwxNC44NGMuNTUuMzcsMS4yMy41NiwyLjA1LjU2LjM5LDAsLjc2LS4wNiwxLjExLS4xOC4zNS0uMTIuNjYtLjI5LjkzLS41Mi4yNy0uMjIuNDgtLjQ5LjYzLS44Mi4xNS0uMzIuMjMtLjY4LjIzLTEuMDksMC0uMzYtLjA2LS42Ny0uMTctLjk1LS4xMS0uMjctLjI3LS41Mi0uNDYtLjczLS4xOS0uMjItLjQyLS40MS0uNjktLjU5LS4yNy0uMTgtLjU1LS4zNi0uODYtLjU1LS42OS0uNC0xLjMzLS43OS0xLjkyLTEuMTctLjU5LS4zOC0xLjEtLjc5LTEuNTMtMS4yMi0uNDMtLjQzLS43OC0uOTEtMS4wMy0xLjQzLS4yNS0uNTItLjM3LTEuMTQtLjM3LTEuODYsMC0uNjIuMTEtMS4xOC4zMy0xLjcuMjItLjUyLjU0LS45Ni45Ny0xLjM0LjQzLS4zOC45NS0uNjgsMS41Ni0uODkuNjEtLjIyLDEuMzEtLjMyLDIuMS0uMzIsMS4wMywwLDEuOTIuMjEsMi42Ni42My43NC40MiwxLjI0LDEuMDIsMS41LDEuNzgtLjg2LjM3LTEuNDkuMTctMi4xOS0uMzUtLjQ0LS4yOS0uOTctLjQ0LTEuNTgtLjQ0LS44NSwwLTEuNTIuMjEtMS45OS42Mi0uNDcuNDItLjcxLDEtLjcxLDEuNzYsMCwuNjMuMTgsMS4xNS41NCwxLjU3LjM2LjQyLjgxLjc5LDEuMzUsMS4xMy41NC4zNCwxLjEzLjY2LDEuNzYuOTcuNjQuMzEsMS4yMi42NywxLjc2LDEuMDguNTQuNDEuOTkuOSwxLjM1LDEuNDcuMzYuNTcuNTQsMS4yOS41NCwyLjE1LDAsLjY3LS4xMywxLjMtLjM5LDEuODctLjI2LjU3LS42MywxLjA3LTEuMTEsMS40OC0uNDguNDItMS4wNy43NC0xLjc3Ljk4LS43LjI0LTEuNDkuMzYtMi4zOC4zNi0xLjE0LDAtMi4xNC0uMjUtMy4wMS0uNzUtLjg2LS41LTEuNDktMS4yMi0xLjg5LTIuMTUuNy0uMjgsMS4zLS40MywxLjkzLjA0LjI2LjE5LjQ3LjQyLjc1LjYxWiIvPgogICAgICA8L2c+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0ibTExMy4wOCwyOS4xM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNy0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOVptLTUuNTYsMi4zOHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjE4LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjUtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTQuNy0yLjk1aC0xLjAxbC0xLjE2LDQuMTMtMS4xOC00LjEzaC0xLjA1bDEuNyw1LjMxLS4wOC4zNmMtLjAyLjExLS4wNS4yLS4xLjI5LS4wNS4wOS0uMTEuMTYtLjE4LjIxLS4wOC4wNS0uMTcuMDgtLjI5LjA4LS4xNCwwLS4yNi0uMDItLjM3LS4wNS0uMTEtLjAzLS4xOS0uMDYtLjI1LS4wOS0uMDYtLjAzLS4wOS0uMDUtLjA5LS4wNWwuMTEuODZzLjA0LjAyLjExLjA1Yy4wNy4wMy4xNy4wNi4zLjA5LjEzLjAzLjI4LjA0LjQ2LjA0LjIyLDAsLjQtLjA0LjU1LS4xMi4xNS0uMDguMjctLjE5LjM3LS4zMi4xLS4xNC4xOC0uMy4yNS0uNDguMDctLjE4LjEzLS4zOC4yLS41OWwxLjcyLTUuNThoMFptLTUuMDgsNS4zM3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjEyLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS02LjE5LTMuMDloLTIuMjVzMC0uMDUsMC0uMTNjMC0uMDguMDEtLjE4LjAzLS4zLjAyLS4xMi4wNS0uMjUuMS0uMzguMDUtLjEzLjExLS4yNi4yLS4zNy4wOS0uMTIuMi0uMjEuMzQtLjI4LjE0LS4wNy4zMS0uMS41MS0uMDkuMTgsMCwuMzQuMDUuNDYuMTIuMTMuMDcuMjMuMTcuMzEuMjkuMDguMTIuMTQuMjQuMTguMzcuMDQuMTMuMDcuMjUuMDkuMzcuMDIuMTIuMDMuMjEuMDMuMjksMCwuMDgsMCwuMTIsMCwuMTNoMFptMS4wMy43MXYtLjNjMC0uMTQsMC0uMy0uMDItLjQ5LS4wMS0uMTktLjA1LS4zOS0uMDktLjYtLjA1LS4yMS0uMTItLjQxLS4yMS0uNjEtLjA5LS4yLS4yMi0uMzgtLjM3LS41NC0uMTUtLjE2LS4zNS0uMjktLjU4LS4zOS0uMjMtLjEtLjUxLS4xNC0uODMtLjE0LS4zMywwLS42Mi4wNS0uODYuMTQtLjI0LjA5LS40NS4yMi0uNjIuMzgtLjE3LjE2LS4zMS4zNC0uNDEuNTQtLjExLjItLjE5LjQtLjI1LjYyLS4wNi4yMS0uMS40Mi0uMTIuNjEtLjAyLjItLjAzLjM4LS4wMy41MywwLC4xNSwwLC4zMi4wMy41MS4wMi4xOS4wNi4zOC4xMi41OC4wNi4yLjE1LjQuMjYuNTkuMTIuMTkuMjcuMzYuNDYuNTIuMTkuMTUuNDIuMjguNy4zNi4yOC4wOS42MS4xNC45OS4xNC4yNSwwLC40Ny0uMDIuNjYtLjA2LjE5LS4wNC4zNS0uMDguNDgtLjEzLjEzLS4wNS4yMy0uMDkuMy0uMTMuMDctLjA0LjExLS4wNy4xMy0uMDhsLjE1LS45NHMtLjA2LjA0LS4xMi4wOWMtLjA3LjA1LS4xNi4xLS4yOS4xNi0uMTIuMDYtLjI4LjExLS40Ny4xNS0uMTkuMDQtLjQxLjA2LS42Ni4wNS0uMywwLS41NS0uMDUtLjc1LS4xMy0uMi0uMDgtLjM2LS4xOC0uNDgtLjMtLjEyLS4xMi0uMjEtLjI1LS4yNi0uMzgtLjA2LS4xMy0uMS0uMjYtLjExLS4zNy0uMDItLjExLS4wMy0uMi0uMDItLjI2di0uMTNoMy4yOFptLTYuMzEtMi4zNWMwLC4yMy0uMDIuNDMtLjA3LjYtLjA1LjE2LS4xMi4zLS4yMi40Mi0uMDguMTEtLjE4LjE5LS4yNy4yNS0uMS4wNi0uMTkuMTEtLjI5LjEzLS4wOS4wMy0uMTguMDUtLjI1LjA1LS4wNywwLS4xMi4wMS0uMTUuMDFoLTEuMDl2LTIuOTZoMS4wOWMuMDgsMCwuMTcsMCwuMjcuMDIuMTEuMDIuMjIuMDUuMzMuMS4xMS4wNS4yMi4xMy4zMi4yNC4xLjExLjE4LjI2LjI0LjQ0LjA2LjE4LjA5LjQyLjA5LjdoMFptMS4yNCwwYzAtLjM5LS4wNS0uNzMtLjE0LTEuMDEtLjA5LS4yOC0uMjItLjUyLS4zOC0uNzEtLjE2LS4xOS0uMzUtLjM0LS41Ni0uNDUtLjIxLS4xMS0uNDUtLjE5LS42OS0uMjQtLjI1LS4wNS0uNS0uMDctLjc3LS4wN2gtMi4yM3Y3LjJoMS4ydi0yLjI5aDEuMDdjLjIxLDAsLjQyLS4wMS42NC0uMDQuMjEtLjAzLjQyLS4wOS42My0uMTguMjEtLjA5LjQxLS4yMy42LS40Mi4yLS4xOC4zNS0uNDMuNDYtLjczLjExLS4zLjE3LS42Ni4xNy0xLjA2aDBabTU1LjU0LDMuMTRjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xMy4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOS0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOC45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM4LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS00LjE3LTQuMjRsLS4xNS0uOTdjLS4wNS0uMDMtLjA5LS4wNi0uMTMtLjA4LS4wNC0uMDItLjA3LS4wNC0uMS0uMDUtLjAzLS4wMS0uMDctLjAzLS4xMi0uMDQtLjA2LS4wMS0uMTEtLjAyLS4xNS0uMDMtLjA0LDAtLjA5LDAtLjE0LDAtLjA5LDAtLjE3LDAtLjI1LjAxLS4wOC4wMS0uMTYuMDMtLjI0LjA3LS4wOC4wMy0uMTUuMDgtLjIyLjE1LS4wOC4wOC0uMTUuMTUtLjIuMjMtLjA1LjA4LS4wOS4xNS0uMTIuMjEtLjAzLjA2LS4wNS4xMS0uMDYuMTR2LS43MmgtMS4wNHY1LjMzaDEuMDR2LTMuMDNjMC0uMDksMC0uMTksMC0uMzEsMC0uMTEuMDItLjIzLjA0LS4zNS4wMy0uMTIuMDctLjI0LjEyLS4zNi4wNi0uMS4xMi0uMTguMjEtLjI2LjA4LS4wOC4xOC0uMTQuMjktLjE4LjExLS4wNC4yNC0uMDcuMzgtLjA3LjE3LDAsLjMzLjAzLjQ2LjA5LjEzLjA2LjI2LjEzLjM3LjIzaDBabS01LjE1LDIuNjVjMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDctLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMi0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzEtLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDcuMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzgtLjQxdi4zMWMwLC4wNSwwLC4xLjAxLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjgzLjQ1YzAsLjEyLS4wMy4yMy0uMS4zMi0uMDcuMDktLjE2LjE2LS4yNy4yMi0uMTEuMDYtLjI0LjEtLjM3LjEzLS4xMy4wMy0uMjcuMDQtLjQuMDQtLjI2LDAtLjQ4LS4wMy0uNjctLjA5LS4xOS0uMDYtLjMzLS4xNS0uNDQtLjI1LS4xLS4xMS0uMTUtLjI0LS4xNS0uMzksMC0uMS4wMi0uMTkuMDUtLjI4LjAzLS4wOC4wNy0uMTUuMTItLjIxLjA1LS4wNi4wOS0uMS4xMi0uMTMuMDQtLjAzLjA1LS4wNS4wNi0uMDVoLjkxYy4yMywwLC40Mi4wMy41Ny4wNy4xNS4wNC4yNi4wOS4zNS4xNi4wOC4wNy4xNC4xNC4xOC4yMi4wMy4wOC4wNS4xNi4wNS4yNWgwWm0tLjEzLTQuMDNjMCwuMjQtLjA0LjQ0LS4xMi42MS0uMDguMTctLjIuMy0uMzYuMzktLjE2LjA5LS4zNi4xNC0uNi4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMTksMCwuMzYuMDQuNDkuMS4xMy4wNi4yNC4xNS4zMi4yNS4wOC4xLjE0LjIyLjE3LjM1LjA0LjEzLjA1LjI2LjA1LjM5aDBabTEuMTcsMy45OGMwLS41LS4xNy0uODYtLjUzLTEuMS0uMzYtLjI0LS44OS0uMzYtMS41OS0uMzUtLjA4LDAtLjE3LDAtLjI4LDAtLjExLDAtLjIyLDAtLjM0LDAtLjEyLDAtLjIyLS4wMi0uMzItLjA0LS4xLS4wMi0uMTgtLjA1LS4yNC0uMS0uMDYtLjA1LS4wOS0uMTEtLjEtLjE5LDAtLjA5LjAzLS4xNi4xLS4yMS4wNi0uMDUuMTUtLjA4LjI2LS4xLjExLS4wMi4yNC0uMDMuMzgtLjAzLjE0LDAsLjI5LDAsLjQ2LDAsLjQ0LDAsLjgyLS4wOCwxLjEzLS4yMy4zMS0uMTUuNTQtLjM2LjcxLS42NS4xNi0uMjguMjQtLjYyLjI0LTEuMDF2LTEuNzNoLS41M3MtLjA5LDAtLjEzLDBjLS4wNSwwLS4wOS4wMS0uMTQuMDMtLjA1LjAyLS4wOS4wNi0uMTMuMTEtLjA0LjA1LS4wNi4xMS0uMDcuMTcsMCwuMDYtLjAxLjExLDAsLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjM5LS4xNi0uMTYtLjA0LS4zNC0uMDYtLjU1LS4wNi0uMTQsMC0uMjguMDEtLjQzLjA1LS4xNS4wMy0uMy4wOS0uNDUuMTctLjE1LjA4LS4yOC4xOS0uNC4zMy0uMTIuMTQtLjIxLjMxLS4yOC41Mi0uMDcuMjEtLjEuNDYtLjEuNzYsMCwuMi4wMy4zOC4wOC41NC4wNS4xNi4xMi4yOS4xOS40LjA4LjExLjE1LjIuMjMuMjcuMDguMDcuMTQuMTMuMTkuMTYuMDUuMDMuMDguMDUuMDguMDUsMCwwLS4wNCwwLS4xLjAxLS4wNy4wMS0uMTUuMDMtLjI0LjA3LS4xLjAzLS4xOS4wOC0uMjkuMTUtLjEuMDctLjE4LjE2LS4yNC4yNy0uMDYuMTEtLjEuMjYtLjEuNDMsMCwuMTMsMCwuMjQuMDQuMzMuMDMuMDkuMDguMTcuMTQuMjMuMDYuMDYuMTIuMTEuMTkuMTQuMDcuMDQuMTMuMDYuMi4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA5LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjguMTcuMi40Mi4zNS43NC40Ny4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTYuMjUuMDVjMCwuMTItLjAzLjIzLS4xLjMyLS4wNy4wOS0uMTYuMTYtLjI3LjIyLS4xMS4wNi0uMjQuMS0uMzcuMTMtLjE0LjAzLS4yNy4wNC0uNC4wNC0uMjYsMC0uNDgtLjAzLS42Ny0uMDktLjE5LS4wNi0uMzMtLjE1LS40NC0uMjUtLjEtLjExLS4xNS0uMjQtLjE1LS4zOSwwLS4xLjAyLS4xOS4wNi0uMjguMDMtLjA4LjA3LS4xNS4xMi0uMjEuMDUtLjA2LjA5LS4xLjEyLS4xMy4wNC0uMDMuMDUtLjA1LjA1LS4wNWguOTFjLjIzLDAsLjQyLjAzLjU3LjA3LjE1LjA0LjI2LjA5LjM1LjE2LjA4LjA3LjE0LjE0LjE4LjIyLjAzLjA4LjA1LjE2LjA1LjI1aDBabS0uMTMtNC4wM2MwLC4yNC0uMDQuNDQtLjEyLjYxLS4wOC4xNy0uMi4zLS4zNi4zOS0uMTYuMDktLjM2LjE0LS41OS4xNC0uMiwwLS4zNy0uMDUtLjUyLS4xNS0uMTQtLjEtLjI1LS4yMy0uMzItLjQtLjA3LS4xNy0uMTEtLjM3LS4xMS0uNTlzLjA0LS40NC4xMS0uNmMuMDctLjE2LjE4LS4yOS4zMy0uMzcuMTUtLjA4LjMzLS4xMy41Ni0uMTIuMiwwLC4zNi4wNC40OS4xLjEzLjA2LjI0LjE1LjMyLjI1LjA4LjEuMTQuMjIuMTcuMzUuMDQuMTMuMDUuMjYuMDUuMzloMFptMS4xNywzLjk4YzAtLjUtLjE3LS44Ni0uNTMtMS4xLS4zNi0uMjQtLjg5LS4zNi0xLjU5LS4zNS0uMDgsMC0uMTcsMC0uMjgsMC0uMTEsMC0uMjIsMC0uMzQsMC0uMTIsMC0uMjItLjAyLS4zMi0uMDQtLjEtLjAyLS4xOC0uMDUtLjI0LS4xLS4wNi0uMDUtLjA5LS4xMS0uMS0uMTksMC0uMDkuMDMtLjE2LjEtLjIxLjA2LS4wNS4xNS0uMDguMjYtLjEuMTEtLjAyLjI0LS4wMy4zOC0uMDMuMTQsMCwuMjksMCwuNDYsMCwuNDQsMCwuODItLjA4LDEuMTMtLjIzLjMxLS4xNS41NC0uMzYuNzEtLjY1LjE2LS4yOC4yNC0uNjIuMjQtMS4wMXYtMS43M2gtLjUzcy0uMDksMC0uMTMsMGMtLjA1LDAtLjA5LjAxLS4xNC4wMy0uMDUuMDItLjA5LjA2LS4xNC4xMS0uMDQuMDUtLjA2LjExLS4wNy4xNywwLC4wNi0uMDEuMTEtLjAxLjE1di4wN3MtLjAxLS4wMi0uMDQtLjA2Yy0uMDMtLjA0LS4wNy0uMDktLjE0LS4xNS0uMDctLjA2LS4xNS0uMTItLjI2LS4xOC0uMTEtLjA2LS4yNC0uMTEtLjQtLjE2LS4xNi0uMDQtLjM0LS4wNi0uNTUtLjA2LS4xNCwwLS4yOC4wMS0uNDMuMDUtLjE1LjAzLS4zLjA5LS40NS4xNy0uMTUuMDgtLjI4LjE5LS40LjMzLS4xMi4xNC0uMjEuMzEtLjI4LjUyLS4wNy4yMS0uMS40Ni0uMS43NiwwLC4yLjAzLjM4LjA4LjU0LjA1LjE2LjEyLjI5LjE5LjQuMDguMTEuMTUuMi4yMy4yNy4wOC4wNy4xNC4xMy4xOS4xNi4wNS4wMy4wOC4wNS4wOC4wNSwwLDAtLjA0LDAtLjEuMDEtLjA3LjAxLS4xNS4wMy0uMjQuMDctLjEuMDMtLjE5LjA4LS4yOS4xNS0uMS4wNy0uMTguMTYtLjI0LjI3LS4wNi4xMS0uMS4yNi0uMS40MywwLC4xMywwLC4yNC4wNC4zMy4wMy4wOS4wOC4xNy4xNC4yMy4wNi4wNi4xMi4xMS4xOS4xNC4wNy4wNC4xMy4wNi4xOS4wOCwwLDAtLjAyLjAxLS4wNi4wNC0uMDQuMDItLjA4LjA2LS4xNC4xMS0uMDYuMDUtLjExLjEyLS4xNy4yLS4wNi4wOC0uMS4xOC0uMTQuMjktLjA0LjExLS4wNi4yNC0uMDYuMzksMCwuMjYuMDkuNDguMjYuNjhzLjQyLjM1Ljc0LjQ3Yy4zMy4xMS43My4xNywxLjIuMTcuMjksMCwuNTctLjAzLjgyLS4wOS4yNi0uMDYuNDktLjE1LjY5LS4yNy4yLS4xMi4zNi0uMjguNDgtLjQ3LjEyLS4xOS4xOC0uNDEuMi0uNjdoMFptLTQ2LjE4LS40di0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTIuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNy0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM2LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMjQtMS4yNmMtLjA1LjA2LS4xMS4xMy0uMTguMTgtLjA3LjA2LS4xNS4xMS0uMjQuMTYtLjExLjA1LS4yMi4wOS0uMzIuMTEtLjEuMDItLjIxLjAzLS4zMi4wMy0uMjEsMC0uMzktLjA1LS41NC0uMTUtLjE1LS4wOS0uMjYtLjIzLS4zNS0uNC0uMDktLjE3LS4xNS0uMzctLjItLjU5LS4wNC0uMjMtLjA2LS40Ny0uMDctLjc0LDAtLjE1LDAtLjMxLjAyLS40OS4wMS0uMTguMDQtLjM2LjA4LS41My4wNC0uMTguMS0uMzQuMTgtLjQ5LjA4LS4xNS4xOS0uMjcuMzMtLjM2LjE0LS4wOS4zMS0uMTQuNTItLjE0LjE5LDAsLjM0LjAzLjQ4LjA4LjEzLjA1LjI0LjEzLjMyLjIyLjA4LjA4LjEzLjE4LjE4LjI4LjA0LjEuMDcuMjEuMDguMzIuMDEuMTEuMDIuMjIuMDIuMzJ2Mi4xN2gwWm0xLjA0LDEuMjZ2LTcuMjNoLTEuMDR2Mi40cy0uMDEtLjAyLS4wNC0uMDZjLS4wMy0uMDQtLjA3LS4wOS0uMTItLjE1LS4wNi0uMDYtLjE0LS4xMi0uMjMtLjE4LS4xLS4wNi0uMjItLjExLS4zNi0uMTUtLjE0LS4wNC0uMzItLjA2LS41MS0uMDYtLjI4LDAtLjUyLjA1LS43My4xMy0uMjEuMDktLjM5LjIxLS41NC4zNi0uMTUuMTUtLjI4LjMyLS4zOC41MS0uMS4xOS0uMTguMzktLjI0LjYtLjA2LjIxLS4xLjQyLS4xMy42Mi0uMDMuMjEtLjA0LjQtLjA0LjU4LDAsLjI5LjAyLjU3LjA3Ljg0LjA1LjI3LjEyLjUyLjIxLjc1LjEuMjMuMjMuNDMuMzkuNi4xNi4xNy4zNS4zLjU3LjQuMjMuMDkuNDkuMTQuNzkuMTMuMTksMCwuMzYtLjAzLjUyLS4wOC4xNS0uMDUuMy0uMTIuNDMtLjIxLjEzLS4wOS4yNy0uMi4zOS0uMzJ2LjUzaC45OVptLTYuNDYtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDcuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTYuMTQtMi4xNWMwLC4xOS0uMDIuMzYtLjA3LjQ5LS4wNS4xMy0uMTIuMjQtLjIxLjMzLS4xMS4xMS0uMjQuMTgtLjM4LjIyLS4xNC4wNC0uMjkuMDctLjQ0LjA3LS4xNSwwLS4yOSwwLS40MiwwaC0xLjAzdi0yLjIxaDEuMDNjLjE2LDAsLjMyLDAsLjQ4LjAyLjE2LjAxLjMuMDQuNDQuMDkuMTMuMDUuMjUuMTIuMzQuMjIuMDguMDkuMTUuMi4xOS4zMy4wNS4xMi4wNy4yNy4wNy40NGgwWm0tLjI2LTMuMDZjMCwuMi0uMDQuMzctLjEuNS0uMDcuMTMtLjE1LjIzLS4yNi4zLS4xLjA4LS4yMS4xMy0uMzMuMTYtLjExLjAzLS4yMi4wNS0uMzEuMDYtLjEsMC0uMTcuMDEtLjIyLDBoLTEuMDd2LTIuMDVoMS4wN3MuMSwwLC4xNywwYy4wNywwLC4xNS4wMS4yNC4wMi4wOC4wMS4xNy4wMy4yNS4wNi4wOC4wMy4xNS4wNy4yLjEyLjEyLjA5LjIxLjIuMjcuMzMuMDYuMTMuMDkuMjkuMDkuNDhoMFptMS41LDMuMDRjMC0uMTQtLjAxLS4yNy0uMDQtLjQxLS4wMy0uMTQtLjA4LS4yNy0uMTUtLjM5LS4wNy0uMTMtLjE2LS4yNC0uMjgtLjM1LS4xNC0uMTMtLjMtLjIzLS40Ny0uMjktLjE3LS4wNy0uMzUtLjExLS41Mi0uMTQuMTItLjA0LjIzLS4wOS4zNS0uMTUuMTItLjA2LjIyLS4xMy4zMi0uMi4xLS4wOC4xOC0uMTYuMjUtLjI2LjA4LS4xNC4xNS0uMjkuMi0uNDcuMDUtLjE4LjA4LS4zOC4wOC0uNjEsMC0uMjYtLjA0LS41LS4xMy0uNy0uMDgtLjItLjItLjM3LS4zNC0uNTEtLjE0LS4xNC0uMy0uMjQtLjQ4LS4zMi0uMjItLjEtLjQ2LS4xNy0uNy0uMi0uMjQtLjAzLS41MS0uMDUtLjc5LS4wNWgtMi4yN3Y3LjJoMi4yNWMuMTcsMCwuMzYsMCwuNTUtLjAxLjE5LS4wMS4zOC0uMDMuNTctLjA3LjE5LS4wNC4zNy0uMS41NS0uMTcuMTctLjA4LjMzLS4xOC40Ny0uMzEuMTUtLjE2LjI3LS4zMi4zNi0uNS4wOS0uMTguMTQtLjM2LjE4LS41NS4wMy0uMTkuMDUtLjM3LjA1LS41NmgwWm0xMTIuNDksMi4xN3YtMy41OGMwLS4xNiwwLS4zMi0uMDItLjQ4LS4wMi0uMTYtLjA1LS4zMS0uMS0uNDUtLjA1LS4xNC0uMTMtLjI4LS4yMy0uNDEtLjEzLS4xOS0uMzEtLjMyLS41My0uNDEtLjIyLS4wOS0uNDctLjEzLS43Ny0uMTMtLjIzLDAtLjQzLjA0LS42LjEtLjE3LjA2LS4zMS4xNC0uNDMuMjMtLjExLjA5LS4yLjE4LS4yNy4yNy0uMDYuMDktLjExLjE2LS4xMy4yMXYtLjdoLTEuMDR2NS4zM2gxLjA0di0zLjI4YzAtLjExLDAtLjIzLjAyLS4zNy4wMS0uMTMuMDUtLjI2LjEtLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA5LS4wOC4xOS0uMTUuMzEtLjE5LjExLS4wNS4yNS0uMDcuNDEtLjA3LjIzLDAsLjQxLjA0LjU1LjExLjEzLjA3LjIzLjE3LjI5LjI5LjA2LjEyLjEuMjYuMTIuNDEuMDIuMTUuMDIuMy4wMi40N3YzLjM3aDEuMDJabS01LjM3LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMxLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzQuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4zNCw2Ljd2LTMuNTZjMC0uMTIsMC0uMjYtLjAyLS40MS0uMDEtLjE1LS4wNC0uMy0uMDgtLjQ0LS4wNC0uMTUtLjExLS4yOS0uMTktLjQzLS4wOC0uMTQtLjItLjI1LS4zNC0uMzYtLjEzLS4wOS0uMjgtLjE2LS40NC0uMi0uMTYtLjA0LS4zMS0uMDYtLjQ3LS4wNi0uMjEsMC0uNC4wMy0uNTYuMDktLjE2LjA2LS4zLjEyLS40Mi4yMS0uMTIuMDgtLjIxLjE3LS4yOS4yNS0uMDguMDktLjEzLjE2LS4xNy4yMy0uMDQuMDctLjA2LjExLS4wNy4xMiwwLS4wMy0uMDItLjA4LS4wNS0uMTUtLjAzLS4wNy0uMDgtLjE1LS4xNS0uMjQtLjA2LS4wOS0uMTUtLjE3LS4yNi0uMjUtLjA5LS4wNi0uMTktLjExLS4zLS4xNS0uMTEtLjA0LS4yMS0uMDctLjMyLS4wOC0uMTEtLjAyLS4yMS0uMDItLjMtLjAyLS4yMiwwLS40Mi4wMy0uNTguMDktLjE3LjA2LS4zLjEzLS40Mi4yMi0uMTEuMDktLjIuMTgtLjI3LjI4LS4wNy4wOS0uMTEuMTgtLjEzLjI1di0uNzJoLTEuMDN2NS4zM2gxLjAzdi0zLjI3YzAtLjIyLjAyLS40LjA1LS41NS4wMy0uMTQuMDgtLjI2LjE0LS4zNS4wNS0uMDkuMTItLjE2LjE4LS4yMi4wOC0uMDguMTYtLjEzLjI2LS4xOC4xLS4wNC4yMS0uMDcuMzQtLjA3LjE2LDAsLjI5LjAyLjM4LjA2LjEuMDQuMTguMDguMjQuMTUuMDguMDcuMTQuMTUuMTkuMjUuMDUuMDkuMDguMjEuMS4zNC4wMi4xMy4wMy4yOS4wMy40N3YzLjM3aDEuMDF2LTMuMjdjMC0uMTIsMC0uMjUuMDEtLjM4LjAxLS4xMy4wNC0uMjYuMDktLjM5LjA1LS4xMy4xMy0uMjQuMjQtLjM1LjA4LS4wOC4xOC0uMTQuMjktLjE4LjEtLjA0LjIxLS4wNi4zMy0uMDYuMTMsMCwuMjQuMDEuMzUuMDQuMS4wMy4yLjA4LjI5LjE2LjA3LjA3LjEzLjE0LjE2LjIxLjA0LjA3LjA2LjEyLjA3LjE2LjAxLjA1LjAzLjExLjA0LjE4LjAxLjA3LjAyLjE2LjAzLjI0LDAsLjA5LjAxLjE4LjAxLjI3djMuMzdoMS4wMVptLTkuMTItMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIxLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjEzLjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE4Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTItLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMi0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wOC4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzguMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOS0uNDF2LjMxYzAsLjA1LDAsLjEuMDEuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptLTUuMDMtMi42MnYtNC41OGgtMS4ydjQuNThjMCwuMTYsMCwuMzMtLjAxLjUsMCwuMTctLjAzLjM0LS4wNy40OS0uMDMuMTYtLjA5LjMtLjE2LjQzLS4xLjE1LS4yMy4yNy0uMzkuMzUtLjE2LjA4LS4zNS4xMi0uNTYuMTItLjE2LDAtLjMxLS4wMi0uNDQtLjA1LS4xNC0uMDMtLjI2LS4wNy0uMzctLjExLS4xLS4wNC0uMTktLjA4LS4yNS0uMTEtLjA2LS4wMy0uMDktLjA1LS4xLS4wNmwuMjYsMS4wNHMuMDMuMDEuMDguMDRjLjA1LjAzLjEyLjA2LjIyLjA5LjEuMDMuMjIuMDcuMzUuMDkuMTQuMDMuMjkuMDQuNDcuMDQuMDcsMCwuMTYsMCwuMjgsMCwuMTIsMCwuMjUtLjAzLjM5LS4wNi4xNC0uMDMuMjgtLjA4LjQzLS4xNS4xNC0uMDcuMjctLjE2LjM5LS4yNy4xMi0uMTEuMjMtLjI0LjMxLS4zOC4wOS0uMTQuMTYtLjMuMjItLjQ5LjA2LS4xOC4xLS40LjEyLS42NS4wMy0uMjUuMDQtLjU0LjA0LS44N2gwWm0zMS4xNiwyLjYydi0zLjU4YzAtLjE2LDAtLjMyLS4wMi0uNDgtLjAyLS4xNi0uMDUtLjMxLS4xLS40NS0uMDUtLjE0LS4xMy0uMjgtLjIzLS40MS0uMTMtLjE5LS4zMS0uMzItLjUzLS40MS0uMjItLjA5LS40Ny0uMTMtLjc3LS4xMy0uMjMsMC0uNDMuMDQtLjYuMS0uMTcuMDYtLjMxLjE0LS40My4yMy0uMTEuMDktLjIuMTgtLjI3LjI3LS4wNi4wOS0uMTEuMTYtLjEzLjIxdi0uN2gtMS4wNHY1LjMzaDEuMDR2LTMuMjhjMC0uMTEsMC0uMjMuMDItLjM3LjAxLS4xMy4wNS0uMjYuMS0uMzkuMDUtLjEzLjEzLS4yNC4yNC0uMzUuMDktLjA4LjE5LS4xNS4zMS0uMTkuMTEtLjA1LjI1LS4wNy40MS0uMDcuMjMsMCwuNDEuMDQuNTUuMTEuMTMuMDcuMjMuMTcuMjkuMjkuMDYuMTIuMS4yNi4xMi40MS4wMi4xNS4wMi4zLjAyLjQ3djMuMzdoMS4wMlptLTYuMzUtMS41OWMwLC4xMy0uMDMuMjUtLjA5LjM0LS4wNi4xLS4xNC4xOS0uMjQuMjYtLjEuMDctLjIyLjEzLS4zNC4xOC0uMDcuMDMtLjE0LjA1LS4yMS4wNi0uMDcuMDEtLjE0LjAyLS4xOS4wMi0uMTcsMC0uMzMtLjAzLS40Ny0uMDktLjE0LS4wNi0uMjUtLjE2LS4zMy0uMjktLjA4LS4xMy0uMTMtLjMtLjEzLS41LDAtLjA1LDAtLjExLDAtLjE2LDAtLjA2LjAyLS4xMS4wMy0uMTYuMDUtLjE2LjE0LS4yOS4yNy0uNC4xMy0uMS4yOC0uMTguNDctLjIyLjE5LS4wNS40LS4wNy42NC0uMDcuMTEsMCwuMjEsMCwuMjkuMDEuMDksMCwuMTYuMDIuMjEuMDMuMDUsMCwuMDguMDEuMDguMDJ2Ljk3aDBabTEuMDQsMS41OXYtMy41YzAtLjIzLS4wMS0uNDMtLjA0LS42LS4wMy0uMTctLjA3LS4zMi0uMTQtLjQ1LS4wNi0uMTMtLjE2LS4yNi0uMjgtLjM4LS4xNi0uMTYtLjM3LS4yOS0uNjMtLjM5LS4yNy0uMS0uNTktLjE1LS45OC0uMTUtLjIzLDAtLjQzLjAyLS42MS4wNi0uMTcuMDMtLjMyLjA4LS40NC4xMi0uMTIuMDUtLjIxLjA5LS4yNy4xMi0uMDYuMDQtLjA5LjA1LS4wOS4wNWwtLjE5Ljk0cy4wMy0uMDMuMDktLjA3Yy4wNi0uMDUuMTQtLjEuMjYtLjE2LjEyLS4wNi4yNi0uMTIuNDMtLjE3LjE3LS4wNS4zNy0uMDguNTktLjA4LjI4LDAsLjUxLjAzLjY4LjA5LjE3LjA2LjMuMTQuMzcuMjUuMDcuMDkuMTIuMTguMTQuMjcuMDMuMDkuMDQuMTguMDQuMjcsMCwuMDksMCwuMTYsMCwuMjN2LjI3cy0uMDMsMC0uMDgtLjAxYy0uMDUsMC0uMTMtLjAxLS4yMi0uMDItLjA5LDAtLjItLjAxLS4zMS0uMDEtLjIsMC0uNDEuMDEtLjYxLjA0LS4yMS4wMy0uNC4wNy0uNTkuMTQtLjE5LjA2LS4zNy4xNS0uNTMuMjYtLjE2LjExLS4zLjI0LS40MS40LS4wOS4xMy0uMTYuMjYtLjIuMzktLjA1LjEzLS4wNy4yNC0uMDkuMzUtLjAyLjExLS4wMi4xOS0uMDIuMjYsMCwuMTEuMDEuMjMuMDQuMzcuMDMuMTQuMDcuMjcuMTQuNDEuMDYuMTQuMTUuMjcuMjcuMzguMTIuMTIuMjYuMjEuNDQuMjkuMTcuMDguMzkuMTIuNjMuMTMuMjYsMCwuNS0uMDIuNy0uMDkuMjEtLjA2LjM5LS4xNS41NC0uMjcuMTUtLjEyLjI4LS4yNi4zOC0uNDF2LjMxYzAsLjA1LDAsLjEsMCwuMTUsMCwuMDUuMDMuMS4wNy4xNC4wMy4wMy4wNy4wNS4xMi4wNy4wNS4wMS4wOS4wMi4xMy4wMi4wNCwwLC4wNywwLC4wOSwwaC41NlptMzIuNTEsMHYtNy4yM2gtMS4wMXY3LjIzaDEuMDFabS0zLjM1LTEuNTljMCwuMTMtLjAzLjI1LS4wOS4zNC0uMDYuMS0uMTQuMTktLjI0LjI2LS4xLjA3LS4yMS4xMy0uMzQuMTgtLjA3LjAzLS4xNC4wNS0uMjEuMDYtLjA3LjAxLS4xNC4wMi0uMTkuMDItLjE3LDAtLjMzLS4wMy0uNDctLjA5LS4xNC0uMDYtLjI1LS4xNi0uMzMtLjI5LS4wOC0uMTMtLjEzLS4zLS4xMy0uNSwwLS4wNSwwLS4xMSwwLS4xNiwwLS4wNi4wMi0uMTEuMDMtLjE2LjA1LS4xNi4xNC0uMjkuMjctLjQuMTMtLjEuMjgtLjE4LjQ3LS4yMi4xOS0uMDUuNC0uMDcuNjQtLjA3LjExLDAsLjIxLDAsLjI5LjAxLjA5LDAsLjE2LjAyLjIxLjAzLjA1LDAsLjA4LjAxLjA4LjAydi45N2gwWm0xLjA0LDEuNTl2LTMuNWMwLS4yMy0uMDEtLjQzLS4wNC0uNi0uMDMtLjE3LS4wNy0uMzItLjE0LS40NS0uMDYtLjEzLS4xNi0uMjYtLjI4LS4zOC0uMTYtLjE2LS4zNy0uMjktLjYzLS4zOS0uMjctLjEtLjU5LS4xNS0uOTgtLjE1LS4yMywwLS40My4wMi0uNjEuMDYtLjE3LjAzLS4zMi4wOC0uNDQuMTItLjEyLjA1LS4yMS4wOS0uMjcuMTItLjA2LjA0LS4wOS4wNS0uMDkuMDVsLS4xOS45NHMuMDMtLjAzLjA5LS4wN2MuMDYtLjA1LjE0LS4xLjI2LS4xNi4xMS0uMDYuMjYtLjEyLjQzLS4xNy4xNy0uMDUuMzctLjA4LjU5LS4wOC4yOCwwLC41MS4wMy42OC4wOS4xNy4wNi4zLjE0LjM3LjI1LjA3LjA5LjEyLjE4LjE0LjI3LjAzLjA5LjA0LjE4LjA0LjI3LDAsLjA5LDAsLjE2LDAsLjIzdi4yN3MtLjAzLDAtLjA4LS4wMWMtLjA1LDAtLjEzLS4wMS0uMjItLjAyLS4wOSwwLS4yLS4wMS0uMzItLjAxLS4yLDAtLjQxLjAxLS42MS4wNC0uMjEuMDMtLjQuMDctLjU5LjE0LS4xOS4wNi0uMzcuMTUtLjUzLjI2LS4xNi4xMS0uMy4yNC0uNDEuNC0uMDkuMTMtLjE2LjI2LS4yLjM5LS4wNS4xMy0uMDguMjQtLjA5LjM1LS4wMi4xMS0uMDIuMTktLjAyLjI2LDAsLjExLjAxLjIzLjA0LjM3LjAzLjE0LjA3LjI3LjE0LjQxLjA2LjE0LjE1LjI3LjI3LjM4LjEyLjEyLjI2LjIxLjQ0LjI5LjE3LjA4LjM5LjEyLjYzLjEzLjI2LDAsLjUtLjAyLjctLjA5LjIxLS4wNi4zOS0uMTUuNTQtLjI3LjE1LS4xMi4yOC0uMjYuMzktLjQxdi4zMWMwLC4wNSwwLC4xLDAsLjE1LDAsLjA1LjAzLjEuMDcuMTQuMDMuMDMuMDcuMDUuMTIuMDcuMDUuMDEuMDkuMDIuMTMuMDIuMDQsMCwuMDcsMCwuMDksMGguNTZabS01LjE1LDB2LTUuMzNoLTEuMDN2NS4zM2gxLjAzWm0uMDktNi43YzAtLjEtLjAzLS4yLS4wOC0uMjctLjA1LS4wOC0uMTItLjE0LS4yMi0uMTgtLjA5LS4wNC0uMi0uMDctLjMyLS4wNy0uMTIsMC0uMjIuMDMtLjMxLjA4LS4wOS4wNS0uMTYuMTEtLjIxLjE5LS4wNS4wOC0uMDguMTYtLjA4LjI1LDAsLjEuMDIuMi4wNy4yOC4wNS4wOC4xMS4xNS4yLjE5LjA5LjA1LjIuMDcuMzMuMDcuMTIsMCwuMjMtLjAzLjMyLS4wNy4wOS0uMDUuMTYtLjExLjIxLS4xOS4wNS0uMDguMDgtLjE4LjA4LS4yOGgwWm0tMi4xMiw1LjE5YzAtLjI2LS4wNi0uNDgtLjE3LS42Ny0uMTEtLjE5LS4yNi0uMzUtLjQ2LS40OC0uMTktLjEzLS40MS0uMjUtLjY1LS4zNS0uMTItLjA1LS4yNC0uMS0uMzctLjE2LS4xMi0uMDUtLjI0LS4xMi0uMzUtLjE5LS4xMS0uMDctLjE5LS4xNS0uMjYtLjI0LS4wNy0uMDktLjEtLjItLjEtLjMyLDAtLjIyLjA4LS4zOC4yMi0uNS4xNS0uMTEuMzUtLjE3LjYyLS4xNy4yMSwwLC40LjAyLjU2LjA1LjE2LjA0LjI5LjA5LjQuMTQuMTEuMDYuMTkuMS4yNC4xNS4wNS4wNC4wOC4wNi4wOC4wN2wtLjE1LS44OHMtLjAyLS4wMi0uMDctLjA2Yy0uMDUtLjA0LS4xMy0uMDgtLjIzLS4xMy0uMTEtLjA1LS4yNS0uMDktLjQyLS4xMi0uMTctLjAzLS4zOS0uMDUtLjY0LS4wNC0uMjMsMC0uNDUuMDMtLjY1LjA5LS4yLjA2LS4zOC4xNS0uNTMuMjgtLjE1LjEyLS4yNy4yNy0uMzYuNDUtLjA5LjE4LS4xMy4zOS0uMTMuNjIsMCwuMjQuMDUuNDUuMTMuNjIuMDguMTcuMTkuMzIuMzMuNDMuMTQuMTIuMjkuMjIuNDUuMzEuMTYuMDguMzMuMTYuNDkuMjMuMTYuMDcuMzIuMTUuNDUuMjIuMTQuMDguMjUuMTcuMzMuMjcuMDguMS4xMy4yMy4xMy4zOCwwLC4yNC0uMDguNDItLjIzLjU0LS4xNS4xMi0uMzguMTctLjcuMTctLjE5LDAtLjM3LS4wMy0uNTUtLjA4LS4xOC0uMDUtLjM0LS4xLS40OC0uMTctLjE0LS4wNi0uMjYtLjEyLS4zNC0uMTctLjA4LS4wNS0uMTMtLjA3LS4xMy0uMDhsLjE1LDEuMDFjLjA3LjA0LjE3LjA5LjI5LjE0LjEzLjA2LjMuMS41LjE0LjIuMDQuNDUuMDYuNzMuMDUuMjcsMCwuNTMtLjA0Ljc3LS4xMi4yNC0uMDguNDUtLjIuNjQtLjM2LjE0LS4xMi4yNi0uMjguMzQtLjQ2LjA4LS4xOS4xMy0uNDEuMTMtLjY2aDBabS01LjM3LTEuMTFjMCwuMzgtLjA0LjcxLS4xMi45OS0uMDguMjgtLjIxLjUtLjM3LjY2LS4xNy4xNi0uMzguMjQtLjY0LjI0LS4yOSwwLS41My0uMDctLjcxLS4yLS4xOC0uMTQtLjMyLS4zNC0uNC0uNjItLjA5LS4yOC0uMTMtLjY0LS4xMy0xLjA3LDAtLjI2LjAxLS41Mi4wNC0uNzYuMDMtLjI0LjA5LS40Ni4xOC0uNjUuMDktLjE5LjIxLS4zNC4zOC0uNDUuMTYtLjExLjM3LS4xNy42NC0uMTcuMjEsMCwuMzguMDUuNTIuMTMuMTQuMDguMjUuMTkuMzMuMzMuMDguMTQuMTQuMjkuMTguNDcuMDQuMTcuMDcuMzUuMDguNTQuMDEuMTkuMDIuMzguMDIuNTZoMFptMS4xLS4wMmMwLS4yOS0uMDItLjU4LS4wNy0uODUtLjA1LS4yNy0uMTItLjUzLS4yMy0uNzYtLjExLS4yMy0uMjQtLjQ0LS40Mi0uNjItLjE3LS4xOC0uMzktLjMyLS42NC0uNDItLjI1LS4xLS41NS0uMTUtLjktLjE2LS4zNCwwLS42NC4wNS0uOS4xNS0uMjYuMS0uNDguMjQtLjY2LjQxLS4xOC4xOC0uMzMuMzgtLjQ0LjYyLS4xMS4yNC0uMi40OS0uMjUuNzctLjA1LjI4LS4wOC41Ni0uMDguODYsMCwuNDEuMDQuNzguMTIsMS4xMS4wOC4zMy4yMS42Mi40Ljg2LjE4LjI0LjQyLjQyLjcyLjU1LjMuMTMuNjYuMTksMS4wOC4yLjM2LDAsLjY3LS4wNy45NS0uMjEuMjgtLjE0LjUyLS4zMy43MS0uNTguMTktLjI1LjM0LS41NC40NC0uODcuMS0uMzMuMTUtLjY4LjE1LTEuMDZoMFptLTUuMzIuNTZjMC0uMjMtLjA0LS40NC0uMS0uNjMtLjA3LS4xOS0uMTctLjM1LS4zLS41LS4xNC0uMTctLjI5LS4zMS0uNDctLjQzLS4xOC0uMTItLjM2LS4yMy0uNTUtLjMyLS4xOS0uMDktLjM4LS4xOC0uNTctLjI2LS4xOS0uMDgtLjM2LS4xNi0uNTItLjI1LS4xNi0uMDgtLjMtLjE4LS40MS0uMjgtLjA3LS4wNy0uMTItLjE0LS4xNi0uMi0uMDQtLjA2LS4wNy0uMTMtLjA4LS4yLS4wMi0uMDctLjAyLS4xNC0uMDItLjIyLDAtLjE0LjAzLS4yNy4wOS0uNC4wNi0uMTMuMTctLjI1LjMyLS4zNS4xLS4wNy4yMy0uMTIuNC0uMTUuMTYtLjAzLjM2LS4wNS42LS4wNS4xMiwwLC4yNCwwLC4zNi4wMy4xMi4wMi4yMy4wNC4zMy4wNi4xNS4wMy4yOC4wNy4zOC4xMS4xLjA0LjE4LjA3LjI0LjEuMDYuMDMuMDkuMDUuMTEuMDdsLS4yNC0xLjAzcy0uMDMtLjAyLS4wOS0uMDVjLS4wNi0uMDMtLjE1LS4wNi0uMjctLjEtLjEyLS4wMy0uMjgtLjA2LS40Ny0uMDktLjE5LS4wMy0uNDItLjA0LS42OS0uMDQtLjIxLDAtLjQxLjAyLS42Mi4wNS0uMi4wNC0uNC4xLS41OC4xOC0uMTkuMDgtLjM2LjItLjUyLjM0LS4xNC4xMi0uMjYuMjYtLjM0LjQtLjA5LjE0LS4xNS4yOS0uMTkuNDQtLjA0LjE1LS4wNi4zLS4wNi40NSwwLC4xNy4wMi4zNC4wNS41LjAzLjE2LjA5LjMxLjE3LjQ2LjEuMTYuMjEuMy4zNi40Mi4xNC4xMi4zMS4yMy40OC4zMi4xOC4wOS4zNi4xOS41NS4yNy4xOS4wOS4zOC4xOC41Ni4yOC4xOS4xLjM2LjIxLjUyLjM0LjEuMDguMTkuMTYuMjYuMjQuMDcuMDguMTIuMTcuMTYuMjcuMDMuMS4wNS4yMS4wNS4zNCwwLC4yLS4wNC4zNy0uMTIuNS0uMDguMTQtLjE5LjI2LS4zNS4zNi0uMDguMDYtLjE3LjEtLjI4LjEzLS4xMS4wMy0uMjIuMDYtLjMzLjA3LS4xMS4wMi0uMjEuMDItLjMuMDMtLjA5LDAtLjE1LDAtLjE4LDAtLjExLDAtLjIyLDAtLjMzLS4wMi0uMTEtLjAxLS4yMi0uMDMtLjMyLS4wNS0uMjItLjA0LS40MS0uMDktLjU2LS4xMy0uMTUtLjA0LS4yNy0uMDgtLjM0LS4xMS0uMDgtLjAzLS4xMi0uMDQtLjEzLS4wNWwuMjYsMS4wMXMuMDQuMDIuMS4wNWMuMDYuMDMuMTYuMDcuMjkuMTEuMTMuMDQuMy4wOC41MS4xMS4yMS4wMy40NS4wNS43NC4wNS4yMiwwLC40NS0uMDIuNjktLjA1LjI0LS4wNC40Ny0uMS43LS4xOS4yMy0uMDkuNDMtLjIyLjYxLS4zOS4xOC0uMTYuMzMtLjM3LjQ0LS42My4xMS0uMjUuMTYtLjU2LjE3LS45MloiLz4KICAgICAgPGc+CiAgICAgICAgPGc+CiAgICAgICAgICA8Zz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtMi41MiwxNS4wNGMuNDQtMy4wNSwzLjUtMy44OCwzLjc5LTYuNjYtMS4zOC42MS0zLjAzLjQyLTQuMjQtLjU4LTEuMzQsMi40MS0xLjQxLDQuNzguNDUsNy4yNFoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy00IiBkPSJtOC40Myw2LjE5YzEuNTYtLjIzLDIuOS0xLjMzLDQuMTgtMi40MSwxLjc3LTEuNSw0LjI0LTMuMzUsNi41OS0zLjE3QzE1LS42OSwxMC40NS4yNCw3LjY4LDEuOTRjMS4wNywxLjE4LDEuMzEsMi44NC43NSw0LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC41LDE1Ljk5Yy0uNDQsMy4wNS0zLjUsMy44OC0zLjc5LDYuNjYsMS4zOC0uNjEsMy4wMy0uNDIsNC4yNC41OCwxLjM0LTIuNDEsMS40MS00Ljc4LS40NS03LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yMi41OSwyNC44NGMtMS41Ni4yMy0yLjksMS4zMy00LjE4LDIuNDEtMS43NywxLjUtNC4yNCwzLjM1LTYuNTksMy4xNyw0LjIsMS4zLDguNzQuMzcsMTEuNTEtMS4zMy0xLjA3LTEuMTgtMS4zMS0yLjg0LS43NS00LjI0WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0xNS45OSwyLjUyYzMuMDUuNDQsMy44NywzLjUsNi42NiwzLjc5LS42MS0xLjM4LS40Mi0zLjAzLjU4LTQuMjQtMi40MS0xLjM0LTQuNzgtMS40MS03LjI0LjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yNC44NCw4LjQzYy4yMywxLjU2LDEuMzMsMi45LDIuNDEsNC4xOCwxLjUsMS43NywzLjM1LDQuMjQsMy4xNyw2LjU5LDEuMy00LjIuMzctOC43NC0xLjMzLTExLjUxLTEuMTgsMS4wNy0yLjg0LDEuMzItNC4yNC43NVoiLz4KICAgICAgICAgICAgPHBhdGggY2xhc3M9ImNscy0yIiBkPSJtMTUuMDQsMjguNWMtMy4wNS0uNDQtMy44OC0zLjUtNi42Ni0zLjc5LjYxLDEuMzguNDIsMy4wMy0uNTgsNC4yNCwyLjQxLDEuMzQsNC43OCwxLjQxLDcuMjQtLjQ1WiIvPgogICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02LjE5LDIyLjU5Yy0uMjMtMS41Ni0xLjMzLTIuOS0yLjQxLTQuMTgtMS41LTEuNzctMy4zNC00LjI0LTMuMTctNi41OS0xLjMsNC4yLS4zNyw4Ljc0LDEuMzMsMTEuNTEsMS4xOC0xLjA3LDIuODQtMS4zMSw0LjI0LS43NVoiLz4KICAgICAgICAgIDwvZz4KICAgICAgICAgIDxnPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im0yOC43NiwyLjI2YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Im02Ljk2LDI0LjA3YzEuMywxLjMsMS4zLDMuNCwwLDQuNy0xLjMsMS4zLTMuNCwxLjMtNC43LDAtMS4zLTEuMy0xLjMtMy40LDAtNC43LDEuMy0xLjMsMy40LTEuMyw0LjcsMFoiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im0yOC43NiwyOC43NmMtMS4zLDEuMy0zLjQsMS4zLTQuNywwLTEuMy0xLjMtMS4zLTMuNCwwLTQuNywxLjMtMS4zLDMuNC0xLjMsNC43LDBzMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgICA8cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Im02Ljk2LDYuOTZjLTEuMywxLjMtMy40LDEuMy00LjcsMC0xLjMtMS4zLTEuMy0zLjQsMC00LjcsMS4zLTEuMywzLjQtMS4zLDQuNywwLDEuMywxLjMsMS4zLDMuNCwwLDQuN1oiLz4KICAgICAgICAgICAgPC9nPgogICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgICAgICA8Zz4KICAgICAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMiIgZD0ibTE0LjEsMTguMzF2MS4xN2gyLjgzdi0yLjU1bDIuNDMsMi4zNWMuMi4xOS4xOS4zLjE5LjQ5di44czAsLjAyLDAsLjA0aDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAyLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMywwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMsMCwuMDRoMHMwLC4wMiwwLC4wNGgwczAsLjAzLDAsLjAzaDBzMCwuMDMtLjAxLjA0aDBzMCwuMDMtLjAxLjAzaDBzMCwuMDIsMCwuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMy0uMDEuMDRoMHMwLC4wMi0uMDEuMDNoMHMwLC4wMi0uMDEuMDNoMHMtLjAxLjAzLS4wMi4wNGgwczAsLjAyLS4wMS4wM2gwczAsLjAyLS4wMS4wM2gwczAsLjAzLS4wMi4wM2gwczAsLjAyLS4wMS4wM2gwcy0uMDEuMDItLjAyLjAzYzAsMCwwLDAtLjAxLjAxLDAsMCwwLC4wMS0uMDEuMDJoMHMwLC4wMi0uMDEuMDJjMCwwLDAsMC0uMDEuMDEsMCwwLS4wMS4wMS0uMDIuMDIsMCwwLDAsMC0uMDEuMDEsMCwwLDAsMC0uMDEuMDFoLS4wMXMtLjAxLjAyLS4wMS4wMmMwLDAsMCwwLS4wMS4wMWgwcy0uMDEuMDEtLjAyLjAyaDBzMCwwLS4wMS4wMWMwLDAsMCwwLS4wMS4wMWgtLjAxcy0uMDEuMDItLjAxLjAyYzAsMC0uMDIuMDEtLjAyLjAyaC0uMDFzMCwuMDItLjAxLjAyaC0uMDFzMCwuMDItLjAxLjAyYzAsMCwwLDAtLjAxLDAsMCwwLS4wMi4wMS0uMDMuMDJoMHMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaC0uMDFzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAxLjAxLS4wMi4wMmgtLjAxcy0uMDEuMDEtLjAyLjAyaDBzLS4wMi4wMi0uMDMuMDJoLS4wMXMtLjAyLjAxLS4wMi4wMWMwLDAsMCwwLS4wMSwwLS4yLjA5LS40MS4xNC0uNjQuMTRoLTMuOTF2MS4xN2wtMi41LTIuNDgsMi41LTIuNDhoMFptMi44My00LjIxaDIuNTV2Mi44M2gtMS4xN2wyLjQ4LDIuNSwyLjQ4LTIuNWgtMS4xN3YtMy45MWMwLS4yMy0uMDUtLjQ1LS4xNC0uNjQsMCwwLDAsMCwwLS4wMXYtLjAycy0uMDEtLjAxLS4wMS0uMDFjMC0uMDEtLjAxLS4wMi0uMDItLjAzaDBzMC0uMDIsMC0uMDJoMHMwLS4wMiwwLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRoMHMwLS4wMi0uMDEtLjAzaDBzMC0uMDItLjAxLS4wM2gwcy0uMDEtLjAzLS4wMi0uMDRjMCwwLDAsMCwwLS4wMSwwLDAsMCwwLS4wMS0uMDFoMHMwLS4wMi0uMDEtLjAzaDBzLS4wMS0uMDMtLjAyLS4wM2gtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMWgwcy0uMDEtLjAxLS4wMi0uMDJoMHMwLDAtLjAxLS4wMWgtLjAxcy0uMDEtLjAyLS4wMS0uMDJjMCwwLDAsMC0uMDEtLjAxLDAsMCwwLDAtLjAxLS4wMSwwLDAtLjAxLS4wMS0uMDItLjAyLDAsMCwwLDAtLjAxLDAsMCwwLDAsMC0uMDEtLjAxaC0uMDFzLS4wMS0uMDItLjAyLS4wMmMwLDAsMCwwLS4wMS0uMDEsMCwwLS4wMS0uMDEtLjAyLS4wMWgtLjAxczAtLjAyLS4wMS0uMDJoLS4wMXMtLjAxLS4wMi0uMDItLjAyaC0uMDFzLS4wMS0uMDItLjAyLS4wMmgtLjAxcy0uMDEtLjAyLS4wMi0uMDJoLS4wMXMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDEtLjAxLS4wMi0uMDJoMHMtLjAyLS4wMi0uMDMtLjAyaDBzLS4wMS0uMDEtLjAyLS4wMmgtLjAxcy0uMDItLjAxLS4wMi0uMDJoMHMtLjAyLS4wMS0uMDMtLjAyaDBzLS4wMSwwLS4wMi0uMDFoLS4wMXMtLjAyLS4wMS0uMDMtLjAxaDBzLS4wMiwwLS4wMy0uMDFoLS4wMXMtLjAxLDAtLjAyLS4wMWgwcy0uMDIsMC0uMDMtLjAxaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wMywwaDBzLS4wMiwwLS4wNCwwaDBzLS4wMiwwLS4wMywwaC0uMDFzLS4wMiwwLS4wNCwwaC0uOGMtLjE4LDAtLjI5LS4wMi0uNDkuMTlsLTIuMzUsMi40M2gwWm0tMi44MywyLjgzaC0yLjU1di0yLjgzaDEuMTdsLTIuNDgtMi41LTIuNDgsMi41aDEuMTd2My45MWMwLC4yMy4wNS40NS4xNC42NCwwLDAsMCwwLDAsLjAxdi4wMnMuMDEuMDEuMDEuMDFjMCwuMDEuMDEuMDIuMDIuMDNoMHMwLC4wMiwwLC4wMmgwczAsLjAyLDAsLjAzaDBzLjAxLjAzLjAyLjA0aDBzMCwuMDIuMDEuMDNoMHMwLC4wMi4wMS4wM2gwcy4wMS4wMy4wMi4wNGMwLDAsMCwwLDAsLjAxLDAsMCwwLDAsLjAxLjAxaDBzMCwuMDIuMDEuMDNoMHMuMDEuMDMuMDIuMDRoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMWgwcy4wMS4wMS4wMi4wMmgwczAsMCwuMDEuMDFoLjAxcy4wMS4wMi4wMS4wMmMwLDAsMCwwLC4wMS4wMSwwLDAsMCwwLC4wMS4wMSwwLDAsLjAxLjAxLjAyLjAyLDAsMCwwLDAsLjAxLjAxLDAsMCwwLDAsLjAxLjAxaC4wMXMuMDEuMDIuMDIuMDJjMCwwLDAsMCwuMDEuMDEsMCwwLC4wMS4wMS4wMi4wMWguMDFzMCwuMDIuMDEuMDJoLjAxcy4wMS4wMi4wMi4wMmguMDFzLjAxLjAyLjAyLjAyaC4wMXMuMDEuMDIuMDIuMDJoLjAxcy4wMi4wMi4wMy4wMmgwcy4wMS4wMS4wMi4wMmguMDFzLjAxLjAxLjAyLjAyaDBzLjAyLjAyLjAzLjAyaDBzLjAxLjAxLjAyLjAyaDBzLjAyLjAxLjAyLjAyaDBzLjAyLjAxLjAzLjAyaDBzLjAxLjAxLjAyLjAxaC4wMXMuMDIuMDEuMDMuMDFoMHMuMDIsMCwuMDMuMDFoMHMuMDIsMCwuMDIuMDFoLjAxcy4wMiwwLC4wMy4wMWgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoMHMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaC4wMXMuMDIsMCwuMDMsMGgwcy4wMiwwLC4wMywwaDBzLjAyLDAsLjAzLDBoLjAxcy4wMiwwLC4wMywwaDBzLjAyLDAsLjA0LDBoMHMuMDIsMCwuMDMsMGguMDFzLjAyLDAsLjA0LDBoLjhjLjE4LDAsLjI5LjAyLjQ5LS4xOWwyLjM1LTIuNDNoMFptMC0yLjgzbC0yLjQzLTIuMzVjLS4yMS0uMi0uMTktLjMtLjE5LS40OXYtLjhzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA1aDBzMC0uMDIsMC0uMDRoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAzLDAtLjA0aDBzMC0uMDMsMC0uMDNoMHMwLS4wMywwLS4wNGgwczAtLjAyLjAxLS4wNGgwczAtLjAyLDAtLjAzaDBzMC0uMDMuMDEtLjA0aDBzMC0uMDIsMC0uMDNoMHMwLS4wMywwLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwczAtLjAzLjAxLS4wNGgwczAtLjAyLjAxLS4wM2gwczAtLjAyLjAxLS4wM2gwcy4wMS0uMDMuMDItLjA0aDBzMC0uMDIuMDEtLjAzaDBzMC0uMDIuMDEtLjAzaDBzMC0uMDMuMDItLjAzaDBzMC0uMDIuMDEtLjAzaDBzLjAxLS4wMi4wMS0uMDNjMCwwLDAsMCwuMDEtLjAxLDAsMCwwLS4wMS4wMS0uMDJoMHMwLS4wMi4wMS0uMDJjMCwwLDAsMCwuMDEtLjAxLDAsMCwuMDEtLjAxLjAyLS4wMiwwLDAsMCwwLC4wMS0uMDEsMCwwLDAsMCwuMDEtLjAxaC4wMXMuMDEtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMS0uMDFoMHMuMDEtLjAxLjAyLS4wMmgwczAsMCwuMDEtLjAxYzAsMCwwLDAsLjAxLS4wMWguMDFzLjAxLS4wMi4wMS0uMDJjMCwwLC4wMi0uMDEuMDItLjAyaC4wMXMwLS4wMi4wMS0uMDJoLjAxczAtLjAyLjAxLS4wMmMwLDAsMCwwLC4wMSwwLDAsMCwuMDItLjAxLjAzLS4wMmgwcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmguMDFzLjAyLS4wMi4wMy0uMDJoLjAxcy4wMS0uMDEuMDItLjAyaC4wMXMuMDEtLjAxLjAyLS4wMmgwcy4wMi0uMDIuMDMtLjAyaC4wMXMuMDItLjAxLjAyLS4wMWMwLDAsMCwwLC4wMSwwLC4yLS4wOS40MS0uMTQuNjQtLjE0aDMuOTF2LTEuMTdsMi41LDIuNDgtMi41LDIuNDh2LTEuMTdoLTIuODN2Mi41NVoiLz4KICAgICAgICAgIDxwb2x5Z29uIGNsYXNzPSJjbHMtNSIgcG9pbnRzPSIxNC4xMSAxOS40NSAxNC4xMSAxNi45MiAxMS41NyAxNi45MiAxMS41NyAxNC4xMSAxNC4xMSAxNC4xMSAxNC4xMSAxMS41NyAxNi45MiAxMS41NyAxNi45MiAxNC4xMSAxOS40NSAxNC4xMSAxOS40NSAxNi45MiAxNi45MiAxNi45MiAxNi45MiAxOS40NSAxNC4xMSAxOS40NSIvPgogICAgICAgIDwvZz4KICAgICAgPC9nPgogICAgPC9nPgogIDwvZz4KPC9zdmc+",Tt=i=>i.replace(/\s+/g," ").replace(/Telep\s+on/gi,"Telepon").replace(/Kunjunga\s+n/gi,"Kunjungan").replace(/Spes\s+ialis/gi,"Spesialis").trim();function Vt(i){let u=i.find(m=>/^SEP$/i.test(m.title)),a=u?Nt(u.html):"",e=u&&new DOMParser().parseFromString(u.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",n=m=>Tt(a.match(m)?.[1]||"")||"-",L=(m,T)=>n(new RegExp(`${m}\\s*:\\s*([\\s\\S]*?)(?=${T}|$)`,"i")),s=M("no_sep","sep")!=="-"?M("no_sep","sep"):n(/No\.?\s*SEP\s*[:.]?\s*([0-9A-Z]+)/i),l=n(/Tgl\.?\s*SEP\s*[:.]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})/i),d=M("no_hp","telepon")!=="-"?M("no_hp","telepon"):L("No\\.?\\s*Telepon","Sub\\/Spesialis"),x=M("kelas").replace(/^Kelas\s*/i,""),z=M("tgl_lahir","tglLahir").replace(/^:\s*/,"").split(/\s*\/\s*/)[0]?.trim()||"-",p=L("Kelamin","No\\.?\\s*Telepon"),P=M("dokter","dpjp"),k=M("kartu","no_kartu","noka"),y=M("norm","rekam_medis"),C=M("nama")||"-",N=k.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),h=N?`${t(N[1].trim())}<span class="sep-inline-mr">No.MR : ${t(N[2].trim())}</span>`:`${t(k)}${y!=="-"?`<span class="sep-inline-mr">No.MR : ${t(y)}</span>`:""}`,O=M("jenis_kunjungan")!=="-"?M("jenis_kunjungan"):n(/Jns\.?\s*Kunjungan\s*[:.]?\s*([\s\S]*?)(?:\s+Kls\.?\s*Hak|$)/i),B=O.replace(/^-\s*/,"").split(/\s+-\s+|\n/).map(m=>m.trim()).filter(Boolean),R=B.length>1?'<ul class="sep-multiline-list">'+B.map(m=>`<li>${t(m)}</li>`).join("")+"</ul>":t(O),E=M("peserta","jenis_peserta")!=="-"?M("peserta","jenis_peserta"):L("(?<!Nama )Peserta","COB|Jns\\.?\\s*Rawat"),U=M("penjamin")!=="-"?M("penjamin"):L("Penjamin","\\*Saya|CATATAN"),$=M("faskes_perujuk","faskes")!=="-"?M("faskes_perujuk","faskes"):L("Faskes\\s*Perujuk","Diagnosa\\s*Awal"),Y=M("diagnosa_awal")!=="-"?M("diagnosa_awal"):L("Diagnosa\\s*Awal","Catatan|Peserta"),w=M("catatan_sep","catatan")!=="-"?M("catatan_sep","catatan"):L("Catatan","Peserta|COB"),S=M("sub_spesialis","spesialis")!=="-"?M("sub_spesialis","spesialis"):L("Sub\\/Spesialis","Dokter"),f=n(/Cetakan\s+ke\s*[:.]?\s*(\d+)/i),A=f!=="-"?`<div class="sep-print-meta">Cetakan ke ${t(f)}</div>`:"",g=(m,T,I="",o=!1)=>`<tr><td class="lbl${o?" right":""}">${m}</td><td class="sep">:</td><td class="val${I?" "+I:""}">${T}</td></tr>`,v='<tr><td colspan="3">&nbsp;</td></tr>',c=x!=="-"?`Kelas ${t(x)}`:"-";return`<section class="rm-page sep-page" id="rm-01">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${It}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT ELEGIBILITAS PESERTA</div>
     <div class="sep-hospital">${t(St.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-columns">
   <div class="sep-col-left"><table class="sep-kv-table">
     ${g("No. SEP",`<span class="sep-no-value">${t(s)}</span>`)}
     ${g("Tgl. SEP",t(l))}
     ${g("No.Kartu",h)}
     ${g("Nama Peserta",`<strong>${t(C)}</strong>`)}
     ${g("Tgl.Lahir",`${t(z)} &nbsp;&nbsp; Kelamin : ${t(p)}`)}
     ${g("No.Telepon",t(d))}
     ${g("Sub/Spesialis",t(S))}
     ${g("Dokter",t(P))}
     ${g("Faskes Perujuk",t($!=="-"?$:`${St} - Kota Jambi`))}
     ${g("Diagnosa Awal",t(Y))}
     ${g("Catatan",t(w))}
   </table></div>
   <div class="sep-col-right"><table class="sep-kv-table">
     ${v}${v}
     ${g("Peserta",t(E),"",!0)}
     ${g("COB","-","",!0)}
     ${g("Jns.Rawat",`<strong>${t(M("jenis"))}</strong>`,"",!0)}
     ${g("Jns.Kunjungan",R,"",!0)}
     ${g("Kls.Hak",`<strong>${c}</strong>`,"",!0)}
     ${g("Kls.Rawat",`<strong>${c}</strong>`,"",!0)}
     ${g("Penjamin",t(U),"",!0)}
   </table></div>
 </div>
 <div class="sep-disclaimer">
   *Saya Menyetujui BPJS Kesehatan menggunakan informasi Medis Pasien jika diperlukan.<br/>
   *SEP bukan sebagai bukti penjamin peserta
 </div>
 ${A}
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div class="sep-sig-role">Pasien/<br/>Keluarga Pasien</div>
     ${e?`<img class="sep-qr" src="${t(e)}" alt="QR SEP" width="100" height="100" />`:""}
     <div class="sep-sig-name">(${t(C)})</div>
   </div>
 </div>
 </section>
</section>`}function Zt(i){let u=i.find($=>/^SPRI$/i.test($.title)),a=W(i,/^SPRI$/i)[0]??"",e=u?new DOMParser().parseFromString(u.html,"text/html"):null,n=$=>{if(!e)return"-";for(let Y of Array.from(e.querySelectorAll("tr"))){let w=Array.from(Y.cells);if(!w.length)continue;let S=(w[0].textContent||"").replace(/\s+/g," ").trim();if(!$.test(S))continue;if(w.length===1)return S;let f=w.slice(1).map(A=>(A.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()).filter(Boolean).join(`
`).trim();if(f)return f}return"-"},L=($,Y)=>Y.match($)?.[1]?.trim()||"-",s=n(/^Pemeriksaan Fisik$/i),l=L(/Keadaan Umum\s*:\s*(.*?)\s*(?:Tensi|$)/i,s),d=L(/Tensi\s*:\s*(.*?)\s*(?:Nadi|$)/i,s),x=L(/Nadi\s*:\s*(.*?)\s*(?:RR|$)/i,s),z=L(/RR\s*:\s*(.*?)\s*(?:Suhu|$)/i,s),p=L(/Suhu\s*:\s*(.*?)\s*(?:BB|$)/i,s),P=L(/BB\s*:\s*(.*?)\s*(?:TB|$)/i,s),k=L(/TB\s*:\s*(.*?)$/i,s),y=L(/Pemeriksaan Fisik\s*:\s*([\s\S]*)$/i,s),C=n(/^Catatan$/i),N=n(/^Diit$/i),h=n(/^Terapi$/i),O=n(/^Kota Jambi,.*Jam|^Waktu Pengantar/i),B=O.match(/^(Kota Jambi,.*?Jam\s*\d{1,2}:\d{2})/i)?.[1]||O,R=M("dokter","dpjp"),E=M("tgl_lahir","tglLahir").split(/\s*\/\s*/),U=E.length>1?`${E[1]} (${E[0]})`:E[0]||"-";return`<section class="rm-page" id="rm-03">
${J("RM. 03")}
<div class="rm-form-title">SURAT PENGANTAR RAWAT INAP (SPRI)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${r("Umur / Tgl. Lahir",U)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Alamat",st(i))}
    ${r("Dikirim Oleh",R)}
    ${r("Waktu Pengantar",B)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr><th colspan="7">PEMERIKSAAN TANDA VITAL &amp; ANTROPOMETRI SAAT MASUK</th></tr>
    <tr>
      <th>KEADAAN UMUM</th><th>TEKANAN DARAH</th><th>NADI</th>
      <th>PERNAPASAN (RR)</th><th>SUHU</th><th>BERAT BADAN</th><th>TINGGI BADAN</th>
    </tr>
  </thead>
  <tbody><tr>
    <td class="center"><strong>${t(l)}</strong></td>
    <td class="center"><strong>${t(d)}</strong></td>
    <td class="center">${t(x)}</td>
    <td class="center">${t(z)}</td>
    <td class="center">${t(p)}</td>
    <td class="center">${t(P)}</td>
    <td class="center">${t(k)}</td>
  </tr></tbody>
</table>

<table class="rm-grid-table">
  <tbody>
    <tr><td style="width: 175px;"><strong>ANAMNESIS</strong></td><td>${F(n(/^Anamnesis$/i))}</td></tr>
    <tr><td><strong>RIWAYAT PENYAKIT KELUARGA</strong></td><td>${F(n(/^Riwayat Penyakit Keluarga$/i))}</td></tr>
    <tr><td><strong>RIWAYAT ALERGI</strong></td><td>${F(n(/^Riwayat Alergi$/i))}</td></tr>
    <tr><td><strong>PEMERIKSAAN FISIK / CATATAN</strong></td><td>${y!=="-"?`<strong>${F(y)}</strong>`:"-"}${C!=="-"?`<br/>${F(C)}`:""}</td></tr>
    <tr><td><strong>PEMERIKSAAN PENUNJANG AWAL</strong></td><td>${F(n(/^Pemeriksaan Penunjang$/i))}</td></tr>
    <tr><td><strong>DIAGNOSA KERJA</strong></td><td><strong>${F(n(/^Diagnosa Kerja$/i))}</strong></td></tr>
    <tr><td><strong>TERAPI &amp; DIIT AWAL</strong></td><td>${F(h)}${N!=="-"?`<br/><strong>Diit :</strong> ${F(N)}`:""}</td></tr>
  </tbody>
</table>

<div class="rm-signature-block" style="justify-content:flex-end;">
  <div class="rm-sig-box">
    <div>${t(B)}</div>
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(R)} )</div>
  </div>
</div>
</section>`}function ta(i){let u=i.find(w=>/^SBPK$/i.test(w.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=new Map,n=new Map,L=[],s="-";if(a){for(let f of Array.from(a.querySelectorAll("tr"))){let A=Array.from(f.cells);for(let g=0;g<A.length-2;g++){let v=(A[g].textContent||"").replace(/\s+/g," ").trim();if((A[g+1].textContent||"").trim()!==":")continue;let c=(A[g+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();v&&c&&!e.has(v)&&e.set(v,c)}A.length>=5&&/^[A-Z]\d{2}(?:\.\d+)?$/.test(A[2].textContent?.trim()??"")&&A[0].textContent?.trim()&&A[1].textContent?.trim()&&L.push({unit:(A[0].textContent||"").replace(/\s+/g," ").trim(),diag:(A[1].textContent||"").replace(/\s+/g," ").trim(),icd:(A[2].textContent||"").trim(),dokter:(A[4].textContent||"").replace(/\s+/g," ").trim()||"-"})}for(let f of Array.from(a.querySelectorAll("li"))){let A=(f.textContent||"").replace(/\s+/g," ").trim();if(!A||/\([A-Z]\d{2}(?:\.\d+)?\)$/i.test(A))continue;let g=A.toUpperCase();n.set(g,(n.get(g)||0)+1)}let w=Array.from(a.querySelectorAll("table")),S=(w[w.length-1]?.textContent||"").match(/\((dr\.[^)]+)\)/i);S&&(s=S[1].trim())}let l=w=>{for(let[S,f]of e)if(w.test(S))return f;return"-"},d=l(/^No Kartu BPJS$/i),x=M("norm","rekam_medis"),z=M("nama"),p=l(/^Tanggal lahir/i),P=l(/^Alamat$/i),k=M("no_sep","sep")!=="-"?M("no_sep","sep"):l(/^No SEP$/i),y=l(/^Jenis Kelamin$/i),C=/^L$/i.test(y)?"Laki-laki (L)":/^P$/i.test(y)?"Perempuan (P)":y,N=l(/^Tgl\.? Masuk RS$/i),h=l(/^Berat badan/i),O=L[0]?.unit||l(/^Unit Pelayanan|^Poliklinik/i),B=l(/^ANAMNESE$/i),R=s!=="-"?s:M("dokter","dpjp"),E=W(i,/^SBPK/i)[0]??"",U=W(i,/^SEP/i)[0]??W(i,/^Rincian Biaya/i)[0]??"",$=L.length?L.map(w=>`<tr><td>${t(w.unit)}</td><td>Diagnosa</td><td><strong>${t(w.diag)}</strong></td><td class="center">${t(w.icd)}</td><td>${t(w.dokter)}</td></tr>`).join(""):`<tr><td>${F(O)}</td><td>Diagnosa Utama</td><td><strong>${F(l(/^Diagnosa utama/i))}</strong></td><td class="center">-</td><td>${t(R)}</td></tr>
       <tr><td>${F(O)}</td><td>Diagnosa Tambahan</td><td>${F(l(/^Diagnosa tambahan/i))}</td><td class="center">-</td><td>${t(R)}</td></tr>`,Y=Array.from(n.entries()).map(([w,S],f)=>`<tr><td class="center">${f+1}</td><td>${t(w)}</td><td>${t(R)}</td><td class="center">${S}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi SBPK Item ${f+1}"></td></tr>`).join("");return`<section class="rm-page" id="rm-02">
${J("RM. 02")}
<div class="rm-form-title">SURAT BUKTI PELAYANAN KESEHATAN (SBPK)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("No. Kartu BPJS",d)}
    ${r("No. Rekam Medis",x)}
    ${r("Nama Pasien",z,!0)}
    ${r("Tgl. Lahir / Umur",p)}
    ${r("Alamat",P)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("No. SEP",k)}
    ${r("Jenis Kelamin",C)}
    ${r("Tgl. Masuk RS",`${N} (*)`,!0)}
    ${r("Berat Badan Bayi",h)}
    ${r("Unit Pelayanan",O)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    <tr>
      <td style="width: 170px;"><strong>Hasil anamnesa datang untuk</strong></td>
      <td>
        <span class="static-box">&nbsp;</span> Suspek &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&#10003;</span> <strong>Tegak Diagnosa</strong> &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Observasi &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Kontrol lanjutan &nbsp;&nbsp;&nbsp;&nbsp;
        <span class="static-box">&nbsp;</span> Buka Balutan / Jahitan
      </td>
    </tr>
    <tr><td><strong>ANAMNESE</strong></td><td>${F(B)}</td></tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 150px;">POLIKLINIK / RUANG</th>
    <th style="width: 120px;">JENIS DIAGNOSA</th>
    <th>DIAGNOSA</th>
    <th style="width: 65px;">ICD X</th>
    <th style="width: 165px;">DOKTER / PETUGAS</th>
  </tr></thead>
  <tbody>${$}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>TINDAKAN / PEMERIKSAAN PENUNJANG / TERAPI (TERAGGREGASI)</th>
    <th style="width: 165px;">UNIT / DOKTER PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${Y}</tbody>
</table>

<div class="footnote-rm">
  (*) Catatan Sistem: periksa kembali tanggal masuk pada SBPK dengan SEP &amp; Resume sebelum berkas dikirim.
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Pasien / Keluarga Pasien</div>
    ${U?`<img class="rm-sig-qr" src="${t(U)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${U?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(z)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penanggung Jawab Pelayanan (DPJP)</div>
    ${E?`<img class="rm-sig-qr" src="${t(E)}" alt="QR persetujuan DPJP" width="80" height="80" />`:""}
    ${E?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(R)} )</div>
  </div>
</div>
</section>`}var bt=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];function mt(i){let u=String(i??"").replace(/^\s*:\s*/,"").trim(),a=u.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/)||u.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(!a)return u||"-";let[e,n,L]=a.slice(1),s=e.length===4?e:L,l=bt[Number(n)-1];return l?`${Number(e.length===4?L:e)} ${l} ${s}`:u}function aa(i){let u=i.find($=>/^Surat (?:Rencana )?Kontrol/i.test($.title)),a=u?Nt(u.html):"",e=$=>Tt(a.match($)?.[1]||"")||"-",n=($,Y)=>e(new RegExp(`${$}\\s*:\\s*([\\s\\S]*?)(?=${Y}|$)`,"i")),L=($,Y)=>{for(let w of $){let S=M(w);if(S!=="-")return S}return e(Y)},s=u&&new DOMParser().parseFromString(u.html,"text/html").querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||""||W(i,/^SEP/i)[0]||W(i,/^Resume/i)[0]||W(i,/^SBPK/i)[0]||W(i,/^Rincian Biaya/i)[0]||"",l=L(["no_surat_kontrol","no_surat"],/NO\.\s*([0-9A-Z]{10,})/i),d=e(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i)!=="-"?e(/Kepada Yth\s*([\s\S]*?)(?=Mohon pemeriksaan|No\.?\s*Kartu|$)/i):M("dokter","dpjp"),x=M("dokter","dpjp")!=="-"?M("dokter","dpjp"):d,z=L(["kartu","no_kartu","noka"],/No\.?\s*Kartu\s*[:.]?\s*([\s\S]*?)(?=Nama\s*Peserta|$)/i),p=M("norm","rekam_medis"),P=z.match(/^(.*?)\s*\(MR\.?\s*([^)]+)\)$/i),k=P?`${t(P[1].trim())}<span class="sep-inline-mr">No.MR : ${t(P[2].trim())}</span>`:`${t(z)}${p!=="-"?`<span class="sep-inline-mr">No.MR : ${t(p)}</span>`:""}`,y=M("nama")!=="-"?M("nama"):n("Nama\\s*Peserta","Tanggal Lahir"),C=M("jenis_kelamin","jk"),N=/perempuan|^p$/i.test(C)?"Perempuan":/laki|^l$/i.test(C)?"Laki-laki":a.match(/Nama Peserta\s*:\s*[^()]*\((Perempuan|Laki-laki)\)/i)?.[1]||"",h=N&&!new RegExp(`\\(${N}\\)`,"i").test(y)?`${y} (${N})`:y,O=mt(L(["tgl_lahir","tglLahir"],/Tanggal Lahir\s*[:.]?\s*([\s\S]*?)(?=Diagnosa|$)/i)),B=L(["diagnosa_awal","diagnosa"],/Diagnosa\s*[:.]?\s*([\s\S]*?)(?=Tanggal entri|$)/i),R=mt(L(["tanggalAwal","tgl_masuk","tgl"],/Tanggal entri\s*[:.]?\s*([\s\S]*?)(?=Demikian|$)/i)),E=($,Y)=>`<tr><td class="lbl">${$}</td><td class="sep">:</td><td class="val">${Y}</td></tr>`,U=$=>`<tr><td class="val" colspan="3" style="padding-top:6px;">${t($)}</td></tr>`;return`<section class="rm-page sep-page" id="surat-kontrol">
 <section class="bpjs-sep-sheet">
 <div class="sep-header">
   <img class="sep-logo" src="${It}" alt="BPJS Kesehatan" width="215" height="33" />
   <div class="sep-title-wrap">
     <div class="sep-title">SURAT RENCANA KONTROL</div>
     <div class="sep-hospital">${t(St.toUpperCase())}</div>
   </div>
 </div>
 <div class="sep-no-value" style="text-align:right;margin-bottom:10px;">NO. ${t(l)}</div>
 <div class="sep-columns">
   <div class="sep-col-left" style="flex:1 1 100%;"><table class="sep-kv-table">
     <tr><td class="lbl">Kepada Yth</td><td class="sep">:</td><td class="val"><strong>${t(d)}</strong></td></tr>
     ${U("Mohon pemeriksaan dan penangan lebih lanjut :")}
     ${E("No.Kartu",k)}
     ${E("Nama Peserta",`<strong>${t(h)}</strong>`)}
     ${E("Tanggal Lahir",t(O))}
     ${E("Diagnosa",t(B))}
     ${E("Tanggal entri",t(R))}
     ${U("Demikian atas bantuannya, diucapkan banyak terima kasih.")}
   </table></div>
 </div>
 <div class="sep-signatures">
   <div class="sep-sig-box">
     <div>Mengetahui,</div>
     ${s?`<img class="sep-qr" src="${t(s)}" alt="QR tanda tangan DPJP" width="100" height="100" />`:""}
     <div class="sep-sig-name">( ${t(x)} )</div>
   </div>
 </div>
 </section>
</section>`}function ia(i){let u=i.find(c=>/^Rincian Biaya/i.test(c.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=new Map,n=new Map;if(a){let c=Array.from(a.querySelectorAll("table")),m=c.find(I=>/frek/i.test(I.rows[0]?.textContent||""));for(let I of Array.from(m?.rows??[])){let o=Array.from(I.cells).map(at=>(at.textContent||"").replace(/\s+/g," ").trim());if(o.length<6||!/^\d+\.?$/.test(o[0]))continue;let b=o[2]||"-",Q=b.toUpperCase().replace(/\s+/g," ").trim(),H=parseInt(o[4],10)||1,_=parseFloat((o[7]||"0").replace(/\./g,"").replace(",","."))||0,tt=e.get(Q);tt?(tt.frek+=H,tt.jaminan+=_):e.set(Q,{name:b,petugas:o[3]||"-",frek:H,tarif:o[5]||"-",jaminan:_})}let T=c.find(I=>/nama\s*obat/i.test(I.rows[0]?.textContent||""));for(let I of Array.from(T?.rows??[])){let o=Array.from(I.cells).map(at=>(at.textContent||"").replace(/\s+/g," ").trim());if(o.length<5||!/^\d+(\.\d+)?$/.test(o[2]))continue;let b=o[1].replace(/^\d+\s*/,"").trim()||"-",Q=b.toUpperCase().replace(/\s+/g," ").trim(),H=parseFloat(o[2].replace(",","."))||0,_=parseFloat((o[5]||"0").replace(/\./g,"").replace(",","."))||0,tt=n.get(Q);tt?(tt.qty+=H,tt.jaminan+=_):n.set(Q,{name:b,qty:H,jaminan:_})}}let L=c=>{if(!a)return 0;for(let m of Array.from(a.querySelectorAll("tr"))){let T=Array.from(m.cells).map(I=>(I.textContent||"").replace(/\s+/g," ").trim());if(T.some(I=>c.test(I)))for(let I of T.slice(1)){let o=parseFloat(I.replace(/\./g,"").replace(",","."));if(Number.isFinite(o)&&o!==0)return o}}return 0},s=L(/^Total Jasa Rp/i),l=L(/^Total Resep/i),d=L(/^Jasa Pelayanan/i),x=L(/^Biaya Administrasi/i),z=L(/^Biaya Materai/i),p=L(/^Diskon/i),P=L(/^Pembulatan/i),k=L(/^Total Biaya/i),y=s+l+d,C=Math.max(0,y-k),N=c=>c.toLocaleString("id-ID",{minimumFractionDigits:0,maximumFractionDigits:0}),h=(c,m,T=!1)=>`<div class="rm-sum-line"${T?' style="font-weight:bold;border-top:1px solid #000;"':""}><span>${t(c)}</span><span class="rm-sum-dots"></span><span>${t(m)}</span></div>`,O=Array.from(e.values()).map((c,m)=>`<tr><td class="center">${m+1}</td><td>${t(c.name)}</td><td>${t(c.petugas)}</td><td class="center">${c.frek}</td><td class="num">${t(c.tarif)}</td><td class="num">${N(c.jaminan)}</td></tr>`).join(""),B=Array.from(n.values()).map((c,m)=>`<tr><td class="center">${m+1}</td><td>${t(c.name)}</td><td class="center">${c.qty}</td><td class="num">${N(c.jaminan)}</td></tr>`).join(""),R=M("norm","rekam_medis"),E=M("nama"),U=M("dokter","dpjp"),$=st(i),Y=M("no_sep","sep"),w=[M("jenis"),M("kelas","ruang")].filter(c=>c!=="-").join(" / ")||"-",S=M("tanggalAwal","tgl_masuk","tgl"),f=M("tanggalAkhir","keluar","tgl_keluar"),A=W(i,/^Rincian Biaya/i),g=A.find(c=>/pasien/i.test(decodeURIComponent(c)))??A[0]??"",v=A.find(c=>/penerima/i.test(decodeURIComponent(c)))??A[1]??"";return`<section class="rm-page" id="rm-05">
${J("RM. 05")}
<div class="rm-form-title">RINCIAN BIAYA PELAYANAN RAWAT INAP &amp; FARMASI</div>

<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${r("No. Rekam Medis",R)}
    ${r("Nama Pasien",E,!0)}
    ${r("Alamat Pasien",$)}
    ${r("Unit / Instalasi",w)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Golongan Pasien",`BPJS KESEHATAN (SEP: ${Y})`)}
    ${r("Dokter DPJP",U)}
    ${r("Periode Rawat",`${S} s/d ${f}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>URAIAN TINDAKAN / PELAYANAN</th>
    <th style="width: 155px;">DOKTER / PELAKSANA</th>
    <th class="center" style="width: 48px;">FREK</th>
    <th class="num" style="width: 88px;">TARIF (Rp)</th>
    <th class="num" style="width: 98px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${O}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>NAMA OBAT / ALKES</th>
    <th class="center" style="width: 52px;">QTY</th>
    <th class="num" style="width: 120px;">JAMINAN (Rp)</th>
  </tr></thead>
  <tbody>${B}</tbody>
</table>

<div class="rm-summary">
  ${h("Sub Total Layanan Medis / Tindakan",N(s))}
  ${h("Sub Total Penjualan (Farmasi/Obat)",N(l))}
  ${h("Jasa Pelayanan (Jasa Medis/Paramudis)",N(d))}
  ${h("Jasa Sarana","0")}
  ${h("Biaya Administrasi",N(x))}
  ${h("Biaya Materai",N(z))}
  ${h("Diskon",N(p))}
  ${h("Pembulatan",N(P))}
  ${h("TOTAL TAGIHAN (KOTOR)",N(y),!0)}
  ${h("Ditanggung Jaminan / Klaim BPJS",N(k))}
  ${h("TANGGUNGAN PASIEN (Sisa yang harus dibayar)",N(C))}
  ${h("Uang Muka / Deposit","0")}
  ${h("Bayar (Tunai/Non-Tunai)",N(C))}
  ${h("Kembali","0")}
  ${h("Status",C===0?"Lunas":"-")}
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Yang Menyerahkan,</div>
    <div>Pasien / Keluarga Pasien</div>
    ${g?`<img class="rm-sig-qr" src="${t(g)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${g?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(E)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Yang Menerima</div>
    ${v?`<img class="rm-sig-qr" src="${t(v)}" alt="QR penerima" width="80" height="80" />`:""}
    ${v?"":'<div class="rm-sig-space"></div>'}
    <div>(Petugas Billing / Kasir)</div>
  </div>
</div>
</section>`}function ea(i){let u=i.find(c=>/^Resume/i.test(c.title)),a=W(i,/^Resume/i)[0]??"",e=W(i,/^SEP/i)[0]??W(i,/^Rincian Biaya/i)[0]??"",n=u?new DOMParser().parseFromString(u.html,"text/html"):null,L=new Map;if(n)for(let c of Array.from(n.querySelectorAll("tr"))){let m=Array.from(c.cells);for(let T=0;T<m.length-2;T++){let I=(m[T].textContent||"").replace(/\s+/g," ").trim().replace(/^-\s*/,"").replace(/\s*:$/,"");if((m[T+1].textContent||"").trim()!==":")continue;let o=(m[T+2].innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim();I&&o&&!L.has(I)&&L.set(I,o)}}let s=(...c)=>{for(let[m,T]of L)if(c.some(I=>I.test(m)))return T;return"-"},l=c=>{for(let[m,T]of L)if(c.test(m))return T;return"-"},d=M("nama"),x=M("norm","rekam_medis"),z=M("tgl_lahir","tglLahir"),p=M("jenis_kelamin","jk"),P=s(/^Tanggal Masuk$/i),k=s(/^Tanggal Keluar$/i),y=s(/^Ruang Rawat$/i),C=s(/^Kelas$/i),N=M("dokter","dpjp"),h=s(/^Anemnesa|^Anamnesa/i),O=s(/^Pemeriksaan Fisik$/i),B=s(/^Hasil Pemeriksaan Diagnostik/i),R=s(/^Diagnosa Utama$/i),E=s(/^Diagnosa Sekunder$/i),U=s(/^Prosedur \/ Operasi|^Diagnosa Tindakan/i),$=s(/^Pengobatan$/i),Y=s(/^Obat Pulang$/i),w=s(/^Kondisi Pulang$/i),S=s(/^Catatan Kondisi Pulang$/i),f=s(/^Jadwal Kontrol$/i),A=s(/^Pemeriksaan Lanjutan/i),g=[["TD",l(/^TD$/)],["HR",l(/^HR$/)],["RR",l(/^RR$/)],["S",l(/^S$/)],["SpO2",l(/^SPO2$/)],["GCS",l(/^GCS$/)]].filter(([,c])=>c!=="-").map(([c,m])=>`${c}: ${m}`).join(" | "),v=(c,m)=>`<tr><td style="width: 175px;"><strong>${c}</strong></td><td>${F(m)}</td></tr>`;return`<section class="rm-page" id="rm-06">
${J("RM. 06")}
<div class="rm-form-title">RINGKASAN PULANG (DISCHARGE SUMMARY)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",d,!0)}
    ${r("No. Rekam Medis",x,!0)}
    ${r("Tgl. Lahir / Kelamin",`${z} / ${p}`)}
    ${r("Jenis Kasus",s(/^Jenis Kasus$/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Masuk",P)}
    ${r("Tanggal Keluar",k)}
    ${r("Ruang / Kelas",`${y} / ${C}`)}
    ${r("DPJP / Rawat Bersama",N)}
  </table></div>
</div>

<table class="rm-grid-table">
  <tbody>
    ${v("ALASAN / INDIKASI RAWAT &amp; ANAMNESA",`${s(/^Alasan \/ Indikasi Rawat/i)}
${h}`.trim())}
    ${v("PEMERIKSAAN FISIK &amp; TANDA VITAL MASUK",`${O}${g?`
Vital Signs : ${g}`:""}`.trim())}
    ${v("HASIL PEMERIKSAAN DIAGNOSTIK",B)}
    ${v("DIAGNOSA UTAMA",R)}
    ${v("DIAGNOSA SEKUNDER",E)}
    ${v("TINDAKAN / PROSEDUR (ICD-9-CM)",U)}
    ${v("PENGOBATAN SELAMA RAWAT",$)}
    ${v("OBAT PULANG",Y)}
    ${v("KONDISI &amp; CARA PULANG",`${w}
${S}`.trim())}
    ${v("INSTRUKSI &amp; JADWAL KONTROL",`${f}
${A}`.trim())}
    ${v("STATUS RUJUKAN &amp; PELAYANAN KB",s(/^Apakah pasien rujukan masuk/i))}
  </tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Mengetahui Pasien / Keluarga</div>
    ${e?`<img class="rm-sig-qr" src="${t(e)}" alt="QR persetujuan pasien" width="80" height="80" />`:""}
    ${e?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(d)} )</div>
  </div>
  <div class="rm-sig-box">
    <div>Yang Membuat</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan DPJP" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(N)} )</div>
  </div>
</div>
</section>`}function Ma(i){let u=i.find(T=>/^Telaah/i.test(T.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=new Map,n=[],L=[],s=[];if(a){for(let I of Array.from(a.querySelectorAll("tr"))){let o=Array.from(I.cells).map(b=>(b.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let b=0;b<o.length-2;b++){let Q=o[b].replace(/:$/,"").trim();o[b+1]===":"&&Q&&o[b+2]&&!e.has(Q)&&e.set(Q,o[b+2])}for(let b of o){let Q=b.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);Q&&!e.has(Q[1].trim())&&e.set(Q[1].trim(),Q[2].trim())}}for(let I of Array.from(a.querySelectorAll("tr"))){let o=Array.from(I.cells).map(Q=>(Q.textContent||"").replace(/\s+/g," ").trim());if(o.length<2||!/^R\/\d+$/i.test(o[0]))continue;let b=o[1].match(/^(.*?)\s*Jml:\s*(\S+)/i);n.push({no:o[0],name:b?b[1].trim():o[1],jml:b?b[2]:"-"})}for(let I of Array.from(a.querySelectorAll("table"))){let o=(I.rows[0]?.textContent||"").replace(/\s+/g," ").trim();if(!/^(Telaah Resep|Telaah Obat|Edukasi)/i.test(o))continue;let b=[];for(let Q of Array.from(I.rows).slice(1)){let H=Array.from(Q.cells).map(_=>(_.textContent||"").replace(/\s+/g," ").trim());H.length<2||!/^\d+$/.test(H[0])||b.push([H[0],H[1]])}b.length&&L.push({title:o.split(/\s{2,}/)[0]||o,rows:b})}let T=Array.from(a.querySelectorAll("table")).find(I=>/Hitung/i.test(I.rows[0]?.textContent||""));T&&s.push(...Array.from(T.rows[0].cells).map(I=>(I.textContent||"").replace(/\s+/g," ").trim()).filter(I=>/Hitung|Timbang|Kemas|Penyerahan/i.test(I)))}s.length||s.push("Hitung","Timbang","Kemas","Penyerahan");let l=(...T)=>{for(let[I,o]of e)if(T.some(b=>b.test(I)))return o;return"-"},d=T=>{for(let I of Array.from(document.querySelectorAll("td"))){let o=(I.textContent||"").replace(/\s+/g," ").trim(),b=o.match(T);if(!b)continue;let Q=o.slice((b.index??0)+b[0].length).replace(/^\s*:\s*/,"").trim();if(Q)return Q;let H=(I.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim();if(H&&!/^:/.test(H))return H}return"-"},x=M("dokter","dpjp")!=="-"?M("dokter","dpjp"):l(/^Dokter/i),z=l(/^No Resep/i),p=d(/^Ruangan\/Poli/i)!=="-"?d(/^Ruangan\/Poli/i):l(/^Ruangan\/?Poli/i,/^Ruangan/i),P=d(/^Tanggal Periksa/i)!=="-"?d(/^Tanggal Periksa/i):l(/^Tanggal/i,/^Tanggal & Jam/i),k=d(/^Jam Datang/i)!=="-"?d(/^Jam Datang/i):l(/^Jam/i),y=l(/^SIP/i),C=M("nama")!=="-"?M("nama"):l(/^Nama Pasien/i),N=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):l(/^No\.? RM/i),h=st(i),O=M("tgl_lahir","tglLahir").replace(/^:\s*/,"")||l(/^Tgl\.? Lahir/i),B=M("no_hp","telepon").replace(/^:\s*/,"")||l(/^No HP/i),R=l(/^Penjamin/i),E=l(/alergi/i),U=l(/berat|\bbb\b/i),$=M("jenis_kelamin","jk").replace(/^:\s*/,""),Y=/perempuan|^p$/i.test($)?"P":/laki|^l$/i.test($)?"L":$,w=C+(Y&&Y!=="-"?` (${Y})`:""),S=`${E!=="-"?E:"-"} / ${U!=="-"?`BB ${U}${/\bkg\b/i.test(U)?"":" kg"}`:"- kg"}`,f=M("no_sep","sep")!=="-"?M("no_sep","sep"):M("kartu"),A='<table class="rm-grid-table"><thead><tr>'+s.map(T=>`<th class="center">${t(T)}</th>`).join("")+"</tr></thead><tbody><tr>"+s.map(()=>'<td style="height:30px">&nbsp;</td>').join("")+"</tr></tbody></table>",g=L.length?L.map(T=>`<table class="rm-grid-table"><thead><tr><th colspan="2">${t(T.title)}</th><th style="width:44px;">Y/T</th></tr></thead><tbody>`+T.rows.map(([I,o])=>`<tr><td class="center" style="width:28px;">${t(I)}</td><td>${t(o)}</td><td class="center">&nbsp;</td></tr>`).join("")+"</tbody></table>").join(""):"",v='<table class="rm-grid-table"><tbody><tr><th colspan="2">PERUBAHAN RESEP</th></tr><tr><th>Tertulis</th><th>Menjadi</th></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><td class="center">Apoteker</td><td class="center">Disetujui Dokter</td></tr><tr><td style="height:28px">&nbsp;</td><td style="height:28px">&nbsp;</td></tr><tr><th colspan="2">WAKTU TUNGGU</th></tr><tr><td>Masuk</td><td>&nbsp;</td></tr><tr><td>Diserahkan</td><td>&nbsp;</td></tr><tr><td>Paraf Pasien/Keluarga</td><td style="height:30px">&nbsp;</td></tr></tbody></table>',c=(T,I,o=!1)=>`<div class="tm-row${o?" long":""}"><span class="tm-label">${t(T)}:</span><span class="tm-val">${I&&I.trim()&&I!=="-"?t(I):"-"}</span></div>`,m=n.length?n.map(T=>`<div class="med"><span class="med-no">${t(T.no)}</span> <span class="med-name">${t(T.name)}</span>`+(T.jml&&T.jml!=="-"?`, <span class="med-jml">Jml: ${t(T.jml)}</span>`:"")+"</div>").join(""):'<div class="med">Tidak ada data obat pada halaman telaah.</div>';return`<section class="rm-page" id="rm-07">
${J("RM. 07")}
<div class="rm-form-title">FORMULIR TELAAH RESEP, TELAAH OBAT &amp; EDUKASI FARMASI</div>

<div class="t-main">
  <div class="t-left">
    <div class="tm-card tm-card--small tm-card--left"><div class="tm-col">
      ${c("Pasien",w)}
      ${c("No. RM",N)}
      ${c("Tgl. Lahir",O)}
      ${c("Alergi &amp; BB",S)}
      ${c("Alamat",h,!0)}
      ${c("No HP",B)}
    </div></div>
    <div class="t-meds">${m}</div>
    ${A}
    <table class="rm-grid-table t-lampiran"><thead><tr>
      <th>Srt. Rujuk Balik</th><th>Surat Iter</th><th>Hasil Lab</th>
    </tr></thead><tbody><tr>
      <td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td><td style="height:26px">&nbsp;</td>
    </tr></tbody></table>
  </div>
  <div class="t-right">
    <div class="tm-card tm-card--right"><div class="tm-col">
      ${c("Dokter",x)}
      ${c("SIP Dokter",y)}
      ${c("No Resep",z)}
      ${c("No SEP",f)}
      ${c("Ruangan",p)}
      ${c("Tanggal",P)}
      ${c("Jam",k)}
      ${c("Penjamin",R)}
    </div></div>
    ${g}
    ${v}
  </div>
</div>

<div class="footnote-rm">Obat tidak boleh diganti tanpa sepengetahuan Dokter.</div>
</section>`}var sa=/^(No\.?\s*(RONTGEN|RM)|Umur|Tanggal Periksa|Bed|Status|Nama Pasien|Jenis Kelamin|Alamat|dr\.?\s*(Pengirim|DPJP)|Dokter (Pengirim|DPJP)|Diagnosa (Klinis|ICD))/i,La=/<div[^>]*class="[^"]*head-cetak-instansi[^"]*"[^>]*>\s*HASIL PEMERIKSAAN RADIOLOGI/i;function ua(i,u,a="rm-08"){let e=u??i.find(n=>/^Radiologi/i.test(n.title));return da(e?.html??"",La).map((n,L)=>{let s=W([{title:"Radiologi",html:n}],/Radiologi/i)[0]??"";return ra(i,n,s,L?`${a}-${L+1}`:a)}).join("")}function ra(i,u,a,e){let n=new DOMParser().parseFromString(u,"text/html"),L=Sa(n,sa),s=[],l="";for(let A of Array.from(n.querySelectorAll("tr"))){let g=Array.from(A.cells).map(dt);for(let v of g){let c=v.match(/^expertise\s*:\s*([\s\S]+)$/i);c&&!l&&(l=c[1].trim())}g.length>=4&&/^\d+$/.test(g[0])&&g[1]&&s.push({name:g[1],golongan:g[2],kontras:g[3]})}let d=(...A)=>{for(let[g,v]of L)if(A.some(c=>c.test(g)))return v;return"-"},x=d(/^No\.? RONTGEN/i),z=d(/^Tanggal Periksa/i),p=d(/^Umur/i),P=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):d(/^No\.? RM/i),k=M("nama")!=="-"?M("nama"):d(/^Nama Pasien/i),y=M("jenis_kelamin","jk").replace(/^:\s*/,"")||d(/^Jenis Kelamin/i),C=/perempuan|^p$/i.test(y)?"P":/laki|^l$/i.test(y)?"L":y,N=st(i),h=d(/^Bed|^Ruang/i),O=d(/^Status/i),B=d(/^dr\.? Pengirim|^Dokter Pengirim/i),R=d(/^dr\.? DPJP|^Dokter DPJP/i),E=(n.body.textContent||"").replace(/\s+/g," ").match(/\(\s*([^)]{3,80})\s*\)/)?.[1]?.trim()||"-",U=R!=="-"?R:E!=="-"?E:jt(a),$=d(/^Diagnosa Klinis/i),Y=d(/^Diagnosa ICD/i),w=s.length&&s[0].golongan||"-",S=s.length?s.map((A,g)=>`<tr><td class="center">${g+1}</td><td><strong>${t(A.name)}</strong></td><td class="center">${t(A.golongan||"-")}</td><td class="center">${t(A.kontras||"-")}</td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Radiologi ${g+1}"></td></tr>`).join(""):'<tr><td class="center">-</td><td>Tidak ada jenis pemeriksaan tercatat.</td><td class="center">-</td><td class="center">-</td><td class="center">-</td></tr>',f=l?l.replace(/^\s*\d+\.\s*/,"").replace(/^\n+|\n+$/g,"").split(`
`).map(A=>A.trim()).map(A=>A?`<div>${t(A)}</div>`:"<div>&nbsp;</div>").join(""):"<div>Tidak ada expertise tercatat pada halaman.</div>";return`<section class="rm-page" id="${t(e)}">
${J("RM. 08")}
<div class="rm-form-title">HASIL PEMERIKSAAN RADIOLOGI</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("No. Rontgen",x,!0)}
    ${r("Tanggal Periksa",z)}
    ${r("No. Rekam Medis",P)}
    ${r("Nama Pasien",k,!0)}
    ${r("Jenis Kelamin",C!=="-"?`Laki-laki / Perempuan (${C})`:"-")}
    ${r("Alamat",N)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Umur / Tgl. Lahir",p)}
    ${r("Ruang / Asal",h!=="-"&&O!=="-"?`${h} (Status: ${O})`:h)}
    ${r("Dokter Pengirim",B)}
    ${r("Dokter DPJP / Penilai",U)}
    ${r("Diagnosa Klinis",$)}
    ${r("Diagnosa ICD",Y)}
    ${r("Status Pasien",O)}
    ${r("Golongan / Jenis",`${w} \u2014 ${s[0]?.kontras||"-"}`)}
  </table></div>
</div>

<table class="rm-grid-table">
  <thead><tr>
    <th style="width: 32px;">NO</th>
    <th>JENIS PEMERIKSAAN</th>
    <th style="width: 110px;">GOLONGAN</th>
    <th style="width: 110px;">KONTRAS</th>
    <th class="center" style="width: 56px;">VER (&#10003;)</th>
  </tr></thead>
  <tbody>${S}</tbody>
</table>

<table class="rm-grid-table">
  <thead><tr><th>URAIAN EXPERTISE &amp; KESAN PEMERIKSAAN</th></tr></thead>
  <tbody><tr><td style="padding: 8px 10px; line-height: 1.5;">${f}</td></tr></tbody>
</table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>No. Rontgen : ${t(x)}</div>
    <div>Jenis Pemeriksaan : ${t(w)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter Penilai</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan radiolog" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(U)} )</div>
  </div>
</div>
</section>`}var na=i=>{for(let u of i){if(!/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(u.title))continue;let a=new DOMParser().parseFromString(u.html,"text/html");for(let e of Array.from(a.querySelectorAll("table"))){let n=Array.from(e.rows[0]?.cells||[]).map(L=>dt(L)).join(" ");if(/^Triase/i.test(n))return Array.from(e.rows).slice(1).map(L=>Array.from(L.cells).map(dt))}}return[]};function la(i){let u=i.find(S=>/^Triage/i.test(S.title)),a=W(i,/^Triage/i)[0]??"",e=u?new DOMParser().parseFromString(u.html,"text/html"):null,n=new Map,L="-";if(e){for(let f of Array.from(e.querySelectorAll("tr"))){let A=Array.from(f.cells).map(g=>(g.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let g=0;g<A.length-2;g++){let v=A[g].replace(/:$/,"").trim();A[g+1]===":"&&v&&A[g+2]&&!n.has(v)&&n.set(v,A[g+2])}for(let g of A){let v=g.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);!v||v[2].includes(":")||v[2].length>120||n.has(v[1].trim())||n.set(v[1].trim(),v[2].trim())}}let S=(e.textContent||"").replace(/\s+/g," ").match(/Dokter yang memeriksa\s*\(([^)]+)\)/i);S&&(L=S[1].trim())}let s=(...S)=>{for(let[f,A]of n)if(S.some(g=>g.test(f)))return A;return"-"},l=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):s(/^No\.?\s*RM/i),d=M("nama")!=="-"?M("nama"):s(/^Nama$/i),x=s(/^Tanggal$/i),z=s(/^Jam Datang/i),p=s(/^Jam Registrasi/i),P=s(/^Cara Datang/i),k=s(/^Diantar Polisi/i),y=s(/^No\.?\s*ID/i),C=s(/^Pengantar Pasien/i),N=s(/^Riwayat Penyakit Dahulu/i),h=s(/^Keluhan Utama/i),O=s(/^Keadaan Umum/i),B=s(/^Suhu/i),R=s(/^Nadi/i),E=s(/^RR$/i),U=s(/^Tekanan Darah/i),$=s(/^Jam$/i),Y=s(/^No\.?\s*Antrian/i),w=s(/^Status/i);return`<section class="rm-page" id="triage">
${J("TRIAGE")}
<div class="rm-form-title">TRIAGE TERINTEGRASI &amp; PENGKAJIAN AWAL IGD</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("No. Rekam Medis",l,!0)}
    ${r("Nama Pasien",d,!0)}
    ${r("Tanggal",x)}
    ${r("Jam Datang",z)}
    ${r("Jam Registrasi",p)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Cara Datang",P)}
    ${r("Diantar Polisi",k)}
    ${r("No. ID",y)}
    ${r("Pengantar Pasien",C)}
    ${r("Status Triage",w,!0)}
  </table></div>
</div>

<div class="sub-heading-rm">ANAMNESA &amp; RIWAYAT</div>
<table class="rm-grid-table"><tbody>
  ${r("Riwayat Penyakit Dahulu",N)}
  ${r("Keluhan Utama",h)}
</tbody></table>

<div class="sub-heading-rm">TANDA VITAL &amp; PEMERIKSAAN</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${r("Keadaan Umum",O)}
    ${r("Suhu (\xB0C)",B)}
    ${r("Nadi (x/menit)",R)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("RR (x/menit)",E)}
    ${r("Tekanan Darah (mmHg)",U)}
    ${r("Jam",$)}
    ${r("No. Antrian",Y)}
  </table></div>
</div>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Status Triage : ${t(w)}</div>
    <div>No. Antrian : ${t(Y)}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter yang Memeriksa</div>
    ${a?`<img class="rm-sig-qr" src="${t(a)}" alt="QR tanda tangan dokter" width="80" height="80" />`:""}
    ${a?"":'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(L!=="-"?L:jt(a))} )</div>
  </div>
</div>
</section>`}function ja(i){let u=i.find(j=>/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(j.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=a?Array.from(a.querySelectorAll("table")):[],n=j=>(j.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim(),L=j=>j?Array.from(j.rows).map(D=>Array.from(D.cells).map(n)):[],s=j=>{let D=e.find(K=>j.test((K.rows[0]?.textContent||"").replace(/\s+/g," ").trim()));return L(D)},l=j=>{let D=e.find(K=>j.test(K.textContent||""));return L(D)},d=e.find(j=>/^Usia$/i.test((j.rows[1]?.cells[1]?.textContent||"").trim())),x=e.find(j=>/^Riwayat Jatuh$/i.test((j.rows[1]?.cells[1]?.textContent||"").trim())),z=j=>j.reduce((D,K)=>{let X=m(K),q=X==="-"?0:Number(X);return D+(Number.isFinite(q)?q:0)},0),p=(j,D)=>D?j>=45?"TINGGI":j>=25?"SEDANG":"RENDAH":j>=12?"TINGGI":j>=6?"SEDANG":"RENDAH",P=(j,D)=>{let K=z(j);return`${K} \u2014 ${p(K,D)}`},k=j=>j?Array.from(j.rows).map((D,K)=>{let X=Array.from(D.cells).map(q=>{let lt=dt(q),gt=q.rowSpan>1?` rowspan="${q.rowSpan}"`:"",Oa=q.colSpan>1?` colspan="${q.colSpan}"`:"",$a=/JUMLAH SKOR|Keterangan Hasil|Catatan/i.test(lt),Pa=lt.includes("\u2713"),vt=K===0?"th":"td";return`<${vt}${gt}${Oa}${$a?' style="font-weight:bold;text-align:right;"':""}>${Pa?`<strong>${t(lt)}</strong>`:t(lt||"-")}</${vt}>`}).join("");return`<tr${K===0?' class="sec-hdr"':""}>${X}</tr>`}).join(""):'<tr><td colspan="5">-</td></tr>',y=s(/^Triase/i),C=s(/^Pengkajian\s*0\s*1\s*2\s*Nilai/i),N=l(/MORSE FALL SCALE/i),h=s(/^Objektif\s*Kelainan/i),O=s(/^Diagnosa Utama$/i),B=s(/^Diagnosa Banding$/i),R=s(/^Tindakan$/i),E=s(/^Pukul\s*Nama Obat/i),U=s(/^No\s*Nama Perawat IGD/i),$=(j,D)=>{let K=Array.isArray(D)?D.join(""):D;return'<table class="rm-grid-table"><thead><tr>'+j.map(X=>`<th>${t(X)}</th>`).join("")+"</tr></thead><tbody>"+(K||'<tr><td colspan="'+j.length+'">-</td></tr>')+"</tbody></table>"},Y=C.slice(1).map(j=>{if(j.some(D=>/^TOTAL$/i.test((D||"").trim()))){let D=j[j.length-1]||"-";return`<tr style="font-weight:bold;"><td colspan="4" style="text-align:right;"><strong>TOTAL</strong></td><td class="center"><strong>${t(D)}</strong></td></tr>`}return"<tr>"+j.map((D,K)=>`<td${K===0?"":' class="center"'}>${t(D||"-")}</td>`).join("")+"</tr>"}).join(""),w=h.slice(1).map(j=>`<tr><td>${t(j[0]||"-")}</td><td>${t(j.slice(1).filter(Boolean).join(" ")||"-")}</td></tr>`).join(""),S=[["DIAGNOSA UTAMA",O.slice(1).flat().filter(Boolean).join(" ")||"-"],["DIAGNOSA BANDING",B.slice(1).flat().filter(Boolean).join(" ")||"-"]].map(([j,D])=>`<tr><td style="width:180px;"><strong>${j}</strong></td><td>${t(D)}</td></tr>`).join(""),f=R.slice(1).flat().filter(Boolean).join(" ")||"-",A=E.slice(1).filter(j=>j.some(Boolean)).map(j=>"<tr>"+j.slice(0,4).map(D=>`<td>${t(D||"-")}</td>`).join("")+"</tr>").join(""),g=U.slice(1).flat().filter(Boolean).join(" \xB7 "),v=na(i).find(j=>(j[0]||"").includes("\u2713"))?.slice(1)||[],c=j=>{let D=j.find(q=>/^JUMLAH SKOR/i.test(q[0]||"")),K=j.find(q=>/^Keterangan Hasil/i.test(q[0]||"")),X=D?.slice(1).filter(Boolean).join(" ")||"-";return K?`${X} \xB7 ${K.slice(1).filter(Boolean).join(" ")}`:X},m=j=>document.querySelector(`input[name="${j}"]:checked`)?.value||"-",T=j=>(Array.from(a?.querySelectorAll("label")||[]).find(D=>j.test((D.textContent||"").replace(/\s+/g," ").trim()))?.nextElementSibling?.textContent||"").replace(/\s+/g," ").trim()||"-",I=(Array.from(a?.querySelectorAll("div")||[]).find(j=>/^Planning\s*:\s*Terapy/i.test((j.textContent||"").trim().slice(0,80)))?.nextElementSibling?.textContent||"").split(/TINDAK LANJUT/i)[0].split(/Kondisi Pasien Saat Pindah/i)[0].replace(/[ \t]+/g," ").trim()||"-",o=M("pengkajian_keperawatan"),[b,Q,H]=(()=>{let j=o.split(/\n\s*RPD\s*:/i),D=j[0].replace(/^\s*Subjektif\s*:\s*/i,"").trim()||"-",K=(j[1]||"").split(/\n\s*RPO\s*:/i);return[D,K[0]?.trim()||"-",K[1]?.trim()||"-"]})(),_=(j,D)=>m(j)==="ya"?M(D):m(j)==="tidak"?"Tidak":"-",tt=j=>{let D=Array.from(document.querySelectorAll(`input[name="${j}"]:checked`)).map(K=>K.value).filter(Boolean);return D.length?D.join(", "):"-"},at=j=>({tanpa_bantuan:"Jalan Tanpa Bantuan",kursi_roda:"Kursi Roda",tempat_tidur:"Brankar",dengan_bantuan:"Dengan Bantuan",tidak_ada:"Tidak mengalami cedera",lantas:"KLL",lainnya:"Lainnya",tidak:"Tidak Terganggu",ya:"Ada Gangguan",Bpjs:"BPJS Kesehatan"})[j]||j||"-",rt=(j,D)=>`<tr><td style="width:175px;"><strong>${j}</strong></td><td>${D}</td></tr>`,At=(j,D)=>`<tr><td class="lbl">${j}</td><td class="col">:</td><td class="val">${D}</td></tr>`,ct=Number(M("nutrisi_bb")),G=Number(M("nutrisi_tb"))/100,Mt=ct>0&&G>0?(ct/(G*G)).toFixed(1).replace(".",","):"-";return`<section class="rm-page" id="pengkajian-igd">
${J("PENGKAJIAN IGD")}
<div class="rm-form-title">LEMBAR PENGKAJIAN INSTALASI GAWAT DARURAT</div>

<div class="igd-masthead">
  <div class="igd-masthead-label">Pasien \xB7 Instalasi Gawat Darurat</div>
  <div class="igd-masthead-name">${t(M("nama"))}</div>
</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${r("Tgl. Lahir / Umur",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?"Perempuan (P)":"Laki-laki (L)")}
    ${r("Agama / Suku",`${T(/^Agama/i)} / ${T(/^Suku/i)}`)}
    ${r("Pekerjaan",M("pekerjaan"))}
    ${r("No. Telp / HP",M("no_hp","telepon"))}
    ${r("Nama Orangtua / Pasangan",`${M("nama_orangtua")} / ${M("nama_pasangan")}`)}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Masuk",M("tgl_masuk"))}
    ${r("Tiba di IGD / Diperiksa",`Pukul ${M("pukul_tiba_di_rs")} / Diperiksa Pukul ${M("pukul_diperiksa")}`)}
    ${r("Prosedur Masuk",at(m("kaji[prosedur_masuk]")))}
    ${r("Cara Masuk",at(m("kaji[cara_masuk]")))}
    ${r("Penyebab Cedera",at(m("kaji[penyebab_cedera]")))}
    ${r("Status Alergi",_("kaji[status_alergi]","status_alergi_text"))}
    ${r("Gangguan Perilaku",at(m("kaji[gangguan_perilaku]")))}
    ${At("Status Kehamilan",/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?t(M("status_kehamilan")):'<span class="filter-note">Tidak berlaku (Pasien Laki-laki \u2014 disaring otomatis)</span>')}
  </table></div>
</div>

<div class="igd-summary">
  <div><span>Triase</span><b>${t(v[0]||"-")} ${t(v[1]||"")}</b></div>
  <div><span>GCS / Kesadaran</span><b>${t(M("vital_gcs"))} \xB7 ${t(M("vital_kesadaran"))}</b></div>
  <div><span>SpO2 / Nadi</span><b>${t(M("vital_spo"))} \xB7 ${t(M("vital_nadi"))}</b></div>
  <div><span>Risiko Jatuh (Morse)</span><b>${t(c(N))}</b></div>
</div>

<div class="sub-heading-rm">KONDISI AWAL &amp; RIWAYAT</div>
<div class="id-box-borderless">
  <div class="id-col"><table class="id-table">
    ${r("Prosedur Masuk",m("kaji[prosedur_masuk]"))}
    ${r("Cara Masuk",m("kaji[cara_masuk]"))}
    ${r("Status Alergi",_("kaji[status_alergi]","status_alergi_text"))}
    ${r("Status Psikologi",m("kaji[status_psikologi]"))}
    ${r("Status Sosial",m("kaji[status_sosial]"))}
    ${r("Status Ekonomi",m("kaji[status_ekonomi]"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Nutrisi (BB/TB)",`${M("nutrisi_bb")} kg / ${M("nutrisi_tb")} cm`)}
    ${r("Kognitif",m("kaji[fungsi_kognitif]"))}
    ${r("Motorik",m("kaji[fungsi_motorik]"))}
    ${r("Hambatan Pembelajaran",_("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text"))}
    ${r("Kebutuhan Edukasi",m("kaji[kebutuhan_edukasi]"))}
    ${r("Penerjemah",_("kaji[dibutuhkan_penerjemah]","penerjemah_text"))}
  </table></div>
</div>

<div class="sub-heading-rm">TANDA VITAL SAAT MASUK</div>
${$(["TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","GCS (E/V/M)","KESADARAN"],["<tr>"+[wt(M("vital_td")),M("vital_nadi"),M("vital_nafas"),M("vital_suhu"),M("vital_spo"),M("vital_gcs")].map(j=>`<td class="center">${t(j)}</td>`).join("")+`<td class="center">${t([M("vital_e"),M("vital_m"),M("vital_v")].join("/"))}</td><td class="center">${t(M("vital_kesadaran"))}</td></tr>`])}

<div class="sub-heading-rm">KONDISI SAAT PINDAH / PULANG DARI IGD</div>
${$(["PUKUL","TEKANAN DARAH","NADI","PERNAPASAN","SUHU","SpO2","GCS","KESADARAN"],["<tr>"+[M("waktu_pasien_pulang"),wt(M("kondisi_pasien_td")),M("kondisi_pasien_nadi"),M("kondisi_pasien_nafas"),M("kondisi_pasien_suhu"),M("kondisi_pasien_spo"),M("kondisi_pasien_gcs"),M("kondisi_pasien_kesadaran")].map(j=>`<td class="center">${t(j)}</td>`).join("")+"</tr>"])}

<div class="sub-heading-rm">TRIASE (DIISI OLEH DOKTER)</div>
<table class="rm-table">
  <thead>
    <tr><th style="width:34px;">PILIH</th><th style="width:95px;">SKALA TRIASE</th><th>KATEGORI &amp; KETERANGAN KLINIS</th><th style="width:105px;">RESPON TIME</th></tr>
  </thead>
  <tbody>${y.slice(1).map(j=>{let D=(j[0]||"").includes("\u2713"),K=j.length>=4?j.slice(1,4):j.slice(0,3);return`<tr${D?' style="font-weight:bold;"':""}><td class="center"><span class="chk-box">${D?"&#10003;":"&nbsp;"}</span></td>${K.map(X=>`<td>${t(X||"-")}</td>`).join("")}</tr>`}).join("")}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">II. PENGKAJIAN PSIKOSOSIAL, SPIRITUAL, EKONOMI, NUTRISI &amp; FUNGSIONAL</td></tr></thead>
  <tbody>
    ${rt("Status Psikologi",m("kaji[status_psikologi]")||"-")}
    ${rt("Status Sosial &amp; Spiritual",`Hubungan keluarga: ${m("kaji[status_sosial]")||"-"} | Kegiatan keagamaan: ${t(M("status_spiritual"))}`)}
    ${rt("Status Pembiayaan",at(m("kaji[status_ekonomi]")))}
    ${rt("Antropometri &amp; Nutrisi",`BB: <strong>${t(M("nutrisi_bb"))} Kg</strong> | TB: <strong>${t(M("nutrisi_tb"))} Cm</strong> | IMT: <strong>${Mt} kg/m&sup2;</strong> | Konsul Gizi: ${m("kaji[nutrisi_konsul]")||"-"}`)}
    ${rt("Status Fungsional",`Kognitif: ${m("kaji[fungsi_kognitif]")||"-"} | Motorik: ${m("kaji[fungsi_motorik]")||"-"}`)}
    ${rt("Komunikasi &amp; Edukasi",`Hambatan: ${_("kaji[hambatan_pembelajaran]","terhambat_pembelajaran_text")} | Penerjemah: ${_("kaji[dibutuhkan_penerjemah]","penerjemah_text")} | Kebutuhan Edukasi: ${tt("kaji[kebutuhan_edukasi]")}`)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">III. ASESMEN NYERI \u2014 WONG BAKER / NRS (PQRST)</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;"><strong>Skala Wong Baker</strong></td>
      <td><span class="filter-note">Skala nyeri Wong Baker (0\u20135) \u2014 lihat halaman asal; di dossier ini tidak ditampilkan sebagai gambar.</span></td>
    </tr>
    <tr><td><strong>(P) Faktor Pencetus</strong></td><td>${t(M("faktor_pencetus"))}</td></tr>
    <tr><td><strong>(Q) Kualitas Nyeri</strong></td><td>${m("kaji[qualitas]")||"-"}</td></tr>
    <tr><td><strong>(R) Lokasi &amp; Penjalaran</strong></td><td>${t(M("lokasi_nyeri"))} &nbsp;|&nbsp; <strong>Menjalar:</strong> ${m("kaji[nyeri_menjalar]")||"-"}</td></tr>
    <tr><td><strong>(S) Skala Nyeri (NRS 0\u201310)</strong></td><td>${t(M("skala_nyeri"))} &nbsp;|&nbsp; Wong Baker: ${t(M("emo_wong"))}</td></tr>
    <tr><td><strong>(T) Waktu &amp; Frekuensi</strong></td><td>${t(M("lamanya_nyeri"))} &nbsp;|&nbsp; ${m("kaji[nyeri_frekwensi]")||"-"}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="5">IV. PENGKAJIAN NYERI (FLACC)</td></tr>
    <tr><th>PENGKAJIAN</th><th>0</th><th>1</th><th>2</th><th>NILAI</th></tr>
  </thead>
  <tbody>${Y||'<tr><td colspan="5">-</td></tr>'}</tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">V. ASESMEN AWAL RESIKO JATUH PADA ANAK (HUMPTY DUMPTY)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${P(["kaji[arja_usia]","kaji[arja_jenis_kelamin]","kaji[arja_diagnosis]","kaji[arja_gangguan_kognitif]","kaji[arja_faktor_lingkungan]","kaji[arja_respon_pembedahan]","kaji[arja_medikamentosa]"],!1)}</strong></td>
    </tr>
    ${k(d)}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="5">VI. ASESMEN AWAL RESIKO JATUH PADA DEWASA (MORSE FALL SCALE)</td></tr></thead>
  <tbody>
    <tr>
      <td colspan="2"><strong>SKOR TERPILIH</strong></td>
      <td colspan="3"><strong>${P(["kaji[arja_dewasa_jatuh]","kaji[arja_dewasa_diagnosa]","kaji[arja_dewasa_alat]","kaji[arja_dewasa_infus]","kaji[arja_dewasa_carajalan]","kaji[arja_dewasa_mental]"],!0)}</strong></td>
    </tr>
    ${k(x)}
  </tbody>
</table>

<div class="two-col-grid">
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0; height: 100%;">
      <thead>
        <tr class="sec-hdr"><td colspan="3">VI-A. PERBANDINGAN TANDA VITAL (OBJEKTIF)</td></tr>
        <tr><th>PARAMETER</th><th style="width: 108px;">AWAL IGD</th><th style="width: 108px;">PINDAH HCU</th></tr>
      </thead>
      <tbody>
        ${[["Tekanan Darah (TD)",M("vital_td"),M("kondisi_pasien_td")],["Nadi (HR)",M("vital_nadi"),M("kondisi_pasien_nadi")],["Pernapasan (RR)",M("vital_nafas"),M("kondisi_pasien_nafas")],["Suhu Aksila",M("vital_suhu"),M("kondisi_pasien_suhu")],["Saturasi Oksigen (SpO2)",M("vital_spo"),M("kondisi_pasien_spo")],["Kesadaran",M("vital_kesadaran"),M("kondisi_pasien_kesadaran")],["Skor GCS",M("vital_gcs"),M("kondisi_pasien_gcs")]].map(([j,D,K])=>`<tr><td><strong>${t(j)}</strong></td><td class="center">${t(D)}</td><td class="center">${t(K)}</td></tr>`).join("")}
      </tbody>
    </table>
  </div>
  <div class="col-half">
    <table class="rm-table" style="margin-bottom: 0;">
      <thead>
        <tr class="sec-hdr"><td colspan="2">VI-B. PEMERIKSAAN FISIK LOKALIS &amp; PENUNJANG</td></tr>
        <tr><th>OBJEKTIF</th><th>KELAINAN</th></tr>
      </thead>
      <tbody>${w}</tbody>
    </table>
  </div>
</div>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">V. PENGKAJIAN MEDIS DOKTER IGD \u2014 ANAMNESIS (SUBJEKTIF)</td></tr></thead>
  <tbody>
    <tr><td style="width:155px;"><strong>(a) Keluhan Utama &amp; RPS</strong></td><td>${F(b)}</td></tr>
    <tr><td><strong>(b) Riwayat Penyakit Dahulu (RPD)</strong></td><td>${F(Q)}</td></tr>
    <tr><td><strong>(c) Riwayat Penggunaan Obat (RPO)</strong></td><td>${F(H)}</td></tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">VI. DIAGNOSA &amp; TINDAKAN & PLANNING TERINTEGRASI</td></tr></thead>
  <tbody>
    ${S}
    <tr><td style="width:165px;"><strong>TINDAKAN</strong></td><td>${t(f)}</td></tr>
    <tr>
      <td><strong>PEMERIKSAAN PENUNJANG</strong></td>
      <td>EKG: ${t(T(/^EKG$/i))} &nbsp;|&nbsp; Radiologi: ${t(T(/^Radiologi$/i))} &nbsp;|&nbsp; Laboratorium: ${t(T(/^Laboratorium$/i))}</td>
    </tr>
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">IX. PENGKAJIAN KEPERAWATAN &amp; MEDIS</td></tr></thead>
  <tbody><tr><td style="width:165px;"><strong>PENGKAJIAN KEPERAWATAN</strong></td><td>${F(M("pengkajian_keperawatan"))}</td></tr></tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">X. PLANNING / TERAPI TERINTEGRASI</td></tr></thead>
  <tbody>
    <tr>
      <td style="width:165px;vertical-align:top;"><strong>Tatalaksana Awal (A)</strong></td>
      <td>${F(I.split(/Konsul dr\./i)[0].trim()||"-")}</td>
    </tr>
    ${I.split(/(?=Konsul dr\.)/i).slice(1).map((j,D)=>{let K=j.match(/^Konsul (dr\.?[^:\n]+)/i)?.[1]?.trim()||"-",X=j.match(/Plan\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",q=j.match(/Terapi\s*:\s*([\s\S]*?)(?=Konsul dr\.|$)/i)?.[1]?.trim()||"-",lt=j.match(/Dx\s*:\s*([\s\S]*?)(?=Masalah\s*:|Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-",gt=j.match(/Masalah\s*:\s*([\s\S]*?)(?=Terapi\s*:|Konsul dr\.|$)/i)?.[1]?.trim()||"-";return`<tr>
          <td style="width:165px;vertical-align:top;"><strong>Advis ( ${String.fromCharCode(66+D)} ) \u2014 ${t(K)}</strong></td>
          <td>
            ${lt!=="-"?`<strong>Dx:</strong> ${F(lt)}<br/>`:""}
            ${gt!=="-"?`<strong>Masalah:</strong> ${F(gt)}<br/>`:""}
            ${X!=="-"?`<strong>Visite Plan:</strong> ${F(X)}<br/>`:""}
            ${q!=="-"?`<strong>Terapi:</strong> ${F(q)}`:""}
          </td>
        </tr>`}).join("")}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="2">XI. DISPOSISI TINDAK LANJUT</td></tr></thead>
  <tbody>
    <tr><td style="width:165px;"><strong>Tindak Lanjut</strong></td><td>${m("medis[tindak_lanjut]")||"-"}</td></tr>
    <tr><td><strong>Ruangan Rawat Inap</strong></td><td>${t(M("tindak_lanjut_ruangan_ranap"))} \u2014 Indikasi: ${t(M("tindak_lanjut_indikasi_ranap"))}</td></tr>
    <tr><td><strong>Pukul Pindah / Pulang</strong></td><td>${t(M("waktu_pasien_pulang"))}</td></tr>
    <tr><td><strong>Kondisi Pasien Saat Pindah</strong></td><td>TD ${t(wt(M("kondisi_pasien_td")))} | Nadi ${t(M("kondisi_pasien_nadi"))} | RR ${t(M("kondisi_pasien_nafas"))} | Suhu ${t(M("kondisi_pasien_suhu"))} | SpO2 ${t(M("kondisi_pasien_spo"))} | GCS ${t(M("kondisi_pasien_gcs"))} | Kesadaran ${t(M("kondisi_pasien_kesadaran"))}</td></tr>
  </tbody>
</table>

<div class="sub-heading-rm">OBAT / TERAPI IGD</div>
${$(["PUKUL","NAMA OBAT","DOSIS / RUTE","TANDA TANGAN"],A)}

<div class="sub-heading-rm">PERAWAT IGD</div>
<table class="rm-grid-table"><tbody><tr><td>${t(g||"-")}</td></tr></tbody></table>

<div class="rm-signature-block">
  <div class="rm-sig-box left-align">
    <div>Ruangan : ${t(M("tindak_lanjut_ruangan_ranap"))}</div>
    <div>Perawat Ruangan : ${t(M("perawat_ruangan"))}</div>
  </div>
  <div class="rm-sig-box">
    <div>Dokter IGD</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( ${t(M("dokter_igd","dokter"))} )</div>
  </div>
</div>
</section>`}function oa(i,u){let a=[/^Telaah/i,/^SBPK/i,/^Radiologi/i],e=L=>{let s=a.findIndex(l=>l.test(L));return s<0?99:s},n=[...i].sort((L,s)=>e(L.title)-e(s.title));for(let L of n){let s=new DOMParser().parseFromString(L.html,"text/html");for(let l of Array.from(s.querySelectorAll("tr"))){let d=Array.from(l.cells).map(x=>(x.textContent||"").replace(/\s+/g," ").trim());for(let x=0;x<d.length-2;x++)if(u.test(d[x])&&d[x+1]===":"&&d[x+2])return d[x+2];for(let x of d){let z=x.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);if(z&&u.test(z[1].trim())&&z[2]&&!z[2].includes(":")&&z[2].length<=160)return z[2].trim()}}}return"-"}var st=i=>nt("alamat").replace(/^\s*:\s*/,"").trim()||oa(i,/^Alamat/i),W=(i,u)=>{let a=i.find(n=>u.test(n.title));if(!a)return[];let e=new DOMParser().parseFromString(a.html,"text/html");return Array.from(e.querySelectorAll("img")).map(n=>n.getAttribute("src")||"").filter(n=>/qr|barcode/i.test(n))},jt=i=>{if(!i)return"-";try{let u=decodeURIComponent(i.replace(/\+/g," "));return(u.match(/approve\s*([\s\S]*?)\s+tgl\b/i)?.[1]||u.match(/(dr\.[^&]+)/i)?.[1]||"").split(/\s+(?:tgl|jam)\b/i)[0].replace(/\s+/g," ").trim()||"-"}catch{return"-"}},wt=i=>/\d/.test(i)?i:"-";function V(i,u){let a=i.find(L=>u.test(L.title)),e=a?new DOMParser().parseFromString(a.html,"text/html"):null,n=new Map;if(!e)return n;for(let L of Array.from(e.querySelectorAll("tr"))){let s=Array.from(L.cells).map(l=>(l.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim());for(let l=0;l<s.length-2;l++){let d=s[l].replace(/^[-:\s]+|[\s:]+$/g,"");!d||s[l+1]!==":"||!s[l+2]||n.has(d)||n.set(d,s[l+2])}for(let l of s){let d=l.match(/^([^:]{2,40}?)\s*:\s*(.+)$/);d&&!d[2].includes(":")&&d[2].length<=120&&!n.has(d[1].trim())&&n.set(d[1].trim(),d[2].trim())}}return n}var ot=i=>i.replace(/&gt;/gi,">").replace(/&lt;/gi,"<").replace(/&quot;/gi,'"').replace(/&#39;/g,"'").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&nbsp;/gi," ");function dt(i){return ot((i.innerHTML||"").replace(/<!--[\s\S]*?-->/g,"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim())}function da(i,u){let a=new RegExp(u.source,u.flags.includes("g")?u.flags:u.flags+"g"),e=Array.from(i.matchAll(a)).map(n=>n.index??0);return e.length<2?[i]:e.map((n,L)=>i.slice(n,L+1<e.length?e[L+1]:i.length))}function Sa(i,u){let a=new Map;for(let e of Array.from(i.querySelectorAll("tr"))){let n=Array.from(e.cells).map(dt);for(let L=0;L<n.length-1;L++){let s=n[L].replace(/^[-:\s]+|[\s:]+$/g,"").trim();if(!u.test(s)||a.has(s))continue;let l=n[L+1].replace(/^:\s*/,"").trim();l&&a.set(s,l)}}return a}var Z=(i,...u)=>{for(let[a,e]of i)if(u.some(n=>n.test(a)))return ot(e);return"-"};function Lt(i,u,a=30){let e=i.find(s=>u.test(s.title)),n=e?new DOMParser().parseFromString(e.html,"text/html"):null;if(!n)return[];let L=[];for(let s of Array.from(n.querySelectorAll("tr"))){let l=Array.from(s.cells).map(d=>(d.textContent||"").replace(/\s+/g," ").trim());if(l.length&&l.some(Boolean)&&L.push(l),L.length>=a)break}return L}var it=i=>'<table class="rm-grid-table"><tbody>'+i.map(([u,a])=>`<tr><td style="width:175px;"><strong>${u}</strong></td><td>${F(a)}</td></tr>`).join("")+"</tbody></table>",ut=(i,u,a=!1)=>{let e=a?[...i,"VER (&#10003;)"]:i;return'<table class="rm-grid-table"><thead><tr>'+e.map(n=>`<th>${n}</th>`).join("")+"</tr></thead><tbody>"+(u.length?u.map(n=>"<tr>"+e.map((L,s)=>a&&s===e.length-1?'<td class="center"><input type="checkbox" class="rm-checkbox"></td>':`<td>${F(n[s]||"-")}</td>`).join("")+"</tr>").join(""):`<tr><td colspan="${e.length}">-</td></tr>`)+"</tbody></table>"},et=(i,u)=>'<div class="rm-signature-block">'+[i,u].map((a,e)=>`<div class="rm-sig-box${e?"":" left-align"}">`+a.slice(0,-1).map(n=>`<div>${n}</div>`).join("")+`<div class="rm-sig-space"></div><div class="rm-sig-name">${a[a.length-1]}</div></div>`).join("")+"</div>";function Aa(i){let u=i.find(o=>/^Persetujuan Tindakan/i.test(o.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=a?Array.from(a.querySelectorAll("table")):[],n=o=>ot((o.innerHTML||"").replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/gi," ").replace(/[ \t]+/g," ").trim()),L=o=>o?Array.from(o.rows).map(b=>Array.from(b.cells).map(n)):[],s=o=>o?.querySelector('img[src*="qrserver"], img[src*="qr-code"]')?.getAttribute("src")||"",l=o=>o.replace(/-->\s*/g,"").replace(/\btsb\b/gi,"tersebut").replace(/pembiuasan/gi,"pembiusan").replace(/\bizi Tuhan\b/gi,"izin Tuhan").replace(/\bresiko\b/gi,"risiko").replace(/\bAm\.?kep\b/gi,"A.Md.Kep").replace(/\s+/g," ").trim(),d=e.find(o=>/PEMBERIAN INFORMASI/i.test(o.rows[0]?.textContent||"")),x=e.find(o=>/JENIS INFORMASI/i.test(o.rows[0]?.textContent||"")),z=e.find(o=>/Dengan ini menyatakan bahwa saya dokter/i.test(o.rows[0]?.textContent||"")),p=e.find(o=>/PERSETUJUAN TINDAKAN KEDOKTERAN/i.test(o.rows[0]?.textContent||"")),P=L(d).slice(1).map(o=>[o[0]||"-",l((o[1]||o[2]||"-").replace(/^:\s*/,""))]).filter((o,b,Q)=>Q.findIndex(H=>H[0]===o[0])===b),k=L(x).slice(1).map((o,b)=>({no:/^\d+$/.test(o[0]||"")?o[0]:String(b+1),label:l(o[1]||"-"),isi:l(o[2]||"-"),centang:(o[3]||"").includes("\u2713")})),y=(z?Array.from(z.rows):[]).map(o=>({teks:l(n(o.cells[0])),ttd:l(o.cells[1]?n(o.cells[1]):""),qr:s(o.cells[1])})).filter((o,b,Q)=>Q.findIndex(H=>H.teks===o.teks)===b),C=L(p),N=l(C[2]?.join(" ")||"-"),h=l(C[3]?.join(" ")||"-"),O=(p?Array.from(p.rows[4]?.cells||[]):[]).map((o,b)=>({teks:l(n(o)),qr:b===2?s(o):""})),B=M("nama"),R=o=>o.replace(/Jambi\s*,?\s*\d{1,2}\/\d{1,2}\/\d{4}\s*,?\s*Jam\s*[\d:.]+/gi,"").replace(/\s+/g," ").trim(),E=o=>o.match(/\(([^)]+)\)/)?.[1]?.trim()||R(o)||"-",U=R(N),$=R(h),Y=U.match(/Nama\s*:\s*(.+?)(?=\s+Umur\s*:|$)/i)?.[1]?.trim()||"-",w=U.match(/Umur\s*:\s*(.+?)(?=\s+Jenis Kelamin\s*:|$)/i)?.[1]?.trim()||"-",S=U.match(/Jenis Kelamin\s*:\s*(.+?)(?=\s+Alamat\s*:|$)/i)?.[1]?.trim()||"-",f=U.match(/Alamat\s*:\s*(.+)$/i)?.[1]?.trim()||"-",A=k.find(o=>o.no==="3")?.isi||"-",g=o=>$.match(o)?.[0]?.trim()||"",v=[g(/Saya memahami perlunya dan manfaat tindakan tersebut[\s\S]*?(?=Saya juga menyadari|$)/i),g(/Saya juga menyadari[\s\S]*?(?=Saya memahami perlunya tindakan pembiusan|Saya bertanggung jawab|$)/i),g(/Saya memahami perlunya tindakan pembiusan[\s\S]*?(?=Saya bertanggung jawab|$)/i),g(/Saya bertanggung jawab[\s\S]*$/i)].filter(Boolean),c=(o,b)=>{let Q=R(O[o]?.teks||"").replace(b,"");return E(Q)},m=c(0,/Yang Menyatakan/i),T=c(1,/Saksi Keluarga/i),I=c(2,/Saksi Rumah Sakit/i);return`<section class="rm-page" id="form-konsent">
${J("RM. 19A")}
<div class="rm-form-title">PERSETUJUAN TINDAKAN KEDOKTERAN (RM 19 A)</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",B,!0)}
    ${r("Umur",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
    ${r("Alamat",st(i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${P.map(([o,b])=>r(o,b,o==="Penerima Informasi / Pemberi Persetujuan")).join("")}
  </table></div>
</div>

<table class="rm-table">
  <thead>
    <tr class="sec-hdr"><td colspan="4">I. PEMBERIAN INFORMASI</td></tr>
    <tr><th style="width:28px;">NO</th><th>JENIS INFORMASI</th><th>ISI INFORMASI</th><th style="width:70px;">TANDA (&#10003;)</th></tr>
  </thead>
  <tbody>
    ${k.length?k.map(o=>`<tr><td class="center">${t(o.no)}</td><td>${t(o.label)}</td><td>${F(o.isi)}</td><td class="center">${o.centang?"&#10003;":"&nbsp;"}</td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
  </tbody>
</table>

<table class="rm-table">
  <thead><tr class="sec-hdr"><td colspan="4">II. PERNYATAAN PEMBERI &amp; PENERIMA INFORMASI</td></tr></thead>
  <tbody>
    ${y.length?y.map((o,b)=>`<tr><td colspan="3">${F(R(o.teks))}</td><td style="text-align:center;vertical-align:top;"><div>${b===0?"Tanda Tangan Dokter":"Tanda Tangan Penerima"}</div>`+(o.qr?`<img class="rm-sig-qr" src="${t(o.qr)}" alt="QR tanda tangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>')+`<div>( <strong>${t(E(o.ttd))}</strong> )</div></td></tr>`).join(""):'<tr><td colspan="4">-</td></tr>'}
    <tr><td colspan="4">* Bila pasien tidak kompeten atau tidak mau menerima informasi, maka penerima informasi adalah wali atau keluarga terdekat.</td></tr>
  </tbody>
</table>

<div style="border:1px solid #000000;margin-bottom:5px;">
  <div class="sec-hdr" style="border-bottom:1px solid #000000;padding:4px 6px;">III. PERSETUJUAN TINDAKAN KEDOKTERAN</div>
  <div style="padding:5px 8px;">
    <div>Yang bertanda tangan di bawah ini, saya:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:80px;">Nama</td><td style="width:10px;">:</td><td><strong>${t(Y)}</strong></td><td style="width:80px;">Umur</td><td style="width:10px;">:</td><td>${t(w)}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td>${t(S)}</td><td>Alamat</td><td>:</td><td>${t(f)}</td></tr>
    </tbody></table>
    <div>Dengan ini menyatakan <strong>PERSETUJUAN</strong> untuk dilakukannya tindakan kedokteran (<strong>${t(A)}</strong>) terhadap: &nbsp; <span class="chk-box">&nbsp;</span> diri saya sendiri &nbsp; <span class="chk-box">&#10003;</span> <strong>Wali / Keluarga dari pasien</strong>:</div>
    <table class="rm-grid-table"><tbody>
      <tr><td style="width:90px;">Nama Pasien</td><td style="width:10px;">:</td><td><strong>${t(B)}</strong></td><td style="width:70px;">Umur</td><td style="width:10px;">:</td><td>${t(M("tgl_lahir","tglLahir"))}</td></tr>
      <tr><td>Jenis Kelamin</td><td>:</td><td><span class="chk-box">${/laki|^l$/i.test(M("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Laki-laki &nbsp; <span class="chk-box">${/perempuan|^p$/i.test(M("jenis_kelamin","jk"))?"&#10003;":"&nbsp;"}</span> Perempuan</td><td>Alamat</td><td>:</td><td>${t(st(i))}</td></tr>
    </tbody></table>
    ${v.map((o,b)=>`<div style="text-align:justify;margin:3px 0;">${b+1}. ${t(o)}</div>`).join("")}
    <table class="rm-table"><thead><tr>
      <th>Yang Menyatakan / Pemberi Persetujuan</th><th>Saksi Keluarga</th><th>Saksi Rumah Sakit</th>
    </tr></thead><tbody><tr>
      <td style="text-align:center;">
        ${O[0]?.qr?`<img class="rm-sig-qr" src="${t(O[0].qr)}" alt="QR penandatangan" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(m)}</strong> )
      </td>
      <td style="text-align:center;">
        ${O[1]?.qr?`<img class="rm-sig-qr" src="${t(O[1].qr)}" alt="QR saksi keluarga" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(T)}</strong> )
      </td>
      <td style="text-align:center;">
        ${O[2]?.qr?`<img class="rm-sig-qr" src="${t(O[2].qr)}" alt="QR saksi rumah sakit" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
        ( <strong>${t(I)}</strong> )
      </td>
    </tr></tbody></table>
  </div>
</div>
</section>`}function ca(i){let u=i.find(j=>/^Anestesi/i.test(j.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=V(i,/^Anestesi/i),n=(...j)=>Z(e,...j),L=(...j)=>{let D=ot(n(...j)).replace(/\s+/g," ").trim();return D&&D!=="-"?D:"-"},s=a?(a.body.textContent||"").replace(/\s+/g," ").trim():"",l=a?Array.from(a.querySelectorAll("table")):[],d=j=>j?Array.from(j.rows).map(D=>Array.from(D.cells).map(K=>(K.textContent||"").replace(/\s+/g," ").trim())):[],x=j=>new RegExp(`${j.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}\\s*\u2713`,"i").test(s)?"&#10003;":"&nbsp;",z=M("nama")!=="-"?M("nama"):L(/^Nama Pasien/i),p=M("norm","rekam_medis")!=="-"?M("norm","rekam_medis"):L(/^No\.? RM/i),P=M("tgl_lahir","tglLahir"),k=M("umur")!=="-"?M("umur"):L(/^Umur/i),y=Number(k.match(/(\d{1,3})/)?.[1]||0),C=M("jenis_kelamin","jk")||L(/^Jenis Kelamin/i),N=/perempuan|^p$/i.test(C)?"Perempuan (P)":/laki|^l$/i.test(C)?"Laki-laki (L)":C,h=L(/^Dokter Anestesi/i),O=L(/^Dokter Bedah/i)!=="-"?L(/^Dokter Bedah/i):M("dokter","dpjp"),B=L(/^Penata Anestesi/i),R=L(/^Ruangan/i)!=="-"?L(/^Ruangan/i):M("jenis","kelas","ruang"),E=L(/^Tanggal/i)!=="-"?L(/^Tanggal/i):M("tanggalAwal","tgl_masuk","tgl"),U=L(/^Diagnosis Prabedah|^Diagnosa Pra/i),$=L(/^Diagnosis Pasca Bedah|^Diagnosa Pasca/i),Y=L(/^Jenis pembedahan/i),w=L(/^Jenis operasi/i),S=L(/^Jam Mulai/i),f=l.find(j=>/Informed Consent/i.test(j.textContent||"")),A=d(f).flat().filter(Boolean).map(j=>({label:j.replace(/^[\d\s✓]+/,"").trim(),on:/✓/.test(j)})).filter(j=>j.label&&j.label.length<60),g=A.length?A.map(j=>`<div><span class="chk-box">${j.on?"&#10003;":"&nbsp;"}</span> ${t(j.label)}</div>`).join(""):"<div>-</div>",v=l.find(j=>/PENYAKIT PENYERTA/i.test(j.textContent||"")),c=d(v).slice(1).filter(j=>j.length>=2&&j[0]&&!/PENYAKIT PENYERTA/i.test(j[0])),m=c.length?c.map(j=>`<div><span class="chk-box">${/ya|ada|\+/i.test(j[1])?"&#10003;":"&nbsp;"}</span> ${t(j[0])}</div>`).join(""):"<div>-</div>",T=Array.from(a?.querySelectorAll("img")||[]).filter(j=>{let D=j.getAttribute("src")||"",K=j.getAttribute("class")||"";return!!D&&!/logo|kars|qr|barcode/i.test(D)&&!/logo/i.test(K)}),I=j=>j?`<div class="chart-frame">${j.outerHTML}</div>`:'<div class="chart-frame">Grafik tidak tersedia pada berkas ini.</div>',o=I(T[0]),b=I(T[1]??T[0]),Q=W(i,/^Anestesi/i),H=[["Dokter Spesialis Anestesiologi",Q[0]||"",h!=="-"?h:jt(Q[0])],["Dokter Operator",Q[1]||"",O!=="-"?O:jt(Q[1])],["Penata / Perawat Anestesi",Q[2]||"",B!=="-"?B:jt(Q[2])]].map(([j,D,K])=>'<div class="tte-box"><div>'+t(j)+'</div><div class="tte-qr">'+(D?`<img src="${t(D)}" alt="QR TTE" width="54" height="54" />`:"")+'</div><div class="tte-name">'+t(K)+"</div></div>").join(""),_=y>0&&y<18,tt=/spinal|subarachnoid|regional/i.test([L(/^Rencana Anestesi/i),L(/^Teknik/i),s].join(" ")),at=_?'<tr><td>Skor Steward</td><td colspan="3">Berlaku untuk pasien anak; skor diisi di halaman asal.</td></tr>':`<tr><td>Aldrete Score</td><td colspan="3">Aktivitas \xB7 Pernapasan \xB7 Sirkulasi \xB7 Kesadaran \xB7 Warna \u2014 skor diisi di halaman asal.</td></tr>
       <tr><td>Bromage Score</td><td colspan="3">${tt?"Gerakan penuh dari tungkai dan pergelangan kaki (blok motorik pulih) \u2014 skor diisi di halaman asal.":"Tidak Berlaku (anestesi non-regional)."}</td></tr>
       <tr><td>Steward Score</td><td colspan="3"><em>Tidak Berlaku (khusus pasien anak \u2014 pasien dewasa).</em></td></tr>`,rt=l.find(j=>/INSTRUKSI PASCA ANESTESI/i.test(j.textContent||"")),At=d(rt).flat().map(j=>j.replace(/^[\d\s]+/,"").trim()).filter(j=>j&&!/INSTRUKSI PASCA ANESTESI/i.test(j)&&j.length>3),ct=At.length?'<ol class="an-instruksi">'+At.map(j=>`<li>${t(j)}</li>`).join("")+"</ol>":"<div>-</div>",G=(j,D)=>`<tr><td class="k">${j}</td><td class="c">:</td><td class="v">${D}</td></tr>`,Mt=j=>`<tr><th class="rm-sec-head" style="text-align:left;">${j}</th></tr>`;return`<section class="rm-page" id="form-anestesi">
<div class="an-meta"><span>Halaman 1 dari 2</span><span>RM. 21</span></div>
${J("RM. 21")}
<div class="rm-form-title">LAPORAN ANESTESI</div>
<div class="an-subtitle">REKAM PELAKSANAAN ANESTESI</div>

<table class="rm-grid-table"><tbody><tr>
  <td style="width:52%;"><table class="an-kv">
    ${G("Nama Pasien",`<strong>${t(z)}</strong>`)}
    ${G("No. Rekam Medis",`<strong>${t(p)}</strong>`)}
    ${G("Tgl. Lahir / Umur",`${t(P)} (${t(k)} / ${t(N)})`)}
    ${G("Diagnosa Pra Bedah",t(U))}
    ${G("Diagnosa Pasca Bedah",`<strong>${t($)}</strong>`)}
  </table></td>
  <td><table class="an-kv">
    ${G("Tanggal Tindakan",`<strong>${t(E)}</strong>`)}
    ${G("Jenis Pembedahan",t(Y))}
    ${G("Jenis Operasi",t(w))}
    ${G("Ruangan",t(R))}
    ${G("Dokter Anestesi",`<strong>${t(h)}</strong>`)}
  </table></td>
</tr></tbody></table>

<table class="rm-grid-table"><tbody>${Mt("A. JENIS PERSIAPAN ANESTESI")}
<tr><td><div class="an-grid-4">${g}</div></td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${Mt("B. PENGKAJIAN PRA BEDAH &amp; RENCANA ANESTESI")}
<tr><td><table class="an-kv">
  ${G("Waktu Mulai",t(S))}
  ${G("Dokter Operator",t(O))}
  ${G("Asisten Bedah",t(L(/^Asisten Bedah|^Asisten/i)))}
  ${G("Instrumen Bedah",t(L(/^Instrumen Bedah|^Perawat Instrumen/i)))}
  ${G("Rencana Anestesi",`${x("Anestesi Umum")} Umum &nbsp; ${x("Spinal")} Spinal &nbsp; ${x("Epidural")} Epidural &nbsp; ${x("Kaudal")} Kaudal`)}
</table>
<div class="an-risk"><strong>Riwayat Penyakit &amp; Faktor Risiko:</strong><div class="an-grid-3">${m}</div></div>
</td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${Mt("C. INDUKSI &amp; MONITORING ANESTESI")}
<tr><td><table class="an-kv">
  ${G("Teknik / Lokasi Tusukan",`${t(L(/^Teknik :|^Lokasi Tusukan/i))} ${t(L(/^Analgesia setinggi/i))}`)}
  ${G("Anestesi Lokal",t(L(/^Anestesi lokal/i)))}
  ${G("ASA",`${x(" I ")} I &nbsp; ${x(" II ")} II &nbsp; ${x(" III ")} III &nbsp; ${x(" IV ")} IV &nbsp; ${x(" V ")} V &nbsp; ${x(" E ")} E`)}
</table></td></tr>
<tr><td>${o}</td></tr></tbody></table>

<!-- ================= HALAMAN 2 ================= -->
<div class="an-page-break"></div>
<div class="an-running">
  <span><strong>LAPORAN ANESTESI (LANJUTAN)</strong> \u2014 ${t(St)}</span>
  <span>Pasien: <strong>${t(z)}</strong> \u2022 RM: <strong>${t(p)}</strong></span>
  <span><strong>Halaman 2 dari 2 \u2022 RM. 21</strong></span>
</div>

<table class="rm-grid-table"><tbody>${Mt("D. MEDIKASI, CAIRAN &amp; JALAN NAPAS")}
<tr><td><table class="an-kv">
  ${G("Medikasi",t(L(/^MEDIKASI|^Obat/i)))}
  ${G("Pemberian Cairan",t(L(/^PEMBERIAN CAIRAN|^RL /i)))}
  ${G("Total Asupan Cairan",t(L(/^kristaloid/i)))}
  ${G("Total Keluaran Cairan",`Perdarahan ${t(L(/^perdarahan/i))} \u2022 Diuresis ${t(L(/^diuresis/i))}`)}
  ${G("Pengelolaan Napas",t(L(/^Respirasi|^Air way/i)))}
</table></td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${Mt("E. PEMANTAUAN RUANG PULIH SADAR")}
<tr><td>${b}</td></tr></tbody></table>

<table class="rm-grid-table"><tbody>${Mt("F. PENILAIAN KELAYAKAN PINDAH RUANGAN")}
${at}</tbody></table>

<table class="rm-grid-table"><tbody>${Mt("G. INSTRUKSI PASCA ANESTESI")}
<tr><td>${ct}</td></tr></tbody></table>

<div class="an-tte-note">Jambi, ${t(E)} \u2014 Dokumen ditandatangani secara elektronik (TTE):</div>
<footer class="an-tte">${H}</footer>
</section>`}function ga(i){let u=V(i,/^Fisioterapi/i),a=Lt(i,/^Fisioterapi/i),e=(...n)=>Z(u,...n);return`<section class="rm-page" id="form-fisioterapi">
${J("FISIOTERAPI")}
<div class="rm-form-title">LEMBAR ASSESMEN &amp; TERAPI FISIOTERAPI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal",e(/^Tanggal/i))}
    ${r("Diagnosa",e(/^Diagnosa/i))}
    ${r("Ruang / Asal",e(/^Ruang|^Unit/i))}
    ${r("Terapis",e(/^Terapis|^Fisioterapis/i))}
  </table></div>
</div>
${it([["KELUHAN UTAMA (SUBJEKTIF)",e(/^Keluhan|^Subjektif/i)],["PEMERIKSAAN OBJEKTIF (ROM / MMT / FUNGSI)",e(/^Objektif|^Pemeriksaan/i)],["ASSESMEN FISIOTERAPI",e(/^Assesmen|^Diagnosa Fisio/i)],["RENCANA TERAPI &amp; TUJUAN",e(/^Rencana|^Terapi|^Tujuan/i)]])}
<div class="sub-heading-rm">PELAKSANAAN TERAPI</div>
${ut(["TANGGAL","MODALITAS / LATIHAN","FREKUENSI","RESPON PASIEN"],a,!0)}
${et(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Terapis / Fisioterapis",`( ${t(e(/^Terapis|^Fisioterapis/i))} )`])}
</section>`}function Na(i){let u=V(i,/^Pengkajian Hemodialisa/i),a=Lt(i,/^Pengkajian Hemodialisa/i),e=(...n)=>Z(u,...n);return`<section class="rm-page" id="form-hemodialisa">
${J("HEMODIALISA")}
<div class="rm-form-title">LEMBAR PENGKAJIAN &amp; SESI HEMODIALISA</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Sesi",e(/^Tanggal/i))}
    ${r("Akses Vaskular",e(/^Akses/i))}
    ${r("Diagnosa",e(/^Diagnosa/i))}
    ${r("Perawat / Dokter",e(/^Perawat|^Dokter/i))}
  </table></div>
</div>
${ut(["PARAMETER","SEBELUM DIALISA","SESUDAH DIALISA","KETERANGAN"],[["Berat Badan",e(/^BB Sebelum|^Berat Sebelum/),e(/^BB Sesudah|^Berat Sesudah/),"-"],["Tekanan Darah",e(/^TD Sebelum|^Tekanan Sebelum/),e(/^TD Sesudah|^Tekanan Sesudah/),"-"],["Nadi",e(/^Nadi Sebelum/),e(/^Nadi Sesudah/),"-"],...a],!0)}
${it([["BLOOD FLOW / DIALYSATE FLOW",e(/^Blood Flow|^Dialysate/i)],["ULTRAFILTRASI &amp; Heparinisasi",e(/^Ultrafiltrasi|^UF|^Heparin/i)],["ADEKUASI (Kt/V)",e(/^Kt\/V|^Adekuasi/i)],["KOMPLIKASI / CATATAN",e(/^Komplikasi|^Catatan/i)]])}
${et(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Perawat Hemodialisa",`( ${t(e(/^Perawat/i))} )`])}
</section>`}function ma(i){let u=i.find(w=>/^Operasi/i.test(w.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=V(i,/^Operasi/i),n=(...w)=>Z(e,...w),L=w=>ot(w).replace(/\bantispetik\b/gi,"antiseptik").replace(/\bincisi\b/gi,"insisi").replace(/\bfacia\b/gi,"fasia").replace(/\bdaryantul\b/gi,"daryantulle").replace(/\bPendarahan\b/g,"Perdarahan").replace(/\bTranfusi\b/g,"Transfusi").replace(/\bEFEKTIF\b/g,"Elektif").replace(/\s+/g," ").trim(),s=(...w)=>{let S=L(n(...w));return S&&S!=="-"?S:"-"},l=(w,S)=>{for(let f of w){let A=M(f);if(A!=="-")return L(A)}return s(S)},d=(()=>{if(!a)return{persiapan:"-",langkah:[]};let w=Array.from(a.querySelectorAll("tr")),S=w.findIndex(c=>/Uraian Pembedahan/i.test(c.textContent||"")),f=S>=0&&w[S+1]?.cells[0]?.textContent||"";f.trim()||(f=Array.from(a.querySelectorAll("td")).map(c=>(c.textContent||"").trim()).sort((c,m)=>m.length-c.length)[0]||"");let A=f.split(/\n+/).map(c=>L(c)).filter(Boolean);if(!A.length)return{persiapan:"-",langkah:[]};let g=A.findIndex(c=>/Diputuskan|sebagai berikut/i.test(c)),v=g>=0?g+1:Math.min(4,A.length);return{persiapan:A.slice(0,v).join(" "),langkah:A.slice(v)}})(),x=a?Array.from(a.querySelectorAll("td")).map(w=>(w.textContent||"").replace(/\s+/g," ").trim()).filter(w=>/^-?\s*(MAYOR|MINOR|EFEKTIF|ELEKTIF|EMERGENSI|CITO|SEDANG|KHUSUS)$/i.test(w)).join(" "):"",z=w=>w.test(x)?"&#10003;":"&nbsp;",p=s(/^Komplikasi/i),P=p==="-"?'<span class="chk-box">&#10003;</span> Tidak ada komplikasi &nbsp;&nbsp; <span class="chk-box">&nbsp;</span> Ada, sebutkan: ..............................':'<span class="chk-box">&nbsp;</span> Tidak ada komplikasi &nbsp;&nbsp; <span class="chk-box">&#10003;</span> Ada: <strong>'+t(p)+"</strong>",k=s(/^Penggunaan Implan/i),y=/^Ya/i.test(k)?`<span class="chk-box">&nbsp;</span> Tidak &nbsp; <span class="chk-box">&#10003;</span> Ya \u2014 Jenis: ${t(s(/^Jenis Implan/i))} | No. Seri: ${t(s(/^Nomor Implan/i))}`:'<span class="chk-box">&#10003;</span> Tidak &nbsp; <span class="chk-box">&nbsp;</span> Ya',C=s(/^Tanggal Bedah/i),N=l(["dokter_operator","operator"],/^Dokter Operator|^Operator/i),h=W(i,/^Operasi/i)[0]??"",O=M("jenis_kelamin","jk")||s(/^Jenis Kelamin/i),B=/perempuan|^p$/i.test(O)?"Perempuan (P)":/laki|^l$/i.test(O)?"Laki-laki (L)":O,R=C!=="-"?mt(C):"-",E=(w,S,f="")=>`<tr><td class="k${f}">${w}</td><td class="c">:</td><td class="v">${S}</td></tr>`,U=(w,S=2)=>`<tr><th class="rm-sec-head" colspan="${S}" style="text-align:left;">${w}</th></tr>`,$=d.persiapan!=="-"?t(d.persiapan):"-",Y=d.langkah.length?'<ol class="op-steps">'+d.langkah.map(w=>`<li>${t(w)}</li>`).join("")+"</ol>":"<div>-</div>";return`<section class="rm-page" id="form-operasi">
${J("RM. 20")}
<div class="rm-form-title">LAPORAN PELAKSANAAN OPERASI</div>

<div class="id-box-borderless">
  <div class="id-col"><table class="op-kv">
    ${E("Nama Pasien",`<strong>${t(l(["nama"],/^Nama Pasien/i))}</strong>`)}
    ${E("Tanggal Lahir / Umur",`${t(l(["tgl_lahir","tglLahir"],/^Tanggal Lahir|^Tgl Lahir/i))} (${t(M("umur")||s(/^Umur/i))})`)}
  </table></div>
  <div class="id-col"><table class="op-kv">
    ${E("No. Rekam Medis",`<strong>${t(l(["norm","rekam_medis"],/^No\.? RM/i))}</strong>`)}
    ${E("Jenis Kelamin",t(B))}
  </table></div>
</div>

<table class="rm-grid-table"><tbody>
  ${U("I. TIM OPERASI &amp; WAKTU PEMBEDAHAN")}
  <tr>
    <td style="width:54%;">
      <table class="op-kv">
        ${E("Dokter Operator",`<strong>${t(N)}</strong>`)}
        ${E("Asisten / Dr. Anestesi",t(s(/^Asisten/i)))}
        ${E("Perawat Instrumen",t(s(/^Perawat Instrumen/i)))}
      </table>
    </td>
    <td>
      <table class="op-kv">
        ${E("Tanggal Bedah",`<strong>${t(C)}</strong>`)}
        ${E("Jam Mulai \u2013 Selesai",`${t(s(/^Jam Mulai/i))} \u2013 ${t(s(/^Jam Selesai/i))}`)}
        ${E("Lama Waktu Bedah",`<strong>${t(s(/^Waktu Bedah/i))}</strong>`)}
      </table>
    </td>
  </tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  ${U("II. DIAGNOSIS, KLASIFIKASI &amp; TINDAKAN / ICD-9-CM")}
  <tr>
    <td style="width:54%;">
      <table class="op-kv">
        ${E("Diagnosis Pra Bedah",t(s(/^Diagnosis Pra Bedah|^Diagnosa Pra/i)))}
        ${E("Diagnosis Pasca Bedah",`<strong>${t(s(/^Diagnosis Pasca Bedah|^Diagnosa Pasca/i))}</strong>`)}
        ${E("Nama / Macam Operasi",`<strong>${t(s(/^Nama Macam Operasi|^Tindakan|^Prosedur/i))}</strong>`)}
      </table>
    </td>
    <td>
      <table class="op-kv">
        <tr><td class="k">Kategori Operasi</td><td class="c">:</td><td class="v"><span class="chk-box">${z(/MAYOR/i)}</span> Mayor &nbsp; <span class="chk-box">${z(/SEDANG|MINOR/i)}</span> Sedang &nbsp; <span class="chk-box">${z(/KHUSUS/i)}</span> Khusus</td></tr>
        <tr><td class="k">Sifat Operasi</td><td class="c">:</td><td class="v"><span class="chk-box">${z(/ELEKTIF|EFEKTIF/i)}</span> Elektif &nbsp; <span class="chk-box">${z(/CITO|EMERGENSI/i)}</span> Cito / Emergensi</td></tr>
        ${E("Jaringan Dieksisi",t(s(/^Jaringan yang Dieksisi|^Jaringan Dieksisi/i)))}
        <tr><td class="k">Penggunaan Implan</td><td class="c">:</td><td class="v">${y}</td></tr>
      </table>
    </td>
  </tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  ${U("III. URAIAN PEMBEDAHAN")}
  <tr><td class="op-narrative">
    <div class="op-preface"><strong>Persiapan &amp; Evaluasi Awal:</strong> ${$}</div>
    <div><strong>Langkah-Langkah Tindakan:</strong></div>
    ${Y}
  </td></tr>
  <tr><td><strong>IV. Komplikasi Intraoperatif:</strong> &nbsp; ${P}</td></tr>
</tbody></table>

<table class="rm-grid-table"><tbody>
  <tr>
    <th class="rm-sec-head" style="width:50%;text-align:left;">V. PEMERIKSAAN PATOLOGI ANATOMI (PA)</th>
    <th class="rm-sec-head" style="text-align:left;">VI. PERDARAHAN, TRANSFUSI &amp; DRAINASE</th>
  </tr>
  <tr>
    <td><table class="op-kv">
      ${E("Jaringan ke PA",`<strong>${t(s(/^Jaringan ke Patologi/i))}</strong>`)}
      ${E("Dikirim Untuk",t(s(/^Dikirim Untuk/i)))}
      ${E("Jenis Jaringan",t(s(/^Jenis Jaringan/i)))}
      ${E("Tanggal Pengiriman",t(s(/^Tanggal Jaringan/i)))}
    </table></td>
    <td><table class="op-kv">
      ${E("Perkiraan Perdarahan",`<strong>${t(s(/^Perkiraan Pendarahan|^Perkiraan Perdarahan/i))}</strong>`)}
      ${E("Transfusi Darah",t(s(/^Tranfusi Darah|^Transfusi Darah/i)))}
      ${E("Pemakaian Drain",t(s(/^Pemakaian Drain/i)))}
    </table></td>
  </tr>
</tbody></table>

<div class="rm-signature-block" style="justify-content:flex-end;">
  <div class="rm-sig-box">
    <div>Jambi, ${t(R)}</div>
    <div>Dokter Operator,</div>
    ${h?`<img class="rm-sig-qr" src="${t(h)}" alt="QR TTE dokter operator" width="80" height="80" />`:'<div class="rm-sig-space"></div>'}
    <div class="rm-sig-name">( ${t(N)} )</div>
  </div>
</div>
</section>`}function wa(i){let u=i.find(n=>/^Laboratorium/i.test(n.title)),a=u?new DOMParser().parseFromString(u.html,"text/html"):null,e=a?Array.from(a.querySelectorAll("img")).map(n=>n.outerHTML).filter(n=>!/logo/i.test(n)):[];return`<section class="rm-page" id="rm-09">
${J("RM. 09")}
<div class="rm-form-title">HASIL PEMERIKSAAN LABORATORIUM PATOLOGI KLINIK</div>
<div class="passthrough-separator"><span>LAMPIRAN HASIL LABORATORIUM (LIS)</span><span>FILE UPLOAD</span></div>
<div class="raw-upload-frame">
  ${e.length?e.join("<br/>"):"-"}
</div>
</section>`}function pa(i){let u=V(i,/^Surat Kematian/i),a=(...e)=>Z(u,...e);return`<section class="rm-page" id="form-kematian">
${J("KEMATIAN")}
<div class="rm-form-title">SURAT KETERANGAN KEMATIAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Tgl. Lahir / Umur",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
    ${r("Alamat",st(i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Kematian",a(/^Tanggal Kematian|^Tanggal/i))}
    ${r("Jam Kematian",a(/^Jam/i))}
    ${r("Tempat Kematian",a(/^Tempat/i))}
    ${r("Ruang / Kelas",[M("jenis"),M("kelas","ruang")].filter(e=>e!=="-").join(" / ")||"-")}
  </table></div>
</div>
${it([["PENYEBAB KEMATIAN LANGSUNG (I)",a(/^Penyebab Langsung|^Penyebab I/i)],["PENYEBAB ANTARA (II)",a(/^Penyebab Antara|^Penyebab II/i)],["PENYAKIT / KONDISI LAIN",a(/^Penyakit Lain|^Kondisi Lain/i)],["KETERANGAN",a(/^Keterangan|^Catatan/i)]])}
${et(["Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(a(/^Tanggal Kematian|^Tanggal/i)),"Dokter yang Menyatakan Meninggal",`( ${t(M("dokter","dpjp"))} )`])}
</section>`}function ya(i){let u=V(i,/^Permintaan Terapi/i),a=Lt(i,/^Permintaan Terapi/i),e=(...n)=>Z(u,...n);return`<section class="rm-page" id="form-terapi">
${J("TERAPI")}
<div class="rm-form-title">PERMINTAAN TERAPI REHABILITASI MEDIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Permintaan",e(/^Tanggal/i))}
    ${r("Ruangan / Unit Asal",e(/^Ruang|^Unit/i))}
    ${r("Dokter Pengirim",e(/^Dokter Pengirim/i))}
    ${r("Diagnosa",e(/^Diagnosa/i))}
  </table></div>
</div>
${it([["JENIS TERAPI YANG DIMINTA",e(/^Jenis Terapi|^Terapi/i)],["TUJUAN TERAPI",e(/^Tujuan/i)],["FREKUENSI / RENCANA",e(/^Frekuensi|^Rencana/i)],["CATATAN KLINIS",e(/^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN PERMINTAAN</div>
${ut(["NO","TERAPI / MODALITAS","FREKUENSI","KETERANGAN"],a,!0)}
${et(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Dokter Pengirim",`( ${t(e(/^Dokter Pengirim/i))} )`])}
</section>`}function Da(i){let u=V(i,/^Uji Fungsi/i),a=Lt(i,/^Uji Fungsi/i),e=(...n)=>Z(u,...n);return`<section class="rm-page" id="form-uji-fungsi">
${J("UJI FUNGSI")}
<div class="rm-form-title">LEMBAR UJI FUNGSI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Pemeriksaan",e(/^Tanggal/i))}
    ${r("Diagnosa",e(/^Diagnosa/i))}
    ${r("Petugas Uji",e(/^Petugas|^Terapis/i))}
    ${r("Alat / Metode",e(/^Alat|^Metode/i))}
  </table></div>
</div>
${ut(["PARAMETER FUNGSI","NILAI / SKOR","SATUAN","KETERANGAN"],a,!0)}
${it([["HASIL / INTERPRETASI",e(/^Hasil|^Interpretasi/i)],["KESIMPULAN",e(/^Kesimpulan/i)],["REKOMENDASI TERAPI",e(/^Rekomendasi|^Saran/i)]])}
${et(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Petugas Uji Fungsi",`( ${t(e(/^Petugas|^Terapis/i))} )`])}
</section>`}function xa(i){let u=V(i,/^Partograf/i),a=Lt(i,/^Partograf/i),e=(...n)=>Z(u,...n);return`<section class="rm-page" id="form-partograf">
${J("PARTOGRAF")}
<div class="rm-form-title">PARTOGRAF \u2014 PEMANTAUAN KEMAJUAN PERSALINAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Umur",e(/^Umur/i))}
    ${r("Grafida / Paritas",e(/^Grafida|^Paritas|^G/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("HPHT",e(/^HPHT/i))}
    ${r("Taksiran Persalinan",e(/^Taksiran|^TP/i))}
    ${r("Tanggal Persalinan",e(/^Tanggal/i))}
    ${r("Petugas",e(/^Petugas|^Bidan/i))}
  </table></div>
</div>
<div class="sub-heading-rm">KEMAJUAN PERSALINAN &amp; OBSERVASI</div>
${ut(["JAM","PEMBUKAAN","TURUN","KONTRAKSI","DJJ","TD / NADI","SUHU","URINE","CATATAN"],a,!0)}
${it([["KEADAAN IBU &amp; JANIN",e(/^Keadaan|^Kondisi/i)],["TINDAKAN / PENYIMPANGAN",e(/^Tindakan|^Penyimpangan/i)],["CATATAN",e(/^Catatan/i)]])}
${et(["Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Bidan / Petugas Persalinan",`( ${t(e(/^Petugas|^Bidan/i))} )`])}
</section>`}function Ea(i){let u=V(i,/^Laporan Tindakan/i),a=Lt(i,/^Laporan Tindakan/i),e=(...n)=>Z(u,...n);return`<section class="rm-page" id="form-laporan-tindakan">
${J("LAPORAN TINDAKAN")}
<div class="rm-form-title">LAPORAN PELAKSANAAN TINDAKAN</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Tindakan",e(/^Tanggal/i))}
    ${r("Jenis Tindakan",e(/^Jenis Tindakan|^Tindakan/i))}
    ${r("Ruang / Unit",e(/^Ruang|^Unit/i))}
    ${r("Pelaksana",e(/^Pelaksana|^Petugas|^Dokter/i))}
  </table></div>
</div>
${it([["INDIKASI / DIAGNOSA",e(/^Indikasi|^Diagnosa/i)],["URAIAN TINDAKAN",e(/^Uraian|^Prosedur/i)],["HASIL TINDAKAN",e(/^Hasil/i)],["KOMPLIKASI / CATATAN",e(/^Komplikasi|^Catatan/i)]])}
<div class="sub-heading-rm">RINCIAN TINDAKAN</div>
${ut(["NO","TINDAKAN","WAKTU / JAM","PELAKSANA"],a,!0)}
${et(["Pasien / Keluarga Pasien",`( ${t(M("nama"))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Pelaksana Tindakan",`( ${t(e(/^Pelaksana|^Petugas|^Dokter/i))} )`])}
</section>`}var kt=i=>i?Array.from(i.rows).map(u=>Array.from(u.cells).map(dt)):[],Ct=i=>[i.match(/(\d{1,2}\/\d{1,2}\/\d{4})/)?.[1]??"-",i.match(/Pukul\s*([\d:]+)/i)?.[1]??"-"],ht=i=>i.match(/dr\.[^\n]+/i)?.[0]?.trim()??"-";function Ia(i){let u=Array.from(i.querySelectorAll("table")),a=u[0]??null,e=u.find(N=>/Jawaban Konsultasi/i.test(N.textContent||""))??null,n=kt(a),L=kt(e),s=n[0]??[],l=n[1]?.[0]||"",d=n.findIndex(N=>/^Penemuan Klinis/i.test(N[0]||"")),[x,z]=Ct(s[1]||""),[p,P]=Ct(L[1]?.[1]||""),k={};for(let N of L.slice(2))for(let h of N){let O=h.match(/^(Subjektif|Objektif|Assesmen|Planning|Instruksi)\s*:\s*([\s\S]*)$/i);O&&(k[O[1].toLowerCase()]=O[2].trim()||"-")}let y=(s[0]||"").replace(/^\s*Konsul Ke\s*:\s*/i,"").replace(/\s+/g," ").trim(),C=ht(L[L.length-1]?.[1]||"");return{konsulen:C!=="-"?C:y||"-",pengirim:ht(n[n.length-1]?.[1]||""),tanggal:x,jam:z,jenis:l.match(/Mohon\s+Konsultasi\s+([^\s:]+)/i)?.[1]??"-",permintaan:l||"-",penemuan:(d>=0?n[d+1]?.[0]:"")||"-",dugaan:n.flat().find(N=>/^Dugaan\s*:/i.test(N))?.replace(/^Dugaan\s*:\s*/i,"").trim()||"-",subjektif:k.subjektif||"-",objektif:k.objektif||"-",asesmen:k.asesmen||"-",planning:k.planning||"-",instruksi:k.instruksi||"-",keputusan:L.flat().find(N=>/Konsultasi selesai tanggal/i.test(N))||"-",tglJawaban:p,jamJawaban:P}}function Ta(i,u,a="rm-10"){let e=u??i.find(l=>/Konsul/i.test(l.title));if(!e)return"";let n=new DOMParser().parseFromString(e.html,"text/html"),L=Array.from(n.querySelectorAll("b")).filter(l=>/^\s*Konsul Ke\s*:/i.test(l.textContent||"")).map(l=>l.closest("table")?.parentElement).filter(l=>!!l),s=W([e],/Konsul/i);return L.map((l,d)=>ba(Ia(l),s[d]??"",d?`${a}-${d+1}`:a)).join("")}function ba(i,u,a){let e=M("dokter","dpjp"),n=i.konsulen!=="-"?i.konsulen:M("dokter_konsulen")!=="-"?M("dokter_konsulen"):jt(u);return`<section class="rm-page" id="${t(a)}">
${J("RM. 10")}
<div class="rm-form-title">LEMBAR KONSULTASI</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("No. Rekam Medis",M("norm","rekam_medis"),!0)}
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("Tanggal Lahir / Umur",M("tgl_lahir","tglLahir"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Jenis Kunjungan",[M("jenis"),M("kelas","ruang")].filter(L=>L!=="-").join(" / ")||"-")}
    ${r("Tanggal Permintaan",`${i.tanggal} ${i.jam}`.trim())}
    ${r("Tanggal Jawaban",`${i.tglJawaban} ${i.jamJawaban}`.trim())}
  </table></div>
</div>
${it([["BAGIAN I : KEPADA YTH. KONSULEN",n],["JENIS PERMOHONAN",i.jenis],["PERMINTAAN KONSULTASI",i.permintaan],["PENEMUAN KLINIS TERPENTING",i.penemuan],["DUGAAN DIAGNOSA",i.dugaan]])}
${it([["S (SUBJEKTIF)",i.subjektif],["O (OBJEKTIF)",i.objektif],["A (ASSESMEN)",i.asesmen],["P (PLANNING)",i.planning],["INSTRUKSI",i.instruksi],["KEPUTUSAN KONSULTASI",i.keputusan]])}
${et(["Dokter Pemohon Konsultasi",e!=="-"?`( ${t(e)} )`:`( ${t(i.pengirim)} )`],["Dokter Konsulen",u?`<img class="rm-sig-qr" src="${t(u)}" alt="QR dokter konsulen" width="80" height="80" />`:'<div class="rm-sig-space"></div>',`( ${t(n)} )`])}
</section>`}function ka(i){let u=V(i,/^Bon Makan/i),a=(...e)=>Z(u,...e);return`<section class="rm-page" id="form-bon-makan">
${J("BON MAKAN")}
<div class="rm-form-title">BON MAKAN PASIEN / PENDAMPING</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Ruang / Kelas",[M("jenis"),M("kelas","ruang")].filter(e=>e!=="-").join(" / ")||"-")}
    ${r("Tanggal",a(/^Tanggal/i))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Nama Pendamping",a(/^Pendamping|^Keluarga/i))}
    ${r("Jumlah Porsi",a(/^Jumlah|^Porsi/i))}
    ${r("Waktu",a(/^Waktu|^Jam/i))}
    ${r("Petugas",a(/^Petugas/i))}
  </table></div>
</div>
${ut(["NO","NAMA","HUBUNGAN","JUMLAH","KETERANGAN"],Lt(i,/^Bon Makan/i),!0)}
<div class="footnote-rm">Bon ini berlaku sesuai jadwal makan yang ditetapkan ruangan / instalasi gizi.</div>
${et(["Pasien / Pendamping",`( ${t(a(/^Pendamping|^Keluarga/i))} )`],["Kota Jambi, "+t(a(/^Tanggal/i)),"Petugas Ruangan",`( ${t(a(/^Petugas/i))} )`])}
</section>`}function Ca(i){let u=V(i,/^PEMERIKSAAN$/i),a=Lt(i,/^PEMERIKSAAN$/i),e=(...n)=>Z(u,...n);return`<section class="rm-page" id="form-pemeriksaan">
${J("PEMERIKSAAN")}
<div class="rm-form-title">HASIL PEMERIKSAAN / DIAGNOSTIK</div>
<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    ${r("Nama Pasien",M("nama"),!0)}
    ${r("No. Rekam Medis",M("norm","rekam_medis"))}
    ${r("Tgl. Lahir",M("tgl_lahir","tglLahir"))}
    ${r("Jenis Kelamin",M("jenis_kelamin","jk"))}
  </table></div>
  <div class="id-col"><table class="id-table">
    ${r("Tanggal Pemeriksaan",e(/^Tanggal/i))}
    ${r("Jenis Pemeriksaan",e(/^Jenis Pemeriksaan|^Pemeriksaan/i))}
    ${r("Spesimen / Bahan",e(/^Spesimen|^Bahan/i))}
    ${r("Dokter Pengirim",e(/^Dokter Pengirim/i))}
  </table></div>
</div>
${ut(["PARAMETER","HASIL","SATUAN","NILAI RUJUKAN"],a,!0)}
${it([["MAKROSKOPIK / TEMUAN",e(/^Makroskopik|^Temuan/i)],["MIKROSKOPIK",e(/^Mikroskopik/i)],["KESIMPULAN / DIAGNOSA",e(/^Kesimpulan|^Diagnosa/i)],["CATATAN",e(/^Catatan/i)]])}
${et(["Petugas / Analis",`( ${t(e(/^Petugas|^Analis/i))} )`],["Kota Jambi, "+t(e(/^Tanggal/i)),"Dokter Penanggung Jawab",`( ${t(e(/^Dokter Penanggung Jawab|^Dokter/i))} )`])}
</section>`}function ha(i,u){let a=Wt(i,u),e=M("no_sep","sep"),n=M("kartu","no_kartu","noka"),L=M("norm","rekam_medis"),s=M("nama"),l=[M("jenis"),M("kelas","ruang")].filter(S=>S!=="-").join(" / ")||"-",d=M("dokter","dpjp"),x=M("tanggalAwal","tgl_masuk","tgl"),z=M("tanggalAkhir","keluar","tgl_keluar"),p=M("tgl_lahir","tglLahir"),P=M("jenis_kelamin","jk"),k=st(i),y=i.filter(S=>/resep/i.test(S.title)).length,C=bt,N=new Date,h=`${N.getDate()} ${C[N.getMonth()]} ${N.getFullYear()}`,O=`<table class="rm-grid-table">
  <thead>
    <tr><th colspan="3">CATATAN KETIDAKSESUAIAN DATA LINTAS DOKUMEN (HASIL UJI SILANG OTOMATIS)</th></tr>
    <tr><th style="width: 32px;">NO</th><th style="width: 170px;">JENIS KETIDAKSESUAIAN</th><th>URAIAN TEMUAN VERIFIKASI</th></tr>
  </thead>
  <tbody>${a.map((S,f)=>`<tr><td class="center">${f+1}</td><td><strong>${t(S.title)}</strong></td><td>${t(S.detail)}</td></tr>`).join("")}</tbody>
</table>`,B=`<section class="rm-page" id="rm-00">
${J("RM. 00")}
<div class="rm-form-title">LEMBAR KENDALI KELENGKAPAN &amp; VERIFIKASI BERKAS KLAIM JKN</div>

<div class="id-box-bordered">
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NAMA PASIEN</td><td class="col">:</td><td class="val"><strong>${t(s)}</strong></td></tr>
    <tr><td class="lbl">NO. REKAM MEDIS</td><td class="col">:</td><td class="val"><strong>${t(L)}</strong></td></tr>
    <tr><td class="lbl">TGL. LAHIR / UMUR</td><td class="col">:</td><td class="val">${t(p)}</td></tr>
    <tr><td class="lbl">JENIS KELAMIN</td><td class="col">:</td><td class="val">${t(P)}</td></tr>
    <tr><td class="lbl">ALAMAT</td><td class="col">:</td><td class="val">${t(k)}</td></tr>
  </table></div>
  <div class="id-col"><table class="id-table">
    <tr><td class="lbl">NO. KARTU BPJS</td><td class="col">:</td><td class="val"><strong>${t(n)}</strong></td></tr>
    <tr><td class="lbl">NO. SEP</td><td class="col">:</td><td class="val"><strong>${t(e)}</strong></td></tr>
    <tr><td class="lbl">TGL. MASUK / KELUAR</td><td class="col">:</td><td class="val">${t([x,z].filter(S=>S&&S!=="-").join(" s/d ")||"-")}</td></tr>
    <tr><td class="lbl">RUANG / KELAS</td><td class="col">:</td><td class="val">${t(l)}</td></tr>
    <tr><td class="lbl">DPJP UTAMA</td><td class="col">:</td><td class="val">${t(d)}</td></tr>
  </table></div>
</div>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 110px;">KODE INA-CBG</th>
      <th>DESKRIPSI GROUPING INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF INA-CBG</th>
      <th class="num" style="width: 120px;">TARIF RIIL RS</th>
      <th class="num" style="width: 115px;">SELISIH</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="center"><strong>${t(nt("ina_cbg_code")||"-")}</strong></td>
      <td>${t(nt("ina_cbg_desc")||"-")}</td>
      <td class="num"><strong>${t(nt("tarif_ina_cbg")||"-")}</strong></td>
      <td class="num">${t(nt("tarif_riil_rs")||"-")}</td>
      <td class="num">${t(nt("selisih")||"-")}</td>
    </tr>
  </tbody>
</table>

<table class="rm-grid-table">
  <thead>
    <tr>
      <th style="width: 32px;">NO</th>
      <th style="width: 58px;">KODE RM</th>
      <th>JENIS BERKAS / DOKUMEN KLAIM</th>
      <th style="width: 120px;">STATUS BERKAS</th>
      <th style="width: 68px;">TANDA (&#10003;)</th>
    </tr>
  </thead>
  <tbody>
    <tr><td class="center">1</td><td class="center">RM. 01</td><td>Surat Elegibilitas Peserta (SEP) \u2014 No. ${t(e)}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 01 SEP"></td></tr>
    <tr><td class="center">2</td><td class="center">RM. 01</td><td>Berkas Klaim Individual Pasien (INA-CBG E-Klaim 5.10.9)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi INA-CBG"></td></tr>
    <tr><td class="center">3</td><td class="center">RM. 02</td><td>Surat Bukti Pelayanan Kesehatan (SBPK) \u2014 ${t(l)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 02 SBPK"></td></tr>
    <tr><td class="center">4</td><td class="center">RM. 03</td><td>Surat Pengantar Rawat Inap (SPRI) \u2014 Tgl. ${t(x||"-")}</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 03 SPRI"></td></tr>
    <tr><td class="center">5</td><td class="center">Seksi 04</td><td>File Upload Dokumen Pasien (Laporan Echo/Doppler &amp; Rekaman EKG)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi Seksi 04 Upload"></td></tr>
    <tr><td class="center">6</td><td class="center">RM. 05</td><td>Rincian Biaya Pelayanan Rawat Inap &amp; Farmasi (${y} Nota Resep)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 05 Billing"></td></tr>
    <tr><td class="center">7</td><td class="center">RM. 06</td><td>Ringkasan Pulang (Discharge Summary) \u2014 DPJP ${t(d)}</td><td class="center"><strong>ADA *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 06 Resume"></td></tr>
    <tr><td class="center">8</td><td class="center">RM. 07</td><td>Formulir Telaah Resep, Telaah Obat &amp; Edukasi Farmasi (No. 230445)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 07 Telaah"></td></tr>
    <tr><td class="center">9</td><td class="center">RM. 08</td><td>Hasil Pemeriksaan Radiologi \u2014 Thorax AP/PA (No. Rontgen 5918)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 08 Radiologi"></td></tr>
    <tr><td class="center">10</td><td class="center">RM. 09</td><td>Hasil Pemeriksaan Laboratorium Patologi Klinik (Hematologi &amp; Urine)</td><td class="center"><strong>TIDAK LENGKAP *</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 09 Lab"></td></tr>
    <tr><td class="center">11</td><td class="center">RM. 10</td><td>Lembar Konsultasi Antar-Spesialis (dr. M. Ryan Ramadhan, Sp.JP., FIHA)</td><td class="center"><strong>ADA</strong></td><td class="center"><input type="checkbox" class="rm-checkbox" aria-label="Verifikasi RM 10 Konsul"></td></tr>
  </tbody>
</table>

${O}

<div class="rm-signature-block">
  <div class="rm-sig-box">
    <div>Kota Jambi, ${h}</div>
    <div>Petugas Casemix / Klaim JKN RS</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">RSUD H. Abdul Manap Kota Jambi</div>
  </div>
  <div class="rm-sig-box">
    <div>Diterima &amp; Diverifikasi Oleh,</div>
    <div>Verifikator BPJS Kesehatan</div>
    <div class="rm-sig-space"></div>
    <div class="rm-sig-name">( .................................................. )</div>
    <div class="rm-sig-sub">NPP. ............................................</div>
  </div>
</div>
</section>`,R=i,E=new Map,U=R.map((S,f)=>{let A=Xt(S.title,f),g=(E.get(A.id)??0)+1;return E.set(A.id,g),g===1?A:{...A,id:`${A.id}-${g}`,tab:`${A.tab} (${g})`,option:`${A.option} (${g})`}}),$=R.map((S,f)=>{let A=U[f];return/^SEP$/i.test(S.title)?Vt(i):/^Surat (?:Rencana )?Kontrol/i.test(S.title)?aa(i):/^SPRI$/i.test(S.title)?Zt(i):/^SBPK$/i.test(S.title)?ta(i):/^Rincian Biaya/i.test(S.title)?ia(i):/^Resume/i.test(S.title)?ea(i):/^Telaah/i.test(S.title)?Ma(i):/^Radiologi/i.test(S.title)?ua(i,S,A.id):/^Triage/i.test(S.title)?la(i):/PENGKAJIAN INSTALASI GAWAT DARURAT/i.test(S.title)?ja(i):/^Laboratorium/i.test(S.title)?wa(i):/Konsul/i.test(S.title)?Ta(i,S,A.id):/^Persetujuan Tindakan/i.test(S.title)?Aa(i):/^Anestesi/i.test(S.title)?ca(i):/^Fisioterapi/i.test(S.title)?ga(i):/^Pengkajian Hemodialisa/i.test(S.title)?Na(i):/^Operasi/i.test(S.title)?ma(i):/^Surat Kematian/i.test(S.title)?pa(i):/^Permintaan Terapi/i.test(S.title)?ya(i):/^Uji Fungsi/i.test(S.title)?Da(i):/^Partograf/i.test(S.title)?xa(i):/^Laporan Tindakan/i.test(S.title)?Ea(i):/^Bon Makan/i.test(S.title)?ka(i):/^PEMERIKSAAN$/i.test(S.title)?Ca(i):`<section class="rm-page" id="${A.id}">
${J(A.code)}
<div class="rm-form-title">${t(S.title)}</div>
<div class="doc-body">${S.html}</div>
</section>`}).join(""),Y=['<button type="button" class="tab-btn active" data-target="all">Semua</button>','<button type="button" class="tab-btn" data-target="rm-00">RM. 00 Kendali</button>',...R.map((S,f)=>{let A=U[f];return`<button type="button" class="tab-btn" data-target="${A.id}">${A.tab}</button>`})].join(""),w=['<option value="all">Semua Formulir RM</option>','<option value="rm-00">RM. 00 \u2014 Lembar Kendali &amp; Verifikasi</option>',...R.map((S,f)=>{let A=U[f];return`<option value="${A.id}">${A.option}</option>`})].join("");return`<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<base href="${t(location.origin)}">
<title>Formulir Rekam Medis Baku \u2014 Dossier Klaim BPJS ${t(St)}</title>
<style>
    /* ==========================================================================
       1. RESET & AUTHENTIC INDONESIAN HOSPITAL RM FORM TOKENS
       Pure Monochrome Black Ink (#000000) on White Paper (#FFFFFF).
       Zero SaaS colors, zero rounded pills/badges, zero drop shadows.
       ========================================================================== */
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      line-height: 1.35;
      color: #000000;
      background-color: #E5E5E5;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    /* ==========================================================================
       2. SCREEN-ONLY VERIFIER TOOLBAR (.no-print)
       ========================================================================== */
    .verifier-toolbar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background-color: #FFFFFF;
      border-bottom: 2px solid #000000;
      padding: 8px 16px;
      font-family: Arial, Helvetica, sans-serif;
    }

    .toolbar-row {
      max-width: 210mm;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }

    .toolbar-group {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
    }

    .toolbar-label {
      font-size: 9pt;
      font-weight: bold;
      text-transform: uppercase;
    }

    .toolbar-select {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 8px;
      cursor: pointer;
    }

    .toolbar-counter {
      font-size: 8.5pt;
      border: 1px solid #000000;
      padding: 3px 8px;
      background-color: #FFFFFF;
    }

    .toolbar-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 4px 10px;
      cursor: pointer;
    }

    .toolbar-btn:hover {
      background-color: #F0F0F0;
    }

    .toolbar-btn-print {
      background-color: #000000;
      color: #FFFFFF;
    }

    .toolbar-btn-print:hover {
      background-color: #222222;
    }

    .toolbar-tabs {
      max-width: 210mm;
      margin: 6px auto 0 auto;
      padding-top: 6px;
      border-top: 1px solid #000000;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .tab-btn {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 7.5pt;
      color: #000000;
      background-color: #FFFFFF;
      border: 1px solid #000000;
      padding: 2px 6px;
      cursor: pointer;
    }

    .tab-btn.active {
      background-color: #000000;
      color: #FFFFFF;
      font-weight: bold;
    }

    /* ==========================================================================
       3. A4 PAPER SHEET CONTAINER (NO DROP SHADOWS)
       ========================================================================== */
    .dossier-wrapper {
      max-width: 210mm;
      margin: 16px auto 40px auto;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .rm-page {
      width: 100%;
      background-color: #FFFFFF;
      border: 1px solid #888888;
      padding: 12mm 14mm;
    }

    .rm-page.hidden-section {
      display: none;
    }

    /* ==========================================================================
       4. OFFICIAL RSUD H. ABDUL MANAP KOP SURAT (TIMES NEW ROMAN + DOUBLE RULE)
       ========================================================================== */
    .rm-code-top {
      text-align: right;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 9pt;
      font-weight: bold;
      margin-bottom: 2px;
      letter-spacing: 0.02em;
    }

    .kop-surat {
      display: flex;
      align-items: center;
      gap: 12px;
      padding-bottom: 5px;
    }

    .kop-logo {
      width: 52px;
      height: 60px;
      flex-shrink: 0;
    }

    .kop-text {
      flex: 1;
      text-align: center;
      font-family: "Times New Roman", Times, serif;
      color: #000000;
      line-height: 1.2;
    }

    .kop-line-1 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-2 {
      font-size: 11pt;
      font-weight: bold;
      letter-spacing: 0.03em;
    }

    .kop-line-3 {
      font-size: 12.5pt;
      font-weight: bold;
      letter-spacing: 0.02em;
      margin-top: 1px;
    }

    .kop-line-4 {
      font-size: 7.5pt;
      font-weight: normal;
      margin-top: 2px;
    }

    .kop-line-5 {
      font-size: 7.5pt;
      font-weight: normal;
    }

    .kop-double-rule {
      border-top: 2px solid #000000;
      height: 2px;
      border-bottom: 0.75px solid #000000;
      margin-bottom: 10px;
    }

    .rm-form-title {
      text-align: center;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 11pt;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 8px;
      letter-spacing: 0.02em;
    }

    /* ==========================================================================
       5. PATIENT IDENTITY BLOCKS (PATTERN A: BORDERED BOX / PATTERN B: BORDERLESS)
       Strict vertical colon ':' alignment (label | 10px ':' | value)
       ========================================================================== */
    .id-box-bordered {
      border: 1px solid #000000;
      padding: 6px 10px;
      margin-bottom: 9px;
      display: flex;
      gap: 16px;
    }

    .id-box-borderless {
      padding: 2px 0;
      margin-bottom: 8px;
      display: flex;
      gap: 16px;
    }

    .id-col {
      flex: 1;
      min-width: 0;
    }

    .id-table {
      width: 100%;
      border-collapse: collapse;
    }

    .id-table td {
      padding: 1.5px 0;
      vertical-align: top;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
      line-height: 1.3;
    }

    .id-table td.lbl {
      width: 118px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.lbl-wide {
      width: 138px;
      white-space: nowrap;
      text-align: left;
    }

    .id-table td.col {
      width: 10px;
      text-align: center;
    }

    .id-table td.val {
      text-align: left;
    }

    /* ==========================================================================
       6. FULL-GRID RM TABLES (border: 1px solid #000 ON ALL TH & TD)
       ========================================================================== */
    .rm-grid-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 8px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-grid-table th,
    .rm-grid-table td {
      border: 1px solid #000000;
      padding: 4px 6px;
      vertical-align: top;
      color: #000000;
    }

    .rm-grid-table th {
      font-size: 8.5pt;
      font-weight: bold;
      text-align: center;
      vertical-align: middle;
      background-color: #FFFFFF;
    }

    .rm-grid-table td.center,
    .rm-grid-table th.center {
      text-align: center;
      vertical-align: middle;
    }

    .rm-grid-table td.num,
    .rm-grid-table th.num {
      text-align: right;
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
    }

    .rm-grid-table td.nowrap {
      white-space: nowrap;
    }

    .rm-grid-table tr.section-banner td {
      font-weight: bold;
      font-size: 8.5pt;
      text-transform: uppercase;
      padding: 4px 6px;
    }

    .rm-grid-table tr.sub-group td {
      font-weight: bold;
      text-decoration: underline;
      padding-top: 5px;
      padding-bottom: 4px;
    }

    .rm-grid-table tr.total-row td {
      font-weight: bold;
      padding: 5px 6px;
    }

    /* Square 11px x 11px Interactive Verification Checkbox */
    .rm-checkbox {
      appearance: none;
      -webkit-appearance: none;
      width: 11px;
      height: 11px;
      border: 1px solid #000000;
      border-radius: 0;
      background-color: #FFFFFF;
      display: inline-grid;
      place-content: center;
      vertical-align: middle;
      cursor: pointer;
    }

    .rm-checkbox::before {
      content: "\u2713";
      font-size: 9px;
      font-weight: bold;
      line-height: 1;
      color: #000000;
      transform: scale(0);
    }

    .rm-checkbox:checked::before {
      transform: scale(1);
    }

    /* Static printed checkbox symbol for clinical forms */
    .static-box {
      display: inline-block;
      width: 10px;
      height: 10px;
      border: 1px solid #000000;
      text-align: center;
      line-height: 9px;
      font-size: 8px;
      font-weight: bold;
      margin-right: 4px;
      vertical-align: middle;
    }

    .sub-heading-rm {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 7px 0 4px 0;
    }

    .footnote-rm {
      font-size: 7.5pt;
      margin-top: 4px;
      line-height: 1.35;
    }

    /* ==========================================================================
       7. ATOMIC SIGNATURE FOOTER (break-inside: avoid)
       ========================================================================== */
    .rm-signature-block {
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 20px;
      break-inside: avoid;
      page-break-inside: avoid;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.2pt;
    }

    .rm-sig-box {
      width: 44%;
      text-align: center;
    }

    .rm-sig-box.left-align {
      text-align: left;
    }

    .rm-sig-space {
      height: 44px;
    }

    .rm-sig-name {
      font-weight: bold;
    }

    .rm-sig-sub {
      font-size: 7.5pt;
    }

    /* ==========================================================================
       8. SECTION 04 \u2014 FILE UPLOAD ORIGINAL PASSTHROUGH (NOT REDESIGNED)
       ========================================================================== */
    .passthrough-separator {
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      padding: 4px 6px;
      margin-bottom: 10px;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 8.5pt;
      font-weight: bold;
      text-transform: uppercase;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .raw-upload-frame {
      border: 1px solid #000000;
      padding: 8px 10px;
      margin-bottom: 12px;
      font-family: "Times New Roman", Times, serif;
      font-size: 8.5pt;
      break-inside: avoid;
    }

    .raw-upload-table {
      width: 100%;
      border-collapse: collapse;
      margin: 6px 0;
      font-size: 8pt;
    }

    .raw-upload-table th,
    .raw-upload-table td {
      border: 1px solid #000000;
      padding: 2px 4px;
    }

    /* ==========================================================================
       9. PRINT MEDIA RULES (@media print \u2014 A4 PORTRAIT, 12MM MARGIN)
       ========================================================================== */
    @media print {
      @page {
        size: A4 portrait;
        margin: 12mm;
      }

      body {
        background-color: #FFFFFF !important;
        margin: 0;
        padding: 0;
      }

      .no-print,
      .verifier-toolbar {
        display: none !important;
      }

      .dossier-wrapper {
        max-width: 100%;
        margin: 0;
        gap: 0;
      }

      .rm-page {
        border: none !important;
        padding: 0 !important;
        margin: 0 !important;
        break-after: page;
        page-break-after: always;
      }

      .rm-page:last-child {
        break-after: auto;
        page-break-after: auto;
      }

      .rm-page.hidden-section {
        display: none !important;
      }

      thead {
        display: table-header-group;
      }

      tr,
      .rm-signature-block,
      .id-box-bordered {
        break-inside: avoid;
        page-break-inside: avoid;
      }
    }

    @media (max-width: 720px) {
      .rm-page {
        padding: 12px;
      }
      .id-box-bordered,
      .id-box-borderless {
        flex-direction: column;
        gap: 4px;
      }
      .rm-signature-block {
        flex-direction: column;
        gap: 14px;
      }
      .rm-sig-box {
        width: 100%;
      }
    }

/* \u2500\u2500 Tambahan generator: komponen hasil scrape & fokus keyboard \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.kop-logo{object-fit:contain;object-position:center}
/* SEP BPJS \u2014 cetakan VClaim (sheet menggantikan kop RSUD) */
.rm-page.sep-page{padding:0}
.bpjs-sep-sheet{width:210mm;max-width:100%;margin:0 auto;padding:10mm 14mm;background:#fff;color:#000;font:9.5pt/1.38 Arial,Helvetica,sans-serif;box-sizing:border-box;break-inside:avoid;page-break-inside:avoid}
.sep-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;position:relative}
.sep-logo{flex:0 0 215px;width:215px;height:33px;object-fit:contain;object-position:left center}
.sep-title-wrap{flex:0 0 auto;text-align:right;padding-right:0}
.sep-title{font-size:10.5pt;font-weight:400;letter-spacing:.3px;text-transform:uppercase}
.sep-hospital{font-size:10.5pt;text-transform:uppercase}
.sep-columns{display:flex;justify-content:space-between;gap:18px}
.sep-col-left{flex:0 0 56%}
.sep-col-right{flex:0 0 42%;display:flex;flex-direction:column;justify-content:space-between}
.sep-kv-table{width:100%;border-collapse:collapse}
.sep-kv-table td{padding:1.8px 0;vertical-align:top;border:none}
.sep-kv-table td.lbl{width:102px;white-space:nowrap}
.sep-col-right .sep-kv-table td.lbl{width:92px}
.sep-kv-table td.sep{width:12px;text-align:center}
.sep-kv-table td.val{word-break:break-word}
.sep-no-value{font-size:9.5pt;letter-spacing:.2px}
.sep-inline-mr{margin-left:14px;white-space:nowrap}
.sep-multiline-list{margin:0;padding:0;list-style:none}
.sep-disclaimer{margin-top:10px;font-size:7.5pt;font-style:italic}
.sep-print-meta{font-size:9.5pt;font-style:normal}
/* Isi/body SEP seragam 9.5pt \u2014 kecuali disclaimer (7.5pt italic). */
.sep-signatures{display:flex;justify-content:flex-end;gap:16px;margin-top:18px}
.sep-sig-box{flex:0 0 44%;font-size:9.5pt;line-height:1.25;text-align:center}
.sep-sig-role{min-height:24px}
.sep-sig-name{margin-top:2px;font-weight:bold}
.sep-qr{display:block;margin:2px auto;width:100px;height:100px;object-fit:contain}
.rm-sig-qr{display:block;width:80px;height:80px;margin:0 auto 4px;object-fit:contain}
/* @page A4 portrait 12mm ditetapkan sekali di blok print utama \u2014 jangan
   ditimpa di sini supaya margin semua halaman dossier konsisten. */
@media print{body{background:#fff;padding:0}.bpjs-sep-sheet{width:100%;padding:0}}
@media screen{body{background:#e5e7eb;padding:20px}.bpjs-sep-sheet{box-shadow:0 1px 4px rgba(0,0,0,.15)}}
/* Telaah (RM.07) \u2014 grid 2 kolom ala telaahResepPrint.ts */
.t-main{display:grid;grid-template-columns:62% 38%;gap:8px;align-items:start}
.t-left,.t-right{display:flex;flex-direction:column;gap:5px;min-width:0}
.tm-card{padding:2px 0 4px;margin-bottom:4px;border-bottom:.5pt solid #333}
.tm-col{display:flex;flex-direction:column;gap:2px}
.tm-row{display:grid;grid-template-columns:30% 70%;column-gap:4px;align-items:start}
.tm-row.long{display:grid}
.tm-label{font-size:7.5pt;line-height:1.25;color:#333}
.tm-val{font-size:8pt;line-height:1.25;overflow-wrap:anywhere}
.t-meds{font-size:8pt;margin-bottom:6px}
.med{margin-bottom:3px;line-height:1.3}
.med-no{font-weight:400}
.med-name{font-weight:700}
.med-jml{font-weight:700;white-space:nowrap}
.t-lampiran th{font-size:7.5pt}
.rm-summary{margin:8px 0 10px;font-size:8.5pt}
.rm-sum-line{display:flex;align-items:baseline;gap:6px;padding:1px 0}
.rm-sum-line .rm-sum-dots{flex:1;border-bottom:1px dotted #000;transform:translateY(-3px)}
.rm-checkbox:focus-visible,.vbox:focus-visible,.toolbar-btn:focus-visible,.toolbar-select:focus-visible,.tab-btn:focus-visible{outline:2px solid #000000;outline-offset:2px}
.vbox{appearance:none;-webkit-appearance:none;width:11px;height:11px;margin:0;border:1px solid #000000;border-radius:0;background-color:#FFFFFF;display:inline-grid;place-content:center;vertical-align:middle;cursor:pointer}
.vbox::before{content:"\u2713";font-size:9px;font-weight:bold;line-height:1;color:#000000;transform:scale(0)}
.vbox:checked::before{transform:scale(1)}
.doc-body table{width:100%!important;border-collapse:collapse!important;margin:0 0 8px!important;font-size:8.2pt!important}
.doc-body th,.doc-body td{border:1px solid #000000!important;padding:3px 5px!important;vertical-align:top;color:#000000!important;overflow-wrap:anywhere}
.doc-body th{background-color:#FFFFFF!important;font-weight:bold;text-align:center}
.doc-body h1,.doc-body h2,.doc-body h3{font-size:9.5pt;margin:6px 0}
.doc-body p{margin:2px 0}
.doc-body label{min-width:100px;font-weight:600;color:#333333}
.doc-body .fv{font-weight:500}
.doc-body img{max-width:100%!important;height:auto!important}
.doc-body .panel,.doc-body .isidalam,.doc-body .card{border:0!important;box-shadow:none!important;padding:0!important;margin:0!important;width:100%!important}
.doc-body .vcol{width:16px!important;text-align:center!important}
.telaah-layout{display:flex;gap:8px;align-items:stretch;margin:0 0 6px}
.telaah-layout table{flex:1;margin-bottom:0}
.img-wrap{display:inline-block;max-width:100%}
.img-tools{display:flex;gap:6px;justify-content:flex-end;margin:0 0 5px}
.img-tools button{font-family:inherit;font-size:10px;padding:3px 9px;border:1px solid #000000;background-color:#FFFFFF;cursor:pointer}
</style></head><body>
<style>
    /* IGD: gambar asal MORBIS (skala nyeri Wong Baker & gambar objektif)
       ikut tercetak, dirapikan sebagai figure + keterangan. */
    .rm-figure { margin: 0 0 8px; break-inside: avoid; text-align: center; }
    .rm-figure img { max-width: 100%; height: auto; border: 1px solid #000000; }
    .rm-figure figcaption { margin-top: 3px; font-size: 7pt; text-transform: uppercase; letter-spacing: 0.04em; }
    .rm-figure-row { display: flex; gap: 10px; align-items: flex-start; break-inside: avoid; }
    .rm-figure-row .rm-figure { flex: 0 0 46%; margin: 0; }
    .rm-figure-row .rm-grid-table { flex: 1; min-width: 0; }
    .rm-note { border: 1px solid #000000; padding: 6px 8px; margin-bottom: 8px; font-size: 8.2pt; line-height: 1.4; break-inside: avoid; }

    /* Bahasa visual RM baku: banner bagian bernomor, tabel full-grid, kotak
       centang statis \u2014 mengikuti prototipe referensi RM.02/IGD. */
    .rm-table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-family: Arial, Helvetica, sans-serif; font-size: 8pt; line-height: 1.28; }
    .rm-table th, .rm-table td { border: 1px solid #000000; padding: 3px 5px; vertical-align: top; }
    .rm-table th { font-weight: bold; text-align: center; vertical-align: middle; }
    .rm-table tr.sec-hdr td { font-weight: bold; font-size: 8.5pt; text-transform: uppercase; padding: 4px 5px; letter-spacing: 0.01em; }
    .chk-box { display: inline-block; width: 9.5px; height: 9.5px; border: 1px solid #000000; text-align: center; line-height: 8.5px; font-size: 7.5pt; font-weight: bold; margin-right: 3px; vertical-align: middle; }
    .opt-item { display: inline-block; margin-right: 10px; white-space: nowrap; }
    .filter-note { font-size: 7.3pt; font-style: italic; }
    .two-col-grid { display: flex; gap: 6px; margin-bottom: 8px; align-items: stretch; }
    .two-col-grid > .col-half { flex: 1; min-width: 0; }
    .rm-top-meta { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px; font-size: 8.5pt; font-weight: bold; }
    .running-header-box { border: 1px solid #000000; padding: 4px 8px; margin-bottom: 6px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; font-size: 7.8pt; }

    /* Editorial clinical: nomor urut otomatis, kepala pasien, dan ringkasan
       data kritis \u2014 tetap tinta hitam di atas kertas A4. */
    #pengkajian-igd { counter-reset: igdsec; }
    #pengkajian-igd .sub-heading-rm {
      counter-increment: igdsec;
      position: relative;
      padding: 3px 0 3px 30px;
      border-bottom: 1px solid #000000;
    }
    #pengkajian-igd .sub-heading-rm::before {
      content: counter(igdsec, decimal-leading-zero);
      position: absolute;
      left: 0;
      top: 3px;
      font-size: 7pt;
      font-weight: normal;
      letter-spacing: 0.08em;
    }
    .igd-masthead { margin-bottom: 9px; }
    .igd-masthead-label { font-size: 7pt; letter-spacing: 0.14em; text-transform: uppercase; }
    .igd-masthead-name {
      font-size: 17pt;
      font-weight: bold;
      line-height: 1.15;
      margin: 2px 0 6px;
      letter-spacing: -0.02em;
    }
    .igd-summary {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1.4fr;
      border-top: 2px solid #000000;
      border-bottom: 1px solid #000000;
      margin: 0 0 9px;
    }
    .igd-summary > div { padding: 5px 8px; border-left: 1px solid #000000; }
    .igd-summary > div:first-child { border-left: 0; padding-left: 0; }
    .igd-summary span { display: block; font-size: 6.5pt; letter-spacing: 0.1em; text-transform: uppercase; }
    .igd-summary b { display: block; font-size: 11pt; line-height: 1.25; margin-top: 2px; }
    .igd-band-value { font-size: 11pt !important; font-weight: bold; }

    /* Laporan Operasi (RM.20) \u2014 tabel label:nilai tanpa garis di dalam kotak,
       narasi pembedahan dipecah jadi langkah bernomor. */
    #form-operasi .op-kv { width: 100%; border-collapse: collapse; }
    #form-operasi .op-kv td { border: none; padding: 1.5px 0; vertical-align: top; font-size: 8.2pt; line-height: 1.3; }
    #form-operasi .op-kv td.k { width: 132px; white-space: nowrap; }
    #form-operasi .op-kv td.c { width: 10px; text-align: center; }
    #form-operasi .op-kv td.v { overflow-wrap: anywhere; }
    #form-operasi .op-narrative { padding: 6px 8px; line-height: 1.45; }
    #form-operasi .op-preface { margin-bottom: 5px; padding-bottom: 5px; border-bottom: 1px dashed #666666; }
    #form-operasi .op-steps { margin: 3px 0 0; padding-left: 18px; }
    #form-operasi .op-steps li { margin-bottom: 2px; }

    /* Laporan Anestesi (RM.21) \u2014 2 halaman A4, grafik terkunci, 3 TTE sejajar. */
    #form-anestesi .an-meta { display: flex; justify-content: space-between; font-size: 8pt; font-weight: bold; margin-bottom: 2px; }
    #form-anestesi .an-subtitle { text-align: center; font-size: 8.5pt; letter-spacing: 0.08em; margin: -4px 0 6px; }
    #form-anestesi .an-kv { width: 100%; border-collapse: collapse; }
    #form-anestesi .an-kv td { border: none; padding: 1.5px 0; vertical-align: top; font-size: 8.2pt; line-height: 1.3; }
    #form-anestesi .an-kv td.k { width: 112px; white-space: nowrap; }
    #form-anestesi .an-kv td.c { width: 10px; text-align: center; }
    #form-anestesi .an-kv td.v { overflow-wrap: anywhere; }
    #form-anestesi .an-grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 2px 6px; font-size: 8pt; }
    #form-anestesi .an-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px 8px; font-size: 7.8pt; margin-top: 2px; }
    #form-anestesi .an-risk { margin-top: 4px; padding-top: 4px; border-top: 1px dashed #666666; }
    #form-anestesi .chart-frame { padding: 4px; text-align: center; border: 1px solid #000000; break-inside: avoid; page-break-inside: avoid; }
    #form-anestesi .chart-frame img { max-width: 100%; height: auto; }
    #form-anestesi .an-page-break { page-break-before: always; break-before: page; }
    #form-anestesi .an-running { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; border-bottom: 1.5px solid #000000; padding-bottom: 4px; margin: 0 0 7px; font-size: 8pt; }
    #form-anestesi .an-instruksi { margin: 0; padding-left: 18px; line-height: 1.4; font-size: 8.2pt; }
    #form-anestesi .an-tte-note { font-size: 7.6pt; margin-top: 4px; }
    #form-anestesi .an-tte { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 8px; break-inside: avoid; page-break-inside: avoid; }
    #form-anestesi .an-tte .tte-box { border: 1px solid #000000; padding: 5px 4px; text-align: center; font-size: 8pt; }
    #form-anestesi .an-tte .tte-qr { width: 54px; height: 54px; margin: 4px auto; border: 1px solid #000000; padding: 2px; display: flex; align-items: center; justify-content: center; }
    #form-anestesi .an-tte .tte-name { font-weight: bold; text-decoration: underline; }
</style>
<header class="verifier-toolbar no-print"><div class="toolbar-row">
<div class="toolbar-group"><span class="toolbar-label">Formulir RM Klaim BPJS:</span><select id="rmSectionSelect" class="toolbar-select" aria-label="Pilih Formulir RM">${w}</select></div>
<div class="toolbar-group"><span class="toolbar-counter">Tanda Verifikator (&#10003;): <strong id="checkCounter">0 / 0</strong></span>
<button type="button" class="toolbar-btn" id="btnCheckAll">Centang Semua</button>
<button type="button" class="toolbar-btn" id="btnResetChecks">Reset</button>
<button type="button" class="toolbar-btn toolbar-btn-print" id="btnPrintPdf">Cetak / Simpan PDF (A4)</button></div>
</div><nav id="rmTabs" class="toolbar-tabs" aria-label="Navigasi Formulir RM">${Y}</nav></header>
<main class="dossier-wrapper">${B}${$}</main>
</body></html>`}async function za(){let i=a=>{let e=getComputedStyle(a);return e.display!=="none"&&e.visibility!=="hidden"&&Number(e.opacity)>0},u=Date.now()+3e3;for(;Date.now()<u&&[".swal2-container",".swal-overlay--active",".sweet-alert"].flatMap(a=>Array.from(document.querySelectorAll(a))).some(i);)await new Promise(a=>window.setTimeout(a,150));await new Promise(a=>window.setTimeout(a,50))}function fa(i){let u=window.open("","_blank");if(!u)return!1;try{return u.document.open(),u.document.write(i),u.document.close(),$t(u),!0}catch{return!1}}async function zt(){let i=document.getElementById("ext-mklaim-print-btn"),u=i?.textContent||"Cetak Rapi M-KLAIM";i&&(i.disabled=!0,i.textContent="Memproses\u2026",i.style.opacity="0.7");try{await za();let{sections:a,inventory:e}=xt();if(a.length<3&&(await new Promise(l=>window.setTimeout(l,800)),{sections:a,inventory:e}=xt()),!a.length){window.alert("Tidak ada section berkas yang bisa dicetak.");return}let n=ha(a,e);if(fa(n))return;let L;for(let l of[0,300,600]){l&&await new Promise(d=>window.setTimeout(d,l));try{if(!(await chrome.runtime.sendMessage({type:"OPEN_PRINT_DOSSIER",html:n}))?.success)throw new Error("background menolak membuka tab");return}catch(d){L=d;let x=d instanceof Error?d.message:String(d);if(!/Receiving end does not exist|Extension context invalidated/i.test(x))break}}let s=L instanceof Error?L.message:String(L||"");chrome.runtime?.id?window.alert(`Gagal membuka dossier: ${s||"tidak diketahui"}. Refresh halaman M-KLAIM (Ctrl+Shift+R) lalu coba lagi.`):window.alert("Ekstensi diperbarui, refresh halaman M-KLAIM (Ctrl+Shift+R) lalu klik lagi Cetak Rapi.")}finally{i&&(i.disabled=!1,i.textContent=u,i.style.opacity="1")}}function va(){let i=Array.from(document.querySelectorAll("button.btn-success")).find(u=>/^printDiv\s*\(/i.test(u.getAttribute("onclick")||""));return i?.parentElement?i.parentElement:Array.from(document.querySelectorAll('div[style*="text-align:right"]')).find(u=>u.querySelector("button"))||document.getElementById("SCETAK")||document.body}var pt="v2";function ft(){if(!window.location.pathname.includes("/v2/m-klaim/detail-v2-refaktor"))return;let i=document.getElementById("ext-mklaim-print-btn");if(i?.dataset.extBuild===pt)return;i?.remove();let u=va(),a=document.createElement("button");a.id="ext-mklaim-print-btn",a.dataset.extBuild=pt,a.type="button",a.className="btn btn-primary btn-sm",a.style.cssText="margin-left:8px;background:#0f766e;border-color:#0f766e;color:#fff;font-weight:600;border-radius:4px;padding:5px 12px;cursor:pointer;white-space:nowrap;",a.textContent="Cetak Rapi M-KLAIM",a.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),zt()}),u.appendChild(a)}window.extMklaimPrintNow=zt,typeof yt.featureModules<"u"&&(yt.featureModules.mKlaimPrint={id:"mKlaimPrint",name:"Cetak Rapi M-KLAIM",description:"Dossier cetak A4 profesional: semua section berkas klaim disusun rapi di tab baru",match:{prefix:"/v2/m-klaim/detail-v2-refaktor"},run:()=>{let i=()=>ft();document.readyState==="complete"?window.setTimeout(i,500):window.addEventListener("load",()=>window.setTimeout(i,500));let u=()=>{let a=document.getElementById("ext-mklaim-print-btn");if(a?.dataset.extBuild!==pt){ft();return}a.parentElement&&a.parentElement.lastElementChild!==a&&a.parentElement.appendChild(a)};new MutationObserver(()=>u()).observe(document.body,{childList:!0,subtree:!0}),window.setInterval(u,1500)}})})();
