"use strict";var __morbis_feature=(()=>{var k=Object.defineProperty;var G=Object.getOwnPropertyDescriptor;var N=Object.getOwnPropertyNames;var U=Object.prototype.hasOwnProperty;var D=(e,t)=>{for(var o in t)k(e,o,{get:t[o],enumerable:!0})},O=(e,t,o,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of N(t))!U.call(e,r)&&r!==o&&k(e,r,{get:()=>t[r],enumerable:!(n=G(t,r))||n.enumerable});return e};var _=e=>O(k({},"__esModule",{value:!0}),e);var ae={};D(ae,{applySelectAll:()=>j,clearSelection:()=>m,getSelected:()=>P,initMKlaimBulkVerifFeature:()=>K,isEligible:()=>z,parseIdVisit:()=>W,pruneSelection:()=>H});function S(){return window}var B="ext-batch-shared-style";function y(){if(document.getElementById(B))return;let e=document.createElement("style");e.id=B,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function I(e,t,o=2){let n=r=>fetch(e,t).catch(a=>{if(r<=0)throw a;return new Promise(i=>setTimeout(i,1e3*(3-r))).then(()=>n(r-1))});return n(o)}function x(e){return new Promise(t=>{y();let o=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",n=document.createElement("div");n.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",n.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${o}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,n.querySelector("h3").textContent=e.title;let r=n.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((l,c)=>{c>0&&r.appendChild(document.createElement("br")),r.appendChild(document.createTextNode(l))});let a=l=>{n.remove(),document.removeEventListener("keydown",i),t(l)},i=l=>{l.key==="Escape"&&a(!1)};n.querySelector(".ext-modal-close").addEventListener("click",()=>a(!1)),n.addEventListener("click",l=>{l.target===n&&a(!1)}),n.querySelector("[data-ext-ok]").addEventListener("click",()=>a(!0));let d=n.querySelector("[data-ext-cancel]");d&&d.addEventListener("click",()=>a(!1)),document.addEventListener("keydown",i),document.body.appendChild(n)})}var $=S(),s={endpointVerif:"/v2/m-klaim/control/verif",endpointBatal:"/v2/m-klaim/control/batal-verif",delayMs:600,barId:"ext-bulk-verif-bar",cssId:"ext-bulk-verif-style",readyTimeoutMs:15e3,readyPollMs:250,warnIfMoreThan:100},f=[{sel:"#data-table",kind:"main",nama:"Klaim",aksi:"Verif",endpoint:s.endpointVerif,danger:!1},{sel:"#data-table-verif",kind:"verif",nama:"Sudah Terverifikasi",aksi:"Batal Verif",endpoint:s.endpointBatal,danger:!0}],u={main:new Set,verif:new Set},b=!1;function j(e,t,o){let n=0;return t.forEach(r=>{!r.id||!r.eligible||(o?u[e].add(r.id):u[e].delete(r.id),n+=1)}),n}function H(e,t){let o=new Set;t.forEach(r=>{r.id&&r.eligible&&o.add(r.id)});let n=0;return Array.from(u[e]).forEach(r=>{o.has(r)||(u[e].delete(r),n+=1)}),n}function P(e){return Array.from(u[e])}function m(e){u[e].clear()}function W(e){let t=e.match(/\d+/);return t?t[0]:null}function z(e,t,o){return t?e==="main"?!0:o:!1}function Q(){if(document.getElementById(s.cssId))return;let e=document.createElement("style");e.id=s.cssId,e.textContent=`
    #${s.barId} {
      position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
      z-index: 2147482000; display: none; align-items: center; gap: 14px;
      background: #0f172a; color: #f8fafc; border-radius: 12px;
      padding: 10px 16px; font-family: 'Inter', system-ui, sans-serif;
      font-size: 13px; box-shadow: 0 8px 28px rgba(15,23,42,.35);
    }
    #${s.barId} .bv-item { display: flex; align-items: center; gap: 8px; }
    #${s.barId} .bv-label { color: #cbd5e1; }
    #${s.barId} .bv-count { color: #f8fafc; font-weight: 700; }
    #${s.barId} button {
      border: none; border-radius: 8px; cursor: pointer; padding: 7px 14px;
      font-size: 12.5px; font-weight: 700; font-family: inherit;
    }
    #${s.barId} .bv-aksi { background: #2563eb; color: #fff; }
    #${s.barId} .bv-aksi:hover { background: #1d4ed8; }
    #${s.barId} .bv-aksi-danger { background: #dc2626; color: #fff; }
    #${s.barId} .bv-aksi-danger:hover { background: #b91c1c; }
    #${s.barId} .bv-reset { background: #334155; color: #e2e8f0; }
    #${s.barId} .bv-reset:hover { background: #475569; }
    #${s.barId} button:disabled { opacity: .55; cursor: not-allowed; }

    .bv-check {
      display: inline-flex; align-items: center; justify-content: center;
      margin-right: 6px; vertical-align: middle; cursor: pointer;
    }
    .bv-check input { width: 14px; height: 14px; cursor: pointer; margin: 0; }
    .bv-check input:disabled { cursor: not-allowed; }
    th.bv-th-head { width: 26px; }
  `,document.head.appendChild(e),y()}function p(e){return document.querySelector(e.sel)}function R(e){let t=window.jQuery;if(!t)return null;try{return t(e.sel).DataTable()??null}catch{return null}}function q(e){return(Array.isArray(e)?e:[e]).filter(t=>t instanceof HTMLElement)}function w(e){let t=e.querySelector('button[onclick*="detail("]');if(t){let n=(t.getAttribute("onclick")||"").match(/\d+/);if(n)return n[0]}let o=e.querySelector('button[onclick*="BatalVerif("]');if(o){let n=(o.getAttribute("onclick")||"").match(/\d+/);if(n)return n[0]}return null}function T(e,t){return z(e.kind,!!t.querySelector('button[onclick*="detail("]'),!!t.querySelector('button[onclick*="BatalVerif("]'))}function A(e,t){return{id:w(t),eligible:T(e,t)}}function F(e){let t=p(e);if(!t)return[];let o=R(e);if(o)try{return q(o.rows({search:"applied"}).nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(n=>!n.classList.contains("dataTables_empty"))}function X(e){let t=p(e);if(!t)return[];let o=R(e);if(o)try{return q(o.rows().nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(n=>!n.classList.contains("dataTables_empty"))}function Y(e,t){let o=w(t),n=t.querySelector("td");if(!o||!n)return;let r=T(e,t),a=document.createElement("span");a.className="bv-check";let i=document.createElement("input");i.type="checkbox",i.dataset.extBvId=o,i.disabled=!r,i.checked=u[e.kind].has(o),i.title=r?"Pilih baris ini":"Baris tidak memenuhi syarat aksi ini",r||(a.title=i.title),i.addEventListener("change",()=>{i.checked?u[e.kind].add(o):u[e.kind].delete(o),g(),v(e)}),a.appendChild(i),n.insertBefore(a,n.firstChild)}function J(e){e.querySelectorAll("tbody .bv-check").forEach(t=>t.remove())}function E(e){let t=p(e);t&&(J(t),t.querySelectorAll("tbody tr").forEach(o=>Y(e,o)),v(e))}function v(e){let o=p(e)?.querySelector("thead input[data-ext-bv-header]");if(!o)return;let n=F(e).filter(i=>T(e,i)),r=n.length,a=n.filter(i=>{let d=w(i);return!!d&&u[e.kind].has(d)}).length;o.disabled=b||r===0,o.checked=r>0&&a===r,o.indeterminate=a>0&&a<r}function Z(e){let o=p(e)?.querySelector("thead th");if(!o)return;if(o.dataset.extBvHeader==="1"){v(e);return}o.classList.add("bv-th-head");let n=document.createElement("span");n.className="bv-check",n.title="Pilih / batal pilih semua baris yang cocok dengan pencarian";let r=document.createElement("input");r.type="checkbox",r.dataset.extBvHeader="1",r.addEventListener("change",()=>{let a=F(e).map(i=>A(e,i));j(e.kind,a,r.checked),E(e),g()}),n.appendChild(r),o.insertBefore(n,o.firstChild),o.dataset.extBvHeader="1"}function h(){f.forEach(e=>{p(e)&&(Z(e),E(e))}),g()}function L(){return document.getElementById(s.barId)}function g(){let e=L();if(!e)return;let t=f.map(n=>[n,u[n.kind].size]).filter(([,n])=>n>0);if(t.length===0||b){e.style.display="none";return}e.innerHTML="",t.forEach(([n,r])=>{let a=document.createElement("div");a.className="bv-item";let i=document.createElement("span");i.className="bv-label",i.textContent=`${n.nama}: `;let d=document.createElement("span");d.className="bv-count",d.textContent=`${r} dipilih`;let l=document.createElement("button");l.className=n.danger?"bv-aksi bv-aksi-danger":"bv-aksi",l.textContent=n.aksi,l.addEventListener("click",()=>{oe(n)}),a.append(i,d,l),e.appendChild(a)});let o=document.createElement("button");o.className="bv-reset",o.textContent="Batal Pilih",o.addEventListener("click",()=>{f.forEach(n=>m(n.kind)),h()}),e.appendChild(o),e.style.display="flex"}function ee(){if(L())return;let e=document.createElement("div");e.id=s.barId,e.style.display="none",document.body.appendChild(e)}async function te(e,t){try{let o=new URLSearchParams({id_visit:t}),n=await I(e,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:o.toString(),credentials:"same-origin"});if(!n.ok)return{id:t,ok:!1,pesan:`HTTP ${n.status}`};let r=await n.json(),a=String(r.kode)==="200";return{id:t,ok:a,pesan:r.message??(a?"Sukses":"Gagal")}}catch(o){return{id:t,ok:!1,pesan:o.message||"Gagal koneksi"}}}function ne(e){let t=X(e).map(n=>A(e,n)),o=H(e.kind,t);return{valid:P(e.kind),gugur:o}}async function oe(e){if(b)return;let{valid:t,gugur:o}=ne(e);if(t.length===0){m(e.kind),h(),await x({title:"Tidak ada baris yang bisa diproses",message:"Pilihan tidak lagi cocok dengan data di tabel. Silakan pilih ulang.",okLabel:"Mengerti",hideCancel:!0});return}let n=Math.ceil(t.length*s.delayMs/1e3),r=[`${e.nama}: ${t.length} baris akan diproses.`];if(o>0&&r.push(`${o} pilihan diabaikan (data berubah/tidak memenuhi syarat).`),r.push(e.danger?"Verifikasi yang dibatalkan kembali ke daftar belum terverifikasi.":"Data yang tidak memenuhi syarat akan ditolak server."),t.length>s.warnIfMoreThan&&r.push(`PERINGATAN: jumlah besar, proses \xB1${n} detik. Jangan tutup halaman.`),r.push("Lanjutkan?"),!await x({title:`${e.aksi} ${t.length} data?`,message:r.join(`
`),variant:e.danger?"danger":"primary",okLabel:`Ya, ${e.aksi}`,cancelLabel:"Batal"}))return;b=!0,f.forEach(c=>v(c)),g();let i=[],d=0;for(let c=0;c<t.length;c+=1){let C=await te(e.endpoint,t[c]);C.ok?d+=1:i.push(C);let M=L()?.querySelector(".bv-label");M&&(M.textContent=`${e.nama} (${c+1}/${t.length}): `),c<t.length-1&&await new Promise(V=>setTimeout(V,s.delayMs))}b=!1,m(e.kind),h();let l=[`${e.aksi} selesai.`,`Berhasil: ${d} dari ${t.length}`];i.length>0&&(l.push("",`Gagal: ${i.length}`),i.slice(0,10).forEach(c=>l.push(`#${c.id} - ${c.pesan}`)),i.length>10&&l.push(`... dan ${i.length-10} lainnya`)),await x({title:"Hasil",message:l.join(`
`),okLabel:"Muat ulang tabel",hideCancel:!0}),window.location.reload()}function re(){return new Promise(e=>{let t=Date.now(),o=()=>{if(f.some(r=>p(r))||Date.now()-t>s.readyTimeoutMs){e();return}setTimeout(o,s.readyPollMs)};o()})}function ie(){let e=window.jQuery;e&&f.forEach(t=>{if(p(t))try{e(t.sel).off("draw.dt.extBv").on("draw.dt.extBv",()=>{b||(E(t),g())})}catch{}})}function K(){try{Q(),re().then(()=>{ee(),h(),ie(),console.log("[BulkVerif] Init complete - tabel:",f.map(e=>e.sel).join(", "))})}catch(e){console.error("[BulkVerif] Init error:",e)}}typeof $.featureModules<"u"&&($.featureModules.mKlaimBulkVerif={id:"mKlaimBulkVerif",name:"Bulk Verif / Batal Verif",description:"Verifikasi atau batalkan verifikasi banyak klaim sekaligus",match:{regex:/^\/v2\/m-klaim\/?$/},run:K});return _(ae);})();
