"use strict";var __morbis_feature=(()=>{var Q="extensionConfig";function kt(p,a,f){let h=a?.features?.[p];if(!h)return!0;if(h.enabled===!1)return!1;let x=f??a?.currentRole??"admin";if(x==="admin")return!0;let w=h.allowedRoles;return!Array.isArray(w)||w.length===0?!0:w.includes(x)}async function vt(p){try{let a=(await chrome.storage.sync.get(Q))?.[Q]??null;return kt(p,a)}catch{return!0}}function wt(p,a){vt(p).then(f=>{if(f)try{a()}catch(h){console.error(`[featureGate:${p}] gagal jalan:`,h)}})}var X="ext-free-text-noop",jt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function At(p){try{let a=p.toUpper;if(typeof a=="function"&&a[X]===!0)return!0;let f=function(h){return h?.value??""};f[X]=!0;try{Object.defineProperty(p,"toUpper",{value:f,writable:!0,configurable:!0})}catch{p.toUpper=f}return!0}catch{return!1}}var N="ext-pa-typo",St=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],C={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},Z=4,Y=24,Et=1,Ct=2.5;function tt(p,a,f,h){let x=typeof p=="number"?p:Number(p);return Number.isFinite(x)?Math.min(h,Math.max(f,x)):a}function L(p,a){let f=p??{};return{fs:tt(f.fs,a.fs,Z,Y),lh:tt(f.lh,a.lh,Et,Ct)}}function P(p){let a=p??{};return{kop:L(a.kop,C.kop),pasien:L(a.pasien,C.pasien),judul:L(a.judul,C.judul),isi:L(a.isi,C.isi),kesimpulan:L(a.kesimpulan,C.kesimpulan),ttd:L(a.ttd,C.ttd)}}function K(){return P(null)}function et(p){try{if(!p)return K();let a=p.getItem(N);return a?P(JSON.parse(a)):K()}catch{return K()}}function Lt(p,a){try{return p?(p.setItem(N,JSON.stringify(P(a))),!0):!1}catch{return!1}}function zt(p){try{p?.removeItem(N)}catch{}}function at(p){let a=P(p),f=h=>Math.min(Y,Math.max(Z,h));return{...a,alamatFs:f(a.kop.fs-8.5),judulLapFs:f(a.kop.fs-4)}}var b=p=>String(Math.round(p*100)/100);function Rt(p){let a=at(p);return{"--pa-kop-fs":`${b(a.kop.fs)}pt`,"--pa-kop-lh":b(a.kop.lh),"--pa-alamat-fs":`${b(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(a.judulLapFs)}pt`,"--pa-pasien-fs":`${b(a.pasien.fs)}pt`,"--pa-pasien-lh":b(a.pasien.lh),"--pa-judul-fs":`${b(a.judul.fs)}pt`,"--pa-judul-lh":b(a.judul.lh),"--pa-isi-fs":`${b(a.isi.fs)}pt`,"--pa-isi-lh":b(a.isi.lh),"--pa-kesimpulan-fs":`${b(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(a.kesimpulan.lh),"--pa-ttd-fs":`${b(a.ttd.fs)}pt`,"--pa-ttd-lh":b(a.ttd.lh)}}function Tt(p,a){if(p)try{for(let[f,h]of Object.entries(Rt(a)))p.setProperty(f,h)}catch{}}var It=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function it(p){let a=p??"",f=a.match(It);if(!f)return null;let h=a.slice(f[0].length).trim();return h===""?null:[f[1],h]}wt("paLabPrint",function(){"use strict";function p(){try{At(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let x=document.createElement("style");x.id="ext-free-text-style",x.textContent=jt,document.head.appendChild(x)}}catch{}}if(p(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",p),window.setInterval(p,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let x="ext-pa-print-proc";if(document.documentElement.getAttribute(x))return;document.documentElement.setAttribute(x,"1");let w=()=>{try{return window.localStorage??null}catch{return null}},j=et(w()),_=()=>{try{Tt(document.documentElement.style,j)}catch{}};_();let v=t=>F(t?.textContent||"");function nt(t){return t.replace(/<[^>]+>/g," ")}function qt(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function F(t){return qt(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let rt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",M=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>v(t)).filter(Boolean);for(;M.length<3;)M.push("");let I=[],ot=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(ot){let t=document.createElement("div");t.innerHTML=ot.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),I=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let U=I.join(" "),lt=t=>{let e=U.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},st=lt("telp"),pt=lt("fax"),H=(U.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],D=(U.match(/https?:\/\/[^\s;,]+/)||[""])[0],S=U.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");H&&(S=S.split(H).join("")),D&&(S=S.split(D).join("")),S=S.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Pt=["Alamat: "+S,st?"Telp: "+st:"",pt?"Fax: "+pt:""].filter(Boolean).join(", "),Ft=[H?"Email: "+H:"",D?"Website: "+D:""].filter(Boolean).join(", ");I=[Pt,Ft].filter(Boolean);let G=v(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",B=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let n=v(e[0]),r=v(e[2]),s=v(e[3]),l=v(e[5]);n&&B.push([n,r]),s&&B.push([s,l])}});let z=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],k=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),A=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",n=!1,r=t.querySelector(".section-title");if(r)e=v(r),n=!0;else{let c=m=>m.split(":")[0].trim();for(let m of Array.from(t.children).slice(0,3)){let g=v(m);if(g&&g.length<=24&&z.includes(k(c(g)))){e=c(g);break}}if(!e){let m=(t.textContent||"").split(`
`).map(g=>g.trim()).find(Boolean)||"";m&&z.includes(k(c(m)))&&(e=c(m))}if(!e)return}let s=document.createElement("div");s.innerHTML=t.innerHTML,s.querySelector(".section-title")?.remove();let l=s.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(c=>c.split(/<br\s*\/?>|\n/).map(m=>F(m.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(c=>c.length),u=[],i=[];l.forEach((c,m)=>{c.forEach((g,y)=>{m>0&&y===0&&u.length&&i.push(u.length),u.push(g)})});let o=u;if(!n&&o.length&&k(o[0])===k(e)){o.shift();for(let c=0;c<i.length;c++)i[c]-=1;for(;i.length&&i[0]<=0;)i.shift()}o.length>1&&!/^[IVXLC]+\.\s/.test(o[0])&&o.slice(1).some(c=>/^II\.\s/.test(c))&&(o[0]="I. "+o[0]),e&&A.push({title:e,items:o,para:i})});let Mt=/^catatan\s*:?/i,Ut=/^icd[\s-]*o\b\s*:?/i,J=[];for(let t of A){let e=[{title:t.title,items:[],para:[]}],n=e[0],r=!1,s=(l,u)=>{n={title:l,items:[],para:[],bare:u},e.push(n),r=!0};if(t.items.forEach((l,u)=>{let i=l.match(Mt),o=i?null:l.match(Ut);if(i){k(n.title)!=="catatan"&&s("Catatan");let c=l.slice(i[0].length).trim();c&&(t.para.includes(u)&&n.para.push(n.items.length),n.items.push(c));return}if(o){k(n.title)!=="icdo"&&s("ICD-0",!0),t.para.includes(u)&&n.para.push(n.items.length),n.items.push(l);return}t.para.includes(u)&&n.para.push(n.items.length),n.items.push(l)}),r)for(let l of e)l.items.length&&J.push(l);else J.push(e[0])}A.length=0,A.push(...J),A.forEach((t,e)=>t._i=e),A.sort((t,e)=>{let n=t._i??0,r=e._i??0,s=z.indexOf(k(t.title)),l=z.indexOf(k(e.title)),u=s===-1?z.length:s,i=l===-1?z.length:l;return u!==i?u-i:n-r});function Ht(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let n=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),r=t.getAttribute("placeholder")||"",s=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(n+" "+r+" "+s).slice(0,300)}}function Dt(t,e,n){let r=e.toLowerCase().split(/[^a-z0-9]+/).filter(i=>i.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(i));if(!r.length)return"";let s=r.sort((i,o)=>o.length-i.length)[0],l="",u=-1;return t.querySelectorAll("input, textarea, select").forEach(i=>{let{val:o,ctx:c}=Ht(i);if(!o||o===e||!o.toLowerCase().includes(s))return;let m=n.test(c)?2:0;m>u&&(u=m,l=o)}),l}function Bt(t,e){return(t.querySelector(e)?.value||"").trim()}async function $t(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let n=i=>/ket\w*\s*klinis/i.test(i),r=i=>/^dokter/i.test(i)||/^rs\b/i.test(i),s=t.map(([i,o],c)=>({label:i,value:o,idx:c})).filter(i=>r(i.label)?!!i.value:n(i.label));if(!s.length)return;let l=new AbortController,u=window.setTimeout(()=>l.abort(),6e3);try{let i=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),o=await fetch(i.toString(),{credentials:"same-origin",signal:l.signal});if(!o.ok){window.console.info("[paPrint] override: fetch input status "+o.status);return}let c=await o.text(),m=new DOMParser().parseFromString(c,"text/html");window.console.info('[paPrint] override: input title="'+(m.title||"").slice(0,60)+'" len='+c.length+" fields="+m.querySelectorAll("input, textarea, select").length);for(let g of s){if(n(g.label)){let W=Bt(m,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),O=F(nt(W));window.console.info("[paPrint] override: "+g.label+' cetak="'+g.value+'" input="'+O+'"'),O&&O!==g.value&&(t[g.idx][1]=O);continue}let y=/^dokter/i.test(g.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,E=Dt(m,g.value,y),T=F(nt(E||""));window.console.info("[paPrint] override: "+g.label+' cetak="'+g.value+'" input="'+T+'"'),T&&T!==g.value&&(t[g.idx][1]=T)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(u)}}await $t(B).catch(()=>{});let R=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>v(t)).filter(Boolean),dt=R[0]||"",ct=R[1]||"",$=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",ut=R.find(t=>/^\(.*\)$/.test(t))||R[2]||"",mt=R.find(t=>/^nip\.?/i.test(t))||R[3]||"",ft=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Ot=Array.from(document.body.querySelectorAll("script")),Nt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),q=B.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let n=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,r=n.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||n,s=r.split(/\s+-\s*/);if(s.length>=3&&/rawat\s+inap/i.test(s[1])){let l=Nt(s[1].trim()),u=s.slice(2).join(" - ").trim(),i=u?l+" - "+u:l;if(i)return[t,i]}return[t,r]}),Kt=q.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),V=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),gt=t=>/^catatan/i.test(t.trim()),ht=t=>t.replace(/^catatan\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),_t=q.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function bt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(n=>{if(!n.ok)throw new Error("img "+n.status);return n.blob()}).then(n=>new Promise((r,s)=>{let l=new FileReader;l.onload=()=>r(String(l.result)),l.onerror=()=>s(l.error),l.readAsDataURL(n)})).catch(()=>e)}async function Gt(){let t=at(j),[e,n]=await Promise.all([bt(rt),$?bt($):Promise.resolve("")]),r="";for(let o=0;o<q.length;o+=2){let c=q[o],m=q[o+1];r+="<tr><td>"+d(c[0])+"</td><td>:</td><td>"+d(c[1])+"</td>"+(m?"<td>"+d(m[0])+"</td><td>:</td><td>"+d(m[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let s="";for(let o of A){if(gt(o.title)){let y=o.items.length?o.items:["Tidak ada"];s+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.judul.fs+'pt"><b><u>CATATAN:</u></b></td><td>'+y.map(E=>"- "+d(ht(E)||"Tidak ada")).join("<br>")+"</td></tr></table>";continue}if(o.bare){o.items.forEach((y,E)=>{s+='<p style="margin:'+(E===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.judul.fs+'pt;"><b>'+d(y.toUpperCase())+"</b></p>"});continue}s+='<p style="margin:12pt 0 0 0;font-size:'+t.judul.fs+'pt;"><b><u>'+d(o.title.toUpperCase())+"</u></b></p>";let c=k(o.title)==="kesimpulan",m=c?t.kesimpulan.fs:t.isi.fs,g=c?t.kesimpulan.lh:t.isi.lh;o.items.forEach((y,E)=>{let T=c?"<b>"+d(y)+"</b>":V(y),W=it(y)?"margin-left:18pt;text-indent:-18pt;":"";s+='<p style="margin:'+(o.para.includes(E)?"14pt":"0")+" 0 6pt 0;font-size:"+m+"pt;line-height:"+g+";text-align:justify;"+W+'">'+T+"</p>"})}let l='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(G)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+M.slice(0,3).map(o=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(o)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+I.map(o=>d(o)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(G.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+r+"</table>"+s+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(dt)+'</p><p style="margin:0 0 6pt 0;">'+d(ct)+"</p>"+(n?'<p style="margin:0 0 6pt 0;"><img src="'+n+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(ut)+'</b></p><p style="margin:0 0 6pt 0;">'+d(mt)+"</p></td></tr></table></body></html>",u=new Blob(["\uFEFF"+l],{type:"application/msword"}),i=document.createElement("a");i.href=URL.createObjectURL(u),i.download="Hasil-PA-"+_t+".doc",document.body.appendChild(i),i.click(),window.setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},4e3)}let Jt=A.map(t=>{if(gt(t.title))return'<div class="section-catatan"><span class="catatan-label">Catatan:</span><div class="catatan-list">'+(t.items.length?t.items:["Tidak ada"]).map(r=>'<div class="catatan-item"><span class="catatan-dash">-</span><span>'+d(ht(r)||"Tidak ada")+"</span></div>").join("")+"</div></div>";let e=k(t.title)==="kesimpulan",n='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+'">'+t.items.map((r,s)=>{let l=t.para.includes(s)?" item-para":"",u=it(r);if(u){let i=e?"<strong>"+d(u[1])+"</strong>":V(u[1]);return'<div class="item-list has-marker'+l+'"><span class="item-marker">'+d(u[0])+"</span><span>"+i+"</span></div>"}return'<div class="item-list'+l+'">'+(e?"<strong>"+d(r)+"</strong>":V(r))+"</div>"}).join("")+"</div>";return t.bare?n:'<div class="section-judul">'+d(t.title)+"</div>"+n}).join("");document.body.innerHTML='<a href="'+d(ft)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(rt)+'" alt="Logo"></div><div class="kop-text">'+M.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+I.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(G)+'</div><div class="patient-info-container">'+Kt+'</div><div class="hasil-pa">'+Jt+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(dt)+"</p><p>"+d(ct)+"</p>"+($?'<img src="'+d($)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(ut)+'</p><p style="margin-top: 2px;">'+d(mt)+"</p></div></div></div>",Ot.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),Gt().catch(()=>{window.location.href=ft})});let xt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(r,s,l,u,i,o,c,m)=>"<label>"+d(l)+'<input type="range" data-g="'+d(r)+'" data-f="'+s+'" min="'+u+'" max="'+i+'" step="'+o+'" value="'+c+'"><output data-o="'+d(r+"-"+s)+'">'+d(String(c)+m)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+St.map(r=>'<div class="t-typo-group"><strong>'+d(r.label)+'</strong><div class="t-typo-row">'+e(r.key,"fs","Font (pt)",4,20,.5,j[r.key].fs,"pt")+e(r.key,"lh","Spasi baris",1,2.5,.05,j[r.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(r=>{let s=r;s.addEventListener("input",()=>{let l=s.dataset.g,u=s.dataset.f;if(!l||!u||!j[l])return;j[l][u]=Number(s.value),_();let i=t.querySelector(`output[data-o="${l}-${u}"]`);i&&(i.textContent=s.value+(u==="fs"?"pt":""))})});let n=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let r=Lt(w(),j);n&&(n.textContent=r?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(zt(w()),j=et(w()),_(),xt(),n){let r=t.querySelector("[data-note]");r&&(r.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&xt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let yt="ext-pa-print-style";if(!document.getElementById(yt)){let t=document.createElement("style");t.id=yt,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-decoration: underline;
            text-transform: uppercase;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Hanging indent: baris bernomor/berpoin \u2014 penanda di kolom
           kiri tetap, teks lanjutan sejajar di bawah teks. */
        .item-list.has-marker {
            display: flex;
            gap: 6px;
        }

        .item-marker {
            flex-shrink: 0;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-judul-fs, 6pt);
            font-weight: bold;
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya). */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let f=Date.now(),h=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(h),a().catch(()=>{})):Date.now()-f>5e3&&window.clearInterval(h)},200)})})();
