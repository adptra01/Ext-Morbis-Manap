"use strict";var __morbis_feature=(()=>{var M=Object.defineProperty;var G=Object.getOwnPropertyDescriptor;var W=Object.getOwnPropertyNames;var Q=Object.prototype.hasOwnProperty;var X=(e,t)=>{for(var n in t)M(e,n,{get:t[n],enumerable:!0})},Y=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of W(t))!Q.call(e,r)&&r!==n&&M(e,r,{get:()=>t[r],enumerable:!(o=G(t,r))||o.enumerable});return e};var Z=e=>Y(M({},"__esModule",{value:!0}),e);var ge={};X(ge,{applySelectAll:()=>z,clearSelection:()=>h,getSelected:()=>F,initMKlaimBulkVerifFeature:()=>N,isEligible:()=>K,parseIdVisit:()=>ee,pruneSelection:()=>R});function j(){return window}var A="ext-batch-shared-style";function L(){if(document.getElementById(A))return;let e=document.createElement("style");e.id=A,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}function P(e,t,n=2){let o=r=>fetch(e,t).catch(i=>{if(r<=0)throw i;return new Promise(s=>setTimeout(s,1e3*(3-r))).then(()=>o(r-1))});return o(n)}function m(e){return new Promise(t=>{L();let n=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",o=document.createElement("div");o.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",o.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${n}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,o.querySelector("h3").textContent=e.title;let r=o.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((d,c)=>{c>0&&r.appendChild(document.createElement("br")),r.appendChild(document.createTextNode(d))});let i=d=>{o.remove(),document.removeEventListener("keydown",s),t(d)},s=d=>{d.key==="Escape"&&i(!1)};o.querySelector(".ext-modal-close").addEventListener("click",()=>i(!1)),o.addEventListener("click",d=>{d.target===o&&i(!1)}),o.querySelector("[data-ext-ok]").addEventListener("click",()=>i(!0));let l=o.querySelector("[data-ext-cancel]");l&&l.addEventListener("click",()=>i(!1)),document.addEventListener("keydown",s),document.body.appendChild(o)})}var q=j(),a={endpointVerif:"/v2/m-klaim/control/verif",endpointBatal:"/v2/m-klaim/control/batal-verif",delayMs:600,barId:"ext-bulk-verif-bar",cssId:"ext-bulk-verif-style",readyTimeoutMs:15e3,readyPollMs:250,warnIfMoreThan:100,UJI_SAJA:!0},b=[{sel:"#data-table",kind:"main",nama:"Klaim",aksi:"Verif",endpoint:a.endpointVerif,danger:!1},{sel:"#data-table-verif",kind:"verif",nama:"Sudah Terverifikasi",aksi:"Batal Verif",endpoint:a.endpointBatal,danger:!0}],p={main:new Set,verif:new Set},f=!1;function z(e,t,n){let o=0;return t.forEach(r=>{!r.id||!r.eligible||(n?p[e].add(r.id):p[e].delete(r.id),o+=1)}),o}function R(e,t){let n=new Set;t.forEach(r=>{r.id&&r.eligible&&n.add(r.id)});let o=0;return Array.from(p[e]).forEach(r=>{n.has(r)||(p[e].delete(r),o+=1)}),o}function F(e){return Array.from(p[e])}function h(e){p[e].clear()}function ee(e){let t=e.match(/\d+/);return t?t[0]:null}function K(e,t,n){return t?e==="main"?!0:n:!1}function te(){if(document.getElementById(a.cssId))return;let e=document.createElement("style");e.id=a.cssId,e.textContent=`
    #${a.barId} {
      position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
      z-index: 2147482000; display: none; align-items: center; gap: 14px;
      background: #0f172a; color: #f8fafc; border-radius: 12px;
      padding: 10px 16px; font-family: 'Inter', system-ui, sans-serif;
      font-size: 13px; box-shadow: 0 8px 28px rgba(15,23,42,.35);
    }
    #${a.barId} .bv-item { display: flex; align-items: center; gap: 8px; }
    #${a.barId} .bv-label { color: #cbd5e1; }
    #${a.barId} .bv-count { color: #f8fafc; font-weight: 700; }
    #${a.barId} button {
      border: none; border-radius: 8px; cursor: pointer; padding: 7px 14px;
      font-size: 12.5px; font-weight: 700; font-family: inherit;
    }
    #${a.barId} .bv-aksi { background: #2563eb; color: #fff; }
    #${a.barId} .bv-aksi:hover { background: #1d4ed8; }
    #${a.barId} .bv-aksi-danger { background: #dc2626; color: #fff; }
    #${a.barId} .bv-aksi-danger:hover { background: #b91c1c; }
    #${a.barId} .bv-reset { background: #334155; color: #e2e8f0; }
    #${a.barId} .bv-reset:hover { background: #475569; }
    #${a.barId} button:disabled { opacity: .55; cursor: not-allowed; }

    .bv-check {
      display: inline-flex; align-items: center; justify-content: center;
      margin-right: 6px; vertical-align: middle; cursor: pointer;
    }
    .bv-check input { width: 14px; height: 14px; cursor: pointer; margin: 0; }
    .bv-check input:disabled { cursor: not-allowed; }
    th.bv-th-head { width: 26px; }
    /* Kolom khusus checkbox - sel tersendiri di awal baris. Header native
       TIDAK disentuh supaya indeks sorting bawaan tidak bergeser. */
    td.bv-sel {
      width: 30px; text-align: center; vertical-align: middle;
      padding: 4px 2px !important; border-right: 1px solid #e2e8f0;
      background: #f8fafc;
    }
    td.bv-sel input { width: 15px; height: 15px; cursor: pointer; margin: 0; }
    td.bv-sel input:disabled { cursor: not-allowed; }
    /* Penanda fitur aktif - memudahkan diagnosis di console */
    html[data-ext-bulk-verif='1'] td.bv-sel { background: #eff6ff; }
  `,document.head.appendChild(e),L()}function u(e){return document.querySelector(e.sel)}function U(e){let t=window.jQuery;if(!t)return null;try{return t(e.sel).DataTable()??null}catch{return null}}function V(e){return(Array.isArray(e)?e:[e]).filter(t=>t instanceof HTMLElement)}function S(e){let t=e.querySelector('[onclick*="detail("]');if(t){let o=(t.getAttribute("onclick")||"").match(/\d+/);if(o)return o[0]}let n=e.querySelector('[onclick*="BatalVerif("]');if(n){let o=(n.getAttribute("onclick")||"").match(/\d+/);if(o)return o[0]}return null}function C(e,t){return K(e.kind,!!t.querySelector('button[onclick*="detail("]'),!!t.querySelector('button[onclick*="BatalVerif("]'))}function O(e,t){return{id:S(t),eligible:C(e,t)}}function _(e){let t=u(e);if(!t)return[];let n=U(e);if(n)try{return V(n.rows({search:"applied"}).nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(o=>!o.classList.contains("dataTables_empty"))}function ne(e){let t=u(e);if(!t)return[];let n=U(e);if(n)try{return V(n.rows().nodes().toArray())}catch{}return Array.from(t.querySelectorAll("tbody tr")).filter(o=>!o.classList.contains("dataTables_empty"))}function oe(e,t){let n=S(t);if(!n){let s=document.createElement("td");s.className="bv-sel",s.dataset.extBvUnid="1";let l=document.createElement("input");l.type="checkbox",l.disabled=!0,l.title="id_visit tidak terbaca dari markup baris ini",s.appendChild(l),t.insertBefore(s,t.firstChild);return}let o=C(e,t),r=document.createElement("td");r.className="bv-sel";let i=document.createElement("input");i.type="checkbox",i.dataset.extBvId=n,i.checked=p[e.kind].has(n),a.UJI_SAJA?(i.disabled=!0,i.title="Mode uji - belum bisa dipilih"):(i.disabled=!o,i.title=o?"Pilih baris ini":"Baris tidak memenuhi syarat aksi ini",i.addEventListener("change",()=>{i.checked?p[e.kind].add(n):p[e.kind].delete(n),x(),E(e)})),r.appendChild(i),t.insertBefore(r,t.firstChild)}function re(e){e.querySelectorAll("tbody td.bv-sel").forEach(t=>t.remove())}function B(e){let t=u(e);t&&(re(t),t.querySelectorAll("tbody tr").forEach(n=>oe(e,n)),E(e))}function E(e){let n=u(e)?.querySelector("thead input[data-ext-bv-header]");if(!n)return;let o=_(e).filter(s=>C(e,s)),r=o.length,i=o.filter(s=>{let l=S(s);return!!l&&p[e.kind].has(l)}).length;n.disabled=a.UJI_SAJA||f||r===0,n.checked=r>0&&i===r,n.indeterminate=i>0&&i<r}function ie(e){let n=u(e)?.querySelector("thead th");if(!n)return;if(n.dataset.extBvHeader==="1"){E(e);return}n.classList.add("bv-th-head");let o=document.createElement("span");o.className="bv-check",o.title="Pilih / batal pilih semua baris yang cocok dengan pencarian";let r=document.createElement("input");if(r.type="checkbox",r.dataset.extBvHeader="1",a.UJI_SAJA){r.disabled=!0,r.title="Mode uji - belum bisa dipilih",o.appendChild(r),n.insertBefore(o,n.firstChild),n.dataset.extBvHeader="1";return}r.addEventListener("change",()=>{let i=_(e).map(s=>O(e,s));z(e.kind,i,r.checked),B(e),x()}),o.appendChild(r),n.insertBefore(o,n.firstChild),n.dataset.extBvHeader="1"}function v(){b.forEach(T),x()}function I(){return document.getElementById(a.barId)}function x(){let e=I();if(!e)return;let t=b.map(o=>[o,p[o.kind].size]).filter(([,o])=>o>0);if(a.UJI_SAJA||t.length===0||f){e.style.display="none";return}e.innerHTML="",t.forEach(([o,r])=>{let i=document.createElement("div");i.className="bv-item";let s=document.createElement("span");s.className="bv-label",s.textContent=`${o.nama}: `;let l=document.createElement("span");l.className="bv-count",l.textContent=`${r} dipilih`;let d=document.createElement("button");d.className=o.danger?"bv-aksi bv-aksi-danger":"bv-aksi",d.textContent=o.aksi,d.addEventListener("click",()=>{de(o)}),i.append(s,l,d),e.appendChild(i)});let n=document.createElement("button");n.className="bv-reset",n.textContent="Batal Pilih",n.addEventListener("click",()=>{b.forEach(o=>h(o.kind)),v()}),e.appendChild(n),e.style.display="flex"}function ae(){if(I())return;let e=document.createElement("div");e.id=a.barId,e.style.display="none",document.body.appendChild(e)}async function se(e,t){try{let n=new URLSearchParams({id_visit:t}),o=await P(e,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:n.toString(),credentials:"same-origin"});if(!o.ok)return{id:t,ok:!1,pesan:`HTTP ${o.status}`};let r=await o.json(),i=String(r.kode)==="200";return{id:t,ok:i,pesan:r.message??(i?"Sukses":"Gagal")}}catch(n){return{id:t,ok:!1,pesan:n.message||"Gagal koneksi"}}}function le(e){let t=ne(e).map(o=>O(e,o)),n=R(e.kind,t);return{valid:F(e.kind),gugur:n}}async function de(e){if(f)return;let{valid:t,gugur:n}=le(e);if(t.length===0){h(e.kind),v(),await m({title:"Tidak ada baris yang bisa diproses",message:"Pilihan tidak lagi cocok dengan data di tabel. Silakan pilih ulang.",okLabel:"Mengerti",hideCancel:!0});return}let o=Math.ceil(t.length*a.delayMs/1e3),r=[`${e.nama}: ${t.length} baris akan diproses.`];if(n>0&&r.push(`${n} pilihan diabaikan (data berubah/tidak memenuhi syarat).`),r.push(e.danger?"Verifikasi yang dibatalkan kembali ke daftar belum terverifikasi.":"Data yang tidak memenuhi syarat akan ditolak server."),t.length>a.warnIfMoreThan&&r.push(`PERINGATAN: jumlah besar, proses \xB1${o} detik. Jangan tutup halaman.`),r.push("Lanjutkan?"),!await m({title:`${e.aksi} ${t.length} data?`,message:r.join(`
`),variant:e.danger?"danger":"primary",okLabel:`Ya, ${e.aksi}`,cancelLabel:"Batal"}))return;f=!0,b.forEach(c=>E(c)),x();let s=[],l=0;for(let c=0;c<t.length;c+=1){let $=await se(e.endpoint,t[c]);$.ok?l+=1:s.push($);let H=I()?.querySelector(".bv-label");H&&(H.textContent=`${e.nama} (${c+1}/${t.length}): `),c<t.length-1&&await new Promise(D=>setTimeout(D,a.delayMs))}f=!1,h(e.kind),v();let d=[`${e.aksi} selesai.`,`Berhasil: ${l} dari ${t.length}`];s.length>0&&(d.push("",`Gagal: ${s.length}`),s.slice(0,10).forEach(c=>d.push(`#${c.id} - ${c.pesan}`)),s.length>10&&d.push(`... dan ${s.length-10} lainnya`)),await m({title:"Hasil",message:d.join(`
`),okLabel:"Muat ulang tabel",hideCancel:!0}),window.location.reload()}function ce(){return new Promise(e=>{let t=Date.now(),n=()=>{if(b.some(r=>u(r))||Date.now()-t>a.readyTimeoutMs){e();return}setTimeout(n,a.readyPollMs)};n()})}var g=!1,k=[],y=new Map;function ue(){k.forEach(e=>e.disconnect()),k.length=0,y.clear()}function w(e){if(!g){g=!0;try{B(e),x()}finally{g=!1}}}function J(e){let t=e.querySelectorAll("tbody tr").length;return t===0||e.querySelectorAll("tbody td.bv-sel").length===t}function pe(e,t){let n=new MutationObserver(()=>{if(g)return;let r=u(e);if(r){if(r!==t){T(e);return}J(r)||w(e)}});n.observe(t,{childList:!0,subtree:!0}),k.push(n);let o=t.parentElement;if(o){let r=new MutationObserver(()=>{let i=u(e);i&&i!==t&&T(e)});r.observe(o,{childList:!0}),k.push(r)}}function T(e){let t=u(e);if(t){if(ie(e),y.get(e.sel)===t){w(e);return}y.set(e.sel,t),w(e),pe(e,t)}}function be(){setInterval(()=>{g||b.forEach(e=>{let t=y.get(e.sel),n=u(e);n&&(!t||!document.contains(t)||n!==t)?T(e):n&&!J(n)&&w(e)})},Math.max(1e3,a.readyPollMs*4))}function fe(){let e=window.jQuery;e&&b.forEach(t=>{let n=u(t);if(!(!n||n.dataset.extBvBound==="1")){n.dataset.extBvBound="1";try{e(t.sel).off("draw.dt.extBv").on("draw.dt.extBv",()=>{f||g||(B(t),x())})}catch{}}})}function N(){try{te(),ce().then(()=>{ue(),ae(),v(),fe(),be(),document.documentElement.setAttribute("data-ext-bulk-verif","1");let e=b.map(t=>{let n=u(t),o=n?n.querySelectorAll("tbody tr:not(.dataTables_empty)").length:0,r=n?n.querySelectorAll("tbody td.bv-sel").length:0,i=n?n.querySelectorAll("tbody td.bv-sel[data-ext-bv-unid]").length:0;return`${t.sel}: kolom=${r}/${o}${i?` (${i} tanpa id)`:""}`});console.log("[BulkVerif] Init complete -",e.join(" | "),a.UJI_SAJA?"(MODE UJI: checkbox nonaktif)":"")})}catch(e){console.error("[BulkVerif] Init error:",e)}}typeof q.featureModules<"u"&&(q.featureModules.mKlaimBulkVerif={id:"mKlaimBulkVerif",name:"Bulk Verif / Batal Verif",description:"Verifikasi atau batalkan verifikasi banyak klaim sekaligus",match:{regex:/^\/v2\/m-klaim\/?$/},run:N});return Z(ge);})();
