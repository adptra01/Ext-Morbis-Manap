"use strict";var __morbis_feature=(()=>{var I={background:"#ffffff",foreground:"#0a0a0e",card:"#ffffff",cardForeground:"#0a0a0e",primary:"#2469f0",primaryForeground:"#f8fafc",primaryHover:"#1d58cc",secondary:"#f1f5f9",secondaryForeground:"#1e293b",muted:"#f1f5f9",mutedForeground:"#64748b",accent:"#f1f5f9",accentForeground:"#1e293b",destructive:"#ef4444",destructiveForeground:"#f8fafc",border:"#e2e8f0",input:"#e2e8f0",ring:"#2469f0",success:"#1b8a4b",successBg:"#eaf6ef",warning:"#c47a1a",warningBg:"#fef4e4",error:"#ef4444",errorBg:"#fef2f2",info:"#2469f0",infoBg:"#eef3ff"},ve=new Set;function ye(e,r){if(ve.has(e)){let d=document.getElementById(e);if(d)return d}let a=document.createElement("style");return a.id=e,a.textContent=r,document.head.appendChild(a),ve.add(e),a}ye("ext-shared-animations",`
  @keyframes fadeSlideIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
`);var Xe=/^[A-Z][0-9][0-9](\.[0-9]{1,2})?$/,et=/^[0-9]{2}(\.[0-9]{1,2})?$/,tt=/^(\d{1,3})\/(\d{1,3})$/,at=/^\d+(\.\d+)?$/;function x(e){let r=e.trim();return r===""||/^[-–—]+$/.test(r)}function J(e){return Xe.test(e.trim().toUpperCase())}function Z(e){return et.test(e.trim())}function be(e){let r=e.trim().replace(/\s+/g,""),a=tt.exec(r);if(!a)return!1;let d=parseInt(a[1],10),l=parseInt(a[2],10);return d>=50&&d<=250&&l>=20&&l<=160}function j(e,r,a){let d=e.trim().replace(",",".");if(!at.test(d))return!1;let l=parseFloat(d);return!isNaN(l)&&l>=r&&l<=a}function ke(e){return/[\p{L}\p{N}]/u.test(e)}var nt='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',rt=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${nt};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,Q=null;function it(){return Q||(Q=new CSSStyleSheet,Q.replaceSync(rt)),Q}var _e=!1;function ot(){if(_e||document.getElementById("ext-pjs-font"))return;_e=!0;let e=document.createElement("link");e.id="ext-pjs-font",e.rel="stylesheet",e.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(e)}function we(e,r="open"){let a=e.attachShadow({mode:r});return a.adoptedStyleSheets=[it()],ot(),a}var st=`
  :host { display: none; }
  :host([open]) { display: block; }
  .overlay {
    position: fixed;
    inset: 0;
    z-index: 2147483000;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(15, 23, 42, 0.55);
    backdrop-filter: blur(2px);
    animation: ext-fade var(--ext-duration-normal) var(--ext-ease);
    padding: var(--ext-space-6);
  }
  .modal {
    width: 520px;
    max-width: 100%;
    background: var(--ext-surface);
    border-radius: var(--ext-radius-lg);
    box-shadow: var(--ext-shadow-lg);
    overflow: hidden;
    animation: ext-slide-up var(--ext-duration-normal) var(--ext-ease);
  }
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--ext-space-4);
    padding: var(--ext-space-5) var(--ext-space-6);
    border-bottom: 1px solid var(--ext-border);
  }
  .title {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-lg);
    font-weight: 700;
    color: var(--ext-text);
    margin: 0;
  }
  .close {
    appearance: none;
    border: none;
    background: var(--ext-surface-2);
    color: var(--ext-text-secondary);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    font-size: 22px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color var(--ext-duration-fast) var(--ext-ease), color var(--ext-duration-fast) var(--ext-ease);
  }
  .close:hover { background: var(--ext-danger-soft); color: var(--ext-danger); }
  .close:focus-visible { outline: none; box-shadow: var(--ext-ring); }

  .body {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text-secondary);
    padding: var(--ext-space-6);
  }
  .footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--ext-space-3);
    padding: 0 var(--ext-space-6) var(--ext-space-6);
  }
  /* tombol utama di dalam modal memakai komponen ext-btn \u2014 styling via atribut host */
  ::slotted(*) { font-family: var(--ext-font-family); }

  /* variant accent line */
  :host([variant='danger']) .header { box-shadow: inset 4px 0 0 var(--ext-danger); }
  :host([variant='success']) .header { box-shadow: inset 4px 0 0 var(--ext-success); }
  :host([variant='info']) .header { box-shadow: inset 4px 0 0 var(--ext-info); }
  :host([variant='warning']) .header { box-shadow: inset 4px 0 0 var(--ext-warning); }

  @keyframes ext-fade { from { opacity: 0; } }
  @keyframes ext-slide-up {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
  }
`,lt=class extends HTMLElement{constructor(){super(),this.handleKey=e=>{e.key==="Escape"&&this.hasAttribute("open")&&this.cancel()},this.root=we(this),this.root.innerHTML=`
      <style>${st}</style>
      <div class="overlay">
        <div class="modal" role="dialog" aria-modal="true">
          <div class="header">
            <h3 class="title"><slot name="title"></slot></h3>
            <button class="close" part="close" aria-label="Tutup">&times;</button>
          </div>
          <div class="body"><slot></slot></div>
          <div class="footer">
            <slot name="footer"></slot>
          </div>
        </div>
      </div>
    `}connectedCallback(){let e=this.root.querySelector(".overlay");this.root.querySelector(".close").addEventListener("click",()=>this.cancel()),e.addEventListener("click",r=>{r.target===e&&this.cancel()}),document.addEventListener("keydown",this.handleKey)}disconnectedCallback(){document.removeEventListener("keydown",this.handleKey)}get titleSlot(){return this.querySelector('[slot="title"]')}get footerSlot(){return this.querySelector('[slot="footer"]')}open(){this.setAttribute("open","")}close(){this.removeAttribute("open")}cancel(){this.dispatchEvent(new CustomEvent("ext-cancel")),this.close()}ok(){this.dispatchEvent(new CustomEvent("ext-ok"))}};customElements.get("ext-modal")||customElements.define("ext-modal",lt);var ut=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,dt=class extends HTMLElement{constructor(){super();let e=we(this);e.innerHTML=`
      <style>${ut}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=e.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",e=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){e.stopPropagation(),e.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(e){(e==="disabled"||e==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}};customElements.get("ext-btn")||customElements.define("ext-btn",dt);function Se(e){return new Promise(r=>{let a=document.createElement("ext-modal");a.setAttribute("variant",e.variant??"warning"),e.okLabel&&a.setAttribute("ok-label",e.okLabel),e.cancelLabel&&a.setAttribute("cancel-label",e.cancelLabel),e.hideCancel&&a.setAttribute("hide-cancel",""),a.innerHTML=`<h3 slot="title"></h3><div class="ext-confirm-body"></div><div slot="footer">
         <ext-btn data-ext-confirm-cancel variant="secondary"></ext-btn>
         <ext-btn data-ext-confirm-ok></ext-btn>
       </div>`;let d=a.querySelector('[slot="title"]');d.textContent=e.title;let l=a.querySelector(".ext-confirm-body");if(e.icon){let m=document.createElement("div");m.className="ext-confirm-icon",m.textContent=e.icon,l.appendChild(m)}e.message&&e.message.split(`
`).forEach((m,h)=>{h>0&&l.appendChild(document.createElement("br")),l.appendChild(document.createTextNode(m))}),a.querySelector("[data-ext-confirm-ok]").textContent=e.okLabel??"Lanjut";let p=a.querySelector("[data-ext-confirm-ok]");p.setAttribute("variant",e.variant==="danger"?"danger":"primary"),e.hideCancel?a.querySelector("[data-ext-confirm-cancel]")?.remove():a.querySelector("[data-ext-confirm-cancel]").textContent=e.cancelLabel??"Batal",p.addEventListener("click",()=>a.ok()),e.hideCancel||a.querySelector("[data-ext-confirm-cancel]").addEventListener("click",()=>a.cancel());let g=m=>{a.remove(),r(m)};a.addEventListener("ext-ok",()=>g(!0)),a.addEventListener("ext-cancel",()=>g(!1)),document.body.appendChild(a),a.open()})}var Ee="morbis_preop_markers";function je(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}function ct(e,r=Date.now()){let a={},d=0;for(let[l,p]of Object.entries(e))p&&p.markedAt&&r-p.markedAt<=2592e6?a[l]=p:d++;return{purged:a,count:d}}function ft(e=je(),r=Date.now()){if(!e)return{};try{let a=e.getItem(Ee);if(!a)return{};let d=JSON.parse(a);if(typeof d!="object"||d===null)return{};let{purged:l,count:p}=ct(d,r),g=0;for(let m of Object.keys(l)){let h=l[m];h&&((h.norm!==void 0||h.nama!==void 0||h.noReg!==void 0)&&g++,l[m]=pt(h))}return(p>0||g>0)&&mt(l,e),l}catch{return{}}}function pt(e){return{idVisit:e.idVisit,markedAt:e.markedAt}}function mt(e,r=je()){if(r)try{r.setItem(Ee,JSON.stringify(e))}catch{}}var ht="http://dev.rsudkotajambi.id/rs",gt="ext-farmasi-app-base",xt=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],vt=".rsudkotajambi.id",yt=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],Ce="Fitur nonaktif: server Reports menggunakan HTTP (belum mendukung HTTPS)";function X(e){try{let r=new URL(e??ee());if(r.protocol==="https:")return null;let a=r.hostname.toLowerCase();return yt.includes(a)?null:Ce}catch{return Ce}}function bt(e){try{let r=new URL(e);if(r.protocol!=="http:"&&r.protocol!=="https:")return!1;let a=r.hostname.toLowerCase();return xt.includes(a)?!0:a.endsWith(vt)}catch{return!1}}function ee(){try{let e=localStorage.getItem(gt);if(e&&bt(e))return e.replace(/\/+$/,"")}catch{}return ht}async function kt(e,r,a=fetch){let d=new AbortController,l=globalThis.setTimeout(()=>d.abort(),25e3);try{return await a(e,{...r,signal:d.signal})}finally{globalThis.clearTimeout(l)}}async function _t(e,r=fetch){try{let a=ee(),d=X(a);if(d)return console.warn("[casemixApi]",d,"\u2014 baca pusat dilewati:",e),null;let l=await kt(a+e,{cache:"no-store",credentials:"omit",headers:{Accept:"application/json"}},r);return l.ok?await l.json():null}catch{return null}}async function wt(e,r,a=fetch){if(!e)return[];let d="/api/reports/resume-history?id_visit="+encodeURIComponent(e)+(r?"&tipe="+r:""),l=await _t(d,a);return!l?.ok||!Array.isArray(l.data)?[]:l.data}function St(){try{let e=globalThis.crypto;if(e&&typeof e.randomUUID=="function")return e.randomUUID()}catch{}return`${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`}function O(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}var Ae="ext_rv_history_",Et=Ae,Ie="ext_rv_lastform_",Le="ext_migrated_rv_",Te=50;function ne(e,r){return`${Ae}${r==="ranap"?"ri":"rj"}_${e||"unknown"}`}function $e(e,r){return`${Ie}${r==="ranap"?"ri":"rj"}_${e||"unknown"}`}function te(e,r){if(!e)return null;try{let a=e.getItem(r);return a?JSON.parse(a):null}catch{return null}}function re(e,r,a){if(e)try{e.setItem(r,JSON.stringify(a))}catch{}}function jt(e,r){return JSON.stringify(e??null)===JSON.stringify(r??null)}function Be(e,r){let a={};return Object.keys(e).forEach(d=>a[d]=!0),Object.keys(r).forEach(d=>a[d]=!0),Object.keys(a).filter(d=>!jt(e[d],r[d]))}function De(e){let r=e===void 0?"-":JSON.stringify(e);return r.length>60?r.slice(0,60)+"\u2026":r}function W(e,r,a=O()){let d=te(a,ne(e,r)),l=Array.isArray(d)?d:[];if(r==="ranap"){let p=te(a,Et+e);if(Array.isArray(p)&&p.length>0&&l.length===0){let g=p.map(m=>({...m,tipe:"ranap"}));return ie(g,e,"ranap",a),g}}return l}function ie(e,r,a,d=O()){re(d,ne(r,a),e.slice(-Te))}function Ct(e,r,a=O()){return te(a,$e(e,r))||(r==="ranap"?te(a,Ie+e):null)}function oe(e,r,a,d=O()){re(d,$e(r,a),e)}function At(){try{let e=document.getElementById("userpanel");if(e){let l="",p="";if(e.querySelectorAll(".subgroup").forEach(m=>{let h=(m.querySelector(".subtitle")?.textContent||"").trim().toLowerCase(),w=(m.querySelector(".subcontent")?.textContent||"").trim();h==="username"&&w&&(l=w),h==="role"&&w&&(p=w)}),l)return`${l}${p?` (${p})`:""}`;let g=(e.querySelector("a")?.textContent||"").trim();if(g&&g!=="Petugas Rumah Sakit")return g}let r=(document.querySelector("#petugas, .petugas, .username, #username, .user-name")?.textContent||"").trim();if(r)return r.slice(0,80);let a=document.querySelector('input[name="dokter"], #dokter, input[name="nama_dokter"]')?.value?.trim();if(a)return a.slice(0,80);let d=document.querySelector('input[name="id_user"], #id_user')?.value?.trim();if(d)return`User #${d}`}catch{}return"petugas"}var It="/api/reports/resume-history";function Lt(){return ee()}function Tt(e){return Le+e}function $t(e,r){if(!e)return 0;try{let a=e.getItem(r);if(a===null)return 0;let d=Number(JSON.parse(a));return Number.isFinite(d)?d:0}catch{return 0}}function Bt(e,r,a,d){if(!(!e||!r))try{let l=Tt(ne(r,a));d>$t(e,l)&&re(e,l,d)}catch{}}function Dt(e,r,a=fetch,d=O(),l=e.tipe){let p={client_id:e.client_id??null,id_visit:r,id_resume:e.id_resume,aksi:e.aksi,tipe:e.tipe,waktu:new Date(e.at).toISOString(),user:e.user,before:e.before,after:e.after,changed:e.changed},g=async()=>{try{let m=Lt(),h=X(m);return h?(console.warn("[resumeHistory]",h,"\u2014 kirim resume dilewati:",r),!1):(await a(m+It,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(p),keepalive:!0,credentials:"omit"})).ok?(Bt(d,r,l,e.at),!0):!1}catch{return!1}};try{return g()}catch{return Promise.resolve(!1)}}var Ne=null,qe=0;function Nt(e){if(!e.idVisit)return null;let r=e.now??Date.now(),a=e.store??O();oe(e.after,e.idVisit,e.tipe,a);let d=JSON.stringify([e.idVisit,e.aksi,e.after]);if(Ne===d&&r-qe<5e3)return null;Ne=d,qe=r;let l={at:r,aksi:e.aksi,id_resume:e.idResume??"",user:e.user??At(),tipe:e.tipe,before:e.before??{},after:e.after,changed:Be(e.before??{},e.after),client_id:St()},p=W(e.idVisit,e.tipe,a);p.push(l),ie(p,e.idVisit,e.tipe,a),oe(e.after,e.idVisit,e.tipe,a);try{Dt(l,e.idVisit,e.fetcher??fetch,a,e.tipe)}catch{}return l}function qt(e){try{let r=document.createElement("div");r.textContent=e,r.style.cssText="position:fixed;top:20px;right:20px;z-index:2147483647;padding:14px 18px;border-radius:8px;background:#dcfce7;color:#065f46;border-left:5px solid #16a34a;font-weight:600;font-size:16px!important;line-height:1.6!important;font-family:"+Ve+"!important;box-shadow:0 4px 16px rgba(0,0,0,.15);max-width:420px;",document.body.appendChild(r),setTimeout(()=>r.remove(),4e3)}catch{}}function Ot(e){if(e!=null){if(typeof e=="string")return e;if(typeof e=="number"||typeof e=="boolean")return String(e);if(Array.isArray(e))return e.map(r=>{if(typeof r=="string")return r;try{return JSON.stringify(r)??""}catch{return""}});try{return JSON.stringify(e)??""}catch{return""}}}function Oe(e){let r={};if(!e||typeof e!="object"||Array.isArray(e))return r;for(let a of Object.keys(e)){let d=Ot(e[a]);d!==void 0&&(r[a]=d)}return r}function zt(e,r){try{if(!e||typeof e!="object")return null;let a=e.waktu?Date.parse(e.waktu):NaN;if(!Number.isFinite(a))return null;let d=Oe(e.after),l=Oe(e.before),p=e.tipe==="rajal"?"rajal":e.tipe==="ranap"?"ranap":r,g=Array.isArray(e.changed)?e.changed.filter(h=>typeof h=="string"):Be(l,d),m=typeof e.client_id=="string"&&e.client_id?e.client_id:void 0;return{at:a,aksi:e.aksi==="buat"?"buat":"ubah",id_resume:typeof e.id_resume=="string"?e.id_resume:"",user:typeof e.user=="string"&&e.user?e.user:"petugas",tipe:p,before:l,after:d,changed:g,...m?{client_id:m}:{}}}catch{return null}}function ze(e){if(e.client_id)return"cid:"+e.client_id;try{return"h:"+e.at+"|"+e.user+"|"+e.aksi+"|"+JSON.stringify(e.after)}catch{return"h:"+e.at+"|"+e.user+"|"+e.aksi}}function Vt(e,r){let a=new Set(e.map(ze)),d=e.slice();for(let l of r){let p=ze(l);a.has(p)||(a.add(p),d.push(l))}return d.sort((l,p)=>l.at-p.at),d.slice(-Te)}var Ve="'Roboto','Segoe UI',system-ui,-apple-system,Arial,sans-serif";function Rt(e){try{document.querySelector("#ext-rv-history-overlay")?.remove()}catch{}let r=e.store??O(),a=W(e.idVisit,e.tipe,r).slice().reverse(),d=e.zIndex??99998,l=document.createElement("div");l.id="ext-rv-history-overlay",l.style.cssText=`position:fixed;inset:0;z-index:${d};background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:24px;`,l.addEventListener("click",function(L){L.target===l&&l.remove()});let p=document.createElement("div");p.style.cssText="background:#fff;border-radius:12px;max-width:680px;width:100%;max-height:82vh;display:flex;flex-direction:column;overflow:hidden;font-size:16px!important;line-height:1.6!important;color:#1c2530;font-family:"+Ve+"!important;",l.appendChild(p);let g=document.createElement("div");g.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #d0d5dd;font-weight:700;";let m=document.createElement("span");m.textContent=`${e.title??"Riwayat Resume"} (${a.length})`,g.appendChild(m);let h=document.createElement("button");h.type="button",h.textContent="\xD7",h.style.cssText="border:none;background:#f8fafc;width:32px;height:32px;border-radius:50%;font-family:inherit!important;font-size:16px!important;line-height:1!important;cursor:pointer;",h.onclick=function(){l.remove()},g.appendChild(h),p.appendChild(g);let w=document.createElement("div");w.style.cssText="padding:14px 18px;overflow-y:auto;",p.appendChild(w);let S=L=>{if(a=L,m.textContent=`${e.title??"Riwayat Resume"} (${a.length})`,w.replaceChildren(),!a.length){w.textContent="Belum ada riwayat untuk kunjungan ini. Riwayat tercatat otomatis setiap kali Simpan ditekan.";return}a.forEach(function(y,N){let P=a.length-N,A=document.createElement("div");A.style.cssText="border:1px solid #d0d5dd;border-radius:8px;padding:10px 12px;margin-bottom:10px;";let z=document.createElement("div");z.style.fontWeight="600";let F=y.user?` \u2014 oleh ${y.user}`:"";z.textContent=`#${P} \u2014 ${new Date(y.at).toLocaleString("id-ID")} \u2014 ${y.aksi==="buat"?"Buat baru":"Ubah"}${F} \u2014 ${y.changed.length} field berubah`,A.appendChild(z);let T=document.createElement("div");T.style.cssText="display:none;margin-top:8px;background:#f8fafc;border-radius:6px;padding:8px 10px;font-size:13px;line-height:1.6;max-height:180px;overflow-y:auto;white-space:pre-wrap;",y.changed.length?T.textContent=y.changed.map(function(M){return M+": "+De(y.before[M])+" \u2192 "+De(y.after[M])}).join(`
`):T.textContent="Tidak ada perbedaan field.",A.appendChild(T);let $=document.createElement("div");$.style.cssText="margin-top:8px;display:flex;gap:8px;";let q=document.createElement("button");q.type="button",q.textContent="Lihat",q.style.cssText="border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",q.onclick=function(){T.style.display=T.style.display==="none"?"block":"none"},$.appendChild(q);let B=document.createElement("button");B.type="button",B.textContent="Salin ke Form",B.style.cssText="background:#00875a;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",B.onclick=function(){try{e.onApply(y.after),l.remove()}catch{}},$.appendChild(B),A.appendChild($),w.appendChild(A)})};S(a);try{document.body.appendChild(l)}catch{}if(e.idVisit){let L=X();if(L)try{let y=document.createElement("div");y.textContent=L+" \u2014 riwayat hanya dari PC ini.",y.style.cssText="margin-top:10px;padding:8px 10px;background:#fef3c7;color:#92400e;border-radius:6px;font-size:13px;line-height:1.5;",w.appendChild(y)}catch{}else try{wt(e.idVisit,e.tipe).then(y=>{try{if(!y.length||!l.isConnected)return;let N=[];for(let z of y){let F=zt(z,e.tipe);F&&N.push(F)}if(!N.length)return;let P=W(e.idVisit,e.tipe,r),A=Vt(P,N);if(A.length===P.length)return;ie(A,e.idVisit,e.tipe,r),S(A.slice().reverse());try{document.dispatchEvent(new CustomEvent("ext-rv-history-merged",{detail:{idVisit:e.idVisit,tipe:e.tipe,count:A.length}}))}catch{}}catch{}})}catch{}}}var Re="ext_migrated_preop_ids",Ue=Le,se=20;function Je(e,r){if(!e)return null;try{let a=e.getItem(r);return a?JSON.parse(a):null}catch{return null}}function Pe(e,r,a){if(e)try{e.setItem(r,JSON.stringify(a))}catch{}}function Ut(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}async function le(e,r,a=fetch){let d=ee(),l=X(d);if(l)return console.warn("[casemixBackfill]",l,"\u2014 backfill dilewati:",e),!1;try{return(await a(d+e,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(r),credentials:"omit"})).ok}catch{return!1}}function Jt(e,r){let a=new Set(r);return Object.keys(e).filter(d=>!a.has(d)).slice(0,se)}function Pt(e,r){return e.filter(a=>a.at>r).slice(0,se)}function Ft(e){let r=[];if(!e)return r;try{let a=[],d=e;if(typeof d.length=="number"&&d.key)for(let l=0;l<d.length;l++){let p=d.key(l);p&&a.push(p)}for(let l of a){let p=l.match(/^ext_rv_history_(ri|rj)_(.+)$/);if(p){r.push({key:l,idVisit:p[2],tipe:p[1]==="ri"?"ranap":"rajal"});continue}p=l.match(/^ext_rv_history_(.+)$/),p&&!p[1].startsWith("ri_")&&!p[1].startsWith("rj_")&&r.push({key:l,idVisit:p[1],tipe:"ranap"})}}catch{}return r}async function Mt(e=Ut(),r=fetch){let a={preopUploaded:0,resumeUploaded:0,offline:!1};if(!e)return a;try{let d=ft(e),l=Je(e,Re)??[],p=Jt(d,l);for(let g of p){let m=d[g];if(m){if(!await le("/api/casemix/pre-op/toggle",{id_visit:g,marked:!0,norm:m.norm??null,nama:m.nama??null,no_reg:m.noReg??null,user:null},r)){a.offline=!0;break}l.push(g),a.preopUploaded++}}try{let g=new Set(Object.keys(d)),m=[];for(let h of l){if(g.has(h)){m.push(h);continue}if(a.offline){m.push(h);continue}await le("/api/casemix/pre-op/toggle",{id_visit:h,marked:!1},r)?a.preopUploaded++:(a.offline=!0,m.push(h))}(m.length!==l.length||a.preopUploaded>0)&&Pe(e,Re,m)}catch{}}catch{a.offline=!0}try{for(let{key:d,idVisit:l,tipe:p}of Ft(e)){if(!l||l==="unknown")continue;if(a.resumeUploaded>=se)break;let g=Je(e,Ue+d)??0,m=W(l,p,e),h=Pt(m,g),w=g;for(let S of h){if(!await le("/api/reports/resume-history",{client_id:S.client_id??null,id_visit:l,id_resume:S.id_resume,aksi:S.aksi,tipe:S.tipe??p,waktu:new Date(S.at).toISOString(),user:S.user,before:S.before,after:S.after,changed:S.changed},r)){a.offline=!0;break}w=Math.max(w,S.at),a.resumeUploaded++}if(w>g&&Pe(e,Ue+d,w),a.offline)break}}catch{a.offline=!0}try{(a.preopUploaded||a.resumeUploaded)&&window.console.debug(`[casemixBackfill] diunggah: ${a.preopUploaded} pre-op, ${a.resumeUploaded} resume`)}catch{}return a}var Fe=null;function Ht(){if(Fe!==null)return;let e=()=>{try{if(document.hidden)return}catch{}Mt().catch(()=>{})};window.setTimeout(e,5e3),Fe=window.setInterval(e,3e4)}(function(){let e=0,r=setInterval(function(){e++;let t=document.documentElement.getAttribute("data-ext-resume-validator"),i=document.documentElement.getAttribute("data-ext-resume-history");if(t!==null||i!==null){clearInterval(r);let n=t==="1",o=i==="1"||n;if(!n&&!o)return;d(n,o)}else e>=100&&clearInterval(r)},50);function a(){let t=window.location.pathname;return t.includes("/tambah-resume-ri")||t.includes("/edit-resume-ri")?"ranap":t.includes("/rm-rawat-jalan-new")?"rajal":null}function d(t,i){let n=a();if(!n)return;let o=setInterval(function(){let s=document.getElementById("save"),u=n==="ranap"?document.querySelector('form[action*="rawat-inap-resume"], form[action*="edit-resume-rawat-inap"]'):document.querySelector('form#formdata, form[action*="rm-rawat-jalan"]');s&&u&&(clearInterval(o),l(u,s,n,t,i))},200)}function l(t,i,n,o,s){p();try{Ht()}catch{}if(s&&g(t,n,o),!o){s&&M(t,i,n);return}ca(n),n==="ranap"&&(T("ranap")||(F(),P(t))),Gt(),Yt(),aa(),Zt(n),Qt(),Xt(),na(n),ra(n),Wt(t),M(t,i,n)}function p(){ye("ext-rv-css",[`.ext-rv-error { border: 2px solid ${I.error} !important; background: ${I.errorBg} !important; transition: all 0.2s; }`,".ext-rv-toast { position: fixed; top: 20px; right: 20px; z-index: 99999; padding: 16px 24px; border-radius: 8px; font-size: 14px; font-weight: 600; box-shadow: 0 4px 16px rgba(0,0,0,0.15); max-width: 420px; line-height: 1.5; }",`.ext-rv-toast-error { background: ${I.errorBg}; color: #991b1b; border-left: 5px solid ${I.error}; }`,`.ext-rv-toast-success { background: ${I.successBg}; color: #065f46; border-left: 5px solid ${I.success}; }`,`.ext-rv-icd-valid { border: 2px solid ${I.success} !important; background: ${I.successBg} !important; }`,`.ext-rv-icd-invalid { border: 2px solid ${I.error} !important; background: ${I.errorBg} !important; }`].join(`
`))}function g(t,i,n){let o=window;if(i==="rajal"){let f=typeof o.simpan=="function"?o.simpan:null;if(f&&!f.__extWrapped){let k=function(...v){if(n&&!G(i))return!1;B(t,i),H=!1;try{localStorage.removeItem(S())}catch{}return f.apply(this,v)};k.__extWrapped=!0,o.simpan=k}}else n&&(o.cekForm=function(){return G(i)});t.onsubmit!==null&&(t.onsubmit=function(f){let k=n?G(i):!0;return!k&&f?f.preventDefault():B(t,i),k});let s=o.jQuery;n&&typeof s=="object"&&s&&typeof s.fn?.on=="function"&&s.fn.on("submit",function(f){return G(i)?!0:(f.preventDefault(),!1)});var u=t.submit.bind(t);t.submit=function(){if(!(n&&!G(i))){B(t,i),H=!1,A();try{localStorage.removeItem(S())}catch{}u()}}}let m="ext_draft_resume_";var h=null,w=4320*60*1e3;function S(){let t=c("id_visit");return m+(t||"unknown")}var L=null,y=2e3;function N(t,i){return function(){L&&clearTimeout(L),L=setTimeout(t,i)}}function P(t){var i=function(){z(t)},n=t.querySelectorAll("input, textarea, select");n.forEach(function(o){o.addEventListener("change",N(i,y)),o.addEventListener("input",N(i,y))}),h=setInterval(i,3e4)}function A(){h!==null&&(clearInterval(h),h=null)}function z(t){let i=S(),n=new FormData(t),o={};n.forEach(function(s,u){o[u]=s.toString()}),o._saved_at=Date.now().toString();try{localStorage.setItem(i,JSON.stringify({savedAt:Date.now(),data:o}))}catch{}}async function F(){let t=S(),i=null;try{i=localStorage.getItem(t)}catch{return}if(!i)return;let n;try{n=JSON.parse(i)}catch{return}if(typeof n.savedAt!="number"||typeof n.data!="object"||n.data===null||Date.now()-n.savedAt>=w){try{localStorage.removeItem(t)}catch{}return}let o=n.data,s=function(){for(let u in o){if(u==="_saved_at")continue;let f=document.querySelector('[name="'+u+'"]');f&&!f.value&&(f.value=o[u])}try{localStorage.removeItem(t)}catch{}};if(await Se({title:"Draft Ditemukan",message:"Data draft sebelumnya ditemukan. Pulihkan?",variant:"info",okLabel:"Pulihkan",cancelLabel:"Hapus"}))s();else try{localStorage.removeItem(t)}catch{}}function T(t){let i=t==="rajal"?"id_rawat_jalan":"id_resume_inap",n=document.getElementById(i);return!!n&&!!n.value}var $=null;function q(){return c("id_visit")}function B(t,i){let n=Me(t),o=q(),s=c(i==="rajal"?"id_rawat_jalan":"id_resume_inap"),u=T(i)?"ubah":"buat",f=Ct(o,i)||{};Nt({idVisit:o,idResume:s,tipe:i,aksi:u,before:f,after:n}),ae(o,i)}function M(t,i,n){let o=q();if(oe(Me(t),o,n),ae(o,n),$||!i.parentElement)return;let s=document.createElement("button");s.type="button",s.id="ext-rv-history-btn",s.textContent="Riwayat",s.style.cssText="margin-left:8px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:13px;",s.onclick=function(){Rt({idVisit:o,tipe:n,title:n==="rajal"?"Riwayat Resume Rajal":"Riwayat Resume Rawat Inap",zIndex:99998,onApply:function(u){Kt(t,u)}})},i.parentElement.insertBefore(s,i.nextSibling),$=s,ae(o,n),window.addEventListener("ext-rv-history-merged",function(u){try{let f=u.detail;f&&f.idVisit===o&&f.tipe===n&&ae(o,n)}catch{}})}function ae(t,i){if(!$)return;let n=W(t,i).length;$.textContent=n>0?"Riwayat ("+n+")":"Riwayat"}function Me(t){let i={},n=/^(kode_|diagnosa_|tindakan\d+$|nosokomial\d+$|kode\d+$|kode9\d+$)/;return t.querySelectorAll("input[name], textarea[name], select[name], input[id]:not([name]):not([type=button]):not([type=submit]), textarea[id]:not([name]), select[id]:not([name])").forEach(function(o){let s=o.getAttribute("name")||(n.test(o.id)?o.id:"");if(!s||s==="_saved_at"||s==="save")return;if(o instanceof HTMLInputElement&&(o.type==="checkbox"||o.type==="radio")){if(!o.checked)return;let f=i[s];f===void 0?i[s]=o.value:Array.isArray(f)?f.push(o.value):i[s]=[f,o.value];return}if(o instanceof HTMLSelectElement&&o.multiple){i[s]=Array.from(o.selectedOptions).map(function(f){return f.value});return}let u=i[s];u!==void 0&&!Array.isArray(u)?i[s]=[u,o.value]:Array.isArray(u)?u.push(o.value):i[s]=o.value}),i}function Kt(t,i){let n=0,o=0;Object.keys(i).forEach(function(s){let u=i[s],f=Array.from(t.querySelectorAll('[name="'+s+'"]'));if(!f.length){let v=t.querySelector("#"+CSS.escape(s));f=v?[v]:[]}if(!f.length){o++;return}let k=Array.isArray(u)?u:[u];f.forEach(function(v,_){if(v instanceof HTMLInputElement&&(v.type==="checkbox"||v.type==="radio"))v.checked=Array.isArray(u)?u.indexOf(v.value)>=0:v.value===u;else if(v instanceof HTMLSelectElement&&v.multiple){let b=Array.isArray(u)?u:[u];Array.from(v.options).forEach(function(E){E.selected=b.indexOf(E.value)>=0})}else v.value=k[_]??"";v.dispatchEvent(new Event("input",{bubbles:!0})),v.dispatchEvent(new Event("change",{bubbles:!0})),n++})}),qt("Disalin "+n+" field"+(o>0?", "+o+" nama tak ditemukan":"")+". Periksa lalu klik Simpan.")}let H=!1;function Wt(t){var i=t.querySelectorAll("input, textarea, select");i.forEach(function(n){n.addEventListener("change",function(){H=!0}),n.addEventListener("input",function(){H=!0})}),t.addEventListener("submit",function(){H=!1}),window.addEventListener("beforeunload",function(n){if(H)return n.preventDefault(),n.returnValue="Data yang belum disimpan akan hilang.",n.returnValue})}function Gt(){[{id:"suhu_pulang",min:30,max:45,step:.1},{id:"suhu",min:30,max:45,step:.1},{id:"nadi_pulang",min:20,max:250,step:1},{id:"nadi",min:20,max:250,step:1},{id:"rr_pulang",min:4,max:80,step:1},{id:"nafas",min:4,max:80,step:1},{id:"spo2_pulang",min:50,max:100,step:1},{id:"spo2",min:50,max:100,step:1},{id:"gcs_e",min:1,max:4,step:1},{id:"gcs_m",min:1,max:6,step:1},{id:"gcs_v",min:1,max:5,step:1},{id:"tinggi",min:30,max:250,step:1},{id:"berat",min:1,max:500,step:.1}].forEach(function(t){var i=document.getElementById(t.id);if(i){var n=i.value.trim();(n==="-"||n===""||isNaN(Number(n)))&&(i.value=""),i.type="number",i.min=String(t.min),i.max=String(t.max),i.step=String(t.step),i.placeholder||(i.placeholder=t.min+"-"+t.max)}})}function Yt(){var t=["td_pulang","td","tensi","tensi_pulang"];t.forEach(function(i){var n=document.getElementById(i);n&&(n.placeholder="120/80",n.pattern="[0-9]{2,3}/[0-9]{2,3}",n.title="Format: angka/angka (Contoh: 120/80)")})}function Zt(t){var i=t==="rajal"?["anamnesa","catatan","terapi_pengobatan","jenis_kasus","tindak_lanjut"]:["alasan_rawat","anamnesa","diagnosa_primary","kode_diagnosa_utama","jenis_kasus","keadaan_keluar","cara_keluar","tgl_keluar2"];i.forEach(function(n){var o=document.getElementById(n);o&&(o.required=!0)})}function Qt(){document.querySelectorAll('input:not([type="submit"]):not([type="button"])').forEach(function(t){t.addEventListener("keydown",function(i){i.key==="Enter"&&i.preventDefault()})})}function Xt(){document.querySelectorAll("textarea").forEach(function(t){t.style.overflow="hidden",t.style.resize="vertical",t.addEventListener("input",function(){t.style.height="auto",t.style.height=t.scrollHeight+"px"})})}let ea=["td_pulang","tensi","nadi_pulang","suhu_pulang","rr_pulang","spo2_pulang","gcs_e","gcs_m","gcs_v"];function ta(){let t=document.getElementById("keadaan_keluar")?.value||"",i=document.getElementById("cara_keluar")?.value||"";return[t,i,document.getElementById("keadaan_keluar")?.options[document.getElementById("keadaan_keluar")?.selectedIndex??0]?.text||"",document.getElementById("cara_keluar")?.options[document.getElementById("cara_keluar")?.selectedIndex??0]?.text||""].some(n=>/meninggal/i.test(n))}function ue(){let t=ta();ea.forEach(function(i){var n=document.getElementById(i);n&&(t?(n.value&&!n.dataset.originalValue&&(n.dataset.originalValue=n.value),n.value="",n.disabled=!0,n.style.backgroundColor="#f5f5f5",n.style.color="#999",n.title="Otomatis kosong: pasien meninggal dunia"):(n.dataset.originalValue&&(n.value=n.dataset.originalValue,delete n.dataset.originalValue),n.disabled=!1,n.style.backgroundColor="",n.style.color="",n.title=""))})}function aa(){let t=document.getElementById("keadaan_keluar"),i=document.getElementById("cara_keluar");ue(),t&&t.addEventListener("change",ue),i&&i.addEventListener("change",ue)}function na(t){var i=He(t),n=Ke(t);i.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("input",function(){var u=s.value.trim();s.classList.remove("ext-rv-icd-valid","ext-rv-icd-invalid"),u!==""&&(/^[A-Z][0-9][0-9](\.[0-9]{1,2})?$/i.test(u)?s.classList.add("ext-rv-icd-valid"):s.classList.add("ext-rv-icd-invalid"))})}),n.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("input",function(){var u=s.value.trim();s.classList.remove("ext-rv-icd-valid","ext-rv-icd-invalid"),u!==""&&(/^[0-9]{2}(\.[0-9]{1,2})?$/.test(u)?s.classList.add("ext-rv-icd-valid"):s.classList.add("ext-rv-icd-invalid"))})})}function ra(t){var i=He(t);i.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("blur",function(){var u=s.value.trim().toUpperCase();u&&(u=u.replace(".",""),u.length>3&&(u=u.substring(0,3)+"."+u.substring(3)),s.value=u,s.dispatchEvent(new Event("input")))})});var n=Ke(t);n.forEach(function(o){let s=document.getElementById(o);s&&s.addEventListener("blur",function(){var u=s.value.trim();u&&(u=u.replace(".",""),u.length>2&&(u=u.substring(0,2)+"."+u.substring(2)),s.value=u,s.dispatchEvent(new Event("input")))})})}function He(t){if(t==="rajal"){let o=[];if(document.querySelectorAll('input[name="kode10[]"]').forEach(function(u){u.id&&o.push(u.id)}),o.length)return o;let s=[];for(let u=1;u<=20;u++)s.push("kode"+u);return s}for(var i=["kode_diagnosa_utama"],n=1;n<=10;n++)i.push("kode_diagnosa_sekunder"+n);return i}function Ke(t){if(t==="rajal"){let o=[];if(document.querySelectorAll('input[name="kode9[]"]').forEach(function(u){u.id&&o.push(u.id)}),o.length)return o;let s=[];for(let u=1;u<=20;u++)s.push("kode9"+u);return s}for(var i=[],n=1;n<=10;n++)i.push("kode_tindakan"+n);return i}function G(t){sa();var i=[];function n(s,u,f){s||i.push({msg:u,id:f})}function o(s,u){let f=c(s);x(f)||ke(f)||n(!1,u+" tidak boleh hanya berisi simbol atau karakter khusus",s)}return t==="rajal"?oa(n,o):ia(n,o),i.length>0?(la(i),!1):!0}function ia(t,i){t(!!c("norm"),"No. RM harus diisi","norm"),t(!!c("pasien"),"Nama pasien harus diisi","pasien"),t(!!c("id_visit"),"Data kunjungan tidak valid","pasien"),i("alasan_rawat","Alasan rawat"),i("anamnesa","Anamnesa"),i("diagnosa_primary","Diagnosa primary"),i("terapi_pengobatan","Terapi/pengobatan"),t(!!c("kode_diagnosa_utama"),"Kode ICD-10 Diagnosa Utama harus diisi","kode_diagnosa_utama"),c("kode_diagnosa_utama")&&!x(c("kode_diagnosa_utama"))&&t(J(c("kode_diagnosa_utama")),"Format kode ICD-10 Diagnosa Utama tidak valid (contoh: A00, B20.9)","kode_diagnosa_utama"),c("diagnosa_utama")&&!de("kode_diagnosa_utama",J)&&t(!!c("id_diagnosa_utama"),"Diagnosa Utama harus dipilih dari hasil pencarian (autocomplete)","diagnosa_utama");for(var n=1;n<=10;n++){var o=c("kode_diagnosa_sekunder"+n),s=c("diagnosa_sekunder"+n),u=c("id_diagnosa_sekunder"+n);o&&!x(o)&&t(J(o),"Format kode ICD-10 Diagnosa Sekunder "+n+" tidak valid","kode_diagnosa_sekunder"+n),s&&!x(s)&&!de("kode_diagnosa_sekunder"+n,J)&&t(!!u,"Diagnosa Sekunder "+n+" harus dipilih dari hasil pencarian","diagnosa_sekunder"+n)}for(var f=1;f<=10;f++){var k=c("kode_tindakan"+f),v=c("tindakan"+f),_=c("id_tindakan"+f);k&&!x(k)&&t(Z(k),"Format kode ICD-9 Tindakan "+f+" tidak valid (contoh: 45.16)","kode_tindakan"+f),v&&!x(v)&&!de("kode_tindakan"+f,Z)&&t(!!_,"Tindakan "+f+" harus dipilih dari hasil pencarian (autocomplete)","tindakan"+f)}var b=c("td_pulang")||c("tensi");b&&!x(b)&&t(be(b),"Tekanan darah pulang tidak valid (contoh: 120/80)",c("td_pulang")?"td_pulang":"tensi");var E=c("keadaan_keluar"),C=E&&/meninggal\s*dunia/i.test(E),V=c("nadi_pulang");!C&&V&&!x(V)&&t(j(V,20,250),"Nadi pulang harus 20-250","nadi_pulang");var R=c("suhu_pulang");!C&&R&&!x(R)&&t(j(R,30,45),"Suhu pulang harus 30-45\xB0C","suhu_pulang");var D=c("rr_pulang");!C&&D&&!x(D)&&t(j(D,4,120),"RR pulang harus 4-120","rr_pulang");var fe=c("spo2_pulang");!C&&fe&&!x(fe)&&t(j(fe,50,100),"SpO2 pulang harus 50-100%","spo2_pulang"),t(!!c("jenis_kasus"),"Jenis kasus harus dipilih","jenis_kasus"),t(!!c("keadaan_keluar"),"Keadaan keluar harus dipilih","keadaan_keluar"),t(!!c("cara_keluar"),"Cara keluar harus dipilih","cara_keluar"),t(!!(c("tgl_keluar2")||c("tgl_keluar")),"Tanggal keluar harus diisi","tgl_keluar2");var pe=c("gcs_e");!C&&pe&&!x(pe)&&t(j(pe,1,4),"GCS Eye harus 1-4","gcs_e");var me=c("gcs_m");!C&&me&&!x(me)&&t(j(me,1,6),"GCS Motor harus 1-6","gcs_m");var K=c("gcs_v");!C&&K&&!x(K)&&t(j(K,1,5),"GCS Verbal harus 1-5","gcs_v");var he=c("gcs_e"),ge=c("gcs_m");if(!C&&he&&ge&&K&&!x(he)&&!x(ge)&&!x(K)){var We=Number(he)+Number(ge)+Number(K);t(j(String(We),3,15),"Total GCS (E+M+V) harus 3-15, saat ini "+We,"gcs_v")}var fa=Y("pasien_rujuk_masuk_opsi").toLowerCase();fa==="ya"&&t(ce("pasien_rujuk_masuk"),"Alasan Datang poin A: pilih asal rujukan masuk","pasien_rujuk_masuk_opsi-ya");var pa=Y("pasien_rujuk_dikembalikan_opsi").toLowerCase();pa==="ya"&&t(ce("pasien_rujuk_dikembalikan"),"Alasan Datang poin B: pilih asal rujukan dikembalikan","pasien_rujuk_dikembalikan_opsi-ya");var ma=Y("pasien_dirujuk_keluar_opsi").toLowerCase();ma==="ya"&&t(ce("pasien_rujuk_keluar"),"Alasan Datang poin C: pilih rujukan keluar","pasien_dirujuk_keluar_opsi-ya");var ha=Y("menggunakan_kb_opsi").toLowerCase();ha==="ya"&&(t(!!c("jenis_kb"),"Pelayanan KB: jenis KB harus dipilih","jenis_kb"),t(!!c("waktu_kb"),"Pelayanan KB: waktu KB harus dipilih","waktu_kb"),t(da(".monitoring_kb"),"Pelayanan KB: pilih minimal satu monitoring KB","monitoring_kb-komplikasi_kb"));var ga=Y("cek_status_covid").toLowerCase();ga==="1"&&t(!!c("status_covid"),"Status COVID: pilih jenis COVID","status_covid");var Ge=c("tgl_masuk")||c("tgl_masuk2"),Ye=c("tgl_keluar2")||c("tgl_keluar");if(Ge&&Ye){let xe=function(Ze){let U=Ze.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})(?:\s+(\d{1,2}):(\d{2}):(\d{2}))?/);if(U)return new Date(+U[3],+U[2]-1,+U[1],+(U[4]||0),+(U[5]||0),+(U[6]||0)).getTime();let Qe=Date.parse(Ze);return isNaN(Qe)?0:Qe};var xa=xe;t(xe(Ye)>=xe(Ge),"Tanggal keluar tidak boleh sebelum tanggal masuk","tgl_keluar2")}}function oa(t,i){t(!!c("id_visit"),"Data kunjungan tidak valid","id_visit"),t(!!c("nama_pasien"),"Nama pasien harus diisi","nama_pasien"),i("anamnesa","Anamnesa"),i("catatan","Catatan diagnosa"),i("terapi_pengobatan","Terapi/pengobatan"),["pemeriksaan_fisik","tindakan","planning"].forEach(function(_){let b=c(_);b&&!x(b)&&!ke(b)&&t(!1,(_==="pemeriksaan_fisik"?"Pemeriksaan fisik":_==="planning"?"Planning":"Tindakan")+" tidak boleh hanya berisi simbol atau karakter khusus",_)}),document.querySelectorAll('input[name="kode10[]"]').forEach(function(_,b){let E=(_.value||"").trim(),C=_.closest("tr"),V=(C?.querySelector('input[name="idicd[]"]')?.value||"").trim(),R=(C?.querySelector('input[name="nama[]"]')?.value||"").trim(),D=_.id||`kode10-${b}`;E&&!x(E)&&!J(E)&&t(!1,"Format kode ICD-10 baris "+(b+1)+" tidak valid (contoh: A00, B20.9)",D),(!x(E)||!x(R))&&!V&&!J(E)&&t(!1,"Diagnosa baris "+(b+1)+" harus dipilih dari hasil pencarian (autocomplete)",D)}),document.querySelectorAll('input[name="kode9[]"]').forEach(function(_,b){let E=(_.value||"").trim(),C=_.closest("tr"),V=(C?.querySelector('input[name="idicdTindakan[]"]')?.value||"").trim(),R=(C?.querySelector('input[name="namaTindakan[]"]')?.value||"").trim(),D=_.id||`kode9-${b}`;E&&!x(E)&&!Z(E)&&t(!1,"Format kode ICD-9 Tindakan baris "+(b+1)+" tidak valid (contoh: 45.16)",D),(!x(E)||!x(R))&&!V&&!Z(E)&&t(!1,"Tindakan baris "+(b+1)+" harus dipilih dari hasil pencarian (autocomplete)",D)});let n=c("tensi");n&&!x(n)&&t(be(n),"Tekanan darah tidak valid (contoh: 120/80)","tensi");let o=c("nadi");o&&!x(o)&&t(j(o,20,250),"Nadi harus 20-250","nadi");let s=c("suhu");s&&!x(s)&&t(j(s,30,45),"Suhu harus 30-45\xB0C","suhu");let u=c("nafas");u&&!x(u)&&t(j(u,4,80),"Nafas harus 4-80","nafas");let f=c("spo2");f&&!x(f)&&t(j(f,50,100),"SpO2 harus 50-100%","spo2");let k=c("tinggi");k&&!x(k)&&t(j(k,30,250),"Tinggi badan harus 30-250 cm","tinggi");let v=c("berat");v&&!x(v)&&t(j(v,1,500),"Berat badan harus 1-500 kg","berat"),t(!!c("jenis_kasus"),"Jenis kasus harus dipilih","jenis_kasus"),t(!!c("tindak_lanjut"),"Tindak lanjut harus dipilih","tindak_lanjut")}function sa(){document.querySelectorAll(".ext-rv-error").forEach(function(t){t.classList.remove("ext-rv-error")})}function la(t){var i=t[0];let n=document.getElementById(i.id);n&&(n.focus(),n.classList.add("ext-rv-error"),setTimeout(function(){n.classList.remove("ext-rv-error")},3e3));for(var o=1;o<t.length;o++){var s=document.getElementById(t[o].id);s&&(s.classList.add("ext-rv-error"),(function(k){setTimeout(function(){k.classList.remove("ext-rv-error")},3e3)})(s))}for(var u=[],o=0;o<t.length;o++)u.push("\u2022 "+t[o].msg);var f=u.join(`
`);Se({title:"Validasi Gagal ("+t.length+" masalah)",message:f,variant:"warning",okLabel:"OK",hideCancel:!0})}function ua(t){return document.getElementById(t)}function c(t){return ua(t)?.value?.trim()||""}function de(t,i){let n=c(t);return!!n&&!x(n)&&i(n)}function Y(t){return document.querySelector('input[name="'+t+'"]:checked')?.value||""}function ce(t){return document.querySelector('input[name="'+t+'"]:checked')!==null}function da(t){return document.querySelector(t+":checked")!==null}function ca(t){if(t==="rajal")return;function i(f,k){var v=document.getElementById(f);v&&v.addEventListener("input",function(_){if(!(_&&_.isTrusted===!1)){var b=document.getElementById(k);b&&(b.value="")}})}i("kode_diagnosa_utama","id_diagnosa_utama"),i("diagnosa_utama","id_diagnosa_utama");for(var n=1;n<=10;n++){var o="id_diagnosa_sekunder"+n;i("kode_diagnosa_sekunder"+n,o),i("diagnosa_sekunder"+n,o)}for(var s=1;s<=10;s++){var u="id_tindakan"+s;i("kode_tindakan"+s,u),i("tindakan"+s,u)}}})()})();
