"use strict";var __morbis_feature=(()=>{var ym=Object.create,lo=Object.defineProperty,wm=Object.getOwnPropertyDescriptor,xm=Object.getOwnPropertyNames,km=Object.getPrototypeOf,Sm=Object.prototype.hasOwnProperty,so=(i,s,c)=>()=>{if(c)throw c[0];try{return i&&(s=i(i=0)),s}catch(u){throw c=[u],u}},Ht=(i,s)=>()=>{try{return s||i((s={exports:{}}).exports,s),s.exports}catch(c){throw s=0,c}},Cm=(i,s)=>{for(var c in s)lo(i,c,{get:s[c],enumerable:!0})},fc=(i,s,c,u)=>{if(s&&typeof s=="object"||typeof s=="function")for(let f of xm(s))!Sm.call(i,f)&&f!==c&&lo(i,f,{get:()=>s[f],enumerable:!(u=wm(s,f))||u.enumerable});return i},Ne=(i,s,c)=>(c=i!=null?ym(km(i)):{},fc(s||!i||!i.__esModule?lo(c,"default",{value:i,enumerable:!0}):c,i)),zm=i=>fc(lo({},"__esModule",{value:!0}),i),_m=Ht(i=>{"use strict";function s(D,O){var M=D.length;D.push(O);e:for(;0<M;){var ge=M-1>>>1,$=D[ge];if(0<f($,O))D[ge]=O,D[M]=$,M=ge;else break e}}function c(D){return D.length===0?null:D[0]}function u(D){if(D.length===0)return null;var O=D[0],M=D.pop();if(M!==O){D[0]=M;e:for(var ge=0,$=D.length,ot=$>>>1;ge<ot;){var g=2*(ge+1)-1,R=D[g],F=g+1,H=D[F];if(0>f(R,M))F<$&&0>f(H,R)?(D[ge]=H,D[F]=M,ge=F):(D[ge]=R,D[g]=M,ge=g);else if(F<$&&0>f(H,M))D[ge]=H,D[F]=M,ge=F;else break e}}return O}function f(D,O){var M=D.sortIndex-O.sortIndex;return M!==0?M:D.id-O.id}i.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"?(b=performance,i.unstable_now=function(){return b.now()}):(h=Date,w=h.now(),i.unstable_now=function(){return h.now()-w});var b,h,w,C=[],x=[],y=1,k=null,S=3,q=!1,X=!1,B=!1,G=!1,oe=typeof setTimeout=="function"?setTimeout:null,U=typeof clearTimeout=="function"?clearTimeout:null,V=typeof setImmediate<"u"?setImmediate:null;function N(D){for(var O=c(x);O!==null;){if(O.callback===null)u(x);else if(O.startTime<=D)u(x),O.sortIndex=O.expirationTime,s(C,O);else break;O=c(x)}}function I(D){if(B=!1,N(D),!X)if(c(C)!==null)X=!0,ae||(ae=!0,De());else{var O=c(x);O!==null&&Qe(I,O.startTime-D)}}var ae=!1,re=-1,L=5,Q=-1;function ue(){return G?!0:!(i.unstable_now()-Q<L)}function at(){if(G=!1,ae){var D=i.unstable_now();Q=D;var O=!0;try{e:{X=!1,B&&(B=!1,U(re),re=-1),q=!0;var M=S;try{t:{for(N(D),k=c(C);k!==null&&!(k.expirationTime>D&&ue());){var ge=k.callback;if(typeof ge=="function"){k.callback=null,S=k.priorityLevel;var $=ge(k.expirationTime<=D);if(D=i.unstable_now(),typeof $=="function"){k.callback=$,N(D),O=!0;break t}k===c(C)&&u(C),N(D)}else u(C);k=c(C)}if(k!==null)O=!0;else{var ot=c(x);ot!==null&&Qe(I,ot.startTime-D),O=!1}}break e}finally{k=null,S=M,q=!1}O=void 0}}finally{O?De():ae=!1}}}var De;typeof V=="function"?De=function(){V(at)}:typeof MessageChannel<"u"?(Ye=new MessageChannel,Dt=Ye.port2,Ye.port1.onmessage=at,De=function(){Dt.postMessage(null)}):De=function(){oe(at,0)};var Ye,Dt;function Qe(D,O){re=oe(function(){D(i.unstable_now())},O)}i.unstable_IdlePriority=5,i.unstable_ImmediatePriority=1,i.unstable_LowPriority=4,i.unstable_NormalPriority=3,i.unstable_Profiling=null,i.unstable_UserBlockingPriority=2,i.unstable_cancelCallback=function(D){D.callback=null},i.unstable_forceFrameRate=function(D){0>D||125<D?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):L=0<D?Math.floor(1e3/D):5},i.unstable_getCurrentPriorityLevel=function(){return S},i.unstable_next=function(D){switch(S){case 1:case 2:case 3:var O=3;break;default:O=S}var M=S;S=O;try{return D()}finally{S=M}},i.unstable_requestPaint=function(){G=!0},i.unstable_runWithPriority=function(D,O){switch(D){case 1:case 2:case 3:case 4:case 5:break;default:D=3}var M=S;S=D;try{return O()}finally{S=M}},i.unstable_scheduleCallback=function(D,O,M){var ge=i.unstable_now();switch(typeof M=="object"&&M!==null?(M=M.delay,M=typeof M=="number"&&0<M?ge+M:ge):M=ge,D){case 1:var $=-1;break;case 2:$=250;break;case 5:$=1073741823;break;case 4:$=1e4;break;default:$=5e3}return $=M+$,D={id:y++,callback:O,priorityLevel:D,startTime:M,expirationTime:$,sortIndex:-1},M>ge?(D.sortIndex=M,s(x,D),c(C)===null&&D===c(x)&&(B?(U(re),re=-1):B=!0,Qe(I,M-ge))):(D.sortIndex=$,s(C,D),X||q||(X=!0,ae||(ae=!0,De()))),D},i.unstable_shouldYield=ue,i.unstable_wrapCallback=function(D){var O=S;return function(){var M=S;S=O;try{return D.apply(this,arguments)}finally{S=M}}}}),Em=Ht((i,s)=>{"use strict";s.exports=_m()}),Nm=Ht(i=>{"use strict";var s=Symbol.for("react.transitional.element"),c=Symbol.for("react.portal"),u=Symbol.for("react.fragment"),f=Symbol.for("react.strict_mode"),b=Symbol.for("react.profiler"),h=Symbol.for("react.consumer"),w=Symbol.for("react.context"),C=Symbol.for("react.forward_ref"),x=Symbol.for("react.suspense"),y=Symbol.for("react.memo"),k=Symbol.for("react.lazy"),S=Symbol.for("react.activity"),q=Symbol.iterator;function X(g){return g===null||typeof g!="object"?null:(g=q&&g[q]||g["@@iterator"],typeof g=="function"?g:null)}var B={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},G=Object.assign,oe={};function U(g,R,F){this.props=g,this.context=R,this.refs=oe,this.updater=F||B}U.prototype.isReactComponent={},U.prototype.setState=function(g,R){if(typeof g!="object"&&typeof g!="function"&&g!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,g,R,"setState")},U.prototype.forceUpdate=function(g){this.updater.enqueueForceUpdate(this,g,"forceUpdate")};function V(){}V.prototype=U.prototype;function N(g,R,F){this.props=g,this.context=R,this.refs=oe,this.updater=F||B}var I=N.prototype=new V;I.constructor=N,G(I,U.prototype),I.isPureReactComponent=!0;var ae=Array.isArray;function re(){}var L={H:null,A:null,T:null,S:null},Q=Object.prototype.hasOwnProperty;function ue(g,R,F){var H=F.ref;return{$$typeof:s,type:g,key:R,ref:H!==void 0?H:null,props:F}}function at(g,R){return ue(g.type,R,g.props)}function De(g){return typeof g=="object"&&g!==null&&g.$$typeof===s}function Ye(g){var R={"=":"=0",":":"=2"};return"$"+g.replace(/[=:]/g,function(F){return R[F]})}var Dt=/\/+/g;function Qe(g,R){return typeof g=="object"&&g!==null&&g.key!=null?Ye(""+g.key):R.toString(36)}function D(g){switch(g.status){case"fulfilled":return g.value;case"rejected":throw g.reason;default:switch(typeof g.status=="string"?g.then(re,re):(g.status="pending",g.then(function(R){g.status==="pending"&&(g.status="fulfilled",g.value=R)},function(R){g.status==="pending"&&(g.status="rejected",g.reason=R)})),g.status){case"fulfilled":return g.value;case"rejected":throw g.reason}}throw g}function O(g,R,F,H,ee){var ie=typeof g;(ie==="undefined"||ie==="boolean")&&(g=null);var ve=!1;if(g===null)ve=!0;else switch(ie){case"bigint":case"string":case"number":ve=!0;break;case"object":switch(g.$$typeof){case s:case c:ve=!0;break;case k:return ve=g._init,O(ve(g._payload),R,F,H,ee)}}if(ve)return ee=ee(g),ve=H===""?"."+Qe(g,0):H,ae(ee)?(F="",ve!=null&&(F=ve.replace(Dt,"$&/")+"/"),O(ee,R,F,"",function(Vt){return Vt})):ee!=null&&(De(ee)&&(ee=at(ee,F+(ee.key==null||g&&g.key===ee.key?"":(""+ee.key).replace(Dt,"$&/")+"/")+ve)),R.push(ee)),1;ve=0;var be=H===""?".":H+":";if(ae(g))for(var Re=0;Re<g.length;Re++)H=g[Re],ie=be+Qe(H,Re),ve+=O(H,R,F,ie,ee);else if(Re=X(g),typeof Re=="function")for(g=Re.call(g),Re=0;!(H=g.next()).done;)H=H.value,ie=be+Qe(H,Re++),ve+=O(H,R,F,ie,ee);else if(ie==="object"){if(typeof g.then=="function")return O(D(g),R,F,H,ee);throw R=String(g),Error("Objects are not valid as a React child (found: "+(R==="[object Object]"?"object with keys {"+Object.keys(g).join(", ")+"}":R)+"). If you meant to render a collection of children, use an array instead.")}return ve}function M(g,R,F){if(g==null)return g;var H=[],ee=0;return O(g,H,"","",function(ie){return R.call(F,ie,ee++)}),H}function ge(g){if(g._status===-1){var R=g._result;R=R(),R.then(function(F){(g._status===0||g._status===-1)&&(g._status=1,g._result=F)},function(F){(g._status===0||g._status===-1)&&(g._status=2,g._result=F)}),g._status===-1&&(g._status=0,g._result=R)}if(g._status===1)return g._result.default;throw g._result}var $=typeof reportError=="function"?reportError:function(g){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var R=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof g=="object"&&g!==null&&typeof g.message=="string"?String(g.message):String(g),error:g});if(!window.dispatchEvent(R))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",g);return}console.error(g)},ot={map:M,forEach:function(g,R,F){M(g,function(){R.apply(this,arguments)},F)},count:function(g){var R=0;return M(g,function(){R++}),R},toArray:function(g){return M(g,function(R){return R})||[]},only:function(g){if(!De(g))throw Error("React.Children.only expected to receive a single React element child.");return g}};i.Activity=S,i.Children=ot,i.Component=U,i.Fragment=u,i.Profiler=b,i.PureComponent=N,i.StrictMode=f,i.Suspense=x,i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=L,i.__COMPILER_RUNTIME={__proto__:null,c:function(g){return L.H.useMemoCache(g)}},i.cache=function(g){return function(){return g.apply(null,arguments)}},i.cacheSignal=function(){return null},i.cloneElement=function(g,R,F){if(g==null)throw Error("The argument must be a React element, but you passed "+g+".");var H=G({},g.props),ee=g.key;if(R!=null)for(ie in R.key!==void 0&&(ee=""+R.key),R)!Q.call(R,ie)||ie==="key"||ie==="__self"||ie==="__source"||ie==="ref"&&R.ref===void 0||(H[ie]=R[ie]);var ie=arguments.length-2;if(ie===1)H.children=F;else if(1<ie){for(var ve=Array(ie),be=0;be<ie;be++)ve[be]=arguments[be+2];H.children=ve}return ue(g.type,ee,H)},i.createContext=function(g){return g={$$typeof:w,_currentValue:g,_currentValue2:g,_threadCount:0,Provider:null,Consumer:null},g.Provider=g,g.Consumer={$$typeof:h,_context:g},g},i.createElement=function(g,R,F){var H,ee={},ie=null;if(R!=null)for(H in R.key!==void 0&&(ie=""+R.key),R)Q.call(R,H)&&H!=="key"&&H!=="__self"&&H!=="__source"&&(ee[H]=R[H]);var ve=arguments.length-2;if(ve===1)ee.children=F;else if(1<ve){for(var be=Array(ve),Re=0;Re<ve;Re++)be[Re]=arguments[Re+2];ee.children=be}if(g&&g.defaultProps)for(H in ve=g.defaultProps,ve)ee[H]===void 0&&(ee[H]=ve[H]);return ue(g,ie,ee)},i.createRef=function(){return{current:null}},i.forwardRef=function(g){return{$$typeof:C,render:g}},i.isValidElement=De,i.lazy=function(g){return{$$typeof:k,_payload:{_status:-1,_result:g},_init:ge}},i.memo=function(g,R){return{$$typeof:y,type:g,compare:R===void 0?null:R}},i.startTransition=function(g){var R=L.T,F={};L.T=F;try{var H=g(),ee=L.S;ee!==null&&ee(F,H),typeof H=="object"&&H!==null&&typeof H.then=="function"&&H.then(re,$)}catch(ie){$(ie)}finally{R!==null&&F.types!==null&&(R.types=F.types),L.T=R}},i.unstable_useCacheRefresh=function(){return L.H.useCacheRefresh()},i.use=function(g){return L.H.use(g)},i.useActionState=function(g,R,F){return L.H.useActionState(g,R,F)},i.useCallback=function(g,R){return L.H.useCallback(g,R)},i.useContext=function(g){return L.H.useContext(g)},i.useDebugValue=function(){},i.useDeferredValue=function(g,R){return L.H.useDeferredValue(g,R)},i.useEffect=function(g,R){return L.H.useEffect(g,R)},i.useEffectEvent=function(g){return L.H.useEffectEvent(g)},i.useId=function(){return L.H.useId()},i.useImperativeHandle=function(g,R,F){return L.H.useImperativeHandle(g,R,F)},i.useInsertionEffect=function(g,R){return L.H.useInsertionEffect(g,R)},i.useLayoutEffect=function(g,R){return L.H.useLayoutEffect(g,R)},i.useMemo=function(g,R){return L.H.useMemo(g,R)},i.useOptimistic=function(g,R){return L.H.useOptimistic(g,R)},i.useReducer=function(g,R,F){return L.H.useReducer(g,R,F)},i.useRef=function(g){return L.H.useRef(g)},i.useState=function(g){return L.H.useState(g)},i.useSyncExternalStore=function(g,R,F){return L.H.useSyncExternalStore(g,R,F)},i.useTransition=function(){return L.H.useTransition()},i.version="19.2.8"}),Et=Ht((i,s)=>{"use strict";s.exports=Nm()}),Tm=Ht(i=>{"use strict";var s=Et();function c(x){var y="https://react.dev/errors/"+x;if(1<arguments.length){y+="?args[]="+encodeURIComponent(arguments[1]);for(var k=2;k<arguments.length;k++)y+="&args[]="+encodeURIComponent(arguments[k])}return"Minified React error #"+x+"; visit "+y+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function u(){}var f={d:{f:u,r:function(){throw Error(c(522))},D:u,C:u,L:u,m:u,X:u,S:u,M:u},p:0,findDOMNode:null},b=Symbol.for("react.portal");function h(x,y,k){var S=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:b,key:S==null?null:""+S,children:x,containerInfo:y,implementation:k}}var w=s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function C(x,y){if(x==="font")return"";if(typeof y=="string")return y==="use-credentials"?y:""}i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=f,i.createPortal=function(x,y){var k=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!y||y.nodeType!==1&&y.nodeType!==9&&y.nodeType!==11)throw Error(c(299));return h(x,y,null,k)},i.flushSync=function(x){var y=w.T,k=f.p;try{if(w.T=null,f.p=2,x)return x()}finally{w.T=y,f.p=k,f.d.f()}},i.preconnect=function(x,y){typeof x=="string"&&(y?(y=y.crossOrigin,y=typeof y=="string"?y==="use-credentials"?y:"":void 0):y=null,f.d.C(x,y))},i.prefetchDNS=function(x){typeof x=="string"&&f.d.D(x)},i.preinit=function(x,y){if(typeof x=="string"&&y&&typeof y.as=="string"){var k=y.as,S=C(k,y.crossOrigin),q=typeof y.integrity=="string"?y.integrity:void 0,X=typeof y.fetchPriority=="string"?y.fetchPriority:void 0;k==="style"?f.d.S(x,typeof y.precedence=="string"?y.precedence:void 0,{crossOrigin:S,integrity:q,fetchPriority:X}):k==="script"&&f.d.X(x,{crossOrigin:S,integrity:q,fetchPriority:X,nonce:typeof y.nonce=="string"?y.nonce:void 0})}},i.preinitModule=function(x,y){if(typeof x=="string")if(typeof y=="object"&&y!==null){if(y.as==null||y.as==="script"){var k=C(y.as,y.crossOrigin);f.d.M(x,{crossOrigin:k,integrity:typeof y.integrity=="string"?y.integrity:void 0,nonce:typeof y.nonce=="string"?y.nonce:void 0})}}else y==null&&f.d.M(x)},i.preload=function(x,y){if(typeof x=="string"&&typeof y=="object"&&y!==null&&typeof y.as=="string"){var k=y.as,S=C(k,y.crossOrigin);f.d.L(x,k,{crossOrigin:S,integrity:typeof y.integrity=="string"?y.integrity:void 0,nonce:typeof y.nonce=="string"?y.nonce:void 0,type:typeof y.type=="string"?y.type:void 0,fetchPriority:typeof y.fetchPriority=="string"?y.fetchPriority:void 0,referrerPolicy:typeof y.referrerPolicy=="string"?y.referrerPolicy:void 0,imageSrcSet:typeof y.imageSrcSet=="string"?y.imageSrcSet:void 0,imageSizes:typeof y.imageSizes=="string"?y.imageSizes:void 0,media:typeof y.media=="string"?y.media:void 0})}},i.preloadModule=function(x,y){if(typeof x=="string")if(y){var k=C(y.as,y.crossOrigin);f.d.m(x,{as:typeof y.as=="string"&&y.as!=="script"?y.as:void 0,crossOrigin:k,integrity:typeof y.integrity=="string"?y.integrity:void 0})}else f.d.m(x)},i.requestFormReset=function(x){f.d.r(x)},i.unstable_batchedUpdates=function(x,y){return x(y)},i.useFormState=function(x,y,k){return w.H.useFormState(x,y,k)},i.useFormStatus=function(){return w.H.useHostTransitionStatus()},i.version="19.2.8"}),Pm=Ht((i,s)=>{"use strict";function c(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(c)}catch(u){console.error(u)}}c(),s.exports=Tm()}),jm=Ht(i=>{"use strict";var s=Em(),c=Et(),u=Pm();function f(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var r=2;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function b(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function h(e){var t=e,r=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,(t.flags&4098)!==0&&(r=t.return),e=t.return;while(e)}return t.tag===3?r:null}function w(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function C(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function x(e){if(h(e)!==e)throw Error(f(188))}function y(e){var t=e.alternate;if(!t){if(t=h(e),t===null)throw Error(f(188));return t!==e?null:e}for(var r=e,n=t;;){var a=r.return;if(a===null)break;var o=a.alternate;if(o===null){if(n=a.return,n!==null){r=n;continue}break}if(a.child===o.child){for(o=a.child;o;){if(o===r)return x(a),e;if(o===n)return x(a),t;o=o.sibling}throw Error(f(188))}if(r.return!==n.return)r=a,n=o;else{for(var l=!1,d=a.child;d;){if(d===r){l=!0,r=a,n=o;break}if(d===n){l=!0,n=a,r=o;break}d=d.sibling}if(!l){for(d=o.child;d;){if(d===r){l=!0,r=o,n=a;break}if(d===n){l=!0,n=o,r=a;break}d=d.sibling}if(!l)throw Error(f(189))}}if(r.alternate!==n)throw Error(f(190))}if(r.tag!==3)throw Error(f(188));return r.stateNode.current===r?e:t}function k(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=k(e),t!==null)return t;e=e.sibling}return null}var S=Object.assign,q=Symbol.for("react.element"),X=Symbol.for("react.transitional.element"),B=Symbol.for("react.portal"),G=Symbol.for("react.fragment"),oe=Symbol.for("react.strict_mode"),U=Symbol.for("react.profiler"),V=Symbol.for("react.consumer"),N=Symbol.for("react.context"),I=Symbol.for("react.forward_ref"),ae=Symbol.for("react.suspense"),re=Symbol.for("react.suspense_list"),L=Symbol.for("react.memo"),Q=Symbol.for("react.lazy"),ue=Symbol.for("react.activity"),at=Symbol.for("react.memo_cache_sentinel"),De=Symbol.iterator;function Ye(e){return e===null||typeof e!="object"?null:(e=De&&e[De]||e["@@iterator"],typeof e=="function"?e:null)}var Dt=Symbol.for("react.client.reference");function Qe(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Dt?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case G:return"Fragment";case U:return"Profiler";case oe:return"StrictMode";case ae:return"Suspense";case re:return"SuspenseList";case ue:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case B:return"Portal";case N:return e.displayName||"Context";case V:return(e._context.displayName||"Context")+".Consumer";case I:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case L:return t=e.displayName||null,t!==null?t:Qe(e.type)||"Memo";case Q:t=e._payload,e=e._init;try{return Qe(e(t))}catch{}}return null}var D=Array.isArray,O=c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,M=u.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ge={pending:!1,data:null,method:null,action:null},$=[],ot=-1;function g(e){return{current:e}}function R(e){0>ot||(e.current=$[ot],$[ot]=null,ot--)}function F(e,t){ot++,$[ot]=e.current,e.current=t}var H=g(null),ee=g(null),ie=g(null),ve=g(null);function be(e,t){switch(F(ie,t),F(ee,e),F(H,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Hp(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Hp(t),e=qp(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}R(H),F(H,e)}function Re(){R(H),R(ee),R(ie)}function Vt(e){e.memoizedState!==null&&F(ve,e);var t=H.current,r=qp(t,e.type);t!==r&&(F(ee,e),F(H,r))}function er(e){ee.current===e&&(R(H),R(ee)),ve.current===e&&(R(ve),ro._currentValue=ge)}var Gr,Jr;function Zr(e){if(Gr===void 0)try{throw Error()}catch(r){var t=r.stack.trim().match(/\n( *(at )?)/);Gr=t&&t[1]||"",Jr=-1<r.stack.indexOf(`
    at`)?" (<anonymous>)":-1<r.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Gr+e+Jr}var Gi=!1;function Ji(e,t){if(!e||Gi)return"";Gi=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var n={DetermineComponentFrameRoot:function(){try{if(t){var A=function(){throw Error()};if(Object.defineProperty(A.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(A,[])}catch(T){var E=T}Reflect.construct(e,[],A)}else{try{A.call()}catch(T){E=T}e.call(A.prototype)}}else{try{throw Error()}catch(T){E=T}(A=e())&&typeof A.catch=="function"&&A.catch(function(){})}}catch(T){if(T&&E&&typeof T.stack=="string")return[T.stack,E.stack]}return[null,null]}};n.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(n.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(n.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var o=n.DetermineComponentFrameRoot(),l=o[0],d=o[1];if(l&&d){var p=l.split(`
`),_=d.split(`
`);for(a=n=0;n<p.length&&!p[n].includes("DetermineComponentFrameRoot");)n++;for(;a<_.length&&!_[a].includes("DetermineComponentFrameRoot");)a++;if(n===p.length||a===_.length)for(n=p.length-1,a=_.length-1;1<=n&&0<=a&&p[n]!==_[a];)a--;for(;1<=n&&0<=a;n--,a--)if(p[n]!==_[a]){if(n!==1||a!==1)do if(n--,a--,0>a||p[n]!==_[a]){var P=`
`+p[n].replace(" at new "," at ");return e.displayName&&P.includes("<anonymous>")&&(P=P.replace("<anonymous>",e.displayName)),P}while(1<=n&&0<=a);break}}}finally{Gi=!1,Error.prepareStackTrace=r}return(r=e?e.displayName||e.name:"")?Zr(r):""}function rb(e,t){switch(e.tag){case 26:case 27:case 5:return Zr(e.type);case 16:return Zr("Lazy");case 13:return e.child!==t&&t!==null?Zr("Suspense Fallback"):Zr("Suspense");case 19:return Zr("SuspenseList");case 0:case 15:return Ji(e.type,!1);case 11:return Ji(e.type.render,!1);case 1:return Ji(e.type,!0);case 31:return Zr("Activity");default:return""}}function bu(e){try{var t="",r=null;do t+=rb(e,r),r=e,e=e.return;while(e);return t}catch(n){return`
Error generating stack: `+n.message+`
`+n.stack}}var Zi=Object.prototype.hasOwnProperty,el=s.unstable_scheduleCallback,tl=s.unstable_cancelCallback,nb=s.unstable_shouldYield,ab=s.unstable_requestPaint,bt=s.unstable_now,ob=s.unstable_getCurrentPriorityLevel,vu=s.unstable_ImmediatePriority,yu=s.unstable_UserBlockingPriority,ho=s.unstable_NormalPriority,ib=s.unstable_LowPriority,wu=s.unstable_IdlePriority,lb=s.log,sb=s.unstable_setDisableYieldValue,ga=null,vt=null;function Sr(e){if(typeof lb=="function"&&sb(e),vt&&typeof vt.setStrictMode=="function")try{vt.setStrictMode(ga,e)}catch{}}var yt=Math.clz32?Math.clz32:db,cb=Math.log,ub=Math.LN2;function db(e){return e>>>=0,e===0?32:31-(cb(e)/ub|0)|0}var bo=256,vo=262144,yo=4194304;function en(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function wo(e,t,r){var n=e.pendingLanes;if(n===0)return 0;var a=0,o=e.suspendedLanes,l=e.pingedLanes;e=e.warmLanes;var d=n&134217727;return d!==0?(n=d&~o,n!==0?a=en(n):(l&=d,l!==0?a=en(l):r||(r=d&~e,r!==0&&(a=en(r))))):(d=n&~o,d!==0?a=en(d):l!==0?a=en(l):r||(r=n&~e,r!==0&&(a=en(r)))),a===0?0:t!==0&&t!==a&&(t&o)===0&&(o=a&-a,r=t&-t,o>=r||o===32&&(r&4194048)!==0)?t:a}function ha(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function fb(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function xu(){var e=yo;return yo<<=1,(yo&62914560)===0&&(yo=4194304),e}function rl(e){for(var t=[],r=0;31>r;r++)t.push(e);return t}function ba(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function pb(e,t,r,n,a,o){var l=e.pendingLanes;e.pendingLanes=r,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=r,e.entangledLanes&=r,e.errorRecoveryDisabledLanes&=r,e.shellSuspendCounter=0;var d=e.entanglements,p=e.expirationTimes,_=e.hiddenUpdates;for(r=l&~r;0<r;){var P=31-yt(r),A=1<<P;d[P]=0,p[P]=-1;var E=_[P];if(E!==null)for(_[P]=null,P=0;P<E.length;P++){var T=E[P];T!==null&&(T.lane&=-536870913)}r&=~A}n!==0&&ku(e,n,0),o!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=o&~(l&~t))}function ku(e,t,r){e.pendingLanes|=t,e.suspendedLanes&=~t;var n=31-yt(t);e.entangledLanes|=t,e.entanglements[n]=e.entanglements[n]|1073741824|r&261930}function Su(e,t){var r=e.entangledLanes|=t;for(e=e.entanglements;r;){var n=31-yt(r),a=1<<n;a&t|e[n]&t&&(e[n]|=t),r&=~a}}function Cu(e,t){var r=t&-t;return r=(r&42)!==0?1:nl(r),(r&(e.suspendedLanes|t))!==0?0:r}function nl(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function al(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function zu(){var e=M.p;return e!==0?e:(e=window.event,e===void 0?32:fm(e.type))}function _u(e,t){var r=M.p;try{return M.p=e,t()}finally{M.p=r}}var Cr=Math.random().toString(36).slice(2),Ge="__reactFiber$"+Cr,ut="__reactProps$"+Cr,En="__reactContainer$"+Cr,ol="__reactEvents$"+Cr,mb="__reactListeners$"+Cr,gb="__reactHandles$"+Cr,Eu="__reactResources$"+Cr,va="__reactMarker$"+Cr;function il(e){delete e[Ge],delete e[ut],delete e[ol],delete e[mb],delete e[gb]}function Nn(e){var t=e[Ge];if(t)return t;for(var r=e.parentNode;r;){if(t=r[En]||r[Ge]){if(r=t.alternate,t.child!==null||r!==null&&r.child!==null)for(e=Xp(e);e!==null;){if(r=e[Ge])return r;e=Xp(e)}return t}e=r,r=e.parentNode}return null}function Tn(e){if(e=e[Ge]||e[En]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function ya(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(f(33))}function Pn(e){var t=e[Eu];return t||(t=e[Eu]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Ke(e){e[va]=!0}var Nu=new Set,Tu={};function tn(e,t){jn(e,t),jn(e+"Capture",t)}function jn(e,t){for(Tu[e]=t,e=0;e<t.length;e++)Nu.add(t[e])}var hb=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Pu={},ju={};function bb(e){return Zi.call(ju,e)?!0:Zi.call(Pu,e)?!1:hb.test(e)?ju[e]=!0:(Pu[e]=!0,!1)}function xo(e,t,r){if(bb(t))if(r===null)e.removeAttribute(t);else{switch(typeof r){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var n=t.toLowerCase().slice(0,5);if(n!=="data-"&&n!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,""+r)}}function ko(e,t,r){if(r===null)e.removeAttribute(t);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+r)}}function tr(e,t,r,n){if(n===null)e.removeAttribute(r);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(r);return}e.setAttributeNS(t,r,""+n)}}function Nt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Au(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function vb(e,t,r){var n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var a=n.get,o=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(l){r=""+l,o.call(this,l)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(l){r=""+l},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ll(e){if(!e._valueTracker){var t=Au(e)?"checked":"value";e._valueTracker=vb(e,t,""+e[t])}}function Lu(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var r=t.getValue(),n="";return e&&(n=Au(e)?e.checked?"true":"false":e.value),e=n,e!==r?(t.setValue(e),!0):!1}function So(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var yb=/[\n"\\]/g;function It(e){return e.replace(yb,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function sl(e,t,r,n,a,o,l,d){e.name="",l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"?e.type=l:e.removeAttribute("type"),t!=null?l==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Nt(t)):e.value!==""+Nt(t)&&(e.value=""+Nt(t)):l!=="submit"&&l!=="reset"||e.removeAttribute("value"),t!=null?cl(e,l,Nt(t)):r!=null?cl(e,l,Nt(r)):n!=null&&e.removeAttribute("value"),a==null&&o!=null&&(e.defaultChecked=!!o),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"?e.name=""+Nt(d):e.removeAttribute("name")}function Ru(e,t,r,n,a,o,l,d){if(o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"&&(e.type=o),t!=null||r!=null){if(!(o!=="submit"&&o!=="reset"||t!=null)){ll(e);return}r=r!=null?""+Nt(r):"",t=t!=null?""+Nt(t):r,d||t===e.value||(e.value=t),e.defaultValue=t}n=n??a,n=typeof n!="function"&&typeof n!="symbol"&&!!n,e.checked=d?e.checked:!!n,e.defaultChecked=!!n,l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"&&(e.name=l),ll(e)}function cl(e,t,r){t==="number"&&So(e.ownerDocument)===e||e.defaultValue===""+r||(e.defaultValue=""+r)}function An(e,t,r,n){if(e=e.options,t){t={};for(var a=0;a<r.length;a++)t["$"+r[a]]=!0;for(r=0;r<e.length;r++)a=t.hasOwnProperty("$"+e[r].value),e[r].selected!==a&&(e[r].selected=a),a&&n&&(e[r].defaultSelected=!0)}else{for(r=""+Nt(r),t=null,a=0;a<e.length;a++){if(e[a].value===r){e[a].selected=!0,n&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function Ou(e,t,r){if(t!=null&&(t=""+Nt(t),t!==e.value&&(e.value=t),r==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=r!=null?""+Nt(r):""}function Du(e,t,r,n){if(t==null){if(n!=null){if(r!=null)throw Error(f(92));if(D(n)){if(1<n.length)throw Error(f(93));n=n[0]}r=n}r==null&&(r=""),t=r}r=Nt(t),e.defaultValue=r,n=e.textContent,n===r&&n!==""&&n!==null&&(e.value=n),ll(e)}function Ln(e,t){if(t){var r=e.firstChild;if(r&&r===e.lastChild&&r.nodeType===3){r.nodeValue=t;return}}e.textContent=t}var wb=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Iu(e,t,r){var n=t.indexOf("--")===0;r==null||typeof r=="boolean"||r===""?n?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":n?e.setProperty(t,r):typeof r!="number"||r===0||wb.has(t)?t==="float"?e.cssFloat=r:e[t]=(""+r).trim():e[t]=r+"px"}function Fu(e,t,r){if(t!=null&&typeof t!="object")throw Error(f(62));if(e=e.style,r!=null){for(var n in r)!r.hasOwnProperty(n)||t!=null&&t.hasOwnProperty(n)||(n.indexOf("--")===0?e.setProperty(n,""):n==="float"?e.cssFloat="":e[n]="");for(var a in t)n=t[a],t.hasOwnProperty(a)&&r[a]!==n&&Iu(e,a,n)}else for(var o in t)t.hasOwnProperty(o)&&Iu(e,o,t[o])}function ul(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var xb=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),kb=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Co(e){return kb.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function rr(){}var dl=null;function fl(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Rn=null,On=null;function Mu(e){var t=Tn(e);if(t&&(e=t.stateNode)){var r=e[ut]||null;e:switch(e=t.stateNode,t.type){case"input":if(sl(e,r.value,r.defaultValue,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name),t=r.name,r.type==="radio"&&t!=null){for(r=e;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll('input[name="'+It(""+t)+'"][type="radio"]'),t=0;t<r.length;t++){var n=r[t];if(n!==e&&n.form===e.form){var a=n[ut]||null;if(!a)throw Error(f(90));sl(n,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<r.length;t++)n=r[t],n.form===e.form&&Lu(n)}break e;case"textarea":Ou(e,r.value,r.defaultValue);break e;case"select":t=r.value,t!=null&&An(e,!!r.multiple,t,!1)}}}var pl=!1;function $u(e,t,r){if(pl)return e(t,r);pl=!0;try{var n=e(t);return n}finally{if(pl=!1,(Rn!==null||On!==null)&&(fi(),Rn&&(t=Rn,e=On,On=Rn=null,Mu(t),e)))for(t=0;t<e.length;t++)Mu(e[t])}}function wa(e,t){var r=e.stateNode;if(r===null)return null;var n=r[ut]||null;if(n===null)return null;r=n[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(n=!n.disabled)||(e=e.type,n=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!n;break e;default:e=!1}if(e)return null;if(r&&typeof r!="function")throw Error(f(231,t,typeof r));return r}var nr=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),ml=!1;if(nr)try{Dn={},Object.defineProperty(Dn,"passive",{get:function(){ml=!0}}),window.addEventListener("test",Dn,Dn),window.removeEventListener("test",Dn,Dn)}catch{ml=!1}var Dn,zr=null,gl=null,zo=null;function Uu(){if(zo)return zo;var e,t=gl,r=t.length,n,a="value"in zr?zr.value:zr.textContent,o=a.length;for(e=0;e<r&&t[e]===a[e];e++);var l=r-e;for(n=1;n<=l&&t[r-n]===a[o-n];n++);return zo=a.slice(e,1<n?1-n:void 0)}function _o(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Eo(){return!0}function Hu(){return!1}function dt(e){function t(r,n,a,o,l){this._reactName=r,this._targetInst=a,this.type=n,this.nativeEvent=o,this.target=l,this.currentTarget=null;for(var d in e)e.hasOwnProperty(d)&&(r=e[d],this[d]=r?r(o):o[d]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?Eo:Hu,this.isPropagationStopped=Hu,this}return S(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var r=this.nativeEvent;r&&(r.preventDefault?r.preventDefault():typeof r.returnValue!="unknown"&&(r.returnValue=!1),this.isDefaultPrevented=Eo)},stopPropagation:function(){var r=this.nativeEvent;r&&(r.stopPropagation?r.stopPropagation():typeof r.cancelBubble!="unknown"&&(r.cancelBubble=!0),this.isPropagationStopped=Eo)},persist:function(){},isPersistent:Eo}),t}var rn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},No=dt(rn),xa=S({},rn,{view:0,detail:0}),Sb=dt(xa),hl,bl,ka,To=S({},xa,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:yl,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==ka&&(ka&&e.type==="mousemove"?(hl=e.screenX-ka.screenX,bl=e.screenY-ka.screenY):bl=hl=0,ka=e),hl)},movementY:function(e){return"movementY"in e?e.movementY:bl}}),qu=dt(To),Cb=S({},To,{dataTransfer:0}),zb=dt(Cb),_b=S({},xa,{relatedTarget:0}),vl=dt(_b),Eb=S({},rn,{animationName:0,elapsedTime:0,pseudoElement:0}),Nb=dt(Eb),Tb=S({},rn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Pb=dt(Tb),jb=S({},rn,{data:0}),Bu=dt(jb),Ab={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Lb={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Rb={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Ob(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Rb[e])?!!t[e]:!1}function yl(){return Ob}var Db=S({},xa,{key:function(e){if(e.key){var t=Ab[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=_o(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Lb[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:yl,charCode:function(e){return e.type==="keypress"?_o(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?_o(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Ib=dt(Db),Fb=S({},To,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Vu=dt(Fb),Mb=S({},xa,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:yl}),$b=dt(Mb),Ub=S({},rn,{propertyName:0,elapsedTime:0,pseudoElement:0}),Hb=dt(Ub),qb=S({},To,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Bb=dt(qb),Vb=S({},rn,{newState:0,oldState:0}),Wb=dt(Vb),Yb=[9,13,27,32],wl=nr&&"CompositionEvent"in window,Sa=null;nr&&"documentMode"in document&&(Sa=document.documentMode);var Qb=nr&&"TextEvent"in window&&!Sa,Wu=nr&&(!wl||Sa&&8<Sa&&11>=Sa),Yu=" ",Qu=!1;function Ku(e,t){switch(e){case"keyup":return Yb.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Xu(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var In=!1;function Kb(e,t){switch(e){case"compositionend":return Xu(t);case"keypress":return t.which!==32?null:(Qu=!0,Yu);case"textInput":return e=t.data,e===Yu&&Qu?null:e;default:return null}}function Xb(e,t){if(In)return e==="compositionend"||!wl&&Ku(e,t)?(e=Uu(),zo=gl=zr=null,In=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Wu&&t.locale!=="ko"?null:t.data;default:return null}}var Gb={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Gu(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Gb[e.type]:t==="textarea"}function Ju(e,t,r,n){Rn?On?On.push(n):On=[n]:Rn=n,t=xi(t,"onChange"),0<t.length&&(r=new No("onChange","change",null,r,n),e.push({event:r,listeners:t}))}var Ca=null,za=null;function Jb(e){Dp(e,0)}function Po(e){var t=ya(e);if(Lu(t))return e}function Zu(e,t){if(e==="change")return t}var ed=!1;nr&&(nr?(jo="oninput"in document,jo||(kl=document.createElement("div"),kl.setAttribute("oninput","return;"),jo=typeof kl.oninput=="function"),xl=jo):xl=!1,ed=xl&&(!document.documentMode||9<document.documentMode));var xl,jo,kl;function td(){Ca&&(Ca.detachEvent("onpropertychange",rd),za=Ca=null)}function rd(e){if(e.propertyName==="value"&&Po(za)){var t=[];Ju(t,za,e,fl(e)),$u(Jb,t)}}function Zb(e,t,r){e==="focusin"?(td(),Ca=t,za=r,Ca.attachEvent("onpropertychange",rd)):e==="focusout"&&td()}function e0(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Po(za)}function t0(e,t){if(e==="click")return Po(t)}function r0(e,t){if(e==="input"||e==="change")return Po(t)}function n0(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var wt=typeof Object.is=="function"?Object.is:n0;function _a(e,t){if(wt(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var r=Object.keys(e),n=Object.keys(t);if(r.length!==n.length)return!1;for(n=0;n<r.length;n++){var a=r[n];if(!Zi.call(t,a)||!wt(e[a],t[a]))return!1}return!0}function nd(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function ad(e,t){var r=nd(e);e=0;for(var n;r;){if(r.nodeType===3){if(n=e+r.textContent.length,e<=t&&n>=t)return{node:r,offset:t-e};e=n}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=nd(r)}}function od(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?od(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function id(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=So(e.document);t instanceof e.HTMLIFrameElement;){try{var r=typeof t.contentWindow.location.href=="string"}catch{r=!1}if(r)e=t.contentWindow;else break;t=So(e.document)}return t}function Sl(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var a0=nr&&"documentMode"in document&&11>=document.documentMode,Fn=null,Cl=null,Ea=null,zl=!1;function ld(e,t,r){var n=r.window===r?r.document:r.nodeType===9?r:r.ownerDocument;zl||Fn==null||Fn!==So(n)||(n=Fn,"selectionStart"in n&&Sl(n)?n={start:n.selectionStart,end:n.selectionEnd}:(n=(n.ownerDocument&&n.ownerDocument.defaultView||window).getSelection(),n={anchorNode:n.anchorNode,anchorOffset:n.anchorOffset,focusNode:n.focusNode,focusOffset:n.focusOffset}),Ea&&_a(Ea,n)||(Ea=n,n=xi(Cl,"onSelect"),0<n.length&&(t=new No("onSelect","select",null,t,r),e.push({event:t,listeners:n}),t.target=Fn)))}function nn(e,t){var r={};return r[e.toLowerCase()]=t.toLowerCase(),r["Webkit"+e]="webkit"+t,r["Moz"+e]="moz"+t,r}var Mn={animationend:nn("Animation","AnimationEnd"),animationiteration:nn("Animation","AnimationIteration"),animationstart:nn("Animation","AnimationStart"),transitionrun:nn("Transition","TransitionRun"),transitionstart:nn("Transition","TransitionStart"),transitioncancel:nn("Transition","TransitionCancel"),transitionend:nn("Transition","TransitionEnd")},_l={},sd={};nr&&(sd=document.createElement("div").style,"AnimationEvent"in window||(delete Mn.animationend.animation,delete Mn.animationiteration.animation,delete Mn.animationstart.animation),"TransitionEvent"in window||delete Mn.transitionend.transition);function an(e){if(_l[e])return _l[e];if(!Mn[e])return e;var t=Mn[e],r;for(r in t)if(t.hasOwnProperty(r)&&r in sd)return _l[e]=t[r];return e}var cd=an("animationend"),ud=an("animationiteration"),dd=an("animationstart"),o0=an("transitionrun"),i0=an("transitionstart"),l0=an("transitioncancel"),fd=an("transitionend"),pd=new Map,El="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");El.push("scrollEnd");function Ft(e,t){pd.set(e,t),tn(t,[e])}var Ao=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Tt=[],$n=0,Nl=0;function Lo(){for(var e=$n,t=Nl=$n=0;t<e;){var r=Tt[t];Tt[t++]=null;var n=Tt[t];Tt[t++]=null;var a=Tt[t];Tt[t++]=null;var o=Tt[t];if(Tt[t++]=null,n!==null&&a!==null){var l=n.pending;l===null?a.next=a:(a.next=l.next,l.next=a),n.pending=a}o!==0&&md(r,a,o)}}function Ro(e,t,r,n){Tt[$n++]=e,Tt[$n++]=t,Tt[$n++]=r,Tt[$n++]=n,Nl|=n,e.lanes|=n,e=e.alternate,e!==null&&(e.lanes|=n)}function Tl(e,t,r,n){return Ro(e,t,r,n),Oo(e)}function on(e,t){return Ro(e,null,null,t),Oo(e)}function md(e,t,r){e.lanes|=r;var n=e.alternate;n!==null&&(n.lanes|=r);for(var a=!1,o=e.return;o!==null;)o.childLanes|=r,n=o.alternate,n!==null&&(n.childLanes|=r),o.tag===22&&(e=o.stateNode,e===null||e._visibility&1||(a=!0)),e=o,o=o.return;return e.tag===3?(o=e.stateNode,a&&t!==null&&(a=31-yt(r),e=o.hiddenUpdates,n=e[a],n===null?e[a]=[t]:n.push(t),t.lane=r|536870912),o):null}function Oo(e){if(50<Ka)throw Ka=0,Fs=null,Error(f(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Un={};function s0(e,t,r,n){this.tag=e,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=n,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function xt(e,t,r,n){return new s0(e,t,r,n)}function Pl(e){return e=e.prototype,!(!e||!e.isReactComponent)}function ar(e,t){var r=e.alternate;return r===null?(r=xt(e.tag,t,e.key,e.mode),r.elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=t,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=e.flags&65011712,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,t=e.dependencies,r.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r.refCleanup=e.refCleanup,r}function gd(e,t){e.flags&=65011714;var r=e.alternate;return r===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=r.childLanes,e.lanes=r.lanes,e.child=r.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=r.memoizedProps,e.memoizedState=r.memoizedState,e.updateQueue=r.updateQueue,e.type=r.type,t=r.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Do(e,t,r,n,a,o){var l=0;if(n=e,typeof e=="function")Pl(e)&&(l=1);else if(typeof e=="string")l=dv(e,r,H.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case ue:return e=xt(31,r,t,a),e.elementType=ue,e.lanes=o,e;case G:return ln(r.children,a,o,t);case oe:l=8,a|=24;break;case U:return e=xt(12,r,t,a|2),e.elementType=U,e.lanes=o,e;case ae:return e=xt(13,r,t,a),e.elementType=ae,e.lanes=o,e;case re:return e=xt(19,r,t,a),e.elementType=re,e.lanes=o,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case N:l=10;break e;case V:l=9;break e;case I:l=11;break e;case L:l=14;break e;case Q:l=16,n=null;break e}l=29,r=Error(f(130,e===null?"null":typeof e,"")),n=null}return t=xt(l,r,t,a),t.elementType=e,t.type=n,t.lanes=o,t}function ln(e,t,r,n){return e=xt(7,e,n,t),e.lanes=r,e}function jl(e,t,r){return e=xt(6,e,null,t),e.lanes=r,e}function hd(e){var t=xt(18,null,null,0);return t.stateNode=e,t}function Al(e,t,r){return t=xt(4,e.children!==null?e.children:[],e.key,t),t.lanes=r,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var bd=new WeakMap;function Pt(e,t){if(typeof e=="object"&&e!==null){var r=bd.get(e);return r!==void 0?r:(t={value:e,source:t,stack:bu(t)},bd.set(e,t),t)}return{value:e,source:t,stack:bu(t)}}var Hn=[],qn=0,Io=null,Na=0,jt=[],At=0,_r=null,Wt=1,Yt="";function or(e,t){Hn[qn++]=Na,Hn[qn++]=Io,Io=e,Na=t}function vd(e,t,r){jt[At++]=Wt,jt[At++]=Yt,jt[At++]=_r,_r=e;var n=Wt;e=Yt;var a=32-yt(n)-1;n&=~(1<<a),r+=1;var o=32-yt(t)+a;if(30<o){var l=a-a%5;o=(n&(1<<l)-1).toString(32),n>>=l,a-=l,Wt=1<<32-yt(t)+a|r<<a|n,Yt=o+e}else Wt=1<<o|r<<a|n,Yt=e}function Ll(e){e.return!==null&&(or(e,1),vd(e,1,0))}function Rl(e){for(;e===Io;)Io=Hn[--qn],Hn[qn]=null,Na=Hn[--qn],Hn[qn]=null;for(;e===_r;)_r=jt[--At],jt[At]=null,Yt=jt[--At],jt[At]=null,Wt=jt[--At],jt[At]=null}function yd(e,t){jt[At++]=Wt,jt[At++]=Yt,jt[At++]=_r,Wt=t.id,Yt=t.overflow,_r=e}var Je=null,Te=null,he=!1,Er=null,Lt=!1,Ol=Error(f(519));function Nr(e){var t=Error(f(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Ta(Pt(t,e)),Ol}function wd(e){var t=e.stateNode,r=e.type,n=e.memoizedProps;switch(t[Ge]=e,t[ut]=n,r){case"dialog":fe("cancel",t),fe("close",t);break;case"iframe":case"object":case"embed":fe("load",t);break;case"video":case"audio":for(r=0;r<Ga.length;r++)fe(Ga[r],t);break;case"source":fe("error",t);break;case"img":case"image":case"link":fe("error",t),fe("load",t);break;case"details":fe("toggle",t);break;case"input":fe("invalid",t),Ru(t,n.value,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name,!0);break;case"select":fe("invalid",t);break;case"textarea":fe("invalid",t),Du(t,n.value,n.defaultValue,n.children)}r=n.children,typeof r!="string"&&typeof r!="number"&&typeof r!="bigint"||t.textContent===""+r||n.suppressHydrationWarning===!0||$p(t.textContent,r)?(n.popover!=null&&(fe("beforetoggle",t),fe("toggle",t)),n.onScroll!=null&&fe("scroll",t),n.onScrollEnd!=null&&fe("scrollend",t),n.onClick!=null&&(t.onclick=rr),t=!0):t=!1,t||Nr(e,!0)}function xd(e){for(Je=e.return;Je;)switch(Je.tag){case 5:case 31:case 13:Lt=!1;return;case 27:case 3:Lt=!0;return;default:Je=Je.return}}function Bn(e){if(e!==Je)return!1;if(!he)return xd(e),he=!0,!1;var t=e.tag,r;if((r=t!==3&&t!==27)&&((r=t===5)&&(r=e.type,r=!(r!=="form"&&r!=="button")||Gs(e.type,e.memoizedProps)),r=!r),r&&Te&&Nr(e),xd(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(f(317));Te=Kp(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(f(317));Te=Kp(e)}else t===27?(t=Te,Hr(e.type)?(e=rc,rc=null,Te=e):Te=t):Te=Je?Rt(e.stateNode.nextSibling):null;return!0}function sn(){Te=Je=null,he=!1}function Dl(){var e=Er;return e!==null&&(gt===null?gt=e:gt.push.apply(gt,e),Er=null),e}function Ta(e){Er===null?Er=[e]:Er.push(e)}var Il=g(null),cn=null,ir=null;function Tr(e,t,r){F(Il,t._currentValue),t._currentValue=r}function lr(e){e._currentValue=Il.current,R(Il)}function Fl(e,t,r){for(;e!==null;){var n=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,n!==null&&(n.childLanes|=t)):n!==null&&(n.childLanes&t)!==t&&(n.childLanes|=t),e===r)break;e=e.return}}function Ml(e,t,r,n){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){var l=a.child;o=o.firstContext;e:for(;o!==null;){var d=o;o=a;for(var p=0;p<t.length;p++)if(d.context===t[p]){o.lanes|=r,d=o.alternate,d!==null&&(d.lanes|=r),Fl(o.return,r,e),n||(l=null);break e}o=d.next}}else if(a.tag===18){if(l=a.return,l===null)throw Error(f(341));l.lanes|=r,o=l.alternate,o!==null&&(o.lanes|=r),Fl(l,r,e),l=null}else l=a.child;if(l!==null)l.return=a;else for(l=a;l!==null;){if(l===e){l=null;break}if(a=l.sibling,a!==null){a.return=l.return,l=a;break}l=l.return}a=l}}function Vn(e,t,r,n){e=null;for(var a=t,o=!1;a!==null;){if(!o){if((a.flags&524288)!==0)o=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var l=a.alternate;if(l===null)throw Error(f(387));if(l=l.memoizedProps,l!==null){var d=a.type;wt(a.pendingProps.value,l.value)||(e!==null?e.push(d):e=[d])}}else if(a===ve.current){if(l=a.alternate,l===null)throw Error(f(387));l.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(ro):e=[ro])}a=a.return}e!==null&&Ml(t,e,r,n),t.flags|=262144}function Fo(e){for(e=e.firstContext;e!==null;){if(!wt(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function un(e){cn=e,ir=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function Ze(e){return kd(cn,e)}function Mo(e,t){return cn===null&&un(e),kd(e,t)}function kd(e,t){var r=t._currentValue;if(t={context:t,memoizedValue:r,next:null},ir===null){if(e===null)throw Error(f(308));ir=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else ir=ir.next=t;return r}var c0=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(r,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(r){return r()})}},u0=s.unstable_scheduleCallback,d0=s.unstable_NormalPriority,Ue={$$typeof:N,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function $l(){return{controller:new c0,data:new Map,refCount:0}}function Pa(e){e.refCount--,e.refCount===0&&u0(d0,function(){e.controller.abort()})}var ja=null,Ul=0,Wn=0,Yn=null;function f0(e,t){if(ja===null){var r=ja=[];Ul=0,Wn=Bs(),Yn={status:"pending",value:void 0,then:function(n){r.push(n)}}}return Ul++,t.then(Sd,Sd),t}function Sd(){if(--Ul===0&&ja!==null){Yn!==null&&(Yn.status="fulfilled");var e=ja;ja=null,Wn=0,Yn=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function p0(e,t){var r=[],n={status:"pending",value:null,reason:null,then:function(a){r.push(a)}};return e.then(function(){n.status="fulfilled",n.value=t;for(var a=0;a<r.length;a++)(0,r[a])(t)},function(a){for(n.status="rejected",n.reason=a,a=0;a<r.length;a++)(0,r[a])(void 0)}),n}var Cd=O.S;O.S=function(e,t){sp=bt(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&f0(e,t),Cd!==null&&Cd(e,t)};var dn=g(null);function Hl(){var e=dn.current;return e!==null?e:Ee.pooledCache}function $o(e,t){t===null?F(dn,dn.current):F(dn,t.pool)}function zd(){var e=Hl();return e===null?null:{parent:Ue._currentValue,pool:e}}var Qn=Error(f(460)),ql=Error(f(474)),Uo=Error(f(542)),Ho={then:function(){}};function _d(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Ed(e,t,r){switch(r=e[r],r===void 0?e.push(t):r!==t&&(t.then(rr,rr),t=r),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Td(e),e;default:if(typeof t.status=="string")t.then(rr,rr);else{if(e=Ee,e!==null&&100<e.shellSuspendCounter)throw Error(f(482));e=t,e.status="pending",e.then(function(n){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=n}},function(n){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=n}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Td(e),e}throw pn=t,Qn}}function fn(e){try{var t=e._init;return t(e._payload)}catch(r){throw r!==null&&typeof r=="object"&&typeof r.then=="function"?(pn=r,Qn):r}}var pn=null;function Nd(){if(pn===null)throw Error(f(459));var e=pn;return pn=null,e}function Td(e){if(e===Qn||e===Uo)throw Error(f(483))}var Kn=null,Aa=0;function qo(e){var t=Aa;return Aa+=1,Kn===null&&(Kn=[]),Ed(Kn,e,t)}function La(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Bo(e,t){throw t.$$typeof===q?Error(f(525)):(e=Object.prototype.toString.call(t),Error(f(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function Pd(e){function t(v,m){if(e){var z=v.deletions;z===null?(v.deletions=[m],v.flags|=16):z.push(m)}}function r(v,m){if(!e)return null;for(;m!==null;)t(v,m),m=m.sibling;return null}function n(v){for(var m=new Map;v!==null;)v.key!==null?m.set(v.key,v):m.set(v.index,v),v=v.sibling;return m}function a(v,m){return v=ar(v,m),v.index=0,v.sibling=null,v}function o(v,m,z){return v.index=z,e?(z=v.alternate,z!==null?(z=z.index,z<m?(v.flags|=67108866,m):z):(v.flags|=67108866,m)):(v.flags|=1048576,m)}function l(v){return e&&v.alternate===null&&(v.flags|=67108866),v}function d(v,m,z,j){return m===null||m.tag!==6?(m=jl(z,v.mode,j),m.return=v,m):(m=a(m,z),m.return=v,m)}function p(v,m,z,j){var Z=z.type;return Z===G?P(v,m,z.props.children,j,z.key):m!==null&&(m.elementType===Z||typeof Z=="object"&&Z!==null&&Z.$$typeof===Q&&fn(Z)===m.type)?(m=a(m,z.props),La(m,z),m.return=v,m):(m=Do(z.type,z.key,z.props,null,v.mode,j),La(m,z),m.return=v,m)}function _(v,m,z,j){return m===null||m.tag!==4||m.stateNode.containerInfo!==z.containerInfo||m.stateNode.implementation!==z.implementation?(m=Al(z,v.mode,j),m.return=v,m):(m=a(m,z.children||[]),m.return=v,m)}function P(v,m,z,j,Z){return m===null||m.tag!==7?(m=ln(z,v.mode,j,Z),m.return=v,m):(m=a(m,z),m.return=v,m)}function A(v,m,z){if(typeof m=="string"&&m!==""||typeof m=="number"||typeof m=="bigint")return m=jl(""+m,v.mode,z),m.return=v,m;if(typeof m=="object"&&m!==null){switch(m.$$typeof){case X:return z=Do(m.type,m.key,m.props,null,v.mode,z),La(z,m),z.return=v,z;case B:return m=Al(m,v.mode,z),m.return=v,m;case Q:return m=fn(m),A(v,m,z)}if(D(m)||Ye(m))return m=ln(m,v.mode,z,null),m.return=v,m;if(typeof m.then=="function")return A(v,qo(m),z);if(m.$$typeof===N)return A(v,Mo(v,m),z);Bo(v,m)}return null}function E(v,m,z,j){var Z=m!==null?m.key:null;if(typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint")return Z!==null?null:d(v,m,""+z,j);if(typeof z=="object"&&z!==null){switch(z.$$typeof){case X:return z.key===Z?p(v,m,z,j):null;case B:return z.key===Z?_(v,m,z,j):null;case Q:return z=fn(z),E(v,m,z,j)}if(D(z)||Ye(z))return Z!==null?null:P(v,m,z,j,null);if(typeof z.then=="function")return E(v,m,qo(z),j);if(z.$$typeof===N)return E(v,m,Mo(v,z),j);Bo(v,z)}return null}function T(v,m,z,j,Z){if(typeof j=="string"&&j!==""||typeof j=="number"||typeof j=="bigint")return v=v.get(z)||null,d(m,v,""+j,Z);if(typeof j=="object"&&j!==null){switch(j.$$typeof){case X:return v=v.get(j.key===null?z:j.key)||null,p(m,v,j,Z);case B:return v=v.get(j.key===null?z:j.key)||null,_(m,v,j,Z);case Q:return j=fn(j),T(v,m,z,j,Z)}if(D(j)||Ye(j))return v=v.get(z)||null,P(m,v,j,Z,null);if(typeof j.then=="function")return T(v,m,z,qo(j),Z);if(j.$$typeof===N)return T(v,m,z,Mo(m,j),Z);Bo(m,j)}return null}function K(v,m,z,j){for(var Z=null,ye=null,J=m,se=m=0,me=null;J!==null&&se<z.length;se++){J.index>se?(me=J,J=null):me=J.sibling;var we=E(v,J,z[se],j);if(we===null){J===null&&(J=me);break}e&&J&&we.alternate===null&&t(v,J),m=o(we,m,se),ye===null?Z=we:ye.sibling=we,ye=we,J=me}if(se===z.length)return r(v,J),he&&or(v,se),Z;if(J===null){for(;se<z.length;se++)J=A(v,z[se],j),J!==null&&(m=o(J,m,se),ye===null?Z=J:ye.sibling=J,ye=J);return he&&or(v,se),Z}for(J=n(J);se<z.length;se++)me=T(J,v,se,z[se],j),me!==null&&(e&&me.alternate!==null&&J.delete(me.key===null?se:me.key),m=o(me,m,se),ye===null?Z=me:ye.sibling=me,ye=me);return e&&J.forEach(function(Yr){return t(v,Yr)}),he&&or(v,se),Z}function ne(v,m,z,j){if(z==null)throw Error(f(151));for(var Z=null,ye=null,J=m,se=m=0,me=null,we=z.next();J!==null&&!we.done;se++,we=z.next()){J.index>se?(me=J,J=null):me=J.sibling;var Yr=E(v,J,we.value,j);if(Yr===null){J===null&&(J=me);break}e&&J&&Yr.alternate===null&&t(v,J),m=o(Yr,m,se),ye===null?Z=Yr:ye.sibling=Yr,ye=Yr,J=me}if(we.done)return r(v,J),he&&or(v,se),Z;if(J===null){for(;!we.done;se++,we=z.next())we=A(v,we.value,j),we!==null&&(m=o(we,m,se),ye===null?Z=we:ye.sibling=we,ye=we);return he&&or(v,se),Z}for(J=n(J);!we.done;se++,we=z.next())we=T(J,v,se,we.value,j),we!==null&&(e&&we.alternate!==null&&J.delete(we.key===null?se:we.key),m=o(we,m,se),ye===null?Z=we:ye.sibling=we,ye=we);return e&&J.forEach(function(kv){return t(v,kv)}),he&&or(v,se),Z}function _e(v,m,z,j){if(typeof z=="object"&&z!==null&&z.type===G&&z.key===null&&(z=z.props.children),typeof z=="object"&&z!==null){switch(z.$$typeof){case X:e:{for(var Z=z.key;m!==null;){if(m.key===Z){if(Z=z.type,Z===G){if(m.tag===7){r(v,m.sibling),j=a(m,z.props.children),j.return=v,v=j;break e}}else if(m.elementType===Z||typeof Z=="object"&&Z!==null&&Z.$$typeof===Q&&fn(Z)===m.type){r(v,m.sibling),j=a(m,z.props),La(j,z),j.return=v,v=j;break e}r(v,m);break}else t(v,m);m=m.sibling}z.type===G?(j=ln(z.props.children,v.mode,j,z.key),j.return=v,v=j):(j=Do(z.type,z.key,z.props,null,v.mode,j),La(j,z),j.return=v,v=j)}return l(v);case B:e:{for(Z=z.key;m!==null;){if(m.key===Z)if(m.tag===4&&m.stateNode.containerInfo===z.containerInfo&&m.stateNode.implementation===z.implementation){r(v,m.sibling),j=a(m,z.children||[]),j.return=v,v=j;break e}else{r(v,m);break}else t(v,m);m=m.sibling}j=Al(z,v.mode,j),j.return=v,v=j}return l(v);case Q:return z=fn(z),_e(v,m,z,j)}if(D(z))return K(v,m,z,j);if(Ye(z)){if(Z=Ye(z),typeof Z!="function")throw Error(f(150));return z=Z.call(z),ne(v,m,z,j)}if(typeof z.then=="function")return _e(v,m,qo(z),j);if(z.$$typeof===N)return _e(v,m,Mo(v,z),j);Bo(v,z)}return typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint"?(z=""+z,m!==null&&m.tag===6?(r(v,m.sibling),j=a(m,z),j.return=v,v=j):(r(v,m),j=jl(z,v.mode,j),j.return=v,v=j),l(v)):r(v,m)}return function(v,m,z,j){try{Aa=0;var Z=_e(v,m,z,j);return Kn=null,Z}catch(J){if(J===Qn||J===Uo)throw J;var ye=xt(29,J,null,v.mode);return ye.lanes=j,ye.return=v,ye}}}var mn=Pd(!0),jd=Pd(!1),Pr=!1;function Bl(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Vl(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function jr(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ar(e,t,r){var n=e.updateQueue;if(n===null)return null;if(n=n.shared,(xe&2)!==0){var a=n.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),n.pending=t,t=Oo(e),md(e,null,r),t}return Ro(e,n,t,r),Oo(e)}function Ra(e,t,r){if(t=t.updateQueue,t!==null&&(t=t.shared,(r&4194048)!==0)){var n=t.lanes;n&=e.pendingLanes,r|=n,t.lanes=r,Su(e,r)}}function Wl(e,t){var r=e.updateQueue,n=e.alternate;if(n!==null&&(n=n.updateQueue,r===n)){var a=null,o=null;if(r=r.firstBaseUpdate,r!==null){do{var l={lane:r.lane,tag:r.tag,payload:r.payload,callback:null,next:null};o===null?a=o=l:o=o.next=l,r=r.next}while(r!==null);o===null?a=o=t:o=o.next=t}else a=o=t;r={baseState:n.baseState,firstBaseUpdate:a,lastBaseUpdate:o,shared:n.shared,callbacks:n.callbacks},e.updateQueue=r;return}e=r.lastBaseUpdate,e===null?r.firstBaseUpdate=t:e.next=t,r.lastBaseUpdate=t}var Yl=!1;function Oa(){if(Yl){var e=Yn;if(e!==null)throw e}}function Da(e,t,r,n){Yl=!1;var a=e.updateQueue;Pr=!1;var o=a.firstBaseUpdate,l=a.lastBaseUpdate,d=a.shared.pending;if(d!==null){a.shared.pending=null;var p=d,_=p.next;p.next=null,l===null?o=_:l.next=_,l=p;var P=e.alternate;P!==null&&(P=P.updateQueue,d=P.lastBaseUpdate,d!==l&&(d===null?P.firstBaseUpdate=_:d.next=_,P.lastBaseUpdate=p))}if(o!==null){var A=a.baseState;l=0,P=_=p=null,d=o;do{var E=d.lane&-536870913,T=E!==d.lane;if(T?(pe&E)===E:(n&E)===E){E!==0&&E===Wn&&(Yl=!0),P!==null&&(P=P.next={lane:0,tag:d.tag,payload:d.payload,callback:null,next:null});e:{var K=e,ne=d;E=t;var _e=r;switch(ne.tag){case 1:if(K=ne.payload,typeof K=="function"){A=K.call(_e,A,E);break e}A=K;break e;case 3:K.flags=K.flags&-65537|128;case 0:if(K=ne.payload,E=typeof K=="function"?K.call(_e,A,E):K,E==null)break e;A=S({},A,E);break e;case 2:Pr=!0}}E=d.callback,E!==null&&(e.flags|=64,T&&(e.flags|=8192),T=a.callbacks,T===null?a.callbacks=[E]:T.push(E))}else T={lane:E,tag:d.tag,payload:d.payload,callback:d.callback,next:null},P===null?(_=P=T,p=A):P=P.next=T,l|=E;if(d=d.next,d===null){if(d=a.shared.pending,d===null)break;T=d,d=T.next,T.next=null,a.lastBaseUpdate=T,a.shared.pending=null}}while(!0);P===null&&(p=A),a.baseState=p,a.firstBaseUpdate=_,a.lastBaseUpdate=P,o===null&&(a.shared.lanes=0),Ir|=l,e.lanes=l,e.memoizedState=A}}function Ad(e,t){if(typeof e!="function")throw Error(f(191,e));e.call(t)}function Ld(e,t){var r=e.callbacks;if(r!==null)for(e.callbacks=null,e=0;e<r.length;e++)Ad(r[e],t)}var Xn=g(null),Vo=g(0);function Rd(e,t){e=hr,F(Vo,e),F(Xn,t),hr=e|t.baseLanes}function Ql(){F(Vo,hr),F(Xn,Xn.current)}function Kl(){hr=Vo.current,R(Xn),R(Vo)}var kt=g(null),Mt=null;function Lr(e){var t=e.alternate;F(Me,Me.current&1),F(kt,e),Mt===null&&(t===null||Xn.current!==null||t.memoizedState!==null)&&(Mt=e)}function Xl(e){F(Me,Me.current),F(kt,e),Mt===null&&(Mt=e)}function Od(e){e.tag===22?(F(Me,Me.current),F(kt,e),Mt===null&&(Mt=e)):Rr(e)}function Rr(){F(Me,Me.current),F(kt,kt.current)}function St(e){R(kt),Mt===e&&(Mt=null),R(Me)}var Me=g(0);function Wo(e){for(var t=e;t!==null;){if(t.tag===13){var r=t.memoizedState;if(r!==null&&(r=r.dehydrated,r===null||ec(r)||tc(r)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder==="forwards"||t.memoizedProps.revealOrder==="backwards"||t.memoizedProps.revealOrder==="unstable_legacy-backwards"||t.memoizedProps.revealOrder==="together")){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var sr=0,le=null,Ce=null,He=null,Yo=!1,Gn=!1,gn=!1,Qo=0,Ia=0,Jn=null,m0=0;function Ie(){throw Error(f(321))}function Gl(e,t){if(t===null)return!1;for(var r=0;r<t.length&&r<e.length;r++)if(!wt(e[r],t[r]))return!1;return!0}function Jl(e,t,r,n,a,o){return sr=o,le=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,O.H=e===null||e.memoizedState===null?yf:ps,gn=!1,o=r(n,a),gn=!1,Gn&&(o=Id(t,r,n,a)),Dd(e),o}function Dd(e){O.H=$a;var t=Ce!==null&&Ce.next!==null;if(sr=0,He=Ce=le=null,Yo=!1,Ia=0,Jn=null,t)throw Error(f(300));e===null||qe||(e=e.dependencies,e!==null&&Fo(e)&&(qe=!0))}function Id(e,t,r,n){le=e;var a=0;do{if(Gn&&(Jn=null),Ia=0,Gn=!1,25<=a)throw Error(f(301));if(a+=1,He=Ce=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}O.H=wf,o=t(r,n)}while(Gn);return o}function g0(){var e=O.H,t=e.useState()[0];return t=typeof t.then=="function"?Fa(t):t,e=e.useState()[0],(Ce!==null?Ce.memoizedState:null)!==e&&(le.flags|=1024),t}function Zl(){var e=Qo!==0;return Qo=0,e}function es(e,t,r){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~r}function ts(e){if(Yo){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Yo=!1}sr=0,He=Ce=le=null,Gn=!1,Ia=Qo=0,Jn=null}function st(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return He===null?le.memoizedState=He=e:He=He.next=e,He}function $e(){if(Ce===null){var e=le.alternate;e=e!==null?e.memoizedState:null}else e=Ce.next;var t=He===null?le.memoizedState:He.next;if(t!==null)He=t,Ce=e;else{if(e===null)throw le.alternate===null?Error(f(467)):Error(f(310));Ce=e,e={memoizedState:Ce.memoizedState,baseState:Ce.baseState,baseQueue:Ce.baseQueue,queue:Ce.queue,next:null},He===null?le.memoizedState=He=e:He=He.next=e}return He}function Ko(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Fa(e){var t=Ia;return Ia+=1,Jn===null&&(Jn=[]),e=Ed(Jn,e,t),t=le,(He===null?t.memoizedState:He.next)===null&&(t=t.alternate,O.H=t===null||t.memoizedState===null?yf:ps),e}function Xo(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Fa(e);if(e.$$typeof===N)return Ze(e)}throw Error(f(438,String(e)))}function rs(e){var t=null,r=le.updateQueue;if(r!==null&&(t=r.memoCache),t==null){var n=le.alternate;n!==null&&(n=n.updateQueue,n!==null&&(n=n.memoCache,n!=null&&(t={data:n.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),r===null&&(r=Ko(),le.updateQueue=r),r.memoCache=t,r=t.data[t.index],r===void 0)for(r=t.data[t.index]=Array(e),n=0;n<e;n++)r[n]=at;return t.index++,r}function cr(e,t){return typeof t=="function"?t(e):t}function Go(e){var t=$e();return ns(t,Ce,e)}function ns(e,t,r){var n=e.queue;if(n===null)throw Error(f(311));n.lastRenderedReducer=r;var a=e.baseQueue,o=n.pending;if(o!==null){if(a!==null){var l=a.next;a.next=o.next,o.next=l}t.baseQueue=a=o,n.pending=null}if(o=e.baseState,a===null)e.memoizedState=o;else{t=a.next;var d=l=null,p=null,_=t,P=!1;do{var A=_.lane&-536870913;if(A!==_.lane?(pe&A)===A:(sr&A)===A){var E=_.revertLane;if(E===0)p!==null&&(p=p.next={lane:0,revertLane:0,gesture:null,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null}),A===Wn&&(P=!0);else if((sr&E)===E){_=_.next,E===Wn&&(P=!0);continue}else A={lane:0,revertLane:_.revertLane,gesture:null,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null},p===null?(d=p=A,l=o):p=p.next=A,le.lanes|=E,Ir|=E;A=_.action,gn&&r(o,A),o=_.hasEagerState?_.eagerState:r(o,A)}else E={lane:A,revertLane:_.revertLane,gesture:_.gesture,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null},p===null?(d=p=E,l=o):p=p.next=E,le.lanes|=A,Ir|=A;_=_.next}while(_!==null&&_!==t);if(p===null?l=o:p.next=d,!wt(o,e.memoizedState)&&(qe=!0,P&&(r=Yn,r!==null)))throw r;e.memoizedState=o,e.baseState=l,e.baseQueue=p,n.lastRenderedState=o}return a===null&&(n.lanes=0),[e.memoizedState,n.dispatch]}function as(e){var t=$e(),r=t.queue;if(r===null)throw Error(f(311));r.lastRenderedReducer=e;var n=r.dispatch,a=r.pending,o=t.memoizedState;if(a!==null){r.pending=null;var l=a=a.next;do o=e(o,l.action),l=l.next;while(l!==a);wt(o,t.memoizedState)||(qe=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),r.lastRenderedState=o}return[o,n]}function Fd(e,t,r){var n=le,a=$e(),o=he;if(o){if(r===void 0)throw Error(f(407));r=r()}else r=t();var l=!wt((Ce||a).memoizedState,r);if(l&&(a.memoizedState=r,qe=!0),a=a.queue,ls(Ud.bind(null,n,a,e),[e]),a.getSnapshot!==t||l||He!==null&&He.memoizedState.tag&1){if(n.flags|=2048,Zn(9,{destroy:void 0},$d.bind(null,n,a,r,t),null),Ee===null)throw Error(f(349));o||(sr&127)!==0||Md(n,t,r)}return r}function Md(e,t,r){e.flags|=16384,e={getSnapshot:t,value:r},t=le.updateQueue,t===null?(t=Ko(),le.updateQueue=t,t.stores=[e]):(r=t.stores,r===null?t.stores=[e]:r.push(e))}function $d(e,t,r,n){t.value=r,t.getSnapshot=n,Hd(t)&&qd(e)}function Ud(e,t,r){return r(function(){Hd(t)&&qd(e)})}function Hd(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!wt(e,r)}catch{return!0}}function qd(e){var t=on(e,2);t!==null&&ht(t,e,2)}function os(e){var t=st();if(typeof e=="function"){var r=e;if(e=r(),gn){Sr(!0);try{r()}finally{Sr(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:cr,lastRenderedState:e},t}function Bd(e,t,r,n){return e.baseState=r,ns(e,Ce,typeof n=="function"?n:cr)}function h0(e,t,r,n,a){if(ei(e))throw Error(f(485));if(e=t.action,e!==null){var o={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(l){o.listeners.push(l)}};O.T!==null?r(!0):o.isTransition=!1,n(o),r=t.pending,r===null?(o.next=t.pending=o,Vd(t,o)):(o.next=r.next,t.pending=r.next=o)}}function Vd(e,t){var r=t.action,n=t.payload,a=e.state;if(t.isTransition){var o=O.T,l={};O.T=l;try{var d=r(a,n),p=O.S;p!==null&&p(l,d),Wd(e,t,d)}catch(_){is(e,t,_)}finally{o!==null&&l.types!==null&&(o.types=l.types),O.T=o}}else try{o=r(a,n),Wd(e,t,o)}catch(_){is(e,t,_)}}function Wd(e,t,r){r!==null&&typeof r=="object"&&typeof r.then=="function"?r.then(function(n){Yd(e,t,n)},function(n){return is(e,t,n)}):Yd(e,t,r)}function Yd(e,t,r){t.status="fulfilled",t.value=r,Qd(t),e.state=r,t=e.pending,t!==null&&(r=t.next,r===t?e.pending=null:(r=r.next,t.next=r,Vd(e,r)))}function is(e,t,r){var n=e.pending;if(e.pending=null,n!==null){n=n.next;do t.status="rejected",t.reason=r,Qd(t),t=t.next;while(t!==n)}e.action=null}function Qd(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Kd(e,t){return t}function Xd(e,t){if(he){var r=Ee.formState;if(r!==null){e:{var n=le;if(he){if(Te){t:{for(var a=Te,o=Lt;a.nodeType!==8;){if(!o){a=null;break t}if(a=Rt(a.nextSibling),a===null){a=null;break t}}o=a.data,a=o==="F!"||o==="F"?a:null}if(a){Te=Rt(a.nextSibling),n=a.data==="F!";break e}}Nr(n)}n=!1}n&&(t=r[0])}}return r=st(),r.memoizedState=r.baseState=t,n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Kd,lastRenderedState:t},r.queue=n,r=hf.bind(null,le,n),n.dispatch=r,n=os(!1),o=fs.bind(null,le,!1,n.queue),n=st(),a={state:t,dispatch:null,action:e,pending:null},n.queue=a,r=h0.bind(null,le,a,o,r),a.dispatch=r,n.memoizedState=e,[t,r,!1]}function Gd(e){var t=$e();return Jd(t,Ce,e)}function Jd(e,t,r){if(t=ns(e,t,Kd)[0],e=Go(cr)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var n=Fa(t)}catch(l){throw l===Qn?Uo:l}else n=t;t=$e();var a=t.queue,o=a.dispatch;return r!==t.memoizedState&&(le.flags|=2048,Zn(9,{destroy:void 0},b0.bind(null,a,r),null)),[n,o,e]}function b0(e,t){e.action=t}function Zd(e){var t=$e(),r=Ce;if(r!==null)return Jd(t,r,e);$e(),t=t.memoizedState,r=$e();var n=r.queue.dispatch;return r.memoizedState=e,[t,n,!1]}function Zn(e,t,r,n){return e={tag:e,create:r,deps:n,inst:t,next:null},t=le.updateQueue,t===null&&(t=Ko(),le.updateQueue=t),r=t.lastEffect,r===null?t.lastEffect=e.next=e:(n=r.next,r.next=e,e.next=n,t.lastEffect=e),e}function ef(){return $e().memoizedState}function Jo(e,t,r,n){var a=st();le.flags|=e,a.memoizedState=Zn(1|t,{destroy:void 0},r,n===void 0?null:n)}function Zo(e,t,r,n){var a=$e();n=n===void 0?null:n;var o=a.memoizedState.inst;Ce!==null&&n!==null&&Gl(n,Ce.memoizedState.deps)?a.memoizedState=Zn(t,o,r,n):(le.flags|=e,a.memoizedState=Zn(1|t,o,r,n))}function tf(e,t){Jo(8390656,8,e,t)}function ls(e,t){Zo(2048,8,e,t)}function v0(e){le.flags|=4;var t=le.updateQueue;if(t===null)t=Ko(),le.updateQueue=t,t.events=[e];else{var r=t.events;r===null?t.events=[e]:r.push(e)}}function rf(e){var t=$e().memoizedState;return v0({ref:t,nextImpl:e}),function(){if((xe&2)!==0)throw Error(f(440));return t.impl.apply(void 0,arguments)}}function nf(e,t){return Zo(4,2,e,t)}function af(e,t){return Zo(4,4,e,t)}function of(e,t){if(typeof t=="function"){e=e();var r=t(e);return function(){typeof r=="function"?r():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function lf(e,t,r){r=r!=null?r.concat([e]):null,Zo(4,4,of.bind(null,t,e),r)}function ss(){}function sf(e,t){var r=$e();t=t===void 0?null:t;var n=r.memoizedState;return t!==null&&Gl(t,n[1])?n[0]:(r.memoizedState=[e,t],e)}function cf(e,t){var r=$e();t=t===void 0?null:t;var n=r.memoizedState;if(t!==null&&Gl(t,n[1]))return n[0];if(n=e(),gn){Sr(!0);try{e()}finally{Sr(!1)}}return r.memoizedState=[n,t],n}function cs(e,t,r){return r===void 0||(sr&1073741824)!==0&&(pe&261930)===0?e.memoizedState=t:(e.memoizedState=r,e=up(),le.lanes|=e,Ir|=e,r)}function uf(e,t,r,n){return wt(r,t)?r:Xn.current!==null?(e=cs(e,r,n),wt(e,t)||(qe=!0),e):(sr&42)===0||(sr&1073741824)!==0&&(pe&261930)===0?(qe=!0,e.memoizedState=r):(e=up(),le.lanes|=e,Ir|=e,t)}function df(e,t,r,n,a){var o=M.p;M.p=o!==0&&8>o?o:8;var l=O.T,d={};O.T=d,fs(e,!1,t,r);try{var p=a(),_=O.S;if(_!==null&&_(d,p),p!==null&&typeof p=="object"&&typeof p.then=="function"){var P=p0(p,n);Ma(e,t,P,_t(e))}else Ma(e,t,n,_t(e))}catch(A){Ma(e,t,{then:function(){},status:"rejected",reason:A},_t())}finally{M.p=o,l!==null&&d.types!==null&&(l.types=d.types),O.T=l}}function y0(){}function us(e,t,r,n){if(e.tag!==5)throw Error(f(476));var a=ff(e).queue;df(e,a,t,ge,r===null?y0:function(){return pf(e),r(n)})}function ff(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:ge,baseState:ge,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:cr,lastRenderedState:ge},next:null};var r={};return t.next={memoizedState:r,baseState:r,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:cr,lastRenderedState:r},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function pf(e){var t=ff(e);t.next===null&&(t=e.alternate.memoizedState),Ma(e,t.next.queue,{},_t())}function ds(){return Ze(ro)}function mf(){return $e().memoizedState}function gf(){return $e().memoizedState}function w0(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var r=_t();e=jr(r);var n=Ar(t,e,r);n!==null&&(ht(n,t,r),Ra(n,t,r)),t={cache:$l()},e.payload=t;return}t=t.return}}function x0(e,t,r){var n=_t();r={lane:n,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},ei(e)?bf(t,r):(r=Tl(e,t,r,n),r!==null&&(ht(r,e,n),vf(r,t,n)))}function hf(e,t,r){var n=_t();Ma(e,t,r,n)}function Ma(e,t,r,n){var a={lane:n,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null};if(ei(e))bf(t,a);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var l=t.lastRenderedState,d=o(l,r);if(a.hasEagerState=!0,a.eagerState=d,wt(d,l))return Ro(e,t,a,0),Ee===null&&Lo(),!1}catch{}if(r=Tl(e,t,a,n),r!==null)return ht(r,e,n),vf(r,t,n),!0}return!1}function fs(e,t,r,n){if(n={lane:2,revertLane:Bs(),gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},ei(e)){if(t)throw Error(f(479))}else t=Tl(e,r,n,2),t!==null&&ht(t,e,2)}function ei(e){var t=e.alternate;return e===le||t!==null&&t===le}function bf(e,t){Gn=Yo=!0;var r=e.pending;r===null?t.next=t:(t.next=r.next,r.next=t),e.pending=t}function vf(e,t,r){if((r&4194048)!==0){var n=t.lanes;n&=e.pendingLanes,r|=n,t.lanes=r,Su(e,r)}}var $a={readContext:Ze,use:Xo,useCallback:Ie,useContext:Ie,useEffect:Ie,useImperativeHandle:Ie,useLayoutEffect:Ie,useInsertionEffect:Ie,useMemo:Ie,useReducer:Ie,useRef:Ie,useState:Ie,useDebugValue:Ie,useDeferredValue:Ie,useTransition:Ie,useSyncExternalStore:Ie,useId:Ie,useHostTransitionStatus:Ie,useFormState:Ie,useActionState:Ie,useOptimistic:Ie,useMemoCache:Ie,useCacheRefresh:Ie};$a.useEffectEvent=Ie;var yf={readContext:Ze,use:Xo,useCallback:function(e,t){return st().memoizedState=[e,t===void 0?null:t],e},useContext:Ze,useEffect:tf,useImperativeHandle:function(e,t,r){r=r!=null?r.concat([e]):null,Jo(4194308,4,of.bind(null,t,e),r)},useLayoutEffect:function(e,t){return Jo(4194308,4,e,t)},useInsertionEffect:function(e,t){Jo(4,2,e,t)},useMemo:function(e,t){var r=st();t=t===void 0?null:t;var n=e();if(gn){Sr(!0);try{e()}finally{Sr(!1)}}return r.memoizedState=[n,t],n},useReducer:function(e,t,r){var n=st();if(r!==void 0){var a=r(t);if(gn){Sr(!0);try{r(t)}finally{Sr(!1)}}}else a=t;return n.memoizedState=n.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},n.queue=e,e=e.dispatch=x0.bind(null,le,e),[n.memoizedState,e]},useRef:function(e){var t=st();return e={current:e},t.memoizedState=e},useState:function(e){e=os(e);var t=e.queue,r=hf.bind(null,le,t);return t.dispatch=r,[e.memoizedState,r]},useDebugValue:ss,useDeferredValue:function(e,t){var r=st();return cs(r,e,t)},useTransition:function(){var e=os(!1);return e=df.bind(null,le,e.queue,!0,!1),st().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,r){var n=le,a=st();if(he){if(r===void 0)throw Error(f(407));r=r()}else{if(r=t(),Ee===null)throw Error(f(349));(pe&127)!==0||Md(n,t,r)}a.memoizedState=r;var o={value:r,getSnapshot:t};return a.queue=o,tf(Ud.bind(null,n,o,e),[e]),n.flags|=2048,Zn(9,{destroy:void 0},$d.bind(null,n,o,r,t),null),r},useId:function(){var e=st(),t=Ee.identifierPrefix;if(he){var r=Yt,n=Wt;r=(n&~(1<<32-yt(n)-1)).toString(32)+r,t="_"+t+"R_"+r,r=Qo++,0<r&&(t+="H"+r.toString(32)),t+="_"}else r=m0++,t="_"+t+"r_"+r.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:ds,useFormState:Xd,useActionState:Xd,useOptimistic:function(e){var t=st();t.memoizedState=t.baseState=e;var r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=r,t=fs.bind(null,le,!0,r),r.dispatch=t,[e,t]},useMemoCache:rs,useCacheRefresh:function(){return st().memoizedState=w0.bind(null,le)},useEffectEvent:function(e){var t=st(),r={impl:e};return t.memoizedState=r,function(){if((xe&2)!==0)throw Error(f(440));return r.impl.apply(void 0,arguments)}}},ps={readContext:Ze,use:Xo,useCallback:sf,useContext:Ze,useEffect:ls,useImperativeHandle:lf,useInsertionEffect:nf,useLayoutEffect:af,useMemo:cf,useReducer:Go,useRef:ef,useState:function(){return Go(cr)},useDebugValue:ss,useDeferredValue:function(e,t){var r=$e();return uf(r,Ce.memoizedState,e,t)},useTransition:function(){var e=Go(cr)[0],t=$e().memoizedState;return[typeof e=="boolean"?e:Fa(e),t]},useSyncExternalStore:Fd,useId:mf,useHostTransitionStatus:ds,useFormState:Gd,useActionState:Gd,useOptimistic:function(e,t){var r=$e();return Bd(r,Ce,e,t)},useMemoCache:rs,useCacheRefresh:gf};ps.useEffectEvent=rf;var wf={readContext:Ze,use:Xo,useCallback:sf,useContext:Ze,useEffect:ls,useImperativeHandle:lf,useInsertionEffect:nf,useLayoutEffect:af,useMemo:cf,useReducer:as,useRef:ef,useState:function(){return as(cr)},useDebugValue:ss,useDeferredValue:function(e,t){var r=$e();return Ce===null?cs(r,e,t):uf(r,Ce.memoizedState,e,t)},useTransition:function(){var e=as(cr)[0],t=$e().memoizedState;return[typeof e=="boolean"?e:Fa(e),t]},useSyncExternalStore:Fd,useId:mf,useHostTransitionStatus:ds,useFormState:Zd,useActionState:Zd,useOptimistic:function(e,t){var r=$e();return Ce!==null?Bd(r,Ce,e,t):(r.baseState=e,[e,r.queue.dispatch])},useMemoCache:rs,useCacheRefresh:gf};wf.useEffectEvent=rf;function ms(e,t,r,n){t=e.memoizedState,r=r(n,t),r=r==null?t:S({},t,r),e.memoizedState=r,e.lanes===0&&(e.updateQueue.baseState=r)}var gs={enqueueSetState:function(e,t,r){e=e._reactInternals;var n=_t(),a=jr(n);a.payload=t,r!=null&&(a.callback=r),t=Ar(e,a,n),t!==null&&(ht(t,e,n),Ra(t,e,n))},enqueueReplaceState:function(e,t,r){e=e._reactInternals;var n=_t(),a=jr(n);a.tag=1,a.payload=t,r!=null&&(a.callback=r),t=Ar(e,a,n),t!==null&&(ht(t,e,n),Ra(t,e,n))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var r=_t(),n=jr(r);n.tag=2,t!=null&&(n.callback=t),t=Ar(e,n,r),t!==null&&(ht(t,e,r),Ra(t,e,r))}};function xf(e,t,r,n,a,o,l){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(n,o,l):t.prototype&&t.prototype.isPureReactComponent?!_a(r,n)||!_a(a,o):!0}function kf(e,t,r,n){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(r,n),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(r,n),t.state!==e&&gs.enqueueReplaceState(t,t.state,null)}function hn(e,t){var r=t;if("ref"in t){r={};for(var n in t)n!=="ref"&&(r[n]=t[n])}if(e=e.defaultProps){r===t&&(r=S({},r));for(var a in e)r[a]===void 0&&(r[a]=e[a])}return r}function Sf(e){Ao(e)}function Cf(e){console.error(e)}function zf(e){Ao(e)}function ti(e,t){try{var r=e.onUncaughtError;r(t.value,{componentStack:t.stack})}catch(n){setTimeout(function(){throw n})}}function _f(e,t,r){try{var n=e.onCaughtError;n(r.value,{componentStack:r.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function hs(e,t,r){return r=jr(r),r.tag=3,r.payload={element:null},r.callback=function(){ti(e,t)},r}function Ef(e){return e=jr(e),e.tag=3,e}function Nf(e,t,r,n){var a=r.type.getDerivedStateFromError;if(typeof a=="function"){var o=n.value;e.payload=function(){return a(o)},e.callback=function(){_f(t,r,n)}}var l=r.stateNode;l!==null&&typeof l.componentDidCatch=="function"&&(e.callback=function(){_f(t,r,n),typeof a!="function"&&(Fr===null?Fr=new Set([this]):Fr.add(this));var d=n.stack;this.componentDidCatch(n.value,{componentStack:d!==null?d:""})})}function k0(e,t,r,n,a){if(r.flags|=32768,n!==null&&typeof n=="object"&&typeof n.then=="function"){if(t=r.alternate,t!==null&&Vn(t,r,a,!0),r=kt.current,r!==null){switch(r.tag){case 31:case 13:return Mt===null?pi():r.alternate===null&&Fe===0&&(Fe=3),r.flags&=-257,r.flags|=65536,r.lanes=a,n===Ho?r.flags|=16384:(t=r.updateQueue,t===null?r.updateQueue=new Set([n]):t.add(n),Us(e,n,a)),!1;case 22:return r.flags|=65536,n===Ho?r.flags|=16384:(t=r.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([n])},r.updateQueue=t):(r=t.retryQueue,r===null?t.retryQueue=new Set([n]):r.add(n)),Us(e,n,a)),!1}throw Error(f(435,r.tag))}return Us(e,n,a),pi(),!1}if(he)return t=kt.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,n!==Ol&&(e=Error(f(422),{cause:n}),Ta(Pt(e,r)))):(n!==Ol&&(t=Error(f(423),{cause:n}),Ta(Pt(t,r))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,n=Pt(n,r),a=hs(e.stateNode,n,a),Wl(e,a),Fe!==4&&(Fe=2)),!1;var o=Error(f(520),{cause:n});if(o=Pt(o,r),Qa===null?Qa=[o]:Qa.push(o),Fe!==4&&(Fe=2),t===null)return!0;n=Pt(n,r),r=t;do{switch(r.tag){case 3:return r.flags|=65536,e=a&-a,r.lanes|=e,e=hs(r.stateNode,n,e),Wl(r,e),!1;case 1:if(t=r.type,o=r.stateNode,(r.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||o!==null&&typeof o.componentDidCatch=="function"&&(Fr===null||!Fr.has(o))))return r.flags|=65536,a&=-a,r.lanes|=a,a=Ef(a),Nf(a,e,r,n),Wl(r,a),!1}r=r.return}while(r!==null);return!1}var bs=Error(f(461)),qe=!1;function et(e,t,r,n){t.child=e===null?jd(t,null,r,n):mn(t,e.child,r,n)}function Tf(e,t,r,n,a){r=r.render;var o=t.ref;if("ref"in n){var l={};for(var d in n)d!=="ref"&&(l[d]=n[d])}else l=n;return un(t),n=Jl(e,t,r,l,o,a),d=Zl(),e!==null&&!qe?(es(e,t,a),ur(e,t,a)):(he&&d&&Ll(t),t.flags|=1,et(e,t,n,a),t.child)}function Pf(e,t,r,n,a){if(e===null){var o=r.type;return typeof o=="function"&&!Pl(o)&&o.defaultProps===void 0&&r.compare===null?(t.tag=15,t.type=o,jf(e,t,o,n,a)):(e=Do(r.type,null,n,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!zs(e,a)){var l=o.memoizedProps;if(r=r.compare,r=r!==null?r:_a,r(l,n)&&e.ref===t.ref)return ur(e,t,a)}return t.flags|=1,e=ar(o,n),e.ref=t.ref,e.return=t,t.child=e}function jf(e,t,r,n,a){if(e!==null){var o=e.memoizedProps;if(_a(o,n)&&e.ref===t.ref)if(qe=!1,t.pendingProps=n=o,zs(e,a))(e.flags&131072)!==0&&(qe=!0);else return t.lanes=e.lanes,ur(e,t,a)}return vs(e,t,r,n,a)}function Af(e,t,r,n){var a=n.children,o=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.mode==="hidden"){if((t.flags&128)!==0){if(o=o!==null?o.baseLanes|r:r,e!==null){for(n=t.child=e.child,a=0;n!==null;)a=a|n.lanes|n.childLanes,n=n.sibling;n=a&~o}else n=0,t.child=null;return Lf(e,t,o,r,n)}if((r&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&$o(t,o!==null?o.cachePool:null),o!==null?Rd(t,o):Ql(),Od(t);else return n=t.lanes=536870912,Lf(e,t,o!==null?o.baseLanes|r:r,r,n)}else o!==null?($o(t,o.cachePool),Rd(t,o),Rr(t),t.memoizedState=null):(e!==null&&$o(t,null),Ql(),Rr(t));return et(e,t,a,r),t.child}function Ua(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Lf(e,t,r,n,a){var o=Hl();return o=o===null?null:{parent:Ue._currentValue,pool:o},t.memoizedState={baseLanes:r,cachePool:o},e!==null&&$o(t,null),Ql(),Od(t),e!==null&&Vn(e,t,n,!0),t.childLanes=a,null}function ri(e,t){return t=ai({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Rf(e,t,r){return mn(t,e.child,null,r),e=ri(t,t.pendingProps),e.flags|=2,St(t),t.memoizedState=null,e}function S0(e,t,r){var n=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(he){if(n.mode==="hidden")return e=ri(t,n),t.lanes=536870912,Ua(null,e);if(Xl(t),(e=Te)?(e=Qp(e,Lt),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:_r!==null?{id:Wt,overflow:Yt}:null,retryLane:536870912,hydrationErrors:null},r=hd(e),r.return=t,t.child=r,Je=t,Te=null)):e=null,e===null)throw Nr(t);return t.lanes=536870912,null}return ri(t,n)}var o=e.memoizedState;if(o!==null){var l=o.dehydrated;if(Xl(t),a)if(t.flags&256)t.flags&=-257,t=Rf(e,t,r);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(f(558));else if(qe||Vn(e,t,r,!1),a=(r&e.childLanes)!==0,qe||a){if(n=Ee,n!==null&&(l=Cu(n,r),l!==0&&l!==o.retryLane))throw o.retryLane=l,on(e,l),ht(n,e,l),bs;pi(),t=Rf(e,t,r)}else e=o.treeContext,Te=Rt(l.nextSibling),Je=t,he=!0,Er=null,Lt=!1,e!==null&&yd(t,e),t=ri(t,n),t.flags|=4096;return t}return e=ar(e.child,{mode:n.mode,children:n.children}),e.ref=t.ref,t.child=e,e.return=t,e}function ni(e,t){var r=t.ref;if(r===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof r!="function"&&typeof r!="object")throw Error(f(284));(e===null||e.ref!==r)&&(t.flags|=4194816)}}function vs(e,t,r,n,a){return un(t),r=Jl(e,t,r,n,void 0,a),n=Zl(),e!==null&&!qe?(es(e,t,a),ur(e,t,a)):(he&&n&&Ll(t),t.flags|=1,et(e,t,r,a),t.child)}function Of(e,t,r,n,a,o){return un(t),t.updateQueue=null,r=Id(t,n,r,a),Dd(e),n=Zl(),e!==null&&!qe?(es(e,t,o),ur(e,t,o)):(he&&n&&Ll(t),t.flags|=1,et(e,t,r,o),t.child)}function Df(e,t,r,n,a){if(un(t),t.stateNode===null){var o=Un,l=r.contextType;typeof l=="object"&&l!==null&&(o=Ze(l)),o=new r(n,o),t.memoizedState=o.state!==null&&o.state!==void 0?o.state:null,o.updater=gs,t.stateNode=o,o._reactInternals=t,o=t.stateNode,o.props=n,o.state=t.memoizedState,o.refs={},Bl(t),l=r.contextType,o.context=typeof l=="object"&&l!==null?Ze(l):Un,o.state=t.memoizedState,l=r.getDerivedStateFromProps,typeof l=="function"&&(ms(t,r,l,n),o.state=t.memoizedState),typeof r.getDerivedStateFromProps=="function"||typeof o.getSnapshotBeforeUpdate=="function"||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(l=o.state,typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount(),l!==o.state&&gs.enqueueReplaceState(o,o.state,null),Da(t,n,o,a),Oa(),o.state=t.memoizedState),typeof o.componentDidMount=="function"&&(t.flags|=4194308),n=!0}else if(e===null){o=t.stateNode;var d=t.memoizedProps,p=hn(r,d);o.props=p;var _=o.context,P=r.contextType;l=Un,typeof P=="object"&&P!==null&&(l=Ze(P));var A=r.getDerivedStateFromProps;P=typeof A=="function"||typeof o.getSnapshotBeforeUpdate=="function",d=t.pendingProps!==d,P||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(d||_!==l)&&kf(t,o,n,l),Pr=!1;var E=t.memoizedState;o.state=E,Da(t,n,o,a),Oa(),_=t.memoizedState,d||E!==_||Pr?(typeof A=="function"&&(ms(t,r,A,n),_=t.memoizedState),(p=Pr||xf(t,r,p,n,E,_,l))?(P||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(t.flags|=4194308)):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=n,t.memoizedState=_),o.props=n,o.state=_,o.context=l,n=p):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),n=!1)}else{o=t.stateNode,Vl(e,t),l=t.memoizedProps,P=hn(r,l),o.props=P,A=t.pendingProps,E=o.context,_=r.contextType,p=Un,typeof _=="object"&&_!==null&&(p=Ze(_)),d=r.getDerivedStateFromProps,(_=typeof d=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(l!==A||E!==p)&&kf(t,o,n,p),Pr=!1,E=t.memoizedState,o.state=E,Da(t,n,o,a),Oa();var T=t.memoizedState;l!==A||E!==T||Pr||e!==null&&e.dependencies!==null&&Fo(e.dependencies)?(typeof d=="function"&&(ms(t,r,d,n),T=t.memoizedState),(P=Pr||xf(t,r,P,n,E,T,p)||e!==null&&e.dependencies!==null&&Fo(e.dependencies))?(_||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(n,T,p),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(n,T,p)),typeof o.componentDidUpdate=="function"&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof o.componentDidUpdate!="function"||l===e.memoizedProps&&E===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&E===e.memoizedState||(t.flags|=1024),t.memoizedProps=n,t.memoizedState=T),o.props=n,o.state=T,o.context=p,n=P):(typeof o.componentDidUpdate!="function"||l===e.memoizedProps&&E===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&E===e.memoizedState||(t.flags|=1024),n=!1)}return o=n,ni(e,t),n=(t.flags&128)!==0,o||n?(o=t.stateNode,r=n&&typeof r.getDerivedStateFromError!="function"?null:o.render(),t.flags|=1,e!==null&&n?(t.child=mn(t,e.child,null,a),t.child=mn(t,null,r,a)):et(e,t,r,a),t.memoizedState=o.state,e=t.child):e=ur(e,t,a),e}function If(e,t,r,n){return sn(),t.flags|=256,et(e,t,r,n),t.child}var ys={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function ws(e){return{baseLanes:e,cachePool:zd()}}function xs(e,t,r){return e=e!==null?e.childLanes&~r:0,t&&(e|=zt),e}function Ff(e,t,r){var n=t.pendingProps,a=!1,o=(t.flags&128)!==0,l;if((l=o)||(l=e!==null&&e.memoizedState===null?!1:(Me.current&2)!==0),l&&(a=!0,t.flags&=-129),l=(t.flags&32)!==0,t.flags&=-33,e===null){if(he){if(a?Lr(t):Rr(t),(e=Te)?(e=Qp(e,Lt),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:_r!==null?{id:Wt,overflow:Yt}:null,retryLane:536870912,hydrationErrors:null},r=hd(e),r.return=t,t.child=r,Je=t,Te=null)):e=null,e===null)throw Nr(t);return tc(e)?t.lanes=32:t.lanes=536870912,null}var d=n.children;return n=n.fallback,a?(Rr(t),a=t.mode,d=ai({mode:"hidden",children:d},a),n=ln(n,a,r,null),d.return=t,n.return=t,d.sibling=n,t.child=d,n=t.child,n.memoizedState=ws(r),n.childLanes=xs(e,l,r),t.memoizedState=ys,Ua(null,n)):(Lr(t),ks(t,d))}var p=e.memoizedState;if(p!==null&&(d=p.dehydrated,d!==null)){if(o)t.flags&256?(Lr(t),t.flags&=-257,t=Ss(e,t,r)):t.memoizedState!==null?(Rr(t),t.child=e.child,t.flags|=128,t=null):(Rr(t),d=n.fallback,a=t.mode,n=ai({mode:"visible",children:n.children},a),d=ln(d,a,r,null),d.flags|=2,n.return=t,d.return=t,n.sibling=d,t.child=n,mn(t,e.child,null,r),n=t.child,n.memoizedState=ws(r),n.childLanes=xs(e,l,r),t.memoizedState=ys,t=Ua(null,n));else if(Lr(t),tc(d)){if(l=d.nextSibling&&d.nextSibling.dataset,l)var _=l.dgst;l=_,n=Error(f(419)),n.stack="",n.digest=l,Ta({value:n,source:null,stack:null}),t=Ss(e,t,r)}else if(qe||Vn(e,t,r,!1),l=(r&e.childLanes)!==0,qe||l){if(l=Ee,l!==null&&(n=Cu(l,r),n!==0&&n!==p.retryLane))throw p.retryLane=n,on(e,n),ht(l,e,n),bs;ec(d)||pi(),t=Ss(e,t,r)}else ec(d)?(t.flags|=192,t.child=e.child,t=null):(e=p.treeContext,Te=Rt(d.nextSibling),Je=t,he=!0,Er=null,Lt=!1,e!==null&&yd(t,e),t=ks(t,n.children),t.flags|=4096);return t}return a?(Rr(t),d=n.fallback,a=t.mode,p=e.child,_=p.sibling,n=ar(p,{mode:"hidden",children:n.children}),n.subtreeFlags=p.subtreeFlags&65011712,_!==null?d=ar(_,d):(d=ln(d,a,r,null),d.flags|=2),d.return=t,n.return=t,n.sibling=d,t.child=n,Ua(null,n),n=t.child,d=e.child.memoizedState,d===null?d=ws(r):(a=d.cachePool,a!==null?(p=Ue._currentValue,a=a.parent!==p?{parent:p,pool:p}:a):a=zd(),d={baseLanes:d.baseLanes|r,cachePool:a}),n.memoizedState=d,n.childLanes=xs(e,l,r),t.memoizedState=ys,Ua(e.child,n)):(Lr(t),r=e.child,e=r.sibling,r=ar(r,{mode:"visible",children:n.children}),r.return=t,r.sibling=null,e!==null&&(l=t.deletions,l===null?(t.deletions=[e],t.flags|=16):l.push(e)),t.child=r,t.memoizedState=null,r)}function ks(e,t){return t=ai({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function ai(e,t){return e=xt(22,e,null,t),e.lanes=0,e}function Ss(e,t,r){return mn(t,e.child,null,r),e=ks(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Mf(e,t,r){e.lanes|=t;var n=e.alternate;n!==null&&(n.lanes|=t),Fl(e.return,t,r)}function Cs(e,t,r,n,a,o){var l=e.memoizedState;l===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:n,tail:r,tailMode:a,treeForkCount:o}:(l.isBackwards=t,l.rendering=null,l.renderingStartTime=0,l.last=n,l.tail=r,l.tailMode=a,l.treeForkCount=o)}function $f(e,t,r){var n=t.pendingProps,a=n.revealOrder,o=n.tail;n=n.children;var l=Me.current,d=(l&2)!==0;if(d?(l=l&1|2,t.flags|=128):l&=1,F(Me,l),et(e,t,n,r),n=he?Na:0,!d&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Mf(e,r,t);else if(e.tag===19)Mf(e,r,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"forwards":for(r=t.child,a=null;r!==null;)e=r.alternate,e!==null&&Wo(e)===null&&(a=r),r=r.sibling;r=a,r===null?(a=t.child,t.child=null):(a=r.sibling,r.sibling=null),Cs(t,!1,a,r,o,n);break;case"backwards":case"unstable_legacy-backwards":for(r=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&Wo(e)===null){t.child=a;break}e=a.sibling,a.sibling=r,r=a,a=e}Cs(t,!0,r,null,o,n);break;case"together":Cs(t,!1,null,null,void 0,n);break;default:t.memoizedState=null}return t.child}function ur(e,t,r){if(e!==null&&(t.dependencies=e.dependencies),Ir|=t.lanes,(r&t.childLanes)===0)if(e!==null){if(Vn(e,t,r,!1),(r&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(f(153));if(t.child!==null){for(e=t.child,r=ar(e,e.pendingProps),t.child=r,r.return=t;e.sibling!==null;)e=e.sibling,r=r.sibling=ar(e,e.pendingProps),r.return=t;r.sibling=null}return t.child}function zs(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&Fo(e)))}function C0(e,t,r){switch(t.tag){case 3:be(t,t.stateNode.containerInfo),Tr(t,Ue,e.memoizedState.cache),sn();break;case 27:case 5:Vt(t);break;case 4:be(t,t.stateNode.containerInfo);break;case 10:Tr(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,Xl(t),null;break;case 13:var n=t.memoizedState;if(n!==null)return n.dehydrated!==null?(Lr(t),t.flags|=128,null):(r&t.child.childLanes)!==0?Ff(e,t,r):(Lr(t),e=ur(e,t,r),e!==null?e.sibling:null);Lr(t);break;case 19:var a=(e.flags&128)!==0;if(n=(r&t.childLanes)!==0,n||(Vn(e,t,r,!1),n=(r&t.childLanes)!==0),a){if(n)return $f(e,t,r);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),F(Me,Me.current),n)break;return null;case 22:return t.lanes=0,Af(e,t,r,t.pendingProps);case 24:Tr(t,Ue,e.memoizedState.cache)}return ur(e,t,r)}function Uf(e,t,r){if(e!==null)if(e.memoizedProps!==t.pendingProps)qe=!0;else{if(!zs(e,r)&&(t.flags&128)===0)return qe=!1,C0(e,t,r);qe=(e.flags&131072)!==0}else qe=!1,he&&(t.flags&1048576)!==0&&vd(t,Na,t.index);switch(t.lanes=0,t.tag){case 16:e:{var n=t.pendingProps;if(e=fn(t.elementType),t.type=e,typeof e=="function")Pl(e)?(n=hn(e,n),t.tag=1,t=Df(null,t,e,n,r)):(t.tag=0,t=vs(null,t,e,n,r));else{if(e!=null){var a=e.$$typeof;if(a===I){t.tag=11,t=Tf(null,t,e,n,r);break e}else if(a===L){t.tag=14,t=Pf(null,t,e,n,r);break e}}throw t=Qe(e)||e,Error(f(306,t,""))}}return t;case 0:return vs(e,t,t.type,t.pendingProps,r);case 1:return n=t.type,a=hn(n,t.pendingProps),Df(e,t,n,a,r);case 3:e:{if(be(t,t.stateNode.containerInfo),e===null)throw Error(f(387));n=t.pendingProps;var o=t.memoizedState;a=o.element,Vl(e,t),Da(t,n,null,r);var l=t.memoizedState;if(n=l.cache,Tr(t,Ue,n),n!==o.cache&&Ml(t,[Ue],r,!0),Oa(),n=l.element,o.isDehydrated)if(o={element:n,isDehydrated:!1,cache:l.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=If(e,t,n,r);break e}else if(n!==a){a=Pt(Error(f(424)),t),Ta(a),t=If(e,t,n,r);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,Te=Rt(e.firstChild),Je=t,he=!0,Er=null,Lt=!0,r=jd(t,null,n,r),t.child=r;r;)r.flags=r.flags&-3|4096,r=r.sibling;else{if(sn(),n===a){t=ur(e,t,r);break e}et(e,t,n,r)}t=t.child}return t;case 26:return ni(e,t),e===null?(r=em(t.type,null,t.pendingProps,null))?t.memoizedState=r:he||(r=t.type,e=t.pendingProps,n=ki(ie.current).createElement(r),n[Ge]=t,n[ut]=e,tt(n,r,e),Ke(n),t.stateNode=n):t.memoizedState=em(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Vt(t),e===null&&he&&(n=t.stateNode=Gp(t.type,t.pendingProps,ie.current),Je=t,Lt=!0,a=Te,Hr(t.type)?(rc=a,Te=Rt(n.firstChild)):Te=a),et(e,t,t.pendingProps.children,r),ni(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&he&&((a=n=Te)&&(n=J0(n,t.type,t.pendingProps,Lt),n!==null?(t.stateNode=n,Je=t,Te=Rt(n.firstChild),Lt=!1,a=!0):a=!1),a||Nr(t)),Vt(t),a=t.type,o=t.pendingProps,l=e!==null?e.memoizedProps:null,n=o.children,Gs(a,o)?n=null:l!==null&&Gs(a,l)&&(t.flags|=32),t.memoizedState!==null&&(a=Jl(e,t,g0,null,null,r),ro._currentValue=a),ni(e,t),et(e,t,n,r),t.child;case 6:return e===null&&he&&((e=r=Te)&&(r=Z0(r,t.pendingProps,Lt),r!==null?(t.stateNode=r,Je=t,Te=null,e=!0):e=!1),e||Nr(t)),null;case 13:return Ff(e,t,r);case 4:return be(t,t.stateNode.containerInfo),n=t.pendingProps,e===null?t.child=mn(t,null,n,r):et(e,t,n,r),t.child;case 11:return Tf(e,t,t.type,t.pendingProps,r);case 7:return et(e,t,t.pendingProps,r),t.child;case 8:return et(e,t,t.pendingProps.children,r),t.child;case 12:return et(e,t,t.pendingProps.children,r),t.child;case 10:return n=t.pendingProps,Tr(t,t.type,n.value),et(e,t,n.children,r),t.child;case 9:return a=t.type._context,n=t.pendingProps.children,un(t),a=Ze(a),n=n(a),t.flags|=1,et(e,t,n,r),t.child;case 14:return Pf(e,t,t.type,t.pendingProps,r);case 15:return jf(e,t,t.type,t.pendingProps,r);case 19:return $f(e,t,r);case 31:return S0(e,t,r);case 22:return Af(e,t,r,t.pendingProps);case 24:return un(t),n=Ze(Ue),e===null?(a=Hl(),a===null&&(a=Ee,o=$l(),a.pooledCache=o,o.refCount++,o!==null&&(a.pooledCacheLanes|=r),a=o),t.memoizedState={parent:n,cache:a},Bl(t),Tr(t,Ue,a)):((e.lanes&r)!==0&&(Vl(e,t),Da(t,null,null,r),Oa()),a=e.memoizedState,o=t.memoizedState,a.parent!==n?(a={parent:n,cache:n},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),Tr(t,Ue,n)):(n=o.cache,Tr(t,Ue,n),n!==a.cache&&Ml(t,[Ue],r,!0))),et(e,t,t.pendingProps.children,r),t.child;case 29:throw t.pendingProps}throw Error(f(156,t.tag))}function dr(e){e.flags|=4}function _s(e,t,r,n,a){if((t=(e.mode&32)!==0)&&(t=!1),t){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if(mp())e.flags|=8192;else throw pn=Ho,ql}else e.flags&=-16777217}function Hf(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!om(t))if(mp())e.flags|=8192;else throw pn=Ho,ql}function oi(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?xu():536870912,e.lanes|=t,na|=t)}function Ha(e,t){if(!he)switch(e.tailMode){case"hidden":t=e.tail;for(var r=null;t!==null;)t.alternate!==null&&(r=t),t=t.sibling;r===null?e.tail=null:r.sibling=null;break;case"collapsed":r=e.tail;for(var n=null;r!==null;)r.alternate!==null&&(n=r),r=r.sibling;n===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:n.sibling=null}}function Pe(e){var t=e.alternate!==null&&e.alternate.child===e.child,r=0,n=0;if(t)for(var a=e.child;a!==null;)r|=a.lanes|a.childLanes,n|=a.subtreeFlags&65011712,n|=a.flags&65011712,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)r|=a.lanes|a.childLanes,n|=a.subtreeFlags,n|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=n,e.childLanes=r,t}function z0(e,t,r){var n=t.pendingProps;switch(Rl(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Pe(t),null;case 1:return Pe(t),null;case 3:return r=t.stateNode,n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),lr(Ue),Re(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(Bn(t)?dr(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,Dl())),Pe(t),null;case 26:var a=t.type,o=t.memoizedState;return e===null?(dr(t),o!==null?(Pe(t),Hf(t,o)):(Pe(t),_s(t,a,null,n,r))):o?o!==e.memoizedState?(dr(t),Pe(t),Hf(t,o)):(Pe(t),t.flags&=-16777217):(e=e.memoizedProps,e!==n&&dr(t),Pe(t),_s(t,a,e,n,r)),null;case 27:if(er(t),r=ie.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==n&&dr(t);else{if(!n){if(t.stateNode===null)throw Error(f(166));return Pe(t),null}e=H.current,Bn(t)?wd(t,e):(e=Gp(a,n,r),t.stateNode=e,dr(t))}return Pe(t),null;case 5:if(er(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==n&&dr(t);else{if(!n){if(t.stateNode===null)throw Error(f(166));return Pe(t),null}if(o=H.current,Bn(t))wd(t,o);else{var l=ki(ie.current);switch(o){case 1:o=l.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:o=l.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":o=l.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":o=l.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":o=l.createElement("div"),o.innerHTML="<script><\/script>",o=o.removeChild(o.firstChild);break;case"select":o=typeof n.is=="string"?l.createElement("select",{is:n.is}):l.createElement("select"),n.multiple?o.multiple=!0:n.size&&(o.size=n.size);break;default:o=typeof n.is=="string"?l.createElement(a,{is:n.is}):l.createElement(a)}}o[Ge]=t,o[ut]=n;e:for(l=t.child;l!==null;){if(l.tag===5||l.tag===6)o.appendChild(l.stateNode);else if(l.tag!==4&&l.tag!==27&&l.child!==null){l.child.return=l,l=l.child;continue}if(l===t)break e;for(;l.sibling===null;){if(l.return===null||l.return===t)break e;l=l.return}l.sibling.return=l.return,l=l.sibling}t.stateNode=o;e:switch(tt(o,a,n),a){case"button":case"input":case"select":case"textarea":n=!!n.autoFocus;break e;case"img":n=!0;break e;default:n=!1}n&&dr(t)}}return Pe(t),_s(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,r),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==n&&dr(t);else{if(typeof n!="string"&&t.stateNode===null)throw Error(f(166));if(e=ie.current,Bn(t)){if(e=t.stateNode,r=t.memoizedProps,n=null,a=Je,a!==null)switch(a.tag){case 27:case 5:n=a.memoizedProps}e[Ge]=t,e=!!(e.nodeValue===r||n!==null&&n.suppressHydrationWarning===!0||$p(e.nodeValue,r)),e||Nr(t,!0)}else e=ki(e).createTextNode(n),e[Ge]=t,t.stateNode=e}return Pe(t),null;case 31:if(r=t.memoizedState,e===null||e.memoizedState!==null){if(n=Bn(t),r!==null){if(e===null){if(!n)throw Error(f(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(f(557));e[Ge]=t}else sn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Pe(t),e=!1}else r=Dl(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=r),e=!0;if(!e)return t.flags&256?(St(t),t):(St(t),null);if((t.flags&128)!==0)throw Error(f(558))}return Pe(t),null;case 13:if(n=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=Bn(t),n!==null&&n.dehydrated!==null){if(e===null){if(!a)throw Error(f(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(f(317));a[Ge]=t}else sn(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Pe(t),a=!1}else a=Dl(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(St(t),t):(St(t),null)}return St(t),(t.flags&128)!==0?(t.lanes=r,t):(r=n!==null,e=e!==null&&e.memoizedState!==null,r&&(n=t.child,a=null,n.alternate!==null&&n.alternate.memoizedState!==null&&n.alternate.memoizedState.cachePool!==null&&(a=n.alternate.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==a&&(n.flags|=2048)),r!==e&&r&&(t.child.flags|=8192),oi(t,t.updateQueue),Pe(t),null);case 4:return Re(),e===null&&Ws(t.stateNode.containerInfo),Pe(t),null;case 10:return lr(t.type),Pe(t),null;case 19:if(R(Me),n=t.memoizedState,n===null)return Pe(t),null;if(a=(t.flags&128)!==0,o=n.rendering,o===null)if(a)Ha(n,!1);else{if(Fe!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(o=Wo(e),o!==null){for(t.flags|=128,Ha(n,!1),e=o.updateQueue,t.updateQueue=e,oi(t,e),t.subtreeFlags=0,e=r,r=t.child;r!==null;)gd(r,e),r=r.sibling;return F(Me,Me.current&1|2),he&&or(t,n.treeForkCount),t.child}e=e.sibling}n.tail!==null&&bt()>ui&&(t.flags|=128,a=!0,Ha(n,!1),t.lanes=4194304)}else{if(!a)if(e=Wo(o),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,oi(t,e),Ha(n,!0),n.tail===null&&n.tailMode==="hidden"&&!o.alternate&&!he)return Pe(t),null}else 2*bt()-n.renderingStartTime>ui&&r!==536870912&&(t.flags|=128,a=!0,Ha(n,!1),t.lanes=4194304);n.isBackwards?(o.sibling=t.child,t.child=o):(e=n.last,e!==null?e.sibling=o:t.child=o,n.last=o)}return n.tail!==null?(e=n.tail,n.rendering=e,n.tail=e.sibling,n.renderingStartTime=bt(),e.sibling=null,r=Me.current,F(Me,a?r&1|2:r&1),he&&or(t,n.treeForkCount),e):(Pe(t),null);case 22:case 23:return St(t),Kl(),n=t.memoizedState!==null,e!==null?e.memoizedState!==null!==n&&(t.flags|=8192):n&&(t.flags|=8192),n?(r&536870912)!==0&&(t.flags&128)===0&&(Pe(t),t.subtreeFlags&6&&(t.flags|=8192)):Pe(t),r=t.updateQueue,r!==null&&oi(t,r.retryQueue),r=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(r=e.memoizedState.cachePool.pool),n=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(n=t.memoizedState.cachePool.pool),n!==r&&(t.flags|=2048),e!==null&&R(dn),null;case 24:return r=null,e!==null&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),lr(Ue),Pe(t),null;case 25:return null;case 30:return null}throw Error(f(156,t.tag))}function _0(e,t){switch(Rl(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return lr(Ue),Re(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return er(t),null;case 31:if(t.memoizedState!==null){if(St(t),t.alternate===null)throw Error(f(340));sn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(St(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(f(340));sn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return R(Me),null;case 4:return Re(),null;case 10:return lr(t.type),null;case 22:case 23:return St(t),Kl(),e!==null&&R(dn),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return lr(Ue),null;case 25:return null;default:return null}}function qf(e,t){switch(Rl(t),t.tag){case 3:lr(Ue),Re();break;case 26:case 27:case 5:er(t);break;case 4:Re();break;case 31:t.memoizedState!==null&&St(t);break;case 13:St(t);break;case 19:R(Me);break;case 10:lr(t.type);break;case 22:case 23:St(t),Kl(),e!==null&&R(dn);break;case 24:lr(Ue)}}function qa(e,t){try{var r=t.updateQueue,n=r!==null?r.lastEffect:null;if(n!==null){var a=n.next;r=a;do{if((r.tag&e)===e){n=void 0;var o=r.create,l=r.inst;n=o(),l.destroy=n}r=r.next}while(r!==a)}}catch(d){Se(t,t.return,d)}}function Or(e,t,r){try{var n=t.updateQueue,a=n!==null?n.lastEffect:null;if(a!==null){var o=a.next;n=o;do{if((n.tag&e)===e){var l=n.inst,d=l.destroy;if(d!==void 0){l.destroy=void 0,a=t;var p=r,_=d;try{_()}catch(P){Se(a,p,P)}}}n=n.next}while(n!==o)}}catch(P){Se(t,t.return,P)}}function Bf(e){var t=e.updateQueue;if(t!==null){var r=e.stateNode;try{Ld(t,r)}catch(n){Se(e,e.return,n)}}}function Vf(e,t,r){r.props=hn(e.type,e.memoizedProps),r.state=e.memoizedState;try{r.componentWillUnmount()}catch(n){Se(e,t,n)}}function Ba(e,t){try{var r=e.ref;if(r!==null){switch(e.tag){case 26:case 27:case 5:var n=e.stateNode;break;case 30:n=e.stateNode;break;default:n=e.stateNode}typeof r=="function"?e.refCleanup=r(n):r.current=n}}catch(a){Se(e,t,a)}}function Qt(e,t){var r=e.ref,n=e.refCleanup;if(r!==null)if(typeof n=="function")try{n()}catch(a){Se(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof r=="function")try{r(null)}catch(a){Se(e,t,a)}else r.current=null}function Wf(e){var t=e.type,r=e.memoizedProps,n=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":r.autoFocus&&n.focus();break e;case"img":r.src?n.src=r.src:r.srcSet&&(n.srcset=r.srcSet)}}catch(a){Se(e,e.return,a)}}function Es(e,t,r){try{var n=e.stateNode;W0(n,e.type,r,t),n[ut]=t}catch(a){Se(e,e.return,a)}}function Yf(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Hr(e.type)||e.tag===4}function Ns(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Yf(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Hr(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ts(e,t,r){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?(r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r).insertBefore(e,t):(t=r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r,t.appendChild(e),r=r._reactRootContainer,r!=null||t.onclick!==null||(t.onclick=rr));else if(n!==4&&(n===27&&Hr(e.type)&&(r=e.stateNode,t=null),e=e.child,e!==null))for(Ts(e,t,r),e=e.sibling;e!==null;)Ts(e,t,r),e=e.sibling}function ii(e,t,r){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?r.insertBefore(e,t):r.appendChild(e);else if(n!==4&&(n===27&&Hr(e.type)&&(r=e.stateNode),e=e.child,e!==null))for(ii(e,t,r),e=e.sibling;e!==null;)ii(e,t,r),e=e.sibling}function Qf(e){var t=e.stateNode,r=e.memoizedProps;try{for(var n=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);tt(t,n,r),t[Ge]=e,t[ut]=r}catch(o){Se(e,e.return,o)}}var fr=!1,Be=!1,Ps=!1,Kf=typeof WeakSet=="function"?WeakSet:Set,Xe=null;function E0(e,t){if(e=e.containerInfo,Ks=Ti,e=id(e),Sl(e)){if("selectionStart"in e)var r={start:e.selectionStart,end:e.selectionEnd};else e:{r=(r=e.ownerDocument)&&r.defaultView||window;var n=r.getSelection&&r.getSelection();if(n&&n.rangeCount!==0){r=n.anchorNode;var a=n.anchorOffset,o=n.focusNode;n=n.focusOffset;try{r.nodeType,o.nodeType}catch{r=null;break e}var l=0,d=-1,p=-1,_=0,P=0,A=e,E=null;t:for(;;){for(var T;A!==r||a!==0&&A.nodeType!==3||(d=l+a),A!==o||n!==0&&A.nodeType!==3||(p=l+n),A.nodeType===3&&(l+=A.nodeValue.length),(T=A.firstChild)!==null;)E=A,A=T;for(;;){if(A===e)break t;if(E===r&&++_===a&&(d=l),E===o&&++P===n&&(p=l),(T=A.nextSibling)!==null)break;A=E,E=A.parentNode}A=T}r=d===-1||p===-1?null:{start:d,end:p}}else r=null}r=r||{start:0,end:0}}else r=null;for(Xs={focusedElem:e,selectionRange:r},Ti=!1,Xe=t;Xe!==null;)if(t=Xe,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,Xe=e;else for(;Xe!==null;){switch(t=Xe,o=t.alternate,e=t.flags,t.tag){case 0:if((e&4)!==0&&(e=t.updateQueue,e=e!==null?e.events:null,e!==null))for(r=0;r<e.length;r++)a=e[r],a.ref.impl=a.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&o!==null){e=void 0,r=t,a=o.memoizedProps,o=o.memoizedState,n=r.stateNode;try{var K=hn(r.type,a);e=n.getSnapshotBeforeUpdate(K,o),n.__reactInternalSnapshotBeforeUpdate=e}catch(ne){Se(r,r.return,ne)}}break;case 3:if((e&1024)!==0){if(e=t.stateNode.containerInfo,r=e.nodeType,r===9)Zs(e);else if(r===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":Zs(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(f(163))}if(e=t.sibling,e!==null){e.return=t.return,Xe=e;break}Xe=t.return}}function Xf(e,t,r){var n=r.flags;switch(r.tag){case 0:case 11:case 15:mr(e,r),n&4&&qa(5,r);break;case 1:if(mr(e,r),n&4)if(e=r.stateNode,t===null)try{e.componentDidMount()}catch(l){Se(r,r.return,l)}else{var a=hn(r.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(l){Se(r,r.return,l)}}n&64&&Bf(r),n&512&&Ba(r,r.return);break;case 3:if(mr(e,r),n&64&&(e=r.updateQueue,e!==null)){if(t=null,r.child!==null)switch(r.child.tag){case 27:case 5:t=r.child.stateNode;break;case 1:t=r.child.stateNode}try{Ld(e,t)}catch(l){Se(r,r.return,l)}}break;case 27:t===null&&n&4&&Qf(r);case 26:case 5:mr(e,r),t===null&&n&4&&Wf(r),n&512&&Ba(r,r.return);break;case 12:mr(e,r);break;case 31:mr(e,r),n&4&&Zf(e,r);break;case 13:mr(e,r),n&4&&ep(e,r),n&64&&(e=r.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(r=D0.bind(null,r),ev(e,r))));break;case 22:if(n=r.memoizedState!==null||fr,!n){t=t!==null&&t.memoizedState!==null||Be,a=fr;var o=Be;fr=n,(Be=t)&&!o?gr(e,r,(r.subtreeFlags&8772)!==0):mr(e,r),fr=a,Be=o}break;case 30:break;default:mr(e,r)}}function Gf(e){var t=e.alternate;t!==null&&(e.alternate=null,Gf(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&il(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Oe=null,ft=!1;function pr(e,t,r){for(r=r.child;r!==null;)Jf(e,t,r),r=r.sibling}function Jf(e,t,r){if(vt&&typeof vt.onCommitFiberUnmount=="function")try{vt.onCommitFiberUnmount(ga,r)}catch{}switch(r.tag){case 26:Be||Qt(r,t),pr(e,t,r),r.memoizedState?r.memoizedState.count--:r.stateNode&&(r=r.stateNode,r.parentNode.removeChild(r));break;case 27:Be||Qt(r,t);var n=Oe,a=ft;Hr(r.type)&&(Oe=r.stateNode,ft=!1),pr(e,t,r),Za(r.stateNode),Oe=n,ft=a;break;case 5:Be||Qt(r,t);case 6:if(n=Oe,a=ft,Oe=null,pr(e,t,r),Oe=n,ft=a,Oe!==null)if(ft)try{(Oe.nodeType===9?Oe.body:Oe.nodeName==="HTML"?Oe.ownerDocument.body:Oe).removeChild(r.stateNode)}catch(o){Se(r,t,o)}else try{Oe.removeChild(r.stateNode)}catch(o){Se(r,t,o)}break;case 18:Oe!==null&&(ft?(e=Oe,Wp(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,r.stateNode),da(e)):Wp(Oe,r.stateNode));break;case 4:n=Oe,a=ft,Oe=r.stateNode.containerInfo,ft=!0,pr(e,t,r),Oe=n,ft=a;break;case 0:case 11:case 14:case 15:Or(2,r,t),Be||Or(4,r,t),pr(e,t,r);break;case 1:Be||(Qt(r,t),n=r.stateNode,typeof n.componentWillUnmount=="function"&&Vf(r,t,n)),pr(e,t,r);break;case 21:pr(e,t,r);break;case 22:Be=(n=Be)||r.memoizedState!==null,pr(e,t,r),Be=n;break;default:pr(e,t,r)}}function Zf(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{da(e)}catch(r){Se(t,t.return,r)}}}function ep(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{da(e)}catch(r){Se(t,t.return,r)}}function N0(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Kf),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Kf),t;default:throw Error(f(435,e.tag))}}function li(e,t){var r=N0(e);t.forEach(function(n){if(!r.has(n)){r.add(n);var a=I0.bind(null,e,n);n.then(a,a)}})}function pt(e,t){var r=t.deletions;if(r!==null)for(var n=0;n<r.length;n++){var a=r[n],o=e,l=t,d=l;e:for(;d!==null;){switch(d.tag){case 27:if(Hr(d.type)){Oe=d.stateNode,ft=!1;break e}break;case 5:Oe=d.stateNode,ft=!1;break e;case 3:case 4:Oe=d.stateNode.containerInfo,ft=!0;break e}d=d.return}if(Oe===null)throw Error(f(160));Jf(o,l,a),Oe=null,ft=!1,o=a.alternate,o!==null&&(o.return=null),a.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)tp(t,e),t=t.sibling}var $t=null;function tp(e,t){var r=e.alternate,n=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:pt(t,e),mt(e),n&4&&(Or(3,e,e.return),qa(3,e),Or(5,e,e.return));break;case 1:pt(t,e),mt(e),n&512&&(Be||r===null||Qt(r,r.return)),n&64&&fr&&(e=e.updateQueue,e!==null&&(n=e.callbacks,n!==null&&(r=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=r===null?n:r.concat(n))));break;case 26:var a=$t;if(pt(t,e),mt(e),n&512&&(Be||r===null||Qt(r,r.return)),n&4){var o=r!==null?r.memoizedState:null;if(n=e.memoizedState,r===null)if(n===null)if(e.stateNode===null){e:{n=e.type,r=e.memoizedProps,a=a.ownerDocument||a;t:switch(n){case"title":o=a.getElementsByTagName("title")[0],(!o||o[va]||o[Ge]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(n),a.head.insertBefore(o,a.querySelector("head > title"))),tt(o,n,r),o[Ge]=e,Ke(o),n=o;break e;case"link":var l=nm("link","href",a).get(n+(r.href||""));if(l){for(var d=0;d<l.length;d++)if(o=l[d],o.getAttribute("href")===(r.href==null||r.href===""?null:r.href)&&o.getAttribute("rel")===(r.rel==null?null:r.rel)&&o.getAttribute("title")===(r.title==null?null:r.title)&&o.getAttribute("crossorigin")===(r.crossOrigin==null?null:r.crossOrigin)){l.splice(d,1);break t}}o=a.createElement(n),tt(o,n,r),a.head.appendChild(o);break;case"meta":if(l=nm("meta","content",a).get(n+(r.content||""))){for(d=0;d<l.length;d++)if(o=l[d],o.getAttribute("content")===(r.content==null?null:""+r.content)&&o.getAttribute("name")===(r.name==null?null:r.name)&&o.getAttribute("property")===(r.property==null?null:r.property)&&o.getAttribute("http-equiv")===(r.httpEquiv==null?null:r.httpEquiv)&&o.getAttribute("charset")===(r.charSet==null?null:r.charSet)){l.splice(d,1);break t}}o=a.createElement(n),tt(o,n,r),a.head.appendChild(o);break;default:throw Error(f(468,n))}o[Ge]=e,Ke(o),n=o}e.stateNode=n}else am(a,e.type,e.stateNode);else e.stateNode=rm(a,n,e.memoizedProps);else o!==n?(o===null?r.stateNode!==null&&(r=r.stateNode,r.parentNode.removeChild(r)):o.count--,n===null?am(a,e.type,e.stateNode):rm(a,n,e.memoizedProps)):n===null&&e.stateNode!==null&&Es(e,e.memoizedProps,r.memoizedProps)}break;case 27:pt(t,e),mt(e),n&512&&(Be||r===null||Qt(r,r.return)),r!==null&&n&4&&Es(e,e.memoizedProps,r.memoizedProps);break;case 5:if(pt(t,e),mt(e),n&512&&(Be||r===null||Qt(r,r.return)),e.flags&32){a=e.stateNode;try{Ln(a,"")}catch(K){Se(e,e.return,K)}}n&4&&e.stateNode!=null&&(a=e.memoizedProps,Es(e,a,r!==null?r.memoizedProps:a)),n&1024&&(Ps=!0);break;case 6:if(pt(t,e),mt(e),n&4){if(e.stateNode===null)throw Error(f(162));n=e.memoizedProps,r=e.stateNode;try{r.nodeValue=n}catch(K){Se(e,e.return,K)}}break;case 3:if(zi=null,a=$t,$t=Si(t.containerInfo),pt(t,e),$t=a,mt(e),n&4&&r!==null&&r.memoizedState.isDehydrated)try{da(t.containerInfo)}catch(K){Se(e,e.return,K)}Ps&&(Ps=!1,rp(e));break;case 4:n=$t,$t=Si(e.stateNode.containerInfo),pt(t,e),mt(e),$t=n;break;case 12:pt(t,e),mt(e);break;case 31:pt(t,e),mt(e),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,li(e,n)));break;case 13:pt(t,e),mt(e),e.child.flags&8192&&e.memoizedState!==null!=(r!==null&&r.memoizedState!==null)&&(ci=bt()),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,li(e,n)));break;case 22:a=e.memoizedState!==null;var p=r!==null&&r.memoizedState!==null,_=fr,P=Be;if(fr=_||a,Be=P||p,pt(t,e),Be=P,fr=_,mt(e),n&8192)e:for(t=e.stateNode,t._visibility=a?t._visibility&-2:t._visibility|1,a&&(r===null||p||fr||Be||bn(e)),r=null,t=e;;){if(t.tag===5||t.tag===26){if(r===null){p=r=t;try{if(o=p.stateNode,a)l=o.style,typeof l.setProperty=="function"?l.setProperty("display","none","important"):l.display="none";else{d=p.stateNode;var A=p.memoizedProps.style,E=A!=null&&A.hasOwnProperty("display")?A.display:null;d.style.display=E==null||typeof E=="boolean"?"":(""+E).trim()}}catch(K){Se(p,p.return,K)}}}else if(t.tag===6){if(r===null){p=t;try{p.stateNode.nodeValue=a?"":p.memoizedProps}catch(K){Se(p,p.return,K)}}}else if(t.tag===18){if(r===null){p=t;try{var T=p.stateNode;a?Yp(T,!0):Yp(p.stateNode,!1)}catch(K){Se(p,p.return,K)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;r===t&&(r=null),t=t.return}r===t&&(r=null),t.sibling.return=t.return,t=t.sibling}n&4&&(n=e.updateQueue,n!==null&&(r=n.retryQueue,r!==null&&(n.retryQueue=null,li(e,r))));break;case 19:pt(t,e),mt(e),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,li(e,n)));break;case 30:break;case 21:break;default:pt(t,e),mt(e)}}function mt(e){var t=e.flags;if(t&2){try{for(var r,n=e.return;n!==null;){if(Yf(n)){r=n;break}n=n.return}if(r==null)throw Error(f(160));switch(r.tag){case 27:var a=r.stateNode,o=Ns(e);ii(e,o,a);break;case 5:var l=r.stateNode;r.flags&32&&(Ln(l,""),r.flags&=-33);var d=Ns(e);ii(e,d,l);break;case 3:case 4:var p=r.stateNode.containerInfo,_=Ns(e);Ts(e,_,p);break;default:throw Error(f(161))}}catch(P){Se(e,e.return,P)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function rp(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;rp(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function mr(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Xf(e,t.alternate,t),t=t.sibling}function bn(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Or(4,t,t.return),bn(t);break;case 1:Qt(t,t.return);var r=t.stateNode;typeof r.componentWillUnmount=="function"&&Vf(t,t.return,r),bn(t);break;case 27:Za(t.stateNode);case 26:case 5:Qt(t,t.return),bn(t);break;case 22:t.memoizedState===null&&bn(t);break;case 30:bn(t);break;default:bn(t)}e=e.sibling}}function gr(e,t,r){for(r=r&&(t.subtreeFlags&8772)!==0,t=t.child;t!==null;){var n=t.alternate,a=e,o=t,l=o.flags;switch(o.tag){case 0:case 11:case 15:gr(a,o,r),qa(4,o);break;case 1:if(gr(a,o,r),n=o,a=n.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(_){Se(n,n.return,_)}if(n=o,a=n.updateQueue,a!==null){var d=n.stateNode;try{var p=a.shared.hiddenCallbacks;if(p!==null)for(a.shared.hiddenCallbacks=null,a=0;a<p.length;a++)Ad(p[a],d)}catch(_){Se(n,n.return,_)}}r&&l&64&&Bf(o),Ba(o,o.return);break;case 27:Qf(o);case 26:case 5:gr(a,o,r),r&&n===null&&l&4&&Wf(o),Ba(o,o.return);break;case 12:gr(a,o,r);break;case 31:gr(a,o,r),r&&l&4&&Zf(a,o);break;case 13:gr(a,o,r),r&&l&4&&ep(a,o);break;case 22:o.memoizedState===null&&gr(a,o,r),Ba(o,o.return);break;case 30:break;default:gr(a,o,r)}t=t.sibling}}function js(e,t){var r=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(r=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==r&&(e!=null&&e.refCount++,r!=null&&Pa(r))}function As(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Pa(e))}function Ut(e,t,r,n){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)np(e,t,r,n),t=t.sibling}function np(e,t,r,n){var a=t.flags;switch(t.tag){case 0:case 11:case 15:Ut(e,t,r,n),a&2048&&qa(9,t);break;case 1:Ut(e,t,r,n);break;case 3:Ut(e,t,r,n),a&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Pa(e)));break;case 12:if(a&2048){Ut(e,t,r,n),e=t.stateNode;try{var o=t.memoizedProps,l=o.id,d=o.onPostCommit;typeof d=="function"&&d(l,t.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(p){Se(t,t.return,p)}}else Ut(e,t,r,n);break;case 31:Ut(e,t,r,n);break;case 13:Ut(e,t,r,n);break;case 23:break;case 22:o=t.stateNode,l=t.alternate,t.memoizedState!==null?o._visibility&2?Ut(e,t,r,n):Va(e,t):o._visibility&2?Ut(e,t,r,n):(o._visibility|=2,ea(e,t,r,n,(t.subtreeFlags&10256)!==0||!1)),a&2048&&js(l,t);break;case 24:Ut(e,t,r,n),a&2048&&As(t.alternate,t);break;default:Ut(e,t,r,n)}}function ea(e,t,r,n,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var o=e,l=t,d=r,p=n,_=l.flags;switch(l.tag){case 0:case 11:case 15:ea(o,l,d,p,a),qa(8,l);break;case 23:break;case 22:var P=l.stateNode;l.memoizedState!==null?P._visibility&2?ea(o,l,d,p,a):Va(o,l):(P._visibility|=2,ea(o,l,d,p,a)),a&&_&2048&&js(l.alternate,l);break;case 24:ea(o,l,d,p,a),a&&_&2048&&As(l.alternate,l);break;default:ea(o,l,d,p,a)}t=t.sibling}}function Va(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var r=e,n=t,a=n.flags;switch(n.tag){case 22:Va(r,n),a&2048&&js(n.alternate,n);break;case 24:Va(r,n),a&2048&&As(n.alternate,n);break;default:Va(r,n)}t=t.sibling}}var Wa=8192;function ta(e,t,r){if(e.subtreeFlags&Wa)for(e=e.child;e!==null;)ap(e,t,r),e=e.sibling}function ap(e,t,r){switch(e.tag){case 26:ta(e,t,r),e.flags&Wa&&e.memoizedState!==null&&fv(r,$t,e.memoizedState,e.memoizedProps);break;case 5:ta(e,t,r);break;case 3:case 4:var n=$t;$t=Si(e.stateNode.containerInfo),ta(e,t,r),$t=n;break;case 22:e.memoizedState===null&&(n=e.alternate,n!==null&&n.memoizedState!==null?(n=Wa,Wa=16777216,ta(e,t,r),Wa=n):ta(e,t,r));break;default:ta(e,t,r)}}function op(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Ya(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var r=0;r<t.length;r++){var n=t[r];Xe=n,lp(n,e)}op(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)ip(e),e=e.sibling}function ip(e){switch(e.tag){case 0:case 11:case 15:Ya(e),e.flags&2048&&Or(9,e,e.return);break;case 3:Ya(e);break;case 12:Ya(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,si(e)):Ya(e);break;default:Ya(e)}}function si(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var r=0;r<t.length;r++){var n=t[r];Xe=n,lp(n,e)}op(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Or(8,t,t.return),si(t);break;case 22:r=t.stateNode,r._visibility&2&&(r._visibility&=-3,si(t));break;default:si(t)}e=e.sibling}}function lp(e,t){for(;Xe!==null;){var r=Xe;switch(r.tag){case 0:case 11:case 15:Or(8,r,t);break;case 23:case 22:if(r.memoizedState!==null&&r.memoizedState.cachePool!==null){var n=r.memoizedState.cachePool.pool;n!=null&&n.refCount++}break;case 24:Pa(r.memoizedState.cache)}if(n=r.child,n!==null)n.return=r,Xe=n;else e:for(r=e;Xe!==null;){n=Xe;var a=n.sibling,o=n.return;if(Gf(n),n===r){Xe=null;break e}if(a!==null){a.return=o,Xe=a;break e}Xe=o}}}var T0={getCacheForType:function(e){var t=Ze(Ue),r=t.data.get(e);return r===void 0&&(r=e(),t.data.set(e,r)),r},cacheSignal:function(){return Ze(Ue).controller.signal}},P0=typeof WeakMap=="function"?WeakMap:Map,xe=0,Ee=null,de=null,pe=0,ke=0,Ct=null,Dr=!1,ra=!1,Ls=!1,hr=0,Fe=0,Ir=0,vn=0,Rs=0,zt=0,na=0,Qa=null,gt=null,Os=!1,ci=0,sp=0,ui=1/0,di=null,Fr=null,We=0,Mr=null,aa=null,br=0,Ds=0,Is=null,cp=null,Ka=0,Fs=null;function _t(){return(xe&2)!==0&&pe!==0?pe&-pe:O.T!==null?Bs():zu()}function up(){if(zt===0)if((pe&536870912)===0||he){var e=vo;vo<<=1,(vo&3932160)===0&&(vo=262144),zt=e}else zt=536870912;return e=kt.current,e!==null&&(e.flags|=32),zt}function ht(e,t,r){(e===Ee&&(ke===2||ke===9)||e.cancelPendingCommit!==null)&&(oa(e,0),$r(e,pe,zt,!1)),ba(e,r),((xe&2)===0||e!==Ee)&&(e===Ee&&((xe&2)===0&&(vn|=r),Fe===4&&$r(e,pe,zt,!1)),Kt(e))}function dp(e,t,r){if((xe&6)!==0)throw Error(f(327));var n=!r&&(t&127)===0&&(t&e.expiredLanes)===0||ha(e,t),a=n?L0(e,t):$s(e,t,!0),o=n;do{if(a===0){ra&&!n&&$r(e,t,0,!1);break}else{if(r=e.current.alternate,o&&!j0(r)){a=$s(e,t,!1),o=!1;continue}if(a===2){if(o=t,e.errorRecoveryDisabledLanes&o)var l=0;else l=e.pendingLanes&-536870913,l=l!==0?l:l&536870912?536870912:0;if(l!==0){t=l;e:{var d=e;a=Qa;var p=d.current.memoizedState.isDehydrated;if(p&&(oa(d,l).flags|=256),l=$s(d,l,!1),l!==2){if(Ls&&!p){d.errorRecoveryDisabledLanes|=o,vn|=o,a=4;break e}o=gt,gt=a,o!==null&&(gt===null?gt=o:gt.push.apply(gt,o))}a=l}if(o=!1,a!==2)continue}}if(a===1){oa(e,0),$r(e,t,0,!0);break}e:{switch(n=e,o=a,o){case 0:case 1:throw Error(f(345));case 4:if((t&4194048)!==t)break;case 6:$r(n,t,zt,!Dr);break e;case 2:gt=null;break;case 3:case 5:break;default:throw Error(f(329))}if((t&62914560)===t&&(a=ci+300-bt(),10<a)){if($r(n,t,zt,!Dr),wo(n,0,!0)!==0)break e;br=t,n.timeoutHandle=Bp(fp.bind(null,n,r,gt,di,Os,t,zt,vn,na,Dr,o,"Throttled",-0,0),a);break e}fp(n,r,gt,di,Os,t,zt,vn,na,Dr,o,null,-0,0)}}break}while(!0);Kt(e)}function fp(e,t,r,n,a,o,l,d,p,_,P,A,E,T){if(e.timeoutHandle=-1,A=t.subtreeFlags,A&8192||(A&16785408)===16785408){A={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:rr},ap(t,o,A);var K=(o&62914560)===o?ci-bt():(o&4194048)===o?sp-bt():0;if(K=pv(A,K),K!==null){br=o,e.cancelPendingCommit=K(wp.bind(null,e,t,o,r,n,a,l,d,p,P,A,null,E,T)),$r(e,o,l,!_);return}}wp(e,t,o,r,n,a,l,d,p)}function j0(e){for(var t=e;;){var r=t.tag;if((r===0||r===11||r===15)&&t.flags&16384&&(r=t.updateQueue,r!==null&&(r=r.stores,r!==null)))for(var n=0;n<r.length;n++){var a=r[n],o=a.getSnapshot;a=a.value;try{if(!wt(o(),a))return!1}catch{return!1}}if(r=t.child,t.subtreeFlags&16384&&r!==null)r.return=t,t=r;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function $r(e,t,r,n){t&=~Rs,t&=~vn,e.suspendedLanes|=t,e.pingedLanes&=~t,n&&(e.warmLanes|=t),n=e.expirationTimes;for(var a=t;0<a;){var o=31-yt(a),l=1<<o;n[o]=-1,a&=~l}r!==0&&ku(e,r,t)}function fi(){return(xe&6)===0?(Xa(0,!1),!1):!0}function Ms(){if(de!==null){if(ke===0)var e=de.return;else e=de,ir=cn=null,ts(e),Kn=null,Aa=0,e=de;for(;e!==null;)qf(e.alternate,e),e=e.return;de=null}}function oa(e,t){var r=e.timeoutHandle;r!==-1&&(e.timeoutHandle=-1,K0(r)),r=e.cancelPendingCommit,r!==null&&(e.cancelPendingCommit=null,r()),br=0,Ms(),Ee=e,de=r=ar(e.current,null),pe=t,ke=0,Ct=null,Dr=!1,ra=ha(e,t),Ls=!1,na=zt=Rs=vn=Ir=Fe=0,gt=Qa=null,Os=!1,(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var a=31-yt(n),o=1<<a;t|=e[a],n&=~o}return hr=t,Lo(),r}function pp(e,t){le=null,O.H=$a,t===Qn||t===Uo?(t=Nd(),ke=3):t===ql?(t=Nd(),ke=4):ke=t===bs?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Ct=t,de===null&&(Fe=1,ti(e,Pt(t,e.current)))}function mp(){var e=kt.current;return e===null?!0:(pe&4194048)===pe?Mt===null:(pe&62914560)===pe||(pe&536870912)!==0?e===Mt:!1}function gp(){var e=O.H;return O.H=$a,e===null?$a:e}function hp(){var e=O.A;return O.A=T0,e}function pi(){Fe=4,Dr||(pe&4194048)!==pe&&kt.current!==null||(ra=!0),(Ir&134217727)===0&&(vn&134217727)===0||Ee===null||$r(Ee,pe,zt,!1)}function $s(e,t,r){var n=xe;xe|=2;var a=gp(),o=hp();(Ee!==e||pe!==t)&&(di=null,oa(e,t)),t=!1;var l=Fe;e:do try{if(ke!==0&&de!==null){var d=de,p=Ct;switch(ke){case 8:Ms(),l=6;break e;case 3:case 2:case 9:case 6:kt.current===null&&(t=!0);var _=ke;if(ke=0,Ct=null,ia(e,d,p,_),r&&ra){l=0;break e}break;default:_=ke,ke=0,Ct=null,ia(e,d,p,_)}}A0(),l=Fe;break}catch(P){pp(e,P)}while(!0);return t&&e.shellSuspendCounter++,ir=cn=null,xe=n,O.H=a,O.A=o,de===null&&(Ee=null,pe=0,Lo()),l}function A0(){for(;de!==null;)bp(de)}function L0(e,t){var r=xe;xe|=2;var n=gp(),a=hp();Ee!==e||pe!==t?(di=null,ui=bt()+500,oa(e,t)):ra=ha(e,t);e:do try{if(ke!==0&&de!==null){t=de;var o=Ct;t:switch(ke){case 1:ke=0,Ct=null,ia(e,t,o,1);break;case 2:case 9:if(_d(o)){ke=0,Ct=null,vp(t);break}t=function(){ke!==2&&ke!==9||Ee!==e||(ke=7),Kt(e)},o.then(t,t);break e;case 3:ke=7;break e;case 4:ke=5;break e;case 7:_d(o)?(ke=0,Ct=null,vp(t)):(ke=0,Ct=null,ia(e,t,o,7));break;case 5:var l=null;switch(de.tag){case 26:l=de.memoizedState;case 5:case 27:var d=de;if(l?om(l):d.stateNode.complete){ke=0,Ct=null;var p=d.sibling;if(p!==null)de=p;else{var _=d.return;_!==null?(de=_,mi(_)):de=null}break t}}ke=0,Ct=null,ia(e,t,o,5);break;case 6:ke=0,Ct=null,ia(e,t,o,6);break;case 8:Ms(),Fe=6;break e;default:throw Error(f(462))}}R0();break}catch(P){pp(e,P)}while(!0);return ir=cn=null,O.H=n,O.A=a,xe=r,de!==null?0:(Ee=null,pe=0,Lo(),Fe)}function R0(){for(;de!==null&&!nb();)bp(de)}function bp(e){var t=Uf(e.alternate,e,hr);e.memoizedProps=e.pendingProps,t===null?mi(e):de=t}function vp(e){var t=e,r=t.alternate;switch(t.tag){case 15:case 0:t=Of(r,t,t.pendingProps,t.type,void 0,pe);break;case 11:t=Of(r,t,t.pendingProps,t.type.render,t.ref,pe);break;case 5:ts(t);default:qf(r,t),t=de=gd(t,hr),t=Uf(r,t,hr)}e.memoizedProps=e.pendingProps,t===null?mi(e):de=t}function ia(e,t,r,n){ir=cn=null,ts(t),Kn=null,Aa=0;var a=t.return;try{if(k0(e,a,t,r,pe)){Fe=1,ti(e,Pt(r,e.current)),de=null;return}}catch(o){if(a!==null)throw de=a,o;Fe=1,ti(e,Pt(r,e.current)),de=null;return}t.flags&32768?(he||n===1?e=!0:ra||(pe&536870912)!==0?e=!1:(Dr=e=!0,(n===2||n===9||n===3||n===6)&&(n=kt.current,n!==null&&n.tag===13&&(n.flags|=16384))),yp(t,e)):mi(t)}function mi(e){var t=e;do{if((t.flags&32768)!==0){yp(t,Dr);return}e=t.return;var r=z0(t.alternate,t,hr);if(r!==null){de=r;return}if(t=t.sibling,t!==null){de=t;return}de=t=e}while(t!==null);Fe===0&&(Fe=5)}function yp(e,t){do{var r=_0(e.alternate,e);if(r!==null){r.flags&=32767,de=r;return}if(r=e.return,r!==null&&(r.flags|=32768,r.subtreeFlags=0,r.deletions=null),!t&&(e=e.sibling,e!==null)){de=e;return}de=e=r}while(e!==null);Fe=6,de=null}function wp(e,t,r,n,a,o,l,d,p){e.cancelPendingCommit=null;do gi();while(We!==0);if((xe&6)!==0)throw Error(f(327));if(t!==null){if(t===e.current)throw Error(f(177));if(o=t.lanes|t.childLanes,o|=Nl,pb(e,r,o,l,d,p),e===Ee&&(de=Ee=null,pe=0),aa=t,Mr=e,br=r,Ds=o,Is=a,cp=n,(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,F0(ho,function(){return zp(),null})):(e.callbackNode=null,e.callbackPriority=0),n=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||n){n=O.T,O.T=null,a=M.p,M.p=2,l=xe,xe|=4;try{E0(e,t,r)}finally{xe=l,M.p=a,O.T=n}}We=1,xp(),kp(),Sp()}}function xp(){if(We===1){We=0;var e=Mr,t=aa,r=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||r){r=O.T,O.T=null;var n=M.p;M.p=2;var a=xe;xe|=4;try{tp(t,e);var o=Xs,l=id(e.containerInfo),d=o.focusedElem,p=o.selectionRange;if(l!==d&&d&&d.ownerDocument&&od(d.ownerDocument.documentElement,d)){if(p!==null&&Sl(d)){var _=p.start,P=p.end;if(P===void 0&&(P=_),"selectionStart"in d)d.selectionStart=_,d.selectionEnd=Math.min(P,d.value.length);else{var A=d.ownerDocument||document,E=A&&A.defaultView||window;if(E.getSelection){var T=E.getSelection(),K=d.textContent.length,ne=Math.min(p.start,K),_e=p.end===void 0?ne:Math.min(p.end,K);!T.extend&&ne>_e&&(l=_e,_e=ne,ne=l);var v=ad(d,ne),m=ad(d,_e);if(v&&m&&(T.rangeCount!==1||T.anchorNode!==v.node||T.anchorOffset!==v.offset||T.focusNode!==m.node||T.focusOffset!==m.offset)){var z=A.createRange();z.setStart(v.node,v.offset),T.removeAllRanges(),ne>_e?(T.addRange(z),T.extend(m.node,m.offset)):(z.setEnd(m.node,m.offset),T.addRange(z))}}}}for(A=[],T=d;T=T.parentNode;)T.nodeType===1&&A.push({element:T,left:T.scrollLeft,top:T.scrollTop});for(typeof d.focus=="function"&&d.focus(),d=0;d<A.length;d++){var j=A[d];j.element.scrollLeft=j.left,j.element.scrollTop=j.top}}Ti=!!Ks,Xs=Ks=null}finally{xe=a,M.p=n,O.T=r}}e.current=t,We=2}}function kp(){if(We===2){We=0;var e=Mr,t=aa,r=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||r){r=O.T,O.T=null;var n=M.p;M.p=2;var a=xe;xe|=4;try{Xf(e,t.alternate,t)}finally{xe=a,M.p=n,O.T=r}}We=3}}function Sp(){if(We===4||We===3){We=0,ab();var e=Mr,t=aa,r=br,n=cp;(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?We=5:(We=0,aa=Mr=null,Cp(e,e.pendingLanes));var a=e.pendingLanes;if(a===0&&(Fr=null),al(r),t=t.stateNode,vt&&typeof vt.onCommitFiberRoot=="function")try{vt.onCommitFiberRoot(ga,t,void 0,(t.current.flags&128)===128)}catch{}if(n!==null){t=O.T,a=M.p,M.p=2,O.T=null;try{for(var o=e.onRecoverableError,l=0;l<n.length;l++){var d=n[l];o(d.value,{componentStack:d.stack})}}finally{O.T=t,M.p=a}}(br&3)!==0&&gi(),Kt(e),a=e.pendingLanes,(r&261930)!==0&&(a&42)!==0?e===Fs?Ka++:(Ka=0,Fs=e):Ka=0,Xa(0,!1)}}function Cp(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Pa(t)))}function gi(){return xp(),kp(),Sp(),zp()}function zp(){if(We!==5)return!1;var e=Mr,t=Ds;Ds=0;var r=al(br),n=O.T,a=M.p;try{M.p=32>r?32:r,O.T=null,r=Is,Is=null;var o=Mr,l=br;if(We=0,aa=Mr=null,br=0,(xe&6)!==0)throw Error(f(331));var d=xe;if(xe|=4,ip(o.current),np(o,o.current,l,r),xe=d,Xa(0,!1),vt&&typeof vt.onPostCommitFiberRoot=="function")try{vt.onPostCommitFiberRoot(ga,o)}catch{}return!0}finally{M.p=a,O.T=n,Cp(e,t)}}function _p(e,t,r){t=Pt(r,t),t=hs(e.stateNode,t,2),e=Ar(e,t,2),e!==null&&(ba(e,2),Kt(e))}function Se(e,t,r){if(e.tag===3)_p(e,e,r);else for(;t!==null;){if(t.tag===3){_p(t,e,r);break}else if(t.tag===1){var n=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof n.componentDidCatch=="function"&&(Fr===null||!Fr.has(n))){e=Pt(r,e),r=Ef(2),n=Ar(t,r,2),n!==null&&(Nf(r,n,t,e),ba(n,2),Kt(n));break}}t=t.return}}function Us(e,t,r){var n=e.pingCache;if(n===null){n=e.pingCache=new P0;var a=new Set;n.set(t,a)}else a=n.get(t),a===void 0&&(a=new Set,n.set(t,a));a.has(r)||(Ls=!0,a.add(r),e=O0.bind(null,e,t,r),t.then(e,e))}function O0(e,t,r){var n=e.pingCache;n!==null&&n.delete(t),e.pingedLanes|=e.suspendedLanes&r,e.warmLanes&=~r,Ee===e&&(pe&r)===r&&(Fe===4||Fe===3&&(pe&62914560)===pe&&300>bt()-ci?(xe&2)===0&&oa(e,0):Rs|=r,na===pe&&(na=0)),Kt(e)}function Ep(e,t){t===0&&(t=xu()),e=on(e,t),e!==null&&(ba(e,t),Kt(e))}function D0(e){var t=e.memoizedState,r=0;t!==null&&(r=t.retryLane),Ep(e,r)}function I0(e,t){var r=0;switch(e.tag){case 31:case 13:var n=e.stateNode,a=e.memoizedState;a!==null&&(r=a.retryLane);break;case 19:n=e.stateNode;break;case 22:n=e.stateNode._retryCache;break;default:throw Error(f(314))}n!==null&&n.delete(t),Ep(e,r)}function F0(e,t){return el(e,t)}var hi=null,la=null,Hs=!1,bi=!1,qs=!1,Ur=0;function Kt(e){e!==la&&e.next===null&&(la===null?hi=la=e:la=la.next=e),bi=!0,Hs||(Hs=!0,$0())}function Xa(e,t){if(!qs&&bi){qs=!0;do for(var r=!1,n=hi;n!==null;){if(!t)if(e!==0){var a=n.pendingLanes;if(a===0)var o=0;else{var l=n.suspendedLanes,d=n.pingedLanes;o=(1<<31-yt(42|e)+1)-1,o&=a&~(l&~d),o=o&201326741?o&201326741|1:o?o|2:0}o!==0&&(r=!0,jp(n,o))}else o=pe,o=wo(n,n===Ee?o:0,n.cancelPendingCommit!==null||n.timeoutHandle!==-1),(o&3)===0||ha(n,o)||(r=!0,jp(n,o));n=n.next}while(r);qs=!1}}function M0(){Np()}function Np(){bi=Hs=!1;var e=0;Ur!==0&&Q0()&&(e=Ur);for(var t=bt(),r=null,n=hi;n!==null;){var a=n.next,o=Tp(n,t);o===0?(n.next=null,r===null?hi=a:r.next=a,a===null&&(la=r)):(r=n,(e!==0||(o&3)!==0)&&(bi=!0)),n=a}We!==0&&We!==5||Xa(e,!1),Ur!==0&&(Ur=0)}function Tp(e,t){for(var r=e.suspendedLanes,n=e.pingedLanes,a=e.expirationTimes,o=e.pendingLanes&-62914561;0<o;){var l=31-yt(o),d=1<<l,p=a[l];p===-1?((d&r)===0||(d&n)!==0)&&(a[l]=fb(d,t)):p<=t&&(e.expiredLanes|=d),o&=~d}if(t=Ee,r=pe,r=wo(e,e===t?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),n=e.callbackNode,r===0||e===t&&(ke===2||ke===9)||e.cancelPendingCommit!==null)return n!==null&&n!==null&&tl(n),e.callbackNode=null,e.callbackPriority=0;if((r&3)===0||ha(e,r)){if(t=r&-r,t===e.callbackPriority)return t;switch(n!==null&&tl(n),al(r)){case 2:case 8:r=yu;break;case 32:r=ho;break;case 268435456:r=wu;break;default:r=ho}return n=Pp.bind(null,e),r=el(r,n),e.callbackPriority=t,e.callbackNode=r,t}return n!==null&&n!==null&&tl(n),e.callbackPriority=2,e.callbackNode=null,2}function Pp(e,t){if(We!==0&&We!==5)return e.callbackNode=null,e.callbackPriority=0,null;var r=e.callbackNode;if(gi()&&e.callbackNode!==r)return null;var n=pe;return n=wo(e,e===Ee?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),n===0?null:(dp(e,n,t),Tp(e,bt()),e.callbackNode!=null&&e.callbackNode===r?Pp.bind(null,e):null)}function jp(e,t){if(gi())return null;dp(e,t,!0)}function $0(){X0(function(){(xe&6)!==0?el(vu,M0):Np()})}function Bs(){if(Ur===0){var e=Wn;e===0&&(e=bo,bo<<=1,(bo&261888)===0&&(bo=256)),Ur=e}return Ur}function Ap(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Co(""+e)}function Lp(e,t){var r=t.ownerDocument.createElement("input");return r.name=t.name,r.value=t.value,e.id&&r.setAttribute("form",e.id),t.parentNode.insertBefore(r,t),e=new FormData(e),r.parentNode.removeChild(r),e}function U0(e,t,r,n,a){if(t==="submit"&&r&&r.stateNode===a){var o=Ap((a[ut]||null).action),l=n.submitter;l&&(t=(t=l[ut]||null)?Ap(t.formAction):l.getAttribute("formAction"),t!==null&&(o=t,l=null));var d=new No("action","action",null,n,a);e.push({event:d,listeners:[{instance:null,listener:function(){if(n.defaultPrevented){if(Ur!==0){var p=l?Lp(a,l):new FormData(a);us(r,{pending:!0,data:p,method:a.method,action:o},null,p)}}else typeof o=="function"&&(d.preventDefault(),p=l?Lp(a,l):new FormData(a),us(r,{pending:!0,data:p,method:a.method,action:o},o,p))},currentTarget:a}]})}}for(yi=0;yi<El.length;yi++)vi=El[yi],Rp=vi.toLowerCase(),Op=vi[0].toUpperCase()+vi.slice(1),Ft(Rp,"on"+Op);var vi,Rp,Op,yi;Ft(cd,"onAnimationEnd"),Ft(ud,"onAnimationIteration"),Ft(dd,"onAnimationStart"),Ft("dblclick","onDoubleClick"),Ft("focusin","onFocus"),Ft("focusout","onBlur"),Ft(o0,"onTransitionRun"),Ft(i0,"onTransitionStart"),Ft(l0,"onTransitionCancel"),Ft(fd,"onTransitionEnd"),jn("onMouseEnter",["mouseout","mouseover"]),jn("onMouseLeave",["mouseout","mouseover"]),jn("onPointerEnter",["pointerout","pointerover"]),jn("onPointerLeave",["pointerout","pointerover"]),tn("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),tn("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),tn("onBeforeInput",["compositionend","keypress","textInput","paste"]),tn("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),tn("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),tn("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ga="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),H0=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ga));function Dp(e,t){t=(t&4)!==0;for(var r=0;r<e.length;r++){var n=e[r],a=n.event;n=n.listeners;e:{var o=void 0;if(t)for(var l=n.length-1;0<=l;l--){var d=n[l],p=d.instance,_=d.currentTarget;if(d=d.listener,p!==o&&a.isPropagationStopped())break e;o=d,a.currentTarget=_;try{o(a)}catch(P){Ao(P)}a.currentTarget=null,o=p}else for(l=0;l<n.length;l++){if(d=n[l],p=d.instance,_=d.currentTarget,d=d.listener,p!==o&&a.isPropagationStopped())break e;o=d,a.currentTarget=_;try{o(a)}catch(P){Ao(P)}a.currentTarget=null,o=p}}}}function fe(e,t){var r=t[ol];r===void 0&&(r=t[ol]=new Set);var n=e+"__bubble";r.has(n)||(Ip(t,e,2,!1),r.add(n))}function Vs(e,t,r){var n=0;t&&(n|=4),Ip(r,e,n,t)}var wi="_reactListening"+Math.random().toString(36).slice(2);function Ws(e){if(!e[wi]){e[wi]=!0,Nu.forEach(function(r){r!=="selectionchange"&&(H0.has(r)||Vs(r,!1,e),Vs(r,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[wi]||(t[wi]=!0,Vs("selectionchange",!1,t))}}function Ip(e,t,r,n){switch(fm(t)){case 2:var a=hv;break;case 8:a=bv;break;default:a=lc}r=a.bind(null,t,r,e),a=void 0,!ml||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),n?a!==void 0?e.addEventListener(t,r,{capture:!0,passive:a}):e.addEventListener(t,r,!0):a!==void 0?e.addEventListener(t,r,{passive:a}):e.addEventListener(t,r,!1)}function Ys(e,t,r,n,a){var o=n;if((t&1)===0&&(t&2)===0&&n!==null)e:for(;;){if(n===null)return;var l=n.tag;if(l===3||l===4){var d=n.stateNode.containerInfo;if(d===a)break;if(l===4)for(l=n.return;l!==null;){var p=l.tag;if((p===3||p===4)&&l.stateNode.containerInfo===a)return;l=l.return}for(;d!==null;){if(l=Nn(d),l===null)return;if(p=l.tag,p===5||p===6||p===26||p===27){n=o=l;continue e}d=d.parentNode}}n=n.return}$u(function(){var _=o,P=fl(r),A=[];e:{var E=pd.get(e);if(E!==void 0){var T=No,K=e;switch(e){case"keypress":if(_o(r)===0)break e;case"keydown":case"keyup":T=Ib;break;case"focusin":K="focus",T=vl;break;case"focusout":K="blur",T=vl;break;case"beforeblur":case"afterblur":T=vl;break;case"click":if(r.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":T=qu;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":T=zb;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":T=$b;break;case cd:case ud:case dd:T=Nb;break;case fd:T=Hb;break;case"scroll":case"scrollend":T=Sb;break;case"wheel":T=Bb;break;case"copy":case"cut":case"paste":T=Pb;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":T=Vu;break;case"toggle":case"beforetoggle":T=Wb}var ne=(t&4)!==0,_e=!ne&&(e==="scroll"||e==="scrollend"),v=ne?E!==null?E+"Capture":null:E;ne=[];for(var m=_,z;m!==null;){var j=m;if(z=j.stateNode,j=j.tag,j!==5&&j!==26&&j!==27||z===null||v===null||(j=wa(m,v),j!=null&&ne.push(Ja(m,j,z))),_e)break;m=m.return}0<ne.length&&(E=new T(E,K,null,r,P),A.push({event:E,listeners:ne}))}}if((t&7)===0){e:{if(E=e==="mouseover"||e==="pointerover",T=e==="mouseout"||e==="pointerout",E&&r!==dl&&(K=r.relatedTarget||r.fromElement)&&(Nn(K)||K[En]))break e;if((T||E)&&(E=P.window===P?P:(E=P.ownerDocument)?E.defaultView||E.parentWindow:window,T?(K=r.relatedTarget||r.toElement,T=_,K=K?Nn(K):null,K!==null&&(_e=h(K),ne=K.tag,K!==_e||ne!==5&&ne!==27&&ne!==6)&&(K=null)):(T=null,K=_),T!==K)){if(ne=qu,j="onMouseLeave",v="onMouseEnter",m="mouse",(e==="pointerout"||e==="pointerover")&&(ne=Vu,j="onPointerLeave",v="onPointerEnter",m="pointer"),_e=T==null?E:ya(T),z=K==null?E:ya(K),E=new ne(j,m+"leave",T,r,P),E.target=_e,E.relatedTarget=z,j=null,Nn(P)===_&&(ne=new ne(v,m+"enter",K,r,P),ne.target=z,ne.relatedTarget=_e,j=ne),_e=j,T&&K)t:{for(ne=q0,v=T,m=K,z=0,j=v;j;j=ne(j))z++;j=0;for(var Z=m;Z;Z=ne(Z))j++;for(;0<z-j;)v=ne(v),z--;for(;0<j-z;)m=ne(m),j--;for(;z--;){if(v===m||m!==null&&v===m.alternate){ne=v;break t}v=ne(v),m=ne(m)}ne=null}else ne=null;T!==null&&Fp(A,E,T,ne,!1),K!==null&&_e!==null&&Fp(A,_e,K,ne,!0)}}e:{if(E=_?ya(_):window,T=E.nodeName&&E.nodeName.toLowerCase(),T==="select"||T==="input"&&E.type==="file")var ye=Zu;else if(Gu(E))if(ed)ye=r0;else{ye=e0;var J=Zb}else T=E.nodeName,!T||T.toLowerCase()!=="input"||E.type!=="checkbox"&&E.type!=="radio"?_&&ul(_.elementType)&&(ye=Zu):ye=t0;if(ye&&(ye=ye(e,_))){Ju(A,ye,r,P);break e}J&&J(e,E,_),e==="focusout"&&_&&E.type==="number"&&_.memoizedProps.value!=null&&cl(E,"number",E.value)}switch(J=_?ya(_):window,e){case"focusin":(Gu(J)||J.contentEditable==="true")&&(Fn=J,Cl=_,Ea=null);break;case"focusout":Ea=Cl=Fn=null;break;case"mousedown":zl=!0;break;case"contextmenu":case"mouseup":case"dragend":zl=!1,ld(A,r,P);break;case"selectionchange":if(a0)break;case"keydown":case"keyup":ld(A,r,P)}var se;if(wl)e:{switch(e){case"compositionstart":var me="onCompositionStart";break e;case"compositionend":me="onCompositionEnd";break e;case"compositionupdate":me="onCompositionUpdate";break e}me=void 0}else In?Ku(e,r)&&(me="onCompositionEnd"):e==="keydown"&&r.keyCode===229&&(me="onCompositionStart");me&&(Wu&&r.locale!=="ko"&&(In||me!=="onCompositionStart"?me==="onCompositionEnd"&&In&&(se=Uu()):(zr=P,gl="value"in zr?zr.value:zr.textContent,In=!0)),J=xi(_,me),0<J.length&&(me=new Bu(me,e,null,r,P),A.push({event:me,listeners:J}),se?me.data=se:(se=Xu(r),se!==null&&(me.data=se)))),(se=Qb?Kb(e,r):Xb(e,r))&&(me=xi(_,"onBeforeInput"),0<me.length&&(J=new Bu("onBeforeInput","beforeinput",null,r,P),A.push({event:J,listeners:me}),J.data=se)),U0(A,e,_,r,P)}Dp(A,t)})}function Ja(e,t,r){return{instance:e,listener:t,currentTarget:r}}function xi(e,t){for(var r=t+"Capture",n=[];e!==null;){var a=e,o=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||o===null||(a=wa(e,r),a!=null&&n.unshift(Ja(e,a,o)),a=wa(e,t),a!=null&&n.push(Ja(e,a,o))),e.tag===3)return n;e=e.return}return[]}function q0(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Fp(e,t,r,n,a){for(var o=t._reactName,l=[];r!==null&&r!==n;){var d=r,p=d.alternate,_=d.stateNode;if(d=d.tag,p!==null&&p===n)break;d!==5&&d!==26&&d!==27||_===null||(p=_,a?(_=wa(r,o),_!=null&&l.unshift(Ja(r,_,p))):a||(_=wa(r,o),_!=null&&l.push(Ja(r,_,p)))),r=r.return}l.length!==0&&e.push({event:t,listeners:l})}var B0=/\r\n?/g,V0=/\u0000|\uFFFD/g;function Mp(e){return(typeof e=="string"?e:""+e).replace(B0,`
`).replace(V0,"")}function $p(e,t){return t=Mp(t),Mp(e)===t}function ze(e,t,r,n,a,o){switch(r){case"children":typeof n=="string"?t==="body"||t==="textarea"&&n===""||Ln(e,n):(typeof n=="number"||typeof n=="bigint")&&t!=="body"&&Ln(e,""+n);break;case"className":ko(e,"class",n);break;case"tabIndex":ko(e,"tabindex",n);break;case"dir":case"role":case"viewBox":case"width":case"height":ko(e,r,n);break;case"style":Fu(e,n,o);break;case"data":if(t!=="object"){ko(e,"data",n);break}case"src":case"href":if(n===""&&(t!=="a"||r!=="href")){e.removeAttribute(r);break}if(n==null||typeof n=="function"||typeof n=="symbol"||typeof n=="boolean"){e.removeAttribute(r);break}n=Co(""+n),e.setAttribute(r,n);break;case"action":case"formAction":if(typeof n=="function"){e.setAttribute(r,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof o=="function"&&(r==="formAction"?(t!=="input"&&ze(e,t,"name",a.name,a,null),ze(e,t,"formEncType",a.formEncType,a,null),ze(e,t,"formMethod",a.formMethod,a,null),ze(e,t,"formTarget",a.formTarget,a,null)):(ze(e,t,"encType",a.encType,a,null),ze(e,t,"method",a.method,a,null),ze(e,t,"target",a.target,a,null)));if(n==null||typeof n=="symbol"||typeof n=="boolean"){e.removeAttribute(r);break}n=Co(""+n),e.setAttribute(r,n);break;case"onClick":n!=null&&(e.onclick=rr);break;case"onScroll":n!=null&&fe("scroll",e);break;case"onScrollEnd":n!=null&&fe("scrollend",e);break;case"dangerouslySetInnerHTML":if(n!=null){if(typeof n!="object"||!("__html"in n))throw Error(f(61));if(r=n.__html,r!=null){if(a.children!=null)throw Error(f(60));e.innerHTML=r}}break;case"multiple":e.multiple=n&&typeof n!="function"&&typeof n!="symbol";break;case"muted":e.muted=n&&typeof n!="function"&&typeof n!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(n==null||typeof n=="function"||typeof n=="boolean"||typeof n=="symbol"){e.removeAttribute("xlink:href");break}r=Co(""+n),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",r);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":n!=null&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(r,""+n):e.removeAttribute(r);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":n&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(r,""):e.removeAttribute(r);break;case"capture":case"download":n===!0?e.setAttribute(r,""):n!==!1&&n!=null&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(r,n):e.removeAttribute(r);break;case"cols":case"rows":case"size":case"span":n!=null&&typeof n!="function"&&typeof n!="symbol"&&!isNaN(n)&&1<=n?e.setAttribute(r,n):e.removeAttribute(r);break;case"rowSpan":case"start":n==null||typeof n=="function"||typeof n=="symbol"||isNaN(n)?e.removeAttribute(r):e.setAttribute(r,n);break;case"popover":fe("beforetoggle",e),fe("toggle",e),xo(e,"popover",n);break;case"xlinkActuate":tr(e,"http://www.w3.org/1999/xlink","xlink:actuate",n);break;case"xlinkArcrole":tr(e,"http://www.w3.org/1999/xlink","xlink:arcrole",n);break;case"xlinkRole":tr(e,"http://www.w3.org/1999/xlink","xlink:role",n);break;case"xlinkShow":tr(e,"http://www.w3.org/1999/xlink","xlink:show",n);break;case"xlinkTitle":tr(e,"http://www.w3.org/1999/xlink","xlink:title",n);break;case"xlinkType":tr(e,"http://www.w3.org/1999/xlink","xlink:type",n);break;case"xmlBase":tr(e,"http://www.w3.org/XML/1998/namespace","xml:base",n);break;case"xmlLang":tr(e,"http://www.w3.org/XML/1998/namespace","xml:lang",n);break;case"xmlSpace":tr(e,"http://www.w3.org/XML/1998/namespace","xml:space",n);break;case"is":xo(e,"is",n);break;case"innerText":case"textContent":break;default:(!(2<r.length)||r[0]!=="o"&&r[0]!=="O"||r[1]!=="n"&&r[1]!=="N")&&(r=xb.get(r)||r,xo(e,r,n))}}function Qs(e,t,r,n,a,o){switch(r){case"style":Fu(e,n,o);break;case"dangerouslySetInnerHTML":if(n!=null){if(typeof n!="object"||!("__html"in n))throw Error(f(61));if(r=n.__html,r!=null){if(a.children!=null)throw Error(f(60));e.innerHTML=r}}break;case"children":typeof n=="string"?Ln(e,n):(typeof n=="number"||typeof n=="bigint")&&Ln(e,""+n);break;case"onScroll":n!=null&&fe("scroll",e);break;case"onScrollEnd":n!=null&&fe("scrollend",e);break;case"onClick":n!=null&&(e.onclick=rr);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!Tu.hasOwnProperty(r))e:{if(r[0]==="o"&&r[1]==="n"&&(a=r.endsWith("Capture"),t=r.slice(2,a?r.length-7:void 0),o=e[ut]||null,o=o!=null?o[r]:null,typeof o=="function"&&e.removeEventListener(t,o,a),typeof n=="function")){typeof o!="function"&&o!==null&&(r in e?e[r]=null:e.hasAttribute(r)&&e.removeAttribute(r)),e.addEventListener(t,n,a);break e}r in e?e[r]=n:n===!0?e.setAttribute(r,""):xo(e,r,n)}}}function tt(e,t,r){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":fe("error",e),fe("load",e);var n=!1,a=!1,o;for(o in r)if(r.hasOwnProperty(o)){var l=r[o];if(l!=null)switch(o){case"src":n=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(f(137,t));default:ze(e,t,o,l,r,null)}}a&&ze(e,t,"srcSet",r.srcSet,r,null),n&&ze(e,t,"src",r.src,r,null);return;case"input":fe("invalid",e);var d=o=l=a=null,p=null,_=null;for(n in r)if(r.hasOwnProperty(n)){var P=r[n];if(P!=null)switch(n){case"name":a=P;break;case"type":l=P;break;case"checked":p=P;break;case"defaultChecked":_=P;break;case"value":o=P;break;case"defaultValue":d=P;break;case"children":case"dangerouslySetInnerHTML":if(P!=null)throw Error(f(137,t));break;default:ze(e,t,n,P,r,null)}}Ru(e,o,d,p,_,l,a,!1);return;case"select":fe("invalid",e),n=l=o=null;for(a in r)if(r.hasOwnProperty(a)&&(d=r[a],d!=null))switch(a){case"value":o=d;break;case"defaultValue":l=d;break;case"multiple":n=d;default:ze(e,t,a,d,r,null)}t=o,r=l,e.multiple=!!n,t!=null?An(e,!!n,t,!1):r!=null&&An(e,!!n,r,!0);return;case"textarea":fe("invalid",e),o=a=n=null;for(l in r)if(r.hasOwnProperty(l)&&(d=r[l],d!=null))switch(l){case"value":n=d;break;case"defaultValue":a=d;break;case"children":o=d;break;case"dangerouslySetInnerHTML":if(d!=null)throw Error(f(91));break;default:ze(e,t,l,d,r,null)}Du(e,n,a,o);return;case"option":for(p in r)r.hasOwnProperty(p)&&(n=r[p],n!=null)&&(p==="selected"?e.selected=n&&typeof n!="function"&&typeof n!="symbol":ze(e,t,p,n,r,null));return;case"dialog":fe("beforetoggle",e),fe("toggle",e),fe("cancel",e),fe("close",e);break;case"iframe":case"object":fe("load",e);break;case"video":case"audio":for(n=0;n<Ga.length;n++)fe(Ga[n],e);break;case"image":fe("error",e),fe("load",e);break;case"details":fe("toggle",e);break;case"embed":case"source":case"link":fe("error",e),fe("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(_ in r)if(r.hasOwnProperty(_)&&(n=r[_],n!=null))switch(_){case"children":case"dangerouslySetInnerHTML":throw Error(f(137,t));default:ze(e,t,_,n,r,null)}return;default:if(ul(t)){for(P in r)r.hasOwnProperty(P)&&(n=r[P],n!==void 0&&Qs(e,t,P,n,r,void 0));return}}for(d in r)r.hasOwnProperty(d)&&(n=r[d],n!=null&&ze(e,t,d,n,r,null))}function W0(e,t,r,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,o=null,l=null,d=null,p=null,_=null,P=null;for(T in r){var A=r[T];if(r.hasOwnProperty(T)&&A!=null)switch(T){case"checked":break;case"value":break;case"defaultValue":p=A;default:n.hasOwnProperty(T)||ze(e,t,T,null,n,A)}}for(var E in n){var T=n[E];if(A=r[E],n.hasOwnProperty(E)&&(T!=null||A!=null))switch(E){case"type":o=T;break;case"name":a=T;break;case"checked":_=T;break;case"defaultChecked":P=T;break;case"value":l=T;break;case"defaultValue":d=T;break;case"children":case"dangerouslySetInnerHTML":if(T!=null)throw Error(f(137,t));break;default:T!==A&&ze(e,t,E,T,n,A)}}sl(e,l,d,p,_,P,o,a);return;case"select":T=l=d=E=null;for(o in r)if(p=r[o],r.hasOwnProperty(o)&&p!=null)switch(o){case"value":break;case"multiple":T=p;default:n.hasOwnProperty(o)||ze(e,t,o,null,n,p)}for(a in n)if(o=n[a],p=r[a],n.hasOwnProperty(a)&&(o!=null||p!=null))switch(a){case"value":E=o;break;case"defaultValue":d=o;break;case"multiple":l=o;default:o!==p&&ze(e,t,a,o,n,p)}t=d,r=l,n=T,E!=null?An(e,!!r,E,!1):!!n!=!!r&&(t!=null?An(e,!!r,t,!0):An(e,!!r,r?[]:"",!1));return;case"textarea":T=E=null;for(d in r)if(a=r[d],r.hasOwnProperty(d)&&a!=null&&!n.hasOwnProperty(d))switch(d){case"value":break;case"children":break;default:ze(e,t,d,null,n,a)}for(l in n)if(a=n[l],o=r[l],n.hasOwnProperty(l)&&(a!=null||o!=null))switch(l){case"value":E=a;break;case"defaultValue":T=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(f(91));break;default:a!==o&&ze(e,t,l,a,n,o)}Ou(e,E,T);return;case"option":for(var K in r)E=r[K],r.hasOwnProperty(K)&&E!=null&&!n.hasOwnProperty(K)&&(K==="selected"?e.selected=!1:ze(e,t,K,null,n,E));for(p in n)E=n[p],T=r[p],n.hasOwnProperty(p)&&E!==T&&(E!=null||T!=null)&&(p==="selected"?e.selected=E&&typeof E!="function"&&typeof E!="symbol":ze(e,t,p,E,n,T));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var ne in r)E=r[ne],r.hasOwnProperty(ne)&&E!=null&&!n.hasOwnProperty(ne)&&ze(e,t,ne,null,n,E);for(_ in n)if(E=n[_],T=r[_],n.hasOwnProperty(_)&&E!==T&&(E!=null||T!=null))switch(_){case"children":case"dangerouslySetInnerHTML":if(E!=null)throw Error(f(137,t));break;default:ze(e,t,_,E,n,T)}return;default:if(ul(t)){for(var _e in r)E=r[_e],r.hasOwnProperty(_e)&&E!==void 0&&!n.hasOwnProperty(_e)&&Qs(e,t,_e,void 0,n,E);for(P in n)E=n[P],T=r[P],!n.hasOwnProperty(P)||E===T||E===void 0&&T===void 0||Qs(e,t,P,E,n,T);return}}for(var v in r)E=r[v],r.hasOwnProperty(v)&&E!=null&&!n.hasOwnProperty(v)&&ze(e,t,v,null,n,E);for(A in n)E=n[A],T=r[A],!n.hasOwnProperty(A)||E===T||E==null&&T==null||ze(e,t,A,E,n,T)}function Up(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function Y0(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,r=performance.getEntriesByType("resource"),n=0;n<r.length;n++){var a=r[n],o=a.transferSize,l=a.initiatorType,d=a.duration;if(o&&d&&Up(l)){for(l=0,d=a.responseEnd,n+=1;n<r.length;n++){var p=r[n],_=p.startTime;if(_>d)break;var P=p.transferSize,A=p.initiatorType;P&&Up(A)&&(p=p.responseEnd,l+=P*(p<d?1:(d-_)/(p-_)))}if(--n,t+=8*(o+l)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Ks=null,Xs=null;function ki(e){return e.nodeType===9?e:e.ownerDocument}function Hp(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function qp(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function Gs(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Js=null;function Q0(){var e=window.event;return e&&e.type==="popstate"?e===Js?!1:(Js=e,!0):(Js=null,!1)}var Bp=typeof setTimeout=="function"?setTimeout:void 0,K0=typeof clearTimeout=="function"?clearTimeout:void 0,Vp=typeof Promise=="function"?Promise:void 0,X0=typeof queueMicrotask=="function"?queueMicrotask:typeof Vp<"u"?function(e){return Vp.resolve(null).then(e).catch(G0)}:Bp;function G0(e){setTimeout(function(){throw e})}function Hr(e){return e==="head"}function Wp(e,t){var r=t,n=0;do{var a=r.nextSibling;if(e.removeChild(r),a&&a.nodeType===8)if(r=a.data,r==="/$"||r==="/&"){if(n===0){e.removeChild(a),da(t);return}n--}else if(r==="$"||r==="$?"||r==="$~"||r==="$!"||r==="&")n++;else if(r==="html")Za(e.ownerDocument.documentElement);else if(r==="head"){r=e.ownerDocument.head,Za(r);for(var o=r.firstChild;o;){var l=o.nextSibling,d=o.nodeName;o[va]||d==="SCRIPT"||d==="STYLE"||d==="LINK"&&o.rel.toLowerCase()==="stylesheet"||r.removeChild(o),o=l}}else r==="body"&&Za(e.ownerDocument.body);r=a}while(r);da(t)}function Yp(e,t){var r=e;e=0;do{var n=r.nextSibling;if(r.nodeType===1?t?(r._stashedDisplay=r.style.display,r.style.display="none"):(r.style.display=r._stashedDisplay||"",r.getAttribute("style")===""&&r.removeAttribute("style")):r.nodeType===3&&(t?(r._stashedText=r.nodeValue,r.nodeValue=""):r.nodeValue=r._stashedText||""),n&&n.nodeType===8)if(r=n.data,r==="/$"){if(e===0)break;e--}else r!=="$"&&r!=="$?"&&r!=="$~"&&r!=="$!"||e++;r=n}while(r)}function Zs(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var r=t;switch(t=t.nextSibling,r.nodeName){case"HTML":case"HEAD":case"BODY":Zs(r),il(r);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(r.rel.toLowerCase()==="stylesheet")continue}e.removeChild(r)}}function J0(e,t,r,n){for(;e.nodeType===1;){var a=r;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!n&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(n){if(!e[va])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(o=e.getAttribute("rel"),o==="stylesheet"&&e.hasAttribute("data-precedence")||o!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(o=e.getAttribute("src"),(o!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var o=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===o)return e}else return e;if(e=Rt(e.nextSibling),e===null)break}return null}function Z0(e,t,r){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!r||(e=Rt(e.nextSibling),e===null))return null;return e}function Qp(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Rt(e.nextSibling),e===null))return null;return e}function ec(e){return e.data==="$?"||e.data==="$~"}function tc(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function ev(e,t){var r=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||r.readyState!=="loading")t();else{var n=function(){t(),r.removeEventListener("DOMContentLoaded",n)};r.addEventListener("DOMContentLoaded",n),e._reactRetry=n}}function Rt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var rc=null;function Kp(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var r=e.data;if(r==="/$"||r==="/&"){if(t===0)return Rt(e.nextSibling);t--}else r!=="$"&&r!=="$!"&&r!=="$?"&&r!=="$~"&&r!=="&"||t++}e=e.nextSibling}return null}function Xp(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var r=e.data;if(r==="$"||r==="$!"||r==="$?"||r==="$~"||r==="&"){if(t===0)return e;t--}else r!=="/$"&&r!=="/&"||t++}e=e.previousSibling}return null}function Gp(e,t,r){switch(t=ki(r),e){case"html":if(e=t.documentElement,!e)throw Error(f(452));return e;case"head":if(e=t.head,!e)throw Error(f(453));return e;case"body":if(e=t.body,!e)throw Error(f(454));return e;default:throw Error(f(451))}}function Za(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);il(e)}var Ot=new Map,Jp=new Set;function Si(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var vr=M.d;M.d={f:tv,r:rv,D:nv,C:av,L:ov,m:iv,X:sv,S:lv,M:cv};function tv(){var e=vr.f(),t=fi();return e||t}function rv(e){var t=Tn(e);t!==null&&t.tag===5&&t.type==="form"?pf(t):vr.r(e)}var sa=typeof document>"u"?null:document;function Zp(e,t,r){var n=sa;if(n&&typeof t=="string"&&t){var a=It(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof r=="string"&&(a+='[crossorigin="'+r+'"]'),Jp.has(a)||(Jp.add(a),e={rel:e,crossOrigin:r,href:t},n.querySelector(a)===null&&(t=n.createElement("link"),tt(t,"link",e),Ke(t),n.head.appendChild(t)))}}function nv(e){vr.D(e),Zp("dns-prefetch",e,null)}function av(e,t){vr.C(e,t),Zp("preconnect",e,t)}function ov(e,t,r){vr.L(e,t,r);var n=sa;if(n&&e&&t){var a='link[rel="preload"][as="'+It(t)+'"]';t==="image"&&r&&r.imageSrcSet?(a+='[imagesrcset="'+It(r.imageSrcSet)+'"]',typeof r.imageSizes=="string"&&(a+='[imagesizes="'+It(r.imageSizes)+'"]')):a+='[href="'+It(e)+'"]';var o=a;switch(t){case"style":o=ca(e);break;case"script":o=ua(e)}Ot.has(o)||(e=S({rel:"preload",href:t==="image"&&r&&r.imageSrcSet?void 0:e,as:t},r),Ot.set(o,e),n.querySelector(a)!==null||t==="style"&&n.querySelector(eo(o))||t==="script"&&n.querySelector(to(o))||(t=n.createElement("link"),tt(t,"link",e),Ke(t),n.head.appendChild(t)))}}function iv(e,t){vr.m(e,t);var r=sa;if(r&&e){var n=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+It(n)+'"][href="'+It(e)+'"]',o=a;switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=ua(e)}if(!Ot.has(o)&&(e=S({rel:"modulepreload",href:e},t),Ot.set(o,e),r.querySelector(a)===null)){switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(r.querySelector(to(o)))return}n=r.createElement("link"),tt(n,"link",e),Ke(n),r.head.appendChild(n)}}}function lv(e,t,r){vr.S(e,t,r);var n=sa;if(n&&e){var a=Pn(n).hoistableStyles,o=ca(e);t=t||"default";var l=a.get(o);if(!l){var d={loading:0,preload:null};if(l=n.querySelector(eo(o)))d.loading=5;else{e=S({rel:"stylesheet",href:e,"data-precedence":t},r),(r=Ot.get(o))&&nc(e,r);var p=l=n.createElement("link");Ke(p),tt(p,"link",e),p._p=new Promise(function(_,P){p.onload=_,p.onerror=P}),p.addEventListener("load",function(){d.loading|=1}),p.addEventListener("error",function(){d.loading|=2}),d.loading|=4,Ci(l,t,n)}l={type:"stylesheet",instance:l,count:1,state:d},a.set(o,l)}}}function sv(e,t){vr.X(e,t);var r=sa;if(r&&e){var n=Pn(r).hoistableScripts,a=ua(e),o=n.get(a);o||(o=r.querySelector(to(a)),o||(e=S({src:e,async:!0},t),(t=Ot.get(a))&&ac(e,t),o=r.createElement("script"),Ke(o),tt(o,"link",e),r.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(a,o))}}function cv(e,t){vr.M(e,t);var r=sa;if(r&&e){var n=Pn(r).hoistableScripts,a=ua(e),o=n.get(a);o||(o=r.querySelector(to(a)),o||(e=S({src:e,async:!0,type:"module"},t),(t=Ot.get(a))&&ac(e,t),o=r.createElement("script"),Ke(o),tt(o,"link",e),r.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(a,o))}}function em(e,t,r,n){var a=(a=ie.current)?Si(a):null;if(!a)throw Error(f(446));switch(e){case"meta":case"title":return null;case"style":return typeof r.precedence=="string"&&typeof r.href=="string"?(t=ca(r.href),r=Pn(a).hoistableStyles,n=r.get(t),n||(n={type:"style",instance:null,count:0,state:null},r.set(t,n)),n):{type:"void",instance:null,count:0,state:null};case"link":if(r.rel==="stylesheet"&&typeof r.href=="string"&&typeof r.precedence=="string"){e=ca(r.href);var o=Pn(a).hoistableStyles,l=o.get(e);if(l||(a=a.ownerDocument||a,l={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},o.set(e,l),(o=a.querySelector(eo(e)))&&!o._p&&(l.instance=o,l.state.loading=5),Ot.has(e)||(r={rel:"preload",as:"style",href:r.href,crossOrigin:r.crossOrigin,integrity:r.integrity,media:r.media,hrefLang:r.hrefLang,referrerPolicy:r.referrerPolicy},Ot.set(e,r),o||uv(a,e,r,l.state))),t&&n===null)throw Error(f(528,""));return l}if(t&&n!==null)throw Error(f(529,""));return null;case"script":return t=r.async,r=r.src,typeof r=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(t=ua(r),r=Pn(a).hoistableScripts,n=r.get(t),n||(n={type:"script",instance:null,count:0,state:null},r.set(t,n)),n):{type:"void",instance:null,count:0,state:null};default:throw Error(f(444,e))}}function ca(e){return'href="'+It(e)+'"'}function eo(e){return'link[rel="stylesheet"]['+e+"]"}function tm(e){return S({},e,{"data-precedence":e.precedence,precedence:null})}function uv(e,t,r,n){e.querySelector('link[rel="preload"][as="style"]['+t+"]")?n.loading=1:(t=e.createElement("link"),n.preload=t,t.addEventListener("load",function(){return n.loading|=1}),t.addEventListener("error",function(){return n.loading|=2}),tt(t,"link",r),Ke(t),e.head.appendChild(t))}function ua(e){return'[src="'+It(e)+'"]'}function to(e){return"script[async]"+e}function rm(e,t,r){if(t.count++,t.instance===null)switch(t.type){case"style":var n=e.querySelector('style[data-href~="'+It(r.href)+'"]');if(n)return t.instance=n,Ke(n),n;var a=S({},r,{"data-href":r.href,"data-precedence":r.precedence,href:null,precedence:null});return n=(e.ownerDocument||e).createElement("style"),Ke(n),tt(n,"style",a),Ci(n,r.precedence,e),t.instance=n;case"stylesheet":a=ca(r.href);var o=e.querySelector(eo(a));if(o)return t.state.loading|=4,t.instance=o,Ke(o),o;n=tm(r),(a=Ot.get(a))&&nc(n,a),o=(e.ownerDocument||e).createElement("link"),Ke(o);var l=o;return l._p=new Promise(function(d,p){l.onload=d,l.onerror=p}),tt(o,"link",n),t.state.loading|=4,Ci(o,r.precedence,e),t.instance=o;case"script":return o=ua(r.src),(a=e.querySelector(to(o)))?(t.instance=a,Ke(a),a):(n=r,(a=Ot.get(o))&&(n=S({},r),ac(n,a)),e=e.ownerDocument||e,a=e.createElement("script"),Ke(a),tt(a,"link",n),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(f(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(n=t.instance,t.state.loading|=4,Ci(n,r.precedence,e));return t.instance}function Ci(e,t,r){for(var n=r.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=n.length?n[n.length-1]:null,o=a,l=0;l<n.length;l++){var d=n[l];if(d.dataset.precedence===t)o=d;else if(o!==a)break}o?o.parentNode.insertBefore(e,o.nextSibling):(t=r.nodeType===9?r.head:r,t.insertBefore(e,t.firstChild))}function nc(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function ac(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var zi=null;function nm(e,t,r){if(zi===null){var n=new Map,a=zi=new Map;a.set(r,n)}else a=zi,n=a.get(r),n||(n=new Map,a.set(r,n));if(n.has(e))return n;for(n.set(e,null),r=r.getElementsByTagName(e),a=0;a<r.length;a++){var o=r[a];if(!(o[va]||o[Ge]||e==="link"&&o.getAttribute("rel")==="stylesheet")&&o.namespaceURI!=="http://www.w3.org/2000/svg"){var l=o.getAttribute(t)||"";l=e+l;var d=n.get(l);d?d.push(o):n.set(l,[o])}}return n}function am(e,t,r){e=e.ownerDocument||e,e.head.insertBefore(r,t==="title"?e.querySelector("head > title"):null)}function dv(e,t,r){if(r===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function om(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function fv(e,t,r,n){if(r.type==="stylesheet"&&(typeof n.media!="string"||matchMedia(n.media).matches!==!1)&&(r.state.loading&4)===0){if(r.instance===null){var a=ca(n.href),o=t.querySelector(eo(a));if(o){t=o._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=_i.bind(e),t.then(e,e)),r.state.loading|=4,r.instance=o,Ke(o);return}o=t.ownerDocument||t,n=tm(n),(a=Ot.get(a))&&nc(n,a),o=o.createElement("link"),Ke(o);var l=o;l._p=new Promise(function(d,p){l.onload=d,l.onerror=p}),tt(o,"link",n),r.instance=o}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(r,t),(t=r.state.preload)&&(r.state.loading&3)===0&&(e.count++,r=_i.bind(e),t.addEventListener("load",r),t.addEventListener("error",r))}}var oc=0;function pv(e,t){return e.stylesheets&&e.count===0&&Ni(e,e.stylesheets),0<e.count||0<e.imgCount?function(r){var n=setTimeout(function(){if(e.stylesheets&&Ni(e,e.stylesheets),e.unsuspend){var o=e.unsuspend;e.unsuspend=null,o()}},6e4+t);0<e.imgBytes&&oc===0&&(oc=62500*Y0());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Ni(e,e.stylesheets),e.unsuspend)){var o=e.unsuspend;e.unsuspend=null,o()}},(e.imgBytes>oc?50:800)+t);return e.unsuspend=r,function(){e.unsuspend=null,clearTimeout(n),clearTimeout(a)}}:null}function _i(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Ni(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var Ei=null;function Ni(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Ei=new Map,t.forEach(mv,e),Ei=null,_i.call(e))}function mv(e,t){if(!(t.state.loading&4)){var r=Ei.get(e);if(r)var n=r.get(null);else{r=new Map,Ei.set(e,r);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),o=0;o<a.length;o++){var l=a[o];(l.nodeName==="LINK"||l.getAttribute("media")!=="not all")&&(r.set(l.dataset.precedence,l),n=l)}n&&r.set(null,n)}a=t.instance,l=a.getAttribute("data-precedence"),o=r.get(l)||n,o===n&&r.set(null,a),r.set(l,a),this.count++,n=_i.bind(this),a.addEventListener("load",n),a.addEventListener("error",n),o?o.parentNode.insertBefore(a,o.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var ro={$$typeof:N,Provider:null,Consumer:null,_currentValue:ge,_currentValue2:ge,_threadCount:0};function gv(e,t,r,n,a,o,l,d,p){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=rl(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=rl(0),this.hiddenUpdates=rl(null),this.identifierPrefix=n,this.onUncaughtError=a,this.onCaughtError=o,this.onRecoverableError=l,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=p,this.incompleteTransitions=new Map}function im(e,t,r,n,a,o,l,d,p,_,P,A){return e=new gv(e,t,r,l,p,_,P,A,d),t=1,o===!0&&(t|=24),o=xt(3,null,null,t),e.current=o,o.stateNode=e,t=$l(),t.refCount++,e.pooledCache=t,t.refCount++,o.memoizedState={element:n,isDehydrated:r,cache:t},Bl(o),e}function lm(e){return e?(e=Un,e):Un}function sm(e,t,r,n,a,o){a=lm(a),n.context===null?n.context=a:n.pendingContext=a,n=jr(t),n.payload={element:r},o=o===void 0?null:o,o!==null&&(n.callback=o),r=Ar(e,n,t),r!==null&&(ht(r,e,t),Ra(r,e,t))}function cm(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var r=e.retryLane;e.retryLane=r!==0&&r<t?r:t}}function ic(e,t){cm(e,t),(e=e.alternate)&&cm(e,t)}function um(e){if(e.tag===13||e.tag===31){var t=on(e,67108864);t!==null&&ht(t,e,67108864),ic(e,67108864)}}function dm(e){if(e.tag===13||e.tag===31){var t=_t();t=nl(t);var r=on(e,t);r!==null&&ht(r,e,t),ic(e,t)}}var Ti=!0;function hv(e,t,r,n){var a=O.T;O.T=null;var o=M.p;try{M.p=2,lc(e,t,r,n)}finally{M.p=o,O.T=a}}function bv(e,t,r,n){var a=O.T;O.T=null;var o=M.p;try{M.p=8,lc(e,t,r,n)}finally{M.p=o,O.T=a}}function lc(e,t,r,n){if(Ti){var a=sc(n);if(a===null)Ys(e,t,n,Pi,r),pm(e,n);else if(yv(a,e,t,r,n))n.stopPropagation();else if(pm(e,n),t&4&&-1<vv.indexOf(e)){for(;a!==null;){var o=Tn(a);if(o!==null)switch(o.tag){case 3:if(o=o.stateNode,o.current.memoizedState.isDehydrated){var l=en(o.pendingLanes);if(l!==0){var d=o;for(d.pendingLanes|=2,d.entangledLanes|=2;l;){var p=1<<31-yt(l);d.entanglements[1]|=p,l&=~p}Kt(o),(xe&6)===0&&(ui=bt()+500,Xa(0,!1))}}break;case 31:case 13:d=on(o,2),d!==null&&ht(d,o,2),fi(),ic(o,2)}if(o=sc(n),o===null&&Ys(e,t,n,Pi,r),o===a)break;a=o}a!==null&&n.stopPropagation()}else Ys(e,t,n,null,r)}}function sc(e){return e=fl(e),cc(e)}var Pi=null;function cc(e){if(Pi=null,e=Nn(e),e!==null){var t=h(e);if(t===null)e=null;else{var r=t.tag;if(r===13){if(e=w(t),e!==null)return e;e=null}else if(r===31){if(e=C(t),e!==null)return e;e=null}else if(r===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Pi=e,null}function fm(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(ob()){case vu:return 2;case yu:return 8;case ho:case ib:return 32;case wu:return 268435456;default:return 32}default:return 32}}var uc=!1,qr=null,Br=null,Vr=null,no=new Map,ao=new Map,Wr=[],vv="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function pm(e,t){switch(e){case"focusin":case"focusout":qr=null;break;case"dragenter":case"dragleave":Br=null;break;case"mouseover":case"mouseout":Vr=null;break;case"pointerover":case"pointerout":no.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":ao.delete(t.pointerId)}}function oo(e,t,r,n,a,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:r,eventSystemFlags:n,nativeEvent:o,targetContainers:[a]},t!==null&&(t=Tn(t),t!==null&&um(t)),e):(e.eventSystemFlags|=n,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function yv(e,t,r,n,a){switch(t){case"focusin":return qr=oo(qr,e,t,r,n,a),!0;case"dragenter":return Br=oo(Br,e,t,r,n,a),!0;case"mouseover":return Vr=oo(Vr,e,t,r,n,a),!0;case"pointerover":var o=a.pointerId;return no.set(o,oo(no.get(o)||null,e,t,r,n,a)),!0;case"gotpointercapture":return o=a.pointerId,ao.set(o,oo(ao.get(o)||null,e,t,r,n,a)),!0}return!1}function mm(e){var t=Nn(e.target);if(t!==null){var r=h(t);if(r!==null){if(t=r.tag,t===13){if(t=w(r),t!==null){e.blockedOn=t,_u(e.priority,function(){dm(r)});return}}else if(t===31){if(t=C(r),t!==null){e.blockedOn=t,_u(e.priority,function(){dm(r)});return}}else if(t===3&&r.stateNode.current.memoizedState.isDehydrated){e.blockedOn=r.tag===3?r.stateNode.containerInfo:null;return}}}e.blockedOn=null}function ji(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var r=sc(e.nativeEvent);if(r===null){r=e.nativeEvent;var n=new r.constructor(r.type,r);dl=n,r.target.dispatchEvent(n),dl=null}else return t=Tn(r),t!==null&&um(t),e.blockedOn=r,!1;t.shift()}return!0}function gm(e,t,r){ji(e)&&r.delete(t)}function wv(){uc=!1,qr!==null&&ji(qr)&&(qr=null),Br!==null&&ji(Br)&&(Br=null),Vr!==null&&ji(Vr)&&(Vr=null),no.forEach(gm),ao.forEach(gm)}function Ai(e,t){e.blockedOn===t&&(e.blockedOn=null,uc||(uc=!0,s.unstable_scheduleCallback(s.unstable_NormalPriority,wv)))}var Li=null;function hm(e){Li!==e&&(Li=e,s.unstable_scheduleCallback(s.unstable_NormalPriority,function(){Li===e&&(Li=null);for(var t=0;t<e.length;t+=3){var r=e[t],n=e[t+1],a=e[t+2];if(typeof n!="function"){if(cc(n||r)===null)continue;break}var o=Tn(r);o!==null&&(e.splice(t,3),t-=3,us(o,{pending:!0,data:a,method:r.method,action:n},n,a))}}))}function da(e){function t(p){return Ai(p,e)}qr!==null&&Ai(qr,e),Br!==null&&Ai(Br,e),Vr!==null&&Ai(Vr,e),no.forEach(t),ao.forEach(t);for(var r=0;r<Wr.length;r++){var n=Wr[r];n.blockedOn===e&&(n.blockedOn=null)}for(;0<Wr.length&&(r=Wr[0],r.blockedOn===null);)mm(r),r.blockedOn===null&&Wr.shift();if(r=(e.ownerDocument||e).$$reactFormReplay,r!=null)for(n=0;n<r.length;n+=3){var a=r[n],o=r[n+1],l=a[ut]||null;if(typeof o=="function")l||hm(r);else if(l){var d=null;if(o&&o.hasAttribute("formAction")){if(a=o,l=o[ut]||null)d=l.formAction;else if(cc(a)!==null)continue}else d=l.action;typeof d=="function"?r[n+1]=d:(r.splice(n,3),n-=3),hm(r)}}}function bm(){function e(o){o.canIntercept&&o.info==="react-transition"&&o.intercept({handler:function(){return new Promise(function(l){return a=l})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),n||setTimeout(r,20)}function r(){if(!n&&!navigation.transition){var o=navigation.currentEntry;o&&o.url!=null&&navigation.navigate(o.url,{state:o.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var n=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(r,100),function(){n=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function dc(e){this._internalRoot=e}Ri.prototype.render=dc.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(f(409));var r=t.current,n=_t();sm(r,n,e,t,null,null)},Ri.prototype.unmount=dc.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;sm(e.current,2,null,e,null,null),fi(),t[En]=null}};function Ri(e){this._internalRoot=e}Ri.prototype.unstable_scheduleHydration=function(e){if(e){var t=zu();e={blockedOn:null,target:e,priority:t};for(var r=0;r<Wr.length&&t!==0&&t<Wr[r].priority;r++);Wr.splice(r,0,e),r===0&&mm(e)}};var vm=c.version;if(vm!=="19.2.8")throw Error(f(527,vm,"19.2.8"));M.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(f(188)):(e=Object.keys(e).join(","),Error(f(268,e)));return e=y(t),e=e!==null?k(e):null,e=e===null?null:e.stateNode,e};var xv={bundleType:0,version:"19.2.8",rendererPackageName:"react-dom",currentDispatcherRef:O,reconcilerVersion:"19.2.8"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(io=__REACT_DEVTOOLS_GLOBAL_HOOK__,!io.isDisabled&&io.supportsFiber))try{ga=io.inject(xv),vt=io}catch{}var io;i.createRoot=function(e,t){if(!b(e))throw Error(f(299));var r=!1,n="",a=Sf,o=Cf,l=zf;return t!=null&&(t.unstable_strictMode===!0&&(r=!0),t.identifierPrefix!==void 0&&(n=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(o=t.onCaughtError),t.onRecoverableError!==void 0&&(l=t.onRecoverableError)),t=im(e,1,!1,null,null,r,n,null,a,o,l,bm),e[En]=t.current,Ws(e),new dc(t)},i.hydrateRoot=function(e,t,r){if(!b(e))throw Error(f(299));var n=!1,a="",o=Sf,l=Cf,d=zf,p=null;return r!=null&&(r.unstable_strictMode===!0&&(n=!0),r.identifierPrefix!==void 0&&(a=r.identifierPrefix),r.onUncaughtError!==void 0&&(o=r.onUncaughtError),r.onCaughtError!==void 0&&(l=r.onCaughtError),r.onRecoverableError!==void 0&&(d=r.onRecoverableError),r.formState!==void 0&&(p=r.formState)),t=im(e,1,!0,t,r??null,n,a,p,o,l,d,bm),t.context=lm(null),r=t.current,n=_t(),n=nl(n),a=jr(n),a.callback=null,Ar(r,a,n),r=n,t.current.lanes=r,ba(t,r),Kt(t),e[En]=t.current,Ws(e),new Ri(t)},i.version="19.2.8"}),Am=Ht((i,s)=>{"use strict";function c(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(c)}catch(u){console.error(u)}}c(),s.exports=jm()}),Lm=Ht(i=>{"use strict";var s=Symbol.for("react.transitional.element"),c=Symbol.for("react.fragment");function u(f,b,h){var w=null;if(h!==void 0&&(w=""+h),b.key!==void 0&&(w=""+b.key),"key"in b){h={};for(var C in b)C!=="key"&&(h[C]=b[C])}else h=b;return b=h.ref,{$$typeof:s,type:f,key:w,ref:b!==void 0?b:null,props:h}}i.Fragment=c,i.jsx=u,i.jsxs=u}),it=Ht((i,s)=>{"use strict";s.exports=Lm()});function Rm(){return fa||(fa=new CSSStyleSheet,fa.replaceSync(gc)),fa}function Om(){if(Oi||document.getElementById("ext-pjs-font"))return;Oi=!0;let i=document.createElement("link");i.id="ext-pjs-font",i.rel="stylesheet",i.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(i)}function pc(i,s="open"){let c=i.attachShadow({mode:s});return c.adoptedStyleSheets=[Rm()],Om(),c}var mc,gc,fa,Oi,hc=so(()=>{"use strict";mc='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',gc=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${mc};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,fa=null,Oi=!1}),bc,vc,Dm=so(()=>{"use strict";hc(),bc=`
  :host { display: none; }
  :host([open]) { display: block; }
  .overlay {
    position: fixed;
    inset: 0;
    z-index: 2147483000;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(15, 23, 42, 0.55);
    backdrop-filter: blur(2px);
    animation: ext-fade var(--ext-duration-normal) var(--ext-ease);
    padding: var(--ext-space-6);
  }
  .modal {
    width: 520px;
    max-width: 100%;
    background: var(--ext-surface);
    border-radius: var(--ext-radius-lg);
    box-shadow: var(--ext-shadow-lg);
    overflow: hidden;
    animation: ext-slide-up var(--ext-duration-normal) var(--ext-ease);
  }
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--ext-space-4);
    padding: var(--ext-space-5) var(--ext-space-6);
    border-bottom: 1px solid var(--ext-border);
  }
  .title {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-lg);
    font-weight: 700;
    color: var(--ext-text);
    margin: 0;
  }
  .close {
    appearance: none;
    border: none;
    background: var(--ext-surface-2);
    color: var(--ext-text-secondary);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    font-size: 22px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color var(--ext-duration-fast) var(--ext-ease), color var(--ext-duration-fast) var(--ext-ease);
  }
  .close:hover { background: var(--ext-danger-soft); color: var(--ext-danger); }
  .close:focus-visible { outline: none; box-shadow: var(--ext-ring); }

  .body {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text-secondary);
    padding: var(--ext-space-6);
  }
  .footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--ext-space-3);
    padding: 0 var(--ext-space-6) var(--ext-space-6);
  }
  /* tombol utama di dalam modal memakai komponen ext-btn \u2014 styling via atribut host */
  ::slotted(*) { font-family: var(--ext-font-family); }

  /* variant accent line */
  :host([variant='danger']) .header { box-shadow: inset 4px 0 0 var(--ext-danger); }
  :host([variant='success']) .header { box-shadow: inset 4px 0 0 var(--ext-success); }
  :host([variant='info']) .header { box-shadow: inset 4px 0 0 var(--ext-info); }
  :host([variant='warning']) .header { box-shadow: inset 4px 0 0 var(--ext-warning); }

  @keyframes ext-fade { from { opacity: 0; } }
  @keyframes ext-slide-up {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
  }
`,vc=class extends HTMLElement{constructor(){super(),this.handleKey=i=>{i.key==="Escape"&&this.hasAttribute("open")&&this.cancel()},this.root=pc(this),this.root.innerHTML=`
      <style>${bc}</style>
      <div class="overlay">
        <div class="modal" role="dialog" aria-modal="true">
          <div class="header">
            <h3 class="title"><slot name="title"></slot></h3>
            <button class="close" part="close" aria-label="Tutup">&times;</button>
          </div>
          <div class="body"><slot></slot></div>
          <div class="footer">
            <slot name="footer"></slot>
          </div>
        </div>
      </div>
    `}connectedCallback(){let i=this.root.querySelector(".overlay");this.root.querySelector(".close").addEventListener("click",()=>this.cancel()),i.addEventListener("click",s=>{s.target===i&&this.cancel()}),document.addEventListener("keydown",this.handleKey)}disconnectedCallback(){document.removeEventListener("keydown",this.handleKey)}get titleSlot(){return this.querySelector('[slot="title"]')}get footerSlot(){return this.querySelector('[slot="footer"]')}open(){this.setAttribute("open","")}close(){this.removeAttribute("open")}cancel(){this.dispatchEvent(new CustomEvent("ext-cancel")),this.close()}ok(){this.dispatchEvent(new CustomEvent("ext-ok"))}},customElements.get("ext-modal")||customElements.define("ext-modal",vc)}),yc,wc,Im=so(()=>{"use strict";hc(),yc=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,wc=class extends HTMLElement{constructor(){super();let i=pc(this);i.innerHTML=`
      <style>${yc}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=i.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",i=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){i.stopPropagation(),i.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(i){(i==="disabled"||i==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}},customElements.get("ext-btn")||customElements.define("ext-btn",wc)}),xc={};Cm(xc,{confirmExt:()=>Fm});function Fm(i){return new Promise(s=>{let c=document.createElement("ext-modal");c.setAttribute("variant",i.variant??"warning"),i.okLabel&&c.setAttribute("ok-label",i.okLabel),i.cancelLabel&&c.setAttribute("cancel-label",i.cancelLabel),i.hideCancel&&c.setAttribute("hide-cancel",""),c.innerHTML=`<h3 slot="title"></h3><div class="ext-confirm-body"></div><div slot="footer">
         <ext-btn data-ext-confirm-cancel variant="secondary"></ext-btn>
         <ext-btn data-ext-confirm-ok></ext-btn>
       </div>`;let u=c.querySelector('[slot="title"]');u.textContent=i.title;let f=c.querySelector(".ext-confirm-body");if(i.icon){let w=document.createElement("div");w.className="ext-confirm-icon",w.textContent=i.icon,f.appendChild(w)}i.message&&i.message.split(`
`).forEach((w,C)=>{C>0&&f.appendChild(document.createElement("br")),f.appendChild(document.createTextNode(w))}),c.querySelector("[data-ext-confirm-ok]").textContent=i.okLabel??"Lanjut";let b=c.querySelector("[data-ext-confirm-ok]");b.setAttribute("variant",i.variant==="danger"?"danger":"primary"),i.hideCancel?c.querySelector("[data-ext-confirm-cancel]")?.remove():c.querySelector("[data-ext-confirm-cancel]").textContent=i.cancelLabel??"Batal",b.addEventListener("click",()=>c.ok()),i.hideCancel||c.querySelector("[data-ext-confirm-cancel]").addEventListener("click",()=>c.cancel());let h=w=>{c.remove(),s(w)};c.addEventListener("ext-ok",()=>h(!0)),c.addEventListener("ext-cancel",()=>h(!1)),document.body.appendChild(c),c.open()})}var Mm=so(()=>{"use strict";Dm(),Im()}),$m={},Um=Ne(Am(),1),Xt=Ne(Et(),1);function yr(i){let s=i.trim();return s===""||/^[-–—]+$/.test(s)}var Hm="http://dev.rsudkotajambi.id/rs",qm="ext-farmasi-app-base",Bm=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],Vm=".rsudkotajambi.id",Wm=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],kc="Fitur nonaktif: server Reports menggunakan HTTP (belum mendukung HTTPS)";function Di(i){try{let s=new URL(i??Ii());if(s.protocol==="https:")return null;let c=s.hostname.toLowerCase();return Wm.includes(c)?null:kc}catch{return kc}}function Ym(i){try{let s=new URL(i);if(s.protocol!=="http:"&&s.protocol!=="https:")return!1;let c=s.hostname.toLowerCase();return Bm.includes(c)?!0:c.endsWith(Vm)}catch{return!1}}function Ii(){try{let i=localStorage.getItem(qm);if(i&&Ym(i))return i.replace(/\/+$/,"")}catch{}return Hm}async function Qm(i,s,c=fetch){let u=new AbortController,f=globalThis.setTimeout(()=>u.abort(),25e3);try{return await c(i,{...s,signal:u.signal})}finally{globalThis.clearTimeout(f)}}async function Km(i,s=fetch){try{let c=Ii(),u=Di(c);if(u)return console.warn("[casemixApi]",u,"\u2014 baca pusat dilewati:",i),null;let f=await Qm(c+i,{cache:"no-store",credentials:"omit",headers:{Accept:"application/json"}},s);return f.ok?await f.json():null}catch{return null}}async function Xm(i,s,c=fetch){if(!i)return[];let u="/api/reports/resume-history?id_visit="+encodeURIComponent(i)+(s?"&tipe="+s:""),f=await Km(u,c);return!f?.ok||!Array.isArray(f.data)?[]:f.data}function Gm(){try{let i=globalThis.crypto;if(i&&typeof i.randomUUID=="function")return i.randomUUID()}catch{}return`${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`}function Qr(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}var Sc="ext_rv_history_",Jm=Sc,Cc="ext_rv_lastform_",Zm="ext_migrated_rv_",zc=50;function Fi(i,s){return`${Sc}${s==="ranap"?"ri":"rj"}_${i||"unknown"}`}function _c(i,s){return`${Cc}${s==="ranap"?"ri":"rj"}_${i||"unknown"}`}function co(i,s){if(!i)return null;try{let c=i.getItem(s);return c?JSON.parse(c):null}catch{return null}}function Mi(i,s,c){if(i)try{i.setItem(s,JSON.stringify(c))}catch{}}function eg(i,s){return JSON.stringify(i??null)===JSON.stringify(s??null)}function Ec(i,s){let c={};return Object.keys(i).forEach(u=>c[u]=!0),Object.keys(s).forEach(u=>c[u]=!0),Object.keys(c).filter(u=>!eg(i[u],s[u]))}function Nc(i){let s=i===void 0?"-":JSON.stringify(i);return s.length>60?s.slice(0,60)+"\u2026":s}function $i(i,s,c=Qr()){let u=co(c,Fi(i,s)),f=Array.isArray(u)?u:[];if(s==="ranap"){let b=co(c,Jm+i);if(Array.isArray(b)&&b.length>0&&f.length===0){let h=b.map(w=>({...w,tipe:"ranap"}));return Ui(h,i,"ranap",c),h}}return f}function Ui(i,s,c,u=Qr()){Mi(u,Fi(s,c),i.slice(-zc))}function tg(i,s,c=Qr()){return co(c,_c(i,s))||(s==="ranap"?co(c,Cc+i):null)}function Tc(i,s,c,u=Qr()){Mi(u,_c(s,c),i)}function rg(){try{let i=document.getElementById("userpanel");if(i){let f="",b="";if(i.querySelectorAll(".subgroup").forEach(w=>{let C=(w.querySelector(".subtitle")?.textContent||"").trim().toLowerCase(),x=(w.querySelector(".subcontent")?.textContent||"").trim();C==="username"&&x&&(f=x),C==="role"&&x&&(b=x)}),f)return`${f}${b?` (${b})`:""}`;let h=(i.querySelector("a")?.textContent||"").trim();if(h&&h!=="Petugas Rumah Sakit")return h}let s=(document.querySelector("#petugas, .petugas, .username, #username, .user-name")?.textContent||"").trim();if(s)return s.slice(0,80);let c=document.querySelector('input[name="dokter"], #dokter, input[name="nama_dokter"]')?.value?.trim();if(c)return c.slice(0,80);let u=document.querySelector('input[name="id_user"], #id_user')?.value?.trim();if(u)return`User #${u}`}catch{}return"petugas"}var ng="/api/reports/resume-history";function ag(){return Ii()}function og(i){return Zm+i}function ig(i,s){if(!i)return 0;try{let c=i.getItem(s);if(c===null)return 0;let u=Number(JSON.parse(c));return Number.isFinite(u)?u:0}catch{return 0}}function lg(i,s,c,u){if(!(!i||!s))try{let f=og(Fi(s,c));u>ig(i,f)&&Mi(i,f,u)}catch{}}function sg(i,s,c=fetch,u=Qr(),f=i.tipe){let b={client_id:i.client_id??null,id_visit:s,id_resume:i.id_resume,aksi:i.aksi,tipe:i.tipe,waktu:new Date(i.at).toISOString(),user:i.user,before:i.before,after:i.after,changed:i.changed},h=async()=>{try{let w=ag(),C=Di(w);return C?(console.warn("[resumeHistory]",C,"\u2014 kirim resume dilewati:",s),!1):(await c(w+ng,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(b),keepalive:!0,credentials:"omit"})).ok?(lg(u,s,f,i.at),!0):!1}catch{return!1}};try{return h()}catch{return Promise.resolve(!1)}}var Pc=null,jc=0;function cg(i){if(!i.idVisit)return null;let s=i.now??Date.now(),c=i.store??Qr();Tc(i.after,i.idVisit,i.tipe,c);let u=JSON.stringify([i.idVisit,i.aksi,i.after]);if(Pc===u&&s-jc<5e3)return null;Pc=u,jc=s;let f={at:s,aksi:i.aksi,id_resume:i.idResume??"",user:i.user??rg(),tipe:i.tipe,before:i.before??{},after:i.after,changed:Ec(i.before??{},i.after),client_id:Gm()},b=$i(i.idVisit,i.tipe,c);b.push(f),Ui(b,i.idVisit,i.tipe,c),Tc(i.after,i.idVisit,i.tipe,c);try{sg(f,i.idVisit,i.fetcher??fetch,c,i.tipe)}catch{}return f}function ug(i){if(i!=null){if(typeof i=="string")return i;if(typeof i=="number"||typeof i=="boolean")return String(i);if(Array.isArray(i))return i.map(s=>{if(typeof s=="string")return s;try{return JSON.stringify(s)??""}catch{return""}});try{return JSON.stringify(i)??""}catch{return""}}}function Ac(i){let s={};if(!i||typeof i!="object"||Array.isArray(i))return s;for(let c of Object.keys(i)){let u=ug(i[c]);u!==void 0&&(s[c]=u)}return s}function dg(i,s){try{if(!i||typeof i!="object")return null;let c=i.waktu?Date.parse(i.waktu):NaN;if(!Number.isFinite(c))return null;let u=Ac(i.after),f=Ac(i.before),b=i.tipe==="rajal"?"rajal":i.tipe==="ranap"?"ranap":s,h=Array.isArray(i.changed)?i.changed.filter(C=>typeof C=="string"):Ec(f,u),w=typeof i.client_id=="string"&&i.client_id?i.client_id:void 0;return{at:c,aksi:i.aksi==="buat"?"buat":"ubah",id_resume:typeof i.id_resume=="string"?i.id_resume:"",user:typeof i.user=="string"&&i.user?i.user:"petugas",tipe:b,before:f,after:u,changed:h,...w?{client_id:w}:{}}}catch{return null}}function Lc(i){if(i.client_id)return"cid:"+i.client_id;try{return"h:"+i.at+"|"+i.user+"|"+i.aksi+"|"+JSON.stringify(i.after)}catch{return"h:"+i.at+"|"+i.user+"|"+i.aksi}}function fg(i,s){let c=new Set(i.map(Lc)),u=i.slice();for(let f of s){let b=Lc(f);c.has(b)||(c.add(b),u.push(f))}return u.sort((f,b)=>f.at-b.at),u.slice(-zc)}var pg="'Roboto','Segoe UI',system-ui,-apple-system,Arial,sans-serif";function mg(i){try{document.querySelector("#ext-rv-history-overlay")?.remove()}catch{}let s=i.store??Qr(),c=$i(i.idVisit,i.tipe,s).slice().reverse(),u=i.zIndex??99998,f=document.createElement("div");f.id="ext-rv-history-overlay",f.style.cssText=`position:fixed;inset:0;z-index:${u};background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:24px;`,f.addEventListener("click",function(k){k.target===f&&f.remove()});let b=document.createElement("div");b.style.cssText="background:#fff;border-radius:12px;max-width:680px;width:100%;max-height:82vh;display:flex;flex-direction:column;overflow:hidden;font-size:16px!important;line-height:1.6!important;color:#1c2530;font-family:"+pg+"!important;",f.appendChild(b);let h=document.createElement("div");h.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #d0d5dd;font-weight:700;";let w=document.createElement("span");w.textContent=`${i.title??"Riwayat Resume"} (${c.length})`,h.appendChild(w);let C=document.createElement("button");C.type="button",C.textContent="\xD7",C.style.cssText="border:none;background:#f8fafc;width:32px;height:32px;border-radius:50%;font-family:inherit!important;font-size:16px!important;line-height:1!important;cursor:pointer;",C.onclick=function(){f.remove()},h.appendChild(C),b.appendChild(h);let x=document.createElement("div");x.style.cssText="padding:14px 18px;overflow-y:auto;",b.appendChild(x);let y=k=>{if(c=k,w.textContent=`${i.title??"Riwayat Resume"} (${c.length})`,x.replaceChildren(),!c.length){x.textContent="Belum ada riwayat untuk kunjungan ini. Riwayat tercatat otomatis setiap kali Simpan ditekan.";return}c.forEach(function(S,q){let X=c.length-q,B=document.createElement("div");B.style.cssText="border:1px solid #d0d5dd;border-radius:8px;padding:10px 12px;margin-bottom:10px;";let G=document.createElement("div");G.style.fontWeight="600";let oe=S.user?` \u2014 oleh ${S.user}`:"",U=S.after?._source==="verif_action",V=U?" \u2014 verifikasi berkas":"";G.textContent=`#${X} \u2014 ${new Date(S.at).toLocaleString("id-ID")} \u2014 ${S.aksi==="buat"?"Buat baru":"Ubah"}${oe} \u2014 ${S.changed.length} field berubah${V}`,B.appendChild(G);let N=document.createElement("div");N.style.cssText="display:none;margin-top:8px;background:#f8fafc;border-radius:6px;padding:8px 10px;font-size:13px;line-height:1.6;max-height:180px;overflow-y:auto;white-space:pre-wrap;",S.changed.length?N.textContent=S.changed.map(function(L){return L+": "+Nc(S.before[L])+" \u2192 "+Nc(S.after[L])}).join(`
`):N.textContent="Tidak ada perbedaan field.",B.appendChild(N);let I=document.createElement("div");I.style.cssText="margin-top:8px;display:flex;gap:8px;";let ae=document.createElement("button");ae.type="button",ae.textContent="Lihat",ae.style.cssText="border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",ae.onclick=function(){N.style.display=N.style.display==="none"?"block":"none"},I.appendChild(ae);let re=document.createElement("button");if(re.type="button",re.textContent="Salin ke Form",re.style.cssText="background:#00875a;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",re.onclick=function(){try{i.onApply(S.after),f.remove()}catch{}},U){let L=document.createElement("span");L.textContent="Entri verifikasi \u2014 bukan snapshot form, tidak untuk disalin.",L.style.cssText="align-self:center;color:#92400e;background:#fef3c7;border-radius:6px;padding:4px 10px;font-size:12px;line-height:1.5;",I.appendChild(L)}else I.appendChild(re);B.appendChild(I),x.appendChild(B)})};y(c);try{document.body.appendChild(f)}catch{}if(i.idVisit){let k=Di();if(k)try{let S=document.createElement("div");S.textContent=k+" \u2014 riwayat hanya dari PC ini.",S.style.cssText="margin-top:10px;padding:8px 10px;background:#fef3c7;color:#92400e;border-radius:6px;font-size:13px;line-height:1.5;",x.appendChild(S)}catch{}else try{Xm(i.idVisit,i.tipe).then(S=>{try{if(!S.length||!f.isConnected)return;let q=[];for(let G of S){let oe=dg(G,i.tipe);oe&&q.push(oe)}if(!q.length)return;let X=$i(i.idVisit,i.tipe,s),B=fg(X,q);if(B.length===X.length)return;Ui(B,i.idVisit,i.tipe,s),y(B.slice().reverse());try{document.dispatchEvent(new CustomEvent("ext-rv-history-merged",{detail:{idVisit:i.idVisit,tipe:i.tipe,count:B.length}}))}catch{}}catch{}})}catch{}}}function rt(i,s){let c=i[s];return Array.isArray(c)?c:c===void 0?[]:[c]}function ct(i,s){let c=i[s];return typeof c=="string"?c:Array.isArray(c)?c[0]??"":""}function gg(i){let s=i.clinicalNotes,c=i.vitalSigns,u={anamnesa:s.anamnesa,pemeriksaan_fisik:s.pemeriksaan_fisik,catatan:s.catatan,tindakan:s.tindakan,terapi_pengobatan:s.terapi_pengobatan,tensi:c.tensi,nadi:c.nadi,suhu:c.suhu,nafas:c.nafas,tinggi:c.tinggi,berat:c.berat},f=s;for(let b of["jenis_kasus","status_kasus","tindak_lanjut"])f[b]&&(u[b]=f[b]);return u["kode10[]"]=i.diagnosa.map(b=>b.kode10),u["idicd[]"]=i.diagnosa.map(b=>b.idicd),u["nama[]"]=i.diagnosa.map(b=>b.namaDiagnosa),u["kasus_diagnosa[]"]=i.diagnosa.map(b=>b.kasus),u["komplikasi[]"]=i.diagnosa.map(b=>b.komplikasi),u["kode9[]"]=i.tindakan.map(b=>b.kode9),u["idicdTindakan[]"]=i.tindakan.map(b=>b.idicdTindakan),u["namaTindakan[]"]=i.tindakan.map(b=>b.namaTindakan),u["komorbid[]"]=i.tindakan.map(b=>b.komorbid),u["kategoriProsedur[]"]=i.tindakan.map(b=>b.kategoriProsedur),u}function hg(i,s){if(i._source==="verif_action")return s;let c=Math.max(rt(i,"kode10[]").length,rt(i,"idicd[]").length,rt(i,"nama[]").length),u=[];for(let h=0;h<c;h++){let w=rt(i,"idicd[]")[h]??"",C=rt(i,"kode10[]")[h]??"",x=rt(i,"nama[]")[h]??"";!w&&!C&&!x||u.push({idicd:w,kode10:C,namaDiagnosa:x,kasus:rt(i,"kasus_diagnosa[]")[h]??"",komplikasi:rt(i,"komplikasi[]")[h]??""})}let f=Math.max(rt(i,"kode9[]").length,rt(i,"idicdTindakan[]").length,rt(i,"namaTindakan[]").length),b=[];for(let h=0;h<f;h++){let w=rt(i,"idicdTindakan[]")[h]??"",C=rt(i,"kode9[]")[h]??"",x=rt(i,"namaTindakan[]")[h]??"";!w&&!C&&!x||b.push({idicdTindakan:w,kode9:C,namaTindakan:x,komorbid:rt(i,"komorbid[]")[h]??"",kategoriProsedur:rt(i,"kategoriProsedur[]")[h]??"",snomedProsedur:"",codeProsedur:""})}return{patientInfo:s.patientInfo,clinicalNotes:{anamnesa:ct(i,"anamnesa"),pemeriksaan_fisik:ct(i,"pemeriksaan_fisik"),catatan:ct(i,"catatan"),tindakan:ct(i,"tindakan"),terapi_pengobatan:ct(i,"terapi_pengobatan"),jenis_kasus:ct(i,"jenis_kasus"),status_kasus:ct(i,"status_kasus"),tindak_lanjut:ct(i,"tindak_lanjut")},vitalSigns:{tensi:ct(i,"tensi"),nadi:ct(i,"nadi"),suhu:ct(i,"suhu"),nafas:ct(i,"nafas"),tinggi:ct(i,"tinggi"),berat:ct(i,"berat")},diagnosa:u,tindakan:b}}var Hi=Ne(Et(),1);function Rc(i){var s,c,u="";if(typeof i=="string"||typeof i=="number")u+=i;else if(typeof i=="object")if(Array.isArray(i)){var f=i.length;for(s=0;s<f;s++)i[s]&&(c=Rc(i[s]))&&(u&&(u+=" "),u+=c)}else for(c in i)i[c]&&(u&&(u+=" "),u+=c);return u}function Oc(){for(var i,s,c=0,u="",f=arguments.length;c<f;c++)(i=arguments[c])&&(s=Rc(i))&&(u&&(u+=" "),u+=s);return u}var bg=(i,s)=>{let c=new Array(i.length+s.length);for(let u=0;u<i.length;u++)c[u]=i[u];for(let u=0;u<s.length;u++)c[i.length+u]=s[u];return c},vg=(i,s)=>({classGroupId:i,validator:s}),Dc=(i=new Map,s=null,c)=>({nextPart:i,validators:s,classGroupId:c}),Ic=[],yg="arbitrary..",wg=i=>{let s=kg(i),{conflictingClassGroups:c,conflictingClassGroupModifiers:u}=i;return{getClassGroupId:f=>{if(f.startsWith("[")&&f.endsWith("]"))return xg(f);let b=f.split("-"),h=b[0]===""&&b.length>1?1:0;return Fc(b,h,s)},getConflictingClassGroupIds:(f,b)=>{if(b){let h=u[f],w=c[f];return h?w?bg(w,h):h:w||Ic}return c[f]||Ic}}},Fc=(i,s,c)=>{if(i.length-s===0)return c.classGroupId;let u=i[s],f=c.nextPart.get(u);if(f){let C=Fc(i,s+1,f);if(C)return C}let b=c.validators;if(b===null)return;let h=s===0?i.join("-"):i.slice(s).join("-"),w=b.length;for(let C=0;C<w;C++){let x=b[C];if(x.validator(h))return x.classGroupId}},xg=i=>i.slice(1,-1).indexOf(":")===-1?void 0:(()=>{let s=i.slice(1,-1),c=s.indexOf(":"),u=s.slice(0,c);return u?yg+u:void 0})(),kg=i=>{let{theme:s,classGroups:c}=i;return Sg(c,s)},Sg=(i,s)=>{let c=Dc();for(let u in i){let f=i[u];qi(f,c,u,s)}return c},qi=(i,s,c,u)=>{let f=i.length;for(let b=0;b<f;b++){let h=i[b];Cg(h,s,c,u)}},Cg=(i,s,c,u)=>{if(typeof i=="string"){zg(i,s,c);return}if(typeof i=="function"){_g(i,s,c,u);return}Eg(i,s,c,u)},zg=(i,s,c)=>{let u=i===""?s:Mc(s,i);u.classGroupId=c},_g=(i,s,c,u)=>{if(Ng(i)){qi(i(u),s,c,u);return}s.validators===null&&(s.validators=[]),s.validators.push(vg(c,i))},Eg=(i,s,c,u)=>{let f=Object.entries(i),b=f.length;for(let h=0;h<b;h++){let[w,C]=f[h];qi(C,Mc(s,w),c,u)}},Mc=(i,s)=>{let c=i,u=s.split("-"),f=u.length;for(let b=0;b<f;b++){let h=u[b],w=c.nextPart.get(h);w||(w=Dc(),c.nextPart.set(h,w)),c=w}return c},Ng=i=>"isThemeGetter"in i&&i.isThemeGetter===!0,Tg=i=>{if(i<1)return{get:()=>{},set:()=>{}};let s=0,c=Object.create(null),u=Object.create(null),f=(b,h)=>{c[b]=h,s++,s>i&&(s=0,u=c,c=Object.create(null))};return{get(b){let h=c[b];if(h!==void 0)return h;if((h=u[b])!==void 0)return f(b,h),h},set(b,h){b in c?c[b]=h:f(b,h)}}},Pg=[],$c=(i,s,c,u,f)=>({modifiers:i,hasImportantModifier:s,baseClassName:c,maybePostfixModifierPosition:u,isExternal:f}),jg=i=>{let{prefix:s,experimentalParseClassName:c}=i,u=f=>{let b=[],h=0,w=0,C=0,x,y=f.length;for(let B=0;B<y;B++){let G=f[B];if(h===0&&w===0){if(G===":"){b.push(f.slice(C,B)),C=B+1;continue}if(G==="/"){x=B;continue}}G==="["?h++:G==="]"?h--:G==="("?w++:G===")"&&w--}let k=b.length===0?f:f.slice(C),S=k,q=!1;k.endsWith("!")?(S=k.slice(0,-1),q=!0):k.startsWith("!")&&(S=k.slice(1),q=!0);let X=x&&x>C?x-C:void 0;return $c(b,q,S,X)};if(s){let f=s+":",b=u;u=h=>h.startsWith(f)?b(h.slice(f.length)):$c(Pg,!1,h,void 0,!0)}if(c){let f=u;u=b=>c({className:b,parseClassName:f})}return u},Ag=i=>{let s=new Map;return i.orderSensitiveModifiers.forEach((c,u)=>{s.set(c,1e6+u)}),c=>{let u=[],f=[];for(let b=0;b<c.length;b++){let h=c[b],w=h[0]==="[",C=s.has(h);w||C?(f.length>0&&(f.sort(),u.push(...f),f=[]),u.push(h)):f.push(h)}return f.length>0&&(f.sort(),u.push(...f)),u}},Lg=i=>({cache:Tg(i.cacheSize),parseClassName:jg(i),sortModifiers:Ag(i),postfixLookupClassGroupIds:Rg(i),...wg(i)}),Rg=i=>{let s=Object.create(null),c=i.postfixLookupClassGroups;if(c)for(let u=0;u<c.length;u++)s[c[u]]=!0;return s},Og=/\s+/,Dg=(i,s)=>{let{parseClassName:c,getClassGroupId:u,getConflictingClassGroupIds:f,sortModifiers:b,postfixLookupClassGroupIds:h}=s,w=[],C=i.trim().split(Og),x="";for(let y=C.length-1;y>=0;y-=1){let k=C[y],{isExternal:S,modifiers:q,hasImportantModifier:X,baseClassName:B,maybePostfixModifierPosition:G}=c(k);if(S){x=k+(x.length>0?" "+x:x);continue}let oe=!!G,U;if(oe){let re=B.substring(0,G);U=u(re);let L=U&&h[U]?u(B):void 0;L&&L!==U&&(U=L,oe=!1)}else U=u(B);if(!U){if(!oe){x=k+(x.length>0?" "+x:x);continue}if(U=u(B),!U){x=k+(x.length>0?" "+x:x);continue}oe=!1}let V=q.length===0?"":q.length===1?q[0]:b(q).join(":"),N=X?V+"!":V,I=N+U;if(w.indexOf(I)>-1)continue;w.push(I);let ae=f(U,oe);for(let re=0;re<ae.length;++re){let L=ae[re];w.push(N+L)}x=k+(x.length>0?" "+x:x)}return x},Ig=(...i)=>{let s=0,c,u,f="";for(;s<i.length;)(c=i[s++])&&(u=Uc(c))&&(f&&(f+=" "),f+=u);return f},Uc=i=>{if(typeof i=="string")return i;let s,c="";for(let u=0;u<i.length;u++)i[u]&&(s=Uc(i[u]))&&(c&&(c+=" "),c+=s);return c},Fg=(i,...s)=>{let c,u,f,b,h=C=>{let x=s.reduce((y,k)=>k(y),i());return c=Lg(x),u=c.cache.get,f=c.cache.set,b=w,w(C)},w=C=>{let x=u(C);if(x)return x;let y=Dg(C,c);return f(C,y),y};return b=h,(...C)=>b(Ig(...C))},Mg=[],Ve=i=>{let s=c=>c[i]||Mg;return s.isThemeGetter=!0,s},Hc=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,qc=/^\((?:(\w[\w-]*):)?(.+)\)$/i,$g=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,Ug=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,Hg=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,qg=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,Bg=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,Vg=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,wr=i=>$g.test(i),ce=i=>!!i&&!Number.isNaN(Number(i)),qt=i=>!!i&&Number.isInteger(Number(i)),Bi=i=>i.endsWith("%")&&ce(i.slice(0,-1)),Gt=i=>Ug.test(i),Bc=()=>!0,Wg=i=>Hg.test(i)&&!qg.test(i),Vi=()=>!1,Yg=i=>Bg.test(i),Qg=i=>Vg.test(i),Kg=i=>!W(i)&&!Y(i),Xg=i=>i.startsWith("@container")&&(i[10]==="/"&&i[11]!==void 0||i[11]==="s"&&i[16]!==void 0&&i.startsWith("-size/",10)||i[11]==="n"&&i[18]!==void 0&&i.startsWith("-normal/",10)),Gg=i=>xr(i,Xc,Vi),W=i=>Hc.test(i),Kr=i=>xr(i,Gc,Wg),Vc=i=>xr(i,oh,ce),Jg=i=>xr(i,Zc,Bc),Zg=i=>xr(i,Jc,Vi),Wc=i=>xr(i,Qc,Vi),eh=i=>xr(i,Kc,Qg),uo=i=>xr(i,eu,Yg),Y=i=>qc.test(i),pa=i=>Xr(i,Gc),th=i=>Xr(i,Jc),Yc=i=>Xr(i,Qc),rh=i=>Xr(i,Xc),nh=i=>Xr(i,Kc),fo=i=>Xr(i,eu,!0),ah=i=>Xr(i,Zc,!0),xr=(i,s,c)=>{let u=Hc.exec(i);return u?u[1]?s(u[1]):c(u[2]):!1},Xr=(i,s,c=!1)=>{let u=qc.exec(i);return u?u[1]?s(u[1]):c:!1},Qc=i=>i==="position"||i==="percentage",Kc=i=>i==="image"||i==="url",Xc=i=>i==="length"||i==="size"||i==="bg-size",Gc=i=>i==="length",oh=i=>i==="number",Jc=i=>i==="family-name",Zc=i=>i==="number"||i==="weight",eu=i=>i==="shadow",ih=()=>{let i=Ve("color"),s=Ve("font"),c=Ve("text"),u=Ve("font-weight"),f=Ve("tracking"),b=Ve("leading"),h=Ve("breakpoint"),w=Ve("container"),C=Ve("spacing"),x=Ve("radius"),y=Ve("shadow"),k=Ve("inset-shadow"),S=Ve("text-shadow"),q=Ve("drop-shadow"),X=Ve("blur"),B=Ve("perspective"),G=Ve("aspect"),oe=Ve("ease"),U=Ve("animate"),V=()=>["auto","avoid","all","avoid-page","page","left","right","column"],N=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],I=()=>[...N(),Y,W],ae=()=>["auto","hidden","clip","visible","scroll"],re=()=>["auto","contain","none"],L=()=>[Y,W,C],Q=()=>[wr,"full","auto",...L()],ue=()=>[qt,"none","subgrid",Y,W],at=()=>["auto",{span:["full",qt,Y,W]},qt,Y,W],De=()=>[qt,"auto",Y,W],Ye=()=>["auto","min","max","fr",Y,W],Dt=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],Qe=()=>["start","end","center","stretch","center-safe","end-safe"],D=()=>["auto",...L()],O=()=>[wr,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...L()],M=()=>[wr,"screen","full","dvw","lvw","svw","min","max","fit",...L()],ge=()=>[wr,"screen","full","lh","dvh","lvh","svh","min","max","fit",...L()],$=()=>[i,Y,W],ot=()=>[...N(),Yc,Wc,{position:[Y,W]}],g=()=>["no-repeat",{repeat:["","x","y","space","round"]}],R=()=>["auto","cover","contain",rh,Gg,{size:[Y,W]}],F=()=>[Bi,pa,Kr],H=()=>["","none","full",x,Y,W],ee=()=>["",ce,pa,Kr],ie=()=>["solid","dashed","dotted","double"],ve=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],be=()=>[ce,Bi,Yc,Wc],Re=()=>["","none",X,Y,W],Vt=()=>["none",ce,Y,W],er=()=>["none",ce,Y,W],Gr=()=>[ce,Y,W],Jr=()=>[wr,"full",...L()];return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[Gt],breakpoint:[Gt],color:[Bc],container:[Gt],"drop-shadow":[Gt],ease:["in","out","in-out"],font:[Kg],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[Gt],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[Gt],shadow:[Gt],spacing:["px",ce],text:[Gt],"text-shadow":[Gt],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",wr,W,Y,G]}],container:["container"],"container-type":[{"@container":["","normal","size",Y,W]}],"container-named":[Xg],columns:[{columns:[ce,W,Y,w]}],"break-after":[{"break-after":V()}],"break-before":[{"break-before":V()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:I()}],overflow:[{overflow:ae()}],"overflow-x":[{"overflow-x":ae()}],"overflow-y":[{"overflow-y":ae()}],overscroll:[{overscroll:re()}],"overscroll-x":[{"overscroll-x":re()}],"overscroll-y":[{"overscroll-y":re()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:Q()}],"inset-x":[{"inset-x":Q()}],"inset-y":[{"inset-y":Q()}],start:[{"inset-s":Q(),start:Q()}],end:[{"inset-e":Q(),end:Q()}],"inset-bs":[{"inset-bs":Q()}],"inset-be":[{"inset-be":Q()}],top:[{top:Q()}],right:[{right:Q()}],bottom:[{bottom:Q()}],left:[{left:Q()}],visibility:["visible","invisible","collapse"],z:[{z:[qt,"auto",Y,W]}],basis:[{basis:[wr,"full","auto",w,...L()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[ce,wr,"auto","initial","none",W]}],grow:[{grow:["",ce,Y,W]}],shrink:[{shrink:["",ce,Y,W]}],order:[{order:[qt,"first","last","none",Y,W]}],"grid-cols":[{"grid-cols":ue()}],"col-start-end":[{col:at()}],"col-start":[{"col-start":De()}],"col-end":[{"col-end":De()}],"grid-rows":[{"grid-rows":ue()}],"row-start-end":[{row:at()}],"row-start":[{"row-start":De()}],"row-end":[{"row-end":De()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":Ye()}],"auto-rows":[{"auto-rows":Ye()}],gap:[{gap:L()}],"gap-x":[{"gap-x":L()}],"gap-y":[{"gap-y":L()}],"justify-content":[{justify:[...Dt(),"normal"]}],"justify-items":[{"justify-items":[...Qe(),"normal"]}],"justify-self":[{"justify-self":["auto",...Qe()]}],"align-content":[{content:["normal",...Dt()]}],"align-items":[{items:[...Qe(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...Qe(),{baseline:["","last"]}]}],"place-content":[{"place-content":Dt()}],"place-items":[{"place-items":[...Qe(),"baseline"]}],"place-self":[{"place-self":["auto",...Qe()]}],p:[{p:L()}],px:[{px:L()}],py:[{py:L()}],ps:[{ps:L()}],pe:[{pe:L()}],pbs:[{pbs:L()}],pbe:[{pbe:L()}],pt:[{pt:L()}],pr:[{pr:L()}],pb:[{pb:L()}],pl:[{pl:L()}],m:[{m:D()}],mx:[{mx:D()}],my:[{my:D()}],ms:[{ms:D()}],me:[{me:D()}],mbs:[{mbs:D()}],mbe:[{mbe:D()}],mt:[{mt:D()}],mr:[{mr:D()}],mb:[{mb:D()}],ml:[{ml:D()}],"space-x":[{"space-x":L()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":L()}],"space-y-reverse":["space-y-reverse"],size:[{size:O()}],"inline-size":[{inline:["auto",...M()]}],"min-inline-size":[{"min-inline":["auto",...M()]}],"max-inline-size":[{"max-inline":["none",...M()]}],"block-size":[{block:["auto",...ge()]}],"min-block-size":[{"min-block":["auto",...ge()]}],"max-block-size":[{"max-block":["none",...ge()]}],w:[{w:[w,"screen",...O()]}],"min-w":[{"min-w":[w,"screen","none",...O()]}],"max-w":[{"max-w":[w,"screen","none","prose",{screen:[h]},...O()]}],h:[{h:["screen","lh",...O()]}],"min-h":[{"min-h":["screen","lh","none",...O()]}],"max-h":[{"max-h":["screen","lh",...O()]}],"font-size":[{text:["base",c,pa,Kr]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[u,ah,Jg]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",Bi,W]}],"font-family":[{font:[th,Zg,s]}],"font-features":[{"font-features":[W]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[f,Y,W]}],"line-clamp":[{"line-clamp":[ce,"none",Y,Vc]}],leading:[{leading:[b,...L()]}],"list-image":[{"list-image":["none",Y,W]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",Y,W]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:$()}],"text-color":[{text:$()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...ie(),"wavy"]}],"text-decoration-thickness":[{decoration:[ce,"from-font","auto",Y,Kr]}],"text-decoration-color":[{decoration:$()}],"underline-offset":[{"underline-offset":[ce,"auto",Y,W]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:L()}],"tab-size":[{tab:[qt,Y,W]}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",Y,W]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",Y,W]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:ot()}],"bg-repeat":[{bg:g()}],"bg-size":[{bg:R()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},qt,Y,W],radial:["",Y,W],conic:[qt,Y,W]},nh,eh]}],"bg-color":[{bg:$()}],"gradient-from-pos":[{from:F()}],"gradient-via-pos":[{via:F()}],"gradient-to-pos":[{to:F()}],"gradient-from":[{from:$()}],"gradient-via":[{via:$()}],"gradient-to":[{to:$()}],rounded:[{rounded:H()}],"rounded-s":[{"rounded-s":H()}],"rounded-e":[{"rounded-e":H()}],"rounded-t":[{"rounded-t":H()}],"rounded-r":[{"rounded-r":H()}],"rounded-b":[{"rounded-b":H()}],"rounded-l":[{"rounded-l":H()}],"rounded-ss":[{"rounded-ss":H()}],"rounded-se":[{"rounded-se":H()}],"rounded-ee":[{"rounded-ee":H()}],"rounded-es":[{"rounded-es":H()}],"rounded-tl":[{"rounded-tl":H()}],"rounded-tr":[{"rounded-tr":H()}],"rounded-br":[{"rounded-br":H()}],"rounded-bl":[{"rounded-bl":H()}],"border-w":[{border:ee()}],"border-w-x":[{"border-x":ee()}],"border-w-y":[{"border-y":ee()}],"border-w-s":[{"border-s":ee()}],"border-w-e":[{"border-e":ee()}],"border-w-bs":[{"border-bs":ee()}],"border-w-be":[{"border-be":ee()}],"border-w-t":[{"border-t":ee()}],"border-w-r":[{"border-r":ee()}],"border-w-b":[{"border-b":ee()}],"border-w-l":[{"border-l":ee()}],"divide-x":[{"divide-x":ee()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":ee()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...ie(),"hidden","none"]}],"divide-style":[{divide:[...ie(),"hidden","none"]}],"border-color":[{border:$()}],"border-color-x":[{"border-x":$()}],"border-color-y":[{"border-y":$()}],"border-color-s":[{"border-s":$()}],"border-color-e":[{"border-e":$()}],"border-color-bs":[{"border-bs":$()}],"border-color-be":[{"border-be":$()}],"border-color-t":[{"border-t":$()}],"border-color-r":[{"border-r":$()}],"border-color-b":[{"border-b":$()}],"border-color-l":[{"border-l":$()}],"divide-color":[{divide:$()}],"outline-style":[{outline:[...ie(),"none","hidden"]}],"outline-offset":[{"outline-offset":[ce,Y,W]}],"outline-w":[{outline:["",ce,pa,Kr]}],"outline-color":[{outline:$()}],shadow:[{shadow:["","none",y,fo,uo]}],"shadow-color":[{shadow:$()}],"inset-shadow":[{"inset-shadow":["none",k,fo,uo]}],"inset-shadow-color":[{"inset-shadow":$()}],"ring-w":[{ring:ee()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:$()}],"ring-offset-w":[{"ring-offset":[ce,Kr]}],"ring-offset-color":[{"ring-offset":$()}],"inset-ring-w":[{"inset-ring":ee()}],"inset-ring-color":[{"inset-ring":$()}],"text-shadow":[{"text-shadow":["none",S,fo,uo]}],"text-shadow-color":[{"text-shadow":$()}],opacity:[{opacity:[ce,Y,W]}],"mix-blend":[{"mix-blend":[...ve(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":ve()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[ce]}],"mask-image-linear-from-pos":[{"mask-linear-from":be()}],"mask-image-linear-to-pos":[{"mask-linear-to":be()}],"mask-image-linear-from-color":[{"mask-linear-from":$()}],"mask-image-linear-to-color":[{"mask-linear-to":$()}],"mask-image-t-from-pos":[{"mask-t-from":be()}],"mask-image-t-to-pos":[{"mask-t-to":be()}],"mask-image-t-from-color":[{"mask-t-from":$()}],"mask-image-t-to-color":[{"mask-t-to":$()}],"mask-image-r-from-pos":[{"mask-r-from":be()}],"mask-image-r-to-pos":[{"mask-r-to":be()}],"mask-image-r-from-color":[{"mask-r-from":$()}],"mask-image-r-to-color":[{"mask-r-to":$()}],"mask-image-b-from-pos":[{"mask-b-from":be()}],"mask-image-b-to-pos":[{"mask-b-to":be()}],"mask-image-b-from-color":[{"mask-b-from":$()}],"mask-image-b-to-color":[{"mask-b-to":$()}],"mask-image-l-from-pos":[{"mask-l-from":be()}],"mask-image-l-to-pos":[{"mask-l-to":be()}],"mask-image-l-from-color":[{"mask-l-from":$()}],"mask-image-l-to-color":[{"mask-l-to":$()}],"mask-image-x-from-pos":[{"mask-x-from":be()}],"mask-image-x-to-pos":[{"mask-x-to":be()}],"mask-image-x-from-color":[{"mask-x-from":$()}],"mask-image-x-to-color":[{"mask-x-to":$()}],"mask-image-y-from-pos":[{"mask-y-from":be()}],"mask-image-y-to-pos":[{"mask-y-to":be()}],"mask-image-y-from-color":[{"mask-y-from":$()}],"mask-image-y-to-color":[{"mask-y-to":$()}],"mask-image-radial":[{"mask-radial":[Y,W]}],"mask-image-radial-from-pos":[{"mask-radial-from":be()}],"mask-image-radial-to-pos":[{"mask-radial-to":be()}],"mask-image-radial-from-color":[{"mask-radial-from":$()}],"mask-image-radial-to-color":[{"mask-radial-to":$()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":N()}],"mask-image-conic-pos":[{"mask-conic":[ce]}],"mask-image-conic-from-pos":[{"mask-conic-from":be()}],"mask-image-conic-to-pos":[{"mask-conic-to":be()}],"mask-image-conic-from-color":[{"mask-conic-from":$()}],"mask-image-conic-to-color":[{"mask-conic-to":$()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:ot()}],"mask-repeat":[{mask:g()}],"mask-size":[{mask:R()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",Y,W]}],filter:[{filter:["","none",Y,W]}],blur:[{blur:Re()}],brightness:[{brightness:[ce,Y,W]}],contrast:[{contrast:[ce,Y,W]}],"drop-shadow":[{"drop-shadow":["","none",q,fo,uo]}],"drop-shadow-color":[{"drop-shadow":$()}],grayscale:[{grayscale:["",ce,Y,W]}],"hue-rotate":[{"hue-rotate":[ce,Y,W]}],invert:[{invert:["",ce,Y,W]}],saturate:[{saturate:[ce,Y,W]}],sepia:[{sepia:["",ce,Y,W]}],"backdrop-filter":[{"backdrop-filter":["","none",Y,W]}],"backdrop-blur":[{"backdrop-blur":Re()}],"backdrop-brightness":[{"backdrop-brightness":[ce,Y,W]}],"backdrop-contrast":[{"backdrop-contrast":[ce,Y,W]}],"backdrop-grayscale":[{"backdrop-grayscale":["",ce,Y,W]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[ce,Y,W]}],"backdrop-invert":[{"backdrop-invert":["",ce,Y,W]}],"backdrop-opacity":[{"backdrop-opacity":[ce,Y,W]}],"backdrop-saturate":[{"backdrop-saturate":[ce,Y,W]}],"backdrop-sepia":[{"backdrop-sepia":["",ce,Y,W]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":L()}],"border-spacing-x":[{"border-spacing-x":L()}],"border-spacing-y":[{"border-spacing-y":L()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",Y,W]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[ce,"initial",Y,W]}],ease:[{ease:["linear","initial",oe,Y,W]}],delay:[{delay:[ce,Y,W]}],animate:[{animate:["none",U,Y,W]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[B,Y,W]}],"perspective-origin":[{"perspective-origin":I()}],rotate:[{rotate:Vt()}],"rotate-x":[{"rotate-x":Vt()}],"rotate-y":[{"rotate-y":Vt()}],"rotate-z":[{"rotate-z":Vt()}],scale:[{scale:er()}],"scale-x":[{"scale-x":er()}],"scale-y":[{"scale-y":er()}],"scale-z":[{"scale-z":er()}],"scale-3d":["scale-3d"],skew:[{skew:Gr()}],"skew-x":[{"skew-x":Gr()}],"skew-y":[{"skew-y":Gr()}],transform:[{transform:[Y,W,"","none","gpu","cpu"]}],"transform-origin":[{origin:I()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:Jr()}],"translate-x":[{"translate-x":Jr()}],"translate-y":[{"translate-y":Jr()}],"translate-z":[{"translate-z":Jr()}],"translate-none":["translate-none"],zoom:[{zoom:[qt,Y,W]}],accent:[{accent:$()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:$()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",Y,W]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scrollbar-thumb-color":[{"scrollbar-thumb":$()}],"scrollbar-track-color":[{"scrollbar-track":$()}],"scrollbar-gutter":[{"scrollbar-gutter":["auto","stable","both"]}],"scrollbar-w":[{scrollbar:["auto","thin","none"]}],"scroll-m":[{"scroll-m":L()}],"scroll-mx":[{"scroll-mx":L()}],"scroll-my":[{"scroll-my":L()}],"scroll-ms":[{"scroll-ms":L()}],"scroll-me":[{"scroll-me":L()}],"scroll-mbs":[{"scroll-mbs":L()}],"scroll-mbe":[{"scroll-mbe":L()}],"scroll-mt":[{"scroll-mt":L()}],"scroll-mr":[{"scroll-mr":L()}],"scroll-mb":[{"scroll-mb":L()}],"scroll-ml":[{"scroll-ml":L()}],"scroll-p":[{"scroll-p":L()}],"scroll-px":[{"scroll-px":L()}],"scroll-py":[{"scroll-py":L()}],"scroll-ps":[{"scroll-ps":L()}],"scroll-pe":[{"scroll-pe":L()}],"scroll-pbs":[{"scroll-pbs":L()}],"scroll-pbe":[{"scroll-pbe":L()}],"scroll-pt":[{"scroll-pt":L()}],"scroll-pr":[{"scroll-pr":L()}],"scroll-pb":[{"scroll-pb":L()}],"scroll-pl":[{"scroll-pl":L()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",Y,W]}],fill:[{fill:["none",...$()]}],"stroke-w":[{stroke:[ce,pa,Kr,Vc]}],stroke:[{stroke:["none",...$()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{"container-named":["container-type"],overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},postfixLookupClassGroups:["container-type"],orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}},lh=Fg(ih);function yn(...i){return lh(Oc(i))}var sh=Ne(it(),1),wn=(0,Hi.forwardRef)(({className:i,autoResize:s=!0,onChange:c,...u},f)=>{let b=(0,Hi.useRef)(null),h=f||b;(0,Hi.useEffect)(()=>{s&&h.current&&(h.current.style.height="auto",h.current.style.height=h.current.scrollHeight+"px")},[u.value,s,h]);let w=C=>{s&&(C.target.style.height="auto",C.target.style.height=C.target.scrollHeight+"px"),c?.(C)};return(0,sh.jsx)("textarea",{ref:h,className:yn("flex w-full rounded-lg border-2 border-input bg-background px-3.5 py-3 text-base text-foreground leading-[1.7]","placeholder:text-muted-foreground","focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 border-primary/50","disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted","resize-y min-h-[80px]",i),onChange:w,...u})});wn.displayName="Textarea";var tu=Ne(it(),1);function xn({className:i,required:s,helperText:c,children:u,...f}){return(0,tu.jsxs)("label",{className:yn("block text-base font-semibold text-foreground uppercase tracking-[0.03em] mb-1.5",i),...f,children:[u,s&&(0,tu.jsx)("span",{className:"text-destructive ml-1","aria-hidden":"true",children:"*"})]})}var po=Ne(it(),1);function ma({title:i,children:s,className:c}){return(0,po.jsxs)("div",{className:yn("bg-background border-2 border-border rounded-xl mb-4 overflow-hidden shadow-sm",c),children:[(0,po.jsxs)("div",{className:"px-4 py-3 bg-primary/5 border-b border-primary/20 text-base font-bold text-primary flex items-center gap-2",children:[(0,po.jsx)("span",{className:"text-base","aria-hidden":"true",children:"\u25CF"}),i]}),(0,po.jsx)("div",{className:"p-4 space-y-4",children:s})]})}var ru=Ne(Et(),1),nu=(...i)=>i.filter((s,c,u)=>!!s&&s.trim()!==""&&u.indexOf(s)===c).join(" ").trim(),ch=i=>i.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),uh=i=>i.replace(/^([A-Z])|[\s-_]+(\w)/g,(s,c,u)=>u?u.toUpperCase():c.toLowerCase()),au=i=>{let s=uh(i);return s.charAt(0).toUpperCase()+s.slice(1)},Wi=Ne(Et(),1),Yi={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"},dh=i=>{for(let s in i)if(s.startsWith("aria-")||s==="role"||s==="title")return!0;return!1},ou=Ne(Et(),1),fh=(0,ou.createContext)({}),ph=()=>(0,ou.useContext)(fh),mh=(0,Wi.forwardRef)(({color:i,size:s,strokeWidth:c,absoluteStrokeWidth:u,className:f="",children:b,iconNode:h,...w},C)=>{let{size:x=24,strokeWidth:y=2,absoluteStrokeWidth:k=!1,color:S="currentColor",className:q=""}=ph()??{},X=u??k?Number(c??y)*24/Number(s??x):c??y;return(0,Wi.createElement)("svg",{ref:C,...Yi,width:s??x??Yi.width,height:s??x??Yi.height,stroke:i??S,strokeWidth:X,className:nu("lucide",q,f),...!b&&!dh(w)&&{"aria-hidden":"true"},...w},[...h.map(([B,G])=>(0,Wi.createElement)(B,G)),...Array.isArray(b)?b:[b]])}),mo=(i,s)=>{let c=(0,ru.forwardRef)(({className:u,...f},b)=>(0,ru.createElement)(mh,{ref:b,iconNode:s,className:nu(`lucide-${ch(au(i))}`,`lucide-${i}`,u),...f}));return c.displayName=au(i),c},gh=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],hh=mo("check",gh),bh=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],vh=mo("info",bh),yh=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],Qi=mo("triangle-alert",yh),wh=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Ki=mo("x",wh),lt=Ne(it(),1);function xh({title:i,subtitle:s,onClose:c,patientInfo:u}){return(0,lt.jsxs)("div",{className:"flex items-center justify-between px-5 py-4 bg-primary text-white shrink-0",children:[(0,lt.jsxs)("div",{className:"flex items-center gap-3 min-w-0",children:[(0,lt.jsx)("div",{className:"flex items-center justify-center w-11 h-11 rounded-xl bg-white/15 flex-shrink-0",children:(0,lt.jsxs)("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[(0,lt.jsx)("path",{d:"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"}),(0,lt.jsx)("polyline",{points:"14 2 14 8 20 8"}),(0,lt.jsx)("line",{x1:"16",y1:"13",x2:"8",y2:"13"}),(0,lt.jsx)("line",{x1:"16",y1:"17",x2:"8",y2:"17"}),(0,lt.jsx)("polyline",{points:"10 9 9 9 8 9"})]})}),(0,lt.jsxs)("div",{className:"min-w-0",children:[(0,lt.jsx)("h2",{className:"text-base font-bold",children:i}),s?(0,lt.jsx)("p",{className:"text-base text-white/80 mt-0.5",children:s}):null,u&&(u.norm||u.pasien||u.nama_dokter)&&(0,lt.jsxs)("div",{className:"text-base text-white/90 mt-1",children:["RM ",u.norm||"\u2014"," \xB7 ",u.pasien||"\u2014"," \xB7"," ",u.nama_dokter||"\u2014"]})]})]}),(0,lt.jsx)("button",{type:"button",onClick:c,className:"bg-white/15 hover:bg-white/25 border-none text-white w-12 h-12 rounded-lg text-xl flex items-center justify-center cursor-pointer transition-colors flex-shrink-0","aria-label":"Tutup modal",children:(0,lt.jsx)(Ki,{className:"size-6"})})]})}var Jt=Ne(it(),1);function kh({anamnesa:i,pemeriksaan:s,onChange:c}){return(0,Jt.jsxs)("div",{className:"space-y-5",children:[(0,Jt.jsxs)("div",{children:[(0,Jt.jsx)(xn,{children:"Anamnesa"}),(0,Jt.jsx)(wn,{value:i,onChange:u=>c("anamnesa",u.target.value),placeholder:"Keluhan pasien...",rows:5,"aria-describedby":"anamnesa-help"}),(0,Jt.jsx)("p",{id:"anamnesa-help",className:"text-base text-muted-foreground mt-1",children:"Tuliskan keluhan utama, riwayat penyakit sekarang, dan riwayat penyakit dahulu"})]}),(0,Jt.jsxs)("div",{children:[(0,Jt.jsx)(xn,{children:"Pemeriksaan Fisik"}),(0,Jt.jsx)(wn,{value:s,onChange:u=>c("pemeriksaan",u.target.value),placeholder:"Hasil pemeriksaan fisik...",rows:5,"aria-describedby":"pemeriksaan-help"}),(0,Jt.jsx)("p",{id:"pemeriksaan-help",className:"text-base text-muted-foreground mt-1",children:"Catat hasil pemeriksaan umum dan sistemik"})]})]})}var Sh=Ne(Et(),1),Ch=Ne(it(),1),kn=(0,Sh.forwardRef)(({className:i,type:s,...c},u)=>(0,Ch.jsx)("input",{type:s,className:yn("flex h-11 w-full rounded-lg border-2 border-input bg-background px-3.5 py-2.5 text-base text-foreground leading-normal","placeholder:text-muted-foreground","focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 border-primary/50","disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted",i),ref:u,...c}));kn.displayName="Input";var Sn=Ne(it(),1);function zh({vitals:i,onChange:s}){return(0,Sn.jsx)("div",{className:"grid grid-cols-2 sm:grid-cols-3 gap-4",children:[{key:"tensi",label:"Tekanan Darah",unit:"mmHg",placeholder:"120/80"},{key:"nadi",label:"Nadi",unit:"x/menit",placeholder:"80"},{key:"suhu",label:"Suhu Tubuh",unit:"\xB0C",placeholder:"36.5"},{key:"nafas",label:"Respirasi",unit:"x/menit",placeholder:"20"},{key:"berat",label:"Berat Badan",unit:"kg",placeholder:"60"},{key:"tinggi",label:"Tinggi Badan",unit:"cm",placeholder:"165"}].map(c=>(0,Sn.jsxs)("div",{className:"space-y-1.5",children:[(0,Sn.jsx)(xn,{children:c.label}),(0,Sn.jsxs)("div",{className:"relative",children:[(0,Sn.jsx)(kn,{value:i[c.key],onChange:u=>s(c.key,u.target.value),placeholder:c.placeholder,className:"pr-20 font-mono font-semibold","aria-label":c.label}),(0,Sn.jsx)("span",{className:"absolute right-4 top-1/2 -translate-y-1/2 text-base font-semibold text-muted-foreground pointer-events-none",children:c.unit})]})]},c.key))})}var Cn=Ne(Et(),1),_h=Ne(Et(),1),iu=i=>typeof i=="boolean"?`${i}`:i===0?"0":i,lu=Oc,Eh=(i,s)=>c=>{var u;if(s?.variants==null)return lu(i,c?.class,c?.className);let{variants:f,defaultVariants:b}=s,h=Object.keys(f).map(x=>{let y=c?.[x],k=b?.[x];if(y===null)return null;let S=iu(y)||iu(k);return f[x][S]}),w=c&&Object.entries(c).reduce((x,y)=>{let[k,S]=y;return S===void 0||(x[k]=S),x},{}),C=s==null||(u=s.compoundVariants)===null||u===void 0?void 0:u.reduce((x,y)=>{let{class:k,className:S,...q}=y;return Object.entries(q).every(X=>{let[B,G]=X;return Array.isArray(G)?G.includes({...b,...w}[B]):{...b,...w}[B]===G})?[...x,k,S]:x},[]);return lu(i,h,C,c?.class,c?.className)},Nh=Ne(it(),1),Th=Eh("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-base font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-5 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground shadow-sm hover:bg-primary/90 active:bg-primary",destructive:"bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90 active:bg-destructive",outline:"border-2 border-border bg-background shadow-sm hover:bg-accent hover:text-accent-foreground active:bg-accent",secondary:"bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80 active:bg-secondary",success:"bg-green-600 text-green-50 shadow-sm hover:bg-green-600/90 active:bg-green-600",dark:"bg-neutral-950 text-white shadow-sm hover:bg-neutral-900 active:bg-neutral-950",ghost:"hover:bg-accent hover:text-accent-foreground active:bg-accent",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-11 px-5 min-w-[90px]",sm:"h-9 px-3.5 min-w-[80px]",xs:"h-7 px-2.5 min-w-0 gap-1.5 text-xs font-medium [&_svg]:size-3.5",lg:"h-12 px-6 text-base min-w-[100px]",xl:"h-13 px-7 text-lg min-w-[110px]",icon:"h-11 w-11"}},defaultVariants:{variant:"default",size:"default"}}),Zt=(0,_h.forwardRef)(({className:i,variant:s,size:c,...u},f)=>(0,Nh.jsx)("button",{className:yn(Th({variant:s,size:c,className:i})),ref:f,...u}));Zt.displayName="Button";var je=Ne(it(),1),Ph="/rekam-medik/search?opsi=kodeicd10&q=";function jh({rows:i,onChange:s}){let[c,u]=(0,Cn.useState)([]),[f,b]=(0,Cn.useState)(-1),[h,w]=(0,Cn.useState)({top:0,left:0,width:0}),[C,x]=(0,Cn.useState)(""),y=(0,Cn.useRef)(null),k=(0,Cn.useRef)(null),S=(U,V)=>s(i.map((N,I)=>I===U?{...N,...V}:N)),q=U=>s(i.filter((V,N)=>N!==U)),X=(U,V,N)=>{if(x(""),clearTimeout(y.current??void 0),k.current?.abort(),U.length<3){u([]),b(-1);return}let I=N.getBoundingClientRect();w({top:I.bottom+4,left:I.left,width:I.width}),y.current=setTimeout(async()=>{let ae=new AbortController;k.current=ae;try{let re=await fetch(`${Ph}${encodeURIComponent(U)}`,{signal:ae.signal});if(!re.ok){x("HTTP "+re.status);return}let L=await re.text();if(!L||L==="[]"){x("Data tidak ditemukan");return}let Q;try{if(Q=JSON.parse(L),!Array.isArray(Q))throw new Error("not array")}catch{Q=L.split(`
`).filter(ue=>ue.includes("|")).map(ue=>{let[at,De,Ye]=ue.split("|");return{NAMA:at.trim(),KODE:De.trim(),ID:Ye.trim()}}).filter(ue=>ue.KODE)}Q.length>0?(u(Q.slice(0,15)),b(V)):x("Data tidak ditemukan")}catch(re){x(String(re))}},300)},B=(U,V)=>{S(U,{idicd:V.ID,kode10:V.KODE,namaDiagnosa:V.NAMA}),u([]),b(-1)},G=U=>V=>{S(U,{namaDiagnosa:V.target.value}),X(V.target.value,U,V.currentTarget)},oe=U=>V=>{S(U,{kode10:V.target.value})};return(0,je.jsxs)("div",{className:"space-y-2",children:[i.length>0&&(0,je.jsxs)("div",{className:"flex gap-2 text-base font-bold text-muted-foreground px-1",children:[(0,je.jsx)("span",{className:"flex-1",children:"Nama Diagnosa"}),(0,je.jsx)("span",{className:"w-28",children:"Kode ICD"}),(0,je.jsx)("span",{className:"w-[76px] text-right",children:"Aksi"})]}),i.length===0?(0,je.jsx)("div",{className:"border-2 border-dashed border-border rounded-xl py-6 text-center bg-background",children:(0,je.jsx)("p",{className:"text-base text-muted-foreground",children:"Belum ada diagnosa"})}):(0,je.jsx)("div",{className:"space-y-2",children:i.map((U,V)=>{let N=V+1;return(0,je.jsxs)("div",{className:"flex gap-2 items-center",children:[(0,je.jsxs)("div",{className:"flex-1 min-w-0 relative",children:[(0,je.jsx)(kn,{id:`rj-nama${N}`,name:"nama[]",value:U.namaDiagnosa,placeholder:"Cari diagnosa...",autoComplete:"off",onChange:G(V),"aria-label":`Nama diagnosa ${N}`,"aria-describedby":`rj-nama-help-${N}`}),(0,je.jsx)("p",{id:`rj-nama-help-${N}`,className:"sr-only",children:"Ketik minimal 3 karakter untuk mencari diagnosis ICD-10"}),(0,je.jsx)("input",{type:"hidden",id:`rj-idicd${N}`,name:"idicd[]",value:U.idicd}),c.length>0&&f===V&&(0,je.jsx)("div",{className:"fixed z-[2147483647] bg-background border-2 border-border rounded-xl shadow-lg max-h-[420px] overflow-auto",style:{top:h.top,left:h.left,width:h.width},role:"listbox","aria-label":"Hasil pencarian ICD-10",children:c.map((I,ae)=>(0,je.jsxs)("div",{onClick:()=>B(V,I),role:"option",className:"px-4 py-4 cursor-pointer text-lg border-b border-border hover:bg-accent transition-colors",children:[(0,je.jsx)("div",{className:"rj-icd-hit-nama font-semibold text-foreground leading-snug",children:I.NAMA}),(0,je.jsx)("div",{className:"rj-icd-hit-kode text-muted-foreground text-xxl leading-tight",children:I.KODE})]},I.ID||ae))}),C&&f===V&&(0,je.jsx)("div",{className:"fixed z-[2147483647] bg-destructive/10 border-2 border-destructive rounded-xl px-3 py-2.5 text-base text-destructive",style:{top:h.top,left:h.left},role:"alert",children:C})]}),(0,je.jsxs)("div",{className:"w-28 shrink-0",children:[(0,je.jsx)(kn,{id:`rj-kode${N}`,name:"kode10[]",value:U.kode10,placeholder:"Kode",onChange:oe(V),className:"font-mono text-base","aria-label":`Kode ICD-10 ${N}`}),(0,je.jsx)("input",{type:"hidden",name:"kasus[]",value:U.kasus}),(0,je.jsx)("input",{type:"hidden",name:"komplikasi[]",value:U.komplikasi})]}),(0,je.jsx)(Zt,{variant:"destructive",size:"default",onClick:()=>q(V),className:"w-[76px] shrink-0","aria-label":`Hapus diagnosa ${N}`,children:"Hapus"})]},V)})}),(0,je.jsx)(Zt,{variant:"default",size:"default",className:"gap-2 w-full",onClick:()=>s([...i,{idicd:"",kode10:"",namaDiagnosa:"",kasus:"LAMA",komplikasi:"TIDAK"}]),children:"\uFF0B Tambah Diagnosa"})]})}var zn=Ne(Et(),1),Ae=Ne(it(),1),Ah="/rekam-medik/search?opsi=clauseDiagnose_icd9&q=";function Lh({rows:i,onChange:s}){let[c,u]=(0,zn.useState)([]),[f,b]=(0,zn.useState)(-1),[h,w]=(0,zn.useState)({top:0,left:0,width:0}),[C,x]=(0,zn.useState)(""),y=(0,zn.useRef)(null),k=(0,zn.useRef)(null),S=(U,V)=>s(i.map((N,I)=>I===U?{...N,...V}:N)),q=U=>s(i.filter((V,N)=>N!==U)),X=(U,V,N)=>{if(x(""),clearTimeout(y.current??void 0),k.current?.abort(),U.length<3){u([]),b(-1);return}let I=N.getBoundingClientRect();w({top:I.bottom+4,left:I.left,width:I.width}),y.current=setTimeout(async()=>{let ae=new AbortController;k.current=ae;try{let re=await fetch(`${Ah}${encodeURIComponent(U)}`,{signal:ae.signal});if(!re.ok){x("HTTP "+re.status);return}let L=await re.text();if(!L||L==="[]"){x("Data tidak ditemukan");return}let Q;try{if(Q=JSON.parse(L),!Array.isArray(Q))throw new Error("not array")}catch{Q=L.split(`
`).filter(ue=>ue.includes("|")).map(ue=>{let[at,De,Ye]=ue.split("|");return{NAMA:at.trim(),KODE:De.trim(),ID:Ye.trim()}}).filter(ue=>ue.KODE)}Q.length>0?(u(Q.slice(0,15)),b(V)):x("Data tidak ditemukan")}catch(re){x(String(re))}},300)},B=(U,V)=>{S(U,{idicdTindakan:V.ID,kode9:V.KODE,namaTindakan:V.NAMA}),u([]),b(-1)},G=U=>V=>{S(U,{namaTindakan:V.target.value}),X(V.target.value,U,V.currentTarget)},oe=U=>V=>{S(U,{kode9:V.target.value})};return(0,Ae.jsxs)("div",{className:"space-y-2",children:[i.length>0&&(0,Ae.jsxs)("div",{className:"flex gap-2 text-base font-bold text-muted-foreground px-1",children:[(0,Ae.jsx)("span",{className:"flex-1",children:"Nama Tindakan"}),(0,Ae.jsx)("span",{className:"w-28",children:"Kode ICD"}),(0,Ae.jsx)("span",{className:"w-[76px] text-right",children:"Aksi"})]}),i.length===0?(0,Ae.jsx)("div",{className:"border-2 border-dashed border-border rounded-xl py-6 text-center bg-background",children:(0,Ae.jsx)("p",{className:"text-base text-muted-foreground",children:"Belum ada tindakan"})}):(0,Ae.jsx)("div",{className:"space-y-2",children:i.map((U,V)=>{let N=V+1;return(0,Ae.jsxs)("div",{className:"flex gap-2 items-center",children:[(0,Ae.jsxs)("div",{className:"flex-1 min-w-0 relative",children:[(0,Ae.jsx)(kn,{id:`rj-nama-tindakan${N}`,name:"nama_tindakan[]",value:U.namaTindakan,placeholder:"Cari tindakan...",autoComplete:"off",onChange:G(V),"aria-label":`Nama tindakan ${N}`,"aria-describedby":`rj-tindakan-help-${N}`}),(0,Ae.jsx)("p",{id:`rj-tindakan-help-${N}`,className:"sr-only",children:"Ketik minimal 3 karakter untuk mencari tindakan ICD-9"}),(0,Ae.jsx)("input",{type:"hidden",id:`rj-idicd-tindakan${N}`,name:"idicd_tindakan[]",value:U.idicdTindakan,autoComplete:"off"}),c.length>0&&f===V&&(0,Ae.jsx)("div",{className:"fixed z-[2147483647] bg-background border-2 border-border rounded-xl shadow-lg max-h-[420px] overflow-auto",style:{top:h.top,left:h.left,width:h.width},role:"listbox","aria-label":"Hasil pencarian ICD-9",children:c.map((I,ae)=>(0,Ae.jsxs)("div",{onClick:()=>B(V,I),role:"option",className:"px-4 py-4 cursor-pointer text-lg border-b border-border hover:bg-accent transition-colors",children:[(0,Ae.jsx)("div",{className:"rj-icd-hit-nama font-semibold text-foreground leading-snug",children:I.NAMA}),(0,Ae.jsx)("div",{className:"rj-icd-hit-kode text-muted-foreground text-xxl leading-tight",children:I.KODE})]},I.ID||ae))}),C&&f===V&&(0,Ae.jsx)("div",{className:"fixed z-[2147483647] bg-destructive/10 border-2 border-destructive rounded-xl px-3 py-2.5 text-base text-destructive",style:{top:h.top,left:h.left},role:"alert",children:C})]}),(0,Ae.jsxs)("div",{className:"w-28 shrink-0",children:[(0,Ae.jsx)(kn,{id:`rj-kode9${N}`,name:"kode9[]",value:U.kode9,placeholder:"Kode",onChange:oe(V),className:"font-mono text-base","aria-label":`Kode ICD-9 ${N}`}),(0,Ae.jsx)("input",{type:"hidden",name:"jenis[]",value:U.jenis||"Primer"}),(0,Ae.jsx)("input",{type:"hidden",name:"kategoriProsedur[]",value:U.kategoriProsedur})]}),(0,Ae.jsx)(Zt,{variant:"destructive",size:"default",onClick:()=>q(V),className:"w-[76px] shrink-0","aria-label":`Hapus tindakan ${N}`,children:"Hapus"})]},V)})}),(0,Ae.jsx)(Zt,{variant:"default",size:"default",className:"gap-2 w-full",onClick:()=>s([...i,{idicdTindakan:"",kode9:"",namaTindakan:"",jenis:i.length===0?"Primer":"Sekunder",komorbid:"",kategoriProsedur:"410606002",snomedProsedur:"",codeProsedur:""}]),children:"\uFF0B Tambah Tindakan"})]})}var nt=Ne(it(),1);function Rh({errors:i,warnings:s=[]}){return i.length>0||s.length>0?(0,nt.jsxs)(nt.Fragment,{children:[s.length>0&&(0,nt.jsx)("div",{className:"px-6 py-4 border-t-2 border-border bg-yellow-50 dark:bg-yellow-950/30",role:"alert",children:(0,nt.jsxs)("div",{className:"flex items-start gap-3",children:[(0,nt.jsx)(Qi,{className:"size-5 text-yellow-600 dark:text-yellow-500 shrink-0 mt-0.5"}),(0,nt.jsxs)("div",{children:[(0,nt.jsx)("p",{className:"text-base font-bold text-yellow-800 dark:text-yellow-300 mb-1",children:"Perhatian"}),(0,nt.jsx)("ul",{className:"space-y-1",children:s.map((c,u)=>(0,nt.jsxs)("li",{className:"text-base text-yellow-700 dark:text-yellow-400",children:[c.section,": ",c.message]},u))})]})]})}),i.length>0&&(0,nt.jsx)("div",{className:"px-6 py-4 border-t-2 border-border bg-destructive/5",role:"alert",children:(0,nt.jsxs)("div",{className:"flex items-start gap-3",children:[(0,nt.jsx)(Qi,{className:"size-5 text-destructive shrink-0 mt-0.5"}),(0,nt.jsxs)("div",{children:[(0,nt.jsxs)("p",{className:"text-base font-bold text-destructive mb-1",children:["Terdapat ",i.length," kesalahan"]}),(0,nt.jsx)("ul",{className:"space-y-1",children:i.map((c,u)=>(0,nt.jsxs)("li",{className:"text-base text-destructive/80",children:[c.section,": ",c.message]},u))})]})]})})]}):null}var go=Ne(it(),1),Oh={default:"bg-primary/10 text-primary border-primary/20",success:"bg-green-50 dark:bg-green-950/20 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800",warning:"bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800",danger:"bg-destructive/10 text-destructive border-destructive/20"},Dh={default:vh,success:hh,warning:Qi,danger:Ki};function su({variant:i="default",icon:s,children:c,className:u,onDismiss:f}){let b=Dh[i];return(0,go.jsxs)("span",{className:yn("inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-base font-semibold",Oh[i],u),children:[s&&(0,go.jsx)(b,{className:"size-3.5"}),c,f&&(0,go.jsx)("button",{onClick:f,className:"ml-1 hover:opacity-70 p-0.5","aria-label":"Dismiss",children:(0,go.jsx)(Ki,{className:"size-3.5"})})]})}var Bt=Ne(it(),1);function Ih({onCancel:i,onSave:s,onRefresh:c,onReset:u,onHistory:f,saving:b,hasErrors:h,lastSaved:w}){let C=u??c;return(0,Bt.jsxs)("div",{className:"flex items-center justify-between px-6 py-4 border-t-2 border-border bg-background/60 backdrop-blur supports-[backdrop-filter]:bg-background/60 shrink-0 sticky bottom-0 z-[1]",children:[(0,Bt.jsxs)("div",{className:"flex items-center gap-3 min-w-0",children:[h&&(0,Bt.jsx)(su,{variant:"danger",icon:!0,children:"Validasi gagal"}),w&&(0,Bt.jsxs)("span",{className:"text-base text-muted-foreground truncate",children:["Tersimpan ",w]}),b&&(0,Bt.jsx)(su,{variant:"default",icon:!0,children:"Menyimpan..."})]}),(0,Bt.jsxs)("div",{className:"flex items-center gap-3",children:[f&&(0,Bt.jsx)(Zt,{type:"button",variant:"success",size:"default",onClick:f,className:"gap-2",children:"Riwayat"}),C&&(0,Bt.jsx)(Zt,{type:"button",variant:"outline",size:"default",onClick:C,className:"gap-2",children:"Reset Formulir"}),(0,Bt.jsx)(Zt,{type:"button",variant:"dark",size:"default",onClick:i,children:"Batal"}),(0,Bt.jsx)(Zt,{type:"button",variant:"default",size:"lg",onClick:s,disabled:b||h,className:"gap-2 px-7 min-h-11","aria-label":"Simpan resume",children:b?"Menyimpan...":"Simpan"})]})]})}var Le=Ne(it(),1);function cu(i){let s=[];return i.diagnosa.forEach((c,u)=>{yr(c.kode10)&&yr(c.namaDiagnosa)||(!yr(c.kode10)&&yr(c.namaDiagnosa)&&s.push({section:`Diagnosa #${u+1}`,message:"Nama diagnosa kosong"}),!yr(c.namaDiagnosa)&&yr(c.kode10)&&s.push({section:`Diagnosa #${u+1}`,message:"Kode ICD-10 kosong"}))}),i.tindakan.forEach((c,u)=>{yr(c.kode9)||yr(c.namaTindakan)&&s.push({section:`Tindakan #${u+1}`,message:"Nama tindakan kosong"})}),s}function Fh({data:i,onSave:s,onClose:c}){let[u,f]=(0,Xt.useState)(i),[b,h]=(0,Xt.useState)(!1),[w,C]=(0,Xt.useState)(null),[x,y]=(0,Xt.useState)(!1),[k,S]=(0,Xt.useState)([]),[q,X]=(0,Xt.useState)([]),B=(0,Xt.useRef)(u.diagnosa.some(Q=>Q.idicd?.trim()));(0,Xt.useEffect)(()=>{y(!1)},[u]);let G=x?cu(u):[],oe=[...G,...q],U=G.length>0,V=(0,Xt.useCallback)(async()=>{if(y(!0),S([]),X([]),cu(u).length>0)return;let Q=u.diagnosa.filter(ue=>ue.idicd?.trim()&&ue.kode10?.trim()&&ue.namaDiagnosa?.trim());B.current&&Q.length===0&&S([{section:"Diagnosa",message:"Semua diagnosa telah dihapus. Sistem Morbis biasanya tidak menghapus ICD yang sudah tersimpan ketika daftar diagnosa dikosongkan."}]),h(!0);try{await s(u),C(new Date().toLocaleTimeString()),window.setTimeout(()=>window.location.reload(),900)}catch(ue){let at=ue instanceof Error?ue.message:String(ue);X([{section:"Server",message:at}])}finally{h(!1)}},[u,s]),N=(Q,ue)=>f({...u,clinicalNotes:{...u.clinicalNotes,[Q]:ue}}),I=async()=>{let{confirmExt:Q}=await Promise.resolve().then(()=>(Mm(),xc));return Q({title:"Reset semua data?",message:"Semua data yang sudah dimasukkan akan dihapus. Tindakan ini tidak dapat dibatalkan.",variant:"danger",cancelLabel:"Kembali",okLabel:"Reset"})},ae=async()=>{await I()&&location.reload()},re=async()=>{if(G.length>0){y(!0);return}await V()},L=()=>{mg({idVisit:u.patientInfo.id_visit||new URLSearchParams(location.search).get("id_visit")||"",tipe:"rajal",title:"Riwayat Resume Rajal",zIndex:2147483647,onApply:Q=>f(hg(Q,u))})};return(0,Le.jsxs)("div",{className:"resume-modal",children:[(0,Le.jsx)(xh,{title:"Resume Rawat Jalan",onClose:c,patientInfo:u.patientInfo}),(0,Le.jsxs)("div",{className:"flex-1 overflow-y-auto px-5 py-4 space-y-3",children:[(0,Le.jsx)(ma,{title:"Data Klinis",children:(0,Le.jsx)(kh,{anamnesa:u.clinicalNotes.anamnesa,pemeriksaan:u.clinicalNotes.pemeriksaan_fisik,onChange:(Q,ue)=>N(Q==="pemeriksaan"?"pemeriksaan_fisik":Q,ue)})}),(0,Le.jsx)(ma,{title:"Tanda Vital",children:(0,Le.jsx)(zh,{vitals:u.vitalSigns,onChange:(Q,ue)=>f({...u,vitalSigns:{...u.vitalSigns,[Q]:ue}})})}),(0,Le.jsx)(ma,{title:"Catatan Medis",children:(0,Le.jsxs)("div",{className:"space-y-3",children:[(0,Le.jsxs)("div",{children:[(0,Le.jsx)(xn,{children:"Catatan Diagnosis"}),(0,Le.jsx)(wn,{value:u.clinicalNotes.catatan,onChange:Q=>N("catatan",Q.target.value),placeholder:"Catatan diagnosa...",rows:3})]}),(0,Le.jsxs)("div",{children:[(0,Le.jsx)(xn,{children:"Tindakan"}),(0,Le.jsx)(wn,{value:u.clinicalNotes.tindakan,onChange:Q=>N("tindakan",Q.target.value),placeholder:"Tindakan...",rows:3})]}),(0,Le.jsxs)("div",{children:[(0,Le.jsx)(xn,{children:"Terapi Pengobatan"}),(0,Le.jsx)(wn,{value:u.clinicalNotes.terapi_pengobatan,onChange:Q=>N("terapi_pengobatan",Q.target.value),placeholder:"Terapi pengobatan...",rows:3})]})]})}),(0,Le.jsx)(ma,{title:`Diagnosis (ICD-10)${u.diagnosa.length>0?` (${u.diagnosa.length})`:""}`,children:(0,Le.jsx)(jh,{rows:u.diagnosa,onChange:Q=>f({...u,diagnosa:Q})})}),(0,Le.jsx)(ma,{title:`Tindakan (ICD-9)${u.tindakan.length>0?` (${u.tindakan.length})`:""}`,children:(0,Le.jsx)(Lh,{rows:u.tindakan,onChange:Q=>f({...u,tindakan:Q})})})]}),(0,Le.jsx)(Rh,{errors:oe,warnings:k}),(0,Le.jsx)(Ih,{saving:b,hasErrors:U,lastSaved:w,onSave:re,onCancel:c,onRefresh:ae,onHistory:L})]})}var Mh=Ne(Et(),1),$h=class extends Mh.Component{constructor(){super(...arguments),this.state={hasError:!1}}static getDerivedStateFromError(){return{hasError:!0}}componentDidCatch(){this.props.onError()}render(){return this.state.hasError?null:this.props.children}},uu=Ne(it(),1),Uh=[{pattern:"periksa.*dokter",weight:1},{pattern:"konsultasi",weight:2},{pattern:"tindakan utama",weight:3},{pattern:"lab",weight:10},{pattern:"glukosa",weight:11},{pattern:"hba1c",weight:12},{pattern:"hb a1c",weight:12}];function du(i){let s=new Map;return[...i].sort((c,u)=>{let f=b=>{let h=b.toLowerCase().trim();for(let w of Uh)if(s.has(w.pattern)||s.set(w.pattern,new RegExp(w.pattern,"i")),s.get(w.pattern).test(h))return w.weight;return 999};return f(c)-f(u)})}function Hh(i){if(!i)return"";let s=i.trim();return s?s.charAt(0).toUpperCase()+s.slice(1):""}function fu(i){return i.map(Hh).join(`
`)}function pu(){let i=document.getElementById("pembayaran-gabung")||document.body,s=[],c=[],u=i.querySelectorAll("tr"),f=!1;for(let C of u){let x=C.textContent?.trim()||"";if(C.querySelector("b")&&!x.match(/^\d/)){f=!0;continue}if(f&&(x.includes("Total")||x.includes("Sub Total"))){f=!1;continue}if(f){let y=Array.from(C.querySelectorAll("td"));if(y.length>=5&&y[0]?.textContent?.trim().match(/^\d+\.?$/)){let k=y[2]?.textContent?.trim()||"",S=y[4]?.textContent?.trim()||"1";s.push(S&&S!=="1"?`${k} (${S})`:k)}}}let b=Array.from(i.querySelectorAll("b")).find(C=>C.textContent?.includes("Biaya Resep"));if(b){let C=b.closest("tr")?.nextElementSibling;for(;C&&!C.textContent?.includes("Sub Total");){if(C.getAttribute("valign")==="top"){let x=Array.from(C.querySelectorAll("td")),y=x[1]?.textContent?.trim()||"",k=y.match(/^\d+\s+(.*)/),S=k?k[1]:y,q=x[2]?.textContent?.trim()||"";c.push(q?`${S} Jml: ${q}`:S)}C=C.nextElementSibling}}let h=du(s),w=du(c);return{tindakan:fu(h),terapiPengobatan:fu(w)}}var Sv=location.pathname.includes("rm-rawat-jalan-new"),qh="/admisi/pelaksanaan_pelayanan/control/rm-rawat-jalan-refaktor?sub=simpan",kr=null,_n=null;function Bh(){let i=document.getElementById("resume-view");if(!i)return null;let s=w=>{let C=i.querySelectorAll("table table tr, fieldset table tr");for(let x of C){let y=x.querySelectorAll("td");for(let k=0;k<y.length;k++)if(y[k].textContent?.trim()===w&&y[k+1]){let S=y[k+1];return(S.textContent?.trim()===":"?y[k+2]:S)?.textContent?.trim()||""}}return""},c=()=>{let w=Array.from(i.querySelectorAll("tr")).find(k=>k.textContent?.includes("Hasil Pemeriksaan Fisik"));if(!w)return"";let C=w.querySelector("td:last-child table, td[colspan] table");if(!C)return"";let x=Array.from(C.querySelectorAll("tr")).find(k=>{let S=k.querySelectorAll("td");return Array.from(S).some(q=>q.textContent?.trim()==="Lainnya")});if(!x)return"";let y=x.querySelectorAll("td");for(let k=0;k<y.length;k++)if(y[k].textContent?.trim()==="Lainnya"&&k+2<y.length){let S=y[k+2]?.textContent?.trim()||"",q=["Tensi:","Nadi:","Suhu:","Nafas:","Tinggi:","Berat:","Lainnya:"];return S.split(`
`).filter(X=>{let B=X.trim();return B&&!q.some(G=>B.startsWith(G))}).join(`
`)}return""},u=w=>{let C=Array.from(i.querySelectorAll("tr")).find(k=>k.textContent?.includes("Hasil Pemeriksaan Fisik"));if(!C)return"";let x=C.querySelector("td:last-child table, td[colspan] table");if(!x)return"";let y=x.querySelectorAll("tr");for(let k of y){let S=k.querySelectorAll("td");for(let q=0;q<S.length;q++)if(S[q].textContent?.trim()===w&&S[q+1]){let X=S[q+1];return(X.textContent?.trim()===":"?S[q+2]:X)?.textContent?.trim()||""}}return""},f=[],b=Array.from(i.querySelectorAll("tr")).find(w=>w.textContent?.includes("ICD X"));if(b){let w=b.querySelector("td:last-child table, td[colspan] table");if(w){let C=w.querySelectorAll("tr");for(let x of C){let y=(x.textContent?.trim()||"").match(/-\s*(.+?)\s*\(([^)]+)\)\s*-/);y&&f.push({idicd:"",kode10:y[2],namaDiagnosa:y[1],kasus:"",komplikasi:""})}}}let h=[];return{patientInfo:{norm:s("No. Rekam Medis"),pasien:s("Nama Pasien"),nama_dokter:""},clinicalNotes:{anamnesa:s("Anamnesa"),pemeriksaan_fisik:c(),catatan:s("Diagnosa"),tindakan:s("Tindakan"),terapi_pengobatan:s("Terapi Pengobatan")},vitalSigns:{tensi:u("Tensi"),nadi:u("Nadi"),suhu:u("Suhu"),nafas:u("Nafas"),tinggi:u("Tinggi"),berat:u("Berat")},diagnosa:f,tindakan:h}}function Vh(){let i=Bh(),s=document,c=k=>s.getElementById(k)?.value||"",u=k=>{let S=s.querySelector(`textarea[name="${k}"], input[name="${k}"], #${k}, select[name="${k}"]`);return S?"tagName"in S&&S.tagName==="SELECT"?S.value:S.value||"":""},f=k=>s.querySelector(`input[name="${k}"]:checked`)?.value||"",b={norm:c("norm")||c("no_rm"),pasien:c("pasien")||c("nama_pasien"),nama_dokter:c("nama_dokter")||c("dokter"),id_visit:c("id_visit")||new URLSearchParams(location.search).get("id_visit")||(typeof te?.id_visit=="string"?te.id_visit:""),id_rawat_jalan:c("id_rawat_jalan")||new URLSearchParams(location.search).get("id")||(typeof te?.id_rawat_jalan=="string"?te.id_rawat_jalan:""),id_user:c("id_user")||(typeof te?.id_user=="string"?te.id_user:"")||"1",id_dokter:c("id_dokter")||(typeof te?.id_dokter=="string"?te.id_dokter:""),id_bed:c("id_bed")||(typeof te?.id_bed=="string"?te.id_bed:""),noregis:c("noregis")||(typeof te?.noregis=="string"?te.noregis:"")},h={anamnesa:u("anamnesa"),pemeriksaan_fisik:u("pemeriksaan_fisik")||u("pemeriksaan")||u("fisik")||"",catatan:u("catatan")||"",tindakan:u("tindakan")||u("namaTindakan"),terapi_pengobatan:u("terapi_pengobatan")||"",jenis_kasus:u("jenis_kasus"),status_kasus:f("status_kasus"),tindak_lanjut:u("tindak_lanjut")},w={tensi:c("tensi"),nadi:c("nadi"),suhu:c("suhu"),nafas:c("nafas"),tinggi:c("tinggi"),berat:c("berat")},C=[],x=s.querySelectorAll('input[name="kode10[]"], input[name="kode[]"]');if(x.length===0){let k=1;for(;s.getElementById(`kode${k}`)||s.querySelector(`input[name="kode10[]"]:nth-child(${k})`);){let S=c(`idicd${k}`)||"",q=c(`kode${k}`)||"",X=c(`nama${k}`)||"";(q||X)&&C.push({idicd:S,kode10:q,namaDiagnosa:X,kasus:"",komplikasi:""}),k++}}else x.forEach(k=>{let S=k.closest("tr");if(!S)return;let q=S.querySelector('input[name="idicd[]"], input[name="idicd"]')?.value||"",X=k.value||"",B=S.querySelector('input[name="namaDiagnosa[]"], input[name="nama[]"]')?.value||"",G=S.querySelector('select[name="kasus_diagnosa[]"], select[name="kasus[]"]')?.value||"",oe=S.querySelector('select[name="komplikasi[]"]')?.value||"";(X||B)&&C.push({idicd:q,kode10:X,namaDiagnosa:B,kasus:G,komplikasi:oe})});if(C.length===0&&te){let k=Array.isArray(te["kode10[]"])?te["kode10[]"]:[],S=Array.isArray(te["nama[]"])?te["nama[]"]:[],q=Array.isArray(te["idicd[]"])?te["idicd[]"]:[],X=Array.isArray(te["kasus_diagnosa[]"])?te["kasus_diagnosa[]"]:[],B=Array.isArray(te["komplikasi[]"])?te["komplikasi[]"]:[];k.forEach((G,oe)=>{G&&C.push({idicd:q[oe]||"",kode10:G,namaDiagnosa:S[oe]||"",kasus:X[oe]||"",komplikasi:B[oe]||""})})}let y=[];if(s.querySelectorAll('input[name="kode9[]"]').forEach(k=>{let S=k.closest("tr");if(!S)return;let q=k.value||"";if(!q)return;let X=S.querySelector('input[name="idicdTindakan[]"]')?.value||"",B=S.querySelector('input[name="namaTindakan[]"]')?.value||"",G=S.querySelector('select[name="komorbid[]"]')?.value||"",oe=S.querySelector('select[name="kategoriProsedur[]"]')?.value||"";y.push({idicdTindakan:X,kode9:q,namaTindakan:B,komorbid:G,kategoriProsedur:oe,snomedProsedur:"",codeProsedur:""})}),y.length===0&&te){let k=Array.isArray(te["kode9[]"])?te["kode9[]"]:[],S=Array.isArray(te["namaTindakan[]"])?te["namaTindakan[]"]:[],q=Array.isArray(te["idicdTindakan[]"])?te["idicdTindakan[]"]:[],X=Array.isArray(te["komorbid[]"])?te["komorbid[]"]:[],B=Array.isArray(te["kategoriProsedur[]"])?te["kategoriProsedur[]"]:[];k.forEach((G,oe)=>{G&&y.push({idicdTindakan:q[oe]||"",kode9:G,namaTindakan:S[oe]||"",komorbid:X[oe]||"",kategoriProsedur:B[oe]||""})})}if(i&&(b.norm=b.norm||i.patientInfo.norm,b.pasien=b.pasien||i.patientInfo.pasien,b.nama_dokter=b.nama_dokter||i.patientInfo.nama_dokter,h.anamnesa=h.anamnesa||i.clinicalNotes.anamnesa,h.pemeriksaan_fisik=h.pemeriksaan_fisik||i.clinicalNotes.pemeriksaan_fisik,h.catatan=h.catatan||i.clinicalNotes.catatan,h.tindakan=h.tindakan||i.clinicalNotes.tindakan,h.terapi_pengobatan=h.terapi_pengobatan||i.clinicalNotes.terapi_pengobatan,w.tensi=w.tensi||i.vitalSigns.tensi,w.nadi=w.nadi||i.vitalSigns.nadi,w.suhu=w.suhu||i.vitalSigns.suhu,w.nafas=w.nafas||i.vitalSigns.nafas,w.tinggi=w.tinggi||i.vitalSigns.tinggi,w.berat=w.berat||i.vitalSigns.berat,C.length===0&&C.push(...i.diagnosa),y.length===0&&y.push(...i.tindakan)),!h.tindakan||h.tindakan==="-"||!h.terapi_pengobatan||h.terapi_pengobatan==="-"){let k=pu();k.tindakan&&(!h.tindakan||h.tindakan==="-")&&(h.tindakan=k.tindakan),k.terapiPengobatan&&(!h.terapi_pengobatan||h.terapi_pengobatan==="-")&&(h.terapi_pengobatan=k.terapiPengobatan)}if(te){let k={anamnesa:h.anamnesa,pemeriksaan_fisik:h.pemeriksaan_fisik,catatan:h.catatan,tindakan:h.tindakan,terapi_pengobatan:h.terapi_pengobatan};for(let[S,q]of Object.entries(k))if(!q||q==="-"){let X=te[S];typeof X=="string"&&X&&(h[S]=X)}}return{patientInfo:b,clinicalNotes:h,vitalSigns:w,diagnosa:C,tindakan:y}}function Wh(i){let s=new URLSearchParams,c=document.getElementById("formdata");if(c)new FormData(c).forEach((N,I)=>{typeof N=="string"&&s.append(I,N)});else if(te)for(let[N,I]of Object.entries(te))if(Array.isArray(I))for(let ae of I)s.append(N,ae);else s.set(N,I);let u=(N,I)=>{I&&(s.get(N)||s.set(N,I))},f=N=>i.patientInfo?.[N]||"",b=N=>document.querySelector(`[name="${N}"]`)?.value||"",h=N=>typeof te?.[N]=="string"?te[N]:"",w=i.patientInfo.id_visit||new URLSearchParams(location.search).get("id_visit")||"",C=i.patientInfo.id_rawat_jalan||new URLSearchParams(location.search).get("id")||"";u("id_visit",w),u("id_rawat_jalan",C),u("id_user",h("id_user")||"1"),s.get("id_kunjungan")||s.set("id_kunjungan",b("id_kunjungan")||h("id_kunjungan")||C||w);for(let N of["norm","ihs_number","ihs_number_dokter","waktu_visit","nama_pasien","id_bed","id_dokter","nama_dokter","planning","pasien","noregis"]){if(s.get(N))continue;let I=f(N)||b(N)||h(N);I&&s.set(N,I)}if(!s.get("waktu")){let N=new Date,I=ae=>String(ae).padStart(2,"0");s.set("waktu",`${I(N.getDate())}/${I(N.getMonth()+1)}/${N.getFullYear()} ${I(N.getHours())}:${I(N.getMinutes())}:${I(N.getSeconds())}`)}for(let N of["nama_pasien","planning","waktu_visit"])s.has(N)||s.set(N,f(N)||h(N)||"");let x=["kode10[]","idicd[]","nama[]","keterangan10[]","kasus_diagnosa[]","komplikasi[]","namaTindakan[]","kode9[]","idicdTindakan[]","komorbid[]","kategoriProsedur[]","snomedProsedur[]","codeProsedur[]"];for(let N of x)s.delete(N);for(let N=1;N<=50;N++)s.delete(`ic${N}`);let y=N=>(N||"").replace(/\n/g,"<br/>");s.set("anamnesa",y(i.clinicalNotes.anamnesa)),s.set("pemeriksaan_fisik",y(i.clinicalNotes.pemeriksaan_fisik)),s.set("catatan",y(i.clinicalNotes.catatan)),s.set("tindakan",y(i.clinicalNotes.tindakan)),s.set("terapi_pengobatan",y(i.clinicalNotes.terapi_pengobatan));let k=N=>(N||"").match(/^([\d/.]+)/)?.[0]||"";s.set("tensi",k(i.vitalSigns.tensi)),s.set("nadi",k(i.vitalSigns.nadi)),s.set("suhu",k(i.vitalSigns.suhu)),s.set("nafas",k(i.vitalSigns.nafas)),s.set("spo2",k(i.vitalSigns.spo2)),s.set("tinggi",k(i.vitalSigns.tinggi)),s.set("berat",k(i.vitalSigns.berat));let S=Array.isArray(te?.["kode10[]"])?te["kode10[]"]:[],q=Array.isArray(te?.["idicd[]"])?te["idicd[]"]:[],X=Array.isArray(te?.["keterangan10[]"])?te["keterangan10[]"]:[];i.diagnosa.filter(N=>N.idicd?.trim()&&N.kode10?.trim()&&N.namaDiagnosa?.trim()).filter((N,I,ae)=>ae.findIndex(re=>re.idicd===N.idicd)===I).forEach(N=>{let I=N.idicd;if(!I&&N.kode10){let L=S.indexOf(N.kode10);L>=0&&q[L]&&(I=q[L])}let ae=q.indexOf(I),re=ae>=0&&X[ae]||"";s.append("nama[]",N.namaDiagnosa),s.append("idicd[]",I),s.append("kode10[]",N.kode10),s.append("keterangan10[]",re),s.append("kasus_diagnosa[]",N.kasus||""),s.append("komplikasi[]",N.komplikasi||"")});let B=Array.isArray(te?.["idicdTindakan[]"])?te["idicdTindakan[]"]:[],G=i.tindakan.filter(N=>N.idicdTindakan?.trim()&&N.kode9?.trim()&&N.namaTindakan?.trim()).filter((N,I,ae)=>ae.findIndex(re=>re.idicdTindakan===N.idicdTindakan&&re.kode9===N.kode9)===I),oe=N=>{let I=B.indexOf(N);return I>=0?h(`ic${I+1}`):""};G.forEach(N=>{s.append("namaTindakan[]",N.namaTindakan),s.append("kode9[]",N.kode9),s.append("idicdTindakan[]",N.idicdTindakan),s.append("komorbid[]",N.komorbid||"");let I=oe(N.idicdTindakan);I&&s.append(`ic${B.indexOf(N.idicdTindakan)+1}`,I)});let U={};for(let N of["id_visit","id_rawat_jalan","id_kunjungan","id_user","norm","ihs_number","ihs_number_dokter","waktu_visit","nama_pasien","waktu","id_bed","id_dokter","nama_dokter","planning","jenis_kasus","save"])U[N]=s.get(N)||"(missing)";let V=Object.entries(U).filter(([,N])=>N==="(missing)").map(([N])=>N);return console.log(`[RJ] payload: ${s.size} key, ${mu.length} dari form,`,V.length?`MISSING: ${V.join(", ")}`:"semua field wajib ada"),console.debug("[RJ] key values:",U),s.toString()}function Yh(i){return Wh(i)}function Xi(i){kr&&(kr.unmount(),kr=null);try{i.innerHTML="",i.style.display="none"}catch{}let s=document.getElementById("morbis-manap-root")?.shadowRoot?.getElementById("ext-resume-shadow-container");if(s){try{s._reactRoot?.unmount?.()}catch{}s.remove()}document.body.classList.remove("ext-resume-open"),_n&&(_n.disabled=!1,_n.style.display="");let c=document.querySelector("[data-scroll-buttons]");c&&(c.style.display="")}function Qh(i,s){if(kr){try{kr.unmount()}catch{}kr=null}try{i.innerHTML=""}catch{}if(!document.getElementById("morbis-resume-fonts")){let w=document.createElement("link");w.id="morbis-resume-fonts",w.rel="stylesheet",w.href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400;1,700&family=Lexend:wght@400;500;600;700&family=Roboto:wght@400;500;600;700&display=swap",document.head.appendChild(w)}let c=(()=>{let w=document.getElementById("morbis-manap-root");if(w?.shadowRoot)return w.shadowRoot;if(w&&!w.shadowRoot)return null;w=document.createElement("div"),w.id="morbis-manap-root",w.style.cssText="position:fixed;inset:0;z-index:2147483647;pointer-events:none;display:block",document.body.appendChild(w);let C=w.attachShadow({mode:"open"}),x=document.createElement("div");x.id="app",C.appendChild(x);let y=document.createElement("style");y.id="morbis-shadow-reset",y.textContent=":host{display:block}#app{isolation:isolate;color-scheme:light}",C.appendChild(y);try{let k=`/* shadow-dom base */
*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
/* ! tailwindcss v3.4.19 | MIT License | https://tailwindcss.com *//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  /* ponytail: senior preset \u2014 :root for popup/sidepanel, :host+#app for Shadow DOM (resume modals).
     Keep in sync: edit :root. */
  :root,
  :host,
  #app {
    --background: 0 0% 100%;
    --foreground: 222.2 47% 11%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 47% 11%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 47% 11%;
    --primary: 221.2 83% 53%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 47% 11%;
    --muted: 210 40% 96%;
    --muted-foreground: 215 20% 35%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 47% 11%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 210 40% 98%;
    --border: 214 32% 72%;
    --input: 214 32% 72%;
    --ring: 221 83% 53%;
    --radius: 0.75rem;
    --warning: 38 92% 50%;
    --warning-foreground: 48 96% 12%;
  }

  /* ponytail: Shadow DOM needs its own color-scheme + base reset; :host isolates from page CSS */
  :host {
    all: initial;
  }
  #app {
    color-scheme: light;
    isolation: isolate;
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    box-sizing: border-box;
  }
  #app *,
  #app *::before,
  #app *::after {
    box-sizing: border-box;
  }

  @theme inline {
    --color-warning: var(--warning);
    --color-warning-foreground: var(--warning-foreground);
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 48%;
    --md-scrollbar: #484d54;
  }

  ::-moz-selection {
    background: #2469f0;
    color: white;
  }

  ::selection {
    background: #2469f0;
    color: white;
  }

  * {
    scrollbar-width: thin;
    scrollbar-color: #c9cdd4 transparent;
  }

  .dark * {
    scrollbar-color: var(--md-scrollbar) transparent;
  }

  *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  *::-webkit-scrollbar-track {
    background: transparent;
  }

  *::-webkit-scrollbar-thumb {
    background: #c9cdd4;
    border-radius: 3px;
  }

  .dark *::-webkit-scrollbar-thumb {
    background: var(--md-scrollbar);
  }

  *::-webkit-scrollbar-thumb:hover {
    background: #a4a9b3;
  }

  .dark *::-webkit-scrollbar-thumb:hover {
    background: #636971;
  }
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {
  .\\!container {
    max-width: 640px !important;
  }
  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {
  .\\!container {
    max-width: 768px !important;
  }
  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {
  .\\!container {
    max-width: 1024px !important;
  }
  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {
  .\\!container {
    max-width: 1280px !important;
  }
  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {
  .\\!container {
    max-width: 1536px !important;
  }
  .container {
    max-width: 1536px;
  }
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.pointer-events-none {
  pointer-events: none;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.collapse {
  visibility: collapse;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-4 {
  bottom: 1rem;
}
.left-1\\/2 {
  left: 50%;
}
.right-4 {
  right: 1rem;
}
.top-1\\/2 {
  top: 50%;
}
.z-10 {
  z-index: 10;
}
.z-50 {
  z-index: 50;
}
.z-\\[1\\] {
  z-index: 1;
}
.z-\\[2147483647\\] {
  z-index: 2147483647;
}
.col-span-full {
  grid-column: 1 / -1;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.-mb-\\[1px\\] {
  margin-bottom: -1px;
}
.mb-1 {
  margin-bottom: 0.25rem;
}
.mb-1\\.5 {
  margin-bottom: 0.375rem;
}
.mb-2 {
  margin-bottom: 0.5rem;
}
.mb-3 {
  margin-bottom: 0.75rem;
}
.mb-4 {
  margin-bottom: 1rem;
}
.ml-1 {
  margin-left: 0.25rem;
}
.mr-1 {
  margin-right: 0.25rem;
}
.mr-2 {
  margin-right: 0.5rem;
}
.mr-3 {
  margin-right: 0.75rem;
}
.mr-auto {
  margin-right: auto;
}
.mt-0\\.5 {
  margin-top: 0.125rem;
}
.mt-1 {
  margin-top: 0.25rem;
}
.mt-2 {
  margin-top: 0.5rem;
}
.mt-3 {
  margin-top: 0.75rem;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.\\!contents {
  display: contents !important;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-1\\.5 {
  width: 0.375rem;
  height: 0.375rem;
}
.size-10 {
  width: 2.5rem;
  height: 2.5rem;
}
.size-3 {
  width: 0.75rem;
  height: 0.75rem;
}
.size-3\\.5 {
  width: 0.875rem;
  height: 0.875rem;
}
.size-4 {
  width: 1rem;
  height: 1rem;
}
.size-5 {
  width: 1.25rem;
  height: 1.25rem;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.h-1 {
  height: 0.25rem;
}
.h-10 {
  height: 2.5rem;
}
.h-11 {
  height: 2.75rem;
}
.h-12 {
  height: 3rem;
}
.h-2 {
  height: 0.5rem;
}
.h-24 {
  height: 6rem;
}
.h-4 {
  height: 1rem;
}
.h-5 {
  height: 1.25rem;
}
.h-6 {
  height: 1.5rem;
}
.h-7 {
  height: 1.75rem;
}
.h-8 {
  height: 2rem;
}
.h-9 {
  height: 2.25rem;
}
.h-\\[300px\\] {
  height: 300px;
}
.h-\\[var\\(--radix-select-trigger-height\\)\\] {
  height: var(--radix-select-trigger-height);
}
.h-full {
  height: 100%;
}
.max-h-60 {
  max-height: 15rem;
}
.max-h-\\[220px\\] {
  max-height: 220px;
}
.max-h-\\[280px\\] {
  max-height: 280px;
}
.max-h-\\[360px\\] {
  max-height: 360px;
}
.max-h-\\[420px\\] {
  max-height: 420px;
}
.max-h-\\[600px\\] {
  max-height: 600px;
}
.min-h-11 {
  min-height: 2.75rem;
}
.min-h-\\[200px\\] {
  min-height: 200px;
}
.min-h-\\[80px\\] {
  min-height: 80px;
}
.w-10 {
  width: 2.5rem;
}
.w-11 {
  width: 2.75rem;
}
.w-12 {
  width: 3rem;
}
.w-2 {
  width: 0.5rem;
}
.w-28 {
  width: 7rem;
}
.w-4 {
  width: 1rem;
}
.w-5 {
  width: 1.25rem;
}
.w-6 {
  width: 1.5rem;
}
.w-7 {
  width: 1.75rem;
}
.w-9 {
  width: 2.25rem;
}
.w-\\[100px\\] {
  width: 100px;
}
.w-\\[120px\\] {
  width: 120px;
}
.w-\\[340px\\] {
  width: 340px;
}
.w-\\[76px\\] {
  width: 76px;
}
.w-\\[90px\\] {
  width: 90px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-0 {
  min-width: 0px;
}
.min-w-\\[100px\\] {
  min-width: 100px;
}
.min-w-\\[110px\\] {
  min-width: 110px;
}
.min-w-\\[12rem\\] {
  min-width: 12rem;
}
.min-w-\\[80px\\] {
  min-width: 80px;
}
.min-w-\\[90px\\] {
  min-width: 90px;
}
.min-w-\\[var\\(--radix-select-trigger-width\\)\\] {
  min-width: var(--radix-select-trigger-width);
}
.max-w-\\[120px\\] {
  max-width: 120px;
}
.max-w-\\[140px\\] {
  max-width: 140px;
}
.max-w-\\[200px\\] {
  max-width: 200px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-90 {
  --tw-scale-x: .9;
  --tw-scale-y: .9;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes pulse {
  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes slide-up {
  0% {
    opacity: 0;
    transform: translateY(8px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
.animate-slide-up {
  animation: slide-up 0.15s ease-out;
}
.cursor-default {
  cursor: default;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize-y {
  resize: vertical;
}
.resize {
  resize: both;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-center {
  align-items: center;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0 {
  gap: 0px;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-1\\.5 {
  gap: 0.375rem;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-2\\.5 {
  gap: 0.625rem;
}
.gap-3 {
  gap: 0.75rem;
}
.gap-4 {
  gap: 1rem;
}
.gap-x-8 {
  -moz-column-gap: 2rem;
       column-gap: 2rem;
}
.gap-y-3 {
  row-gap: 0.75rem;
}
.space-y-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.125rem * var(--tw-space-y-reverse));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}
.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.5rem * var(--tw-space-y-reverse));
}
.space-y-2\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.625rem * var(--tw-space-y-reverse));
}
.space-y-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}
.space-y-5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1.25rem * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.divide-border > :not([hidden]) ~ :not([hidden]) {
  border-color: hsl(var(--border));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-y-auto {
  overflow-y: auto;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.break-words {
  overflow-wrap: break-word;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 0.5rem;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.rounded-b-2xl {
  border-bottom-right-radius: 1rem;
  border-bottom-left-radius: 1rem;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l-2 {
  border-left-width: 2px;
}
.border-t {
  border-top-width: 1px;
}
.border-t-2 {
  border-top-width: 2px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-\\[\\#2469f0\\] {
  --tw-border-opacity: 1;
  border-color: rgb(36 105 240 / var(--tw-border-opacity, 1));
}
.border-amber-200 {
  --tw-border-opacity: 1;
  border-color: rgb(253 230 138 / var(--tw-border-opacity, 1));
}
.border-border {
  border-color: hsl(var(--border));
}
.border-destructive {
  border-color: hsl(var(--destructive));
}
.border-destructive\\/20 {
  border-color: hsl(var(--destructive) / 0.2);
}
.border-foreground {
  border-color: hsl(var(--foreground));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-input {
  border-color: hsl(var(--input));
}
.border-primary {
  border-color: hsl(var(--primary));
}
.border-primary\\/20 {
  border-color: hsl(var(--primary) / 0.2);
}
.border-primary\\/50 {
  border-color: hsl(var(--primary) / 0.5);
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.bg-\\[\\#2469f0\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(36 105 240 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  background-color: hsl(var(--accent));
}
.bg-accent\\/20 {
  background-color: hsl(var(--accent) / 0.2);
}
.bg-accent\\/40 {
  background-color: hsl(var(--accent) / 0.4);
}
.bg-accent\\/50 {
  background-color: hsl(var(--accent) / 0.5);
}
.bg-amber-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}
.bg-amber-50\\/50 {
  background-color: rgb(255 251 235 / 0.5);
}
.bg-background {
  background-color: hsl(var(--background));
}
.bg-background\\/60 {
  background-color: hsl(var(--background) / 0.6);
}
.bg-blue-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}
.bg-border {
  background-color: hsl(var(--border));
}
.bg-card {
  background-color: hsl(var(--card));
}
.bg-destructive {
  background-color: hsl(var(--destructive));
}
.bg-destructive\\/10 {
  background-color: hsl(var(--destructive) / 0.1);
}
.bg-destructive\\/5 {
  background-color: hsl(var(--destructive) / 0.05);
}
.bg-foreground {
  background-color: hsl(var(--foreground));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}
.bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}
.bg-green-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}
.bg-green-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));
}
.bg-green-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.bg-muted {
  background-color: hsl(var(--muted));
}
.bg-muted-foreground {
  background-color: hsl(var(--muted-foreground));
}
.bg-muted\\/40 {
  background-color: hsl(var(--muted) / 0.4);
}
.bg-neutral-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.bg-popover {
  background-color: hsl(var(--popover));
}
.bg-primary {
  background-color: hsl(var(--primary));
}
.bg-primary\\/10 {
  background-color: hsl(var(--primary) / 0.1);
}
.bg-primary\\/5 {
  background-color: hsl(var(--primary) / 0.05);
}
.bg-red-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}
.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}
.bg-red-500\\/5 {
  background-color: rgb(239 68 68 / 0.05);
}
.bg-red-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}
.bg-secondary {
  background-color: hsl(var(--secondary));
}
.bg-white\\/15 {
  background-color: rgb(255 255 255 / 0.15);
}
.bg-yellow-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}
.bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}
.from-muted {
  --tw-gradient-from: hsl(var(--muted)) var(--tw-gradient-from-position);
  --tw-gradient-to: hsl(var(--muted) / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.to-muted\\/50 {
  --tw-gradient-to: hsl(var(--muted) / 0.5) var(--tw-gradient-to-position);
}
.p-0\\.5 {
  padding: 0.125rem;
}
.p-1 {
  padding: 0.25rem;
}
.p-1\\.5 {
  padding: 0.375rem;
}
.p-2 {
  padding: 0.5rem;
}
.p-2\\.5 {
  padding: 0.625rem;
}
.p-3 {
  padding: 0.75rem;
}
.p-4 {
  padding: 1rem;
}
.p-5 {
  padding: 1.25rem;
}
.p-8 {
  padding: 2rem;
}
.px-1 {
  padding-left: 0.25rem;
  padding-right: 0.25rem;
}
.px-1\\.5 {
  padding-left: 0.375rem;
  padding-right: 0.375rem;
}
.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}
.px-2\\.5 {
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}
.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}
.px-3\\.5 {
  padding-left: 0.875rem;
  padding-right: 0.875rem;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-5 {
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}
.px-7 {
  padding-left: 1.75rem;
  padding-right: 1.75rem;
}
.py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}
.py-0\\.5 {
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
}
.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}
.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}
.py-12 {
  padding-top: 3rem;
  padding-bottom: 3rem;
}
.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
.py-2\\.5 {
  padding-top: 0.625rem;
  padding-bottom: 0.625rem;
}
.py-3 {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}
.py-3\\.5 {
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
}
.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}
.py-6 {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}
.pb-1\\.5 {
  padding-bottom: 0.375rem;
}
.pb-2 {
  padding-bottom: 0.5rem;
}
.pr-20 {
  padding-right: 5rem;
}
.pt-3 {
  padding-top: 0.75rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.font-\\[\\'Roboto\\'\\2c \\'Segoe_UI\\'\\2c system-ui\\2c sans-serif\\] {
  font-family: 'Roboto','Segoe UI',system-ui,sans-serif;
}
.font-mono {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace;
}
.text-\\[10px\\] {
  font-size: 10px;
}
.text-\\[11px\\] {
  font-size: 11px;
}
.text-\\[8px\\] {
  font-size: 8px;
}
.text-\\[9px\\] {
  font-size: 9px;
}
.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-md-sm {
  font-size: 12px;
  line-height: 18px;
}
.text-md-xs {
  font-size: 11px;
  line-height: 16px;
}
.text-xl {
  font-size: 1.25rem;
  line-height: 1.75rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.text-xxl {
  font-size: 22px;
  line-height: 28px;
}
.font-bold {
  font-weight: 700;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.italic {
  font-style: italic;
}
.leading-\\[1\\.6\\] {
  line-height: 1.6;
}
.leading-\\[1\\.7\\] {
  line-height: 1.7;
}
.leading-normal {
  line-height: 1.5;
}
.leading-relaxed {
  line-height: 1.625;
}
.leading-snug {
  line-height: 1.375;
}
.leading-tight {
  line-height: 1.25;
}
.tracking-\\[0\\.03em\\] {
  letter-spacing: 0.03em;
}
.tracking-tight {
  letter-spacing: -0.025em;
}
.tracking-wide {
  letter-spacing: 0.025em;
}
.tracking-wider {
  letter-spacing: 0.05em;
}
.text-\\[\\#2469f0\\] {
  --tw-text-opacity: 1;
  color: rgb(36 105 240 / var(--tw-text-opacity, 1));
}
.text-amber-700 {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}
.text-background {
  color: hsl(var(--background));
}
.text-blue-700 {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}
.text-card-foreground {
  color: hsl(var(--card-foreground));
}
.text-destructive {
  color: hsl(var(--destructive));
}
.text-destructive-foreground {
  color: hsl(var(--destructive-foreground));
}
.text-destructive\\/80 {
  color: hsl(var(--destructive) / 0.8);
}
.text-foreground {
  color: hsl(var(--foreground));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}
.text-green-50 {
  --tw-text-opacity: 1;
  color: rgb(240 253 244 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-700 {
  --tw-text-opacity: 1;
  color: rgb(21 128 61 / var(--tw-text-opacity, 1));
}
.text-muted-foreground {
  color: hsl(var(--muted-foreground));
}
.text-popover-foreground {
  color: hsl(var(--popover-foreground));
}
.text-primary {
  color: hsl(var(--primary));
}
.text-primary-foreground {
  color: hsl(var(--primary-foreground));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity, 1));
}
.text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity, 1));
}
.text-red-900 {
  --tw-text-opacity: 1;
  color: rgb(127 29 29 / var(--tw-text-opacity, 1));
}
.text-secondary-foreground {
  color: hsl(var(--secondary-foreground));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-white\\/80 {
  color: rgb(255 255 255 / 0.8);
}
.text-white\\/90 {
  color: rgb(255 255 255 / 0.9);
}
.text-yellow-600 {
  --tw-text-opacity: 1;
  color: rgb(202 138 4 / var(--tw-text-opacity, 1));
}
.text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity, 1));
}
.text-yellow-800 {
  --tw-text-opacity: 1;
  color: rgb(133 77 14 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.underline-offset-4 {
  text-underline-offset: 4px;
}
.antialiased {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.opacity-0 {
  opacity: 0;
}
.opacity-30 {
  opacity: 0.3;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-60 {
  opacity: 0.6;
}
.opacity-85 {
  opacity: 0.85;
}
.opacity-90 {
  opacity: 0.9;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.grayscale {
  --tw-grayscale: grayscale(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.duration-300 {
  transition-duration: 300ms;
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
@keyframes enter {
  from {
    opacity: var(--tw-enter-opacity, 1);
    transform: translate3d(var(--tw-enter-translate-x, 0), var(--tw-enter-translate-y, 0), 0) scale3d(var(--tw-enter-scale, 1), var(--tw-enter-scale, 1), var(--tw-enter-scale, 1)) rotate(var(--tw-enter-rotate, 0));
  }
}
@keyframes exit {
  to {
    opacity: var(--tw-exit-opacity, 1);
    transform: translate3d(var(--tw-exit-translate-x, 0), var(--tw-exit-translate-y, 0), 0) scale3d(var(--tw-exit-scale, 1), var(--tw-exit-scale, 1), var(--tw-exit-scale, 1)) rotate(var(--tw-exit-rotate, 0));
  }
}
.animate-in {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.fade-in {
  --tw-enter-opacity: 0;
}
.fade-out {
  --tw-exit-opacity: 0;
}
.duration-200 {
  animation-duration: 200ms;
}
.duration-300 {
  animation-duration: 300ms;
}
.ease-in-out {
  animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.running {
  animation-play-state: running;
}
.placeholder\\:text-muted-foreground::-moz-placeholder {
  color: hsl(var(--muted-foreground));
}
.placeholder\\:text-muted-foreground::placeholder {
  color: hsl(var(--muted-foreground));
}
.last\\:border-b-0:last-child {
  border-bottom-width: 0px;
}
.hover\\:bg-accent:hover {
  background-color: hsl(var(--accent));
}
.hover\\:bg-amber-100\\/50:hover {
  background-color: rgb(254 243 199 / 0.5);
}
.hover\\:bg-destructive\\/10:hover {
  background-color: hsl(var(--destructive) / 0.1);
}
.hover\\:bg-destructive\\/20:hover {
  background-color: hsl(var(--destructive) / 0.2);
}
.hover\\:bg-destructive\\/90:hover {
  background-color: hsl(var(--destructive) / 0.9);
}
.hover\\:bg-green-600\\/90:hover {
  background-color: rgb(22 163 74 / 0.9);
}
.hover\\:bg-green-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(21 128 61 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-neutral-900:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(23 23 23 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-primary\\/5:hover {
  background-color: hsl(var(--primary) / 0.05);
}
.hover\\:bg-primary\\/90:hover {
  background-color: hsl(var(--primary) / 0.9);
}
.hover\\:bg-red-500\\/10:hover {
  background-color: rgb(239 68 68 / 0.1);
}
.hover\\:bg-red-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-secondary\\/80:hover {
  background-color: hsl(var(--secondary) / 0.8);
}
.hover\\:bg-white\\/25:hover {
  background-color: rgb(255 255 255 / 0.25);
}
.hover\\:text-accent-foreground:hover {
  color: hsl(var(--accent-foreground));
}
.hover\\:text-destructive:hover {
  color: hsl(var(--destructive));
}
.hover\\:text-foreground:hover {
  color: hsl(var(--foreground));
}
.hover\\:text-red-600:hover {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.hover\\:underline:hover {
  text-decoration-line: underline;
}
.hover\\:opacity-70:hover {
  opacity: 0.7;
}
.focus\\:bg-accent:focus {
  background-color: hsl(var(--accent));
}
.focus\\:text-accent-foreground:focus {
  color: hsl(var(--accent-foreground));
}
.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-primary:focus {
  --tw-ring-color: hsl(var(--primary));
}
.focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity, 1));
}
.focus\\:ring-ring:focus {
  --tw-ring-color: hsl(var(--ring));
}
.focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}
.focus-visible\\:outline-none:focus-visible {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus-visible\\:ring-primary:focus-visible {
  --tw-ring-color: hsl(var(--primary));
}
.focus-visible\\:ring-ring:focus-visible {
  --tw-ring-color: hsl(var(--ring));
}
.focus-visible\\:ring-offset-1:focus-visible {
  --tw-ring-offset-width: 1px;
}
.focus-visible\\:ring-offset-2:focus-visible {
  --tw-ring-offset-width: 2px;
}
.active\\:bg-accent:active {
  background-color: hsl(var(--accent));
}
.active\\:bg-destructive:active {
  background-color: hsl(var(--destructive));
}
.active\\:bg-green-600:active {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.active\\:bg-neutral-950:active {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.active\\:bg-primary:active {
  background-color: hsl(var(--primary));
}
.active\\:bg-secondary:active {
  background-color: hsl(var(--secondary));
}
.disabled\\:pointer-events-none:disabled {
  pointer-events: none;
}
.disabled\\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}
.disabled\\:bg-muted:disabled {
  background-color: hsl(var(--muted));
}
.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}
.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}
.data-\\[disabled\\]\\:pointer-events-none[data-disabled] {
  pointer-events: none;
}
.data-\\[side\\=bottom\\]\\:translate-y-1[data-side="bottom"] {
  --tw-translate-y: 0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[side\\=top\\]\\:-translate-y-1[data-side="top"] {
  --tw-translate-y: -0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:translate-x-4[data-state="checked"] {
  --tw-translate-x: 1rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=unchecked\\]\\:translate-x-0[data-state="unchecked"] {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:bg-primary[data-state="checked"] {
  background-color: hsl(var(--primary));
}
.data-\\[state\\=unchecked\\]\\:bg-input[data-state="unchecked"] {
  background-color: hsl(var(--input));
}
.data-\\[disabled\\]\\:opacity-50[data-disabled] {
  opacity: 0.5;
}
.data-\\[state\\=open\\]\\:animate-in[data-state="open"] {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:animate-out[data-state="closed"] {
  animation-name: exit;
  animation-duration: 150ms;
  --tw-exit-opacity: initial;
  --tw-exit-scale: initial;
  --tw-exit-rotate: initial;
  --tw-exit-translate-x: initial;
  --tw-exit-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:fade-out-0[data-state="closed"] {
  --tw-exit-opacity: 0;
}
.data-\\[state\\=open\\]\\:fade-in-0[data-state="open"] {
  --tw-enter-opacity: 0;
}
.data-\\[state\\=closed\\]\\:zoom-out-95[data-state="closed"] {
  --tw-exit-scale: .95;
}
.data-\\[state\\=open\\]\\:zoom-in-95[data-state="open"] {
  --tw-enter-scale: .95;
}
@supports (backdrop-filter: var(--tw)) {
  .supports-\\[backdrop-filter\\]\\:bg-background\\/60 {
    background-color: hsl(var(--background) / 0.6);
  }
}
.dark\\:border-amber-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(146 64 14 / var(--tw-border-opacity, 1));
}
.dark\\:border-green-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 101 52 / var(--tw-border-opacity, 1));
}
.dark\\:border-red-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(127 29 29 / var(--tw-border-opacity, 1));
}
.dark\\:bg-amber-900\\/30:is(.dark *) {
  background-color: rgb(120 53 15 / 0.3);
}
.dark\\:bg-amber-950\\/20:is(.dark *) {
  background-color: rgb(69 26 3 / 0.2);
}
.dark\\:bg-blue-900\\/30:is(.dark *) {
  background-color: rgb(30 58 138 / 0.3);
}
.dark\\:bg-blue-950\\/20:is(.dark *) {
  background-color: rgb(23 37 84 / 0.2);
}
.dark\\:bg-green-950\\/20:is(.dark *) {
  background-color: rgb(5 46 22 / 0.2);
}
.dark\\:bg-red-950\\/20:is(.dark *) {
  background-color: rgb(69 10 10 / 0.2);
}
.dark\\:bg-yellow-950\\/30:is(.dark *) {
  background-color: rgb(66 32 6 / 0.3);
}
.dark\\:text-amber-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}
.dark\\:text-blue-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.dark\\:text-green-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 202 202 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
@media (min-width: 640px) {
  .sm\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
@media (min-width: 768px) {
  .md\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .md\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .md\\:text-left {
    text-align: left;
  }
}
@media (min-width: 1024px) {
  .lg\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
.\\[\\&\\>span\\]\\:line-clamp-1>span {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.\\[\\&\\>span\\]\\:h-3>span {
  height: 0.75rem;
}
.\\[\\&\\>span\\]\\:w-3>span {
  width: 0.75rem;
}
.data-\\[state\\=checked\\]\\:\\[\\&\\>span\\]\\:translate-x-3>span[data-state="checked"] {
  --tw-translate-x: 0.75rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.\\[\\&_svg\\]\\:pointer-events-none svg {
  pointer-events: none;
}
.\\[\\&_svg\\]\\:size-3\\.5 svg {
  width: 0.875rem;
  height: 0.875rem;
}
.\\[\\&_svg\\]\\:size-5 svg {
  width: 1.25rem;
  height: 1.25rem;
}
.\\[\\&_svg\\]\\:shrink-0 svg {
  flex-shrink: 0;
}
`;if(k=k.replace(/@import[^;]+;/g,""),k&&"adoptedStyleSheets"in C&&"CSSStyleSheet"in window)try{let S=new window.CSSStyleSheet;S.replaceSync(k),C.adoptedStyleSheets=[...C.adoptedStyleSheets,S]}catch{let S=document.createElement("style");S.textContent=k,C.appendChild(S)}else if(k){let S=document.createElement("style");S.textContent=k,C.appendChild(S)}}catch{}return C})(),u=`/* shadow-dom base */
*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
/* ! tailwindcss v3.4.19 | MIT License | https://tailwindcss.com *//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  /* ponytail: senior preset \u2014 :root for popup/sidepanel, :host+#app for Shadow DOM (resume modals).
     Keep in sync: edit :root. */
  :root,
  :host,
  #app {
    --background: 0 0% 100%;
    --foreground: 222.2 47% 11%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 47% 11%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 47% 11%;
    --primary: 221.2 83% 53%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 47% 11%;
    --muted: 210 40% 96%;
    --muted-foreground: 215 20% 35%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 47% 11%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 210 40% 98%;
    --border: 214 32% 72%;
    --input: 214 32% 72%;
    --ring: 221 83% 53%;
    --radius: 0.75rem;
    --warning: 38 92% 50%;
    --warning-foreground: 48 96% 12%;
  }

  /* ponytail: Shadow DOM needs its own color-scheme + base reset; :host isolates from page CSS */
  :host {
    all: initial;
  }
  #app {
    color-scheme: light;
    isolation: isolate;
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    box-sizing: border-box;
  }
  #app *,
  #app *::before,
  #app *::after {
    box-sizing: border-box;
  }

  @theme inline {
    --color-warning: var(--warning);
    --color-warning-foreground: var(--warning-foreground);
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 48%;
    --md-scrollbar: #484d54;
  }

  ::-moz-selection {
    background: #2469f0;
    color: white;
  }

  ::selection {
    background: #2469f0;
    color: white;
  }

  * {
    scrollbar-width: thin;
    scrollbar-color: #c9cdd4 transparent;
  }

  .dark * {
    scrollbar-color: var(--md-scrollbar) transparent;
  }

  *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  *::-webkit-scrollbar-track {
    background: transparent;
  }

  *::-webkit-scrollbar-thumb {
    background: #c9cdd4;
    border-radius: 3px;
  }

  .dark *::-webkit-scrollbar-thumb {
    background: var(--md-scrollbar);
  }

  *::-webkit-scrollbar-thumb:hover {
    background: #a4a9b3;
  }

  .dark *::-webkit-scrollbar-thumb:hover {
    background: #636971;
  }
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {
  .\\!container {
    max-width: 640px !important;
  }
  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {
  .\\!container {
    max-width: 768px !important;
  }
  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {
  .\\!container {
    max-width: 1024px !important;
  }
  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {
  .\\!container {
    max-width: 1280px !important;
  }
  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {
  .\\!container {
    max-width: 1536px !important;
  }
  .container {
    max-width: 1536px;
  }
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.pointer-events-none {
  pointer-events: none;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.collapse {
  visibility: collapse;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-4 {
  bottom: 1rem;
}
.left-1\\/2 {
  left: 50%;
}
.right-4 {
  right: 1rem;
}
.top-1\\/2 {
  top: 50%;
}
.z-10 {
  z-index: 10;
}
.z-50 {
  z-index: 50;
}
.z-\\[1\\] {
  z-index: 1;
}
.z-\\[2147483647\\] {
  z-index: 2147483647;
}
.col-span-full {
  grid-column: 1 / -1;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.-mb-\\[1px\\] {
  margin-bottom: -1px;
}
.mb-1 {
  margin-bottom: 0.25rem;
}
.mb-1\\.5 {
  margin-bottom: 0.375rem;
}
.mb-2 {
  margin-bottom: 0.5rem;
}
.mb-3 {
  margin-bottom: 0.75rem;
}
.mb-4 {
  margin-bottom: 1rem;
}
.ml-1 {
  margin-left: 0.25rem;
}
.mr-1 {
  margin-right: 0.25rem;
}
.mr-2 {
  margin-right: 0.5rem;
}
.mr-3 {
  margin-right: 0.75rem;
}
.mr-auto {
  margin-right: auto;
}
.mt-0\\.5 {
  margin-top: 0.125rem;
}
.mt-1 {
  margin-top: 0.25rem;
}
.mt-2 {
  margin-top: 0.5rem;
}
.mt-3 {
  margin-top: 0.75rem;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.\\!contents {
  display: contents !important;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-1\\.5 {
  width: 0.375rem;
  height: 0.375rem;
}
.size-10 {
  width: 2.5rem;
  height: 2.5rem;
}
.size-3 {
  width: 0.75rem;
  height: 0.75rem;
}
.size-3\\.5 {
  width: 0.875rem;
  height: 0.875rem;
}
.size-4 {
  width: 1rem;
  height: 1rem;
}
.size-5 {
  width: 1.25rem;
  height: 1.25rem;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.h-1 {
  height: 0.25rem;
}
.h-10 {
  height: 2.5rem;
}
.h-11 {
  height: 2.75rem;
}
.h-12 {
  height: 3rem;
}
.h-2 {
  height: 0.5rem;
}
.h-24 {
  height: 6rem;
}
.h-4 {
  height: 1rem;
}
.h-5 {
  height: 1.25rem;
}
.h-6 {
  height: 1.5rem;
}
.h-7 {
  height: 1.75rem;
}
.h-8 {
  height: 2rem;
}
.h-9 {
  height: 2.25rem;
}
.h-\\[300px\\] {
  height: 300px;
}
.h-\\[var\\(--radix-select-trigger-height\\)\\] {
  height: var(--radix-select-trigger-height);
}
.h-full {
  height: 100%;
}
.max-h-60 {
  max-height: 15rem;
}
.max-h-\\[220px\\] {
  max-height: 220px;
}
.max-h-\\[280px\\] {
  max-height: 280px;
}
.max-h-\\[360px\\] {
  max-height: 360px;
}
.max-h-\\[420px\\] {
  max-height: 420px;
}
.max-h-\\[600px\\] {
  max-height: 600px;
}
.min-h-11 {
  min-height: 2.75rem;
}
.min-h-\\[200px\\] {
  min-height: 200px;
}
.min-h-\\[80px\\] {
  min-height: 80px;
}
.w-10 {
  width: 2.5rem;
}
.w-11 {
  width: 2.75rem;
}
.w-12 {
  width: 3rem;
}
.w-2 {
  width: 0.5rem;
}
.w-28 {
  width: 7rem;
}
.w-4 {
  width: 1rem;
}
.w-5 {
  width: 1.25rem;
}
.w-6 {
  width: 1.5rem;
}
.w-7 {
  width: 1.75rem;
}
.w-9 {
  width: 2.25rem;
}
.w-\\[100px\\] {
  width: 100px;
}
.w-\\[120px\\] {
  width: 120px;
}
.w-\\[340px\\] {
  width: 340px;
}
.w-\\[76px\\] {
  width: 76px;
}
.w-\\[90px\\] {
  width: 90px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-0 {
  min-width: 0px;
}
.min-w-\\[100px\\] {
  min-width: 100px;
}
.min-w-\\[110px\\] {
  min-width: 110px;
}
.min-w-\\[12rem\\] {
  min-width: 12rem;
}
.min-w-\\[80px\\] {
  min-width: 80px;
}
.min-w-\\[90px\\] {
  min-width: 90px;
}
.min-w-\\[var\\(--radix-select-trigger-width\\)\\] {
  min-width: var(--radix-select-trigger-width);
}
.max-w-\\[120px\\] {
  max-width: 120px;
}
.max-w-\\[140px\\] {
  max-width: 140px;
}
.max-w-\\[200px\\] {
  max-width: 200px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-90 {
  --tw-scale-x: .9;
  --tw-scale-y: .9;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes pulse {
  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes slide-up {
  0% {
    opacity: 0;
    transform: translateY(8px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
.animate-slide-up {
  animation: slide-up 0.15s ease-out;
}
.cursor-default {
  cursor: default;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize-y {
  resize: vertical;
}
.resize {
  resize: both;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-center {
  align-items: center;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0 {
  gap: 0px;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-1\\.5 {
  gap: 0.375rem;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-2\\.5 {
  gap: 0.625rem;
}
.gap-3 {
  gap: 0.75rem;
}
.gap-4 {
  gap: 1rem;
}
.gap-x-8 {
  -moz-column-gap: 2rem;
       column-gap: 2rem;
}
.gap-y-3 {
  row-gap: 0.75rem;
}
.space-y-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.125rem * var(--tw-space-y-reverse));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}
.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.5rem * var(--tw-space-y-reverse));
}
.space-y-2\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.625rem * var(--tw-space-y-reverse));
}
.space-y-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}
.space-y-5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1.25rem * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.divide-border > :not([hidden]) ~ :not([hidden]) {
  border-color: hsl(var(--border));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-y-auto {
  overflow-y: auto;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.break-words {
  overflow-wrap: break-word;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 0.5rem;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.rounded-b-2xl {
  border-bottom-right-radius: 1rem;
  border-bottom-left-radius: 1rem;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l-2 {
  border-left-width: 2px;
}
.border-t {
  border-top-width: 1px;
}
.border-t-2 {
  border-top-width: 2px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-\\[\\#2469f0\\] {
  --tw-border-opacity: 1;
  border-color: rgb(36 105 240 / var(--tw-border-opacity, 1));
}
.border-amber-200 {
  --tw-border-opacity: 1;
  border-color: rgb(253 230 138 / var(--tw-border-opacity, 1));
}
.border-border {
  border-color: hsl(var(--border));
}
.border-destructive {
  border-color: hsl(var(--destructive));
}
.border-destructive\\/20 {
  border-color: hsl(var(--destructive) / 0.2);
}
.border-foreground {
  border-color: hsl(var(--foreground));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-input {
  border-color: hsl(var(--input));
}
.border-primary {
  border-color: hsl(var(--primary));
}
.border-primary\\/20 {
  border-color: hsl(var(--primary) / 0.2);
}
.border-primary\\/50 {
  border-color: hsl(var(--primary) / 0.5);
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.bg-\\[\\#2469f0\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(36 105 240 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  background-color: hsl(var(--accent));
}
.bg-accent\\/20 {
  background-color: hsl(var(--accent) / 0.2);
}
.bg-accent\\/40 {
  background-color: hsl(var(--accent) / 0.4);
}
.bg-accent\\/50 {
  background-color: hsl(var(--accent) / 0.5);
}
.bg-amber-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}
.bg-amber-50\\/50 {
  background-color: rgb(255 251 235 / 0.5);
}
.bg-background {
  background-color: hsl(var(--background));
}
.bg-background\\/60 {
  background-color: hsl(var(--background) / 0.6);
}
.bg-blue-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}
.bg-border {
  background-color: hsl(var(--border));
}
.bg-card {
  background-color: hsl(var(--card));
}
.bg-destructive {
  background-color: hsl(var(--destructive));
}
.bg-destructive\\/10 {
  background-color: hsl(var(--destructive) / 0.1);
}
.bg-destructive\\/5 {
  background-color: hsl(var(--destructive) / 0.05);
}
.bg-foreground {
  background-color: hsl(var(--foreground));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}
.bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}
.bg-green-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}
.bg-green-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));
}
.bg-green-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.bg-muted {
  background-color: hsl(var(--muted));
}
.bg-muted-foreground {
  background-color: hsl(var(--muted-foreground));
}
.bg-muted\\/40 {
  background-color: hsl(var(--muted) / 0.4);
}
.bg-neutral-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.bg-popover {
  background-color: hsl(var(--popover));
}
.bg-primary {
  background-color: hsl(var(--primary));
}
.bg-primary\\/10 {
  background-color: hsl(var(--primary) / 0.1);
}
.bg-primary\\/5 {
  background-color: hsl(var(--primary) / 0.05);
}
.bg-red-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}
.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}
.bg-red-500\\/5 {
  background-color: rgb(239 68 68 / 0.05);
}
.bg-red-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}
.bg-secondary {
  background-color: hsl(var(--secondary));
}
.bg-white\\/15 {
  background-color: rgb(255 255 255 / 0.15);
}
.bg-yellow-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}
.bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}
.from-muted {
  --tw-gradient-from: hsl(var(--muted)) var(--tw-gradient-from-position);
  --tw-gradient-to: hsl(var(--muted) / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.to-muted\\/50 {
  --tw-gradient-to: hsl(var(--muted) / 0.5) var(--tw-gradient-to-position);
}
.p-0\\.5 {
  padding: 0.125rem;
}
.p-1 {
  padding: 0.25rem;
}
.p-1\\.5 {
  padding: 0.375rem;
}
.p-2 {
  padding: 0.5rem;
}
.p-2\\.5 {
  padding: 0.625rem;
}
.p-3 {
  padding: 0.75rem;
}
.p-4 {
  padding: 1rem;
}
.p-5 {
  padding: 1.25rem;
}
.p-8 {
  padding: 2rem;
}
.px-1 {
  padding-left: 0.25rem;
  padding-right: 0.25rem;
}
.px-1\\.5 {
  padding-left: 0.375rem;
  padding-right: 0.375rem;
}
.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}
.px-2\\.5 {
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}
.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}
.px-3\\.5 {
  padding-left: 0.875rem;
  padding-right: 0.875rem;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-5 {
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}
.px-7 {
  padding-left: 1.75rem;
  padding-right: 1.75rem;
}
.py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}
.py-0\\.5 {
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
}
.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}
.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}
.py-12 {
  padding-top: 3rem;
  padding-bottom: 3rem;
}
.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
.py-2\\.5 {
  padding-top: 0.625rem;
  padding-bottom: 0.625rem;
}
.py-3 {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}
.py-3\\.5 {
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
}
.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}
.py-6 {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}
.pb-1\\.5 {
  padding-bottom: 0.375rem;
}
.pb-2 {
  padding-bottom: 0.5rem;
}
.pr-20 {
  padding-right: 5rem;
}
.pt-3 {
  padding-top: 0.75rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.font-\\[\\'Roboto\\'\\2c \\'Segoe_UI\\'\\2c system-ui\\2c sans-serif\\] {
  font-family: 'Roboto','Segoe UI',system-ui,sans-serif;
}
.font-mono {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace;
}
.text-\\[10px\\] {
  font-size: 10px;
}
.text-\\[11px\\] {
  font-size: 11px;
}
.text-\\[8px\\] {
  font-size: 8px;
}
.text-\\[9px\\] {
  font-size: 9px;
}
.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-md-sm {
  font-size: 12px;
  line-height: 18px;
}
.text-md-xs {
  font-size: 11px;
  line-height: 16px;
}
.text-xl {
  font-size: 1.25rem;
  line-height: 1.75rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.text-xxl {
  font-size: 22px;
  line-height: 28px;
}
.font-bold {
  font-weight: 700;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.italic {
  font-style: italic;
}
.leading-\\[1\\.6\\] {
  line-height: 1.6;
}
.leading-\\[1\\.7\\] {
  line-height: 1.7;
}
.leading-normal {
  line-height: 1.5;
}
.leading-relaxed {
  line-height: 1.625;
}
.leading-snug {
  line-height: 1.375;
}
.leading-tight {
  line-height: 1.25;
}
.tracking-\\[0\\.03em\\] {
  letter-spacing: 0.03em;
}
.tracking-tight {
  letter-spacing: -0.025em;
}
.tracking-wide {
  letter-spacing: 0.025em;
}
.tracking-wider {
  letter-spacing: 0.05em;
}
.text-\\[\\#2469f0\\] {
  --tw-text-opacity: 1;
  color: rgb(36 105 240 / var(--tw-text-opacity, 1));
}
.text-amber-700 {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}
.text-background {
  color: hsl(var(--background));
}
.text-blue-700 {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}
.text-card-foreground {
  color: hsl(var(--card-foreground));
}
.text-destructive {
  color: hsl(var(--destructive));
}
.text-destructive-foreground {
  color: hsl(var(--destructive-foreground));
}
.text-destructive\\/80 {
  color: hsl(var(--destructive) / 0.8);
}
.text-foreground {
  color: hsl(var(--foreground));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}
.text-green-50 {
  --tw-text-opacity: 1;
  color: rgb(240 253 244 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-700 {
  --tw-text-opacity: 1;
  color: rgb(21 128 61 / var(--tw-text-opacity, 1));
}
.text-muted-foreground {
  color: hsl(var(--muted-foreground));
}
.text-popover-foreground {
  color: hsl(var(--popover-foreground));
}
.text-primary {
  color: hsl(var(--primary));
}
.text-primary-foreground {
  color: hsl(var(--primary-foreground));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity, 1));
}
.text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity, 1));
}
.text-red-900 {
  --tw-text-opacity: 1;
  color: rgb(127 29 29 / var(--tw-text-opacity, 1));
}
.text-secondary-foreground {
  color: hsl(var(--secondary-foreground));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-white\\/80 {
  color: rgb(255 255 255 / 0.8);
}
.text-white\\/90 {
  color: rgb(255 255 255 / 0.9);
}
.text-yellow-600 {
  --tw-text-opacity: 1;
  color: rgb(202 138 4 / var(--tw-text-opacity, 1));
}
.text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity, 1));
}
.text-yellow-800 {
  --tw-text-opacity: 1;
  color: rgb(133 77 14 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.underline-offset-4 {
  text-underline-offset: 4px;
}
.antialiased {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.opacity-0 {
  opacity: 0;
}
.opacity-30 {
  opacity: 0.3;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-60 {
  opacity: 0.6;
}
.opacity-85 {
  opacity: 0.85;
}
.opacity-90 {
  opacity: 0.9;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.grayscale {
  --tw-grayscale: grayscale(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.duration-300 {
  transition-duration: 300ms;
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
@keyframes enter {
  from {
    opacity: var(--tw-enter-opacity, 1);
    transform: translate3d(var(--tw-enter-translate-x, 0), var(--tw-enter-translate-y, 0), 0) scale3d(var(--tw-enter-scale, 1), var(--tw-enter-scale, 1), var(--tw-enter-scale, 1)) rotate(var(--tw-enter-rotate, 0));
  }
}
@keyframes exit {
  to {
    opacity: var(--tw-exit-opacity, 1);
    transform: translate3d(var(--tw-exit-translate-x, 0), var(--tw-exit-translate-y, 0), 0) scale3d(var(--tw-exit-scale, 1), var(--tw-exit-scale, 1), var(--tw-exit-scale, 1)) rotate(var(--tw-exit-rotate, 0));
  }
}
.animate-in {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.fade-in {
  --tw-enter-opacity: 0;
}
.fade-out {
  --tw-exit-opacity: 0;
}
.duration-200 {
  animation-duration: 200ms;
}
.duration-300 {
  animation-duration: 300ms;
}
.ease-in-out {
  animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.running {
  animation-play-state: running;
}
.placeholder\\:text-muted-foreground::-moz-placeholder {
  color: hsl(var(--muted-foreground));
}
.placeholder\\:text-muted-foreground::placeholder {
  color: hsl(var(--muted-foreground));
}
.last\\:border-b-0:last-child {
  border-bottom-width: 0px;
}
.hover\\:bg-accent:hover {
  background-color: hsl(var(--accent));
}
.hover\\:bg-amber-100\\/50:hover {
  background-color: rgb(254 243 199 / 0.5);
}
.hover\\:bg-destructive\\/10:hover {
  background-color: hsl(var(--destructive) / 0.1);
}
.hover\\:bg-destructive\\/20:hover {
  background-color: hsl(var(--destructive) / 0.2);
}
.hover\\:bg-destructive\\/90:hover {
  background-color: hsl(var(--destructive) / 0.9);
}
.hover\\:bg-green-600\\/90:hover {
  background-color: rgb(22 163 74 / 0.9);
}
.hover\\:bg-green-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(21 128 61 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-neutral-900:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(23 23 23 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-primary\\/5:hover {
  background-color: hsl(var(--primary) / 0.05);
}
.hover\\:bg-primary\\/90:hover {
  background-color: hsl(var(--primary) / 0.9);
}
.hover\\:bg-red-500\\/10:hover {
  background-color: rgb(239 68 68 / 0.1);
}
.hover\\:bg-red-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-secondary\\/80:hover {
  background-color: hsl(var(--secondary) / 0.8);
}
.hover\\:bg-white\\/25:hover {
  background-color: rgb(255 255 255 / 0.25);
}
.hover\\:text-accent-foreground:hover {
  color: hsl(var(--accent-foreground));
}
.hover\\:text-destructive:hover {
  color: hsl(var(--destructive));
}
.hover\\:text-foreground:hover {
  color: hsl(var(--foreground));
}
.hover\\:text-red-600:hover {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.hover\\:underline:hover {
  text-decoration-line: underline;
}
.hover\\:opacity-70:hover {
  opacity: 0.7;
}
.focus\\:bg-accent:focus {
  background-color: hsl(var(--accent));
}
.focus\\:text-accent-foreground:focus {
  color: hsl(var(--accent-foreground));
}
.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-primary:focus {
  --tw-ring-color: hsl(var(--primary));
}
.focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity, 1));
}
.focus\\:ring-ring:focus {
  --tw-ring-color: hsl(var(--ring));
}
.focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}
.focus-visible\\:outline-none:focus-visible {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus-visible\\:ring-primary:focus-visible {
  --tw-ring-color: hsl(var(--primary));
}
.focus-visible\\:ring-ring:focus-visible {
  --tw-ring-color: hsl(var(--ring));
}
.focus-visible\\:ring-offset-1:focus-visible {
  --tw-ring-offset-width: 1px;
}
.focus-visible\\:ring-offset-2:focus-visible {
  --tw-ring-offset-width: 2px;
}
.active\\:bg-accent:active {
  background-color: hsl(var(--accent));
}
.active\\:bg-destructive:active {
  background-color: hsl(var(--destructive));
}
.active\\:bg-green-600:active {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.active\\:bg-neutral-950:active {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.active\\:bg-primary:active {
  background-color: hsl(var(--primary));
}
.active\\:bg-secondary:active {
  background-color: hsl(var(--secondary));
}
.disabled\\:pointer-events-none:disabled {
  pointer-events: none;
}
.disabled\\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}
.disabled\\:bg-muted:disabled {
  background-color: hsl(var(--muted));
}
.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}
.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}
.data-\\[disabled\\]\\:pointer-events-none[data-disabled] {
  pointer-events: none;
}
.data-\\[side\\=bottom\\]\\:translate-y-1[data-side="bottom"] {
  --tw-translate-y: 0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[side\\=top\\]\\:-translate-y-1[data-side="top"] {
  --tw-translate-y: -0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:translate-x-4[data-state="checked"] {
  --tw-translate-x: 1rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=unchecked\\]\\:translate-x-0[data-state="unchecked"] {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:bg-primary[data-state="checked"] {
  background-color: hsl(var(--primary));
}
.data-\\[state\\=unchecked\\]\\:bg-input[data-state="unchecked"] {
  background-color: hsl(var(--input));
}
.data-\\[disabled\\]\\:opacity-50[data-disabled] {
  opacity: 0.5;
}
.data-\\[state\\=open\\]\\:animate-in[data-state="open"] {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:animate-out[data-state="closed"] {
  animation-name: exit;
  animation-duration: 150ms;
  --tw-exit-opacity: initial;
  --tw-exit-scale: initial;
  --tw-exit-rotate: initial;
  --tw-exit-translate-x: initial;
  --tw-exit-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:fade-out-0[data-state="closed"] {
  --tw-exit-opacity: 0;
}
.data-\\[state\\=open\\]\\:fade-in-0[data-state="open"] {
  --tw-enter-opacity: 0;
}
.data-\\[state\\=closed\\]\\:zoom-out-95[data-state="closed"] {
  --tw-exit-scale: .95;
}
.data-\\[state\\=open\\]\\:zoom-in-95[data-state="open"] {
  --tw-enter-scale: .95;
}
@supports (backdrop-filter: var(--tw)) {
  .supports-\\[backdrop-filter\\]\\:bg-background\\/60 {
    background-color: hsl(var(--background) / 0.6);
  }
}
.dark\\:border-amber-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(146 64 14 / var(--tw-border-opacity, 1));
}
.dark\\:border-green-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 101 52 / var(--tw-border-opacity, 1));
}
.dark\\:border-red-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(127 29 29 / var(--tw-border-opacity, 1));
}
.dark\\:bg-amber-900\\/30:is(.dark *) {
  background-color: rgb(120 53 15 / 0.3);
}
.dark\\:bg-amber-950\\/20:is(.dark *) {
  background-color: rgb(69 26 3 / 0.2);
}
.dark\\:bg-blue-900\\/30:is(.dark *) {
  background-color: rgb(30 58 138 / 0.3);
}
.dark\\:bg-blue-950\\/20:is(.dark *) {
  background-color: rgb(23 37 84 / 0.2);
}
.dark\\:bg-green-950\\/20:is(.dark *) {
  background-color: rgb(5 46 22 / 0.2);
}
.dark\\:bg-red-950\\/20:is(.dark *) {
  background-color: rgb(69 10 10 / 0.2);
}
.dark\\:bg-yellow-950\\/30:is(.dark *) {
  background-color: rgb(66 32 6 / 0.3);
}
.dark\\:text-amber-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}
.dark\\:text-blue-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.dark\\:text-green-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 202 202 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
@media (min-width: 640px) {
  .sm\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
@media (min-width: 768px) {
  .md\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .md\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .md\\:text-left {
    text-align: left;
  }
}
@media (min-width: 1024px) {
  .lg\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
.\\[\\&\\>span\\]\\:line-clamp-1>span {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.\\[\\&\\>span\\]\\:h-3>span {
  height: 0.75rem;
}
.\\[\\&\\>span\\]\\:w-3>span {
  width: 0.75rem;
}
.data-\\[state\\=checked\\]\\:\\[\\&\\>span\\]\\:translate-x-3>span[data-state="checked"] {
  --tw-translate-x: 0.75rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.\\[\\&_svg\\]\\:pointer-events-none svg {
  pointer-events: none;
}
.\\[\\&_svg\\]\\:size-3\\.5 svg {
  width: 0.875rem;
  height: 0.875rem;
}
.\\[\\&_svg\\]\\:size-5 svg {
  width: 1.25rem;
  height: 1.25rem;
}
.\\[\\&_svg\\]\\:shrink-0 svg {
  flex-shrink: 0;
}
`.replace(/@import[^;]+;/g,""),f=`
      .resume-modal {
        background: #f8f6f3;
        border-radius: 20px;
        box-shadow: 0 25px 60px rgba(0,0,0,.3);
        width: 94%;
        max-width: 900px;
        max-height: 90vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: resume-slideup .3s ease;
        font-size: 16px;
        line-height: 1.6;
        color: #1a1d23;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
      }
      /* Paksa Roboto 16px/1.6 di atas CSS host (termasuk yang !important):
         menang di light-DOM fallback & elemen yang tidak inherit font
         (button native). Kode ICD (.font-mono) dikecualikan. */
      .resume-modal,
      .resume-modal *:not(.font-mono) {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
        line-height: 1.6 !important;
      }
      /* Dropdown bawaan browser (option/optgroup): render native, paksa eksplisit. */
      .resume-modal option,
      .resume-modal optgroup {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
      }
      .resume-modal *,
      .resume-modal *::before,
      .resume-modal *::after {
        box-sizing: border-box;
      }
      .resume-modal input,
      .resume-modal select,
      .resume-modal textarea {
        all: unset;
        box-sizing: border-box;
        font-family: inherit;
        font-size: inherit;
        color: inherit;
        cursor: default;
        height: auto;
        min-height: 32px;
        width: 100%;
        border: 1px solid hsl(214.3 31.8% 91.4%);
        border-radius: 6px;
        background: white;
        padding: 4px 10px;
        outline: none;
        transition: border-color 0.15s, box-shadow 0.15s;
      }
      .resume-modal input:focus,
      .resume-modal select:focus,
      .resume-modal textarea:focus {
        border-color: hsl(221.2 83.2% 53.3%);
        box-shadow: 0 0 0 2px hsl(221.2 83.2% 53.3% / 0.15);
      }
      .resume-modal textarea {
        resize: vertical;
        min-height: 80px;
        padding: 8px 10px;
      }
      .resume-modal select {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 8px center;
        padding-right: 28px;
      }
      .resume-modal h1,
      .resume-modal h2,
      .resume-modal h3 {
        font-family: 'Lexend', system-ui, sans-serif;
      }
    `;if(c&&!c.getElementById("morbis-resume-shadow-css")){let w=document.createElement("style");w.id="morbis-resume-shadow-css",w.textContent=u+f,c.appendChild(w)}if(!document.getElementById("morbis-resume-css")){let w=document.createElement("style");w.id="morbis-resume-css",w.textContent=u+`
      /* \u2500\u2500 Reset host-page overrides inside the modal \u2500\u2500 */
      /* ponytail: specificity 0-2-0 beats most host styles without !important */
      .resume-modal .resume-modal {
        background: #f8f6f3;
        border-radius: 20px;
        box-shadow: 0 25px 60px rgba(0,0,0,.3);
        width: 94%;
        max-width: 900px;
        max-height: 90vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: resume-slideup .3s ease;
        font-size: 16px;
        line-height: 1.6;
        color: #1a1d23;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
      }
      /* Paksa Roboto 16px/1.6 di atas CSS host (termasuk yang !important):
         menang di light-DOM fallback & elemen yang tidak inherit font
         (button native). Kode ICD (.font-mono) dikecualikan. */
      .resume-modal,
      .resume-modal *:not(.font-mono) {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
        line-height: 1.6 !important;
      }
      /* Dropdown bawaan browser (option/optgroup): render native, paksa eksplisit. */
      .resume-modal option,
      .resume-modal optgroup {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
      }

      /* \u2500\u2500 Dropdown autocomplete ICD \u2500\u2500
         Aturan .resume-modal *:not(.font-mono) di atas memaksa
         font-size 16px !important untuk SELURUH isi modal, sehingga
         class Tailwind apa pun (text-lg/text-xl/text-xxl) ikut
         tertimpa. Baris nama & kode pada dropdown dikecualikan lalu
         diberi ukuran eksplisit di sini, setelah aturan itu, dengan
         !important yang sama supaya benar-benar menang.
         Kode sengaja TANPA font-mono: JetBrains Mono punya x-height
         jauh lebih rendah sehingga kode terlihat kecil dibanding nama.
         Catatan: jangan pakai backtick di dalam template literal ini. */
      .resume-modal .rj-icd-hit-nama,
      .resume-modal .rj-icd-hit-kode {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
      }
      .resume-modal .rj-icd-hit-nama {
        font-size: 18px !important;
        line-height: 1.4 !important;
      }
      .resume-modal .rj-icd-hit-kode {
        font-size: 22px !important;
        line-height: 1.25 !important;
      }
      .resume-modal .resume-modal *,
      .resume-modal .resume-modal *::before,
      .resume-modal .resume-modal *::after {
        box-sizing: border-box;
      }
      /* Neutralize host page input/select/textarea defaults.
         No reset on buttons \u2014 our Button component owns its own styling via Tailwind. */
      .resume-modal .resume-modal input,
      .resume-modal .resume-modal select,
      .resume-modal .resume-modal textarea {
        all: unset;
        box-sizing: border-box;
        font-family: inherit;
        font-size: inherit;
        color: inherit;
        cursor: default;
      }
      .resume-modal .resume-modal input,
      .resume-modal .resume-modal select,
      .resume-modal .resume-modal textarea {
        height: auto;
        min-height: 32px;
        width: 100%;
        border: 1px solid hsl(214.3 31.8% 91.4%);
        border-radius: 6px;
        background: white;
        padding: 4px 10px;
        outline: none;
        transition: border-color 0.15s, box-shadow 0.15s;
      }
      .resume-modal .resume-modal input:focus,
      .resume-modal .resume-modal select:focus,
      .resume-modal .resume-modal textarea:focus {
        border-color: hsl(221.2 83.2% 53.3%);
        box-shadow: 0 0 0 2px hsl(221.2 83.2% 53.3% / 0.15);
      }
      .resume-modal .resume-modal textarea {
        resize: vertical;
        min-height: 80px;
        padding: 8px 10px;
      }
      .resume-modal .resume-modal select {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 8px center;
        padding-right: 28px;
      }
      .resume-modal .resume-modal h1,
      .resume-modal .resume-modal h2,
      .resume-modal .resume-modal h3 {
        font-family: 'Lexend', system-ui, sans-serif;
      }
      /* \u2500\u2500 Radix Select portal (renders outside .resume-modal) \u2500\u2500 */
      [data-radix-select-viewport] {
        padding: 4px;
      }
      [data-radix-select-viewport] [role="option"] {
        all: unset;
        display: flex;
        align-items: center;
        padding: 6px 8px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
        line-height: 18px;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
        color: #1a1d23;
      }
      [data-radix-select-viewport] [role="option"]:focus,
      [data-radix-select-viewport] [role="option"][data-highlighted] {
        background: hsl(210 40% 96.1%);
        color: hsl(222.2 47.4% 11.2%);
      }
      [data-radix-popper-content-wrapper] {
        z-index: 2147483646 !important;
      }
      @keyframes resume-slideup { from { opacity: 0; transform: translateY(24px) } to { opacity: 1; transform: translateY(0) } }
    `,document.head.appendChild(w)}let b=(()=>{if(!c)return i;i.style.display="none";let w=c.getElementById("app"),C=c.getElementById("ext-resume-shadow-container");C||(C=document.createElement("div"),C.id="ext-resume-shadow-container",C.style.cssText="position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;pointer-events:auto",(w??c).appendChild(C)),C.style.display="flex",_n&&(_n.style.display="none");let x=document.querySelector("[data-scroll-buttons]");return x&&(x.style.display="none"),C})();kr=(0,Um.createRoot)(b);let h=async w=>{let C=Yh(w),x=await fetch(qh,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:C,credentials:"same-origin"}),y=await x.text();if(!x.ok)throw console.error("[RJ] save failed:",x.status,y),new Error("HTTP "+x.status);let k=null;try{k=JSON.parse(y)}catch{k=null}if(k){if(Number(k.status)!==200)throw console.error("[RJ] server reject:",k),new Error(k.msg||"Gagal simpan (status "+k.status+")")}else{let X=/(?:<b>)?(?:Notice|Warning|Fatal error|Parse error|Catchable fatal error)(?:<\/b>)?\s*:\s*[^<]*/gi,B=[],G;for(;(G=X.exec(y))!==null;){let oe=G[0].trim().replace(/<[^>]+>/g,"");oe&&(/github\.com\/newrelic|newrelic-browser|google-analytics|googletagmanager/i.test(oe)||B.push(oe))}if(B.length>0)throw console.error("[RJ] PHP errors:",B),new Error(B.join(`
`))}te=null;let S=w.patientInfo.id_visit||new URLSearchParams(location.search).get("id_visit")||"",q=w.patientInfo.id_rawat_jalan||new URLSearchParams(location.search).get("id")||"";cg({idVisit:S,idResume:q,tipe:"rajal",aksi:q?"ubah":"buat",before:tg(S,"rajal")??{},after:gg(w)})};kr.render((0,uu.jsx)($h,{onError:()=>setTimeout(()=>Xi(i),0),children:(0,uu.jsx)(Fh,{data:s,onSave:h,onClose:()=>Xi(i)})})),document.body.classList.add("ext-resume-open"),setTimeout(()=>{(c?.getElementById("ext-resume-shadow-container")??i).querySelectorAll("textarea").forEach(w=>{let C=w;C.addEventListener("input",()=>{C.style.height="auto",C.style.height=C.scrollHeight+"px"}),C.dispatchEvent(new Event("input"))})},50)}var te=null;function Kh(i){let s={},c=(u,f)=>{u&&(u.endsWith("[]")?(Array.isArray(s[u])||(s[u]=[]),s[u].push(f)):s[u]=f)};return i.querySelectorAll("input[name]").forEach(u=>{let f=(u.getAttribute("type")||"text").toLowerCase();(f==="radio"||f==="checkbox")&&!u.checked||f==="submit"||f==="button"||f==="file"||f==="image"||c(u.name,u.value??"")}),i.querySelectorAll("textarea[name]").forEach(u=>{c(u.name,u.value??"")}),i.querySelectorAll("select").forEach(u=>{u.id&&(s[u.id]=u.value??""),u.name&&c(u.name,u.value??"")}),s}var mu=[];async function Xh(){let i=new URLSearchParams(location.search).get("id_visit");if(!i)return{};let s=[`${location.origin}/admisi/pelaksanaan_pelayanan/rm-rawat-jalan-new?id_visit=${i}&page=6`,`${location.origin}/admisi/pelaksanaan_pelayanan/rm-rawat-jalan-new?id_visit=${i}`,`${location.origin}/admisi/pelaksanaan_pelayanan/rj?id_visit=${i}`];for(let c of s)for(let u=0;u<3;u++){u>0&&await new Promise(f=>setTimeout(f,350));try{let f=await fetch(c,{credentials:"same-origin",cache:"no-store",headers:{Referer:location.origin+"/admisi/pelaksanaan_pelayanan/"}});if(!f.ok)continue;let b=await f.text(),h=new DOMParser().parseFromString(b,"text/html");if(h.querySelector('form, input[name="id_kunjungan"]')===null)break;let w=Kh(h);if(w.id_kunjungan)return mu=Object.keys(w),w;break}catch(f){console.warn("[RJ] fetchFormState gagal untuk",c,f)}}return console.warn("[RJ] fetchFormState: tidak menemukan form RJ untuk id_visit",i),{}}function Gh(){let i=[];for(let s of document.querySelectorAll("p, td")){let c=s.textContent?.trim().match(/No Resep\s*:\s*(\d+)/i);c&&!i.includes(c[1])&&i.push(c[1])}return i}async function Jh(i){let s=await(await fetch(i,{credentials:"same-origin"})).text(),c=new DOMParser().parseFromString(s,"text/html").querySelectorAll("h5"),u=null;for(let w of c)if(w.textContent?.trim()==="Resep yang ditebus"){u=w;break}if(!u)return[];let f=u.nextElementSibling;for(;f&&f.tagName!=="TABLE";)f=f.nextElementSibling;if(!f)return[];let b=[],h=f.querySelectorAll("tr");for(let w=1;w<h.length;w++){let C=h[w].querySelectorAll("td");if(C.length<8)continue;let x=C[1]?.textContent?.trim(),y=C[7]?.textContent?.trim(),k=C[5]?.textContent?.trim();x&&b.push(`${x} - ${y||"-"}`)}return b}async function Zh(){let i=Gh();if(!i.length)return null;let s=await Promise.all(i.map(f=>{let b=`${location.origin}/admisi/pelaksanaan_pelayanan/history/resep?id=${f}`;return Jh(b)})),c=new Set,u=[];for(let f of s)for(let b of f){let h=b.split(" - ")[0];c.has(h)||(c.add(h),u.push(b))}return u.length?u.join(`
`):null}function gu(){if(!location.href.startsWith(location.origin+"/v2/m-klaim/detail-v2-refaktor")||!new URLSearchParams(location.search).has("id_visit")||(document.querySelector("input[name=jenis]")?.value??document.querySelector("select[name=jenis]")?.value??"").toUpperCase().includes("INAP")||document.getElementById("ext-resume-float-btn"))return;let i=document.createElement("div");i.id="ext-resume-container",i.className="resume-modal",i.style.cssText="position: fixed; inset: 0; z-index: 2147483647; display: none; background: rgba(0,0,0,.4); align-items: center; justify-content: center;",document.body.appendChild(i);let s=document.createElement("button");_n=s,s.id="ext-resume-float-btn",s.textContent="RJ",s.title="Resume Rajal",s.style.cssText="position:fixed;right:16px;top:50%;transform:translateY(-50%);z-index:2147483645;width:48px;height:48px;border-radius:12px;border:none;background:#2b5f8a;color:white;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.2);transition:transform .15s,box-shadow .15s;",s.onmouseenter=()=>{s.style.transform="translateY(-50%) scale(1.05)",s.style.boxShadow="0 4px 16px rgba(43,95,138,.35)"},s.onmouseleave=()=>{s.style.transform="translateY(-50%)",s.style.boxShadow="0 2px 8px rgba(0,0,0,.2)"},s.addEventListener("click",async()=>{if(!s.disabled){s.disabled=!0;try{te||(te=await Xh());let c=await Zh(),u=Vh();c&&(u.clinicalNotes.terapi_pengobatan=c);let f=!u.clinicalNotes.tindakan||u.clinicalNotes.tindakan==="-",b=!u.clinicalNotes.terapi_pengobatan||u.clinicalNotes.terapi_pengobatan==="-";if(f||b){let h=pu();h.tindakan&&f&&(u.clinicalNotes.tindakan=h.tindakan),h.terapiPengobatan&&b&&(u.clinicalNotes.terapi_pengobatan=h.terapiPengobatan)}i.style.display="flex",Qh(i,u)}catch(c){console.error("[RJ] click error:",c),i.style.display="none",s.disabled=!1}}}),document.body.appendChild(s),document.addEventListener("keydown",c=>{c.key==="Escape"&&i.style.display!=="none"&&Xi(i)})}function hu(){return document.documentElement.getAttribute("data-ext-resume-modal")==="1"}function eb(){return["/login","/auth","/signin","/masuk","/keluar","/logout"].some(i=>location.pathname.toLowerCase().includes(i))||document.querySelectorAll('input[type="password"]').length>0}function tb(i=5e3){return hu()?Promise.resolve(!0):new Promise(s=>{let c=Date.now(),u=setInterval(()=>{hu()?(clearInterval(u),s(!0)):Date.now()-c>i&&(clearInterval(u),s(!1))},200)})}return(async()=>eb()||await tb()&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",gu):gu()))(),zm($m)})();/*! Bundled license information:

scheduler/cjs/scheduler.production.js:
  (**
   * @license React
   * scheduler.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react.production.js:
  (**
   * @license React
   * react.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.js:
  (**
   * @license React
   * react-dom.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom-client.production.js:
  (**
   * @license React
   * react-dom-client.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react-jsx-runtime.production.js:
  (**
   * @license React
   * react-jsx-runtime.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs:
lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs:
lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs:
lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs:
lucide-react/dist/esm/defaultAttributes.mjs:
lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs:
lucide-react/dist/esm/context.mjs:
lucide-react/dist/esm/Icon.mjs:
lucide-react/dist/esm/createLucideIcon.mjs:
lucide-react/dist/esm/icons/check.mjs:
lucide-react/dist/esm/icons/info.mjs:
lucide-react/dist/esm/icons/triangle-alert.mjs:
lucide-react/dist/esm/icons/x.mjs:
lucide-react/dist/esm/lucide-react.mjs:
  (**
   * @license lucide-react v1.38.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
