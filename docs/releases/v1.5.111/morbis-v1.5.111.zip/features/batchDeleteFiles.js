"use strict";var __morbis_feature=(()=>{function M(){return window}var $="ext-batch-shared-style";function S(){if(document.getElementById($))return;let e=document.createElement("style");e.id=$,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}var h={search:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',trash:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>',xClose:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>',warning:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 00-3.48 0l-8 14A2 2 0 004 21h16a2 2 0 001.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',eye:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',refresh:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 11-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>',upload:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',file:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',check:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',arrowRight:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>'};function z(e,t){let n=t||18;return`<span style="display:inline-flex;align-items:center;justify-content:center;width:${n}px;height:${n}px;flex-shrink:0;">${e}</span>`}async function D(e,t){try{let n=await fetch(e,{method:"GET",mode:"cors",credentials:"omit"});if(!n.ok)throw new Error(`HTTP ${n.status}`);let a=await n.blob(),i=URL.createObjectURL(a);A(i,t,e,()=>URL.revokeObjectURL(i))}catch{A(e,t,e)}}var w=null;function A(e,t,n,a){w&&w();let i=t.toLowerCase().split(".").pop()||"",l=i==="pdf",p=["jpg","jpeg","png","gif","webp"].includes(i),r=document.createElement("div");r.id="ext-inline-preview-modal",r.style.cssText="position:fixed !important;top:0 !important;left:0 !important;width:100vw !important;height:100vh !important;background:rgba(15,23,42,0.88) !important;z-index:10001 !important;display:flex !important;align-items:center !important;justify-content:center !important;flex-direction:column !important;padding:20px !important;box-sizing:border-box !important;backdrop-filter:blur(8px) !important;-webkit-backdrop-filter:blur(8px) !important;";let o='<div class="ext-inline-preview-loading" style="display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;color:#fff;"><div class="ext-inline-preview-spinner"></div><div style="font-size:14px;">Loading preview...</div></div>';l?o=`<iframe id="ext-inline-preview-iframe" src="${e}" style="width:100%;height:100%;border:none;display:block;border-radius:12px;"></iframe>`:p?o=`<img id="ext-inline-preview-img" src="${e}" alt="Image Preview" style="width:100%;height:100%;border:none;display:block;object-fit:contain;border-radius:12px;">`:o=`<div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:15px;color:#64748b;background:#f8fafc;flex-direction:column;gap:16px;border-radius:12px;">${h.file}<div>Preview not available for this format</div></div>`;let c=t.replace(/"/g,"&quot;").replace(/</g,"&lt;");r.innerHTML=`
    <div style="position:absolute;top:20px;right:20px;display:flex;gap:10px;align-items:center;background:rgba(15,23,42,0.8);padding:10px 16px;border-radius:12px;backdrop-filter:blur(12px);z-index:10002;border:1px solid rgba(255,255,255,0.1);">
      <span style="color:#e2e8f0;font-size:13px;max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500;">${c}</span>
      <button id="ext-preview-newtab" style="padding:7px 14px;background:#3b82f6;color:white;border:none;border-radius:8px;cursor:pointer;font-size:12px;font-weight:600;transition:background 0.15s ease;display:inline-flex;align-items:center;gap:6px;">${h.arrowRight} Open Tab</button>
      <button id="ext-preview-close" style="padding:7px 12px;background:rgba(255,255,255,0.1);color:#e2e8f0;border:1px solid rgba(255,255,255,0.15);border-radius:8px;cursor:pointer;font-size:16px;font-weight:500;transition:all 0.15s ease;line-height:1;">${h.xClose}</button>
    </div>
    <div style="width:clamp(400px,90vw,1200px);height:clamp(300px,90vh,800px);background:white;border-radius:16px;box-shadow:0 25px 60px rgba(0,0,0,0.4);overflow:hidden;position:relative;">${o}</div>
  `,document.body.appendChild(r);let u=!1,m,f=g=>{g.key==="Escape"&&x()},x=()=>{u||(u=!0,w===x&&(w=null),a&&a(),document.removeEventListener("keydown",f),m!==void 0&&clearInterval(m),r.remove())};w=x,document.getElementById("ext-preview-close")?.addEventListener("click",x),document.getElementById("ext-preview-newtab")?.addEventListener("click",()=>{window.open(n||e,"_blank"),x()}),r.addEventListener("click",g=>{g.target===r&&x()}),document.addEventListener("keydown",f),(l||p)&&(m=window.setInterval(()=>{if(l?document.getElementById("ext-inline-preview-iframe")?.getAttribute("src"):document.getElementById("ext-inline-preview-img")?.complete){let g=r.querySelector(".ext-inline-preview-loading");g&&g.remove(),clearInterval(m)}},500))}function v(e){return new Promise(t=>{S();let n=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",a=document.createElement("div");a.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",a.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${n}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,a.querySelector("h3").textContent=e.title;let i=a.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((o,c)=>{c>0&&i.appendChild(document.createElement("br")),i.appendChild(document.createTextNode(o))});let l=o=>{a.remove(),document.removeEventListener("keydown",p),t(o)},p=o=>{o.key==="Escape"&&l(!1)};a.querySelector(".ext-modal-close").addEventListener("click",()=>l(!1)),a.addEventListener("click",o=>{o.target===a&&l(!1)}),a.querySelector("[data-ext-ok]").addEventListener("click",()=>l(!0));let r=a.querySelector("[data-ext-cancel]");r&&r.addEventListener("click",()=>l(!1)),document.addEventListener("keydown",p),document.body.appendChild(a)})}var L=M(),d={deleteEndpoint:"/admisi/pelaksanaan_pelayanan/dokumen-pasien/control?sub=hapus",fetchListUrl:"/admisi/pelaksanaan_pelayanan/dokumen-pasien",maxConcurrent:1,maxBatchSize:10,delayBetweenDelete:500,modalId:"ext-batch-delete-modal",previewId:"ext-delete-preview-list",progressId:"ext-delete-progress-bar",statusId:"ext-delete-status-text"},s=[],b=!1;function j(){if(document.getElementById("ext-batch-delete-style"))return;let e=document.createElement("style");e.id="ext-batch-delete-style",e.textContent=`
    #ext-batch-delete-btn {
      display: inline-flex; align-items: center; gap: 8px;
      background: #ef4444; color: white; border: none; border-radius: 10px; cursor: pointer;
      font-family: 'Inter', system-ui, -apple-system, sans-serif; font-size: 13px; font-weight: 700;
      padding: 10px 22px; transition: all 0.15s ease;
      letter-spacing: -0.1px; box-shadow: 0 2px 8px rgba(239,68,68,0.25);
    }
    #ext-batch-delete-btn:hover {
      background: #dc2626; box-shadow: 0 4px 14px rgba(220,38,38,0.35);
      transform: translateY(-1px);
    }
    #ext-batch-delete-btn:active { transform: translateY(0); }
  `,document.head.appendChild(e),S()}function U(e){document.querySelectorAll("button:not(#ext-batch-delete-btn):not([disabled])").forEach(t=>{e?(t.disabled=!0,t.dataset.extWasEnabled="true"):t.dataset.extWasEnabled==="true"&&(t.disabled=!1,delete t.dataset.extWasEnabled)}),document.querySelectorAll("form input, form button, form a").forEach(t=>{e?(t.disabled=!0,t.dataset.extWasEnabled="true"):t.dataset.extWasEnabled==="true"&&(t.disabled=!1,delete t.dataset.extWasEnabled)})}function T(e){["ext-delete-close-btn","ext-delete-cancel-btn","ext-fetch-files-btn","ext-start-delete-btn"].forEach(t=>{let n=document.getElementById(t);n&&(n.disabled=e,n.style.opacity=e?"0.5":"1",n.style.cursor=e?"not-allowed":"pointer")}),document.querySelectorAll("#"+d.previewId+" input, #"+d.previewId+" button").forEach(t=>t.disabled=e),U(e)}function P(){let e=document.querySelector("#"+d.modalId+" .ext-modal-buttons");e&&(e.innerHTML='<button class="ext-btn ext-btn-purple" id="ext-reload-btn"><span style="display:inline-flex;align-items:center;gap:7px;">'+h.refresh+" Reload Halaman</span></button>",document.getElementById("ext-reload-btn")?.addEventListener("click",()=>{window.location.reload()}))}async function B(e){try{let t=new FormData;return t.append("id",e),(await fetch(d.deleteEndpoint,{method:"POST",body:t,credentials:"same-origin",signal:AbortSignal.timeout(3e4)})).ok}catch(t){return console.error("[Delete Dokumen] Error:",t),!1}}function O(){let e=document.getElementById(d.modalId);e||(e=document.createElement("div"),e.id=d.modalId,e.className="ext-batch-delete-modal",e.innerHTML=`
      <div class="ext-modal-content">
        <div class="ext-modal-header">
          <h3 style="margin: 0; font-size: 18px; color: #0f172a; font-weight: 700; letter-spacing: -0.3px;">Hapus Dokumen</h3>
          <button class="ext-modal-close" id="ext-delete-close-btn">${h.xClose}</button>
        </div>
        <div class="ext-warning-box">
          <strong style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-size: 13px; letter-spacing: 0.5px; text-transform: uppercase;">${z(h.warning,18)} PERHATIAN!</strong>
          <span style="font-size: 12px; opacity: 0.85; line-height: 1.5;">File yang dihapus <strong style="color: #7c2d12;">tidak dapat dikembalikan</strong>. Tindakan ini bersifat permanen.</span>
        </div>
        <div style="margin-bottom: 20px; display: flex; gap: 10px;">
          <button id="ext-fetch-files-btn" class="ext-btn ext-btn-purple">
            <span style="display: inline-flex; align-items: center; gap: 7px;">${h.search} Cari Dokumen Pasien</span>
          </button>
        </div>
        <div id="ext-delete-search-wrap" style="display: none; margin-bottom: 12px;">
          <input type="text" id="ext-delete-search-input" class="ext-search-input" placeholder="Cari dokumen...">
        </div>
        <div id="${d.previewId}" style="display: none; border: 1px solid #e5e7eb; border-radius: 6px; overflow: hidden;"></div>
        <div id="${d.progressId}" style="display: none; height: 4px; background: #374151; margin: 12px 0; border-radius: 2px; overflow: hidden;">
          <div class="progress-fill"></div>
        </div>
        <div id="${d.statusId}" style="margin: 8px 0; font-size: 11px; color: #9ca3af; font-weight: 500; letter-spacing: 0.3px;"></div>
        <div class="ext-modal-buttons">
          <button id="ext-delete-cancel-btn" class="ext-btn ext-btn-secondary">Batal</button>
          <button id="ext-start-delete-btn" class="ext-btn ext-btn-danger" disabled><span style="display:inline-flex;align-items:center;gap:6px;">${h.trash}</span> Hapus Terpilih</button>
        </div>
      </div>
    `,document.body.appendChild(e),setTimeout(()=>{document.getElementById("ext-delete-close-btn")?.addEventListener("click",C),document.getElementById("ext-delete-cancel-btn")?.addEventListener("click",C),document.getElementById("ext-fetch-files-btn")?.addEventListener("click",q),document.getElementById("ext-start-delete-btn")?.addEventListener("click",R),document.getElementById("ext-delete-search-input")?.addEventListener("input",k),e?.addEventListener("click",function(t){t.target===e&&C()})},50)),document.querySelectorAll(".ext-batch-delete-modal.show").forEach(t=>{t!==e&&t.classList.remove("show")}),e.classList.add("show")}function I(e){let t=document.getElementById("ext-start-delete-btn");t&&(t.disabled=e===0||b,t.textContent=`Hapus ${e} Dokumen`)}function C(){let e=document.getElementById(d.modalId);e&&e.classList.remove("show"),s=[],b=!1;let t=document.getElementById(d.previewId),n=document.getElementById(d.progressId),a=document.getElementById(d.statusId);t&&(t.style.display="none",t.innerHTML=""),n&&(n.style.display="none"),a&&(a.textContent="");let i=document.querySelector("#"+d.modalId+" .ext-modal-buttons");i&&(i.innerHTML='<button id="ext-delete-cancel-btn" class="ext-btn ext-btn-secondary">Batal</button><button id="ext-start-delete-btn" class="ext-btn ext-btn-danger" disabled><span style="display:inline-flex;align-items:center;gap:6px;">'+h.trash+"</span> Hapus Terpilih</button>",document.getElementById("ext-delete-cancel-btn")?.addEventListener("click",C),document.getElementById("ext-start-delete-btn")?.addEventListener("click",R)),T(!1)}async function q(){let e=new URLSearchParams(window.location.search).get("id_visit");if(console.log("[BatchDelete] Current URL:",window.location.href),console.log("[BatchDelete] id_visit found:",e),!e){console.error("[BatchDelete] id_visit not found in URL!"),v({title:"Parameter id_visit tidak ditemukan",message:"Pastikan buka dari halaman detail pasien.",variant:"warning",okLabel:"OK",hideCancel:!0});return}let t=document.getElementById("ext-fetch-files-btn");t&&(t.disabled=!0,t.textContent="Mencari...");try{let n=`${window.location.origin}${d.fetchListUrl}?id_visit=${e}&page=85&id_kunjungan=`,a=await fetch(n,{signal:AbortSignal.timeout(3e4)});if(!a.ok)throw new Error("Gagal memuat halaman dokumen pasien");let i=await a.text(),l=new DOMParser().parseFromString(i,"text/html").querySelectorAll("table.data-list.tabel tr");console.log("[BatchDelete] Total rows found:",l.length),s=[];for(let r=1;r<l.length;r++){let o=l[r],c=o.querySelector('button[onclick*="hapus"]'),u=null;if(console.log(`[BatchDelete] Row ${r}: deleteBtn found:`,!!c),c){let H=c.getAttribute("onclick")?.match(/hapus\(([^)]+)\)/);H&&(u=H[1].replace(/['"]/g,"").trim())}if(!u)continue;let m=o.querySelector("td:nth-child(2) a"),f=o.cells[1]?.textContent?.trim()||"unknown",x=o.cells[2]?.textContent?.trim()||"-",g=o.cells[3]?.textContent?.trim()||"-",E=o.cells[4]?.textContent?.trim()||"-",y=m?.getAttribute("href")||"",_=y.startsWith("http")?y:`${window.location.origin}${y}`;s.push({id_dokumen:u,filename:f,keterangan:x,tglFile:g,tglUpload:E,url:_,selected:!1,status:"pending"})}if(s.length===0){console.error("[BatchDelete] No documents found in queue!");let r=document.getElementById(d.statusId);r&&(r.textContent="Tidak ada dokumen ditemukan.");return}console.log("[BatchDelete] Queue populated with",s.length,"documents"),k();let p=document.getElementById(d.statusId);p&&(p.textContent=`${s.length} dokumen siap dihapus!`)}catch(n){console.error("[Batch Delete] Crawl error:",n);let a=document.getElementById(d.statusId);a&&(a.textContent="Error: "+n.message)}finally{t&&(t.disabled=!1,t.textContent="Cari Dokumen Pasien")}}async function N(e){try{if(b)return;let t=s[e];if(!t||!await v({title:"Hapus dokumen ini?",message:`${t.filename}
ID: ${t.id_dokumen}

Tindakan ini tidak bisa di-undo.`,variant:"danger",okLabel:"Ya, Hapus"}))return;let n=document.getElementById(d.statusId);t.status="deleting",k(),n&&(n.textContent=`Menghapus 1 dokumen: ${t.filename}...`),await B(t.id_dokumen)?(s.splice(e,1),n&&(n.textContent=`Sukses menghapus: ${t.filename}`)):(t.status="error",n&&(n.textContent=`Gagal menghapus: ${t.filename}`)),k()}catch(t){console.error("[BatchDelete] deleteSingleFromQueue error:",t)}}function k(){let e=document.getElementById(d.previewId),t=document.getElementById(d.statusId),n=document.getElementById("ext-delete-search-wrap"),a=document.getElementById("ext-delete-search-input"),i=(a?.value||"").toLowerCase();if(!s||s.length===0){e&&(e.style.display="none",e.innerHTML=""),n&&(n.style.display="none"),a&&(a.value=""),I(0),t&&(t.textContent="",t.style.color="#4b5563");return}n&&(n.style.display="block");let l=s.map((o,c)=>({item:o,idx:c})).filter(({item:o})=>!i||o.filename.toLowerCase().includes(i)||o.keterangan.toLowerCase().includes(i)||o.id_dokumen.toLowerCase().includes(i));if(e)e.style.display="block",e.style.borderRadius="6px";else return;let p=document.createElement("div");p.style.cssText="padding:10px 16px;background:#f8fafc;border-bottom:1px solid #f1f5f9;font-size:11px;font-weight:700;color:#1e293b;text-transform:uppercase;letter-spacing:0.5px;";let r=()=>{p.innerHTML='Dokumen Pasien <span style="color:#64748b;font-weight:400;">('+s.length+' dokumen, <span style="color:#dc2626;">'+s.filter(o=>o.selected).length+"</span> dipilih)</span>"};if(r(),e.innerHTML="",e.appendChild(p),l.length===0){let o=document.createElement("div");o.style.cssText="padding:32px;text-align:center;font-size:13px;color:#94a3b8;",o.textContent="Tidak ada dokumen yang cocok dengan pencarian.",e?.appendChild(o)}l.forEach(({item:o,idx:c})=>{let u=document.createElement("div");u.className="ext-delete-preview-item",o.selected&&u.classList.add("selected");let m=b;u.innerHTML=`
      <label class="ext-checkbox-label" style="flex:1;min-width:0;">
        <input type="checkbox" data-index="${c}" class="ext-checkbox" ${o.selected?"checked":""} ${m?"disabled":""}>
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
            <strong style="font-size: 13px; color: #000000; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${c+1}. ${o.filename}</strong>
            ${o.status!=="pending"?`<span class="ext-status-badge" data-status="${o.status==="success"?"success":o.status==="error"?"error":"deleting"}">${o.status==="success"?"Selesai":o.status==="error"?"Gagal":"Memproses"}</span>`:""}
          </div>
          <div style="font-size: 11px; color: #4b5563; margin-top: 6px; display: flex; gap: 8px; flex-wrap: wrap;">
            <span>ID: <strong style="color: #111827;">${o.id_dokumen}</strong></span>
            <span style="color: #d1d5db;">|</span>
            <span>${o.tglFile}</span>
            <span style="color: #d1d5db;">|</span>
            <span>${o.tglUpload}</span>
          </div>
          <div style="font-size: 11px; color: #6b7280; margin-top: 2px;">${o.keterangan}</div>
        </div>
      </label>
      <button data-index="${c}" class="ext-delete-preview-btn" ${m?"disabled":""}>${h.eye} Preview</button>
      <button data-index="${c}" class="ext-delete-single-btn" title="Hapus Dokumen Ini" ${m?"disabled":""}>${h.trash}</button>
    `;let f=u.querySelector('input[type="checkbox"]');!b&&f&&f.addEventListener("change",y=>{s[c].selected=y.target.checked,u.classList.toggle("selected",s[c].selected),r(),I(s.filter(_=>_.selected).length)});let x=u.querySelectorAll("button"),g=x.length>0?x[0]:null,E=x.length>1?x[1]:null;b||(g?.addEventListener("click",()=>{D(s[c].url,s[c].filename)}),E?.addEventListener("click",()=>{N(c)})),e?.appendChild(u)}),I(s.filter(o=>o.selected).length)}async function R(){try{if(b)return;let e=s.filter(r=>r.selected);if(e.length===0){v({title:"Tidak ada dokumen dipilih",message:"Centang dokumen yang ingin dihapus terlebih dahulu.",variant:"warning",okLabel:"OK",hideCancel:!0});return}if(!await v({title:`Hapus ${e.length} dokumen?`,message:"TIDAK BISA DIUNDO!",variant:"danger",okLabel:"Ya, Hapus"}))return;b=!0,T(!0);let t=0,n=0,a=document.getElementById(d.progressId),i=a?.querySelector(".progress-fill"),l=document.getElementById(d.statusId);a&&(a.style.display="block"),i&&(i.style.width="0%"),l&&(l.style.color="#fcd34d");for(let r=0;r<e.length;r++){let o=e[r];if(o.status="deleting",await B(o.id_dokumen)?(o.status="success",t++):(o.status="error",n++),k(),i&&l){let c=(r+1)/e.length*100;i.style.width=c+"%",l.textContent=`Diproses ${r+1}/${e.length} - Sukses: ${t}, Gagal: ${n}`}await new Promise(c=>setTimeout(c,d.delayBetweenDelete))}let p=`Selesai! Sukses: ${t}, Gagal: ${n}`;l&&(l.textContent=p,l.style.color=n>0?"#000000":"#6ee7b7"),n>0&&console.log("Failed deletes:",s.filter(r=>r.status==="error")),v({title:"Proses selesai",message:p,variant:n>0?"warning":"success",okLabel:"OK",hideCancel:!0}),P(),b=!1}catch(e){console.error("[BatchDelete] startBatchDelete error:",e),b=!1,T(!1)}}function G(){return!!new URLSearchParams(window.location.search).get("id_visit")}async function W(){let e=new URLSearchParams(window.location.search).get("id_visit");if(!e){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_DELETE_ERROR",data:{error:"Parameter id_visit tidak ditemukan di URL."}}).catch(console.error);return}try{let t=`${window.location.origin}${d.fetchListUrl}?id_visit=${e}&page=85&id_kunjungan=`,n=await fetch(t,{signal:AbortSignal.timeout(3e4)});if(!n.ok)throw new Error("Gagal memuat halaman dokumen pasien");let a=await n.text(),i=new DOMParser().parseFromString(a,"text/html").querySelectorAll("table.data-list.tabel tr");s=[];for(let l=1;l<i.length;l++){let p=i[l],r=p.querySelector('button[onclick*="hapus"]'),o=null;if(r){let y=r.getAttribute("onclick")?.match(/hapus\(([^)]+)\)/);y&&(o=y[1].replace(/['"]/g,"").trim())}if(!o)continue;let c=p.querySelector("td:nth-child(2) a"),u=p.cells[1]?.textContent?.trim()||"unknown",m=p.cells[2]?.textContent?.trim()||"-",f=p.cells[3]?.textContent?.trim()||"-",x=p.cells[4]?.textContent?.trim()||"-",g=c?.getAttribute("href")||"",E=g.startsWith("http")?g:`${window.location.origin}${g}`;s.push({id_dokumen:o,filename:u,keterangan:m,tglFile:f,tglUpload:x,url:E,selected:!1,status:"pending"})}chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_DELETE_CRAWL_RESULT",data:{items:s}}).catch(console.error)}catch(t){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_DELETE_ERROR",data:{error:t.message}}).catch(console.error)}}async function F(e,t){if(!s[e])return;let n=await B(t);chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_DELETE_SINGLE_RESULT",data:{index:e,success:n,error:n?void 0:"Gagal memproses penghapusan di server."}}).catch(console.error)}async function K(){try{let e=s.filter(a=>a.selected);if(e.length===0)return;let t=0,n=0;for(let a=0;a<e.length;a++){let i=e[a];i.status="deleting",chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_DELETE_PROGRESS",data:{percent:a/e.length*100,status:`Menghapus: ${i.filename} (${a+1}/${e.length})...`,items:s,finished:!1}}).catch(console.error),await B(i.id_dokumen)?(i.status="success",t++):(i.status="error",n++),V(a+1,e.length,t,n,s),await new Promise(l=>setTimeout(l,d.delayBetweenDelete))}}catch(e){console.error("[BatchDelete] startBatchDeleteToSidepanel error:",e),chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_DELETE_ERROR",data:{error:e.message}}).catch(console.error)}}function V(e,t,n,a,i){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_DELETE_PROGRESS",data:{percent:e/t*100,status:`Diproses ${e}/${t} - Sukses: ${n}, Gagal: ${a}`,items:i,finished:e>=t}}).catch(console.error)}function Y(){if(G()&&L.currentConfig?.features?.batchDelete?.enabled&&L.ExtensionCore.isFeatureAllowed("batchDelete"))try{if(console.log("[BatchDelete] Init starting..."),j(),chrome.runtime.sendMessage({type:"PAGE_CONTEXT",feature:"mKlaimDetail",data:{idVisit:new URLSearchParams(window.location.search).get("id_visit")}}).catch(console.error),window.__extBatchDeleteRegistered)return;window.__extBatchDeleteRegistered=!0,chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type==="TAB_ACTION"){let{action:a,payload:i}=e;a==="BATCH_DELETE_CRAWL"?W():a==="BATCH_DELETE_UPDATE_ITEMS"?s=i.items:a==="BATCH_DELETE_PREVIEW"?D(i.url,i.filename).catch(()=>{window.open(i.url,"_blank")}):a==="BATCH_DELETE_SINGLE"?F(i.index,i.id_dokumen):a==="BATCH_DELETE_START"&&K(),n({success:!0})}else e.type==="BATCH_DELETE_ACTION"&&n({success:!0});return!0}),console.log("[BatchDelete] Init complete")}catch(e){console.error("[BatchDelete] Init error:",e)}}window.batchDeleteShowModal=O,typeof L.featureModules<"u"&&(L.featureModules.batchDelete={id:"batchDelete",name:"Batch Delete Dokumen",description:"Hapus multiple dokumen sekaligus",match:{regex:/^\/v2\/m-klaim\/detail-v2-refaktor\/?$/},run:Y})})();
