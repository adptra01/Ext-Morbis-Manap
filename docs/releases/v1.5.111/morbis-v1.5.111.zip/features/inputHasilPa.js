"use strict";var __morbis_feature=(()=>{var A='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',T=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${A};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,g=null;function z(){return g||(g=new CSSStyleSheet,g.replaceSync(T)),g}var E=!1;function P(){if(E||document.getElementById("ext-pjs-font"))return;E=!0;let o=document.createElement("link");o.id="ext-pjs-font",o.rel="stylesheet",o.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(o)}function j(o,b="open"){let m=o.attachShadow({mode:b});return m.adoptedStyleSheets=[z()],P(),m}var $=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,H=class extends HTMLElement{constructor(){super();let o=j(this);o.innerHTML=`
      <style>${$}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=o.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",o=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){o.stopPropagation(),o.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(o){(o==="disabled"||o==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}};customElements.get("ext-btn")||customElements.define("ext-btn",H),(function(){let o=t=>document.querySelector(t),b=t=>o(t)?.value?.trim()||"",m=null;function q(){return{idLab:new URLSearchParams(window.location.search).get("id_lab")||b('input[name="id_lab"]'),idVisit:b('input[name="id_visit"]'),idHasilLab:b('input[name="hasil[1][id]"]')}}async function F(t,n){try{let e=((await(await fetch(`/admisi/pelaksanaan_pelayanan/laboratorium-data?id_visit=${n}`,{credentials:"same-origin"})).text()).match(/<tr[^>]*>[\s\S]*?<\/tr>/g)||[]).find(i=>i.includes(`nolab="${t}"`));if(!e)return null;let r=e.match(/cetakFormPermintaanLab\(\s*(\d+)/)?.[1]||null,d=e.match(/edit_tanggal\(\s*\d+\s*,\s*\d+\s*,\s*"([^"]+)"/)?.[1]||null;return r?{id:r,tgl:d}:null}catch{return null}}function h(t){window.open(t,"_blank")}let y=["dok_luar","nama_rs"],x={},v=null;function _(t){return t.toLowerCase().split(" ").map(n=>n&&n.charAt(0).toUpperCase()+n.slice(1)).join(" ")}function L(t){return document.querySelector(`[name="${t}"]`)}function C(t,n){let e=x[t];return e===void 0?(n&&(x[t]=n),!1):n===e?!1:n.toLowerCase()!==e.toLowerCase()?(x[t]=n,!1):n===_(e)?!0:(x[t]=n,!1)}function w(){try{for(let t of y){let n=L(t);n&&C(t,(n.value??"").trim())}}catch{}}function K(){try{for(let t of y){let n=L(t);n&&C(t,(n.value??"").trim())&&(n.value=x[t],window.console.info("[paKeepCase] "+t+" dikembalikan ke ejaan asli"))}}catch{}}function R(){let t=window.XMLHttpRequest.prototype;if(t.__extKeepPatched)return;t.__extKeepPatched=!0;let n=t.open,e=t.send;t.open=function(...r){try{let d=r[1];this.__extUrl=typeof d=="string"?d:String(d)}catch{}return n.apply(this,r)},t.send=function(...r){try{let d=this,i=r[0],l=d.__extUrl;if(Object.keys(x).length&&typeof l=="string"&&l.includes("pemeriksaan-pa")&&typeof i=="string"&&i.includes("dok_luar=")){let s=new URLSearchParams(i),u=!1;for(let a of y){let c=x[a],p=s.get(a);c&&p!==null&&p!==c&&p===_(c)&&(s.set(a,c),u=!0)}if(u)return window.console.info("[paKeepCase] payload dok_luar/nama_rs dikembalikan ke ejaan asli"),e.call(this,s.toString())}else if(Object.keys(x).length&&typeof l=="string"&&l.includes("pemeriksaan-pa")&&typeof FormData<"u"&&i instanceof FormData&&(i.has("dok_luar")||i.has("nama_rs")))for(let s of y){let u=x[s],a=i.get(s);u&&typeof a=="string"&&a!==u&&a===_(u)&&(window.console.info("[paKeepCase] payload FormData "+s+" dikembalikan"),i.set(s,u))}}catch{}return e.apply(this,r)}}function U(){let t=window;t.__paKeepCase||(t.__paKeepCase=!0,w(),document.addEventListener("input",n=>{let e=n.target;e&&typeof e.matches=="function"&&e.matches("input, textarea, select")&&w()},!0),document.addEventListener("focusout",()=>w(),!0),document.addEventListener("submit",()=>w(),!0),R(),v=window.setInterval(K,300),window.console.info("[paKeepCase] aktif di input-hasil-pa"))}function M(t,n){let e=document.createElement("div");e.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:999999;display:flex;align-items:center;justify-content:center;";let r=document.createElement("div");r.style.cssText="background:#fff;border-radius:8px;padding:16px 18px;min-width:340px;box-shadow:0 8px 30px rgba(0,0,0,.25);font-family:Arial,sans-serif;";let d=document.createElement("div");d.textContent="Edit Tanggal Pengajuan",d.style.cssText="font-weight:700;font-size:14px;margin-bottom:10px;color:#1e293b;";let i=document.createElement("input");i.type="date",i.style.cssText="width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:6px;font-size:13px;padding:10px;";let l=m?.match(/^(\d{2})\/(\d{2})\/(\d{4})/);l&&(i.value=`${l[3]}-${l[2]}-${l[1]}`);let s=document.createElement("div");s.textContent="Server menerima dd/mm/yyyy hh:mm:ss \u2014 waktu diset otomatis ke 00:00:00.",s.style.cssText="font-size:11px;color:#64748b;margin:4px 0 12px;";let u=document.createElement("div");u.style.cssText="display:flex;justify-content:flex-end;";let a=document.createElement("button");a.type="button",a.textContent="Edit Tanggal",a.style.cssText="margin:18px;padding:15px;border:none;border-radius:6px;font-size:12px;font-weight:600;color:#fff;background:#2563eb;cursor:pointer;";let c=document.createElement("button");c.type="button",c.textContent="Batal",c.style.cssText="margin:18px;padding:15px;border:none;border-radius:6px;font-size:12px;font-weight:600;color:#fff;background:#dc2626;cursor:pointer;",a.addEventListener("click",async()=>{let p=i.value.trim();if(!p){alert("Isi tanggal pengajuan baru dulu.");return}let[f,B,O]=p.split("-"),X=`${O}/${B}/${f} 00:00:00`;a.disabled=!0,a.textContent="Menyimpan\u2026";let k=!1;try{k=(await(await fetch("/laboratorium/control/edit_tanggal",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},body:new URLSearchParams({lab:t,id_visit:n,date:X,action:"edit"}).toString()})).json()).status==1}catch{k=!1}e.remove(),alert(k?"Edit Tanggal Pengajuan berhasil diubah.":"Gagal menyimpan tanggal baru."),k&&window.location.reload()}),c.addEventListener("click",()=>e.remove()),e.addEventListener("click",p=>{p.target===e&&e.remove()}),u.append(a,c),r.append(d,i,s,u),e.appendChild(r),document.body.appendChild(e),i.focus()}function D(){let t=Array.from(document.querySelectorAll("fieldset")).find(a=>a.textContent?.includes("Data Pasien"));if(!t)return;let n=document.querySelector("[data-ext-lab-actions]");n&&n.remove();let{idLab:e,idVisit:r,idHasilLab:d}=q();if(!e||!r||!d){console.warn("[inputHasilPa] Missing ids",{idLab:e,idVisit:r,idHasilLab:d});return}let i=document.createElement("div");i.setAttribute("data-ext-lab-actions","true"),i.style.cssText="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0;";let l=(a,c,p)=>{let f=document.createElement("ext-btn");return f.setAttribute("variant",c),f.setAttribute("size","sm"),f.textContent=a,f.addEventListener("click",p),f},s=d;F(e,r).then(a=>{a?(s=a.id,m=a.tgl,console.log("[inputHasilPa] permintaan data",{idLab:e,idVisit:r,id:a.id,tgl:a.tgl})):console.warn("[inputHasilPa] Baris lab tidak ditemukan di daftar, pakai hasil[1][id].",{idLab:e,idVisit:r})}),i.append(l("Edit Tanggal Pengajuan","primary",()=>M(e,r)),l("Cetak","info",()=>h(`/laboratorium/print/hasil-lab?id=${e}&nolab=${e}`)),l("Cetak Form Permintaan Lab","secondary",()=>h(`/admisi/formulir-permintaan-labor/cetak?id=${s}&id_visit=${r}&jenis=cetak`)),l("Edit Form Permintaan Lab","secondary",()=>h(`/admisi/formulir-permintaan-labor/form?id=${s}&id_visit=undefined&jenis=edit`)),l("Halaman Asli Pengajuan Lab","ghost",()=>h(`/admisi/pelaksanaan_pelayanan/laboratorium-data?id_visit=${r}`)));let u=Array.from(document.querySelectorAll("fieldset")).find(a=>a.textContent?.includes("Tanggal Hasil"));if(u)u.after(i);else{let a=document.querySelector("form");a?a.appendChild(i):t.after(i)}}function S(){document.documentElement.getAttribute("data-ext-lab-history")&&(U(),D())}let I=performance.now();(function t(){document.documentElement.getAttribute("data-ext-lab-history")?S():performance.now()-I<5e3&&setTimeout(t,200)})();let V=history.pushState;history.pushState=function(...t){V.apply(this,t),setTimeout(S,100)},window.addEventListener("popstate",()=>setTimeout(S,100)),window.addEventListener("pagehide",()=>{v!==null&&(clearInterval(v),v=null)})})()})();
