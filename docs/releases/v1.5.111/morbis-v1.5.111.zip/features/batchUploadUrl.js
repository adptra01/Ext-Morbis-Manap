"use strict";var __morbis_feature=(()=>{function ne(){return window}var K="ext-batch-shared-style";function W(){if(document.getElementById(K))return;let e=document.createElement("style");e.id=K,e.textContent=`
    .ext-modal-content {
      background: #ffffff; border-radius: 16px; padding: 28px 32px;
      max-width: 860px; width: 95%; max-height: 85vh; overflow-y: auto;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.04), 0 20px 40px -15px rgba(0,0,0,0.08);
      margin: auto; font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .ext-modal-content * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }

    .ext-modal-header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 20px; padding-bottom: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .ext-modal-header h3 {
      margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;
      letter-spacing: -0.3px;
    }

    .ext-modal-close {
      width: 36px; height: 36px; font-size: 18px; color: #94a3b8;
      border-radius: 10px; background: #f8fafc; border: 1px solid #e2e8f0;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      font-weight: 500; transition: all 0.15s ease;
    }
    .ext-modal-close:hover { background: #fef2f2; color: #dc2626; border-color: #fecaca; transform: scale(1.05); }
    .ext-modal-close:active { transform: scale(0.95); }

    /* Base styles for batch modals (upload + delete). Same class is used by
       both features so opening one closes the other; CSS must live here in
       shared utils or a role-gated feature (delete off, upload on) renders
       an unstyled, non-fixed modal. */
    .ext-batch-delete-modal {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(15,23,42,0.45); display: none; z-index: 10000;
      align-items: center; justify-content: center;
      backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
    }
    .ext-batch-delete-modal.show { display: flex; }

    .ext-modal-buttons {
      margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;
    }

    .ext-btn {
      padding: 10px 22px; border: none; border-radius: 10px; cursor: pointer;
      font-size: 13px; font-weight: 600; transition: all 0.15s ease;
      letter-spacing: -0.1px; display: inline-flex; align-items: center; gap: 7px;
    }
    .ext-btn:active { transform: scale(0.97); }

    .ext-btn-primary { background: #2563eb; color: white; }
    .ext-btn-primary:hover { background: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .ext-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
    .ext-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
    .ext-btn-secondary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    .ext-btn-danger { background: #ef4444; color: white; }
    .ext-btn-danger:hover { background: #dc2626; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .ext-btn-danger:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }
    .ext-btn-danger.disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

    .ext-btn-purple {
      background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;
    }
    .ext-btn-purple:hover { background: #7c3aed; color: white; border-color: #7c3aed; box-shadow: 0 4px 12px rgba(124,58,237,0.2); }
    .ext-btn-purple:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; transform: none; }

    .ext-warning-box {
      background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px;
      padding: 16px 18px; margin-bottom: 20px; color: #9a3412;
      font-size: 13px; line-height: 1.6;
    }
    .ext-warning-box strong { color: #7c2d12; }

    .ext-search-input {
      width: 100%; padding: 10px 14px; font-size: 13px;
      border: 1px solid #e2e8f0; border-radius: 10px; outline: none;
      color: #1e293b; background: #f8fafc; box-sizing: border-box;
      pointer-events: auto;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ext-search-input:focus { border-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,0.1); background: #fff; }
    .ext-search-input::placeholder { color: #94a3b8; }

    .ext-status-badge {
      font-size: 10px; padding: 3px 10px; background: #f1f5f9;
      border-radius: 20px; color: #475569; font-weight: 600;
      white-space: nowrap; border: 1px solid #e2e8f0;
      letter-spacing: 0.2px;
    }
    .ext-status-badge[data-status="success"] { background: #ecfdf5; color: #065f46; border-color: #a7f3d0; }
    .ext-status-badge[data-status="error"] { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .ext-status-badge[data-status="deleting"] { background: #fffbeb; color: #92400e; border-color: #fde68a; }

    .ext-modal-content input,
    .ext-modal-content textarea,
    .ext-modal-content select,
    .ext-modal-content button {
      pointer-events: auto !important;
    }

    .ext-checkbox {
      margin-top: 4px; cursor: pointer; accent-color: #2563eb;
      width: 20px; height: 20px; flex-shrink: 0; border-radius: 4px;
    }

    .ext-checkbox-label {
      display: flex; gap: 12px; align-items: flex-start;
      cursor: pointer; flex: 1; min-width: 0;
    }

    .ext-delete-preview-item {
      padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 12px;
      display: flex; gap: 12px; align-items: flex-start;
      background: #fff; transition: background-color 0.15s ease;
    }
    .ext-delete-preview-item:hover { background: #f8fafc; }
    .ext-delete-preview-item.selected {
      background: #fef2f2; border-left: 3px solid #ef4444;
    }

    .ext-delete-preview-btn {
      padding: 7px 14px; background: #f8fafc; color: #475569;
      border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px;
      font-weight: 600; cursor: pointer; white-space: nowrap;
      display: inline-flex; align-items: center; gap: 5px;
      transition: all 0.15s ease;
    }
    .ext-delete-preview-btn:hover { background: #475569; color: white; border-color: #475569; }
    .ext-delete-preview-btn:active { transform: scale(0.97); }
    .ext-delete-preview-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .ext-delete-single-btn {
      width: 32px; height: 32px; color: #dc2626; border-radius: 8px;
      background: #fef2f2; border: 1px solid #fecaca;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.15s ease; flex-shrink: 0;
    }
    .ext-delete-single-btn:hover { background: #dc2626; color: white; border-color: #dc2626; }
    .ext-delete-single-btn:active { transform: scale(0.93); }

    .progress-fill {
      height: 100%; background: #2563eb; width: 0%;
      border-radius: 2px; transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ext-preview-item {
      padding: 5px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px;
    }
    .ext-preview-item.success { color: #059669; }
    .ext-preview-item.error { color: #dc2626; }
    .ext-preview-item.pending { color: #64748b; }
  `,document.head.appendChild(e)}var y={search:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',trash:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>',xClose:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>',warning:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 00-3.48 0l-8 14A2 2 0 004 21h16a2 2 0 001.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',eye:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',refresh:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 11-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>',upload:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',file:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',check:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',arrowRight:'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>'};async function V(e,t){try{let n=await fetch(e,{method:"GET",mode:"cors",credentials:"omit"});if(!n.ok)throw new Error(`HTTP ${n.status}`);let a=await n.blob(),r=URL.createObjectURL(a);Y(r,t,e,()=>URL.revokeObjectURL(r))}catch{Y(e,t,e)}}var A=null;function Y(e,t,n,a){A&&A();let r=t.toLowerCase().split(".").pop()||"",o=r==="pdf",l=["jpg","jpeg","png","gif","webp"].includes(r),s=document.createElement("div");s.id="ext-inline-preview-modal",s.style.cssText="position:fixed !important;top:0 !important;left:0 !important;width:100vw !important;height:100vh !important;background:rgba(15,23,42,0.88) !important;z-index:10001 !important;display:flex !important;align-items:center !important;justify-content:center !important;flex-direction:column !important;padding:20px !important;box-sizing:border-box !important;backdrop-filter:blur(8px) !important;-webkit-backdrop-filter:blur(8px) !important;";let c='<div class="ext-inline-preview-loading" style="display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;color:#fff;"><div class="ext-inline-preview-spinner"></div><div style="font-size:14px;">Loading preview...</div></div>';o?c=`<iframe id="ext-inline-preview-iframe" src="${e}" style="width:100%;height:100%;border:none;display:block;border-radius:12px;"></iframe>`:l?c=`<img id="ext-inline-preview-img" src="${e}" alt="Image Preview" style="width:100%;height:100%;border:none;display:block;object-fit:contain;border-radius:12px;">`:c=`<div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:15px;color:#64748b;background:#f8fafc;flex-direction:column;gap:16px;border-radius:12px;">${y.file}<div>Preview not available for this format</div></div>`;let i=t.replace(/"/g,"&quot;").replace(/</g,"&lt;");s.innerHTML=`
    <div style="position:absolute;top:20px;right:20px;display:flex;gap:10px;align-items:center;background:rgba(15,23,42,0.8);padding:10px 16px;border-radius:12px;backdrop-filter:blur(12px);z-index:10002;border:1px solid rgba(255,255,255,0.1);">
      <span style="color:#e2e8f0;font-size:13px;max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500;">${i}</span>
      <button id="ext-preview-newtab" style="padding:7px 14px;background:#3b82f6;color:white;border:none;border-radius:8px;cursor:pointer;font-size:12px;font-weight:600;transition:background 0.15s ease;display:inline-flex;align-items:center;gap:6px;">${y.arrowRight} Open Tab</button>
      <button id="ext-preview-close" style="padding:7px 12px;background:rgba(255,255,255,0.1);color:#e2e8f0;border:1px solid rgba(255,255,255,0.15);border-radius:8px;cursor:pointer;font-size:16px;font-weight:500;transition:all 0.15s ease;line-height:1;">${y.xClose}</button>
    </div>
    <div style="width:clamp(400px,90vw,1200px);height:clamp(300px,90vh,800px);background:white;border-radius:16px;box-shadow:0 25px 60px rgba(0,0,0,0.4);overflow:hidden;position:relative;">${c}</div>
  `,document.body.appendChild(s);let d=!1,p,f=h=>{h.key==="Escape"&&g()},g=()=>{d||(d=!0,A===g&&(A=null),a&&a(),document.removeEventListener("keydown",f),p!==void 0&&clearInterval(p),s.remove())};A=g,document.getElementById("ext-preview-close")?.addEventListener("click",g),document.getElementById("ext-preview-newtab")?.addEventListener("click",()=>{window.open(n||e,"_blank"),g()}),s.addEventListener("click",h=>{h.target===s&&g()}),document.addEventListener("keydown",f),(o||l)&&(p=window.setInterval(()=>{if(o?document.getElementById("ext-inline-preview-iframe")?.getAttribute("src"):document.getElementById("ext-inline-preview-img")?.complete){let h=s.querySelector(".ext-inline-preview-loading");h&&h.remove(),clearInterval(p)}},500))}function $(e){return new Promise(t=>{W();let n=e.variant==="danger"?"ext-btn-danger":"ext-btn-primary",a=document.createElement("div");a.style.cssText="position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.55);backdrop-filter:blur(2px);",a.innerHTML=`
      <div class="ext-modal-content" style="max-width:480px;">
        <div class="ext-modal-header">
          <h3></h3>
          <button class="ext-modal-close">&times;</button>
        </div>
        <div class="ext-confirm-body" style="font-size:14px;color:#334155;line-height:1.6;"></div>
        <div class="ext-modal-buttons">
          ${e.hideCancel?"":`<button class="ext-btn ext-btn-secondary" data-ext-cancel>${e.cancelLabel??"Batal"}</button>`}
          <button class="ext-btn ${n}" data-ext-ok>${e.okLabel??"Lanjut"}</button>
        </div>
      </div>`,a.querySelector("h3").textContent=e.title;let r=a.querySelector(".ext-confirm-body");e.message&&e.message.split(`
`).forEach((c,i)=>{i>0&&r.appendChild(document.createElement("br")),r.appendChild(document.createTextNode(c))});let o=c=>{a.remove(),document.removeEventListener("keydown",l),t(c)},l=c=>{c.key==="Escape"&&o(!1)};a.querySelector(".ext-modal-close").addEventListener("click",()=>o(!1)),a.addEventListener("click",c=>{c.target===a&&o(!1)}),a.querySelector("[data-ext-ok]").addEventListener("click",()=>o(!0));let s=a.querySelector("[data-ext-cancel]");s&&s.addEventListener("click",()=>o(!1)),document.addEventListener("keydown",l),document.body.appendChild(a)})}function re(e){let t=new Date,n=t.getTime(),a=Math.random().toString(36).substring(2,8);return`upload_${t.toISOString().slice(0,10).replace(/-/g,"")}_${n}_${a}${e}`}function ie(e,t){return re(".pdf")}function X(e,t,n){let a=Math.max(1,Math.round(t)),r=Math.max(1,Math.round(n)),o=new TextEncoder,l=oe(e),s=l?.components??3,c=s===1?"/DeviceGray":s===4?"/DeviceCMYK":"/DeviceRGB",i=l&&l.width>0?l.width:a,d=l&&l.height>0?l.height:r,p=le(e),f=se(p,a,r),g=`1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
`,h=`2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
`,m=`3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${a} ${r}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>
endobj
`,T=`4 0 obj
<< /Type /XObject /Subtype /Image /Width ${i} /Height ${d} /ColorSpace ${c} /BitsPerComponent 8 /Filter /DCTDecode /Length ${e.length} >>
stream
`,L=`
endstream
endobj
`,v=`q
${f} cm
/Im0 Do
Q
`,I=`5 0 obj
<< /Length ${o.encode(v).length} >>
stream
${v}endstream
endobj
`,S=`%PDF-1.4
`,B=[],E=0,R=[],C=z=>{B.push(z),E+=z.length};C(o.encode(S)),R[0]=E,C(o.encode(g)),R[1]=E,C(o.encode(h)),R[2]=E,C(o.encode(m)),R[3]=E,C(o.encode(T)),C(e),C(o.encode(L)),R[4]=E,C(o.encode(I));let Ce=E,G=`xref
0 6
0000000000 65535 f 
`;for(let z of R)G+=`${String(z).padStart(10,"0")} 00000 n 
`;return G+=`trailer
<< /Size 6 /Root 1 0 R >>
startxref
${Ce}
%%EOF
`,C(o.encode(G)),new Blob(B,{type:"application/pdf"})}function oe(e){let t=e.length,n=2;for(;n+4<t;){if(e[n]!==255){n++;continue}let a=n+1;for(;a<t&&e[a]===255;)a++;if(a>=t)break;let r=e[a],o=a+1;if(r===216||r===217||r===1)break;if(r>=208&&r<=215){n=o;continue}if(o+2>t)break;let l=e[o]<<8|e[o+1];if(l<2)break;if(r>=192&&r<=195||r>=197&&r<=199||r>=201&&r<=203||r>=205&&r<=207){let s=o+2;if(s+6>t)break;let c=e[s+1]<<8|e[s+2],i=e[s+3]<<8|e[s+4],d=e[s+5];return d>=1&&d<=4&&c>0&&i>0?{width:i,height:c,components:d}:null}n=o+l}return null}function le(e){let t=e.length,n=2;for(;n+4<t;){if(e[n]!==255){n++;continue}let a=n+1;for(;a<t&&e[a]===255;)a++;if(a>=t)break;let r=e[a],o=a+1;if(r===216||r===217||r===1)break;if(r>=208&&r<=215){n=o;continue}if(o+2>t)break;let l=e[o]<<8|e[o+1];if(l<2)break;if(r===225){let s=o+2,c=l-2;if(c>=12&&e[s]===69&&e[s+1]===120&&e[s+2]===105&&e[s+3]===102&&e[s+4]===0&&e[s+5]===0){let i=s+6,d=c-6;if(d>=8){let p=e[i]===73&&e[i+1]===73,f=e[i]===77&&e[i+1]===77;if(p||f){let g=m=>p?e[i+m]|e[i+m+1]<<8:e[i+m]<<8|e[i+m+1],h=m=>p?e[i+m]|e[i+m+1]<<8|e[i+m+2]<<16|e[i+m+3]<<24:e[i+m]<<24|e[i+m+1]<<16|e[i+m+2]<<8|e[i+m+3];if(g(2)===42){let m=h(4);if(m+2<=d){let T=g(m);for(let L=0;L<T;L++){let v=m+2+L*12;if(v+12>d)break;if(g(v)!==274)continue;let I=g(v+2),S=p?e[i+v+8]|e[i+v+9]<<8:e[i+v+8]<<8|e[i+v+9];return I===3&&S>=1&&S<=8?S:1}return 1}}}}}}n=o+l}return 1}function se(e,t,n){switch(e){case 2:return`${-t} 0 0 ${n} ${t} 0`;case 3:return`${-t} 0 0 ${-n} ${t} ${n}`;case 4:return`${t} 0 0 ${-n} 0 ${n}`;case 5:return`0 ${-n} ${-t} 0 ${t} ${n}`;case 6:return`0 ${-n} ${t} 0 0 ${n}`;case 7:return`0 ${n} ${t} 0 0 0`;case 8:return`0 ${n} ${-t} 0 ${t} 0`;default:return`${t} 0 0 ${n} 0 0`}}function de(e){return e.length>=5&&e[0]===37&&e[1]===80&&e[2]===68&&e[3]===70&&e[4]===45?"pdf":e.length>=3&&e[0]===255&&e[1]===216&&e[2]===255?"jpeg":e.length>=8&&e[0]===137&&e[1]===80&&e[2]===78&&e[3]===71?"png":e.length>=6&&e[0]===71&&e[1]===73&&e[2]===70&&e[3]===56?"gif":e.length>=12&&e[0]===82&&e[1]===73&&e[2]===70&&e[3]===70&&e[8]===87&&e[9]===69&&e[10]===66&&e[11]===80?"webp":"unknown"}var P=ne(),x={targetUrl:"/v2/m-klaim/detail-v2-refaktor",uploadEndpoint:"/v2/m-klaim/uploda-dokumen/control?sub=simpan",maxConcurrent:3,maxBatchSize:50,supportedExtensions:[".pdf",".jpg",".jpeg",".png",".gif"],modalId:"ext-batch-url-modal",textareaId:"ext-url-input",previewId:"ext-preview-list",progressId:"ext-progress-bar",statusId:"ext-status-text"};function ce(e){let t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${a}`}function pe(){return ce(new Date)}function H(){let e=a=>{if(!a)return null;let r=String(a).trim(),o=r.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(o)return`${o[1]}-${o[2].padStart(2,"0")}-${o[3].padStart(2,"0")}`;let l=r.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);if(l)return`${l[3]}-${l[2].padStart(2,"0")}-${l[1].padStart(2,"0")}`;let s=r.match(/^(\d{1,2})-(\d{1,2})-(\d{4})/);return s?`${s[3]}-${s[2].padStart(2,"0")}-${s[1].padStart(2,"0")}`:null},t=["#tgl","#tanggal","#tanggal_masuk",'input[name="tanggal"]'];for(let a of t){let r=document.querySelector(a),o=e(r?.value);if(o)return o}let n=new URLSearchParams(window.location.search);for(let a of["tanggalAwal","tanggalAkhir","tanggal","tgl"]){let r=e(n.get(a));if(r)return r}return console.warn("[Batch Upload] Tanggal klaim tidak ditemukan (input #tgl & URL), pakai tanggal hari ini"),pe()}function k(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function ue(e,t={},n=3e4){let a=new AbortController,r=setTimeout(()=>a.abort(),n),o=t.signal,l=()=>a.abort();return o&&(o.aborted?(clearTimeout(r),a.abort()):o.addEventListener("abort",l,{once:!0})),fetch(e,{...t,signal:a.signal}).finally(()=>{clearTimeout(r),o&&o.removeEventListener("abort",l)})}async function F(e,t={},n=2){let a=t.signal,r=null;for(let o=0;o<=n;o++){try{let l=a?{...t,signal:a}:t,s=await ue(e,l);if(s.ok||s.status>=400&&s.status<500&&s.status!==429)return s;r=new Error(`HTTP ${s.status}: ${s.statusText}`)}catch(l){if(r=l,l instanceof DOMException&&l.name==="AbortError"){if(a?.aborted)throw new Error("Batch cancelled");r=new Error("Request timeout")}}o<n&&!(r instanceof Error&&r.message==="Batch cancelled")&&(await new Promise(l=>setTimeout(l,1e3*(o+1))),console.log(`[Batch Upload] Retry ${o+1}/${n} for ${e}`))}throw r||new Error("Fetch failed after retries")}var u=[],w=!1,_=null;function O(){return _||(_=new AbortController),_.signal}function q(){_&&_.abort(),w=!1}function Z(e){return!e||typeof e!="string"?[]:e.split(`
`).map(t=>t.trim()).filter(t=>t.length>0).map(t=>t.replace(/ /g,"%20")).filter(t=>{try{new URL(t);let n=t.split(/[?#]/)[0].toLowerCase();return x.supportedExtensions.some(a=>n.endsWith(a))}catch{return!1}})}function j(e){try{let t=new URL(e),n=decodeURIComponent(t.pathname).split("/").pop()||"unknown",a=n.replace(/\.[^/.]+$/,""),r=a.split(/[-_\s]+/),o="",l=H(),s=r.filter(i=>{let d=/^\d+$/.test(i),p=i.length;return d&&p>=6&&p<=12&&p!==10&&p!==13});if(s.length>0)o=s[0];else{let i=t.searchParams.get("norm")||t.searchParams.get("no_rm");i&&/^\d{6,12}$/.test(i)&&(o=i)}let c=r.filter(i=>!/^\d{10}$/.test(i)&&i!==o).join(" ").trim()||a.replace(/[-_]+/g," ");return{filename:n,norm:o,tanggal:l,jenis_dokumen:"Lain-lain",keterangan:c,url:e,status:"pending"}}catch{return{filename:"error",norm:"",tanggal:H(),jenis_dokumen:"Lain-lain",keterangan:"URL tidak valid",url:e,status:"error",error:"Invalid URL format"}}}function ge(){let e=document.getElementById(x.modalId);e||(e=document.createElement("div"),e.id=x.modalId,e.className="ext-batch-delete-modal",e.innerHTML=`
      <div class="ext-modal-content">
        <div class="ext-modal-header">
          <h3 style="margin: 0; font-size: 18px; color: #0f172a; font-weight: 700; letter-spacing: -0.3px;">Upload Dokumen Ulang</h3>
          <button class="ext-modal-close" id="ext-modal-close-btn">${y.xClose}</button>
        </div>
        <div class="ext-mode-radio">
          <label><input type="radio" name="ext-upload-mode" value="manual" checked> Mode Manual (Paste URL)</label>
          <label><input type="radio" name="ext-upload-mode" value="auto"> Auto-Crawl Rekam Medis</label>
        </div>
        <div id="ext-manual-section">
          <label class="ext-input-label">Paste URL Dokumen (satu per baris):</label>
          <textarea id="${x.textareaId}" placeholder="https://example.com/dokumen1.pdf&#10;https://example.com/dokumen2.jpg&#10;..."></textarea>
          <div style="margin-top: 12px; display: flex; gap: 10px;">
            <button class="ext-btn ext-btn-purple" id="ext-analyze-btn">${y.search} Analisis URL</button>
          </div>
        </div>
        <div id="ext-auto-section" style="display: none;">
          <p style="font-size: 13px; color: #64748b; margin-bottom: 12px;">Mendeteksi dokumen otomatis dari halaman Rekam Medis pasien ini.</p>
          <div style="margin-bottom: 12px; display: flex; gap: 10px;">
            <button class="ext-btn ext-btn-purple" id="ext-crawl-btn">${y.search} Cari Dokumen Pasien Otomatis</button>
          </div>
          <div id="ext-upload-search-wrap" class="ext-upload-search-wrap" style="display: none;">
            <input type="text" id="ext-upload-search-input" class="ext-search-input" placeholder="Cari dokumen...">
          </div>
        </div>
        <div id="${x.previewId}" style="display: none; border: 1px solid #e5e7eb; border-radius: 6px; overflow: hidden;"></div>
        <div id="${x.progressId}" style="display: none; height: 4px; background: #374151; margin: 12px 0; border-radius: 2px; overflow: hidden;">
          <div class="progress-fill"></div>
        </div>
        <div id="${x.statusId}" style="margin: 8px 0; font-size: 11px; color: #9ca3af; font-weight: 500; letter-spacing: 0.3px;"></div>
        <div class="ext-modal-buttons">
          <button class="ext-btn ext-btn-secondary" id="ext-cancel-btn">Tutup</button>
          <button class="ext-btn ext-btn-danger" id="ext-cancel-batch-btn" style="display:none;" title="Batalkan proses upload yang sedang berjalan">${y.xClose} Batalkan Upload</button>
          <button id="ext-test-single-btn" class="ext-btn ext-btn-secondary" style="background: #fef3c7; color: #92400e; border-color: #fde68a;">Test 1 URL</button>
          <button id="ext-start-upload-btn" class="ext-btn ext-btn-primary" disabled>${y.upload} Mulai Upload</button>
        </div>
      </div>
    `,setTimeout(()=>{document.getElementById("ext-modal-close-btn")?.addEventListener("click",()=>e?.classList.remove("show")),document.getElementById("ext-analyze-btn")?.addEventListener("click",me),document.getElementById("ext-cancel-btn")?.addEventListener("click",N),document.getElementById("ext-cancel-batch-btn")?.addEventListener("click",q),document.getElementById("ext-test-single-btn")?.addEventListener("click",ee),document.getElementById("ext-start-upload-btn")?.addEventListener("click",te),document.querySelectorAll('input[name="ext-upload-mode"]').forEach(t=>{t.addEventListener("change",n=>{let a=n.target,r=document.getElementById("ext-manual-section"),o=document.getElementById("ext-auto-section");a.value==="manual"?(r&&(r.style.display="block"),o&&(o.style.display="none")):(r&&(r.style.display="none"),o&&(o.style.display="block")),u=[],U([]),b("")})}),document.getElementById("ext-crawl-btn")?.addEventListener("click",xe),document.getElementById("ext-upload-search-input")?.addEventListener("input",()=>U(u)),e?.addEventListener("click",function(t){t.target===e&&N()})},0),document.body.appendChild(e)),document.querySelectorAll(".ext-batch-delete-modal.show").forEach(t=>{t!==e&&t.classList.remove("show")}),e.classList.add("show"),document.getElementById(x.textareaId)?.focus()}function N(){q();let e=document.getElementById(x.modalId);if(e){e.classList.remove("show"),u=[],w=!1,U([]),J(0),b("");let t=document.getElementById("ext-upload-search-input");t&&(t.value="");let n=document.getElementById("ext-upload-search-wrap");n&&(n.style.display="none");let a=document.querySelector("#"+x.modalId+" .ext-modal-buttons");a&&(a.innerHTML='<button class="ext-btn ext-btn-secondary" id="ext-cancel-btn">Tutup</button><button class="ext-btn ext-btn-danger" id="ext-cancel-batch-btn" style="display:none;" title="Batalkan proses upload yang sedang berjalan">'+y.xClose+' Batalkan Upload</button><button id="ext-test-single-btn" class="ext-btn ext-btn-secondary" style="background: #fef3c7; color: #92400e; border-color: #fde68a;">Test 1 URL</button><button id="ext-start-upload-btn" class="ext-btn ext-btn-primary" disabled>'+y.upload+" Mulai Upload</button>",document.getElementById("ext-cancel-btn")?.addEventListener("click",N),document.getElementById("ext-cancel-batch-btn")?.addEventListener("click",q),document.getElementById("ext-test-single-btn")?.addEventListener("click",ee),document.getElementById("ext-start-upload-btn")?.addEventListener("click",te))}}function U(e){let t=document.getElementById(x.previewId),n=document.getElementById("ext-start-upload-btn"),a=document.getElementById("ext-upload-search-wrap"),r=document.getElementById("ext-upload-search-input"),o=document.getElementById("ext-auto-section")?.style.display!=="none",l=(r?.value||"").toLowerCase();if(!e||e.length===0){t&&(t.style.display="none"),n&&(n.disabled=!0),a&&(a.style.display="none"),r&&(r.value="");return}a&&o&&(a.style.display="block");let s=e.map((i,d)=>({item:i,i:d})).filter(({item:i})=>!l||i.filename.toLowerCase().includes(l)||i.keterangan.toLowerCase().includes(l)||i.norm.toLowerCase().includes(l));t&&(t.style.display="block");let c=document.createElement("div");if(c.style.marginBottom="10px",c.innerHTML=`<strong class="preview-header-text">Preview (${s.length} dari ${e.length} dokumen, ${e.filter(i=>i.selected!==!1).length} dipilih):</strong>`,t&&(t.innerHTML="",t.appendChild(c)),s.length===0){let i=document.createElement("div");i.style.cssText="padding:24px;text-align:center;font-size:13px;color:#9ca3af;",i.textContent="Tidak ada dokumen yang cocok dengan pencarian.",t?.appendChild(i)}s.forEach(({item:i,i:d})=>{let p="";i.tglFileTabel?p=`<div style="font-size:11px;color:#4b5563;margin-top:6px;display:flex;gap:8px;flex-wrap:wrap;">
        <span>Dibuat: <strong style="color:#111827;">${k(i.tglFileTabel||"")}</strong></span>
        <span style="color:#d1d5db;">|</span>
        <span>Diunggah: <strong style="color:#111827;">${k(i.tglUploadTabel||"")}</strong></span>
      </div>`:p=`<div style="font-size:11px;color:#4b5563;margin-top:6px;display:flex;gap:8px;flex-wrap:wrap;">
        <span>NORM: <strong style="color:#111827;">${k(i.norm||"-")}</strong></span>
        <span style="color:#d1d5db;">|</span>
        <span>Tgl Klaim: <strong style="color:#111827;">${k(i.tanggal)}</strong></span>
      </div>`;let f=(i.filename.split(".").pop()||"").toLowerCase(),g={pdf:"bg-red-100 text-red-700",jpg:"bg-blue-100 text-blue-700",jpeg:"bg-blue-100 text-blue-700",png:"bg-green-100 text-green-700"}[f]||"bg-gray-100 text-gray-700",h=f?`<span class="${g}" style="font-size:10px;padding:1px 5px;border-radius:4px;font-weight:600;text-transform:uppercase;margin-left:6px;">${f}</span>`:"",m=document.createElement("div");m.className="ext-delete-preview-item",i.selected&&m.classList.add("selected"),m.innerHTML=`
      <label class="ext-checkbox-label" style="flex:1;min-width:0;">
        <input type="checkbox" class="ext-checkbox" data-index="${d}" ${i.selected!==!1?"checked":""} ${w?"disabled":""}>
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
            <strong style="font-size: 13px; color: #000000; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${d+1}. ${k(i.filename)}${h}</strong>
            ${i.status!=="pending"?`<span class="ext-status-badge" data-status="${i.status==="success"?"success":i.status==="error"?"error":"deleting"}">${i.status==="success"?"Sukses":i.status==="error"?"Gagal":"Memproses"}</span>`:""}
          </div>
          ${p}
          <input type="text" class="ext-keterangan-input" data-index="${d}" value="${k(i.keterangan||"")}" placeholder="Keterangan dokumen..." ${w?"disabled":""}>
          ${i.error?`<div style="font-size: 11px; color: #dc2626; margin-top: 4px;"><strong>Error:</strong> ${k(i.error)}</div>`:""}
        </div>
      </label>
      <button data-index="${d}" class="ext-delete-preview-btn" ${w?"disabled":""}>${y.eye} Preview</button>
      <button data-index="${d}" class="ext-delete-single-btn" title="Buang dari Antrian" ${w?"disabled":""}>${y.xClose}</button>
    `;let T=m.querySelector(".ext-checkbox"),L=m.querySelector(".ext-delete-preview-btn"),v=m.querySelector(".ext-delete-single-btn"),I=B=>{if(w)return;i.selected=B,T&&(T.checked=B),B?m.classList.add("selected"):m.classList.remove("selected");let E=e.filter(R=>R.selected!==!1).length;c.innerHTML=`<strong class="preview-header-text">Preview (${E} Dokumen Dipilih):</strong>`,n&&(n.disabled=E===0)};T?.addEventListener("change",B=>I(B.target.checked)),v?.addEventListener("click",()=>I(!1));let S=m.querySelector(".ext-keterangan-input");S?.addEventListener("input",function(){u[d].keterangan=S.value}),L&&(L.addEventListener("click",async()=>{try{await V(u[d].url,u[d].filename)}catch{window.open(u[d].url,"_blank")}}),w&&(L.disabled=!0)),t?.appendChild(m)}),n&&(n.disabled=e.filter(i=>i.selected!==!1).length===0)}function J(e){let t=document.getElementById(x.progressId);if(!t)return;let n=t.querySelector(".progress-fill");e>0?(t.style.display="block",n&&(n.style.width=`${e}%`)):t.style.display="none"}function b(e){let t=document.getElementById(x.statusId);t&&(t.textContent=e)}function M(e){let t=["ext-analyze-btn","ext-cancel-btn","ext-test-single-btn","ext-start-upload-btn","ext-modal-close-btn","ext-crawl-btn",x.textareaId];document.querySelectorAll('input[name="ext-upload-mode"]').forEach(a=>{a.disabled=e});let n=document.getElementById("ext-cancel-batch-btn");n&&(n.style.display=e?"inline-flex":"none"),t.forEach(a=>{let r=document.getElementById(a);r&&(r.disabled=e,(a==="ext-modal-close-btn"||a===x.textareaId)&&(r.style.opacity=e?"0.5":"1",r.style.cursor=e?"not-allowed":a===x.textareaId?"text":"pointer"))})}function me(){let e=document.getElementById(x.textareaId)?.value.trim()||"";if(!e){$({title:"Tidak ada URL",message:"Silakan paste URL terlebih dahulu.",variant:"warning",okLabel:"OK",hideCancel:!0});return}let t=Z(e);if(t.length===0){$({title:"Tidak ada URL valid",message:"Pastikan URL mengandung ekstensi file yang didukung.",variant:"warning",okLabel:"OK",hideCancel:!0});return}if(t.length>x.maxBatchSize){$({title:"Terlalu banyak URL",message:`Maksimal ${x.maxBatchSize} URL per batch.`,variant:"warning",okLabel:"OK",hideCancel:!0});return}u=t.map(n=>j(n)),U(u),b(`${t.length} URL siap diproses`)}async function xe(){let e=new URLSearchParams(window.location.search).get("id_visit");if(!e){$({title:"Parameter id_visit tidak ditemukan",message:"Pastikan buka dari halaman detail pasien.",variant:"warning",okLabel:"OK",hideCancel:!0});return}b("Sedang mencari dokumen di rekam medis...");let t=document.getElementById("ext-crawl-btn");t&&(t.disabled=!0,t.textContent="Mencari...");try{let n=`${window.location.origin}/admisi/pelaksanaan_pelayanan/dokumen-pasien?id_visit=${e}&id_kunjungan=`,a=await fetch(n,{signal:O()});if(!a.ok)throw new Error("Gagal memuat halaman dokumen pasien");let r=await a.text(),o=new DOMParser().parseFromString(r,"text/html"),l=o.querySelectorAll("table.data-list.tabel tr");l.length<=1&&(l=o.querySelectorAll("table.tabel tr")),l.length<=1&&(l=o.querySelectorAll('table[id*="dokumen"] tr, table[class*="dokumen"] tr')),l.length<=1&&(l=o.querySelectorAll("tbody tr"));let s=[];for(let c=1;c<l.length;c++){let i=l[c],d=i.querySelector('td a[href*="/assets/dokumen-pasien/"]');if(d||(d=i.querySelector('td a[href*="dokumen-pasien"]')),d||(d=i.querySelector("a[href]")),!d)continue;let p=d.getAttribute("href");if(!p?.includes("/assets/dokumen-pasien/"))continue;let f=p.startsWith("http")?p:`${window.location.origin}${p}`,g=Array.from(i.querySelectorAll("td")),h=g[1]?.textContent?.trim()||g[0]?.textContent?.trim()||"",m=g[2]?.textContent?.trim()||g[1]?.textContent?.trim()||"",T=g[3]?.textContent?.trim()||g[2]?.textContent?.trim()||"",L=g[4]?.textContent?.trim()||g[3]?.textContent?.trim()||"";s.push({url:f,filenameTabel:h,tglFile:T,tglUpload:L,keteranganTabel:m})}if(s.length===0){b("Tidak ada dokumen ditemukan di rekam medis."),t&&(t.disabled=!1,t.textContent="Cari Dokumen Pasien Otomatis");return}u=s.map(c=>{let i=j(c.url);return i.tglFileTabel=c.tglFile,i.tglUploadTabel=c.tglUpload,i.filename=c.filenameTabel||i.filename,i.keterangan=c.keteranganTabel||i.filename||"-",i.selected=!1,i}),U(u),b(`${u.length} dokumen berhasil ditemukan!`)}catch(n){b("Error: "+n.message)}finally{t&&(t.disabled=!1,t.textContent="Cari Dokumen Pasien Otomatis")}}async function be(e,t){b(`Mengunduh: ${k(t)}...`),console.log("[Batch Upload] Fetching URL:",e);let n,a=O();try{n=await F(e,{method:"GET",credentials:"same-origin",signal:a},2)}catch{n=await F(e,{method:"GET",mode:"cors",credentials:"omit",signal:a},1)}if(!n.ok){let c=await n.text().catch(()=>"");throw new Error(`HTTP ${n.status} \u2014 ${n.statusText||c.slice(0,120)}`)}let r=await n.blob();if(r.size===0)throw new Error("File kosong (0 bytes) dari server");let o=await r.slice(0,512).text().catch(()=>"");if(/^\s*<!doctype html|<html[\s>]/i.test(o))throw new Error("Server mengembalikan halaman HTML (sesi login kadaluarsa?) \u2014 bukan file dokumen");let l=t.includes(".")?"."+t.split(".").pop():"",s=t.replace(/[<>:"/\\|?*]/g,"_");return new File([r],s,{type:r.type||`application/${l.slice(1)||"octet-stream"}`})}async function fe(e){if(typeof createImageBitmap=="function"){let t=await createImageBitmap(e);try{return{width:t.width,height:t.height}}finally{t.close?.()}}return new Promise((t,n)=>{let a=new Image,r=URL.createObjectURL(e);a.onload=()=>{URL.revokeObjectURL(r),t({width:a.naturalWidth,height:a.naturalHeight})},a.onerror=()=>{URL.revokeObjectURL(r),n(new Error("Tidak bisa membaca dimensi gambar"))},a.src=r})}async function he(e){let t=document.createElement("canvas"),n=URL.createObjectURL(e);try{let a=await new Promise((c,i)=>{let d=new Image;d.onload=()=>c(d),d.onerror=()=>i(new Error("Gagal memuat gambar untuk konversi ke PDF")),d.src=n}),r=Math.max(1,a.naturalWidth),o=Math.max(1,a.naturalHeight);t.width=r,t.height=o;let l=t.getContext("2d");if(!l)throw new Error("Canvas 2D tidak tersedia");l.fillStyle="#ffffff",l.fillRect(0,0,r,o),l.drawImage(a,0,0);let s=await new Promise(c=>t.toBlob(c,"image/jpeg",.92));if(!s)throw new Error("Gagal rasterisasi gambar ke JPEG");return{bytes:new Uint8Array(await s.arrayBuffer()),width:r,height:o}}finally{URL.revokeObjectURL(n)}}async function we(e){let t=new Uint8Array(await e.slice(0,16).arrayBuffer()),n=de(t),a=e.name.replace(/\.[a-z0-9]+$/i,".pdf");if(n==="pdf")return new File([e],a,{type:"application/pdf"});if(n==="jpeg"){let r=new Uint8Array(await e.arrayBuffer()),{width:o,height:l}=await fe(e);return new File([X(r,o,l)],a,{type:"application/pdf"})}if(n==="png"||n==="gif"||n==="webp"){let{bytes:r,width:o,height:l}=await he(e);return new File([X(r,o,l)],a,{type:"application/pdf"})}throw new Error(`File bukan PDF/gambar yang bisa dikonversi (${e.type||"tipe tidak diketahui"}) \u2014 upload dibatalkan`)}function ye(){let e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0"),r=String(e.getHours()).padStart(2,"0"),o=String(e.getMinutes()).padStart(2,"0"),l=String(e.getSeconds()).padStart(2,"0");return`${t}-${n}-${a} ${r}:${o}:${l}`}async function D(e,t){try{let n=ie(e,e.keterangan);b(`Download: ${k(e.filename)}...`);let a=await be(e.url,n);b(`Konversi ke PDF: ${k(e.filename)}...`),a=await we(a);let r=new FormData;r.append("id_visit",t),r.append("norm",e.norm),r.append("tgl_file",e.tanggal),r.append("jenis_dokumen",e.jenis_dokumen||"Lain-lain"),r.append("dok",a);let o=ye();r.append("keterangan",o),b(`Upload: ${k(a.name)} (${(a.size/1024).toFixed(0)} KB)...`);let l=await F(x.uploadEndpoint,{method:"POST",body:r,credentials:"same-origin",signal:O()},2);if(!l.ok){if(l.redirected)throw new Error("Sesi login kadaluarsa \u2014 login ulang di tab ini lalu coba lagi");let d=await l.text().catch(()=>""),p=d.replace(/<[^>]+>/g,"").trim().slice(0,200),f=d.match(/"message"\s*:\s*"([^"]+)"/),g=f?`Server ${l.status}: ${f[1]}`:`Server ${l.status}: ${p||l.statusText}`;throw new Error(g)}let s=await l.text(),c=l.headers.get("content-type")||"";if(/application\/json/i.test(c))try{let d=JSON.parse(s);return d.success===!1||d.status==="error"||d.error?{success:!1,error:d.message||d.error||"Server rejected"}:{success:!0,result:s}}catch{return{success:!0,result:s}}if(/text\/html/i.test(c))return/class="[^"]*alert-danger[^"]*"/i.test(s)||/<div[^>]*class="[^"]*error[^"]*"[^>]*>[\s\S]{0,200}<\/div>/i.test(s)||/"success"\s*:\s*false/i.test(s)?{success:!1,error:`Server error: ${s.replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim().slice(0,200)}`}:{success:!0,result:s};let i=s.trim();return/^(error|gagal)/i.test(i)?{success:!1,error:`Server: ${i.slice(0,200)}`}:{success:!0,result:s}}catch(n){let a=n.message;if(a==="Batch cancelled")throw n;let r=a;return a.includes("Failed to fetch")||a.includes("NetworkError")?r="Network error \u2014 cek koneksi atau CORS":a.includes("timeout")||a.includes("AbortError")?r="Timeout \u2014 server tidak merespon dalam 30 detik":a.includes("0 bytes")&&(r="File kosong dari server"),{success:!1,error:r}}}async function Q(){if(w)return;_=new AbortController,w=!0,M(!0);let e=document.getElementById("ext-start-upload-btn");e&&(e.textContent="Memproses...");let t=new URLSearchParams(window.location.search).get("id_visit")||"";if(!t){$({title:"ID Visit tidak ditemukan",message:"Pastikan buka dari halaman detail pasien.",variant:"warning",okLabel:"OK",hideCancel:!0}),M(!1),w=!1,e&&(e.textContent="Mulai Upload");return}let n=0,a=0,r=!1,o=u.filter(i=>i.selected!==!1),l=o.length;if(l===0){$({title:"Tidak ada dokumen dipilih",message:"Tidak ada dokumen yang dipilih untuk diupload.",variant:"warning",okLabel:"OK",hideCancel:!0}),M(!1),w=!1,b(""),e&&(e.textContent="Mulai Upload");return}for(let i=0;i<l;i++){if(O().aborted){r=!0,b("Batch dibatalkan oleh user");break}let d=new URLSearchParams(window.location.search).get("id_visit")||"";if(!d){b("ID Visit hilang dari URL \u2014 batch dihentikan");break}d!==t&&console.warn("[Batch Upload] ID Visit berubah mid-batch:",t,"->",d);let p=o[i];b(`[${i+1}/${l}] ${k(p.filename)}...`);try{let g=new URLSearchParams(window.location.search).get("id_visit")||t,h=await D(p,g);h.success?(p.status="success",n++):(p.status="error",p.error=h.error,a++)}catch(g){if(g instanceof Error&&g.message==="Batch cancelled"){r=!0,b("Batch dibatalkan");break}p.status="error",p.error=g.message,a++}let f=(i+1)/l*100;J(f),U(u)}let s=r?["Batch dibatalkan:",`${n} sukses`]:[`Selesai ${l} dokumen:`,`${n} sukses`];a>0&&s.push(`${a} gagal`),b(s.join(" ")),a>0&&console.warn("[Batch Upload] Failed:",u.filter(i=>i.status==="error").map(i=>`${i.filename}: ${i.error}`));let c=document.querySelector("#"+x.modalId+" .ext-modal-buttons");if(c){let i=`<button class="ext-btn ext-btn-purple" id="ext-reload-btn"><span style="display:inline-flex;align-items:center;gap:7px;">${y.refresh} Reload Halaman</span></button>`,d=a>0?'<button class="ext-btn ext-btn-secondary" id="ext-retry-failed-btn" style="border-color:#fbbf24;color:#92400e;">Ulangi yang Gagal</button>':"";c.innerHTML=`<div style="display:flex;gap:8px;justify-content:flex-end;">${d}${i}</div>`,document.getElementById("ext-reload-btn")?.addEventListener("click",()=>window.location.reload()),a>0&&document.getElementById("ext-retry-failed-btn")?.addEventListener("click",()=>{u.forEach(p=>{p.status==="error"&&(p.status="pending",p.error=void 0)}),U(u),Q()})}w=!1}async function ee(){if(u.length===0){$({title:"Tidak ada URL",message:"Tidak ada URL untuk ditest.",variant:"warning",okLabel:"OK",hideCancel:!0});return}if(w)return;w=!0,M(!0);let e=u[0];b("Testing single upload...");let t=new URLSearchParams(window.location.search).get("id_visit")||"";try{let n=await D(e,t);n.success?(e.status="success",b("Test sukses! Detail di console.")):(e.status="error",e.error=n.error,b("Test gagal! Detail di console."))}catch(n){e.status="error",e.error=n.message,b("Test error! Detail di console.")}U(u),M(!1),w=!1}function te(){if(u.length===0){$({title:"Tidak ada URL",message:"Tidak ada URL untuk diproses.",variant:"warning",okLabel:"OK",hideCancel:!0});return}let e=u.filter(t=>t.selected!==!1).length;if(e===0){$({title:"Tidak ada dokumen dipilih",message:"Centang dokumen yang ingin diupload.",variant:"warning",okLabel:"OK",hideCancel:!0});return}(async()=>await $({title:`Upload ${e} dokumen?`,message:"Proses ini tidak dapat dibatalkan.",variant:"warning",okLabel:"Ya, Upload"})&&Q())()}function ke(){return!!new URLSearchParams(window.location.search).get("id_visit")}async function ve(){let e=new URLSearchParams(window.location.search).get("id_visit");if(!e){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_ERROR",data:{error:"Parameter id_visit tidak ditemukan di URL."}}).catch(console.error);return}try{let t=`${window.location.origin}/admisi/pelaksanaan_pelayanan/dokumen-pasien?id_visit=${e}&page=85&id_kunjungan=`,n=await fetch(t);if(!n.ok)throw new Error("Gagal memuat halaman dokumen pasien");let a=await n.text(),r=new DOMParser().parseFromString(a,"text/html").querySelectorAll("table.data-list.tabel tr"),o=[];for(let l=1;l<r.length;l++){let s=r[l],c=s.querySelector("td:nth-child(2) a");if(!c)continue;let i=c.getAttribute("href");if(!i?.includes("/assets/dokumen-pasien/"))continue;let d=i.startsWith("http")?i:`${window.location.origin}${i}`,p=s.cells[1]?.textContent?.trim()||"",f=s.cells[2]?.textContent?.trim()||"",g=s.cells[3]?.textContent?.trim()||"",h=s.cells[4]?.textContent?.trim()||"";o.push({url:d,filenameTabel:p,tglFile:g,tglUpload:h,keteranganTabel:f})}if(o.length===0){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_CRAWL_RESULT",data:{items:[]}}).catch(console.error);return}u=o.map(l=>{let s=j(l.url);return s.tglFileTabel=l.tglFile,s.tglUploadTabel=l.tglUpload,s.filename=l.filenameTabel||s.filename,s.keterangan=l.keteranganTabel||s.filename||"-",s.selected=!1,s}),chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_CRAWL_RESULT",data:{items:u}}).catch(console.error)}catch(t){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_ERROR",data:{error:t.message}}).catch(console.error)}}async function Le(){_=new AbortController;try{let e=new URLSearchParams(window.location.search).get("id_visit")||"";if(!e){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_ERROR",data:{error:"ID Visit tidak ditemukan di URL"}}).catch(console.error);return}let t=0,n=0,a=u.filter(o=>o.selected!==!1),r=a.length;if(r===0){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_ERROR",data:{error:"Tidak ada dokumen yang dipilih."}}).catch(console.error);return}for(let o=0;o<r;o++){let l=a[o];l.status="uploading",ae(o,r,t,n,u);try{let s=await D(l,e);s.success?(l.status="success",t++):(l.status="error",l.error=s.error,n++)}catch(s){l.status="error",l.error=s.message,n++}ae(o+1,r,t,n,u)}}catch(e){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_ERROR",data:{error:e.message}}).catch(console.error)}}function ae(e,t,n,a,r){chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_PROGRESS",data:{percent:e/t*100,status:`Diproses: ${e}/${t} - Sukses: ${n}, Gagal: ${a}`,items:r,finished:e>=t}}).catch(console.error)}async function $e(){if(u.length===0)return;let e=u[0],t=new URLSearchParams(window.location.search).get("id_visit")||"";e.status="uploading",chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_PROGRESS",data:{percent:50,status:`Testing single upload: ${e.filename}...`,items:u,finished:!1}}).catch(console.error);try{let n=await D(e,t);n.success?e.status="success":(e.status="error",e.error=n.error)}catch(n){e.status="error",e.error=n.message}chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_PROGRESS",data:{percent:100,status:e.status==="success"?"Test upload sukses!":"Test upload gagal!",items:u,finished:!0}}).catch(console.error)}function Ee(){if(document.getElementById("ext-batch-url-style"))return;let e=document.createElement("style");e.id="ext-batch-url-style",e.textContent=`
    #${x.textareaId} {
      width:100%;height:150px;padding:12px;border:1px solid #e2e8f0;
      border-radius:10px;font-size:12px;resize:vertical;
      background:#f8fafc;color:#1e293b;
      transition:border-color .15s ease;box-sizing:border-box;
    }
    #${x.textareaId}:focus {
      border-color:#94a3b8;box-shadow:0 0 0 3px rgba(148,163,184,.1);
      background:#fff;outline:none;
    }
    #${x.previewId} {
      margin-top:15px;max-height:none;overflow-y:visible;
      border:1px solid #f1f5f9;border-radius:10px;padding:12px;
    }
    #${x.progressId} .progress-fill {
      height:100%;background:#2563eb;border-radius:3px;
      width:0%;transition:width .3s cubic-bezier(.16,1,.3,1);
    }
    .ext-input-label{display:block;margin-bottom:6px;font-weight:600;font-size:13px;color:#334155}
    .ext-mode-radio{display:flex;gap:20px;align-items:center;margin-bottom:16px;font-size:13px;color:#475569}
    .ext-mode-radio label{cursor:pointer;display:flex;align-items:center;gap:6px}
    .ext-mode-radio input[type="radio"]{accent-color:#2563eb}
    .ext-upload-search-wrap{display:none;margin-bottom:10px}
    .ext-keterangan-input{
      width:100%;padding:6px 10px;font-size:11px;border:1px solid #e2e8f0;border-radius:6px;
      outline:none;color:#475569;background:#f8fafc;box-sizing:border-box;margin-top:5px;
    }
    .ext-keterangan-input:focus{border-color:#94a3b8;background:#fff}
    .ext-keterangan-input::placeholder{color:#94a3b8}
    .ext-inline-preview-spinner{
      width:40px;height:40px;border:4px solid rgba(255,255,255,.15);
      border-top:4px solid #fff;border-radius:50%;animation:ext-spin .8s linear infinite
    }
    @keyframes ext-spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
  `,document.head.appendChild(e),W()}function Te(){!P.currentConfig?.features?.batchUpload?.enabled||!P.ExtensionCore.isFeatureAllowed("batchUpload")||ke()&&(Ee(),chrome.runtime.sendMessage({type:"PAGE_CONTEXT",feature:"mKlaimDetail",data:{idVisit:new URLSearchParams(window.location.search).get("id_visit"),tanggalMasuk:H()}}).catch(console.error),!window.__extBatchUploadRegistered&&(window.__extBatchUploadRegistered=!0,chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type==="TAB_ACTION"){let{action:a,payload:r}=e;a==="BATCH_UPLOAD_ANALYZE"?(u=Z(r.inputText).map(o=>j(o)),chrome.runtime.sendMessage({type:"TAB_ACTION_RESULT",action:"BATCH_UPLOAD_ANALYZE_RESULT",data:{items:u}}).catch(console.error)):a==="BATCH_UPLOAD_CRAWL"?ve():a==="BATCH_UPLOAD_UPDATE_ITEMS"?u=r.items:a==="BATCH_UPLOAD_PREVIEW"?V(r.url,r.filename).catch(()=>{window.open(r.url,"_blank")}):a==="BATCH_UPLOAD_START"?Le():a==="BATCH_UPLOAD_TEST_SINGLE"&&$e(),n({success:!0})}else e.type==="BATCH_UPLOAD_ACTION"&&n({success:!0});return!0})))}window.batchUploadShowModal=ge,typeof P.featureModules<"u"&&P.featureModules!==null?P.featureModules.batchUpload={id:"batchUpload",name:"Upload Dokumen Ulang",description:"Upload Dokumen Ulang via paste URL dengan metadata extraction otomatis",match:{regex:/^\/v2\/m-klaim\/detail-v2-refaktor\/?$/},run:Te}:console.warn("[Batch Upload] featureModules not defined, module registration skipped")})();
