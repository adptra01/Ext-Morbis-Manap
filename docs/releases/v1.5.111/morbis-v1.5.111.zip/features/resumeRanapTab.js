"use strict";var __morbis_feature=(()=>{var cm=Object.create,ic=Object.defineProperty,um=Object.getOwnPropertyDescriptor,dm=Object.getOwnPropertyNames,pm=Object.getPrototypeOf,fm=Object.prototype.hasOwnProperty,Ut=(i,s)=>()=>{try{return s||i((s={exports:{}}).exports,s),s.exports}catch(c){throw s=0,c}},mm=(i,s,c,p)=>{if(s&&typeof s=="object"||typeof s=="function")for(let d of dm(s))!fm.call(i,d)&&d!==c&&ic(i,d,{get:()=>s[d],enumerable:!(p=um(s,d))||p.enumerable});return i},Ie=(i,s,c)=>(c=i!=null?cm(pm(i)):{},mm(s||!i||!i.__esModule?ic(c,"default",{value:i,enumerable:!0}):c,i)),gm=Ut(i=>{"use strict";function s(D,M){var I=D.length;D.push(M);e:for(;0<I;){var ce=I-1>>>1,U=D[ce];if(0<d(U,M))D[ce]=M,D[I]=U,I=ce;else break e}}function c(D){return D.length===0?null:D[0]}function p(D){if(D.length===0)return null;var M=D[0],I=D.pop();if(I!==M){D[0]=I;e:for(var ce=0,U=D.length,at=U>>>1;ce<at;){var g=2*(ce+1)-1,A=D[g],F=g+1,$=D[F];if(0>d(A,I))F<U&&0>d($,A)?(D[ce]=$,D[F]=I,ce=F):(D[ce]=A,D[g]=I,ce=g);else if(F<U&&0>d($,I))D[ce]=$,D[F]=I,ce=F;else break e}}return M}function d(D,M){var I=D.sortIndex-M.sortIndex;return I!==0?I:D.id-M.id}i.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"?(S=performance,i.unstable_now=function(){return S.now()}):(L=Date,C=L.now(),i.unstable_now=function(){return L.now()-C});var S,L,C,R=[],k=[],z=1,N=null,O=3,re=!1,se=!1,K=!1,G=!1,ze=typeof setTimeout=="function"?setTimeout:null,pe=typeof clearTimeout=="function"?clearTimeout:null,Ue=typeof setImmediate<"u"?setImmediate:null;function oe(D){for(var M=c(k);M!==null;){if(M.callback===null)p(k);else if(M.startTime<=D)p(k),M.sortIndex=M.expirationTime,s(R,M);else break;M=c(k)}}function ye(D){if(K=!1,oe(D),!se)if(c(R)!==null)se=!0,be||(be=!0,Re());else{var M=c(k);M!==null&&Ke(ye,M.startTime-D)}}var be=!1,w=-1,E=5,B=-1;function Ne(){return G?!0:!(i.unstable_now()-B<E)}function Ae(){if(G=!1,be){var D=i.unstable_now();B=D;var M=!0;try{e:{se=!1,K&&(K=!1,pe(w),w=-1),re=!0;var I=O;try{t:{for(oe(D),N=c(R);N!==null&&!(N.expirationTime>D&&Ne());){var ce=N.callback;if(typeof ce=="function"){N.callback=null,O=N.priorityLevel;var U=ce(N.expirationTime<=D);if(D=i.unstable_now(),typeof U=="function"){N.callback=U,oe(D),M=!0;break t}N===c(R)&&p(R),oe(D)}else p(R);N=c(R)}if(N!==null)M=!0;else{var at=c(k);at!==null&&Ke(ye,at.startTime-D),M=!1}}break e}finally{N=null,O=I,re=!1}M=void 0}}finally{M?Re():be=!1}}}var Re;typeof Ue=="function"?Re=function(){Ue(Ae)}:typeof MessageChannel<"u"?(lt=new MessageChannel,Rt=lt.port2,lt.port1.onmessage=Ae,Re=function(){Rt.postMessage(null)}):Re=function(){ze(Ae,0)};var lt,Rt;function Ke(D,M){w=ze(function(){D(i.unstable_now())},M)}i.unstable_IdlePriority=5,i.unstable_ImmediatePriority=1,i.unstable_LowPriority=4,i.unstable_NormalPriority=3,i.unstable_Profiling=null,i.unstable_UserBlockingPriority=2,i.unstable_cancelCallback=function(D){D.callback=null},i.unstable_forceFrameRate=function(D){0>D||125<D?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):E=0<D?Math.floor(1e3/D):5},i.unstable_getCurrentPriorityLevel=function(){return O},i.unstable_next=function(D){switch(O){case 1:case 2:case 3:var M=3;break;default:M=O}var I=O;O=M;try{return D()}finally{O=I}},i.unstable_requestPaint=function(){G=!0},i.unstable_runWithPriority=function(D,M){switch(D){case 1:case 2:case 3:case 4:case 5:break;default:D=3}var I=O;O=D;try{return M()}finally{O=I}},i.unstable_scheduleCallback=function(D,M,I){var ce=i.unstable_now();switch(typeof I=="object"&&I!==null?(I=I.delay,I=typeof I=="number"&&0<I?ce+I:ce):I=ce,D){case 1:var U=-1;break;case 2:U=250;break;case 5:U=1073741823;break;case 4:U=1e4;break;default:U=5e3}return U=I+U,D={id:z++,callback:M,priorityLevel:D,startTime:I,expirationTime:U,sortIndex:-1},I>ce?(D.sortIndex=I,s(k,D),c(R)===null&&D===c(k)&&(K?(pe(w),w=-1):K=!0,Ke(ye,I-ce))):(D.sortIndex=U,s(R,D),se||re||(se=!0,be||(be=!0,Re()))),D},i.unstable_shouldYield=Ne,i.unstable_wrapCallback=function(D){var M=O;return function(){var I=O;O=M;try{return D.apply(this,arguments)}finally{O=I}}}}),hm=Ut((i,s)=>{"use strict";s.exports=gm()}),bm=Ut(i=>{"use strict";var s=Symbol.for("react.transitional.element"),c=Symbol.for("react.portal"),p=Symbol.for("react.fragment"),d=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),L=Symbol.for("react.consumer"),C=Symbol.for("react.context"),R=Symbol.for("react.forward_ref"),k=Symbol.for("react.suspense"),z=Symbol.for("react.memo"),N=Symbol.for("react.lazy"),O=Symbol.for("react.activity"),re=Symbol.iterator;function se(g){return g===null||typeof g!="object"?null:(g=re&&g[re]||g["@@iterator"],typeof g=="function"?g:null)}var K={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},G=Object.assign,ze={};function pe(g,A,F){this.props=g,this.context=A,this.refs=ze,this.updater=F||K}pe.prototype.isReactComponent={},pe.prototype.setState=function(g,A){if(typeof g!="object"&&typeof g!="function"&&g!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,g,A,"setState")},pe.prototype.forceUpdate=function(g){this.updater.enqueueForceUpdate(this,g,"forceUpdate")};function Ue(){}Ue.prototype=pe.prototype;function oe(g,A,F){this.props=g,this.context=A,this.refs=ze,this.updater=F||K}var ye=oe.prototype=new Ue;ye.constructor=oe,G(ye,pe.prototype),ye.isPureReactComponent=!0;var be=Array.isArray;function w(){}var E={H:null,A:null,T:null,S:null},B=Object.prototype.hasOwnProperty;function Ne(g,A,F){var $=F.ref;return{$$typeof:s,type:g,key:A,ref:$!==void 0?$:null,props:F}}function Ae(g,A){return Ne(g.type,A,g.props)}function Re(g){return typeof g=="object"&&g!==null&&g.$$typeof===s}function lt(g){var A={"=":"=0",":":"=2"};return"$"+g.replace(/[=:]/g,function(F){return A[F]})}var Rt=/\/+/g;function Ke(g,A){return typeof g=="object"&&g!==null&&g.key!=null?lt(""+g.key):A.toString(36)}function D(g){switch(g.status){case"fulfilled":return g.value;case"rejected":throw g.reason;default:switch(typeof g.status=="string"?g.then(w,w):(g.status="pending",g.then(function(A){g.status==="pending"&&(g.status="fulfilled",g.value=A)},function(A){g.status==="pending"&&(g.status="rejected",g.reason=A)})),g.status){case"fulfilled":return g.value;case"rejected":throw g.reason}}throw g}function M(g,A,F,$,Y){var J=typeof g;(J==="undefined"||J==="boolean")&&(g=null);var me=!1;if(g===null)me=!0;else switch(J){case"bigint":case"string":case"number":me=!0;break;case"object":switch(g.$$typeof){case s:case c:me=!0;break;case N:return me=g._init,M(me(g._payload),A,F,$,Y)}}if(me)return Y=Y(g),me=$===""?"."+Ke(g,0):$,be(Y)?(F="",me!=null&&(F=me.replace(Rt,"$&/")+"/"),M(Y,A,F,"",function(Vt){return Vt})):Y!=null&&(Re(Y)&&(Y=Ae(Y,F+(Y.key==null||g&&g.key===Y.key?"":(""+Y.key).replace(Rt,"$&/")+"/")+me)),A.push(Y)),1;me=0;var fe=$===""?".":$+":";if(be(g))for(var Le=0;Le<g.length;Le++)$=g[Le],J=fe+Ke($,Le),me+=M($,A,F,J,Y);else if(Le=se(g),typeof Le=="function")for(g=Le.call(g),Le=0;!($=g.next()).done;)$=$.value,J=fe+Ke($,Le++),me+=M($,A,F,J,Y);else if(J==="object"){if(typeof g.then=="function")return M(D(g),A,F,$,Y);throw A=String(g),Error("Objects are not valid as a React child (found: "+(A==="[object Object]"?"object with keys {"+Object.keys(g).join(", ")+"}":A)+"). If you meant to render a collection of children, use an array instead.")}return me}function I(g,A,F){if(g==null)return g;var $=[],Y=0;return M(g,$,"","",function(J){return A.call(F,J,Y++)}),$}function ce(g){if(g._status===-1){var A=g._result;A=A(),A.then(function(F){(g._status===0||g._status===-1)&&(g._status=1,g._result=F)},function(F){(g._status===0||g._status===-1)&&(g._status=2,g._result=F)}),g._status===-1&&(g._status=0,g._result=A)}if(g._status===1)return g._result.default;throw g._result}var U=typeof reportError=="function"?reportError:function(g){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var A=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof g=="object"&&g!==null&&typeof g.message=="string"?String(g.message):String(g),error:g});if(!window.dispatchEvent(A))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",g);return}console.error(g)},at={map:I,forEach:function(g,A,F){I(g,function(){A.apply(this,arguments)},F)},count:function(g){var A=0;return I(g,function(){A++}),A},toArray:function(g){return I(g,function(A){return A})||[]},only:function(g){if(!Re(g))throw Error("React.Children.only expected to receive a single React element child.");return g}};i.Activity=O,i.Children=at,i.Component=pe,i.Fragment=p,i.Profiler=S,i.PureComponent=oe,i.StrictMode=d,i.Suspense=k,i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=E,i.__COMPILER_RUNTIME={__proto__:null,c:function(g){return E.H.useMemoCache(g)}},i.cache=function(g){return function(){return g.apply(null,arguments)}},i.cacheSignal=function(){return null},i.cloneElement=function(g,A,F){if(g==null)throw Error("The argument must be a React element, but you passed "+g+".");var $=G({},g.props),Y=g.key;if(A!=null)for(J in A.key!==void 0&&(Y=""+A.key),A)!B.call(A,J)||J==="key"||J==="__self"||J==="__source"||J==="ref"&&A.ref===void 0||($[J]=A[J]);var J=arguments.length-2;if(J===1)$.children=F;else if(1<J){for(var me=Array(J),fe=0;fe<J;fe++)me[fe]=arguments[fe+2];$.children=me}return Ne(g.type,Y,$)},i.createContext=function(g){return g={$$typeof:C,_currentValue:g,_currentValue2:g,_threadCount:0,Provider:null,Consumer:null},g.Provider=g,g.Consumer={$$typeof:L,_context:g},g},i.createElement=function(g,A,F){var $,Y={},J=null;if(A!=null)for($ in A.key!==void 0&&(J=""+A.key),A)B.call(A,$)&&$!=="key"&&$!=="__self"&&$!=="__source"&&(Y[$]=A[$]);var me=arguments.length-2;if(me===1)Y.children=F;else if(1<me){for(var fe=Array(me),Le=0;Le<me;Le++)fe[Le]=arguments[Le+2];Y.children=fe}if(g&&g.defaultProps)for($ in me=g.defaultProps,me)Y[$]===void 0&&(Y[$]=me[$]);return Ne(g,J,Y)},i.createRef=function(){return{current:null}},i.forwardRef=function(g){return{$$typeof:R,render:g}},i.isValidElement=Re,i.lazy=function(g){return{$$typeof:N,_payload:{_status:-1,_result:g},_init:ce}},i.memo=function(g,A){return{$$typeof:z,type:g,compare:A===void 0?null:A}},i.startTransition=function(g){var A=E.T,F={};E.T=F;try{var $=g(),Y=E.S;Y!==null&&Y(F,$),typeof $=="object"&&$!==null&&typeof $.then=="function"&&$.then(w,U)}catch(J){U(J)}finally{A!==null&&F.types!==null&&(A.types=F.types),E.T=A}},i.unstable_useCacheRefresh=function(){return E.H.useCacheRefresh()},i.use=function(g){return E.H.use(g)},i.useActionState=function(g,A,F){return E.H.useActionState(g,A,F)},i.useCallback=function(g,A){return E.H.useCallback(g,A)},i.useContext=function(g){return E.H.useContext(g)},i.useDebugValue=function(){},i.useDeferredValue=function(g,A){return E.H.useDeferredValue(g,A)},i.useEffect=function(g,A){return E.H.useEffect(g,A)},i.useEffectEvent=function(g){return E.H.useEffectEvent(g)},i.useId=function(){return E.H.useId()},i.useImperativeHandle=function(g,A,F){return E.H.useImperativeHandle(g,A,F)},i.useInsertionEffect=function(g,A){return E.H.useInsertionEffect(g,A)},i.useLayoutEffect=function(g,A){return E.H.useLayoutEffect(g,A)},i.useMemo=function(g,A){return E.H.useMemo(g,A)},i.useOptimistic=function(g,A){return E.H.useOptimistic(g,A)},i.useReducer=function(g,A,F){return E.H.useReducer(g,A,F)},i.useRef=function(g){return E.H.useRef(g)},i.useState=function(g){return E.H.useState(g)},i.useSyncExternalStore=function(g,A,F){return E.H.useSyncExternalStore(g,A,F)},i.useTransition=function(){return E.H.useTransition()},i.version="19.2.8"}),At=Ut((i,s)=>{"use strict";s.exports=bm()}),vm=Ut(i=>{"use strict";var s=At();function c(k){var z="https://react.dev/errors/"+k;if(1<arguments.length){z+="?args[]="+encodeURIComponent(arguments[1]);for(var N=2;N<arguments.length;N++)z+="&args[]="+encodeURIComponent(arguments[N])}return"Minified React error #"+k+"; visit "+z+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function p(){}var d={d:{f:p,r:function(){throw Error(c(522))},D:p,C:p,L:p,m:p,X:p,S:p,M:p},p:0,findDOMNode:null},S=Symbol.for("react.portal");function L(k,z,N){var O=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:S,key:O==null?null:""+O,children:k,containerInfo:z,implementation:N}}var C=s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function R(k,z){if(k==="font")return"";if(typeof z=="string")return z==="use-credentials"?z:""}i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=d,i.createPortal=function(k,z){var N=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!z||z.nodeType!==1&&z.nodeType!==9&&z.nodeType!==11)throw Error(c(299));return L(k,z,null,N)},i.flushSync=function(k){var z=C.T,N=d.p;try{if(C.T=null,d.p=2,k)return k()}finally{C.T=z,d.p=N,d.d.f()}},i.preconnect=function(k,z){typeof k=="string"&&(z?(z=z.crossOrigin,z=typeof z=="string"?z==="use-credentials"?z:"":void 0):z=null,d.d.C(k,z))},i.prefetchDNS=function(k){typeof k=="string"&&d.d.D(k)},i.preinit=function(k,z){if(typeof k=="string"&&z&&typeof z.as=="string"){var N=z.as,O=R(N,z.crossOrigin),re=typeof z.integrity=="string"?z.integrity:void 0,se=typeof z.fetchPriority=="string"?z.fetchPriority:void 0;N==="style"?d.d.S(k,typeof z.precedence=="string"?z.precedence:void 0,{crossOrigin:O,integrity:re,fetchPriority:se}):N==="script"&&d.d.X(k,{crossOrigin:O,integrity:re,fetchPriority:se,nonce:typeof z.nonce=="string"?z.nonce:void 0})}},i.preinitModule=function(k,z){if(typeof k=="string")if(typeof z=="object"&&z!==null){if(z.as==null||z.as==="script"){var N=R(z.as,z.crossOrigin);d.d.M(k,{crossOrigin:N,integrity:typeof z.integrity=="string"?z.integrity:void 0,nonce:typeof z.nonce=="string"?z.nonce:void 0})}}else z==null&&d.d.M(k)},i.preload=function(k,z){if(typeof k=="string"&&typeof z=="object"&&z!==null&&typeof z.as=="string"){var N=z.as,O=R(N,z.crossOrigin);d.d.L(k,N,{crossOrigin:O,integrity:typeof z.integrity=="string"?z.integrity:void 0,nonce:typeof z.nonce=="string"?z.nonce:void 0,type:typeof z.type=="string"?z.type:void 0,fetchPriority:typeof z.fetchPriority=="string"?z.fetchPriority:void 0,referrerPolicy:typeof z.referrerPolicy=="string"?z.referrerPolicy:void 0,imageSrcSet:typeof z.imageSrcSet=="string"?z.imageSrcSet:void 0,imageSizes:typeof z.imageSizes=="string"?z.imageSizes:void 0,media:typeof z.media=="string"?z.media:void 0})}},i.preloadModule=function(k,z){if(typeof k=="string")if(z){var N=R(z.as,z.crossOrigin);d.d.m(k,{as:typeof z.as=="string"&&z.as!=="script"?z.as:void 0,crossOrigin:N,integrity:typeof z.integrity=="string"?z.integrity:void 0})}else d.d.m(k)},i.requestFormReset=function(k){d.d.r(k)},i.unstable_batchedUpdates=function(k,z){return k(z)},i.useFormState=function(k,z,N){return C.H.useFormState(k,z,N)},i.useFormStatus=function(){return C.H.useHostTransitionStatus()},i.version="19.2.8"}),ym=Ut((i,s)=>{"use strict";function c(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(c)}catch(p){console.error(p)}}c(),s.exports=vm()}),wm=Ut(i=>{"use strict";var s=hm(),c=At(),p=ym();function d(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var r=2;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function S(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function L(e){var t=e,r=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,(t.flags&4098)!==0&&(r=t.return),e=t.return;while(e)}return t.tag===3?r:null}function C(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function R(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function k(e){if(L(e)!==e)throw Error(d(188))}function z(e){var t=e.alternate;if(!t){if(t=L(e),t===null)throw Error(d(188));return t!==e?null:e}for(var r=e,n=t;;){var a=r.return;if(a===null)break;var o=a.alternate;if(o===null){if(n=a.return,n!==null){r=n;continue}break}if(a.child===o.child){for(o=a.child;o;){if(o===r)return k(a),e;if(o===n)return k(a),t;o=o.sibling}throw Error(d(188))}if(r.return!==n.return)r=a,n=o;else{for(var l=!1,u=a.child;u;){if(u===r){l=!0,r=a,n=o;break}if(u===n){l=!0,n=a,r=o;break}u=u.sibling}if(!l){for(u=o.child;u;){if(u===r){l=!0,r=o,n=a;break}if(u===n){l=!0,n=o,r=a;break}u=u.sibling}if(!l)throw Error(d(189))}}if(r.alternate!==n)throw Error(d(190))}if(r.tag!==3)throw Error(d(188));return r.stateNode.current===r?e:t}function N(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=N(e),t!==null)return t;e=e.sibling}return null}var O=Object.assign,re=Symbol.for("react.element"),se=Symbol.for("react.transitional.element"),K=Symbol.for("react.portal"),G=Symbol.for("react.fragment"),ze=Symbol.for("react.strict_mode"),pe=Symbol.for("react.profiler"),Ue=Symbol.for("react.consumer"),oe=Symbol.for("react.context"),ye=Symbol.for("react.forward_ref"),be=Symbol.for("react.suspense"),w=Symbol.for("react.suspense_list"),E=Symbol.for("react.memo"),B=Symbol.for("react.lazy"),Ne=Symbol.for("react.activity"),Ae=Symbol.for("react.memo_cache_sentinel"),Re=Symbol.iterator;function lt(e){return e===null||typeof e!="object"?null:(e=Re&&e[Re]||e["@@iterator"],typeof e=="function"?e:null)}var Rt=Symbol.for("react.client.reference");function Ke(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Rt?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case G:return"Fragment";case pe:return"Profiler";case ze:return"StrictMode";case be:return"Suspense";case w:return"SuspenseList";case Ne:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case K:return"Portal";case oe:return e.displayName||"Context";case Ue:return(e._context.displayName||"Context")+".Consumer";case ye:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case E:return t=e.displayName||null,t!==null?t:Ke(e.type)||"Memo";case B:t=e._payload,e=e._init;try{return Ke(e(t))}catch{}}return null}var D=Array.isArray,M=c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,I=p.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ce={pending:!1,data:null,method:null,action:null},U=[],at=-1;function g(e){return{current:e}}function A(e){0>at||(e.current=U[at],U[at]=null,at--)}function F(e,t){at++,U[at]=e.current,e.current=t}var $=g(null),Y=g(null),J=g(null),me=g(null);function fe(e,t){switch(F(J,t),F(Y,e),F($,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Tf(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Tf(t),e=Af(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}A($),F($,e)}function Le(){A($),A(Y),A(J)}function Vt(e){e.memoizedState!==null&&F(me,e);var t=$.current,r=Af(t,e.type);t!==r&&(F(Y,e),F($,r))}function Gt(e){Y.current===e&&(A($),A(Y)),me.current===e&&(A(me),Qa._currentValue=ce)}var Kr,Yr;function Xr(e){if(Kr===void 0)try{throw Error()}catch(r){var t=r.stack.trim().match(/\n( *(at )?)/);Kr=t&&t[1]||"",Yr=-1<r.stack.indexOf(`
    at`)?" (<anonymous>)":-1<r.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Kr+e+Yr}var Bi=!1;function Wi(e,t){if(!e||Bi)return"";Bi=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var n={DetermineComponentFrameRoot:function(){try{if(t){var T=function(){throw Error()};if(Object.defineProperty(T.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(T,[])}catch(_){var y=_}Reflect.construct(e,[],T)}else{try{T.call()}catch(_){y=_}e.call(T.prototype)}}else{try{throw Error()}catch(_){y=_}(T=e())&&typeof T.catch=="function"&&T.catch(function(){})}}catch(_){if(_&&y&&typeof _.stack=="string")return[_.stack,y.stack]}return[null,null]}};n.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var a=Object.getOwnPropertyDescriptor(n.DetermineComponentFrameRoot,"name");a&&a.configurable&&Object.defineProperty(n.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var o=n.DetermineComponentFrameRoot(),l=o[0],u=o[1];if(l&&u){var f=l.split(`
`),v=u.split(`
`);for(a=n=0;n<f.length&&!f[n].includes("DetermineComponentFrameRoot");)n++;for(;a<v.length&&!v[a].includes("DetermineComponentFrameRoot");)a++;if(n===f.length||a===v.length)for(n=f.length-1,a=v.length-1;1<=n&&0<=a&&f[n]!==v[a];)a--;for(;1<=n&&0<=a;n--,a--)if(f[n]!==v[a]){if(n!==1||a!==1)do if(n--,a--,0>a||f[n]!==v[a]){var P=`
`+f[n].replace(" at new "," at ");return e.displayName&&P.includes("<anonymous>")&&(P=P.replace("<anonymous>",e.displayName)),P}while(1<=n&&0<=a);break}}}finally{Bi=!1,Error.prepareStackTrace=r}return(r=e?e.displayName||e.name:"")?Xr(r):""}function $h(e,t){switch(e.tag){case 26:case 27:case 5:return Xr(e.type);case 16:return Xr("Lazy");case 13:return e.child!==t&&t!==null?Xr("Suspense Fallback"):Xr("Suspense");case 19:return Xr("SuspenseList");case 0:case 15:return Wi(e.type,!1);case 11:return Wi(e.type.render,!1);case 1:return Wi(e.type,!0);case 31:return Xr("Activity");default:return""}}function lu(e){try{var t="",r=null;do t+=$h(e,r),r=e,e=e.return;while(e);return t}catch(n){return`
Error generating stack: `+n.message+`
`+n.stack}}var Qi=Object.prototype.hasOwnProperty,Ki=s.unstable_scheduleCallback,Yi=s.unstable_cancelCallback,Hh=s.unstable_shouldYield,Vh=s.unstable_requestPaint,gt=s.unstable_now,qh=s.unstable_getCurrentPriorityLevel,su=s.unstable_ImmediatePriority,cu=s.unstable_UserBlockingPriority,lo=s.unstable_NormalPriority,Bh=s.unstable_LowPriority,uu=s.unstable_IdlePriority,Wh=s.log,Qh=s.unstable_setDisableYieldValue,ia=null,ht=null;function yr(e){if(typeof Wh=="function"&&Qh(e),ht&&typeof ht.setStrictMode=="function")try{ht.setStrictMode(ia,e)}catch{}}var bt=Math.clz32?Math.clz32:Xh,Kh=Math.log,Yh=Math.LN2;function Xh(e){return e>>>=0,e===0?32:31-(Kh(e)/Yh|0)|0}var so=256,co=262144,uo=4194304;function Gr(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function po(e,t,r){var n=e.pendingLanes;if(n===0)return 0;var a=0,o=e.suspendedLanes,l=e.pingedLanes;e=e.warmLanes;var u=n&134217727;return u!==0?(n=u&~o,n!==0?a=Gr(n):(l&=u,l!==0?a=Gr(l):r||(r=u&~e,r!==0&&(a=Gr(r))))):(u=n&~o,u!==0?a=Gr(u):l!==0?a=Gr(l):r||(r=n&~e,r!==0&&(a=Gr(r)))),a===0?0:t!==0&&t!==a&&(t&o)===0&&(o=a&-a,r=t&-t,o>=r||o===32&&(r&4194048)!==0)?t:a}function la(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Gh(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function du(){var e=uo;return uo<<=1,(uo&62914560)===0&&(uo=4194304),e}function Xi(e){for(var t=[],r=0;31>r;r++)t.push(e);return t}function sa(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Jh(e,t,r,n,a,o){var l=e.pendingLanes;e.pendingLanes=r,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=r,e.entangledLanes&=r,e.errorRecoveryDisabledLanes&=r,e.shellSuspendCounter=0;var u=e.entanglements,f=e.expirationTimes,v=e.hiddenUpdates;for(r=l&~r;0<r;){var P=31-bt(r),T=1<<P;u[P]=0,f[P]=-1;var y=v[P];if(y!==null)for(v[P]=null,P=0;P<y.length;P++){var _=y[P];_!==null&&(_.lane&=-536870913)}r&=~T}n!==0&&pu(e,n,0),o!==0&&a===0&&e.tag!==0&&(e.suspendedLanes|=o&~(l&~t))}function pu(e,t,r){e.pendingLanes|=t,e.suspendedLanes&=~t;var n=31-bt(t);e.entangledLanes|=t,e.entanglements[n]=e.entanglements[n]|1073741824|r&261930}function fu(e,t){var r=e.entangledLanes|=t;for(e=e.entanglements;r;){var n=31-bt(r),a=1<<n;a&t|e[n]&t&&(e[n]|=t),r&=~a}}function mu(e,t){var r=t&-t;return r=(r&42)!==0?1:Gi(r),(r&(e.suspendedLanes|t))!==0?0:r}function Gi(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Ji(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function gu(){var e=I.p;return e!==0?e:(e=window.event,e===void 0?32:rm(e.type))}function hu(e,t){var r=I.p;try{return I.p=e,t()}finally{I.p=r}}var wr=Math.random().toString(36).slice(2),Je="__reactFiber$"+wr,st="__reactProps$"+wr,bn="__reactContainer$"+wr,Zi="__reactEvents$"+wr,Zh="__reactListeners$"+wr,eb="__reactHandles$"+wr,bu="__reactResources$"+wr,ca="__reactMarker$"+wr;function el(e){delete e[Je],delete e[st],delete e[Zi],delete e[Zh],delete e[eb]}function vn(e){var t=e[Je];if(t)return t;for(var r=e.parentNode;r;){if(t=r[bn]||r[Je]){if(r=t.alternate,t.child!==null||r!==null&&r.child!==null)for(e=Uf(e);e!==null;){if(r=e[Je])return r;e=Uf(e)}return t}e=r,r=e.parentNode}return null}function yn(e){if(e=e[Je]||e[bn]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function ua(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(d(33))}function wn(e){var t=e[bu];return t||(t=e[bu]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Ye(e){e[ca]=!0}var vu=new Set,yu={};function Jr(e,t){xn(e,t),xn(e+"Capture",t)}function xn(e,t){for(yu[e]=t,e=0;e<t.length;e++)vu.add(t[e])}var tb=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),wu={},xu={};function rb(e){return Qi.call(xu,e)?!0:Qi.call(wu,e)?!1:tb.test(e)?xu[e]=!0:(wu[e]=!0,!1)}function fo(e,t,r){if(rb(t))if(r===null)e.removeAttribute(t);else{switch(typeof r){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var n=t.toLowerCase().slice(0,5);if(n!=="data-"&&n!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,""+r)}}function mo(e,t,r){if(r===null)e.removeAttribute(t);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+r)}}function Jt(e,t,r,n){if(n===null)e.removeAttribute(r);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(r);return}e.setAttributeNS(t,r,""+n)}}function zt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function ku(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function nb(e,t,r){var n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var a=n.get,o=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return a.call(this)},set:function(l){r=""+l,o.call(this,l)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(l){r=""+l},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function tl(e){if(!e._valueTracker){var t=ku(e)?"checked":"value";e._valueTracker=nb(e,t,""+e[t])}}function Su(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var r=t.getValue(),n="";return e&&(n=ku(e)?e.checked?"true":"false":e.value),e=n,e!==r?(t.setValue(e),!0):!1}function go(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var ab=/[\n"\\]/g;function Ot(e){return e.replace(ab,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function rl(e,t,r,n,a,o,l,u){e.name="",l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"?e.type=l:e.removeAttribute("type"),t!=null?l==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+zt(t)):e.value!==""+zt(t)&&(e.value=""+zt(t)):l!=="submit"&&l!=="reset"||e.removeAttribute("value"),t!=null?nl(e,l,zt(t)):r!=null?nl(e,l,zt(r)):n!=null&&e.removeAttribute("value"),a==null&&o!=null&&(e.defaultChecked=!!o),a!=null&&(e.checked=a&&typeof a!="function"&&typeof a!="symbol"),u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"?e.name=""+zt(u):e.removeAttribute("name")}function _u(e,t,r,n,a,o,l,u){if(o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"&&(e.type=o),t!=null||r!=null){if(!(o!=="submit"&&o!=="reset"||t!=null)){tl(e);return}r=r!=null?""+zt(r):"",t=t!=null?""+zt(t):r,u||t===e.value||(e.value=t),e.defaultValue=t}n=n??a,n=typeof n!="function"&&typeof n!="symbol"&&!!n,e.checked=u?e.checked:!!n,e.defaultChecked=!!n,l!=null&&typeof l!="function"&&typeof l!="symbol"&&typeof l!="boolean"&&(e.name=l),tl(e)}function nl(e,t,r){t==="number"&&go(e.ownerDocument)===e||e.defaultValue===""+r||(e.defaultValue=""+r)}function kn(e,t,r,n){if(e=e.options,t){t={};for(var a=0;a<r.length;a++)t["$"+r[a]]=!0;for(r=0;r<e.length;r++)a=t.hasOwnProperty("$"+e[r].value),e[r].selected!==a&&(e[r].selected=a),a&&n&&(e[r].defaultSelected=!0)}else{for(r=""+zt(r),t=null,a=0;a<e.length;a++){if(e[a].value===r){e[a].selected=!0,n&&(e[a].defaultSelected=!0);return}t!==null||e[a].disabled||(t=e[a])}t!==null&&(t.selected=!0)}}function zu(e,t,r){if(t!=null&&(t=""+zt(t),t!==e.value&&(e.value=t),r==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=r!=null?""+zt(r):""}function Cu(e,t,r,n){if(t==null){if(n!=null){if(r!=null)throw Error(d(92));if(D(n)){if(1<n.length)throw Error(d(93));n=n[0]}r=n}r==null&&(r=""),t=r}r=zt(t),e.defaultValue=r,n=e.textContent,n===r&&n!==""&&n!==null&&(e.value=n),tl(e)}function Sn(e,t){if(t){var r=e.firstChild;if(r&&r===e.lastChild&&r.nodeType===3){r.nodeValue=t;return}}e.textContent=t}var ob=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Eu(e,t,r){var n=t.indexOf("--")===0;r==null||typeof r=="boolean"||r===""?n?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":n?e.setProperty(t,r):typeof r!="number"||r===0||ob.has(t)?t==="float"?e.cssFloat=r:e[t]=(""+r).trim():e[t]=r+"px"}function Nu(e,t,r){if(t!=null&&typeof t!="object")throw Error(d(62));if(e=e.style,r!=null){for(var n in r)!r.hasOwnProperty(n)||t!=null&&t.hasOwnProperty(n)||(n.indexOf("--")===0?e.setProperty(n,""):n==="float"?e.cssFloat="":e[n]="");for(var a in t)n=t[a],t.hasOwnProperty(a)&&r[a]!==n&&Eu(e,a,n)}else for(var o in t)t.hasOwnProperty(o)&&Eu(e,o,t[o])}function al(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var ib=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),lb=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function ho(e){return lb.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Zt(){}var ol=null;function il(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var _n=null,zn=null;function Pu(e){var t=yn(e);if(t&&(e=t.stateNode)){var r=e[st]||null;e:switch(e=t.stateNode,t.type){case"input":if(rl(e,r.value,r.defaultValue,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name),t=r.name,r.type==="radio"&&t!=null){for(r=e;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll('input[name="'+Ot(""+t)+'"][type="radio"]'),t=0;t<r.length;t++){var n=r[t];if(n!==e&&n.form===e.form){var a=n[st]||null;if(!a)throw Error(d(90));rl(n,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<r.length;t++)n=r[t],n.form===e.form&&Su(n)}break e;case"textarea":zu(e,r.value,r.defaultValue);break e;case"select":t=r.value,t!=null&&kn(e,!!r.multiple,t,!1)}}}var ll=!1;function ju(e,t,r){if(ll)return e(t,r);ll=!0;try{var n=e(t);return n}finally{if(ll=!1,(_n!==null||zn!==null)&&(oi(),_n&&(t=_n,e=zn,zn=_n=null,Pu(t),e)))for(t=0;t<e.length;t++)Pu(e[t])}}function da(e,t){var r=e.stateNode;if(r===null)return null;var n=r[st]||null;if(n===null)return null;r=n[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(n=!n.disabled)||(e=e.type,n=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!n;break e;default:e=!1}if(e)return null;if(r&&typeof r!="function")throw Error(d(231,t,typeof r));return r}var er=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),sl=!1;if(er)try{Cn={},Object.defineProperty(Cn,"passive",{get:function(){sl=!0}}),window.addEventListener("test",Cn,Cn),window.removeEventListener("test",Cn,Cn)}catch{sl=!1}var Cn,xr=null,cl=null,bo=null;function Lu(){if(bo)return bo;var e,t=cl,r=t.length,n,a="value"in xr?xr.value:xr.textContent,o=a.length;for(e=0;e<r&&t[e]===a[e];e++);var l=r-e;for(n=1;n<=l&&t[r-n]===a[o-n];n++);return bo=a.slice(e,1<n?1-n:void 0)}function vo(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function yo(){return!0}function Tu(){return!1}function ct(e){function t(r,n,a,o,l){this._reactName=r,this._targetInst=a,this.type=n,this.nativeEvent=o,this.target=l,this.currentTarget=null;for(var u in e)e.hasOwnProperty(u)&&(r=e[u],this[u]=r?r(o):o[u]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?yo:Tu,this.isPropagationStopped=Tu,this}return O(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var r=this.nativeEvent;r&&(r.preventDefault?r.preventDefault():typeof r.returnValue!="unknown"&&(r.returnValue=!1),this.isDefaultPrevented=yo)},stopPropagation:function(){var r=this.nativeEvent;r&&(r.stopPropagation?r.stopPropagation():typeof r.cancelBubble!="unknown"&&(r.cancelBubble=!0),this.isPropagationStopped=yo)},persist:function(){},isPersistent:yo}),t}var Zr={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},wo=ct(Zr),pa=O({},Zr,{view:0,detail:0}),sb=ct(pa),ul,dl,fa,xo=O({},pa,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:fl,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==fa&&(fa&&e.type==="mousemove"?(ul=e.screenX-fa.screenX,dl=e.screenY-fa.screenY):dl=ul=0,fa=e),ul)},movementY:function(e){return"movementY"in e?e.movementY:dl}}),Au=ct(xo),cb=O({},xo,{dataTransfer:0}),ub=ct(cb),db=O({},pa,{relatedTarget:0}),pl=ct(db),pb=O({},Zr,{animationName:0,elapsedTime:0,pseudoElement:0}),fb=ct(pb),mb=O({},Zr,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),gb=ct(mb),hb=O({},Zr,{data:0}),Ru=ct(hb),bb={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},vb={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},yb={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function wb(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=yb[e])?!!t[e]:!1}function fl(){return wb}var xb=O({},pa,{key:function(e){if(e.key){var t=bb[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=vo(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?vb[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:fl,charCode:function(e){return e.type==="keypress"?vo(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?vo(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),kb=ct(xb),Sb=O({},xo,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Ou=ct(Sb),_b=O({},pa,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:fl}),zb=ct(_b),Cb=O({},Zr,{propertyName:0,elapsedTime:0,pseudoElement:0}),Eb=ct(Cb),Nb=O({},xo,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Pb=ct(Nb),jb=O({},Zr,{newState:0,oldState:0}),Lb=ct(jb),Tb=[9,13,27,32],ml=er&&"CompositionEvent"in window,ma=null;er&&"documentMode"in document&&(ma=document.documentMode);var Ab=er&&"TextEvent"in window&&!ma,Mu=er&&(!ml||ma&&8<ma&&11>=ma),Du=" ",Fu=!1;function Iu(e,t){switch(e){case"keyup":return Tb.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Uu(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var En=!1;function Rb(e,t){switch(e){case"compositionend":return Uu(t);case"keypress":return t.which!==32?null:(Fu=!0,Du);case"textInput":return e=t.data,e===Du&&Fu?null:e;default:return null}}function Ob(e,t){if(En)return e==="compositionend"||!ml&&Iu(e,t)?(e=Lu(),bo=cl=xr=null,En=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Mu&&t.locale!=="ko"?null:t.data;default:return null}}var Mb={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function $u(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Mb[e.type]:t==="textarea"}function Hu(e,t,r,n){_n?zn?zn.push(n):zn=[n]:_n=n,t=mi(t,"onChange"),0<t.length&&(r=new wo("onChange","change",null,r,n),e.push({event:r,listeners:t}))}var ga=null,ha=null;function Db(e){Cf(e,0)}function ko(e){var t=ua(e);if(Su(t))return e}function Vu(e,t){if(e==="change")return t}var qu=!1;er&&(er?(So="oninput"in document,So||(hl=document.createElement("div"),hl.setAttribute("oninput","return;"),So=typeof hl.oninput=="function"),gl=So):gl=!1,qu=gl&&(!document.documentMode||9<document.documentMode));var gl,So,hl;function Bu(){ga&&(ga.detachEvent("onpropertychange",Wu),ha=ga=null)}function Wu(e){if(e.propertyName==="value"&&ko(ha)){var t=[];Hu(t,ha,e,il(e)),ju(Db,t)}}function Fb(e,t,r){e==="focusin"?(Bu(),ga=t,ha=r,ga.attachEvent("onpropertychange",Wu)):e==="focusout"&&Bu()}function Ib(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return ko(ha)}function Ub(e,t){if(e==="click")return ko(t)}function $b(e,t){if(e==="input"||e==="change")return ko(t)}function Hb(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var vt=typeof Object.is=="function"?Object.is:Hb;function ba(e,t){if(vt(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var r=Object.keys(e),n=Object.keys(t);if(r.length!==n.length)return!1;for(n=0;n<r.length;n++){var a=r[n];if(!Qi.call(t,a)||!vt(e[a],t[a]))return!1}return!0}function Qu(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Ku(e,t){var r=Qu(e);e=0;for(var n;r;){if(r.nodeType===3){if(n=e+r.textContent.length,e<=t&&n>=t)return{node:r,offset:t-e};e=n}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=Qu(r)}}function Yu(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Yu(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Xu(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=go(e.document);t instanceof e.HTMLIFrameElement;){try{var r=typeof t.contentWindow.location.href=="string"}catch{r=!1}if(r)e=t.contentWindow;else break;t=go(e.document)}return t}function bl(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var Vb=er&&"documentMode"in document&&11>=document.documentMode,Nn=null,vl=null,va=null,yl=!1;function Gu(e,t,r){var n=r.window===r?r.document:r.nodeType===9?r:r.ownerDocument;yl||Nn==null||Nn!==go(n)||(n=Nn,"selectionStart"in n&&bl(n)?n={start:n.selectionStart,end:n.selectionEnd}:(n=(n.ownerDocument&&n.ownerDocument.defaultView||window).getSelection(),n={anchorNode:n.anchorNode,anchorOffset:n.anchorOffset,focusNode:n.focusNode,focusOffset:n.focusOffset}),va&&ba(va,n)||(va=n,n=mi(vl,"onSelect"),0<n.length&&(t=new wo("onSelect","select",null,t,r),e.push({event:t,listeners:n}),t.target=Nn)))}function en(e,t){var r={};return r[e.toLowerCase()]=t.toLowerCase(),r["Webkit"+e]="webkit"+t,r["Moz"+e]="moz"+t,r}var Pn={animationend:en("Animation","AnimationEnd"),animationiteration:en("Animation","AnimationIteration"),animationstart:en("Animation","AnimationStart"),transitionrun:en("Transition","TransitionRun"),transitionstart:en("Transition","TransitionStart"),transitioncancel:en("Transition","TransitionCancel"),transitionend:en("Transition","TransitionEnd")},wl={},Ju={};er&&(Ju=document.createElement("div").style,"AnimationEvent"in window||(delete Pn.animationend.animation,delete Pn.animationiteration.animation,delete Pn.animationstart.animation),"TransitionEvent"in window||delete Pn.transitionend.transition);function tn(e){if(wl[e])return wl[e];if(!Pn[e])return e;var t=Pn[e],r;for(r in t)if(t.hasOwnProperty(r)&&r in Ju)return wl[e]=t[r];return e}var Zu=tn("animationend"),ed=tn("animationiteration"),td=tn("animationstart"),qb=tn("transitionrun"),Bb=tn("transitionstart"),Wb=tn("transitioncancel"),rd=tn("transitionend"),nd=new Map,xl="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");xl.push("scrollEnd");function Mt(e,t){nd.set(e,t),Jr(t,[e])}var _o=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Ct=[],jn=0,kl=0;function zo(){for(var e=jn,t=kl=jn=0;t<e;){var r=Ct[t];Ct[t++]=null;var n=Ct[t];Ct[t++]=null;var a=Ct[t];Ct[t++]=null;var o=Ct[t];if(Ct[t++]=null,n!==null&&a!==null){var l=n.pending;l===null?a.next=a:(a.next=l.next,l.next=a),n.pending=a}o!==0&&ad(r,a,o)}}function Co(e,t,r,n){Ct[jn++]=e,Ct[jn++]=t,Ct[jn++]=r,Ct[jn++]=n,kl|=n,e.lanes|=n,e=e.alternate,e!==null&&(e.lanes|=n)}function Sl(e,t,r,n){return Co(e,t,r,n),Eo(e)}function rn(e,t){return Co(e,null,null,t),Eo(e)}function ad(e,t,r){e.lanes|=r;var n=e.alternate;n!==null&&(n.lanes|=r);for(var a=!1,o=e.return;o!==null;)o.childLanes|=r,n=o.alternate,n!==null&&(n.childLanes|=r),o.tag===22&&(e=o.stateNode,e===null||e._visibility&1||(a=!0)),e=o,o=o.return;return e.tag===3?(o=e.stateNode,a&&t!==null&&(a=31-bt(r),e=o.hiddenUpdates,n=e[a],n===null?e[a]=[t]:n.push(t),t.lane=r|536870912),o):null}function Eo(e){if(50<Ua)throw Ua=0,Ts=null,Error(d(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Ln={};function Qb(e,t,r,n){this.tag=e,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=n,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function yt(e,t,r,n){return new Qb(e,t,r,n)}function _l(e){return e=e.prototype,!(!e||!e.isReactComponent)}function tr(e,t){var r=e.alternate;return r===null?(r=yt(e.tag,t,e.key,e.mode),r.elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=t,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=e.flags&65011712,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,t=e.dependencies,r.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r.refCleanup=e.refCleanup,r}function od(e,t){e.flags&=65011714;var r=e.alternate;return r===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=r.childLanes,e.lanes=r.lanes,e.child=r.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=r.memoizedProps,e.memoizedState=r.memoizedState,e.updateQueue=r.updateQueue,e.type=r.type,t=r.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function No(e,t,r,n,a,o){var l=0;if(n=e,typeof e=="function")_l(e)&&(l=1);else if(typeof e=="string")l=X0(e,r,$.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case Ne:return e=yt(31,r,t,a),e.elementType=Ne,e.lanes=o,e;case G:return nn(r.children,a,o,t);case ze:l=8,a|=24;break;case pe:return e=yt(12,r,t,a|2),e.elementType=pe,e.lanes=o,e;case be:return e=yt(13,r,t,a),e.elementType=be,e.lanes=o,e;case w:return e=yt(19,r,t,a),e.elementType=w,e.lanes=o,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case oe:l=10;break e;case Ue:l=9;break e;case ye:l=11;break e;case E:l=14;break e;case B:l=16,n=null;break e}l=29,r=Error(d(130,e===null?"null":typeof e,"")),n=null}return t=yt(l,r,t,a),t.elementType=e,t.type=n,t.lanes=o,t}function nn(e,t,r,n){return e=yt(7,e,n,t),e.lanes=r,e}function zl(e,t,r){return e=yt(6,e,null,t),e.lanes=r,e}function id(e){var t=yt(18,null,null,0);return t.stateNode=e,t}function Cl(e,t,r){return t=yt(4,e.children!==null?e.children:[],e.key,t),t.lanes=r,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var ld=new WeakMap;function Et(e,t){if(typeof e=="object"&&e!==null){var r=ld.get(e);return r!==void 0?r:(t={value:e,source:t,stack:lu(t)},ld.set(e,t),t)}return{value:e,source:t,stack:lu(t)}}var Tn=[],An=0,Po=null,ya=0,Nt=[],Pt=0,kr=null,qt=1,Bt="";function rr(e,t){Tn[An++]=ya,Tn[An++]=Po,Po=e,ya=t}function sd(e,t,r){Nt[Pt++]=qt,Nt[Pt++]=Bt,Nt[Pt++]=kr,kr=e;var n=qt;e=Bt;var a=32-bt(n)-1;n&=~(1<<a),r+=1;var o=32-bt(t)+a;if(30<o){var l=a-a%5;o=(n&(1<<l)-1).toString(32),n>>=l,a-=l,qt=1<<32-bt(t)+a|r<<a|n,Bt=o+e}else qt=1<<o|r<<a|n,Bt=e}function El(e){e.return!==null&&(rr(e,1),sd(e,1,0))}function Nl(e){for(;e===Po;)Po=Tn[--An],Tn[An]=null,ya=Tn[--An],Tn[An]=null;for(;e===kr;)kr=Nt[--Pt],Nt[Pt]=null,Bt=Nt[--Pt],Nt[Pt]=null,qt=Nt[--Pt],Nt[Pt]=null}function cd(e,t){Nt[Pt++]=qt,Nt[Pt++]=Bt,Nt[Pt++]=kr,qt=t.id,Bt=t.overflow,kr=e}var Ze=null,Pe=null,ue=!1,Sr=null,jt=!1,Pl=Error(d(519));function _r(e){var t=Error(d(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw wa(Et(t,e)),Pl}function ud(e){var t=e.stateNode,r=e.type,n=e.memoizedProps;switch(t[Je]=e,t[st]=n,r){case"dialog":ae("cancel",t),ae("close",t);break;case"iframe":case"object":case"embed":ae("load",t);break;case"video":case"audio":for(r=0;r<Ha.length;r++)ae(Ha[r],t);break;case"source":ae("error",t);break;case"img":case"image":case"link":ae("error",t),ae("load",t);break;case"details":ae("toggle",t);break;case"input":ae("invalid",t),_u(t,n.value,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name,!0);break;case"select":ae("invalid",t);break;case"textarea":ae("invalid",t),Cu(t,n.value,n.defaultValue,n.children)}r=n.children,typeof r!="string"&&typeof r!="number"&&typeof r!="bigint"||t.textContent===""+r||n.suppressHydrationWarning===!0||jf(t.textContent,r)?(n.popover!=null&&(ae("beforetoggle",t),ae("toggle",t)),n.onScroll!=null&&ae("scroll",t),n.onScrollEnd!=null&&ae("scrollend",t),n.onClick!=null&&(t.onclick=Zt),t=!0):t=!1,t||_r(e,!0)}function dd(e){for(Ze=e.return;Ze;)switch(Ze.tag){case 5:case 31:case 13:jt=!1;return;case 27:case 3:jt=!0;return;default:Ze=Ze.return}}function Rn(e){if(e!==Ze)return!1;if(!ue)return dd(e),ue=!0,!1;var t=e.tag,r;if((r=t!==3&&t!==27)&&((r=t===5)&&(r=e.type,r=!(r!=="form"&&r!=="button")||Bs(e.type,e.memoizedProps)),r=!r),r&&Pe&&_r(e),dd(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(317));Pe=If(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(317));Pe=If(e)}else t===27?(t=Pe,Fr(e.type)?(e=Xs,Xs=null,Pe=e):Pe=t):Pe=Ze?Lt(e.stateNode.nextSibling):null;return!0}function an(){Pe=Ze=null,ue=!1}function jl(){var e=Sr;return e!==null&&(ft===null?ft=e:ft.push.apply(ft,e),Sr=null),e}function wa(e){Sr===null?Sr=[e]:Sr.push(e)}var Ll=g(null),on=null,nr=null;function zr(e,t,r){F(Ll,t._currentValue),t._currentValue=r}function ar(e){e._currentValue=Ll.current,A(Ll)}function Tl(e,t,r){for(;e!==null;){var n=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,n!==null&&(n.childLanes|=t)):n!==null&&(n.childLanes&t)!==t&&(n.childLanes|=t),e===r)break;e=e.return}}function Al(e,t,r,n){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){var l=a.child;o=o.firstContext;e:for(;o!==null;){var u=o;o=a;for(var f=0;f<t.length;f++)if(u.context===t[f]){o.lanes|=r,u=o.alternate,u!==null&&(u.lanes|=r),Tl(o.return,r,e),n||(l=null);break e}o=u.next}}else if(a.tag===18){if(l=a.return,l===null)throw Error(d(341));l.lanes|=r,o=l.alternate,o!==null&&(o.lanes|=r),Tl(l,r,e),l=null}else l=a.child;if(l!==null)l.return=a;else for(l=a;l!==null;){if(l===e){l=null;break}if(a=l.sibling,a!==null){a.return=l.return,l=a;break}l=l.return}a=l}}function On(e,t,r,n){e=null;for(var a=t,o=!1;a!==null;){if(!o){if((a.flags&524288)!==0)o=!0;else if((a.flags&262144)!==0)break}if(a.tag===10){var l=a.alternate;if(l===null)throw Error(d(387));if(l=l.memoizedProps,l!==null){var u=a.type;vt(a.pendingProps.value,l.value)||(e!==null?e.push(u):e=[u])}}else if(a===me.current){if(l=a.alternate,l===null)throw Error(d(387));l.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e!==null?e.push(Qa):e=[Qa])}a=a.return}e!==null&&Al(t,e,r,n),t.flags|=262144}function jo(e){for(e=e.firstContext;e!==null;){if(!vt(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function ln(e){on=e,nr=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function et(e){return pd(on,e)}function Lo(e,t){return on===null&&ln(e),pd(e,t)}function pd(e,t){var r=t._currentValue;if(t={context:t,memoizedValue:r,next:null},nr===null){if(e===null)throw Error(d(308));nr=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else nr=nr.next=t;return r}var Kb=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(r,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(r){return r()})}},Yb=s.unstable_scheduleCallback,Xb=s.unstable_NormalPriority,$e={$$typeof:oe,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Rl(){return{controller:new Kb,data:new Map,refCount:0}}function xa(e){e.refCount--,e.refCount===0&&Yb(Xb,function(){e.controller.abort()})}var ka=null,Ol=0,Mn=0,Dn=null;function Gb(e,t){if(ka===null){var r=ka=[];Ol=0,Mn=Fs(),Dn={status:"pending",value:void 0,then:function(n){r.push(n)}}}return Ol++,t.then(fd,fd),t}function fd(){if(--Ol===0&&ka!==null){Dn!==null&&(Dn.status="fulfilled");var e=ka;ka=null,Mn=0,Dn=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Jb(e,t){var r=[],n={status:"pending",value:null,reason:null,then:function(a){r.push(a)}};return e.then(function(){n.status="fulfilled",n.value=t;for(var a=0;a<r.length;a++)(0,r[a])(t)},function(a){for(n.status="rejected",n.reason=a,a=0;a<r.length;a++)(0,r[a])(void 0)}),n}var md=M.S;M.S=function(e,t){Gp=gt(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&Gb(e,t),md!==null&&md(e,t)};var sn=g(null);function Ml(){var e=sn.current;return e!==null?e:Ce.pooledCache}function To(e,t){t===null?F(sn,sn.current):F(sn,t.pool)}function gd(){var e=Ml();return e===null?null:{parent:$e._currentValue,pool:e}}var Fn=Error(d(460)),Dl=Error(d(474)),Ao=Error(d(542)),Ro={then:function(){}};function hd(e){return e=e.status,e==="fulfilled"||e==="rejected"}function bd(e,t,r){switch(r=e[r],r===void 0?e.push(t):r!==t&&(t.then(Zt,Zt),t=r),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,yd(e),e;default:if(typeof t.status=="string")t.then(Zt,Zt);else{if(e=Ce,e!==null&&100<e.shellSuspendCounter)throw Error(d(482));e=t,e.status="pending",e.then(function(n){if(t.status==="pending"){var a=t;a.status="fulfilled",a.value=n}},function(n){if(t.status==="pending"){var a=t;a.status="rejected",a.reason=n}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,yd(e),e}throw un=t,Fn}}function cn(e){try{var t=e._init;return t(e._payload)}catch(r){throw r!==null&&typeof r=="object"&&typeof r.then=="function"?(un=r,Fn):r}}var un=null;function vd(){if(un===null)throw Error(d(459));var e=un;return un=null,e}function yd(e){if(e===Fn||e===Ao)throw Error(d(483))}var In=null,Sa=0;function Oo(e){var t=Sa;return Sa+=1,In===null&&(In=[]),bd(In,e,t)}function _a(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Mo(e,t){throw t.$$typeof===re?Error(d(525)):(e=Object.prototype.toString.call(t),Error(d(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function wd(e){function t(h,m){if(e){var b=h.deletions;b===null?(h.deletions=[m],h.flags|=16):b.push(m)}}function r(h,m){if(!e)return null;for(;m!==null;)t(h,m),m=m.sibling;return null}function n(h){for(var m=new Map;h!==null;)h.key!==null?m.set(h.key,h):m.set(h.index,h),h=h.sibling;return m}function a(h,m){return h=tr(h,m),h.index=0,h.sibling=null,h}function o(h,m,b){return h.index=b,e?(b=h.alternate,b!==null?(b=b.index,b<m?(h.flags|=67108866,m):b):(h.flags|=67108866,m)):(h.flags|=1048576,m)}function l(h){return e&&h.alternate===null&&(h.flags|=67108866),h}function u(h,m,b,j){return m===null||m.tag!==6?(m=zl(b,h.mode,j),m.return=h,m):(m=a(m,b),m.return=h,m)}function f(h,m,b,j){var Q=b.type;return Q===G?P(h,m,b.props.children,j,b.key):m!==null&&(m.elementType===Q||typeof Q=="object"&&Q!==null&&Q.$$typeof===B&&cn(Q)===m.type)?(m=a(m,b.props),_a(m,b),m.return=h,m):(m=No(b.type,b.key,b.props,null,h.mode,j),_a(m,b),m.return=h,m)}function v(h,m,b,j){return m===null||m.tag!==4||m.stateNode.containerInfo!==b.containerInfo||m.stateNode.implementation!==b.implementation?(m=Cl(b,h.mode,j),m.return=h,m):(m=a(m,b.children||[]),m.return=h,m)}function P(h,m,b,j,Q){return m===null||m.tag!==7?(m=nn(b,h.mode,j,Q),m.return=h,m):(m=a(m,b),m.return=h,m)}function T(h,m,b){if(typeof m=="string"&&m!==""||typeof m=="number"||typeof m=="bigint")return m=zl(""+m,h.mode,b),m.return=h,m;if(typeof m=="object"&&m!==null){switch(m.$$typeof){case se:return b=No(m.type,m.key,m.props,null,h.mode,b),_a(b,m),b.return=h,b;case K:return m=Cl(m,h.mode,b),m.return=h,m;case B:return m=cn(m),T(h,m,b)}if(D(m)||lt(m))return m=nn(m,h.mode,b,null),m.return=h,m;if(typeof m.then=="function")return T(h,Oo(m),b);if(m.$$typeof===oe)return T(h,Lo(h,m),b);Mo(h,m)}return null}function y(h,m,b,j){var Q=m!==null?m.key:null;if(typeof b=="string"&&b!==""||typeof b=="number"||typeof b=="bigint")return Q!==null?null:u(h,m,""+b,j);if(typeof b=="object"&&b!==null){switch(b.$$typeof){case se:return b.key===Q?f(h,m,b,j):null;case K:return b.key===Q?v(h,m,b,j):null;case B:return b=cn(b),y(h,m,b,j)}if(D(b)||lt(b))return Q!==null?null:P(h,m,b,j,null);if(typeof b.then=="function")return y(h,m,Oo(b),j);if(b.$$typeof===oe)return y(h,m,Lo(h,b),j);Mo(h,b)}return null}function _(h,m,b,j,Q){if(typeof j=="string"&&j!==""||typeof j=="number"||typeof j=="bigint")return h=h.get(b)||null,u(m,h,""+j,Q);if(typeof j=="object"&&j!==null){switch(j.$$typeof){case se:return h=h.get(j.key===null?b:j.key)||null,f(m,h,j,Q);case K:return h=h.get(j.key===null?b:j.key)||null,v(m,h,j,Q);case B:return j=cn(j),_(h,m,b,j,Q)}if(D(j)||lt(j))return h=h.get(b)||null,P(m,h,j,Q,null);if(typeof j.then=="function")return _(h,m,b,Oo(j),Q);if(j.$$typeof===oe)return _(h,m,b,Lo(m,j),Q);Mo(m,j)}return null}function q(h,m,b,j){for(var Q=null,ge=null,W=m,ee=m=0,le=null;W!==null&&ee<b.length;ee++){W.index>ee?(le=W,W=null):le=W.sibling;var he=y(h,W,b[ee],j);if(he===null){W===null&&(W=le);break}e&&W&&he.alternate===null&&t(h,W),m=o(he,m,ee),ge===null?Q=he:ge.sibling=he,ge=he,W=le}if(ee===b.length)return r(h,W),ue&&rr(h,ee),Q;if(W===null){for(;ee<b.length;ee++)W=T(h,b[ee],j),W!==null&&(m=o(W,m,ee),ge===null?Q=W:ge.sibling=W,ge=W);return ue&&rr(h,ee),Q}for(W=n(W);ee<b.length;ee++)le=_(W,h,ee,b[ee],j),le!==null&&(e&&le.alternate!==null&&W.delete(le.key===null?ee:le.key),m=o(le,m,ee),ge===null?Q=le:ge.sibling=le,ge=le);return e&&W.forEach(function(Vr){return t(h,Vr)}),ue&&rr(h,ee),Q}function X(h,m,b,j){if(b==null)throw Error(d(151));for(var Q=null,ge=null,W=m,ee=m=0,le=null,he=b.next();W!==null&&!he.done;ee++,he=b.next()){W.index>ee?(le=W,W=null):le=W.sibling;var Vr=y(h,W,he.value,j);if(Vr===null){W===null&&(W=le);break}e&&W&&Vr.alternate===null&&t(h,W),m=o(Vr,m,ee),ge===null?Q=Vr:ge.sibling=Vr,ge=Vr,W=le}if(he.done)return r(h,W),ue&&rr(h,ee),Q;if(W===null){for(;!he.done;ee++,he=b.next())he=T(h,he.value,j),he!==null&&(m=o(he,m,ee),ge===null?Q=he:ge.sibling=he,ge=he);return ue&&rr(h,ee),Q}for(W=n(W);!he.done;ee++,he=b.next())he=_(W,h,ee,he.value,j),he!==null&&(e&&he.alternate!==null&&W.delete(he.key===null?ee:he.key),m=o(he,m,ee),ge===null?Q=he:ge.sibling=he,ge=he);return e&&W.forEach(function(lv){return t(h,lv)}),ue&&rr(h,ee),Q}function _e(h,m,b,j){if(typeof b=="object"&&b!==null&&b.type===G&&b.key===null&&(b=b.props.children),typeof b=="object"&&b!==null){switch(b.$$typeof){case se:e:{for(var Q=b.key;m!==null;){if(m.key===Q){if(Q=b.type,Q===G){if(m.tag===7){r(h,m.sibling),j=a(m,b.props.children),j.return=h,h=j;break e}}else if(m.elementType===Q||typeof Q=="object"&&Q!==null&&Q.$$typeof===B&&cn(Q)===m.type){r(h,m.sibling),j=a(m,b.props),_a(j,b),j.return=h,h=j;break e}r(h,m);break}else t(h,m);m=m.sibling}b.type===G?(j=nn(b.props.children,h.mode,j,b.key),j.return=h,h=j):(j=No(b.type,b.key,b.props,null,h.mode,j),_a(j,b),j.return=h,h=j)}return l(h);case K:e:{for(Q=b.key;m!==null;){if(m.key===Q)if(m.tag===4&&m.stateNode.containerInfo===b.containerInfo&&m.stateNode.implementation===b.implementation){r(h,m.sibling),j=a(m,b.children||[]),j.return=h,h=j;break e}else{r(h,m);break}else t(h,m);m=m.sibling}j=Cl(b,h.mode,j),j.return=h,h=j}return l(h);case B:return b=cn(b),_e(h,m,b,j)}if(D(b))return q(h,m,b,j);if(lt(b)){if(Q=lt(b),typeof Q!="function")throw Error(d(150));return b=Q.call(b),X(h,m,b,j)}if(typeof b.then=="function")return _e(h,m,Oo(b),j);if(b.$$typeof===oe)return _e(h,m,Lo(h,b),j);Mo(h,b)}return typeof b=="string"&&b!==""||typeof b=="number"||typeof b=="bigint"?(b=""+b,m!==null&&m.tag===6?(r(h,m.sibling),j=a(m,b),j.return=h,h=j):(r(h,m),j=zl(b,h.mode,j),j.return=h,h=j),l(h)):r(h,m)}return function(h,m,b,j){try{Sa=0;var Q=_e(h,m,b,j);return In=null,Q}catch(W){if(W===Fn||W===Ao)throw W;var ge=yt(29,W,null,h.mode);return ge.lanes=j,ge.return=h,ge}}}var dn=wd(!0),xd=wd(!1),Cr=!1;function Fl(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Il(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Er(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Nr(e,t,r){var n=e.updateQueue;if(n===null)return null;if(n=n.shared,(ve&2)!==0){var a=n.pending;return a===null?t.next=t:(t.next=a.next,a.next=t),n.pending=t,t=Eo(e),ad(e,null,r),t}return Co(e,n,t,r),Eo(e)}function za(e,t,r){if(t=t.updateQueue,t!==null&&(t=t.shared,(r&4194048)!==0)){var n=t.lanes;n&=e.pendingLanes,r|=n,t.lanes=r,fu(e,r)}}function Ul(e,t){var r=e.updateQueue,n=e.alternate;if(n!==null&&(n=n.updateQueue,r===n)){var a=null,o=null;if(r=r.firstBaseUpdate,r!==null){do{var l={lane:r.lane,tag:r.tag,payload:r.payload,callback:null,next:null};o===null?a=o=l:o=o.next=l,r=r.next}while(r!==null);o===null?a=o=t:o=o.next=t}else a=o=t;r={baseState:n.baseState,firstBaseUpdate:a,lastBaseUpdate:o,shared:n.shared,callbacks:n.callbacks},e.updateQueue=r;return}e=r.lastBaseUpdate,e===null?r.firstBaseUpdate=t:e.next=t,r.lastBaseUpdate=t}var $l=!1;function Ca(){if($l){var e=Dn;if(e!==null)throw e}}function Ea(e,t,r,n){$l=!1;var a=e.updateQueue;Cr=!1;var o=a.firstBaseUpdate,l=a.lastBaseUpdate,u=a.shared.pending;if(u!==null){a.shared.pending=null;var f=u,v=f.next;f.next=null,l===null?o=v:l.next=v,l=f;var P=e.alternate;P!==null&&(P=P.updateQueue,u=P.lastBaseUpdate,u!==l&&(u===null?P.firstBaseUpdate=v:u.next=v,P.lastBaseUpdate=f))}if(o!==null){var T=a.baseState;l=0,P=v=f=null,u=o;do{var y=u.lane&-536870913,_=y!==u.lane;if(_?(ie&y)===y:(n&y)===y){y!==0&&y===Mn&&($l=!0),P!==null&&(P=P.next={lane:0,tag:u.tag,payload:u.payload,callback:null,next:null});e:{var q=e,X=u;y=t;var _e=r;switch(X.tag){case 1:if(q=X.payload,typeof q=="function"){T=q.call(_e,T,y);break e}T=q;break e;case 3:q.flags=q.flags&-65537|128;case 0:if(q=X.payload,y=typeof q=="function"?q.call(_e,T,y):q,y==null)break e;T=O({},T,y);break e;case 2:Cr=!0}}y=u.callback,y!==null&&(e.flags|=64,_&&(e.flags|=8192),_=a.callbacks,_===null?a.callbacks=[y]:_.push(y))}else _={lane:y,tag:u.tag,payload:u.payload,callback:u.callback,next:null},P===null?(v=P=_,f=T):P=P.next=_,l|=y;if(u=u.next,u===null){if(u=a.shared.pending,u===null)break;_=u,u=_.next,_.next=null,a.lastBaseUpdate=_,a.shared.pending=null}}while(!0);P===null&&(f=T),a.baseState=f,a.firstBaseUpdate=v,a.lastBaseUpdate=P,o===null&&(a.shared.lanes=0),Ar|=l,e.lanes=l,e.memoizedState=T}}function kd(e,t){if(typeof e!="function")throw Error(d(191,e));e.call(t)}function Sd(e,t){var r=e.callbacks;if(r!==null)for(e.callbacks=null,e=0;e<r.length;e++)kd(r[e],t)}var Un=g(null),Do=g(0);function _d(e,t){e=fr,F(Do,e),F(Un,t),fr=e|t.baseLanes}function Hl(){F(Do,fr),F(Un,Un.current)}function Vl(){fr=Do.current,A(Un),A(Do)}var wt=g(null),Dt=null;function Pr(e){var t=e.alternate;F(De,De.current&1),F(wt,e),Dt===null&&(t===null||Un.current!==null||t.memoizedState!==null)&&(Dt=e)}function ql(e){F(De,De.current),F(wt,e),Dt===null&&(Dt=e)}function zd(e){e.tag===22?(F(De,De.current),F(wt,e),Dt===null&&(Dt=e)):jr(e)}function jr(){F(De,De.current),F(wt,wt.current)}function xt(e){A(wt),Dt===e&&(Dt=null),A(De)}var De=g(0);function Fo(e){for(var t=e;t!==null;){if(t.tag===13){var r=t.memoizedState;if(r!==null&&(r=r.dehydrated,r===null||Ks(r)||Ys(r)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder==="forwards"||t.memoizedProps.revealOrder==="backwards"||t.memoizedProps.revealOrder==="unstable_legacy-backwards"||t.memoizedProps.revealOrder==="together")){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var or=0,Z=null,ke=null,He=null,Io=!1,$n=!1,pn=!1,Uo=0,Na=0,Hn=null,Zb=0;function Oe(){throw Error(d(321))}function Bl(e,t){if(t===null)return!1;for(var r=0;r<t.length&&r<e.length;r++)if(!vt(e[r],t[r]))return!1;return!0}function Wl(e,t,r,n,a,o){return or=o,Z=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,M.H=e===null||e.memoizedState===null?sp:ls,pn=!1,o=r(n,a),pn=!1,$n&&(o=Ed(t,r,n,a)),Cd(e),o}function Cd(e){M.H=La;var t=ke!==null&&ke.next!==null;if(or=0,He=ke=Z=null,Io=!1,Na=0,Hn=null,t)throw Error(d(300));e===null||Ve||(e=e.dependencies,e!==null&&jo(e)&&(Ve=!0))}function Ed(e,t,r,n){Z=e;var a=0;do{if($n&&(Hn=null),Na=0,$n=!1,25<=a)throw Error(d(301));if(a+=1,He=ke=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}M.H=cp,o=t(r,n)}while($n);return o}function e0(){var e=M.H,t=e.useState()[0];return t=typeof t.then=="function"?Pa(t):t,e=e.useState()[0],(ke!==null?ke.memoizedState:null)!==e&&(Z.flags|=1024),t}function Ql(){var e=Uo!==0;return Uo=0,e}function Kl(e,t,r){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~r}function Yl(e){if(Io){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Io=!1}or=0,He=ke=Z=null,$n=!1,Na=Uo=0,Hn=null}function ot(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return He===null?Z.memoizedState=He=e:He=He.next=e,He}function Fe(){if(ke===null){var e=Z.alternate;e=e!==null?e.memoizedState:null}else e=ke.next;var t=He===null?Z.memoizedState:He.next;if(t!==null)He=t,ke=e;else{if(e===null)throw Z.alternate===null?Error(d(467)):Error(d(310));ke=e,e={memoizedState:ke.memoizedState,baseState:ke.baseState,baseQueue:ke.baseQueue,queue:ke.queue,next:null},He===null?Z.memoizedState=He=e:He=He.next=e}return He}function $o(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Pa(e){var t=Na;return Na+=1,Hn===null&&(Hn=[]),e=bd(Hn,e,t),t=Z,(He===null?t.memoizedState:He.next)===null&&(t=t.alternate,M.H=t===null||t.memoizedState===null?sp:ls),e}function Ho(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Pa(e);if(e.$$typeof===oe)return et(e)}throw Error(d(438,String(e)))}function Xl(e){var t=null,r=Z.updateQueue;if(r!==null&&(t=r.memoCache),t==null){var n=Z.alternate;n!==null&&(n=n.updateQueue,n!==null&&(n=n.memoCache,n!=null&&(t={data:n.data.map(function(a){return a.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),r===null&&(r=$o(),Z.updateQueue=r),r.memoCache=t,r=t.data[t.index],r===void 0)for(r=t.data[t.index]=Array(e),n=0;n<e;n++)r[n]=Ae;return t.index++,r}function ir(e,t){return typeof t=="function"?t(e):t}function Vo(e){var t=Fe();return Gl(t,ke,e)}function Gl(e,t,r){var n=e.queue;if(n===null)throw Error(d(311));n.lastRenderedReducer=r;var a=e.baseQueue,o=n.pending;if(o!==null){if(a!==null){var l=a.next;a.next=o.next,o.next=l}t.baseQueue=a=o,n.pending=null}if(o=e.baseState,a===null)e.memoizedState=o;else{t=a.next;var u=l=null,f=null,v=t,P=!1;do{var T=v.lane&-536870913;if(T!==v.lane?(ie&T)===T:(or&T)===T){var y=v.revertLane;if(y===0)f!==null&&(f=f.next={lane:0,revertLane:0,gesture:null,action:v.action,hasEagerState:v.hasEagerState,eagerState:v.eagerState,next:null}),T===Mn&&(P=!0);else if((or&y)===y){v=v.next,y===Mn&&(P=!0);continue}else T={lane:0,revertLane:v.revertLane,gesture:null,action:v.action,hasEagerState:v.hasEagerState,eagerState:v.eagerState,next:null},f===null?(u=f=T,l=o):f=f.next=T,Z.lanes|=y,Ar|=y;T=v.action,pn&&r(o,T),o=v.hasEagerState?v.eagerState:r(o,T)}else y={lane:T,revertLane:v.revertLane,gesture:v.gesture,action:v.action,hasEagerState:v.hasEagerState,eagerState:v.eagerState,next:null},f===null?(u=f=y,l=o):f=f.next=y,Z.lanes|=T,Ar|=T;v=v.next}while(v!==null&&v!==t);if(f===null?l=o:f.next=u,!vt(o,e.memoizedState)&&(Ve=!0,P&&(r=Dn,r!==null)))throw r;e.memoizedState=o,e.baseState=l,e.baseQueue=f,n.lastRenderedState=o}return a===null&&(n.lanes=0),[e.memoizedState,n.dispatch]}function Jl(e){var t=Fe(),r=t.queue;if(r===null)throw Error(d(311));r.lastRenderedReducer=e;var n=r.dispatch,a=r.pending,o=t.memoizedState;if(a!==null){r.pending=null;var l=a=a.next;do o=e(o,l.action),l=l.next;while(l!==a);vt(o,t.memoizedState)||(Ve=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),r.lastRenderedState=o}return[o,n]}function Nd(e,t,r){var n=Z,a=Fe(),o=ue;if(o){if(r===void 0)throw Error(d(407));r=r()}else r=t();var l=!vt((ke||a).memoizedState,r);if(l&&(a.memoizedState=r,Ve=!0),a=a.queue,ts(Ld.bind(null,n,a,e),[e]),a.getSnapshot!==t||l||He!==null&&He.memoizedState.tag&1){if(n.flags|=2048,Vn(9,{destroy:void 0},jd.bind(null,n,a,r,t),null),Ce===null)throw Error(d(349));o||(or&127)!==0||Pd(n,t,r)}return r}function Pd(e,t,r){e.flags|=16384,e={getSnapshot:t,value:r},t=Z.updateQueue,t===null?(t=$o(),Z.updateQueue=t,t.stores=[e]):(r=t.stores,r===null?t.stores=[e]:r.push(e))}function jd(e,t,r,n){t.value=r,t.getSnapshot=n,Td(t)&&Ad(e)}function Ld(e,t,r){return r(function(){Td(t)&&Ad(e)})}function Td(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!vt(e,r)}catch{return!0}}function Ad(e){var t=rn(e,2);t!==null&&mt(t,e,2)}function Zl(e){var t=ot();if(typeof e=="function"){var r=e;if(e=r(),pn){yr(!0);try{r()}finally{yr(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ir,lastRenderedState:e},t}function Rd(e,t,r,n){return e.baseState=r,Gl(e,ke,typeof n=="function"?n:ir)}function t0(e,t,r,n,a){if(Wo(e))throw Error(d(485));if(e=t.action,e!==null){var o={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(l){o.listeners.push(l)}};M.T!==null?r(!0):o.isTransition=!1,n(o),r=t.pending,r===null?(o.next=t.pending=o,Od(t,o)):(o.next=r.next,t.pending=r.next=o)}}function Od(e,t){var r=t.action,n=t.payload,a=e.state;if(t.isTransition){var o=M.T,l={};M.T=l;try{var u=r(a,n),f=M.S;f!==null&&f(l,u),Md(e,t,u)}catch(v){es(e,t,v)}finally{o!==null&&l.types!==null&&(o.types=l.types),M.T=o}}else try{o=r(a,n),Md(e,t,o)}catch(v){es(e,t,v)}}function Md(e,t,r){r!==null&&typeof r=="object"&&typeof r.then=="function"?r.then(function(n){Dd(e,t,n)},function(n){return es(e,t,n)}):Dd(e,t,r)}function Dd(e,t,r){t.status="fulfilled",t.value=r,Fd(t),e.state=r,t=e.pending,t!==null&&(r=t.next,r===t?e.pending=null:(r=r.next,t.next=r,Od(e,r)))}function es(e,t,r){var n=e.pending;if(e.pending=null,n!==null){n=n.next;do t.status="rejected",t.reason=r,Fd(t),t=t.next;while(t!==n)}e.action=null}function Fd(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Id(e,t){return t}function Ud(e,t){if(ue){var r=Ce.formState;if(r!==null){e:{var n=Z;if(ue){if(Pe){t:{for(var a=Pe,o=jt;a.nodeType!==8;){if(!o){a=null;break t}if(a=Lt(a.nextSibling),a===null){a=null;break t}}o=a.data,a=o==="F!"||o==="F"?a:null}if(a){Pe=Lt(a.nextSibling),n=a.data==="F!";break e}}_r(n)}n=!1}n&&(t=r[0])}}return r=ot(),r.memoizedState=r.baseState=t,n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Id,lastRenderedState:t},r.queue=n,r=op.bind(null,Z,n),n.dispatch=r,n=Zl(!1),o=is.bind(null,Z,!1,n.queue),n=ot(),a={state:t,dispatch:null,action:e,pending:null},n.queue=a,r=t0.bind(null,Z,a,o,r),a.dispatch=r,n.memoizedState=e,[t,r,!1]}function $d(e){var t=Fe();return Hd(t,ke,e)}function Hd(e,t,r){if(t=Gl(e,t,Id)[0],e=Vo(ir)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var n=Pa(t)}catch(l){throw l===Fn?Ao:l}else n=t;t=Fe();var a=t.queue,o=a.dispatch;return r!==t.memoizedState&&(Z.flags|=2048,Vn(9,{destroy:void 0},r0.bind(null,a,r),null)),[n,o,e]}function r0(e,t){e.action=t}function Vd(e){var t=Fe(),r=ke;if(r!==null)return Hd(t,r,e);Fe(),t=t.memoizedState,r=Fe();var n=r.queue.dispatch;return r.memoizedState=e,[t,n,!1]}function Vn(e,t,r,n){return e={tag:e,create:r,deps:n,inst:t,next:null},t=Z.updateQueue,t===null&&(t=$o(),Z.updateQueue=t),r=t.lastEffect,r===null?t.lastEffect=e.next=e:(n=r.next,r.next=e,e.next=n,t.lastEffect=e),e}function qd(){return Fe().memoizedState}function qo(e,t,r,n){var a=ot();Z.flags|=e,a.memoizedState=Vn(1|t,{destroy:void 0},r,n===void 0?null:n)}function Bo(e,t,r,n){var a=Fe();n=n===void 0?null:n;var o=a.memoizedState.inst;ke!==null&&n!==null&&Bl(n,ke.memoizedState.deps)?a.memoizedState=Vn(t,o,r,n):(Z.flags|=e,a.memoizedState=Vn(1|t,o,r,n))}function Bd(e,t){qo(8390656,8,e,t)}function ts(e,t){Bo(2048,8,e,t)}function n0(e){Z.flags|=4;var t=Z.updateQueue;if(t===null)t=$o(),Z.updateQueue=t,t.events=[e];else{var r=t.events;r===null?t.events=[e]:r.push(e)}}function Wd(e){var t=Fe().memoizedState;return n0({ref:t,nextImpl:e}),function(){if((ve&2)!==0)throw Error(d(440));return t.impl.apply(void 0,arguments)}}function Qd(e,t){return Bo(4,2,e,t)}function Kd(e,t){return Bo(4,4,e,t)}function Yd(e,t){if(typeof t=="function"){e=e();var r=t(e);return function(){typeof r=="function"?r():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Xd(e,t,r){r=r!=null?r.concat([e]):null,Bo(4,4,Yd.bind(null,t,e),r)}function rs(){}function Gd(e,t){var r=Fe();t=t===void 0?null:t;var n=r.memoizedState;return t!==null&&Bl(t,n[1])?n[0]:(r.memoizedState=[e,t],e)}function Jd(e,t){var r=Fe();t=t===void 0?null:t;var n=r.memoizedState;if(t!==null&&Bl(t,n[1]))return n[0];if(n=e(),pn){yr(!0);try{e()}finally{yr(!1)}}return r.memoizedState=[n,t],n}function ns(e,t,r){return r===void 0||(or&1073741824)!==0&&(ie&261930)===0?e.memoizedState=t:(e.memoizedState=r,e=Zp(),Z.lanes|=e,Ar|=e,r)}function Zd(e,t,r,n){return vt(r,t)?r:Un.current!==null?(e=ns(e,r,n),vt(e,t)||(Ve=!0),e):(or&42)===0||(or&1073741824)!==0&&(ie&261930)===0?(Ve=!0,e.memoizedState=r):(e=Zp(),Z.lanes|=e,Ar|=e,t)}function ep(e,t,r,n,a){var o=I.p;I.p=o!==0&&8>o?o:8;var l=M.T,u={};M.T=u,is(e,!1,t,r);try{var f=a(),v=M.S;if(v!==null&&v(u,f),f!==null&&typeof f=="object"&&typeof f.then=="function"){var P=Jb(f,n);ja(e,t,P,_t(e))}else ja(e,t,n,_t(e))}catch(T){ja(e,t,{then:function(){},status:"rejected",reason:T},_t())}finally{I.p=o,l!==null&&u.types!==null&&(l.types=u.types),M.T=l}}function a0(){}function as(e,t,r,n){if(e.tag!==5)throw Error(d(476));var a=tp(e).queue;ep(e,a,t,ce,r===null?a0:function(){return rp(e),r(n)})}function tp(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:ce,baseState:ce,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ir,lastRenderedState:ce},next:null};var r={};return t.next={memoizedState:r,baseState:r,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ir,lastRenderedState:r},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function rp(e){var t=tp(e);t.next===null&&(t=e.alternate.memoizedState),ja(e,t.next.queue,{},_t())}function os(){return et(Qa)}function np(){return Fe().memoizedState}function ap(){return Fe().memoizedState}function o0(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var r=_t();e=Er(r);var n=Nr(t,e,r);n!==null&&(mt(n,t,r),za(n,t,r)),t={cache:Rl()},e.payload=t;return}t=t.return}}function i0(e,t,r){var n=_t();r={lane:n,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},Wo(e)?ip(t,r):(r=Sl(e,t,r,n),r!==null&&(mt(r,e,n),lp(r,t,n)))}function op(e,t,r){var n=_t();ja(e,t,r,n)}function ja(e,t,r,n){var a={lane:n,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null};if(Wo(e))ip(t,a);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var l=t.lastRenderedState,u=o(l,r);if(a.hasEagerState=!0,a.eagerState=u,vt(u,l))return Co(e,t,a,0),Ce===null&&zo(),!1}catch{}if(r=Sl(e,t,a,n),r!==null)return mt(r,e,n),lp(r,t,n),!0}return!1}function is(e,t,r,n){if(n={lane:2,revertLane:Fs(),gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},Wo(e)){if(t)throw Error(d(479))}else t=Sl(e,r,n,2),t!==null&&mt(t,e,2)}function Wo(e){var t=e.alternate;return e===Z||t!==null&&t===Z}function ip(e,t){$n=Io=!0;var r=e.pending;r===null?t.next=t:(t.next=r.next,r.next=t),e.pending=t}function lp(e,t,r){if((r&4194048)!==0){var n=t.lanes;n&=e.pendingLanes,r|=n,t.lanes=r,fu(e,r)}}var La={readContext:et,use:Ho,useCallback:Oe,useContext:Oe,useEffect:Oe,useImperativeHandle:Oe,useLayoutEffect:Oe,useInsertionEffect:Oe,useMemo:Oe,useReducer:Oe,useRef:Oe,useState:Oe,useDebugValue:Oe,useDeferredValue:Oe,useTransition:Oe,useSyncExternalStore:Oe,useId:Oe,useHostTransitionStatus:Oe,useFormState:Oe,useActionState:Oe,useOptimistic:Oe,useMemoCache:Oe,useCacheRefresh:Oe};La.useEffectEvent=Oe;var sp={readContext:et,use:Ho,useCallback:function(e,t){return ot().memoizedState=[e,t===void 0?null:t],e},useContext:et,useEffect:Bd,useImperativeHandle:function(e,t,r){r=r!=null?r.concat([e]):null,qo(4194308,4,Yd.bind(null,t,e),r)},useLayoutEffect:function(e,t){return qo(4194308,4,e,t)},useInsertionEffect:function(e,t){qo(4,2,e,t)},useMemo:function(e,t){var r=ot();t=t===void 0?null:t;var n=e();if(pn){yr(!0);try{e()}finally{yr(!1)}}return r.memoizedState=[n,t],n},useReducer:function(e,t,r){var n=ot();if(r!==void 0){var a=r(t);if(pn){yr(!0);try{r(t)}finally{yr(!1)}}}else a=t;return n.memoizedState=n.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:a},n.queue=e,e=e.dispatch=i0.bind(null,Z,e),[n.memoizedState,e]},useRef:function(e){var t=ot();return e={current:e},t.memoizedState=e},useState:function(e){e=Zl(e);var t=e.queue,r=op.bind(null,Z,t);return t.dispatch=r,[e.memoizedState,r]},useDebugValue:rs,useDeferredValue:function(e,t){var r=ot();return ns(r,e,t)},useTransition:function(){var e=Zl(!1);return e=ep.bind(null,Z,e.queue,!0,!1),ot().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,r){var n=Z,a=ot();if(ue){if(r===void 0)throw Error(d(407));r=r()}else{if(r=t(),Ce===null)throw Error(d(349));(ie&127)!==0||Pd(n,t,r)}a.memoizedState=r;var o={value:r,getSnapshot:t};return a.queue=o,Bd(Ld.bind(null,n,o,e),[e]),n.flags|=2048,Vn(9,{destroy:void 0},jd.bind(null,n,o,r,t),null),r},useId:function(){var e=ot(),t=Ce.identifierPrefix;if(ue){var r=Bt,n=qt;r=(n&~(1<<32-bt(n)-1)).toString(32)+r,t="_"+t+"R_"+r,r=Uo++,0<r&&(t+="H"+r.toString(32)),t+="_"}else r=Zb++,t="_"+t+"r_"+r.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:os,useFormState:Ud,useActionState:Ud,useOptimistic:function(e){var t=ot();t.memoizedState=t.baseState=e;var r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=r,t=is.bind(null,Z,!0,r),r.dispatch=t,[e,t]},useMemoCache:Xl,useCacheRefresh:function(){return ot().memoizedState=o0.bind(null,Z)},useEffectEvent:function(e){var t=ot(),r={impl:e};return t.memoizedState=r,function(){if((ve&2)!==0)throw Error(d(440));return r.impl.apply(void 0,arguments)}}},ls={readContext:et,use:Ho,useCallback:Gd,useContext:et,useEffect:ts,useImperativeHandle:Xd,useInsertionEffect:Qd,useLayoutEffect:Kd,useMemo:Jd,useReducer:Vo,useRef:qd,useState:function(){return Vo(ir)},useDebugValue:rs,useDeferredValue:function(e,t){var r=Fe();return Zd(r,ke.memoizedState,e,t)},useTransition:function(){var e=Vo(ir)[0],t=Fe().memoizedState;return[typeof e=="boolean"?e:Pa(e),t]},useSyncExternalStore:Nd,useId:np,useHostTransitionStatus:os,useFormState:$d,useActionState:$d,useOptimistic:function(e,t){var r=Fe();return Rd(r,ke,e,t)},useMemoCache:Xl,useCacheRefresh:ap};ls.useEffectEvent=Wd;var cp={readContext:et,use:Ho,useCallback:Gd,useContext:et,useEffect:ts,useImperativeHandle:Xd,useInsertionEffect:Qd,useLayoutEffect:Kd,useMemo:Jd,useReducer:Jl,useRef:qd,useState:function(){return Jl(ir)},useDebugValue:rs,useDeferredValue:function(e,t){var r=Fe();return ke===null?ns(r,e,t):Zd(r,ke.memoizedState,e,t)},useTransition:function(){var e=Jl(ir)[0],t=Fe().memoizedState;return[typeof e=="boolean"?e:Pa(e),t]},useSyncExternalStore:Nd,useId:np,useHostTransitionStatus:os,useFormState:Vd,useActionState:Vd,useOptimistic:function(e,t){var r=Fe();return ke!==null?Rd(r,ke,e,t):(r.baseState=e,[e,r.queue.dispatch])},useMemoCache:Xl,useCacheRefresh:ap};cp.useEffectEvent=Wd;function ss(e,t,r,n){t=e.memoizedState,r=r(n,t),r=r==null?t:O({},t,r),e.memoizedState=r,e.lanes===0&&(e.updateQueue.baseState=r)}var cs={enqueueSetState:function(e,t,r){e=e._reactInternals;var n=_t(),a=Er(n);a.payload=t,r!=null&&(a.callback=r),t=Nr(e,a,n),t!==null&&(mt(t,e,n),za(t,e,n))},enqueueReplaceState:function(e,t,r){e=e._reactInternals;var n=_t(),a=Er(n);a.tag=1,a.payload=t,r!=null&&(a.callback=r),t=Nr(e,a,n),t!==null&&(mt(t,e,n),za(t,e,n))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var r=_t(),n=Er(r);n.tag=2,t!=null&&(n.callback=t),t=Nr(e,n,r),t!==null&&(mt(t,e,r),za(t,e,r))}};function up(e,t,r,n,a,o,l){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(n,o,l):t.prototype&&t.prototype.isPureReactComponent?!ba(r,n)||!ba(a,o):!0}function dp(e,t,r,n){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(r,n),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(r,n),t.state!==e&&cs.enqueueReplaceState(t,t.state,null)}function fn(e,t){var r=t;if("ref"in t){r={};for(var n in t)n!=="ref"&&(r[n]=t[n])}if(e=e.defaultProps){r===t&&(r=O({},r));for(var a in e)r[a]===void 0&&(r[a]=e[a])}return r}function pp(e){_o(e)}function fp(e){console.error(e)}function mp(e){_o(e)}function Qo(e,t){try{var r=e.onUncaughtError;r(t.value,{componentStack:t.stack})}catch(n){setTimeout(function(){throw n})}}function gp(e,t,r){try{var n=e.onCaughtError;n(r.value,{componentStack:r.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(a){setTimeout(function(){throw a})}}function us(e,t,r){return r=Er(r),r.tag=3,r.payload={element:null},r.callback=function(){Qo(e,t)},r}function hp(e){return e=Er(e),e.tag=3,e}function bp(e,t,r,n){var a=r.type.getDerivedStateFromError;if(typeof a=="function"){var o=n.value;e.payload=function(){return a(o)},e.callback=function(){gp(t,r,n)}}var l=r.stateNode;l!==null&&typeof l.componentDidCatch=="function"&&(e.callback=function(){gp(t,r,n),typeof a!="function"&&(Rr===null?Rr=new Set([this]):Rr.add(this));var u=n.stack;this.componentDidCatch(n.value,{componentStack:u!==null?u:""})})}function l0(e,t,r,n,a){if(r.flags|=32768,n!==null&&typeof n=="object"&&typeof n.then=="function"){if(t=r.alternate,t!==null&&On(t,r,a,!0),r=wt.current,r!==null){switch(r.tag){case 31:case 13:return Dt===null?ii():r.alternate===null&&Me===0&&(Me=3),r.flags&=-257,r.flags|=65536,r.lanes=a,n===Ro?r.flags|=16384:(t=r.updateQueue,t===null?r.updateQueue=new Set([n]):t.add(n),Os(e,n,a)),!1;case 22:return r.flags|=65536,n===Ro?r.flags|=16384:(t=r.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([n])},r.updateQueue=t):(r=t.retryQueue,r===null?t.retryQueue=new Set([n]):r.add(n)),Os(e,n,a)),!1}throw Error(d(435,r.tag))}return Os(e,n,a),ii(),!1}if(ue)return t=wt.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=a,n!==Pl&&(e=Error(d(422),{cause:n}),wa(Et(e,r)))):(n!==Pl&&(t=Error(d(423),{cause:n}),wa(Et(t,r))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,n=Et(n,r),a=us(e.stateNode,n,a),Ul(e,a),Me!==4&&(Me=2)),!1;var o=Error(d(520),{cause:n});if(o=Et(o,r),Ia===null?Ia=[o]:Ia.push(o),Me!==4&&(Me=2),t===null)return!0;n=Et(n,r),r=t;do{switch(r.tag){case 3:return r.flags|=65536,e=a&-a,r.lanes|=e,e=us(r.stateNode,n,e),Ul(r,e),!1;case 1:if(t=r.type,o=r.stateNode,(r.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||o!==null&&typeof o.componentDidCatch=="function"&&(Rr===null||!Rr.has(o))))return r.flags|=65536,a&=-a,r.lanes|=a,a=hp(a),bp(a,e,r,n),Ul(r,a),!1}r=r.return}while(r!==null);return!1}var ds=Error(d(461)),Ve=!1;function tt(e,t,r,n){t.child=e===null?xd(t,null,r,n):dn(t,e.child,r,n)}function vp(e,t,r,n,a){r=r.render;var o=t.ref;if("ref"in n){var l={};for(var u in n)u!=="ref"&&(l[u]=n[u])}else l=n;return ln(t),n=Wl(e,t,r,l,o,a),u=Ql(),e!==null&&!Ve?(Kl(e,t,a),lr(e,t,a)):(ue&&u&&El(t),t.flags|=1,tt(e,t,n,a),t.child)}function yp(e,t,r,n,a){if(e===null){var o=r.type;return typeof o=="function"&&!_l(o)&&o.defaultProps===void 0&&r.compare===null?(t.tag=15,t.type=o,wp(e,t,o,n,a)):(e=No(r.type,null,n,t,t.mode,a),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!ys(e,a)){var l=o.memoizedProps;if(r=r.compare,r=r!==null?r:ba,r(l,n)&&e.ref===t.ref)return lr(e,t,a)}return t.flags|=1,e=tr(o,n),e.ref=t.ref,e.return=t,t.child=e}function wp(e,t,r,n,a){if(e!==null){var o=e.memoizedProps;if(ba(o,n)&&e.ref===t.ref)if(Ve=!1,t.pendingProps=n=o,ys(e,a))(e.flags&131072)!==0&&(Ve=!0);else return t.lanes=e.lanes,lr(e,t,a)}return ps(e,t,r,n,a)}function xp(e,t,r,n){var a=n.children,o=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.mode==="hidden"){if((t.flags&128)!==0){if(o=o!==null?o.baseLanes|r:r,e!==null){for(n=t.child=e.child,a=0;n!==null;)a=a|n.lanes|n.childLanes,n=n.sibling;n=a&~o}else n=0,t.child=null;return kp(e,t,o,r,n)}if((r&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&To(t,o!==null?o.cachePool:null),o!==null?_d(t,o):Hl(),zd(t);else return n=t.lanes=536870912,kp(e,t,o!==null?o.baseLanes|r:r,r,n)}else o!==null?(To(t,o.cachePool),_d(t,o),jr(t),t.memoizedState=null):(e!==null&&To(t,null),Hl(),jr(t));return tt(e,t,a,r),t.child}function Ta(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function kp(e,t,r,n,a){var o=Ml();return o=o===null?null:{parent:$e._currentValue,pool:o},t.memoizedState={baseLanes:r,cachePool:o},e!==null&&To(t,null),Hl(),zd(t),e!==null&&On(e,t,n,!0),t.childLanes=a,null}function Ko(e,t){return t=Xo({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Sp(e,t,r){return dn(t,e.child,null,r),e=Ko(t,t.pendingProps),e.flags|=2,xt(t),t.memoizedState=null,e}function s0(e,t,r){var n=t.pendingProps,a=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(ue){if(n.mode==="hidden")return e=Ko(t,n),t.lanes=536870912,Ta(null,e);if(ql(t),(e=Pe)?(e=Ff(e,jt),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:kr!==null?{id:qt,overflow:Bt}:null,retryLane:536870912,hydrationErrors:null},r=id(e),r.return=t,t.child=r,Ze=t,Pe=null)):e=null,e===null)throw _r(t);return t.lanes=536870912,null}return Ko(t,n)}var o=e.memoizedState;if(o!==null){var l=o.dehydrated;if(ql(t),a)if(t.flags&256)t.flags&=-257,t=Sp(e,t,r);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(d(558));else if(Ve||On(e,t,r,!1),a=(r&e.childLanes)!==0,Ve||a){if(n=Ce,n!==null&&(l=mu(n,r),l!==0&&l!==o.retryLane))throw o.retryLane=l,rn(e,l),mt(n,e,l),ds;ii(),t=Sp(e,t,r)}else e=o.treeContext,Pe=Lt(l.nextSibling),Ze=t,ue=!0,Sr=null,jt=!1,e!==null&&cd(t,e),t=Ko(t,n),t.flags|=4096;return t}return e=tr(e.child,{mode:n.mode,children:n.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Yo(e,t){var r=t.ref;if(r===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof r!="function"&&typeof r!="object")throw Error(d(284));(e===null||e.ref!==r)&&(t.flags|=4194816)}}function ps(e,t,r,n,a){return ln(t),r=Wl(e,t,r,n,void 0,a),n=Ql(),e!==null&&!Ve?(Kl(e,t,a),lr(e,t,a)):(ue&&n&&El(t),t.flags|=1,tt(e,t,r,a),t.child)}function _p(e,t,r,n,a,o){return ln(t),t.updateQueue=null,r=Ed(t,n,r,a),Cd(e),n=Ql(),e!==null&&!Ve?(Kl(e,t,o),lr(e,t,o)):(ue&&n&&El(t),t.flags|=1,tt(e,t,r,o),t.child)}function zp(e,t,r,n,a){if(ln(t),t.stateNode===null){var o=Ln,l=r.contextType;typeof l=="object"&&l!==null&&(o=et(l)),o=new r(n,o),t.memoizedState=o.state!==null&&o.state!==void 0?o.state:null,o.updater=cs,t.stateNode=o,o._reactInternals=t,o=t.stateNode,o.props=n,o.state=t.memoizedState,o.refs={},Fl(t),l=r.contextType,o.context=typeof l=="object"&&l!==null?et(l):Ln,o.state=t.memoizedState,l=r.getDerivedStateFromProps,typeof l=="function"&&(ss(t,r,l,n),o.state=t.memoizedState),typeof r.getDerivedStateFromProps=="function"||typeof o.getSnapshotBeforeUpdate=="function"||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(l=o.state,typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount(),l!==o.state&&cs.enqueueReplaceState(o,o.state,null),Ea(t,n,o,a),Ca(),o.state=t.memoizedState),typeof o.componentDidMount=="function"&&(t.flags|=4194308),n=!0}else if(e===null){o=t.stateNode;var u=t.memoizedProps,f=fn(r,u);o.props=f;var v=o.context,P=r.contextType;l=Ln,typeof P=="object"&&P!==null&&(l=et(P));var T=r.getDerivedStateFromProps;P=typeof T=="function"||typeof o.getSnapshotBeforeUpdate=="function",u=t.pendingProps!==u,P||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(u||v!==l)&&dp(t,o,n,l),Cr=!1;var y=t.memoizedState;o.state=y,Ea(t,n,o,a),Ca(),v=t.memoizedState,u||y!==v||Cr?(typeof T=="function"&&(ss(t,r,T,n),v=t.memoizedState),(f=Cr||up(t,r,f,n,y,v,l))?(P||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(t.flags|=4194308)):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=n,t.memoizedState=v),o.props=n,o.state=v,o.context=l,n=f):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),n=!1)}else{o=t.stateNode,Il(e,t),l=t.memoizedProps,P=fn(r,l),o.props=P,T=t.pendingProps,y=o.context,v=r.contextType,f=Ln,typeof v=="object"&&v!==null&&(f=et(v)),u=r.getDerivedStateFromProps,(v=typeof u=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(l!==T||y!==f)&&dp(t,o,n,f),Cr=!1,y=t.memoizedState,o.state=y,Ea(t,n,o,a),Ca();var _=t.memoizedState;l!==T||y!==_||Cr||e!==null&&e.dependencies!==null&&jo(e.dependencies)?(typeof u=="function"&&(ss(t,r,u,n),_=t.memoizedState),(P=Cr||up(t,r,P,n,y,_,f)||e!==null&&e.dependencies!==null&&jo(e.dependencies))?(v||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(n,_,f),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(n,_,f)),typeof o.componentDidUpdate=="function"&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof o.componentDidUpdate!="function"||l===e.memoizedProps&&y===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&y===e.memoizedState||(t.flags|=1024),t.memoizedProps=n,t.memoizedState=_),o.props=n,o.state=_,o.context=f,n=P):(typeof o.componentDidUpdate!="function"||l===e.memoizedProps&&y===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&y===e.memoizedState||(t.flags|=1024),n=!1)}return o=n,Yo(e,t),n=(t.flags&128)!==0,o||n?(o=t.stateNode,r=n&&typeof r.getDerivedStateFromError!="function"?null:o.render(),t.flags|=1,e!==null&&n?(t.child=dn(t,e.child,null,a),t.child=dn(t,null,r,a)):tt(e,t,r,a),t.memoizedState=o.state,e=t.child):e=lr(e,t,a),e}function Cp(e,t,r,n){return an(),t.flags|=256,tt(e,t,r,n),t.child}var fs={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function ms(e){return{baseLanes:e,cachePool:gd()}}function gs(e,t,r){return e=e!==null?e.childLanes&~r:0,t&&(e|=St),e}function Ep(e,t,r){var n=t.pendingProps,a=!1,o=(t.flags&128)!==0,l;if((l=o)||(l=e!==null&&e.memoizedState===null?!1:(De.current&2)!==0),l&&(a=!0,t.flags&=-129),l=(t.flags&32)!==0,t.flags&=-33,e===null){if(ue){if(a?Pr(t):jr(t),(e=Pe)?(e=Ff(e,jt),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:kr!==null?{id:qt,overflow:Bt}:null,retryLane:536870912,hydrationErrors:null},r=id(e),r.return=t,t.child=r,Ze=t,Pe=null)):e=null,e===null)throw _r(t);return Ys(e)?t.lanes=32:t.lanes=536870912,null}var u=n.children;return n=n.fallback,a?(jr(t),a=t.mode,u=Xo({mode:"hidden",children:u},a),n=nn(n,a,r,null),u.return=t,n.return=t,u.sibling=n,t.child=u,n=t.child,n.memoizedState=ms(r),n.childLanes=gs(e,l,r),t.memoizedState=fs,Ta(null,n)):(Pr(t),hs(t,u))}var f=e.memoizedState;if(f!==null&&(u=f.dehydrated,u!==null)){if(o)t.flags&256?(Pr(t),t.flags&=-257,t=bs(e,t,r)):t.memoizedState!==null?(jr(t),t.child=e.child,t.flags|=128,t=null):(jr(t),u=n.fallback,a=t.mode,n=Xo({mode:"visible",children:n.children},a),u=nn(u,a,r,null),u.flags|=2,n.return=t,u.return=t,n.sibling=u,t.child=n,dn(t,e.child,null,r),n=t.child,n.memoizedState=ms(r),n.childLanes=gs(e,l,r),t.memoizedState=fs,t=Ta(null,n));else if(Pr(t),Ys(u)){if(l=u.nextSibling&&u.nextSibling.dataset,l)var v=l.dgst;l=v,n=Error(d(419)),n.stack="",n.digest=l,wa({value:n,source:null,stack:null}),t=bs(e,t,r)}else if(Ve||On(e,t,r,!1),l=(r&e.childLanes)!==0,Ve||l){if(l=Ce,l!==null&&(n=mu(l,r),n!==0&&n!==f.retryLane))throw f.retryLane=n,rn(e,n),mt(l,e,n),ds;Ks(u)||ii(),t=bs(e,t,r)}else Ks(u)?(t.flags|=192,t.child=e.child,t=null):(e=f.treeContext,Pe=Lt(u.nextSibling),Ze=t,ue=!0,Sr=null,jt=!1,e!==null&&cd(t,e),t=hs(t,n.children),t.flags|=4096);return t}return a?(jr(t),u=n.fallback,a=t.mode,f=e.child,v=f.sibling,n=tr(f,{mode:"hidden",children:n.children}),n.subtreeFlags=f.subtreeFlags&65011712,v!==null?u=tr(v,u):(u=nn(u,a,r,null),u.flags|=2),u.return=t,n.return=t,n.sibling=u,t.child=n,Ta(null,n),n=t.child,u=e.child.memoizedState,u===null?u=ms(r):(a=u.cachePool,a!==null?(f=$e._currentValue,a=a.parent!==f?{parent:f,pool:f}:a):a=gd(),u={baseLanes:u.baseLanes|r,cachePool:a}),n.memoizedState=u,n.childLanes=gs(e,l,r),t.memoizedState=fs,Ta(e.child,n)):(Pr(t),r=e.child,e=r.sibling,r=tr(r,{mode:"visible",children:n.children}),r.return=t,r.sibling=null,e!==null&&(l=t.deletions,l===null?(t.deletions=[e],t.flags|=16):l.push(e)),t.child=r,t.memoizedState=null,r)}function hs(e,t){return t=Xo({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Xo(e,t){return e=yt(22,e,null,t),e.lanes=0,e}function bs(e,t,r){return dn(t,e.child,null,r),e=hs(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Np(e,t,r){e.lanes|=t;var n=e.alternate;n!==null&&(n.lanes|=t),Tl(e.return,t,r)}function vs(e,t,r,n,a,o){var l=e.memoizedState;l===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:n,tail:r,tailMode:a,treeForkCount:o}:(l.isBackwards=t,l.rendering=null,l.renderingStartTime=0,l.last=n,l.tail=r,l.tailMode=a,l.treeForkCount=o)}function Pp(e,t,r){var n=t.pendingProps,a=n.revealOrder,o=n.tail;n=n.children;var l=De.current,u=(l&2)!==0;if(u?(l=l&1|2,t.flags|=128):l&=1,F(De,l),tt(e,t,n,r),n=ue?ya:0,!u&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Np(e,r,t);else if(e.tag===19)Np(e,r,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(a){case"forwards":for(r=t.child,a=null;r!==null;)e=r.alternate,e!==null&&Fo(e)===null&&(a=r),r=r.sibling;r=a,r===null?(a=t.child,t.child=null):(a=r.sibling,r.sibling=null),vs(t,!1,a,r,o,n);break;case"backwards":case"unstable_legacy-backwards":for(r=null,a=t.child,t.child=null;a!==null;){if(e=a.alternate,e!==null&&Fo(e)===null){t.child=a;break}e=a.sibling,a.sibling=r,r=a,a=e}vs(t,!0,r,null,o,n);break;case"together":vs(t,!1,null,null,void 0,n);break;default:t.memoizedState=null}return t.child}function lr(e,t,r){if(e!==null&&(t.dependencies=e.dependencies),Ar|=t.lanes,(r&t.childLanes)===0)if(e!==null){if(On(e,t,r,!1),(r&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(d(153));if(t.child!==null){for(e=t.child,r=tr(e,e.pendingProps),t.child=r,r.return=t;e.sibling!==null;)e=e.sibling,r=r.sibling=tr(e,e.pendingProps),r.return=t;r.sibling=null}return t.child}function ys(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&jo(e)))}function c0(e,t,r){switch(t.tag){case 3:fe(t,t.stateNode.containerInfo),zr(t,$e,e.memoizedState.cache),an();break;case 27:case 5:Vt(t);break;case 4:fe(t,t.stateNode.containerInfo);break;case 10:zr(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,ql(t),null;break;case 13:var n=t.memoizedState;if(n!==null)return n.dehydrated!==null?(Pr(t),t.flags|=128,null):(r&t.child.childLanes)!==0?Ep(e,t,r):(Pr(t),e=lr(e,t,r),e!==null?e.sibling:null);Pr(t);break;case 19:var a=(e.flags&128)!==0;if(n=(r&t.childLanes)!==0,n||(On(e,t,r,!1),n=(r&t.childLanes)!==0),a){if(n)return Pp(e,t,r);t.flags|=128}if(a=t.memoizedState,a!==null&&(a.rendering=null,a.tail=null,a.lastEffect=null),F(De,De.current),n)break;return null;case 22:return t.lanes=0,xp(e,t,r,t.pendingProps);case 24:zr(t,$e,e.memoizedState.cache)}return lr(e,t,r)}function jp(e,t,r){if(e!==null)if(e.memoizedProps!==t.pendingProps)Ve=!0;else{if(!ys(e,r)&&(t.flags&128)===0)return Ve=!1,c0(e,t,r);Ve=(e.flags&131072)!==0}else Ve=!1,ue&&(t.flags&1048576)!==0&&sd(t,ya,t.index);switch(t.lanes=0,t.tag){case 16:e:{var n=t.pendingProps;if(e=cn(t.elementType),t.type=e,typeof e=="function")_l(e)?(n=fn(e,n),t.tag=1,t=zp(null,t,e,n,r)):(t.tag=0,t=ps(null,t,e,n,r));else{if(e!=null){var a=e.$$typeof;if(a===ye){t.tag=11,t=vp(null,t,e,n,r);break e}else if(a===E){t.tag=14,t=yp(null,t,e,n,r);break e}}throw t=Ke(e)||e,Error(d(306,t,""))}}return t;case 0:return ps(e,t,t.type,t.pendingProps,r);case 1:return n=t.type,a=fn(n,t.pendingProps),zp(e,t,n,a,r);case 3:e:{if(fe(t,t.stateNode.containerInfo),e===null)throw Error(d(387));n=t.pendingProps;var o=t.memoizedState;a=o.element,Il(e,t),Ea(t,n,null,r);var l=t.memoizedState;if(n=l.cache,zr(t,$e,n),n!==o.cache&&Al(t,[$e],r,!0),Ca(),n=l.element,o.isDehydrated)if(o={element:n,isDehydrated:!1,cache:l.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=Cp(e,t,n,r);break e}else if(n!==a){a=Et(Error(d(424)),t),wa(a),t=Cp(e,t,n,r);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,Pe=Lt(e.firstChild),Ze=t,ue=!0,Sr=null,jt=!0,r=xd(t,null,n,r),t.child=r;r;)r.flags=r.flags&-3|4096,r=r.sibling;else{if(an(),n===a){t=lr(e,t,r);break e}tt(e,t,n,r)}t=t.child}return t;case 26:return Yo(e,t),e===null?(r=qf(t.type,null,t.pendingProps,null))?t.memoizedState=r:ue||(r=t.type,e=t.pendingProps,n=gi(J.current).createElement(r),n[Je]=t,n[st]=e,rt(n,r,e),Ye(n),t.stateNode=n):t.memoizedState=qf(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Vt(t),e===null&&ue&&(n=t.stateNode=$f(t.type,t.pendingProps,J.current),Ze=t,jt=!0,a=Pe,Fr(t.type)?(Xs=a,Pe=Lt(n.firstChild)):Pe=a),tt(e,t,t.pendingProps.children,r),Yo(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&ue&&((a=n=Pe)&&(n=D0(n,t.type,t.pendingProps,jt),n!==null?(t.stateNode=n,Ze=t,Pe=Lt(n.firstChild),jt=!1,a=!0):a=!1),a||_r(t)),Vt(t),a=t.type,o=t.pendingProps,l=e!==null?e.memoizedProps:null,n=o.children,Bs(a,o)?n=null:l!==null&&Bs(a,l)&&(t.flags|=32),t.memoizedState!==null&&(a=Wl(e,t,e0,null,null,r),Qa._currentValue=a),Yo(e,t),tt(e,t,n,r),t.child;case 6:return e===null&&ue&&((e=r=Pe)&&(r=F0(r,t.pendingProps,jt),r!==null?(t.stateNode=r,Ze=t,Pe=null,e=!0):e=!1),e||_r(t)),null;case 13:return Ep(e,t,r);case 4:return fe(t,t.stateNode.containerInfo),n=t.pendingProps,e===null?t.child=dn(t,null,n,r):tt(e,t,n,r),t.child;case 11:return vp(e,t,t.type,t.pendingProps,r);case 7:return tt(e,t,t.pendingProps,r),t.child;case 8:return tt(e,t,t.pendingProps.children,r),t.child;case 12:return tt(e,t,t.pendingProps.children,r),t.child;case 10:return n=t.pendingProps,zr(t,t.type,n.value),tt(e,t,n.children,r),t.child;case 9:return a=t.type._context,n=t.pendingProps.children,ln(t),a=et(a),n=n(a),t.flags|=1,tt(e,t,n,r),t.child;case 14:return yp(e,t,t.type,t.pendingProps,r);case 15:return wp(e,t,t.type,t.pendingProps,r);case 19:return Pp(e,t,r);case 31:return s0(e,t,r);case 22:return xp(e,t,r,t.pendingProps);case 24:return ln(t),n=et($e),e===null?(a=Ml(),a===null&&(a=Ce,o=Rl(),a.pooledCache=o,o.refCount++,o!==null&&(a.pooledCacheLanes|=r),a=o),t.memoizedState={parent:n,cache:a},Fl(t),zr(t,$e,a)):((e.lanes&r)!==0&&(Il(e,t),Ea(t,null,null,r),Ca()),a=e.memoizedState,o=t.memoizedState,a.parent!==n?(a={parent:n,cache:n},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),zr(t,$e,n)):(n=o.cache,zr(t,$e,n),n!==a.cache&&Al(t,[$e],r,!0))),tt(e,t,t.pendingProps.children,r),t.child;case 29:throw t.pendingProps}throw Error(d(156,t.tag))}function sr(e){e.flags|=4}function ws(e,t,r,n,a){if((t=(e.mode&32)!==0)&&(t=!1),t){if(e.flags|=16777216,(a&335544128)===a)if(e.stateNode.complete)e.flags|=8192;else if(nf())e.flags|=8192;else throw un=Ro,Dl}else e.flags&=-16777217}function Lp(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!Yf(t))if(nf())e.flags|=8192;else throw un=Ro,Dl}function Go(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?du():536870912,e.lanes|=t,Qn|=t)}function Aa(e,t){if(!ue)switch(e.tailMode){case"hidden":t=e.tail;for(var r=null;t!==null;)t.alternate!==null&&(r=t),t=t.sibling;r===null?e.tail=null:r.sibling=null;break;case"collapsed":r=e.tail;for(var n=null;r!==null;)r.alternate!==null&&(n=r),r=r.sibling;n===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:n.sibling=null}}function je(e){var t=e.alternate!==null&&e.alternate.child===e.child,r=0,n=0;if(t)for(var a=e.child;a!==null;)r|=a.lanes|a.childLanes,n|=a.subtreeFlags&65011712,n|=a.flags&65011712,a.return=e,a=a.sibling;else for(a=e.child;a!==null;)r|=a.lanes|a.childLanes,n|=a.subtreeFlags,n|=a.flags,a.return=e,a=a.sibling;return e.subtreeFlags|=n,e.childLanes=r,t}function u0(e,t,r){var n=t.pendingProps;switch(Nl(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return je(t),null;case 1:return je(t),null;case 3:return r=t.stateNode,n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),ar($e),Le(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(Rn(t)?sr(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,jl())),je(t),null;case 26:var a=t.type,o=t.memoizedState;return e===null?(sr(t),o!==null?(je(t),Lp(t,o)):(je(t),ws(t,a,null,n,r))):o?o!==e.memoizedState?(sr(t),je(t),Lp(t,o)):(je(t),t.flags&=-16777217):(e=e.memoizedProps,e!==n&&sr(t),je(t),ws(t,a,e,n,r)),null;case 27:if(Gt(t),r=J.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==n&&sr(t);else{if(!n){if(t.stateNode===null)throw Error(d(166));return je(t),null}e=$.current,Rn(t)?ud(t,e):(e=$f(a,n,r),t.stateNode=e,sr(t))}return je(t),null;case 5:if(Gt(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==n&&sr(t);else{if(!n){if(t.stateNode===null)throw Error(d(166));return je(t),null}if(o=$.current,Rn(t))ud(t,o);else{var l=gi(J.current);switch(o){case 1:o=l.createElementNS("http://www.w3.org/2000/svg",a);break;case 2:o=l.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;default:switch(a){case"svg":o=l.createElementNS("http://www.w3.org/2000/svg",a);break;case"math":o=l.createElementNS("http://www.w3.org/1998/Math/MathML",a);break;case"script":o=l.createElement("div"),o.innerHTML="<script><\/script>",o=o.removeChild(o.firstChild);break;case"select":o=typeof n.is=="string"?l.createElement("select",{is:n.is}):l.createElement("select"),n.multiple?o.multiple=!0:n.size&&(o.size=n.size);break;default:o=typeof n.is=="string"?l.createElement(a,{is:n.is}):l.createElement(a)}}o[Je]=t,o[st]=n;e:for(l=t.child;l!==null;){if(l.tag===5||l.tag===6)o.appendChild(l.stateNode);else if(l.tag!==4&&l.tag!==27&&l.child!==null){l.child.return=l,l=l.child;continue}if(l===t)break e;for(;l.sibling===null;){if(l.return===null||l.return===t)break e;l=l.return}l.sibling.return=l.return,l=l.sibling}t.stateNode=o;e:switch(rt(o,a,n),a){case"button":case"input":case"select":case"textarea":n=!!n.autoFocus;break e;case"img":n=!0;break e;default:n=!1}n&&sr(t)}}return je(t),ws(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,r),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==n&&sr(t);else{if(typeof n!="string"&&t.stateNode===null)throw Error(d(166));if(e=J.current,Rn(t)){if(e=t.stateNode,r=t.memoizedProps,n=null,a=Ze,a!==null)switch(a.tag){case 27:case 5:n=a.memoizedProps}e[Je]=t,e=!!(e.nodeValue===r||n!==null&&n.suppressHydrationWarning===!0||jf(e.nodeValue,r)),e||_r(t,!0)}else e=gi(e).createTextNode(n),e[Je]=t,t.stateNode=e}return je(t),null;case 31:if(r=t.memoizedState,e===null||e.memoizedState!==null){if(n=Rn(t),r!==null){if(e===null){if(!n)throw Error(d(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(557));e[Je]=t}else an(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;je(t),e=!1}else r=jl(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=r),e=!0;if(!e)return t.flags&256?(xt(t),t):(xt(t),null);if((t.flags&128)!==0)throw Error(d(558))}return je(t),null;case 13:if(n=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=Rn(t),n!==null&&n.dehydrated!==null){if(e===null){if(!a)throw Error(d(318));if(a=t.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(d(317));a[Je]=t}else an(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;je(t),a=!1}else a=jl(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(xt(t),t):(xt(t),null)}return xt(t),(t.flags&128)!==0?(t.lanes=r,t):(r=n!==null,e=e!==null&&e.memoizedState!==null,r&&(n=t.child,a=null,n.alternate!==null&&n.alternate.memoizedState!==null&&n.alternate.memoizedState.cachePool!==null&&(a=n.alternate.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==a&&(n.flags|=2048)),r!==e&&r&&(t.child.flags|=8192),Go(t,t.updateQueue),je(t),null);case 4:return Le(),e===null&&Us(t.stateNode.containerInfo),je(t),null;case 10:return ar(t.type),je(t),null;case 19:if(A(De),n=t.memoizedState,n===null)return je(t),null;if(a=(t.flags&128)!==0,o=n.rendering,o===null)if(a)Aa(n,!1);else{if(Me!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(o=Fo(e),o!==null){for(t.flags|=128,Aa(n,!1),e=o.updateQueue,t.updateQueue=e,Go(t,e),t.subtreeFlags=0,e=r,r=t.child;r!==null;)od(r,e),r=r.sibling;return F(De,De.current&1|2),ue&&rr(t,n.treeForkCount),t.child}e=e.sibling}n.tail!==null&&gt()>ni&&(t.flags|=128,a=!0,Aa(n,!1),t.lanes=4194304)}else{if(!a)if(e=Fo(o),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,Go(t,e),Aa(n,!0),n.tail===null&&n.tailMode==="hidden"&&!o.alternate&&!ue)return je(t),null}else 2*gt()-n.renderingStartTime>ni&&r!==536870912&&(t.flags|=128,a=!0,Aa(n,!1),t.lanes=4194304);n.isBackwards?(o.sibling=t.child,t.child=o):(e=n.last,e!==null?e.sibling=o:t.child=o,n.last=o)}return n.tail!==null?(e=n.tail,n.rendering=e,n.tail=e.sibling,n.renderingStartTime=gt(),e.sibling=null,r=De.current,F(De,a?r&1|2:r&1),ue&&rr(t,n.treeForkCount),e):(je(t),null);case 22:case 23:return xt(t),Vl(),n=t.memoizedState!==null,e!==null?e.memoizedState!==null!==n&&(t.flags|=8192):n&&(t.flags|=8192),n?(r&536870912)!==0&&(t.flags&128)===0&&(je(t),t.subtreeFlags&6&&(t.flags|=8192)):je(t),r=t.updateQueue,r!==null&&Go(t,r.retryQueue),r=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(r=e.memoizedState.cachePool.pool),n=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(n=t.memoizedState.cachePool.pool),n!==r&&(t.flags|=2048),e!==null&&A(sn),null;case 24:return r=null,e!==null&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),ar($e),je(t),null;case 25:return null;case 30:return null}throw Error(d(156,t.tag))}function d0(e,t){switch(Nl(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return ar($e),Le(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Gt(t),null;case 31:if(t.memoizedState!==null){if(xt(t),t.alternate===null)throw Error(d(340));an()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(xt(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(d(340));an()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return A(De),null;case 4:return Le(),null;case 10:return ar(t.type),null;case 22:case 23:return xt(t),Vl(),e!==null&&A(sn),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return ar($e),null;case 25:return null;default:return null}}function Tp(e,t){switch(Nl(t),t.tag){case 3:ar($e),Le();break;case 26:case 27:case 5:Gt(t);break;case 4:Le();break;case 31:t.memoizedState!==null&&xt(t);break;case 13:xt(t);break;case 19:A(De);break;case 10:ar(t.type);break;case 22:case 23:xt(t),Vl(),e!==null&&A(sn);break;case 24:ar($e)}}function Ra(e,t){try{var r=t.updateQueue,n=r!==null?r.lastEffect:null;if(n!==null){var a=n.next;r=a;do{if((r.tag&e)===e){n=void 0;var o=r.create,l=r.inst;n=o(),l.destroy=n}r=r.next}while(r!==a)}}catch(u){xe(t,t.return,u)}}function Lr(e,t,r){try{var n=t.updateQueue,a=n!==null?n.lastEffect:null;if(a!==null){var o=a.next;n=o;do{if((n.tag&e)===e){var l=n.inst,u=l.destroy;if(u!==void 0){l.destroy=void 0,a=t;var f=r,v=u;try{v()}catch(P){xe(a,f,P)}}}n=n.next}while(n!==o)}}catch(P){xe(t,t.return,P)}}function Ap(e){var t=e.updateQueue;if(t!==null){var r=e.stateNode;try{Sd(t,r)}catch(n){xe(e,e.return,n)}}}function Rp(e,t,r){r.props=fn(e.type,e.memoizedProps),r.state=e.memoizedState;try{r.componentWillUnmount()}catch(n){xe(e,t,n)}}function Oa(e,t){try{var r=e.ref;if(r!==null){switch(e.tag){case 26:case 27:case 5:var n=e.stateNode;break;case 30:n=e.stateNode;break;default:n=e.stateNode}typeof r=="function"?e.refCleanup=r(n):r.current=n}}catch(a){xe(e,t,a)}}function Wt(e,t){var r=e.ref,n=e.refCleanup;if(r!==null)if(typeof n=="function")try{n()}catch(a){xe(e,t,a)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof r=="function")try{r(null)}catch(a){xe(e,t,a)}else r.current=null}function Op(e){var t=e.type,r=e.memoizedProps,n=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":r.autoFocus&&n.focus();break e;case"img":r.src?n.src=r.src:r.srcSet&&(n.srcset=r.srcSet)}}catch(a){xe(e,e.return,a)}}function xs(e,t,r){try{var n=e.stateNode;L0(n,e.type,r,t),n[st]=t}catch(a){xe(e,e.return,a)}}function Mp(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Fr(e.type)||e.tag===4}function ks(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Mp(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Fr(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ss(e,t,r){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?(r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r).insertBefore(e,t):(t=r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r,t.appendChild(e),r=r._reactRootContainer,r!=null||t.onclick!==null||(t.onclick=Zt));else if(n!==4&&(n===27&&Fr(e.type)&&(r=e.stateNode,t=null),e=e.child,e!==null))for(Ss(e,t,r),e=e.sibling;e!==null;)Ss(e,t,r),e=e.sibling}function Jo(e,t,r){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?r.insertBefore(e,t):r.appendChild(e);else if(n!==4&&(n===27&&Fr(e.type)&&(r=e.stateNode),e=e.child,e!==null))for(Jo(e,t,r),e=e.sibling;e!==null;)Jo(e,t,r),e=e.sibling}function Dp(e){var t=e.stateNode,r=e.memoizedProps;try{for(var n=e.type,a=t.attributes;a.length;)t.removeAttributeNode(a[0]);rt(t,n,r),t[Je]=e,t[st]=r}catch(o){xe(e,e.return,o)}}var cr=!1,qe=!1,_s=!1,Fp=typeof WeakSet=="function"?WeakSet:Set,Xe=null;function p0(e,t){if(e=e.containerInfo,Vs=ki,e=Xu(e),bl(e)){if("selectionStart"in e)var r={start:e.selectionStart,end:e.selectionEnd};else e:{r=(r=e.ownerDocument)&&r.defaultView||window;var n=r.getSelection&&r.getSelection();if(n&&n.rangeCount!==0){r=n.anchorNode;var a=n.anchorOffset,o=n.focusNode;n=n.focusOffset;try{r.nodeType,o.nodeType}catch{r=null;break e}var l=0,u=-1,f=-1,v=0,P=0,T=e,y=null;t:for(;;){for(var _;T!==r||a!==0&&T.nodeType!==3||(u=l+a),T!==o||n!==0&&T.nodeType!==3||(f=l+n),T.nodeType===3&&(l+=T.nodeValue.length),(_=T.firstChild)!==null;)y=T,T=_;for(;;){if(T===e)break t;if(y===r&&++v===a&&(u=l),y===o&&++P===n&&(f=l),(_=T.nextSibling)!==null)break;T=y,y=T.parentNode}T=_}r=u===-1||f===-1?null:{start:u,end:f}}else r=null}r=r||{start:0,end:0}}else r=null;for(qs={focusedElem:e,selectionRange:r},ki=!1,Xe=t;Xe!==null;)if(t=Xe,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,Xe=e;else for(;Xe!==null;){switch(t=Xe,o=t.alternate,e=t.flags,t.tag){case 0:if((e&4)!==0&&(e=t.updateQueue,e=e!==null?e.events:null,e!==null))for(r=0;r<e.length;r++)a=e[r],a.ref.impl=a.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&o!==null){e=void 0,r=t,a=o.memoizedProps,o=o.memoizedState,n=r.stateNode;try{var q=fn(r.type,a);e=n.getSnapshotBeforeUpdate(q,o),n.__reactInternalSnapshotBeforeUpdate=e}catch(X){xe(r,r.return,X)}}break;case 3:if((e&1024)!==0){if(e=t.stateNode.containerInfo,r=e.nodeType,r===9)Qs(e);else if(r===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":Qs(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(d(163))}if(e=t.sibling,e!==null){e.return=t.return,Xe=e;break}Xe=t.return}}function Ip(e,t,r){var n=r.flags;switch(r.tag){case 0:case 11:case 15:dr(e,r),n&4&&Ra(5,r);break;case 1:if(dr(e,r),n&4)if(e=r.stateNode,t===null)try{e.componentDidMount()}catch(l){xe(r,r.return,l)}else{var a=fn(r.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(a,t,e.__reactInternalSnapshotBeforeUpdate)}catch(l){xe(r,r.return,l)}}n&64&&Ap(r),n&512&&Oa(r,r.return);break;case 3:if(dr(e,r),n&64&&(e=r.updateQueue,e!==null)){if(t=null,r.child!==null)switch(r.child.tag){case 27:case 5:t=r.child.stateNode;break;case 1:t=r.child.stateNode}try{Sd(e,t)}catch(l){xe(r,r.return,l)}}break;case 27:t===null&&n&4&&Dp(r);case 26:case 5:dr(e,r),t===null&&n&4&&Op(r),n&512&&Oa(r,r.return);break;case 12:dr(e,r);break;case 31:dr(e,r),n&4&&Hp(e,r);break;case 13:dr(e,r),n&4&&Vp(e,r),n&64&&(e=r.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(r=x0.bind(null,r),I0(e,r))));break;case 22:if(n=r.memoizedState!==null||cr,!n){t=t!==null&&t.memoizedState!==null||qe,a=cr;var o=qe;cr=n,(qe=t)&&!o?pr(e,r,(r.subtreeFlags&8772)!==0):dr(e,r),cr=a,qe=o}break;case 30:break;default:dr(e,r)}}function Up(e){var t=e.alternate;t!==null&&(e.alternate=null,Up(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&el(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Te=null,ut=!1;function ur(e,t,r){for(r=r.child;r!==null;)$p(e,t,r),r=r.sibling}function $p(e,t,r){if(ht&&typeof ht.onCommitFiberUnmount=="function")try{ht.onCommitFiberUnmount(ia,r)}catch{}switch(r.tag){case 26:qe||Wt(r,t),ur(e,t,r),r.memoizedState?r.memoizedState.count--:r.stateNode&&(r=r.stateNode,r.parentNode.removeChild(r));break;case 27:qe||Wt(r,t);var n=Te,a=ut;Fr(r.type)&&(Te=r.stateNode,ut=!1),ur(e,t,r),qa(r.stateNode),Te=n,ut=a;break;case 5:qe||Wt(r,t);case 6:if(n=Te,a=ut,Te=null,ur(e,t,r),Te=n,ut=a,Te!==null)if(ut)try{(Te.nodeType===9?Te.body:Te.nodeName==="HTML"?Te.ownerDocument.body:Te).removeChild(r.stateNode)}catch(o){xe(r,t,o)}else try{Te.removeChild(r.stateNode)}catch(o){xe(r,t,o)}break;case 18:Te!==null&&(ut?(e=Te,Mf(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,r.stateNode),ta(e)):Mf(Te,r.stateNode));break;case 4:n=Te,a=ut,Te=r.stateNode.containerInfo,ut=!0,ur(e,t,r),Te=n,ut=a;break;case 0:case 11:case 14:case 15:Lr(2,r,t),qe||Lr(4,r,t),ur(e,t,r);break;case 1:qe||(Wt(r,t),n=r.stateNode,typeof n.componentWillUnmount=="function"&&Rp(r,t,n)),ur(e,t,r);break;case 21:ur(e,t,r);break;case 22:qe=(n=qe)||r.memoizedState!==null,ur(e,t,r),qe=n;break;default:ur(e,t,r)}}function Hp(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{ta(e)}catch(r){xe(t,t.return,r)}}}function Vp(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{ta(e)}catch(r){xe(t,t.return,r)}}function f0(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Fp),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Fp),t;default:throw Error(d(435,e.tag))}}function Zo(e,t){var r=f0(e);t.forEach(function(n){if(!r.has(n)){r.add(n);var a=k0.bind(null,e,n);n.then(a,a)}})}function dt(e,t){var r=t.deletions;if(r!==null)for(var n=0;n<r.length;n++){var a=r[n],o=e,l=t,u=l;e:for(;u!==null;){switch(u.tag){case 27:if(Fr(u.type)){Te=u.stateNode,ut=!1;break e}break;case 5:Te=u.stateNode,ut=!1;break e;case 3:case 4:Te=u.stateNode.containerInfo,ut=!0;break e}u=u.return}if(Te===null)throw Error(d(160));$p(o,l,a),Te=null,ut=!1,o=a.alternate,o!==null&&(o.return=null),a.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)qp(t,e),t=t.sibling}var Ft=null;function qp(e,t){var r=e.alternate,n=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:dt(t,e),pt(e),n&4&&(Lr(3,e,e.return),Ra(3,e),Lr(5,e,e.return));break;case 1:dt(t,e),pt(e),n&512&&(qe||r===null||Wt(r,r.return)),n&64&&cr&&(e=e.updateQueue,e!==null&&(n=e.callbacks,n!==null&&(r=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=r===null?n:r.concat(n))));break;case 26:var a=Ft;if(dt(t,e),pt(e),n&512&&(qe||r===null||Wt(r,r.return)),n&4){var o=r!==null?r.memoizedState:null;if(n=e.memoizedState,r===null)if(n===null)if(e.stateNode===null){e:{n=e.type,r=e.memoizedProps,a=a.ownerDocument||a;t:switch(n){case"title":o=a.getElementsByTagName("title")[0],(!o||o[ca]||o[Je]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=a.createElement(n),a.head.insertBefore(o,a.querySelector("head > title"))),rt(o,n,r),o[Je]=e,Ye(o),n=o;break e;case"link":var l=Qf("link","href",a).get(n+(r.href||""));if(l){for(var u=0;u<l.length;u++)if(o=l[u],o.getAttribute("href")===(r.href==null||r.href===""?null:r.href)&&o.getAttribute("rel")===(r.rel==null?null:r.rel)&&o.getAttribute("title")===(r.title==null?null:r.title)&&o.getAttribute("crossorigin")===(r.crossOrigin==null?null:r.crossOrigin)){l.splice(u,1);break t}}o=a.createElement(n),rt(o,n,r),a.head.appendChild(o);break;case"meta":if(l=Qf("meta","content",a).get(n+(r.content||""))){for(u=0;u<l.length;u++)if(o=l[u],o.getAttribute("content")===(r.content==null?null:""+r.content)&&o.getAttribute("name")===(r.name==null?null:r.name)&&o.getAttribute("property")===(r.property==null?null:r.property)&&o.getAttribute("http-equiv")===(r.httpEquiv==null?null:r.httpEquiv)&&o.getAttribute("charset")===(r.charSet==null?null:r.charSet)){l.splice(u,1);break t}}o=a.createElement(n),rt(o,n,r),a.head.appendChild(o);break;default:throw Error(d(468,n))}o[Je]=e,Ye(o),n=o}e.stateNode=n}else Kf(a,e.type,e.stateNode);else e.stateNode=Wf(a,n,e.memoizedProps);else o!==n?(o===null?r.stateNode!==null&&(r=r.stateNode,r.parentNode.removeChild(r)):o.count--,n===null?Kf(a,e.type,e.stateNode):Wf(a,n,e.memoizedProps)):n===null&&e.stateNode!==null&&xs(e,e.memoizedProps,r.memoizedProps)}break;case 27:dt(t,e),pt(e),n&512&&(qe||r===null||Wt(r,r.return)),r!==null&&n&4&&xs(e,e.memoizedProps,r.memoizedProps);break;case 5:if(dt(t,e),pt(e),n&512&&(qe||r===null||Wt(r,r.return)),e.flags&32){a=e.stateNode;try{Sn(a,"")}catch(q){xe(e,e.return,q)}}n&4&&e.stateNode!=null&&(a=e.memoizedProps,xs(e,a,r!==null?r.memoizedProps:a)),n&1024&&(_s=!0);break;case 6:if(dt(t,e),pt(e),n&4){if(e.stateNode===null)throw Error(d(162));n=e.memoizedProps,r=e.stateNode;try{r.nodeValue=n}catch(q){xe(e,e.return,q)}}break;case 3:if(vi=null,a=Ft,Ft=hi(t.containerInfo),dt(t,e),Ft=a,pt(e),n&4&&r!==null&&r.memoizedState.isDehydrated)try{ta(t.containerInfo)}catch(q){xe(e,e.return,q)}_s&&(_s=!1,Bp(e));break;case 4:n=Ft,Ft=hi(e.stateNode.containerInfo),dt(t,e),pt(e),Ft=n;break;case 12:dt(t,e),pt(e);break;case 31:dt(t,e),pt(e),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,Zo(e,n)));break;case 13:dt(t,e),pt(e),e.child.flags&8192&&e.memoizedState!==null!=(r!==null&&r.memoizedState!==null)&&(ti=gt()),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,Zo(e,n)));break;case 22:a=e.memoizedState!==null;var f=r!==null&&r.memoizedState!==null,v=cr,P=qe;if(cr=v||a,qe=P||f,dt(t,e),qe=P,cr=v,pt(e),n&8192)e:for(t=e.stateNode,t._visibility=a?t._visibility&-2:t._visibility|1,a&&(r===null||f||cr||qe||mn(e)),r=null,t=e;;){if(t.tag===5||t.tag===26){if(r===null){f=r=t;try{if(o=f.stateNode,a)l=o.style,typeof l.setProperty=="function"?l.setProperty("display","none","important"):l.display="none";else{u=f.stateNode;var T=f.memoizedProps.style,y=T!=null&&T.hasOwnProperty("display")?T.display:null;u.style.display=y==null||typeof y=="boolean"?"":(""+y).trim()}}catch(q){xe(f,f.return,q)}}}else if(t.tag===6){if(r===null){f=t;try{f.stateNode.nodeValue=a?"":f.memoizedProps}catch(q){xe(f,f.return,q)}}}else if(t.tag===18){if(r===null){f=t;try{var _=f.stateNode;a?Df(_,!0):Df(f.stateNode,!1)}catch(q){xe(f,f.return,q)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;r===t&&(r=null),t=t.return}r===t&&(r=null),t.sibling.return=t.return,t=t.sibling}n&4&&(n=e.updateQueue,n!==null&&(r=n.retryQueue,r!==null&&(n.retryQueue=null,Zo(e,r))));break;case 19:dt(t,e),pt(e),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,Zo(e,n)));break;case 30:break;case 21:break;default:dt(t,e),pt(e)}}function pt(e){var t=e.flags;if(t&2){try{for(var r,n=e.return;n!==null;){if(Mp(n)){r=n;break}n=n.return}if(r==null)throw Error(d(160));switch(r.tag){case 27:var a=r.stateNode,o=ks(e);Jo(e,o,a);break;case 5:var l=r.stateNode;r.flags&32&&(Sn(l,""),r.flags&=-33);var u=ks(e);Jo(e,u,l);break;case 3:case 4:var f=r.stateNode.containerInfo,v=ks(e);Ss(e,v,f);break;default:throw Error(d(161))}}catch(P){xe(e,e.return,P)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Bp(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Bp(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function dr(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Ip(e,t.alternate,t),t=t.sibling}function mn(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Lr(4,t,t.return),mn(t);break;case 1:Wt(t,t.return);var r=t.stateNode;typeof r.componentWillUnmount=="function"&&Rp(t,t.return,r),mn(t);break;case 27:qa(t.stateNode);case 26:case 5:Wt(t,t.return),mn(t);break;case 22:t.memoizedState===null&&mn(t);break;case 30:mn(t);break;default:mn(t)}e=e.sibling}}function pr(e,t,r){for(r=r&&(t.subtreeFlags&8772)!==0,t=t.child;t!==null;){var n=t.alternate,a=e,o=t,l=o.flags;switch(o.tag){case 0:case 11:case 15:pr(a,o,r),Ra(4,o);break;case 1:if(pr(a,o,r),n=o,a=n.stateNode,typeof a.componentDidMount=="function")try{a.componentDidMount()}catch(v){xe(n,n.return,v)}if(n=o,a=n.updateQueue,a!==null){var u=n.stateNode;try{var f=a.shared.hiddenCallbacks;if(f!==null)for(a.shared.hiddenCallbacks=null,a=0;a<f.length;a++)kd(f[a],u)}catch(v){xe(n,n.return,v)}}r&&l&64&&Ap(o),Oa(o,o.return);break;case 27:Dp(o);case 26:case 5:pr(a,o,r),r&&n===null&&l&4&&Op(o),Oa(o,o.return);break;case 12:pr(a,o,r);break;case 31:pr(a,o,r),r&&l&4&&Hp(a,o);break;case 13:pr(a,o,r),r&&l&4&&Vp(a,o);break;case 22:o.memoizedState===null&&pr(a,o,r),Oa(o,o.return);break;case 30:break;default:pr(a,o,r)}t=t.sibling}}function zs(e,t){var r=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(r=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==r&&(e!=null&&e.refCount++,r!=null&&xa(r))}function Cs(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&xa(e))}function It(e,t,r,n){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)Wp(e,t,r,n),t=t.sibling}function Wp(e,t,r,n){var a=t.flags;switch(t.tag){case 0:case 11:case 15:It(e,t,r,n),a&2048&&Ra(9,t);break;case 1:It(e,t,r,n);break;case 3:It(e,t,r,n),a&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&xa(e)));break;case 12:if(a&2048){It(e,t,r,n),e=t.stateNode;try{var o=t.memoizedProps,l=o.id,u=o.onPostCommit;typeof u=="function"&&u(l,t.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(f){xe(t,t.return,f)}}else It(e,t,r,n);break;case 31:It(e,t,r,n);break;case 13:It(e,t,r,n);break;case 23:break;case 22:o=t.stateNode,l=t.alternate,t.memoizedState!==null?o._visibility&2?It(e,t,r,n):Ma(e,t):o._visibility&2?It(e,t,r,n):(o._visibility|=2,qn(e,t,r,n,(t.subtreeFlags&10256)!==0||!1)),a&2048&&zs(l,t);break;case 24:It(e,t,r,n),a&2048&&Cs(t.alternate,t);break;default:It(e,t,r,n)}}function qn(e,t,r,n,a){for(a=a&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var o=e,l=t,u=r,f=n,v=l.flags;switch(l.tag){case 0:case 11:case 15:qn(o,l,u,f,a),Ra(8,l);break;case 23:break;case 22:var P=l.stateNode;l.memoizedState!==null?P._visibility&2?qn(o,l,u,f,a):Ma(o,l):(P._visibility|=2,qn(o,l,u,f,a)),a&&v&2048&&zs(l.alternate,l);break;case 24:qn(o,l,u,f,a),a&&v&2048&&Cs(l.alternate,l);break;default:qn(o,l,u,f,a)}t=t.sibling}}function Ma(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var r=e,n=t,a=n.flags;switch(n.tag){case 22:Ma(r,n),a&2048&&zs(n.alternate,n);break;case 24:Ma(r,n),a&2048&&Cs(n.alternate,n);break;default:Ma(r,n)}t=t.sibling}}var Da=8192;function Bn(e,t,r){if(e.subtreeFlags&Da)for(e=e.child;e!==null;)Qp(e,t,r),e=e.sibling}function Qp(e,t,r){switch(e.tag){case 26:Bn(e,t,r),e.flags&Da&&e.memoizedState!==null&&G0(r,Ft,e.memoizedState,e.memoizedProps);break;case 5:Bn(e,t,r);break;case 3:case 4:var n=Ft;Ft=hi(e.stateNode.containerInfo),Bn(e,t,r),Ft=n;break;case 22:e.memoizedState===null&&(n=e.alternate,n!==null&&n.memoizedState!==null?(n=Da,Da=16777216,Bn(e,t,r),Da=n):Bn(e,t,r));break;default:Bn(e,t,r)}}function Kp(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Fa(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var r=0;r<t.length;r++){var n=t[r];Xe=n,Xp(n,e)}Kp(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Yp(e),e=e.sibling}function Yp(e){switch(e.tag){case 0:case 11:case 15:Fa(e),e.flags&2048&&Lr(9,e,e.return);break;case 3:Fa(e);break;case 12:Fa(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,ei(e)):Fa(e);break;default:Fa(e)}}function ei(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var r=0;r<t.length;r++){var n=t[r];Xe=n,Xp(n,e)}Kp(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Lr(8,t,t.return),ei(t);break;case 22:r=t.stateNode,r._visibility&2&&(r._visibility&=-3,ei(t));break;default:ei(t)}e=e.sibling}}function Xp(e,t){for(;Xe!==null;){var r=Xe;switch(r.tag){case 0:case 11:case 15:Lr(8,r,t);break;case 23:case 22:if(r.memoizedState!==null&&r.memoizedState.cachePool!==null){var n=r.memoizedState.cachePool.pool;n!=null&&n.refCount++}break;case 24:xa(r.memoizedState.cache)}if(n=r.child,n!==null)n.return=r,Xe=n;else e:for(r=e;Xe!==null;){n=Xe;var a=n.sibling,o=n.return;if(Up(n),n===r){Xe=null;break e}if(a!==null){a.return=o,Xe=a;break e}Xe=o}}}var m0={getCacheForType:function(e){var t=et($e),r=t.data.get(e);return r===void 0&&(r=e(),t.data.set(e,r)),r},cacheSignal:function(){return et($e).controller.signal}},g0=typeof WeakMap=="function"?WeakMap:Map,ve=0,Ce=null,ne=null,ie=0,we=0,kt=null,Tr=!1,Wn=!1,Es=!1,fr=0,Me=0,Ar=0,gn=0,Ns=0,St=0,Qn=0,Ia=null,ft=null,Ps=!1,ti=0,Gp=0,ni=1/0,ai=null,Rr=null,We=0,Or=null,Kn=null,mr=0,js=0,Ls=null,Jp=null,Ua=0,Ts=null;function _t(){return(ve&2)!==0&&ie!==0?ie&-ie:M.T!==null?Fs():gu()}function Zp(){if(St===0)if((ie&536870912)===0||ue){var e=co;co<<=1,(co&3932160)===0&&(co=262144),St=e}else St=536870912;return e=wt.current,e!==null&&(e.flags|=32),St}function mt(e,t,r){(e===Ce&&(we===2||we===9)||e.cancelPendingCommit!==null)&&(Yn(e,0),Mr(e,ie,St,!1)),sa(e,r),((ve&2)===0||e!==Ce)&&(e===Ce&&((ve&2)===0&&(gn|=r),Me===4&&Mr(e,ie,St,!1)),Qt(e))}function ef(e,t,r){if((ve&6)!==0)throw Error(d(327));var n=!r&&(t&127)===0&&(t&e.expiredLanes)===0||la(e,t),a=n?v0(e,t):Rs(e,t,!0),o=n;do{if(a===0){Wn&&!n&&Mr(e,t,0,!1);break}else{if(r=e.current.alternate,o&&!h0(r)){a=Rs(e,t,!1),o=!1;continue}if(a===2){if(o=t,e.errorRecoveryDisabledLanes&o)var l=0;else l=e.pendingLanes&-536870913,l=l!==0?l:l&536870912?536870912:0;if(l!==0){t=l;e:{var u=e;a=Ia;var f=u.current.memoizedState.isDehydrated;if(f&&(Yn(u,l).flags|=256),l=Rs(u,l,!1),l!==2){if(Es&&!f){u.errorRecoveryDisabledLanes|=o,gn|=o,a=4;break e}o=ft,ft=a,o!==null&&(ft===null?ft=o:ft.push.apply(ft,o))}a=l}if(o=!1,a!==2)continue}}if(a===1){Yn(e,0),Mr(e,t,0,!0);break}e:{switch(n=e,o=a,o){case 0:case 1:throw Error(d(345));case 4:if((t&4194048)!==t)break;case 6:Mr(n,t,St,!Tr);break e;case 2:ft=null;break;case 3:case 5:break;default:throw Error(d(329))}if((t&62914560)===t&&(a=ti+300-gt(),10<a)){if(Mr(n,t,St,!Tr),po(n,0,!0)!==0)break e;mr=t,n.timeoutHandle=Rf(tf.bind(null,n,r,ft,ai,Ps,t,St,gn,Qn,Tr,o,"Throttled",-0,0),a);break e}tf(n,r,ft,ai,Ps,t,St,gn,Qn,Tr,o,null,-0,0)}}break}while(!0);Qt(e)}function tf(e,t,r,n,a,o,l,u,f,v,P,T,y,_){if(e.timeoutHandle=-1,T=t.subtreeFlags,T&8192||(T&16785408)===16785408){T={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Zt},Qp(t,o,T);var q=(o&62914560)===o?ti-gt():(o&4194048)===o?Gp-gt():0;if(q=J0(T,q),q!==null){mr=o,e.cancelPendingCommit=q(uf.bind(null,e,t,o,r,n,a,l,u,f,P,T,null,y,_)),Mr(e,o,l,!v);return}}uf(e,t,o,r,n,a,l,u,f)}function h0(e){for(var t=e;;){var r=t.tag;if((r===0||r===11||r===15)&&t.flags&16384&&(r=t.updateQueue,r!==null&&(r=r.stores,r!==null)))for(var n=0;n<r.length;n++){var a=r[n],o=a.getSnapshot;a=a.value;try{if(!vt(o(),a))return!1}catch{return!1}}if(r=t.child,t.subtreeFlags&16384&&r!==null)r.return=t,t=r;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Mr(e,t,r,n){t&=~Ns,t&=~gn,e.suspendedLanes|=t,e.pingedLanes&=~t,n&&(e.warmLanes|=t),n=e.expirationTimes;for(var a=t;0<a;){var o=31-bt(a),l=1<<o;n[o]=-1,a&=~l}r!==0&&pu(e,r,t)}function oi(){return(ve&6)===0?($a(0,!1),!1):!0}function As(){if(ne!==null){if(we===0)var e=ne.return;else e=ne,nr=on=null,Yl(e),In=null,Sa=0,e=ne;for(;e!==null;)Tp(e.alternate,e),e=e.return;ne=null}}function Yn(e,t){var r=e.timeoutHandle;r!==-1&&(e.timeoutHandle=-1,R0(r)),r=e.cancelPendingCommit,r!==null&&(e.cancelPendingCommit=null,r()),mr=0,As(),Ce=e,ne=r=tr(e.current,null),ie=t,we=0,kt=null,Tr=!1,Wn=la(e,t),Es=!1,Qn=St=Ns=gn=Ar=Me=0,ft=Ia=null,Ps=!1,(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var a=31-bt(n),o=1<<a;t|=e[a],n&=~o}return fr=t,zo(),r}function rf(e,t){Z=null,M.H=La,t===Fn||t===Ao?(t=vd(),we=3):t===Dl?(t=vd(),we=4):we=t===ds?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,kt=t,ne===null&&(Me=1,Qo(e,Et(t,e.current)))}function nf(){var e=wt.current;return e===null?!0:(ie&4194048)===ie?Dt===null:(ie&62914560)===ie||(ie&536870912)!==0?e===Dt:!1}function af(){var e=M.H;return M.H=La,e===null?La:e}function of(){var e=M.A;return M.A=m0,e}function ii(){Me=4,Tr||(ie&4194048)!==ie&&wt.current!==null||(Wn=!0),(Ar&134217727)===0&&(gn&134217727)===0||Ce===null||Mr(Ce,ie,St,!1)}function Rs(e,t,r){var n=ve;ve|=2;var a=af(),o=of();(Ce!==e||ie!==t)&&(ai=null,Yn(e,t)),t=!1;var l=Me;e:do try{if(we!==0&&ne!==null){var u=ne,f=kt;switch(we){case 8:As(),l=6;break e;case 3:case 2:case 9:case 6:wt.current===null&&(t=!0);var v=we;if(we=0,kt=null,Xn(e,u,f,v),r&&Wn){l=0;break e}break;default:v=we,we=0,kt=null,Xn(e,u,f,v)}}b0(),l=Me;break}catch(P){rf(e,P)}while(!0);return t&&e.shellSuspendCounter++,nr=on=null,ve=n,M.H=a,M.A=o,ne===null&&(Ce=null,ie=0,zo()),l}function b0(){for(;ne!==null;)lf(ne)}function v0(e,t){var r=ve;ve|=2;var n=af(),a=of();Ce!==e||ie!==t?(ai=null,ni=gt()+500,Yn(e,t)):Wn=la(e,t);e:do try{if(we!==0&&ne!==null){t=ne;var o=kt;t:switch(we){case 1:we=0,kt=null,Xn(e,t,o,1);break;case 2:case 9:if(hd(o)){we=0,kt=null,sf(t);break}t=function(){we!==2&&we!==9||Ce!==e||(we=7),Qt(e)},o.then(t,t);break e;case 3:we=7;break e;case 4:we=5;break e;case 7:hd(o)?(we=0,kt=null,sf(t)):(we=0,kt=null,Xn(e,t,o,7));break;case 5:var l=null;switch(ne.tag){case 26:l=ne.memoizedState;case 5:case 27:var u=ne;if(l?Yf(l):u.stateNode.complete){we=0,kt=null;var f=u.sibling;if(f!==null)ne=f;else{var v=u.return;v!==null?(ne=v,li(v)):ne=null}break t}}we=0,kt=null,Xn(e,t,o,5);break;case 6:we=0,kt=null,Xn(e,t,o,6);break;case 8:As(),Me=6;break e;default:throw Error(d(462))}}y0();break}catch(P){rf(e,P)}while(!0);return nr=on=null,M.H=n,M.A=a,ve=r,ne!==null?0:(Ce=null,ie=0,zo(),Me)}function y0(){for(;ne!==null&&!Hh();)lf(ne)}function lf(e){var t=jp(e.alternate,e,fr);e.memoizedProps=e.pendingProps,t===null?li(e):ne=t}function sf(e){var t=e,r=t.alternate;switch(t.tag){case 15:case 0:t=_p(r,t,t.pendingProps,t.type,void 0,ie);break;case 11:t=_p(r,t,t.pendingProps,t.type.render,t.ref,ie);break;case 5:Yl(t);default:Tp(r,t),t=ne=od(t,fr),t=jp(r,t,fr)}e.memoizedProps=e.pendingProps,t===null?li(e):ne=t}function Xn(e,t,r,n){nr=on=null,Yl(t),In=null,Sa=0;var a=t.return;try{if(l0(e,a,t,r,ie)){Me=1,Qo(e,Et(r,e.current)),ne=null;return}}catch(o){if(a!==null)throw ne=a,o;Me=1,Qo(e,Et(r,e.current)),ne=null;return}t.flags&32768?(ue||n===1?e=!0:Wn||(ie&536870912)!==0?e=!1:(Tr=e=!0,(n===2||n===9||n===3||n===6)&&(n=wt.current,n!==null&&n.tag===13&&(n.flags|=16384))),cf(t,e)):li(t)}function li(e){var t=e;do{if((t.flags&32768)!==0){cf(t,Tr);return}e=t.return;var r=u0(t.alternate,t,fr);if(r!==null){ne=r;return}if(t=t.sibling,t!==null){ne=t;return}ne=t=e}while(t!==null);Me===0&&(Me=5)}function cf(e,t){do{var r=d0(e.alternate,e);if(r!==null){r.flags&=32767,ne=r;return}if(r=e.return,r!==null&&(r.flags|=32768,r.subtreeFlags=0,r.deletions=null),!t&&(e=e.sibling,e!==null)){ne=e;return}ne=e=r}while(e!==null);Me=6,ne=null}function uf(e,t,r,n,a,o,l,u,f){e.cancelPendingCommit=null;do si();while(We!==0);if((ve&6)!==0)throw Error(d(327));if(t!==null){if(t===e.current)throw Error(d(177));if(o=t.lanes|t.childLanes,o|=kl,Jh(e,r,o,l,u,f),e===Ce&&(ne=Ce=null,ie=0),Kn=t,Or=e,mr=r,js=o,Ls=a,Jp=n,(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,S0(lo,function(){return gf(),null})):(e.callbackNode=null,e.callbackPriority=0),n=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||n){n=M.T,M.T=null,a=I.p,I.p=2,l=ve,ve|=4;try{p0(e,t,r)}finally{ve=l,I.p=a,M.T=n}}We=1,df(),pf(),ff()}}function df(){if(We===1){We=0;var e=Or,t=Kn,r=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||r){r=M.T,M.T=null;var n=I.p;I.p=2;var a=ve;ve|=4;try{qp(t,e);var o=qs,l=Xu(e.containerInfo),u=o.focusedElem,f=o.selectionRange;if(l!==u&&u&&u.ownerDocument&&Yu(u.ownerDocument.documentElement,u)){if(f!==null&&bl(u)){var v=f.start,P=f.end;if(P===void 0&&(P=v),"selectionStart"in u)u.selectionStart=v,u.selectionEnd=Math.min(P,u.value.length);else{var T=u.ownerDocument||document,y=T&&T.defaultView||window;if(y.getSelection){var _=y.getSelection(),q=u.textContent.length,X=Math.min(f.start,q),_e=f.end===void 0?X:Math.min(f.end,q);!_.extend&&X>_e&&(l=_e,_e=X,X=l);var h=Ku(u,X),m=Ku(u,_e);if(h&&m&&(_.rangeCount!==1||_.anchorNode!==h.node||_.anchorOffset!==h.offset||_.focusNode!==m.node||_.focusOffset!==m.offset)){var b=T.createRange();b.setStart(h.node,h.offset),_.removeAllRanges(),X>_e?(_.addRange(b),_.extend(m.node,m.offset)):(b.setEnd(m.node,m.offset),_.addRange(b))}}}}for(T=[],_=u;_=_.parentNode;)_.nodeType===1&&T.push({element:_,left:_.scrollLeft,top:_.scrollTop});for(typeof u.focus=="function"&&u.focus(),u=0;u<T.length;u++){var j=T[u];j.element.scrollLeft=j.left,j.element.scrollTop=j.top}}ki=!!Vs,qs=Vs=null}finally{ve=a,I.p=n,M.T=r}}e.current=t,We=2}}function pf(){if(We===2){We=0;var e=Or,t=Kn,r=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||r){r=M.T,M.T=null;var n=I.p;I.p=2;var a=ve;ve|=4;try{Ip(e,t.alternate,t)}finally{ve=a,I.p=n,M.T=r}}We=3}}function ff(){if(We===4||We===3){We=0,Vh();var e=Or,t=Kn,r=mr,n=Jp;(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?We=5:(We=0,Kn=Or=null,mf(e,e.pendingLanes));var a=e.pendingLanes;if(a===0&&(Rr=null),Ji(r),t=t.stateNode,ht&&typeof ht.onCommitFiberRoot=="function")try{ht.onCommitFiberRoot(ia,t,void 0,(t.current.flags&128)===128)}catch{}if(n!==null){t=M.T,a=I.p,I.p=2,M.T=null;try{for(var o=e.onRecoverableError,l=0;l<n.length;l++){var u=n[l];o(u.value,{componentStack:u.stack})}}finally{M.T=t,I.p=a}}(mr&3)!==0&&si(),Qt(e),a=e.pendingLanes,(r&261930)!==0&&(a&42)!==0?e===Ts?Ua++:(Ua=0,Ts=e):Ua=0,$a(0,!1)}}function mf(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,xa(t)))}function si(){return df(),pf(),ff(),gf()}function gf(){if(We!==5)return!1;var e=Or,t=js;js=0;var r=Ji(mr),n=M.T,a=I.p;try{I.p=32>r?32:r,M.T=null,r=Ls,Ls=null;var o=Or,l=mr;if(We=0,Kn=Or=null,mr=0,(ve&6)!==0)throw Error(d(331));var u=ve;if(ve|=4,Yp(o.current),Wp(o,o.current,l,r),ve=u,$a(0,!1),ht&&typeof ht.onPostCommitFiberRoot=="function")try{ht.onPostCommitFiberRoot(ia,o)}catch{}return!0}finally{I.p=a,M.T=n,mf(e,t)}}function hf(e,t,r){t=Et(r,t),t=us(e.stateNode,t,2),e=Nr(e,t,2),e!==null&&(sa(e,2),Qt(e))}function xe(e,t,r){if(e.tag===3)hf(e,e,r);else for(;t!==null;){if(t.tag===3){hf(t,e,r);break}else if(t.tag===1){var n=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof n.componentDidCatch=="function"&&(Rr===null||!Rr.has(n))){e=Et(r,e),r=hp(2),n=Nr(t,r,2),n!==null&&(bp(r,n,t,e),sa(n,2),Qt(n));break}}t=t.return}}function Os(e,t,r){var n=e.pingCache;if(n===null){n=e.pingCache=new g0;var a=new Set;n.set(t,a)}else a=n.get(t),a===void 0&&(a=new Set,n.set(t,a));a.has(r)||(Es=!0,a.add(r),e=w0.bind(null,e,t,r),t.then(e,e))}function w0(e,t,r){var n=e.pingCache;n!==null&&n.delete(t),e.pingedLanes|=e.suspendedLanes&r,e.warmLanes&=~r,Ce===e&&(ie&r)===r&&(Me===4||Me===3&&(ie&62914560)===ie&&300>gt()-ti?(ve&2)===0&&Yn(e,0):Ns|=r,Qn===ie&&(Qn=0)),Qt(e)}function bf(e,t){t===0&&(t=du()),e=rn(e,t),e!==null&&(sa(e,t),Qt(e))}function x0(e){var t=e.memoizedState,r=0;t!==null&&(r=t.retryLane),bf(e,r)}function k0(e,t){var r=0;switch(e.tag){case 31:case 13:var n=e.stateNode,a=e.memoizedState;a!==null&&(r=a.retryLane);break;case 19:n=e.stateNode;break;case 22:n=e.stateNode._retryCache;break;default:throw Error(d(314))}n!==null&&n.delete(t),bf(e,r)}function S0(e,t){return Ki(e,t)}var ci=null,Gn=null,Ms=!1,ui=!1,Ds=!1,Dr=0;function Qt(e){e!==Gn&&e.next===null&&(Gn===null?ci=Gn=e:Gn=Gn.next=e),ui=!0,Ms||(Ms=!0,z0())}function $a(e,t){if(!Ds&&ui){Ds=!0;do for(var r=!1,n=ci;n!==null;){if(!t)if(e!==0){var a=n.pendingLanes;if(a===0)var o=0;else{var l=n.suspendedLanes,u=n.pingedLanes;o=(1<<31-bt(42|e)+1)-1,o&=a&~(l&~u),o=o&201326741?o&201326741|1:o?o|2:0}o!==0&&(r=!0,xf(n,o))}else o=ie,o=po(n,n===Ce?o:0,n.cancelPendingCommit!==null||n.timeoutHandle!==-1),(o&3)===0||la(n,o)||(r=!0,xf(n,o));n=n.next}while(r);Ds=!1}}function _0(){vf()}function vf(){ui=Ms=!1;var e=0;Dr!==0&&A0()&&(e=Dr);for(var t=gt(),r=null,n=ci;n!==null;){var a=n.next,o=yf(n,t);o===0?(n.next=null,r===null?ci=a:r.next=a,a===null&&(Gn=r)):(r=n,(e!==0||(o&3)!==0)&&(ui=!0)),n=a}We!==0&&We!==5||$a(e,!1),Dr!==0&&(Dr=0)}function yf(e,t){for(var r=e.suspendedLanes,n=e.pingedLanes,a=e.expirationTimes,o=e.pendingLanes&-62914561;0<o;){var l=31-bt(o),u=1<<l,f=a[l];f===-1?((u&r)===0||(u&n)!==0)&&(a[l]=Gh(u,t)):f<=t&&(e.expiredLanes|=u),o&=~u}if(t=Ce,r=ie,r=po(e,e===t?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),n=e.callbackNode,r===0||e===t&&(we===2||we===9)||e.cancelPendingCommit!==null)return n!==null&&n!==null&&Yi(n),e.callbackNode=null,e.callbackPriority=0;if((r&3)===0||la(e,r)){if(t=r&-r,t===e.callbackPriority)return t;switch(n!==null&&Yi(n),Ji(r)){case 2:case 8:r=cu;break;case 32:r=lo;break;case 268435456:r=uu;break;default:r=lo}return n=wf.bind(null,e),r=Ki(r,n),e.callbackPriority=t,e.callbackNode=r,t}return n!==null&&n!==null&&Yi(n),e.callbackPriority=2,e.callbackNode=null,2}function wf(e,t){if(We!==0&&We!==5)return e.callbackNode=null,e.callbackPriority=0,null;var r=e.callbackNode;if(si()&&e.callbackNode!==r)return null;var n=ie;return n=po(e,e===Ce?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),n===0?null:(ef(e,n,t),yf(e,gt()),e.callbackNode!=null&&e.callbackNode===r?wf.bind(null,e):null)}function xf(e,t){if(si())return null;ef(e,t,!0)}function z0(){O0(function(){(ve&6)!==0?Ki(su,_0):vf()})}function Fs(){if(Dr===0){var e=Mn;e===0&&(e=so,so<<=1,(so&261888)===0&&(so=256)),Dr=e}return Dr}function kf(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:ho(""+e)}function Sf(e,t){var r=t.ownerDocument.createElement("input");return r.name=t.name,r.value=t.value,e.id&&r.setAttribute("form",e.id),t.parentNode.insertBefore(r,t),e=new FormData(e),r.parentNode.removeChild(r),e}function C0(e,t,r,n,a){if(t==="submit"&&r&&r.stateNode===a){var o=kf((a[st]||null).action),l=n.submitter;l&&(t=(t=l[st]||null)?kf(t.formAction):l.getAttribute("formAction"),t!==null&&(o=t,l=null));var u=new wo("action","action",null,n,a);e.push({event:u,listeners:[{instance:null,listener:function(){if(n.defaultPrevented){if(Dr!==0){var f=l?Sf(a,l):new FormData(a);as(r,{pending:!0,data:f,method:a.method,action:o},null,f)}}else typeof o=="function"&&(u.preventDefault(),f=l?Sf(a,l):new FormData(a),as(r,{pending:!0,data:f,method:a.method,action:o},o,f))},currentTarget:a}]})}}for(pi=0;pi<xl.length;pi++)di=xl[pi],_f=di.toLowerCase(),zf=di[0].toUpperCase()+di.slice(1),Mt(_f,"on"+zf);var di,_f,zf,pi;Mt(Zu,"onAnimationEnd"),Mt(ed,"onAnimationIteration"),Mt(td,"onAnimationStart"),Mt("dblclick","onDoubleClick"),Mt("focusin","onFocus"),Mt("focusout","onBlur"),Mt(qb,"onTransitionRun"),Mt(Bb,"onTransitionStart"),Mt(Wb,"onTransitionCancel"),Mt(rd,"onTransitionEnd"),xn("onMouseEnter",["mouseout","mouseover"]),xn("onMouseLeave",["mouseout","mouseover"]),xn("onPointerEnter",["pointerout","pointerover"]),xn("onPointerLeave",["pointerout","pointerover"]),Jr("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Jr("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Jr("onBeforeInput",["compositionend","keypress","textInput","paste"]),Jr("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Jr("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Jr("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ha="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),E0=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ha));function Cf(e,t){t=(t&4)!==0;for(var r=0;r<e.length;r++){var n=e[r],a=n.event;n=n.listeners;e:{var o=void 0;if(t)for(var l=n.length-1;0<=l;l--){var u=n[l],f=u.instance,v=u.currentTarget;if(u=u.listener,f!==o&&a.isPropagationStopped())break e;o=u,a.currentTarget=v;try{o(a)}catch(P){_o(P)}a.currentTarget=null,o=f}else for(l=0;l<n.length;l++){if(u=n[l],f=u.instance,v=u.currentTarget,u=u.listener,f!==o&&a.isPropagationStopped())break e;o=u,a.currentTarget=v;try{o(a)}catch(P){_o(P)}a.currentTarget=null,o=f}}}}function ae(e,t){var r=t[Zi];r===void 0&&(r=t[Zi]=new Set);var n=e+"__bubble";r.has(n)||(Ef(t,e,2,!1),r.add(n))}function Is(e,t,r){var n=0;t&&(n|=4),Ef(r,e,n,t)}var fi="_reactListening"+Math.random().toString(36).slice(2);function Us(e){if(!e[fi]){e[fi]=!0,vu.forEach(function(r){r!=="selectionchange"&&(E0.has(r)||Is(r,!1,e),Is(r,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[fi]||(t[fi]=!0,Is("selectionchange",!1,t))}}function Ef(e,t,r,n){switch(rm(t)){case 2:var a=tv;break;case 8:a=rv;break;default:a=tc}r=a.bind(null,t,r,e),a=void 0,!sl||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(a=!0),n?a!==void 0?e.addEventListener(t,r,{capture:!0,passive:a}):e.addEventListener(t,r,!0):a!==void 0?e.addEventListener(t,r,{passive:a}):e.addEventListener(t,r,!1)}function $s(e,t,r,n,a){var o=n;if((t&1)===0&&(t&2)===0&&n!==null)e:for(;;){if(n===null)return;var l=n.tag;if(l===3||l===4){var u=n.stateNode.containerInfo;if(u===a)break;if(l===4)for(l=n.return;l!==null;){var f=l.tag;if((f===3||f===4)&&l.stateNode.containerInfo===a)return;l=l.return}for(;u!==null;){if(l=vn(u),l===null)return;if(f=l.tag,f===5||f===6||f===26||f===27){n=o=l;continue e}u=u.parentNode}}n=n.return}ju(function(){var v=o,P=il(r),T=[];e:{var y=nd.get(e);if(y!==void 0){var _=wo,q=e;switch(e){case"keypress":if(vo(r)===0)break e;case"keydown":case"keyup":_=kb;break;case"focusin":q="focus",_=pl;break;case"focusout":q="blur",_=pl;break;case"beforeblur":case"afterblur":_=pl;break;case"click":if(r.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":_=Au;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":_=ub;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":_=zb;break;case Zu:case ed:case td:_=fb;break;case rd:_=Eb;break;case"scroll":case"scrollend":_=sb;break;case"wheel":_=Pb;break;case"copy":case"cut":case"paste":_=gb;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":_=Ou;break;case"toggle":case"beforetoggle":_=Lb}var X=(t&4)!==0,_e=!X&&(e==="scroll"||e==="scrollend"),h=X?y!==null?y+"Capture":null:y;X=[];for(var m=v,b;m!==null;){var j=m;if(b=j.stateNode,j=j.tag,j!==5&&j!==26&&j!==27||b===null||h===null||(j=da(m,h),j!=null&&X.push(Va(m,j,b))),_e)break;m=m.return}0<X.length&&(y=new _(y,q,null,r,P),T.push({event:y,listeners:X}))}}if((t&7)===0){e:{if(y=e==="mouseover"||e==="pointerover",_=e==="mouseout"||e==="pointerout",y&&r!==ol&&(q=r.relatedTarget||r.fromElement)&&(vn(q)||q[bn]))break e;if((_||y)&&(y=P.window===P?P:(y=P.ownerDocument)?y.defaultView||y.parentWindow:window,_?(q=r.relatedTarget||r.toElement,_=v,q=q?vn(q):null,q!==null&&(_e=L(q),X=q.tag,q!==_e||X!==5&&X!==27&&X!==6)&&(q=null)):(_=null,q=v),_!==q)){if(X=Au,j="onMouseLeave",h="onMouseEnter",m="mouse",(e==="pointerout"||e==="pointerover")&&(X=Ou,j="onPointerLeave",h="onPointerEnter",m="pointer"),_e=_==null?y:ua(_),b=q==null?y:ua(q),y=new X(j,m+"leave",_,r,P),y.target=_e,y.relatedTarget=b,j=null,vn(P)===v&&(X=new X(h,m+"enter",q,r,P),X.target=b,X.relatedTarget=_e,j=X),_e=j,_&&q)t:{for(X=N0,h=_,m=q,b=0,j=h;j;j=X(j))b++;j=0;for(var Q=m;Q;Q=X(Q))j++;for(;0<b-j;)h=X(h),b--;for(;0<j-b;)m=X(m),j--;for(;b--;){if(h===m||m!==null&&h===m.alternate){X=h;break t}h=X(h),m=X(m)}X=null}else X=null;_!==null&&Nf(T,y,_,X,!1),q!==null&&_e!==null&&Nf(T,_e,q,X,!0)}}e:{if(y=v?ua(v):window,_=y.nodeName&&y.nodeName.toLowerCase(),_==="select"||_==="input"&&y.type==="file")var ge=Vu;else if($u(y))if(qu)ge=$b;else{ge=Ib;var W=Fb}else _=y.nodeName,!_||_.toLowerCase()!=="input"||y.type!=="checkbox"&&y.type!=="radio"?v&&al(v.elementType)&&(ge=Vu):ge=Ub;if(ge&&(ge=ge(e,v))){Hu(T,ge,r,P);break e}W&&W(e,y,v),e==="focusout"&&v&&y.type==="number"&&v.memoizedProps.value!=null&&nl(y,"number",y.value)}switch(W=v?ua(v):window,e){case"focusin":($u(W)||W.contentEditable==="true")&&(Nn=W,vl=v,va=null);break;case"focusout":va=vl=Nn=null;break;case"mousedown":yl=!0;break;case"contextmenu":case"mouseup":case"dragend":yl=!1,Gu(T,r,P);break;case"selectionchange":if(Vb)break;case"keydown":case"keyup":Gu(T,r,P)}var ee;if(ml)e:{switch(e){case"compositionstart":var le="onCompositionStart";break e;case"compositionend":le="onCompositionEnd";break e;case"compositionupdate":le="onCompositionUpdate";break e}le=void 0}else En?Iu(e,r)&&(le="onCompositionEnd"):e==="keydown"&&r.keyCode===229&&(le="onCompositionStart");le&&(Mu&&r.locale!=="ko"&&(En||le!=="onCompositionStart"?le==="onCompositionEnd"&&En&&(ee=Lu()):(xr=P,cl="value"in xr?xr.value:xr.textContent,En=!0)),W=mi(v,le),0<W.length&&(le=new Ru(le,e,null,r,P),T.push({event:le,listeners:W}),ee?le.data=ee:(ee=Uu(r),ee!==null&&(le.data=ee)))),(ee=Ab?Rb(e,r):Ob(e,r))&&(le=mi(v,"onBeforeInput"),0<le.length&&(W=new Ru("onBeforeInput","beforeinput",null,r,P),T.push({event:W,listeners:le}),W.data=ee)),C0(T,e,v,r,P)}Cf(T,t)})}function Va(e,t,r){return{instance:e,listener:t,currentTarget:r}}function mi(e,t){for(var r=t+"Capture",n=[];e!==null;){var a=e,o=a.stateNode;if(a=a.tag,a!==5&&a!==26&&a!==27||o===null||(a=da(e,r),a!=null&&n.unshift(Va(e,a,o)),a=da(e,t),a!=null&&n.push(Va(e,a,o))),e.tag===3)return n;e=e.return}return[]}function N0(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Nf(e,t,r,n,a){for(var o=t._reactName,l=[];r!==null&&r!==n;){var u=r,f=u.alternate,v=u.stateNode;if(u=u.tag,f!==null&&f===n)break;u!==5&&u!==26&&u!==27||v===null||(f=v,a?(v=da(r,o),v!=null&&l.unshift(Va(r,v,f))):a||(v=da(r,o),v!=null&&l.push(Va(r,v,f)))),r=r.return}l.length!==0&&e.push({event:t,listeners:l})}var P0=/\r\n?/g,j0=/\u0000|\uFFFD/g;function Pf(e){return(typeof e=="string"?e:""+e).replace(P0,`
`).replace(j0,"")}function jf(e,t){return t=Pf(t),Pf(e)===t}function Se(e,t,r,n,a,o){switch(r){case"children":typeof n=="string"?t==="body"||t==="textarea"&&n===""||Sn(e,n):(typeof n=="number"||typeof n=="bigint")&&t!=="body"&&Sn(e,""+n);break;case"className":mo(e,"class",n);break;case"tabIndex":mo(e,"tabindex",n);break;case"dir":case"role":case"viewBox":case"width":case"height":mo(e,r,n);break;case"style":Nu(e,n,o);break;case"data":if(t!=="object"){mo(e,"data",n);break}case"src":case"href":if(n===""&&(t!=="a"||r!=="href")){e.removeAttribute(r);break}if(n==null||typeof n=="function"||typeof n=="symbol"||typeof n=="boolean"){e.removeAttribute(r);break}n=ho(""+n),e.setAttribute(r,n);break;case"action":case"formAction":if(typeof n=="function"){e.setAttribute(r,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof o=="function"&&(r==="formAction"?(t!=="input"&&Se(e,t,"name",a.name,a,null),Se(e,t,"formEncType",a.formEncType,a,null),Se(e,t,"formMethod",a.formMethod,a,null),Se(e,t,"formTarget",a.formTarget,a,null)):(Se(e,t,"encType",a.encType,a,null),Se(e,t,"method",a.method,a,null),Se(e,t,"target",a.target,a,null)));if(n==null||typeof n=="symbol"||typeof n=="boolean"){e.removeAttribute(r);break}n=ho(""+n),e.setAttribute(r,n);break;case"onClick":n!=null&&(e.onclick=Zt);break;case"onScroll":n!=null&&ae("scroll",e);break;case"onScrollEnd":n!=null&&ae("scrollend",e);break;case"dangerouslySetInnerHTML":if(n!=null){if(typeof n!="object"||!("__html"in n))throw Error(d(61));if(r=n.__html,r!=null){if(a.children!=null)throw Error(d(60));e.innerHTML=r}}break;case"multiple":e.multiple=n&&typeof n!="function"&&typeof n!="symbol";break;case"muted":e.muted=n&&typeof n!="function"&&typeof n!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(n==null||typeof n=="function"||typeof n=="boolean"||typeof n=="symbol"){e.removeAttribute("xlink:href");break}r=ho(""+n),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",r);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":n!=null&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(r,""+n):e.removeAttribute(r);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":n&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(r,""):e.removeAttribute(r);break;case"capture":case"download":n===!0?e.setAttribute(r,""):n!==!1&&n!=null&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(r,n):e.removeAttribute(r);break;case"cols":case"rows":case"size":case"span":n!=null&&typeof n!="function"&&typeof n!="symbol"&&!isNaN(n)&&1<=n?e.setAttribute(r,n):e.removeAttribute(r);break;case"rowSpan":case"start":n==null||typeof n=="function"||typeof n=="symbol"||isNaN(n)?e.removeAttribute(r):e.setAttribute(r,n);break;case"popover":ae("beforetoggle",e),ae("toggle",e),fo(e,"popover",n);break;case"xlinkActuate":Jt(e,"http://www.w3.org/1999/xlink","xlink:actuate",n);break;case"xlinkArcrole":Jt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",n);break;case"xlinkRole":Jt(e,"http://www.w3.org/1999/xlink","xlink:role",n);break;case"xlinkShow":Jt(e,"http://www.w3.org/1999/xlink","xlink:show",n);break;case"xlinkTitle":Jt(e,"http://www.w3.org/1999/xlink","xlink:title",n);break;case"xlinkType":Jt(e,"http://www.w3.org/1999/xlink","xlink:type",n);break;case"xmlBase":Jt(e,"http://www.w3.org/XML/1998/namespace","xml:base",n);break;case"xmlLang":Jt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",n);break;case"xmlSpace":Jt(e,"http://www.w3.org/XML/1998/namespace","xml:space",n);break;case"is":fo(e,"is",n);break;case"innerText":case"textContent":break;default:(!(2<r.length)||r[0]!=="o"&&r[0]!=="O"||r[1]!=="n"&&r[1]!=="N")&&(r=ib.get(r)||r,fo(e,r,n))}}function Hs(e,t,r,n,a,o){switch(r){case"style":Nu(e,n,o);break;case"dangerouslySetInnerHTML":if(n!=null){if(typeof n!="object"||!("__html"in n))throw Error(d(61));if(r=n.__html,r!=null){if(a.children!=null)throw Error(d(60));e.innerHTML=r}}break;case"children":typeof n=="string"?Sn(e,n):(typeof n=="number"||typeof n=="bigint")&&Sn(e,""+n);break;case"onScroll":n!=null&&ae("scroll",e);break;case"onScrollEnd":n!=null&&ae("scrollend",e);break;case"onClick":n!=null&&(e.onclick=Zt);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!yu.hasOwnProperty(r))e:{if(r[0]==="o"&&r[1]==="n"&&(a=r.endsWith("Capture"),t=r.slice(2,a?r.length-7:void 0),o=e[st]||null,o=o!=null?o[r]:null,typeof o=="function"&&e.removeEventListener(t,o,a),typeof n=="function")){typeof o!="function"&&o!==null&&(r in e?e[r]=null:e.hasAttribute(r)&&e.removeAttribute(r)),e.addEventListener(t,n,a);break e}r in e?e[r]=n:n===!0?e.setAttribute(r,""):fo(e,r,n)}}}function rt(e,t,r){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":ae("error",e),ae("load",e);var n=!1,a=!1,o;for(o in r)if(r.hasOwnProperty(o)){var l=r[o];if(l!=null)switch(o){case"src":n=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(d(137,t));default:Se(e,t,o,l,r,null)}}a&&Se(e,t,"srcSet",r.srcSet,r,null),n&&Se(e,t,"src",r.src,r,null);return;case"input":ae("invalid",e);var u=o=l=a=null,f=null,v=null;for(n in r)if(r.hasOwnProperty(n)){var P=r[n];if(P!=null)switch(n){case"name":a=P;break;case"type":l=P;break;case"checked":f=P;break;case"defaultChecked":v=P;break;case"value":o=P;break;case"defaultValue":u=P;break;case"children":case"dangerouslySetInnerHTML":if(P!=null)throw Error(d(137,t));break;default:Se(e,t,n,P,r,null)}}_u(e,o,u,f,v,l,a,!1);return;case"select":ae("invalid",e),n=l=o=null;for(a in r)if(r.hasOwnProperty(a)&&(u=r[a],u!=null))switch(a){case"value":o=u;break;case"defaultValue":l=u;break;case"multiple":n=u;default:Se(e,t,a,u,r,null)}t=o,r=l,e.multiple=!!n,t!=null?kn(e,!!n,t,!1):r!=null&&kn(e,!!n,r,!0);return;case"textarea":ae("invalid",e),o=a=n=null;for(l in r)if(r.hasOwnProperty(l)&&(u=r[l],u!=null))switch(l){case"value":n=u;break;case"defaultValue":a=u;break;case"children":o=u;break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(d(91));break;default:Se(e,t,l,u,r,null)}Cu(e,n,a,o);return;case"option":for(f in r)r.hasOwnProperty(f)&&(n=r[f],n!=null)&&(f==="selected"?e.selected=n&&typeof n!="function"&&typeof n!="symbol":Se(e,t,f,n,r,null));return;case"dialog":ae("beforetoggle",e),ae("toggle",e),ae("cancel",e),ae("close",e);break;case"iframe":case"object":ae("load",e);break;case"video":case"audio":for(n=0;n<Ha.length;n++)ae(Ha[n],e);break;case"image":ae("error",e),ae("load",e);break;case"details":ae("toggle",e);break;case"embed":case"source":case"link":ae("error",e),ae("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(v in r)if(r.hasOwnProperty(v)&&(n=r[v],n!=null))switch(v){case"children":case"dangerouslySetInnerHTML":throw Error(d(137,t));default:Se(e,t,v,n,r,null)}return;default:if(al(t)){for(P in r)r.hasOwnProperty(P)&&(n=r[P],n!==void 0&&Hs(e,t,P,n,r,void 0));return}}for(u in r)r.hasOwnProperty(u)&&(n=r[u],n!=null&&Se(e,t,u,n,r,null))}function L0(e,t,r,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var a=null,o=null,l=null,u=null,f=null,v=null,P=null;for(_ in r){var T=r[_];if(r.hasOwnProperty(_)&&T!=null)switch(_){case"checked":break;case"value":break;case"defaultValue":f=T;default:n.hasOwnProperty(_)||Se(e,t,_,null,n,T)}}for(var y in n){var _=n[y];if(T=r[y],n.hasOwnProperty(y)&&(_!=null||T!=null))switch(y){case"type":o=_;break;case"name":a=_;break;case"checked":v=_;break;case"defaultChecked":P=_;break;case"value":l=_;break;case"defaultValue":u=_;break;case"children":case"dangerouslySetInnerHTML":if(_!=null)throw Error(d(137,t));break;default:_!==T&&Se(e,t,y,_,n,T)}}rl(e,l,u,f,v,P,o,a);return;case"select":_=l=u=y=null;for(o in r)if(f=r[o],r.hasOwnProperty(o)&&f!=null)switch(o){case"value":break;case"multiple":_=f;default:n.hasOwnProperty(o)||Se(e,t,o,null,n,f)}for(a in n)if(o=n[a],f=r[a],n.hasOwnProperty(a)&&(o!=null||f!=null))switch(a){case"value":y=o;break;case"defaultValue":u=o;break;case"multiple":l=o;default:o!==f&&Se(e,t,a,o,n,f)}t=u,r=l,n=_,y!=null?kn(e,!!r,y,!1):!!n!=!!r&&(t!=null?kn(e,!!r,t,!0):kn(e,!!r,r?[]:"",!1));return;case"textarea":_=y=null;for(u in r)if(a=r[u],r.hasOwnProperty(u)&&a!=null&&!n.hasOwnProperty(u))switch(u){case"value":break;case"children":break;default:Se(e,t,u,null,n,a)}for(l in n)if(a=n[l],o=r[l],n.hasOwnProperty(l)&&(a!=null||o!=null))switch(l){case"value":y=a;break;case"defaultValue":_=a;break;case"children":break;case"dangerouslySetInnerHTML":if(a!=null)throw Error(d(91));break;default:a!==o&&Se(e,t,l,a,n,o)}zu(e,y,_);return;case"option":for(var q in r)y=r[q],r.hasOwnProperty(q)&&y!=null&&!n.hasOwnProperty(q)&&(q==="selected"?e.selected=!1:Se(e,t,q,null,n,y));for(f in n)y=n[f],_=r[f],n.hasOwnProperty(f)&&y!==_&&(y!=null||_!=null)&&(f==="selected"?e.selected=y&&typeof y!="function"&&typeof y!="symbol":Se(e,t,f,y,n,_));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var X in r)y=r[X],r.hasOwnProperty(X)&&y!=null&&!n.hasOwnProperty(X)&&Se(e,t,X,null,n,y);for(v in n)if(y=n[v],_=r[v],n.hasOwnProperty(v)&&y!==_&&(y!=null||_!=null))switch(v){case"children":case"dangerouslySetInnerHTML":if(y!=null)throw Error(d(137,t));break;default:Se(e,t,v,y,n,_)}return;default:if(al(t)){for(var _e in r)y=r[_e],r.hasOwnProperty(_e)&&y!==void 0&&!n.hasOwnProperty(_e)&&Hs(e,t,_e,void 0,n,y);for(P in n)y=n[P],_=r[P],!n.hasOwnProperty(P)||y===_||y===void 0&&_===void 0||Hs(e,t,P,y,n,_);return}}for(var h in r)y=r[h],r.hasOwnProperty(h)&&y!=null&&!n.hasOwnProperty(h)&&Se(e,t,h,null,n,y);for(T in n)y=n[T],_=r[T],!n.hasOwnProperty(T)||y===_||y==null&&_==null||Se(e,t,T,y,n,_)}function Lf(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function T0(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,r=performance.getEntriesByType("resource"),n=0;n<r.length;n++){var a=r[n],o=a.transferSize,l=a.initiatorType,u=a.duration;if(o&&u&&Lf(l)){for(l=0,u=a.responseEnd,n+=1;n<r.length;n++){var f=r[n],v=f.startTime;if(v>u)break;var P=f.transferSize,T=f.initiatorType;P&&Lf(T)&&(f=f.responseEnd,l+=P*(f<u?1:(u-v)/(f-v)))}if(--n,t+=8*(o+l)/(a.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Vs=null,qs=null;function gi(e){return e.nodeType===9?e:e.ownerDocument}function Tf(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Af(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function Bs(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Ws=null;function A0(){var e=window.event;return e&&e.type==="popstate"?e===Ws?!1:(Ws=e,!0):(Ws=null,!1)}var Rf=typeof setTimeout=="function"?setTimeout:void 0,R0=typeof clearTimeout=="function"?clearTimeout:void 0,Of=typeof Promise=="function"?Promise:void 0,O0=typeof queueMicrotask=="function"?queueMicrotask:typeof Of<"u"?function(e){return Of.resolve(null).then(e).catch(M0)}:Rf;function M0(e){setTimeout(function(){throw e})}function Fr(e){return e==="head"}function Mf(e,t){var r=t,n=0;do{var a=r.nextSibling;if(e.removeChild(r),a&&a.nodeType===8)if(r=a.data,r==="/$"||r==="/&"){if(n===0){e.removeChild(a),ta(t);return}n--}else if(r==="$"||r==="$?"||r==="$~"||r==="$!"||r==="&")n++;else if(r==="html")qa(e.ownerDocument.documentElement);else if(r==="head"){r=e.ownerDocument.head,qa(r);for(var o=r.firstChild;o;){var l=o.nextSibling,u=o.nodeName;o[ca]||u==="SCRIPT"||u==="STYLE"||u==="LINK"&&o.rel.toLowerCase()==="stylesheet"||r.removeChild(o),o=l}}else r==="body"&&qa(e.ownerDocument.body);r=a}while(r);ta(t)}function Df(e,t){var r=e;e=0;do{var n=r.nextSibling;if(r.nodeType===1?t?(r._stashedDisplay=r.style.display,r.style.display="none"):(r.style.display=r._stashedDisplay||"",r.getAttribute("style")===""&&r.removeAttribute("style")):r.nodeType===3&&(t?(r._stashedText=r.nodeValue,r.nodeValue=""):r.nodeValue=r._stashedText||""),n&&n.nodeType===8)if(r=n.data,r==="/$"){if(e===0)break;e--}else r!=="$"&&r!=="$?"&&r!=="$~"&&r!=="$!"||e++;r=n}while(r)}function Qs(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var r=t;switch(t=t.nextSibling,r.nodeName){case"HTML":case"HEAD":case"BODY":Qs(r),el(r);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(r.rel.toLowerCase()==="stylesheet")continue}e.removeChild(r)}}function D0(e,t,r,n){for(;e.nodeType===1;){var a=r;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!n&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(n){if(!e[ca])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(o=e.getAttribute("rel"),o==="stylesheet"&&e.hasAttribute("data-precedence")||o!==a.rel||e.getAttribute("href")!==(a.href==null||a.href===""?null:a.href)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin)||e.getAttribute("title")!==(a.title==null?null:a.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(o=e.getAttribute("src"),(o!==(a.src==null?null:a.src)||e.getAttribute("type")!==(a.type==null?null:a.type)||e.getAttribute("crossorigin")!==(a.crossOrigin==null?null:a.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var o=a.name==null?null:""+a.name;if(a.type==="hidden"&&e.getAttribute("name")===o)return e}else return e;if(e=Lt(e.nextSibling),e===null)break}return null}function F0(e,t,r){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!r||(e=Lt(e.nextSibling),e===null))return null;return e}function Ff(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Lt(e.nextSibling),e===null))return null;return e}function Ks(e){return e.data==="$?"||e.data==="$~"}function Ys(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function I0(e,t){var r=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||r.readyState!=="loading")t();else{var n=function(){t(),r.removeEventListener("DOMContentLoaded",n)};r.addEventListener("DOMContentLoaded",n),e._reactRetry=n}}function Lt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Xs=null;function If(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var r=e.data;if(r==="/$"||r==="/&"){if(t===0)return Lt(e.nextSibling);t--}else r!=="$"&&r!=="$!"&&r!=="$?"&&r!=="$~"&&r!=="&"||t++}e=e.nextSibling}return null}function Uf(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var r=e.data;if(r==="$"||r==="$!"||r==="$?"||r==="$~"||r==="&"){if(t===0)return e;t--}else r!=="/$"&&r!=="/&"||t++}e=e.previousSibling}return null}function $f(e,t,r){switch(t=gi(r),e){case"html":if(e=t.documentElement,!e)throw Error(d(452));return e;case"head":if(e=t.head,!e)throw Error(d(453));return e;case"body":if(e=t.body,!e)throw Error(d(454));return e;default:throw Error(d(451))}}function qa(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);el(e)}var Tt=new Map,Hf=new Set;function hi(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var gr=I.d;I.d={f:U0,r:$0,D:H0,C:V0,L:q0,m:B0,X:Q0,S:W0,M:K0};function U0(){var e=gr.f(),t=oi();return e||t}function $0(e){var t=yn(e);t!==null&&t.tag===5&&t.type==="form"?rp(t):gr.r(e)}var Jn=typeof document>"u"?null:document;function Vf(e,t,r){var n=Jn;if(n&&typeof t=="string"&&t){var a=Ot(t);a='link[rel="'+e+'"][href="'+a+'"]',typeof r=="string"&&(a+='[crossorigin="'+r+'"]'),Hf.has(a)||(Hf.add(a),e={rel:e,crossOrigin:r,href:t},n.querySelector(a)===null&&(t=n.createElement("link"),rt(t,"link",e),Ye(t),n.head.appendChild(t)))}}function H0(e){gr.D(e),Vf("dns-prefetch",e,null)}function V0(e,t){gr.C(e,t),Vf("preconnect",e,t)}function q0(e,t,r){gr.L(e,t,r);var n=Jn;if(n&&e&&t){var a='link[rel="preload"][as="'+Ot(t)+'"]';t==="image"&&r&&r.imageSrcSet?(a+='[imagesrcset="'+Ot(r.imageSrcSet)+'"]',typeof r.imageSizes=="string"&&(a+='[imagesizes="'+Ot(r.imageSizes)+'"]')):a+='[href="'+Ot(e)+'"]';var o=a;switch(t){case"style":o=Zn(e);break;case"script":o=ea(e)}Tt.has(o)||(e=O({rel:"preload",href:t==="image"&&r&&r.imageSrcSet?void 0:e,as:t},r),Tt.set(o,e),n.querySelector(a)!==null||t==="style"&&n.querySelector(Ba(o))||t==="script"&&n.querySelector(Wa(o))||(t=n.createElement("link"),rt(t,"link",e),Ye(t),n.head.appendChild(t)))}}function B0(e,t){gr.m(e,t);var r=Jn;if(r&&e){var n=t&&typeof t.as=="string"?t.as:"script",a='link[rel="modulepreload"][as="'+Ot(n)+'"][href="'+Ot(e)+'"]',o=a;switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=ea(e)}if(!Tt.has(o)&&(e=O({rel:"modulepreload",href:e},t),Tt.set(o,e),r.querySelector(a)===null)){switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(r.querySelector(Wa(o)))return}n=r.createElement("link"),rt(n,"link",e),Ye(n),r.head.appendChild(n)}}}function W0(e,t,r){gr.S(e,t,r);var n=Jn;if(n&&e){var a=wn(n).hoistableStyles,o=Zn(e);t=t||"default";var l=a.get(o);if(!l){var u={loading:0,preload:null};if(l=n.querySelector(Ba(o)))u.loading=5;else{e=O({rel:"stylesheet",href:e,"data-precedence":t},r),(r=Tt.get(o))&&Gs(e,r);var f=l=n.createElement("link");Ye(f),rt(f,"link",e),f._p=new Promise(function(v,P){f.onload=v,f.onerror=P}),f.addEventListener("load",function(){u.loading|=1}),f.addEventListener("error",function(){u.loading|=2}),u.loading|=4,bi(l,t,n)}l={type:"stylesheet",instance:l,count:1,state:u},a.set(o,l)}}}function Q0(e,t){gr.X(e,t);var r=Jn;if(r&&e){var n=wn(r).hoistableScripts,a=ea(e),o=n.get(a);o||(o=r.querySelector(Wa(a)),o||(e=O({src:e,async:!0},t),(t=Tt.get(a))&&Js(e,t),o=r.createElement("script"),Ye(o),rt(o,"link",e),r.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(a,o))}}function K0(e,t){gr.M(e,t);var r=Jn;if(r&&e){var n=wn(r).hoistableScripts,a=ea(e),o=n.get(a);o||(o=r.querySelector(Wa(a)),o||(e=O({src:e,async:!0,type:"module"},t),(t=Tt.get(a))&&Js(e,t),o=r.createElement("script"),Ye(o),rt(o,"link",e),r.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(a,o))}}function qf(e,t,r,n){var a=(a=J.current)?hi(a):null;if(!a)throw Error(d(446));switch(e){case"meta":case"title":return null;case"style":return typeof r.precedence=="string"&&typeof r.href=="string"?(t=Zn(r.href),r=wn(a).hoistableStyles,n=r.get(t),n||(n={type:"style",instance:null,count:0,state:null},r.set(t,n)),n):{type:"void",instance:null,count:0,state:null};case"link":if(r.rel==="stylesheet"&&typeof r.href=="string"&&typeof r.precedence=="string"){e=Zn(r.href);var o=wn(a).hoistableStyles,l=o.get(e);if(l||(a=a.ownerDocument||a,l={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},o.set(e,l),(o=a.querySelector(Ba(e)))&&!o._p&&(l.instance=o,l.state.loading=5),Tt.has(e)||(r={rel:"preload",as:"style",href:r.href,crossOrigin:r.crossOrigin,integrity:r.integrity,media:r.media,hrefLang:r.hrefLang,referrerPolicy:r.referrerPolicy},Tt.set(e,r),o||Y0(a,e,r,l.state))),t&&n===null)throw Error(d(528,""));return l}if(t&&n!==null)throw Error(d(529,""));return null;case"script":return t=r.async,r=r.src,typeof r=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(t=ea(r),r=wn(a).hoistableScripts,n=r.get(t),n||(n={type:"script",instance:null,count:0,state:null},r.set(t,n)),n):{type:"void",instance:null,count:0,state:null};default:throw Error(d(444,e))}}function Zn(e){return'href="'+Ot(e)+'"'}function Ba(e){return'link[rel="stylesheet"]['+e+"]"}function Bf(e){return O({},e,{"data-precedence":e.precedence,precedence:null})}function Y0(e,t,r,n){e.querySelector('link[rel="preload"][as="style"]['+t+"]")?n.loading=1:(t=e.createElement("link"),n.preload=t,t.addEventListener("load",function(){return n.loading|=1}),t.addEventListener("error",function(){return n.loading|=2}),rt(t,"link",r),Ye(t),e.head.appendChild(t))}function ea(e){return'[src="'+Ot(e)+'"]'}function Wa(e){return"script[async]"+e}function Wf(e,t,r){if(t.count++,t.instance===null)switch(t.type){case"style":var n=e.querySelector('style[data-href~="'+Ot(r.href)+'"]');if(n)return t.instance=n,Ye(n),n;var a=O({},r,{"data-href":r.href,"data-precedence":r.precedence,href:null,precedence:null});return n=(e.ownerDocument||e).createElement("style"),Ye(n),rt(n,"style",a),bi(n,r.precedence,e),t.instance=n;case"stylesheet":a=Zn(r.href);var o=e.querySelector(Ba(a));if(o)return t.state.loading|=4,t.instance=o,Ye(o),o;n=Bf(r),(a=Tt.get(a))&&Gs(n,a),o=(e.ownerDocument||e).createElement("link"),Ye(o);var l=o;return l._p=new Promise(function(u,f){l.onload=u,l.onerror=f}),rt(o,"link",n),t.state.loading|=4,bi(o,r.precedence,e),t.instance=o;case"script":return o=ea(r.src),(a=e.querySelector(Wa(o)))?(t.instance=a,Ye(a),a):(n=r,(a=Tt.get(o))&&(n=O({},r),Js(n,a)),e=e.ownerDocument||e,a=e.createElement("script"),Ye(a),rt(a,"link",n),e.head.appendChild(a),t.instance=a);case"void":return null;default:throw Error(d(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(n=t.instance,t.state.loading|=4,bi(n,r.precedence,e));return t.instance}function bi(e,t,r){for(var n=r.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),a=n.length?n[n.length-1]:null,o=a,l=0;l<n.length;l++){var u=n[l];if(u.dataset.precedence===t)o=u;else if(o!==a)break}o?o.parentNode.insertBefore(e,o.nextSibling):(t=r.nodeType===9?r.head:r,t.insertBefore(e,t.firstChild))}function Gs(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function Js(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var vi=null;function Qf(e,t,r){if(vi===null){var n=new Map,a=vi=new Map;a.set(r,n)}else a=vi,n=a.get(r),n||(n=new Map,a.set(r,n));if(n.has(e))return n;for(n.set(e,null),r=r.getElementsByTagName(e),a=0;a<r.length;a++){var o=r[a];if(!(o[ca]||o[Je]||e==="link"&&o.getAttribute("rel")==="stylesheet")&&o.namespaceURI!=="http://www.w3.org/2000/svg"){var l=o.getAttribute(t)||"";l=e+l;var u=n.get(l);u?u.push(o):n.set(l,[o])}}return n}function Kf(e,t,r){e=e.ownerDocument||e,e.head.insertBefore(r,t==="title"?e.querySelector("head > title"):null)}function X0(e,t,r){if(r===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function Yf(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function G0(e,t,r,n){if(r.type==="stylesheet"&&(typeof n.media!="string"||matchMedia(n.media).matches!==!1)&&(r.state.loading&4)===0){if(r.instance===null){var a=Zn(n.href),o=t.querySelector(Ba(a));if(o){t=o._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=yi.bind(e),t.then(e,e)),r.state.loading|=4,r.instance=o,Ye(o);return}o=t.ownerDocument||t,n=Bf(n),(a=Tt.get(a))&&Gs(n,a),o=o.createElement("link"),Ye(o);var l=o;l._p=new Promise(function(u,f){l.onload=u,l.onerror=f}),rt(o,"link",n),r.instance=o}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(r,t),(t=r.state.preload)&&(r.state.loading&3)===0&&(e.count++,r=yi.bind(e),t.addEventListener("load",r),t.addEventListener("error",r))}}var Zs=0;function J0(e,t){return e.stylesheets&&e.count===0&&xi(e,e.stylesheets),0<e.count||0<e.imgCount?function(r){var n=setTimeout(function(){if(e.stylesheets&&xi(e,e.stylesheets),e.unsuspend){var o=e.unsuspend;e.unsuspend=null,o()}},6e4+t);0<e.imgBytes&&Zs===0&&(Zs=62500*T0());var a=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&xi(e,e.stylesheets),e.unsuspend)){var o=e.unsuspend;e.unsuspend=null,o()}},(e.imgBytes>Zs?50:800)+t);return e.unsuspend=r,function(){e.unsuspend=null,clearTimeout(n),clearTimeout(a)}}:null}function yi(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)xi(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var wi=null;function xi(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,wi=new Map,t.forEach(Z0,e),wi=null,yi.call(e))}function Z0(e,t){if(!(t.state.loading&4)){var r=wi.get(e);if(r)var n=r.get(null);else{r=new Map,wi.set(e,r);for(var a=e.querySelectorAll("link[data-precedence],style[data-precedence]"),o=0;o<a.length;o++){var l=a[o];(l.nodeName==="LINK"||l.getAttribute("media")!=="not all")&&(r.set(l.dataset.precedence,l),n=l)}n&&r.set(null,n)}a=t.instance,l=a.getAttribute("data-precedence"),o=r.get(l)||n,o===n&&r.set(null,a),r.set(l,a),this.count++,n=yi.bind(this),a.addEventListener("load",n),a.addEventListener("error",n),o?o.parentNode.insertBefore(a,o.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(a,e.firstChild)),t.state.loading|=4}}var Qa={$$typeof:oe,Provider:null,Consumer:null,_currentValue:ce,_currentValue2:ce,_threadCount:0};function ev(e,t,r,n,a,o,l,u,f){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Xi(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Xi(0),this.hiddenUpdates=Xi(null),this.identifierPrefix=n,this.onUncaughtError=a,this.onCaughtError=o,this.onRecoverableError=l,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=f,this.incompleteTransitions=new Map}function Xf(e,t,r,n,a,o,l,u,f,v,P,T){return e=new ev(e,t,r,l,f,v,P,T,u),t=1,o===!0&&(t|=24),o=yt(3,null,null,t),e.current=o,o.stateNode=e,t=Rl(),t.refCount++,e.pooledCache=t,t.refCount++,o.memoizedState={element:n,isDehydrated:r,cache:t},Fl(o),e}function Gf(e){return e?(e=Ln,e):Ln}function Jf(e,t,r,n,a,o){a=Gf(a),n.context===null?n.context=a:n.pendingContext=a,n=Er(t),n.payload={element:r},o=o===void 0?null:o,o!==null&&(n.callback=o),r=Nr(e,n,t),r!==null&&(mt(r,e,t),za(r,e,t))}function Zf(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var r=e.retryLane;e.retryLane=r!==0&&r<t?r:t}}function ec(e,t){Zf(e,t),(e=e.alternate)&&Zf(e,t)}function em(e){if(e.tag===13||e.tag===31){var t=rn(e,67108864);t!==null&&mt(t,e,67108864),ec(e,67108864)}}function tm(e){if(e.tag===13||e.tag===31){var t=_t();t=Gi(t);var r=rn(e,t);r!==null&&mt(r,e,t),ec(e,t)}}var ki=!0;function tv(e,t,r,n){var a=M.T;M.T=null;var o=I.p;try{I.p=2,tc(e,t,r,n)}finally{I.p=o,M.T=a}}function rv(e,t,r,n){var a=M.T;M.T=null;var o=I.p;try{I.p=8,tc(e,t,r,n)}finally{I.p=o,M.T=a}}function tc(e,t,r,n){if(ki){var a=rc(n);if(a===null)$s(e,t,n,Si,r),nm(e,n);else if(av(a,e,t,r,n))n.stopPropagation();else if(nm(e,n),t&4&&-1<nv.indexOf(e)){for(;a!==null;){var o=yn(a);if(o!==null)switch(o.tag){case 3:if(o=o.stateNode,o.current.memoizedState.isDehydrated){var l=Gr(o.pendingLanes);if(l!==0){var u=o;for(u.pendingLanes|=2,u.entangledLanes|=2;l;){var f=1<<31-bt(l);u.entanglements[1]|=f,l&=~f}Qt(o),(ve&6)===0&&(ni=gt()+500,$a(0,!1))}}break;case 31:case 13:u=rn(o,2),u!==null&&mt(u,o,2),oi(),ec(o,2)}if(o=rc(n),o===null&&$s(e,t,n,Si,r),o===a)break;a=o}a!==null&&n.stopPropagation()}else $s(e,t,n,null,r)}}function rc(e){return e=il(e),nc(e)}var Si=null;function nc(e){if(Si=null,e=vn(e),e!==null){var t=L(e);if(t===null)e=null;else{var r=t.tag;if(r===13){if(e=C(t),e!==null)return e;e=null}else if(r===31){if(e=R(t),e!==null)return e;e=null}else if(r===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Si=e,null}function rm(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(qh()){case su:return 2;case cu:return 8;case lo:case Bh:return 32;case uu:return 268435456;default:return 32}default:return 32}}var ac=!1,Ir=null,Ur=null,$r=null,Ka=new Map,Ya=new Map,Hr=[],nv="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function nm(e,t){switch(e){case"focusin":case"focusout":Ir=null;break;case"dragenter":case"dragleave":Ur=null;break;case"mouseover":case"mouseout":$r=null;break;case"pointerover":case"pointerout":Ka.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Ya.delete(t.pointerId)}}function Xa(e,t,r,n,a,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:r,eventSystemFlags:n,nativeEvent:o,targetContainers:[a]},t!==null&&(t=yn(t),t!==null&&em(t)),e):(e.eventSystemFlags|=n,t=e.targetContainers,a!==null&&t.indexOf(a)===-1&&t.push(a),e)}function av(e,t,r,n,a){switch(t){case"focusin":return Ir=Xa(Ir,e,t,r,n,a),!0;case"dragenter":return Ur=Xa(Ur,e,t,r,n,a),!0;case"mouseover":return $r=Xa($r,e,t,r,n,a),!0;case"pointerover":var o=a.pointerId;return Ka.set(o,Xa(Ka.get(o)||null,e,t,r,n,a)),!0;case"gotpointercapture":return o=a.pointerId,Ya.set(o,Xa(Ya.get(o)||null,e,t,r,n,a)),!0}return!1}function am(e){var t=vn(e.target);if(t!==null){var r=L(t);if(r!==null){if(t=r.tag,t===13){if(t=C(r),t!==null){e.blockedOn=t,hu(e.priority,function(){tm(r)});return}}else if(t===31){if(t=R(r),t!==null){e.blockedOn=t,hu(e.priority,function(){tm(r)});return}}else if(t===3&&r.stateNode.current.memoizedState.isDehydrated){e.blockedOn=r.tag===3?r.stateNode.containerInfo:null;return}}}e.blockedOn=null}function _i(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var r=rc(e.nativeEvent);if(r===null){r=e.nativeEvent;var n=new r.constructor(r.type,r);ol=n,r.target.dispatchEvent(n),ol=null}else return t=yn(r),t!==null&&em(t),e.blockedOn=r,!1;t.shift()}return!0}function om(e,t,r){_i(e)&&r.delete(t)}function ov(){ac=!1,Ir!==null&&_i(Ir)&&(Ir=null),Ur!==null&&_i(Ur)&&(Ur=null),$r!==null&&_i($r)&&($r=null),Ka.forEach(om),Ya.forEach(om)}function zi(e,t){e.blockedOn===t&&(e.blockedOn=null,ac||(ac=!0,s.unstable_scheduleCallback(s.unstable_NormalPriority,ov)))}var Ci=null;function im(e){Ci!==e&&(Ci=e,s.unstable_scheduleCallback(s.unstable_NormalPriority,function(){Ci===e&&(Ci=null);for(var t=0;t<e.length;t+=3){var r=e[t],n=e[t+1],a=e[t+2];if(typeof n!="function"){if(nc(n||r)===null)continue;break}var o=yn(r);o!==null&&(e.splice(t,3),t-=3,as(o,{pending:!0,data:a,method:r.method,action:n},n,a))}}))}function ta(e){function t(f){return zi(f,e)}Ir!==null&&zi(Ir,e),Ur!==null&&zi(Ur,e),$r!==null&&zi($r,e),Ka.forEach(t),Ya.forEach(t);for(var r=0;r<Hr.length;r++){var n=Hr[r];n.blockedOn===e&&(n.blockedOn=null)}for(;0<Hr.length&&(r=Hr[0],r.blockedOn===null);)am(r),r.blockedOn===null&&Hr.shift();if(r=(e.ownerDocument||e).$$reactFormReplay,r!=null)for(n=0;n<r.length;n+=3){var a=r[n],o=r[n+1],l=a[st]||null;if(typeof o=="function")l||im(r);else if(l){var u=null;if(o&&o.hasAttribute("formAction")){if(a=o,l=o[st]||null)u=l.formAction;else if(nc(a)!==null)continue}else u=l.action;typeof u=="function"?r[n+1]=u:(r.splice(n,3),n-=3),im(r)}}}function lm(){function e(o){o.canIntercept&&o.info==="react-transition"&&o.intercept({handler:function(){return new Promise(function(l){return a=l})},focusReset:"manual",scroll:"manual"})}function t(){a!==null&&(a(),a=null),n||setTimeout(r,20)}function r(){if(!n&&!navigation.transition){var o=navigation.currentEntry;o&&o.url!=null&&navigation.navigate(o.url,{state:o.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var n=!1,a=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(r,100),function(){n=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),a!==null&&(a(),a=null)}}}function oc(e){this._internalRoot=e}Ei.prototype.render=oc.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(d(409));var r=t.current,n=_t();Jf(r,n,e,t,null,null)},Ei.prototype.unmount=oc.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Jf(e.current,2,null,e,null,null),oi(),t[bn]=null}};function Ei(e){this._internalRoot=e}Ei.prototype.unstable_scheduleHydration=function(e){if(e){var t=gu();e={blockedOn:null,target:e,priority:t};for(var r=0;r<Hr.length&&t!==0&&t<Hr[r].priority;r++);Hr.splice(r,0,e),r===0&&am(e)}};var sm=c.version;if(sm!=="19.2.8")throw Error(d(527,sm,"19.2.8"));I.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(d(188)):(e=Object.keys(e).join(","),Error(d(268,e)));return e=z(t),e=e!==null?N(e):null,e=e===null?null:e.stateNode,e};var iv={bundleType:0,version:"19.2.8",rendererPackageName:"react-dom",currentDispatcherRef:M,reconcilerVersion:"19.2.8"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(Ga=__REACT_DEVTOOLS_GLOBAL_HOOK__,!Ga.isDisabled&&Ga.supportsFiber))try{ia=Ga.inject(iv),ht=Ga}catch{}var Ga;i.createRoot=function(e,t){if(!S(e))throw Error(d(299));var r=!1,n="",a=pp,o=fp,l=mp;return t!=null&&(t.unstable_strictMode===!0&&(r=!0),t.identifierPrefix!==void 0&&(n=t.identifierPrefix),t.onUncaughtError!==void 0&&(a=t.onUncaughtError),t.onCaughtError!==void 0&&(o=t.onCaughtError),t.onRecoverableError!==void 0&&(l=t.onRecoverableError)),t=Xf(e,1,!1,null,null,r,n,null,a,o,l,lm),e[bn]=t.current,Us(e),new oc(t)},i.hydrateRoot=function(e,t,r){if(!S(e))throw Error(d(299));var n=!1,a="",o=pp,l=fp,u=mp,f=null;return r!=null&&(r.unstable_strictMode===!0&&(n=!0),r.identifierPrefix!==void 0&&(a=r.identifierPrefix),r.onUncaughtError!==void 0&&(o=r.onUncaughtError),r.onCaughtError!==void 0&&(l=r.onCaughtError),r.onRecoverableError!==void 0&&(u=r.onRecoverableError),r.formState!==void 0&&(f=r.formState)),t=Xf(e,1,!0,t,r??null,n,a,f,o,l,u,lm),t.context=Gf(null),r=t.current,n=_t(),n=Gi(n),a=Er(n),a.callback=null,Nr(r,a,n),r=n,t.current.lanes=r,sa(t,r),Qt(t),e[bn]=t.current,Us(e),new Ei(t)},i.version="19.2.8"}),xm=Ut((i,s)=>{"use strict";function c(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(c)}catch(p){console.error(p)}}c(),s.exports=wm()}),km=Ut(i=>{"use strict";var s=Symbol.for("react.transitional.element"),c=Symbol.for("react.fragment");function p(d,S,L){var C=null;if(L!==void 0&&(C=""+L),S.key!==void 0&&(C=""+S.key),"key"in S){L={};for(var R in S)R!=="key"&&(L[R]=S[R])}else L=S;return S=L.ref,{$$typeof:s,type:d,key:C,ref:S!==void 0?S:null,props:L}}i.Fragment=c,i.jsx=p,i.jsxs=p}),$t=Ut((i,s)=>{"use strict";s.exports=km()}),Sm=Ie(xm(),1),_m='"Plus Jakarta Sans", -apple-system, "Segoe UI", Roboto, Arial, sans-serif',zm=`
  :host {
    /* Brand */
    --ext-primary: #00875a;
    --ext-primary-hover: #007049;
    --ext-primary-soft: #e6f4ef;

    /* Semantic */
    --ext-success: #027a48;
    --ext-success-soft: #e8f6ef;
    --ext-warning: #b54708;
    --ext-warning-soft: #fdf1e3;
    --ext-danger: #d92d20;
    --ext-danger-hover: #b42318;
    --ext-danger-soft: #fdeceb;
    --ext-info: #175cd3;
    --ext-info-soft: #e8f0fd;

    /* Surface */
    --ext-bg: #f4f6f8;
    --ext-surface: #ffffff;
    --ext-surface-2: #f8fafc;
    --ext-border: #d0d5dd;

    /* Text \u2014 kontras tinggi untuk keterbacaan usia 30-40 */
    --ext-text: #1c2530;
    --ext-text-secondary: #475467;
    --ext-text-muted: #667085;
    --ext-text-on-primary: #ffffff;

    /* Typography \u2014 lebih besar dari default, untuk mudah dibaca */
    --ext-font-family: ${_m};
    --ext-font-size-xs: 12px;
    --ext-font-size-sm: 13px;
    --ext-font-size-md: 15px;
    --ext-font-size-lg: 17px;
    --ext-font-size-xl: 20px;
    --ext-line-height: 1.5;

    /* Radius */
    --ext-radius-sm: 6px;
    --ext-radius-md: 10px;
    --ext-radius-lg: 14px;

    /* Spacing */
    --ext-space-1: 4px;
    --ext-space-2: 8px;
    --ext-space-3: 12px;
    --ext-space-4: 16px;
    --ext-space-5: 20px;
    --ext-space-6: 24px;
    --ext-space-8: 32px;

    /* Shadow */
    --ext-shadow-sm: 0 1px 2px rgba(16, 24, 40, 0.06);
    --ext-shadow-md: 0 6px 20px rgba(16, 24, 40, 0.1);
    --ext-shadow-lg: 0 20px 50px rgba(16, 24, 40, 0.18);

    /* Focus ring \u2014 terlihat jelas, penting utk usability */
    --ext-ring: 0 0 0 3px rgba(0, 135, 90, 0.35);

    /* Motion */
    --ext-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --ext-duration-fast: 140ms;
    --ext-duration-normal: 220ms;
  }
`,Ja=null;function Cm(){return Ja||(Ja=new CSSStyleSheet,Ja.replaceSync(zm)),Ja}var lc=!1;function Em(){if(lc||document.getElementById("ext-pjs-font"))return;lc=!0;let i=document.createElement("link");i.id="ext-pjs-font",i.rel="stylesheet",i.href="http://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap",document.head.appendChild(i)}function Za(i,s="open"){let c=i.attachShadow({mode:s});return c.adoptedStyleSheets=[Cm()],Em(),c}var Nm=`
  :host { display: inline-block; }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--ext-space-2);
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    line-height: 1.2;
    border: 1px solid transparent;
    border-radius: var(--ext-radius-md);
    padding: 10px 18px;
    cursor: pointer;
    transition: background-color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      transform var(--ext-duration-fast) var(--ext-ease),
      box-shadow var(--ext-duration-fast) var(--ext-ease);
    min-height: 42px;
    white-space: nowrap;
  }
  button:hover:not(:disabled) { transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:focus-visible { outline: none; box-shadow: var(--ext-ring); }
  button:disabled { opacity: 0.55; cursor: not-allowed; }

  /* sizes */
  :host([size='sm']) button { font-size: var(--ext-font-size-sm); padding: 6px 12px; min-height: 32px; border-radius: var(--ext-radius-sm); }
  :host([size='lg']) button { font-size: var(--ext-font-size-lg); padding: 13px 24px; min-height: 50px; }

  /* variants */
  :host([variant='primary']) button { background: var(--ext-primary); color: var(--ext-text-on-primary); }
  :host([variant='primary']) button:hover:not(:disabled) { background: var(--ext-primary-hover); }
  :host([variant='danger']) button { background: var(--ext-danger); color: var(--ext-text-on-primary); }
  :host([variant='danger']) button:hover:not(:disabled) { background: var(--ext-danger-hover); }
  :host([variant='success']) button { background: var(--ext-success); color: var(--ext-text-on-primary); }
  :host([variant='secondary']) button { background: var(--ext-surface); color: var(--ext-text); border-color: var(--ext-border); }
  :host([variant='secondary']) button:hover:not(:disabled) { background: var(--ext-surface-2); }
  :host([variant='ghost']) button { background: transparent; color: var(--ext-primary); }
  :host([variant='ghost']) button:hover:not(:disabled) { background: var(--ext-primary-soft); }
  :host([variant='ghost-danger']) button { background: transparent; color: var(--ext-danger); }
  :host([variant='ghost-danger']) button:hover:not(:disabled) { background: var(--ext-danger-soft); }

  /* loading spinner */
  .spinner {
    width: 16px; height: 16px;
    border: 2px solid currentColor;
    border-top-color: transparent;
    border-radius: 50%;
    animation: ext-spin 0.7s linear infinite;
    display: none;
  }
  :host([loading]) .spinner { display: inline-block; }
  :host([loading]) button { pointer-events: none; opacity: 0.8; }
  @keyframes ext-spin { to { transform: rotate(360deg); } }
`,Pm=class extends HTMLElement{constructor(){super();let i=Za(this);i.innerHTML=`
      <style>${Nm}</style>
      <button type="button">
        <span class="spinner" aria-hidden="true"></span>
        <span class="label"><slot></slot></span>
      </button>
    `,this.btn=i.querySelector("button")}connectedCallback(){this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"),this.btn.addEventListener("click",i=>{if(this.hasAttribute("loading")||this.hasAttribute("disabled")){i.stopPropagation(),i.preventDefault();return}})}static get observedAttributes(){return["disabled","loading"]}attributeChangedCallback(i){(i==="disabled"||i==="loading")&&(this.btn.disabled=this.hasAttribute("disabled")||this.hasAttribute("loading"),this.btn.setAttribute("aria-busy",this.hasAttribute("loading")?"true":"false"))}};customElements.get("ext-btn")||customElements.define("ext-btn",Pm);var jm=`
  :host {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-xs);
    font-weight: 700;
    line-height: 1;
    padding: 5px 10px;
    border-radius: 999px;
    border: 1px solid transparent;
    white-space: nowrap;
    letter-spacing: 0.01em;
  }
  :host([variant='success']) { background: var(--ext-success-soft); color: var(--ext-success); border-color: #bfe3cf; }
  :host([variant='warning']) { background: var(--ext-warning-soft); color: var(--ext-warning); border-color: #f2d3ae; }
  :host([variant='danger']) { background: var(--ext-danger-soft); color: var(--ext-danger); border-color: #f3c1be; }
  :host([variant='info']) { background: var(--ext-info-soft); color: var(--ext-info); border-color: #c3d6f5; }
  :host([variant='neutral']) { background: var(--ext-surface-2); color: var(--ext-text-secondary); border-color: var(--ext-border); }
  :host([variant='primary']) { background: var(--ext-primary-soft); color: var(--ext-primary); border-color: #b8ddcd; }
`,Lm=class extends HTMLElement{constructor(){super();let i=Za(this);i.innerHTML=`<style>${jm}</style><slot></slot>`}};customElements.get("ext-badge")||customElements.define("ext-badge",Lm);var Tm=`
  :host {
    display: flex;
    flex-direction: column;
    font-family: var(--ext-font-family);
    background: var(--ext-surface);
    border: 1px solid var(--ext-border);
    border-radius: var(--ext-radius-lg);
    overflow: hidden;
  }
  .tablist {
    display: flex;
    border-bottom: 1px solid var(--ext-border);
    background: var(--ext-surface-2);
    overflow-x: auto;
  }
  ::slotted([slot='tab']) {
    appearance: none;
    border: none;
    background: transparent;
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    font-weight: 600;
    color: var(--ext-text-secondary);
    padding: 14px 20px;
    cursor: pointer;
    border-bottom: 3px solid transparent;
    margin-bottom: -1px;
    white-space: nowrap;
    transition: color var(--ext-duration-fast) var(--ext-ease),
      border-color var(--ext-duration-fast) var(--ext-ease),
      background-color var(--ext-duration-fast) var(--ext-ease);
  }
  ::slotted([slot='tab']:hover) { color: var(--ext-primary); background: var(--ext-primary-soft); }
  ::slotted([slot='tab'][data-active]) { color: var(--ext-primary); border-bottom-color: var(--ext-primary); font-weight: 700; }
  ::slotted([slot='tab']:focus-visible) { outline: none; box-shadow: inset var(--ext-ring); }
  .panels { padding: var(--ext-space-5); }
  ::slotted([slot='panel']) { display: none; }
  ::slotted([slot='panel'][data-active]) { display: block; }
`,Am=class extends HTMLElement{constructor(){super(),this.attachShadowWithTokens()}attachShadowWithTokens(){let i=Za(this);i.innerHTML=`
      <style>${Tm}</style>
      <div class="tablist"><slot name="tab"></slot></div>
      <div class="panels"><slot name="panel"></slot></div>
    `}connectedCallback(){this.addEventListener("click",s=>{let c=s.target.closest('[slot="tab"]');!c||!this.contains(c)||this.activate(c.getAttribute("data-tab")||"")});let i=this.querySelector('[slot="tab"][data-active]');i&&this.activate(i.getAttribute("data-tab")||"")}activate(i){i&&(this.querySelectorAll('[slot="tab"]').forEach(s=>{s.getAttribute("data-tab")===i?s.setAttribute("data-active",""):s.removeAttribute("data-active")}),this.querySelectorAll('[slot="panel"]').forEach(s=>{s.getAttribute("data-panel")===i?s.setAttribute("data-active",""):s.removeAttribute("data-active")}),this.dispatchEvent(new CustomEvent("ext-tab-change",{detail:{tab:i}})))}};customElements.get("ext-tabs")||customElements.define("ext-tabs",Am);var Rm=`
  :host { display: none; }
  :host([open]) { display: block; }
  .overlay {
    position: fixed;
    inset: 0;
    z-index: 2147483000;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(15, 23, 42, 0.55);
    backdrop-filter: blur(2px);
    animation: ext-fade var(--ext-duration-normal) var(--ext-ease);
    padding: var(--ext-space-6);
  }
  .modal {
    width: 520px;
    max-width: 100%;
    background: var(--ext-surface);
    border-radius: var(--ext-radius-lg);
    box-shadow: var(--ext-shadow-lg);
    overflow: hidden;
    animation: ext-slide-up var(--ext-duration-normal) var(--ext-ease);
  }
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--ext-space-4);
    padding: var(--ext-space-5) var(--ext-space-6);
    border-bottom: 1px solid var(--ext-border);
  }
  .title {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-lg);
    font-weight: 700;
    color: var(--ext-text);
    margin: 0;
  }
  .close {
    appearance: none;
    border: none;
    background: var(--ext-surface-2);
    color: var(--ext-text-secondary);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    font-size: 22px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color var(--ext-duration-fast) var(--ext-ease), color var(--ext-duration-fast) var(--ext-ease);
  }
  .close:hover { background: var(--ext-danger-soft); color: var(--ext-danger); }
  .close:focus-visible { outline: none; box-shadow: var(--ext-ring); }

  .body {
    font-family: var(--ext-font-family);
    font-size: var(--ext-font-size-md);
    line-height: var(--ext-line-height);
    color: var(--ext-text-secondary);
    padding: var(--ext-space-6);
  }
  .footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--ext-space-3);
    padding: 0 var(--ext-space-6) var(--ext-space-6);
  }
  /* tombol utama di dalam modal memakai komponen ext-btn \u2014 styling via atribut host */
  ::slotted(*) { font-family: var(--ext-font-family); }

  /* variant accent line */
  :host([variant='danger']) .header { box-shadow: inset 4px 0 0 var(--ext-danger); }
  :host([variant='success']) .header { box-shadow: inset 4px 0 0 var(--ext-success); }
  :host([variant='info']) .header { box-shadow: inset 4px 0 0 var(--ext-info); }
  :host([variant='warning']) .header { box-shadow: inset 4px 0 0 var(--ext-warning); }

  @keyframes ext-fade { from { opacity: 0; } }
  @keyframes ext-slide-up {
    from { opacity: 0; transform: translateY(18px) scale(0.98); }
  }
`,Om=class extends HTMLElement{constructor(){super(),this.handleKey=i=>{i.key==="Escape"&&this.hasAttribute("open")&&this.cancel()},this.root=Za(this),this.root.innerHTML=`
      <style>${Rm}</style>
      <div class="overlay">
        <div class="modal" role="dialog" aria-modal="true">
          <div class="header">
            <h3 class="title"><slot name="title"></slot></h3>
            <button class="close" part="close" aria-label="Tutup">&times;</button>
          </div>
          <div class="body"><slot></slot></div>
          <div class="footer">
            <slot name="footer"></slot>
          </div>
        </div>
      </div>
    `}connectedCallback(){let i=this.root.querySelector(".overlay");this.root.querySelector(".close").addEventListener("click",()=>this.cancel()),i.addEventListener("click",s=>{s.target===i&&this.cancel()}),document.addEventListener("keydown",this.handleKey)}disconnectedCallback(){document.removeEventListener("keydown",this.handleKey)}get titleSlot(){return this.querySelector('[slot="title"]')}get footerSlot(){return this.querySelector('[slot="footer"]')}open(){this.setAttribute("open","")}close(){this.removeAttribute("open")}cancel(){this.dispatchEvent(new CustomEvent("ext-cancel")),this.close()}ok(){this.dispatchEvent(new CustomEvent("ext-ok"))}};customElements.get("ext-modal")||customElements.define("ext-modal",Om);function sc(i){return new Promise(s=>{let c=document.createElement("ext-modal");c.setAttribute("variant",i.variant??"warning"),i.okLabel&&c.setAttribute("ok-label",i.okLabel),i.cancelLabel&&c.setAttribute("cancel-label",i.cancelLabel),i.hideCancel&&c.setAttribute("hide-cancel",""),c.innerHTML=`<h3 slot="title"></h3><div class="ext-confirm-body"></div><div slot="footer">
         <ext-btn data-ext-confirm-cancel variant="secondary"></ext-btn>
         <ext-btn data-ext-confirm-ok></ext-btn>
       </div>`;let p=c.querySelector('[slot="title"]');p.textContent=i.title;let d=c.querySelector(".ext-confirm-body");if(i.icon){let C=document.createElement("div");C.className="ext-confirm-icon",C.textContent=i.icon,d.appendChild(C)}i.message&&i.message.split(`
`).forEach((C,R)=>{R>0&&d.appendChild(document.createElement("br")),d.appendChild(document.createTextNode(C))}),c.querySelector("[data-ext-confirm-ok]").textContent=i.okLabel??"Lanjut";let S=c.querySelector("[data-ext-confirm-ok]");S.setAttribute("variant",i.variant==="danger"?"danger":"primary"),i.hideCancel?c.querySelector("[data-ext-confirm-cancel]")?.remove():c.querySelector("[data-ext-confirm-cancel]").textContent=i.cancelLabel??"Batal",S.addEventListener("click",()=>c.ok()),i.hideCancel||c.querySelector("[data-ext-confirm-cancel]").addEventListener("click",()=>c.cancel());let L=C=>{c.remove(),s(C)};c.addEventListener("ext-ok",()=>L(!0)),c.addEventListener("ext-cancel",()=>L(!1)),document.body.appendChild(c),c.open()})}var Qe=Ie(At(),1),Mm="http://dev.rsudkotajambi.id/rs",Dm="ext-farmasi-app-base",Fm=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],Im=".rsudkotajambi.id",Um=["dev.rsudkotajambi.id","103.147.236.138","localhost","127.0.0.1"],cc="Fitur nonaktif: server Reports menggunakan HTTP (belum mendukung HTTPS)";function Ni(i){try{let s=new URL(i??Pi());if(s.protocol==="https:")return null;let c=s.hostname.toLowerCase();return Um.includes(c)?null:cc}catch{return cc}}function $m(i){try{let s=new URL(i);if(s.protocol!=="http:"&&s.protocol!=="https:")return!1;let c=s.hostname.toLowerCase();return Fm.includes(c)?!0:c.endsWith(Im)}catch{return!1}}function Pi(){try{let i=localStorage.getItem(Dm);if(i&&$m(i))return i.replace(/\/+$/,"")}catch{}return Mm}async function Hm(i,s,c=fetch){let p=new AbortController,d=globalThis.setTimeout(()=>p.abort(),25e3);try{return await c(i,{...s,signal:p.signal})}finally{globalThis.clearTimeout(d)}}async function Vm(i,s=fetch){try{let c=Pi(),p=Ni(c);if(p)return console.warn("[casemixApi]",p,"\u2014 baca pusat dilewati:",i),null;let d=await Hm(c+i,{cache:"no-store",credentials:"omit",headers:{Accept:"application/json"}},s);return d.ok?await d.json():null}catch{return null}}async function qm(i,s,c=fetch){if(!i)return[];let p="/api/reports/resume-history?id_visit="+encodeURIComponent(i)+(s?"&tipe="+s:""),d=await Vm(p,c);return!d?.ok||!Array.isArray(d.data)?[]:d.data}function Bm(){try{let i=globalThis.crypto;if(i&&typeof i.randomUUID=="function")return i.randomUUID()}catch{}return`${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`}function qr(){try{if(typeof window<"u"&&window.localStorage)return window.localStorage}catch{}return null}var uc="ext_rv_history_",Wm=uc,dc="ext_rv_lastform_",Qm="ext_migrated_rv_",pc=50;function ji(i,s){return`${uc}${s==="ranap"?"ri":"rj"}_${i||"unknown"}`}function fc(i,s){return`${dc}${s==="ranap"?"ri":"rj"}_${i||"unknown"}`}function eo(i,s){if(!i)return null;try{let c=i.getItem(s);return c?JSON.parse(c):null}catch{return null}}function Li(i,s,c){if(i)try{i.setItem(s,JSON.stringify(c))}catch{}}function Km(i,s){return JSON.stringify(i??null)===JSON.stringify(s??null)}function mc(i,s){let c={};return Object.keys(i).forEach(p=>c[p]=!0),Object.keys(s).forEach(p=>c[p]=!0),Object.keys(c).filter(p=>!Km(i[p],s[p]))}function gc(i){let s=i===void 0?"-":JSON.stringify(i);return s.length>60?s.slice(0,60)+"\u2026":s}function Ti(i,s,c=qr()){let p=eo(c,ji(i,s)),d=Array.isArray(p)?p:[];if(s==="ranap"){let S=eo(c,Wm+i);if(Array.isArray(S)&&S.length>0&&d.length===0){let L=S.map(C=>({...C,tipe:"ranap"}));return Ai(L,i,"ranap",c),L}}return d}function Ai(i,s,c,p=qr()){Li(p,ji(s,c),i.slice(-pc))}function Ym(i,s,c=qr()){return eo(c,fc(i,s))||(s==="ranap"?eo(c,dc+i):null)}function hc(i,s,c,p=qr()){Li(p,fc(s,c),i)}function Xm(){try{let i=document.getElementById("userpanel");if(i){let d="",S="";if(i.querySelectorAll(".subgroup").forEach(C=>{let R=(C.querySelector(".subtitle")?.textContent||"").trim().toLowerCase(),k=(C.querySelector(".subcontent")?.textContent||"").trim();R==="username"&&k&&(d=k),R==="role"&&k&&(S=k)}),d)return`${d}${S?` (${S})`:""}`;let L=(i.querySelector("a")?.textContent||"").trim();if(L&&L!=="Petugas Rumah Sakit")return L}let s=(document.querySelector("#petugas, .petugas, .username, #username, .user-name")?.textContent||"").trim();if(s)return s.slice(0,80);let c=document.querySelector('input[name="dokter"], #dokter, input[name="nama_dokter"]')?.value?.trim();if(c)return c.slice(0,80);let p=document.querySelector('input[name="id_user"], #id_user')?.value?.trim();if(p)return`User #${p}`}catch{}return"petugas"}var Gm="/api/reports/resume-history";function Jm(){return Pi()}function Zm(i){return Qm+i}function eg(i,s){if(!i)return 0;try{let c=i.getItem(s);if(c===null)return 0;let p=Number(JSON.parse(c));return Number.isFinite(p)?p:0}catch{return 0}}function tg(i,s,c,p){if(!(!i||!s))try{let d=Zm(ji(s,c));p>eg(i,d)&&Li(i,d,p)}catch{}}function rg(i,s,c=fetch,p=qr(),d=i.tipe){let S={client_id:i.client_id??null,id_visit:s,id_resume:i.id_resume,aksi:i.aksi,tipe:i.tipe,waktu:new Date(i.at).toISOString(),user:i.user,before:i.before,after:i.after,changed:i.changed},L=async()=>{try{let C=Jm(),R=Ni(C);return R?(console.warn("[resumeHistory]",R,"\u2014 kirim resume dilewati:",s),!1):(await c(C+Gm,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(S),keepalive:!0,credentials:"omit"})).ok?(tg(p,s,d,i.at),!0):!1}catch{return!1}};try{return L()}catch{return Promise.resolve(!1)}}var bc=null,vc=0;function ng(i){if(!i.idVisit)return null;let s=i.now??Date.now(),c=i.store??qr();hc(i.after,i.idVisit,i.tipe,c);let p=JSON.stringify([i.idVisit,i.aksi,i.after]);if(bc===p&&s-vc<5e3)return null;bc=p,vc=s;let d={at:s,aksi:i.aksi,id_resume:i.idResume??"",user:i.user??Xm(),tipe:i.tipe,before:i.before??{},after:i.after,changed:mc(i.before??{},i.after),client_id:Bm()},S=Ti(i.idVisit,i.tipe,c);S.push(d),Ai(S,i.idVisit,i.tipe,c),hc(i.after,i.idVisit,i.tipe,c);try{rg(d,i.idVisit,i.fetcher??fetch,c,i.tipe)}catch{}return d}function ag(i){if(i!=null){if(typeof i=="string")return i;if(typeof i=="number"||typeof i=="boolean")return String(i);if(Array.isArray(i))return i.map(s=>{if(typeof s=="string")return s;try{return JSON.stringify(s)??""}catch{return""}});try{return JSON.stringify(i)??""}catch{return""}}}function yc(i){let s={};if(!i||typeof i!="object"||Array.isArray(i))return s;for(let c of Object.keys(i)){let p=ag(i[c]);p!==void 0&&(s[c]=p)}return s}function og(i,s){try{if(!i||typeof i!="object")return null;let c=i.waktu?Date.parse(i.waktu):NaN;if(!Number.isFinite(c))return null;let p=yc(i.after),d=yc(i.before),S=i.tipe==="rajal"?"rajal":i.tipe==="ranap"?"ranap":s,L=Array.isArray(i.changed)?i.changed.filter(R=>typeof R=="string"):mc(d,p),C=typeof i.client_id=="string"&&i.client_id?i.client_id:void 0;return{at:c,aksi:i.aksi==="buat"?"buat":"ubah",id_resume:typeof i.id_resume=="string"?i.id_resume:"",user:typeof i.user=="string"&&i.user?i.user:"petugas",tipe:S,before:d,after:p,changed:L,...C?{client_id:C}:{}}}catch{return null}}function wc(i){if(i.client_id)return"cid:"+i.client_id;try{return"h:"+i.at+"|"+i.user+"|"+i.aksi+"|"+JSON.stringify(i.after)}catch{return"h:"+i.at+"|"+i.user+"|"+i.aksi}}function ig(i,s){let c=new Set(i.map(wc)),p=i.slice();for(let d of s){let S=wc(d);c.has(S)||(c.add(S),p.push(d))}return p.sort((d,S)=>d.at-S.at),p.slice(-pc)}var lg="'Roboto','Segoe UI',system-ui,-apple-system,Arial,sans-serif";function sg(i){try{document.querySelector("#ext-rv-history-overlay")?.remove()}catch{}let s=i.store??qr(),c=Ti(i.idVisit,i.tipe,s).slice().reverse(),p=i.zIndex??99998,d=document.createElement("div");d.id="ext-rv-history-overlay",d.style.cssText=`position:fixed;inset:0;z-index:${p};background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:24px;`,d.addEventListener("click",function(N){N.target===d&&d.remove()});let S=document.createElement("div");S.style.cssText="background:#fff;border-radius:12px;max-width:680px;width:100%;max-height:82vh;display:flex;flex-direction:column;overflow:hidden;font-size:16px!important;line-height:1.6!important;color:#1c2530;font-family:"+lg+"!important;",d.appendChild(S);let L=document.createElement("div");L.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #d0d5dd;font-weight:700;";let C=document.createElement("span");C.textContent=`${i.title??"Riwayat Resume"} (${c.length})`,L.appendChild(C);let R=document.createElement("button");R.type="button",R.textContent="\xD7",R.style.cssText="border:none;background:#f8fafc;width:32px;height:32px;border-radius:50%;font-family:inherit!important;font-size:16px!important;line-height:1!important;cursor:pointer;",R.onclick=function(){d.remove()},L.appendChild(R),S.appendChild(L);let k=document.createElement("div");k.style.cssText="padding:14px 18px;overflow-y:auto;",S.appendChild(k);let z=N=>{if(c=N,C.textContent=`${i.title??"Riwayat Resume"} (${c.length})`,k.replaceChildren(),!c.length){k.textContent="Belum ada riwayat untuk kunjungan ini. Riwayat tercatat otomatis setiap kali Simpan ditekan.";return}c.forEach(function(O,re){let se=c.length-re,K=document.createElement("div");K.style.cssText="border:1px solid #d0d5dd;border-radius:8px;padding:10px 12px;margin-bottom:10px;";let G=document.createElement("div");G.style.fontWeight="600";let ze=O.user?` \u2014 oleh ${O.user}`:"",pe=O.after?._source==="verif_action",Ue=pe?" \u2014 verifikasi berkas":"";G.textContent=`#${se} \u2014 ${new Date(O.at).toLocaleString("id-ID")} \u2014 ${O.aksi==="buat"?"Buat baru":"Ubah"}${ze} \u2014 ${O.changed.length} field berubah${Ue}`,K.appendChild(G);let oe=document.createElement("div");oe.style.cssText="display:none;margin-top:8px;background:#f8fafc;border-radius:6px;padding:8px 10px;font-size:13px;line-height:1.6;max-height:180px;overflow-y:auto;white-space:pre-wrap;",O.changed.length?oe.textContent=O.changed.map(function(E){return E+": "+gc(O.before[E])+" \u2192 "+gc(O.after[E])}).join(`
`):oe.textContent="Tidak ada perbedaan field.",K.appendChild(oe);let ye=document.createElement("div");ye.style.cssText="margin-top:8px;display:flex;gap:8px;";let be=document.createElement("button");be.type="button",be.textContent="Lihat",be.style.cssText="border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",be.onclick=function(){oe.style.display=oe.style.display==="none"?"block":"none"},ye.appendChild(be);let w=document.createElement("button");if(w.type="button",w.textContent="Salin ke Form",w.style.cssText="background:#00875a;color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;",w.onclick=function(){try{i.onApply(O.after),d.remove()}catch{}},pe){let E=document.createElement("span");E.textContent="Entri verifikasi \u2014 bukan snapshot form, tidak untuk disalin.",E.style.cssText="align-self:center;color:#92400e;background:#fef3c7;border-radius:6px;padding:4px 10px;font-size:12px;line-height:1.5;",ye.appendChild(E)}else ye.appendChild(w);K.appendChild(ye),k.appendChild(K)})};z(c);try{document.body.appendChild(d)}catch{}if(i.idVisit){let N=Ni();if(N)try{let O=document.createElement("div");O.textContent=N+" \u2014 riwayat hanya dari PC ini.",O.style.cssText="margin-top:10px;padding:8px 10px;background:#fef3c7;color:#92400e;border-radius:6px;font-size:13px;line-height:1.5;",k.appendChild(O)}catch{}else try{qm(i.idVisit,i.tipe).then(O=>{try{if(!O.length||!d.isConnected)return;let re=[];for(let G of O){let ze=og(G,i.tipe);ze&&re.push(ze)}if(!re.length)return;let se=Ti(i.idVisit,i.tipe,s),K=ig(se,re);if(K.length===se.length)return;Ai(K,i.idVisit,i.tipe,s),z(K.slice().reverse());try{document.dispatchEvent(new CustomEvent("ext-rv-history-merged",{detail:{idVisit:i.idVisit,tipe:i.tipe,count:K.length}}))}catch{}}catch{}})}catch{}}}var xc=["alasan_rawat","anamnesa","riwayat_penyakit","tensi","nadi","suhu","spo2","nafas","gcs_e","gcs_m","gcs_v","fisik_text","laborat","diagnosa_primary","diagnosa_skunder","diagnosa_tindakan","tindakan","terapi_pengobatan","obat_plg","tindakan_dua","jenis_kasus","kode_diagnosa_utama","id_diagnosa_utama","ku","kes","td_pulang","nadi_pulang","suhu_pulang","rr_pulang","spo2_pulang","catatan_keluar","keadaan_keluar","cara_keluar","penyebab_kematian","instruksi_pulang","tgl_keluar","jadwal_kontrol","pemeriksaan_lanjut","kelas","id_kelas"],to=[{field:"icd_sekunder",idName:"id_diagnosa_sekunder[]",kodePrefix:"kode_diagnosa_sekunder",namaPrefix:"diagnosa_sekunder"},{field:"icd_tindakan",idName:"id_tindakan[]",kodePrefix:"kode_tindakan",namaPrefix:"tindakan"},{field:"icd_nosokomial",idName:"id_nosokomial[]",kodePrefix:"kode_nosokomial",namaPrefix:"nosokomial"}];function cg(i){let s={};for(let c of xc){let p=i[c];typeof p=="string"&&(s[c]=p)}s.diagnosa_utama=i.diagnosa_utama_nama;for(let c of to){let p=i[c.field];s[c.idName]=p.map(d=>d.id),p.forEach((d,S)=>{s[`${c.kodePrefix}${S+1}`]=d.kode,s[`${c.namaPrefix}${S+1}`]=d.nama})}return s}function Ri(i,s){let c=i[s];return typeof c=="string"?c:Array.isArray(c)?c[0]??"":""}function ug(i,s){if(i._source==="verif_action")return s;let c=structuredClone(s);for(let S of xc){let L=i[S];typeof L=="string"&&(c[S]=L)}let p=Ri(i,"diagnosa_utama");p&&(c.diagnosa_utama_nama=p);let d=S=>{let L=i[S.idName],C=Array.isArray(L)?L:[],R=[];for(let k=1;k<=10;k++){let z=Ri(i,`${S.kodePrefix}${k}`),N=Ri(i,`${S.namaPrefix}${k}`);!z&&!N||R.push({id:C[k-1]??"",kode:z,nama:N})}return R};return c.icd_sekunder=d(to[0]),c.icd_tindakan=d(to[1]),c.icd_nosokomial=d(to[2]),c}var dg=Ie(At(),1);function kc(i){var s,c,p="";if(typeof i=="string"||typeof i=="number")p+=i;else if(typeof i=="object")if(Array.isArray(i)){var d=i.length;for(s=0;s<d;s++)i[s]&&(c=kc(i[s]))&&(p&&(p+=" "),p+=c)}else for(c in i)i[c]&&(p&&(p+=" "),p+=c);return p}function Sc(){for(var i,s,c=0,p="",d=arguments.length;c<d;c++)(i=arguments[c])&&(s=kc(i))&&(p&&(p+=" "),p+=s);return p}var pg=(i,s)=>{let c=new Array(i.length+s.length);for(let p=0;p<i.length;p++)c[p]=i[p];for(let p=0;p<s.length;p++)c[i.length+p]=s[p];return c},fg=(i,s)=>({classGroupId:i,validator:s}),_c=(i=new Map,s=null,c)=>({nextPart:i,validators:s,classGroupId:c}),zc=[],mg="arbitrary..",gg=i=>{let s=bg(i),{conflictingClassGroups:c,conflictingClassGroupModifiers:p}=i;return{getClassGroupId:d=>{if(d.startsWith("[")&&d.endsWith("]"))return hg(d);let S=d.split("-"),L=S[0]===""&&S.length>1?1:0;return Cc(S,L,s)},getConflictingClassGroupIds:(d,S)=>{if(S){let L=p[d],C=c[d];return L?C?pg(C,L):L:C||zc}return c[d]||zc}}},Cc=(i,s,c)=>{if(i.length-s===0)return c.classGroupId;let p=i[s],d=c.nextPart.get(p);if(d){let R=Cc(i,s+1,d);if(R)return R}let S=c.validators;if(S===null)return;let L=s===0?i.join("-"):i.slice(s).join("-"),C=S.length;for(let R=0;R<C;R++){let k=S[R];if(k.validator(L))return k.classGroupId}},hg=i=>i.slice(1,-1).indexOf(":")===-1?void 0:(()=>{let s=i.slice(1,-1),c=s.indexOf(":"),p=s.slice(0,c);return p?mg+p:void 0})(),bg=i=>{let{theme:s,classGroups:c}=i;return vg(c,s)},vg=(i,s)=>{let c=_c();for(let p in i){let d=i[p];Oi(d,c,p,s)}return c},Oi=(i,s,c,p)=>{let d=i.length;for(let S=0;S<d;S++){let L=i[S];yg(L,s,c,p)}},yg=(i,s,c,p)=>{if(typeof i=="string"){wg(i,s,c);return}if(typeof i=="function"){xg(i,s,c,p);return}kg(i,s,c,p)},wg=(i,s,c)=>{let p=i===""?s:Ec(s,i);p.classGroupId=c},xg=(i,s,c,p)=>{if(Sg(i)){Oi(i(p),s,c,p);return}s.validators===null&&(s.validators=[]),s.validators.push(fg(c,i))},kg=(i,s,c,p)=>{let d=Object.entries(i),S=d.length;for(let L=0;L<S;L++){let[C,R]=d[L];Oi(R,Ec(s,C),c,p)}},Ec=(i,s)=>{let c=i,p=s.split("-"),d=p.length;for(let S=0;S<d;S++){let L=p[S],C=c.nextPart.get(L);C||(C=_c(),c.nextPart.set(L,C)),c=C}return c},Sg=i=>"isThemeGetter"in i&&i.isThemeGetter===!0,_g=i=>{if(i<1)return{get:()=>{},set:()=>{}};let s=0,c=Object.create(null),p=Object.create(null),d=(S,L)=>{c[S]=L,s++,s>i&&(s=0,p=c,c=Object.create(null))};return{get(S){let L=c[S];if(L!==void 0)return L;if((L=p[S])!==void 0)return d(S,L),L},set(S,L){S in c?c[S]=L:d(S,L)}}},zg=[],Nc=(i,s,c,p,d)=>({modifiers:i,hasImportantModifier:s,baseClassName:c,maybePostfixModifierPosition:p,isExternal:d}),Cg=i=>{let{prefix:s,experimentalParseClassName:c}=i,p=d=>{let S=[],L=0,C=0,R=0,k,z=d.length;for(let K=0;K<z;K++){let G=d[K];if(L===0&&C===0){if(G===":"){S.push(d.slice(R,K)),R=K+1;continue}if(G==="/"){k=K;continue}}G==="["?L++:G==="]"?L--:G==="("?C++:G===")"&&C--}let N=S.length===0?d:d.slice(R),O=N,re=!1;N.endsWith("!")?(O=N.slice(0,-1),re=!0):N.startsWith("!")&&(O=N.slice(1),re=!0);let se=k&&k>R?k-R:void 0;return Nc(S,re,O,se)};if(s){let d=s+":",S=p;p=L=>L.startsWith(d)?S(L.slice(d.length)):Nc(zg,!1,L,void 0,!0)}if(c){let d=p;p=S=>c({className:S,parseClassName:d})}return p},Eg=i=>{let s=new Map;return i.orderSensitiveModifiers.forEach((c,p)=>{s.set(c,1e6+p)}),c=>{let p=[],d=[];for(let S=0;S<c.length;S++){let L=c[S],C=L[0]==="[",R=s.has(L);C||R?(d.length>0&&(d.sort(),p.push(...d),d=[]),p.push(L)):d.push(L)}return d.length>0&&(d.sort(),p.push(...d)),p}},Ng=i=>({cache:_g(i.cacheSize),parseClassName:Cg(i),sortModifiers:Eg(i),postfixLookupClassGroupIds:Pg(i),...gg(i)}),Pg=i=>{let s=Object.create(null),c=i.postfixLookupClassGroups;if(c)for(let p=0;p<c.length;p++)s[c[p]]=!0;return s},jg=/\s+/,Lg=(i,s)=>{let{parseClassName:c,getClassGroupId:p,getConflictingClassGroupIds:d,sortModifiers:S,postfixLookupClassGroupIds:L}=s,C=[],R=i.trim().split(jg),k="";for(let z=R.length-1;z>=0;z-=1){let N=R[z],{isExternal:O,modifiers:re,hasImportantModifier:se,baseClassName:K,maybePostfixModifierPosition:G}=c(N);if(O){k=N+(k.length>0?" "+k:k);continue}let ze=!!G,pe;if(ze){let w=K.substring(0,G);pe=p(w);let E=pe&&L[pe]?p(K):void 0;E&&E!==pe&&(pe=E,ze=!1)}else pe=p(K);if(!pe){if(!ze){k=N+(k.length>0?" "+k:k);continue}if(pe=p(K),!pe){k=N+(k.length>0?" "+k:k);continue}ze=!1}let Ue=re.length===0?"":re.length===1?re[0]:S(re).join(":"),oe=se?Ue+"!":Ue,ye=oe+pe;if(C.indexOf(ye)>-1)continue;C.push(ye);let be=d(pe,ze);for(let w=0;w<be.length;++w){let E=be[w];C.push(oe+E)}k=N+(k.length>0?" "+k:k)}return k},Tg=(...i)=>{let s=0,c,p,d="";for(;s<i.length;)(c=i[s++])&&(p=Pc(c))&&(d&&(d+=" "),d+=p);return d},Pc=i=>{if(typeof i=="string")return i;let s,c="";for(let p=0;p<i.length;p++)i[p]&&(s=Pc(i[p]))&&(c&&(c+=" "),c+=s);return c},Ag=(i,...s)=>{let c,p,d,S,L=R=>{let k=s.reduce((z,N)=>N(z),i());return c=Ng(k),p=c.cache.get,d=c.cache.set,S=C,C(R)},C=R=>{let k=p(R);if(k)return k;let z=Lg(R,c);return d(R,z),z};return S=L,(...R)=>S(Tg(...R))},Rg=[],Be=i=>{let s=c=>c[i]||Rg;return s.isThemeGetter=!0,s},jc=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,Lc=/^\((?:(\w[\w-]*):)?(.+)\)$/i,Og=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,Mg=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,Dg=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,Fg=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,Ig=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,Ug=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,hr=i=>Og.test(i),te=i=>!!i&&!Number.isNaN(Number(i)),Ht=i=>!!i&&Number.isInteger(Number(i)),Mi=i=>i.endsWith("%")&&te(i.slice(0,-1)),Kt=i=>Mg.test(i),Tc=()=>!0,$g=i=>Dg.test(i)&&!Fg.test(i),Di=()=>!1,Hg=i=>Ig.test(i),Vg=i=>Ug.test(i),qg=i=>!H(i)&&!V(i),Bg=i=>i.startsWith("@container")&&(i[10]==="/"&&i[11]!==void 0||i[11]==="s"&&i[16]!==void 0&&i.startsWith("-size/",10)||i[11]==="n"&&i[18]!==void 0&&i.startsWith("-normal/",10)),Wg=i=>br(i,Fc,Di),H=i=>jc.test(i),Br=i=>br(i,Ic,$g),Ac=i=>br(i,eh,te),Qg=i=>br(i,$c,Tc),Kg=i=>br(i,Uc,Di),Rc=i=>br(i,Mc,Di),Yg=i=>br(i,Dc,Vg),ro=i=>br(i,Hc,Hg),V=i=>Lc.test(i),ra=i=>Wr(i,Ic),Xg=i=>Wr(i,Uc),Oc=i=>Wr(i,Mc),Gg=i=>Wr(i,Fc),Jg=i=>Wr(i,Dc),no=i=>Wr(i,Hc,!0),Zg=i=>Wr(i,$c,!0),br=(i,s,c)=>{let p=jc.exec(i);return p?p[1]?s(p[1]):c(p[2]):!1},Wr=(i,s,c=!1)=>{let p=Lc.exec(i);return p?p[1]?s(p[1]):c:!1},Mc=i=>i==="position"||i==="percentage",Dc=i=>i==="image"||i==="url",Fc=i=>i==="length"||i==="size"||i==="bg-size",Ic=i=>i==="length",eh=i=>i==="number",Uc=i=>i==="family-name",$c=i=>i==="number"||i==="weight",Hc=i=>i==="shadow",th=()=>{let i=Be("color"),s=Be("font"),c=Be("text"),p=Be("font-weight"),d=Be("tracking"),S=Be("leading"),L=Be("breakpoint"),C=Be("container"),R=Be("spacing"),k=Be("radius"),z=Be("shadow"),N=Be("inset-shadow"),O=Be("text-shadow"),re=Be("drop-shadow"),se=Be("blur"),K=Be("perspective"),G=Be("aspect"),ze=Be("ease"),pe=Be("animate"),Ue=()=>["auto","avoid","all","avoid-page","page","left","right","column"],oe=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],ye=()=>[...oe(),V,H],be=()=>["auto","hidden","clip","visible","scroll"],w=()=>["auto","contain","none"],E=()=>[V,H,R],B=()=>[hr,"full","auto",...E()],Ne=()=>[Ht,"none","subgrid",V,H],Ae=()=>["auto",{span:["full",Ht,V,H]},Ht,V,H],Re=()=>[Ht,"auto",V,H],lt=()=>["auto","min","max","fr",V,H],Rt=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],Ke=()=>["start","end","center","stretch","center-safe","end-safe"],D=()=>["auto",...E()],M=()=>[hr,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...E()],I=()=>[hr,"screen","full","dvw","lvw","svw","min","max","fit",...E()],ce=()=>[hr,"screen","full","lh","dvh","lvh","svh","min","max","fit",...E()],U=()=>[i,V,H],at=()=>[...oe(),Oc,Rc,{position:[V,H]}],g=()=>["no-repeat",{repeat:["","x","y","space","round"]}],A=()=>["auto","cover","contain",Gg,Wg,{size:[V,H]}],F=()=>[Mi,ra,Br],$=()=>["","none","full",k,V,H],Y=()=>["",te,ra,Br],J=()=>["solid","dashed","dotted","double"],me=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],fe=()=>[te,Mi,Oc,Rc],Le=()=>["","none",se,V,H],Vt=()=>["none",te,V,H],Gt=()=>["none",te,V,H],Kr=()=>[te,V,H],Yr=()=>[hr,"full",...E()];return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[Kt],breakpoint:[Kt],color:[Tc],container:[Kt],"drop-shadow":[Kt],ease:["in","out","in-out"],font:[qg],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[Kt],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[Kt],shadow:[Kt],spacing:["px",te],text:[Kt],"text-shadow":[Kt],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",hr,H,V,G]}],container:["container"],"container-type":[{"@container":["","normal","size",V,H]}],"container-named":[Bg],columns:[{columns:[te,H,V,C]}],"break-after":[{"break-after":Ue()}],"break-before":[{"break-before":Ue()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:ye()}],overflow:[{overflow:be()}],"overflow-x":[{"overflow-x":be()}],"overflow-y":[{"overflow-y":be()}],overscroll:[{overscroll:w()}],"overscroll-x":[{"overscroll-x":w()}],"overscroll-y":[{"overscroll-y":w()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:B()}],"inset-x":[{"inset-x":B()}],"inset-y":[{"inset-y":B()}],start:[{"inset-s":B(),start:B()}],end:[{"inset-e":B(),end:B()}],"inset-bs":[{"inset-bs":B()}],"inset-be":[{"inset-be":B()}],top:[{top:B()}],right:[{right:B()}],bottom:[{bottom:B()}],left:[{left:B()}],visibility:["visible","invisible","collapse"],z:[{z:[Ht,"auto",V,H]}],basis:[{basis:[hr,"full","auto",C,...E()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[te,hr,"auto","initial","none",H]}],grow:[{grow:["",te,V,H]}],shrink:[{shrink:["",te,V,H]}],order:[{order:[Ht,"first","last","none",V,H]}],"grid-cols":[{"grid-cols":Ne()}],"col-start-end":[{col:Ae()}],"col-start":[{"col-start":Re()}],"col-end":[{"col-end":Re()}],"grid-rows":[{"grid-rows":Ne()}],"row-start-end":[{row:Ae()}],"row-start":[{"row-start":Re()}],"row-end":[{"row-end":Re()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":lt()}],"auto-rows":[{"auto-rows":lt()}],gap:[{gap:E()}],"gap-x":[{"gap-x":E()}],"gap-y":[{"gap-y":E()}],"justify-content":[{justify:[...Rt(),"normal"]}],"justify-items":[{"justify-items":[...Ke(),"normal"]}],"justify-self":[{"justify-self":["auto",...Ke()]}],"align-content":[{content:["normal",...Rt()]}],"align-items":[{items:[...Ke(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...Ke(),{baseline:["","last"]}]}],"place-content":[{"place-content":Rt()}],"place-items":[{"place-items":[...Ke(),"baseline"]}],"place-self":[{"place-self":["auto",...Ke()]}],p:[{p:E()}],px:[{px:E()}],py:[{py:E()}],ps:[{ps:E()}],pe:[{pe:E()}],pbs:[{pbs:E()}],pbe:[{pbe:E()}],pt:[{pt:E()}],pr:[{pr:E()}],pb:[{pb:E()}],pl:[{pl:E()}],m:[{m:D()}],mx:[{mx:D()}],my:[{my:D()}],ms:[{ms:D()}],me:[{me:D()}],mbs:[{mbs:D()}],mbe:[{mbe:D()}],mt:[{mt:D()}],mr:[{mr:D()}],mb:[{mb:D()}],ml:[{ml:D()}],"space-x":[{"space-x":E()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":E()}],"space-y-reverse":["space-y-reverse"],size:[{size:M()}],"inline-size":[{inline:["auto",...I()]}],"min-inline-size":[{"min-inline":["auto",...I()]}],"max-inline-size":[{"max-inline":["none",...I()]}],"block-size":[{block:["auto",...ce()]}],"min-block-size":[{"min-block":["auto",...ce()]}],"max-block-size":[{"max-block":["none",...ce()]}],w:[{w:[C,"screen",...M()]}],"min-w":[{"min-w":[C,"screen","none",...M()]}],"max-w":[{"max-w":[C,"screen","none","prose",{screen:[L]},...M()]}],h:[{h:["screen","lh",...M()]}],"min-h":[{"min-h":["screen","lh","none",...M()]}],"max-h":[{"max-h":["screen","lh",...M()]}],"font-size":[{text:["base",c,ra,Br]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[p,Zg,Qg]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",Mi,H]}],"font-family":[{font:[Xg,Kg,s]}],"font-features":[{"font-features":[H]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[d,V,H]}],"line-clamp":[{"line-clamp":[te,"none",V,Ac]}],leading:[{leading:[S,...E()]}],"list-image":[{"list-image":["none",V,H]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",V,H]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:U()}],"text-color":[{text:U()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...J(),"wavy"]}],"text-decoration-thickness":[{decoration:[te,"from-font","auto",V,Br]}],"text-decoration-color":[{decoration:U()}],"underline-offset":[{"underline-offset":[te,"auto",V,H]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:E()}],"tab-size":[{tab:[Ht,V,H]}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",V,H]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",V,H]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:at()}],"bg-repeat":[{bg:g()}],"bg-size":[{bg:A()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},Ht,V,H],radial:["",V,H],conic:[Ht,V,H]},Jg,Yg]}],"bg-color":[{bg:U()}],"gradient-from-pos":[{from:F()}],"gradient-via-pos":[{via:F()}],"gradient-to-pos":[{to:F()}],"gradient-from":[{from:U()}],"gradient-via":[{via:U()}],"gradient-to":[{to:U()}],rounded:[{rounded:$()}],"rounded-s":[{"rounded-s":$()}],"rounded-e":[{"rounded-e":$()}],"rounded-t":[{"rounded-t":$()}],"rounded-r":[{"rounded-r":$()}],"rounded-b":[{"rounded-b":$()}],"rounded-l":[{"rounded-l":$()}],"rounded-ss":[{"rounded-ss":$()}],"rounded-se":[{"rounded-se":$()}],"rounded-ee":[{"rounded-ee":$()}],"rounded-es":[{"rounded-es":$()}],"rounded-tl":[{"rounded-tl":$()}],"rounded-tr":[{"rounded-tr":$()}],"rounded-br":[{"rounded-br":$()}],"rounded-bl":[{"rounded-bl":$()}],"border-w":[{border:Y()}],"border-w-x":[{"border-x":Y()}],"border-w-y":[{"border-y":Y()}],"border-w-s":[{"border-s":Y()}],"border-w-e":[{"border-e":Y()}],"border-w-bs":[{"border-bs":Y()}],"border-w-be":[{"border-be":Y()}],"border-w-t":[{"border-t":Y()}],"border-w-r":[{"border-r":Y()}],"border-w-b":[{"border-b":Y()}],"border-w-l":[{"border-l":Y()}],"divide-x":[{"divide-x":Y()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":Y()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...J(),"hidden","none"]}],"divide-style":[{divide:[...J(),"hidden","none"]}],"border-color":[{border:U()}],"border-color-x":[{"border-x":U()}],"border-color-y":[{"border-y":U()}],"border-color-s":[{"border-s":U()}],"border-color-e":[{"border-e":U()}],"border-color-bs":[{"border-bs":U()}],"border-color-be":[{"border-be":U()}],"border-color-t":[{"border-t":U()}],"border-color-r":[{"border-r":U()}],"border-color-b":[{"border-b":U()}],"border-color-l":[{"border-l":U()}],"divide-color":[{divide:U()}],"outline-style":[{outline:[...J(),"none","hidden"]}],"outline-offset":[{"outline-offset":[te,V,H]}],"outline-w":[{outline:["",te,ra,Br]}],"outline-color":[{outline:U()}],shadow:[{shadow:["","none",z,no,ro]}],"shadow-color":[{shadow:U()}],"inset-shadow":[{"inset-shadow":["none",N,no,ro]}],"inset-shadow-color":[{"inset-shadow":U()}],"ring-w":[{ring:Y()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:U()}],"ring-offset-w":[{"ring-offset":[te,Br]}],"ring-offset-color":[{"ring-offset":U()}],"inset-ring-w":[{"inset-ring":Y()}],"inset-ring-color":[{"inset-ring":U()}],"text-shadow":[{"text-shadow":["none",O,no,ro]}],"text-shadow-color":[{"text-shadow":U()}],opacity:[{opacity:[te,V,H]}],"mix-blend":[{"mix-blend":[...me(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":me()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[te]}],"mask-image-linear-from-pos":[{"mask-linear-from":fe()}],"mask-image-linear-to-pos":[{"mask-linear-to":fe()}],"mask-image-linear-from-color":[{"mask-linear-from":U()}],"mask-image-linear-to-color":[{"mask-linear-to":U()}],"mask-image-t-from-pos":[{"mask-t-from":fe()}],"mask-image-t-to-pos":[{"mask-t-to":fe()}],"mask-image-t-from-color":[{"mask-t-from":U()}],"mask-image-t-to-color":[{"mask-t-to":U()}],"mask-image-r-from-pos":[{"mask-r-from":fe()}],"mask-image-r-to-pos":[{"mask-r-to":fe()}],"mask-image-r-from-color":[{"mask-r-from":U()}],"mask-image-r-to-color":[{"mask-r-to":U()}],"mask-image-b-from-pos":[{"mask-b-from":fe()}],"mask-image-b-to-pos":[{"mask-b-to":fe()}],"mask-image-b-from-color":[{"mask-b-from":U()}],"mask-image-b-to-color":[{"mask-b-to":U()}],"mask-image-l-from-pos":[{"mask-l-from":fe()}],"mask-image-l-to-pos":[{"mask-l-to":fe()}],"mask-image-l-from-color":[{"mask-l-from":U()}],"mask-image-l-to-color":[{"mask-l-to":U()}],"mask-image-x-from-pos":[{"mask-x-from":fe()}],"mask-image-x-to-pos":[{"mask-x-to":fe()}],"mask-image-x-from-color":[{"mask-x-from":U()}],"mask-image-x-to-color":[{"mask-x-to":U()}],"mask-image-y-from-pos":[{"mask-y-from":fe()}],"mask-image-y-to-pos":[{"mask-y-to":fe()}],"mask-image-y-from-color":[{"mask-y-from":U()}],"mask-image-y-to-color":[{"mask-y-to":U()}],"mask-image-radial":[{"mask-radial":[V,H]}],"mask-image-radial-from-pos":[{"mask-radial-from":fe()}],"mask-image-radial-to-pos":[{"mask-radial-to":fe()}],"mask-image-radial-from-color":[{"mask-radial-from":U()}],"mask-image-radial-to-color":[{"mask-radial-to":U()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":oe()}],"mask-image-conic-pos":[{"mask-conic":[te]}],"mask-image-conic-from-pos":[{"mask-conic-from":fe()}],"mask-image-conic-to-pos":[{"mask-conic-to":fe()}],"mask-image-conic-from-color":[{"mask-conic-from":U()}],"mask-image-conic-to-color":[{"mask-conic-to":U()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:at()}],"mask-repeat":[{mask:g()}],"mask-size":[{mask:A()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",V,H]}],filter:[{filter:["","none",V,H]}],blur:[{blur:Le()}],brightness:[{brightness:[te,V,H]}],contrast:[{contrast:[te,V,H]}],"drop-shadow":[{"drop-shadow":["","none",re,no,ro]}],"drop-shadow-color":[{"drop-shadow":U()}],grayscale:[{grayscale:["",te,V,H]}],"hue-rotate":[{"hue-rotate":[te,V,H]}],invert:[{invert:["",te,V,H]}],saturate:[{saturate:[te,V,H]}],sepia:[{sepia:["",te,V,H]}],"backdrop-filter":[{"backdrop-filter":["","none",V,H]}],"backdrop-blur":[{"backdrop-blur":Le()}],"backdrop-brightness":[{"backdrop-brightness":[te,V,H]}],"backdrop-contrast":[{"backdrop-contrast":[te,V,H]}],"backdrop-grayscale":[{"backdrop-grayscale":["",te,V,H]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[te,V,H]}],"backdrop-invert":[{"backdrop-invert":["",te,V,H]}],"backdrop-opacity":[{"backdrop-opacity":[te,V,H]}],"backdrop-saturate":[{"backdrop-saturate":[te,V,H]}],"backdrop-sepia":[{"backdrop-sepia":["",te,V,H]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":E()}],"border-spacing-x":[{"border-spacing-x":E()}],"border-spacing-y":[{"border-spacing-y":E()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",V,H]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[te,"initial",V,H]}],ease:[{ease:["linear","initial",ze,V,H]}],delay:[{delay:[te,V,H]}],animate:[{animate:["none",pe,V,H]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[K,V,H]}],"perspective-origin":[{"perspective-origin":ye()}],rotate:[{rotate:Vt()}],"rotate-x":[{"rotate-x":Vt()}],"rotate-y":[{"rotate-y":Vt()}],"rotate-z":[{"rotate-z":Vt()}],scale:[{scale:Gt()}],"scale-x":[{"scale-x":Gt()}],"scale-y":[{"scale-y":Gt()}],"scale-z":[{"scale-z":Gt()}],"scale-3d":["scale-3d"],skew:[{skew:Kr()}],"skew-x":[{"skew-x":Kr()}],"skew-y":[{"skew-y":Kr()}],transform:[{transform:[V,H,"","none","gpu","cpu"]}],"transform-origin":[{origin:ye()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:Yr()}],"translate-x":[{"translate-x":Yr()}],"translate-y":[{"translate-y":Yr()}],"translate-z":[{"translate-z":Yr()}],"translate-none":["translate-none"],zoom:[{zoom:[Ht,V,H]}],accent:[{accent:U()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:U()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",V,H]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scrollbar-thumb-color":[{"scrollbar-thumb":U()}],"scrollbar-track-color":[{"scrollbar-track":U()}],"scrollbar-gutter":[{"scrollbar-gutter":["auto","stable","both"]}],"scrollbar-w":[{scrollbar:["auto","thin","none"]}],"scroll-m":[{"scroll-m":E()}],"scroll-mx":[{"scroll-mx":E()}],"scroll-my":[{"scroll-my":E()}],"scroll-ms":[{"scroll-ms":E()}],"scroll-me":[{"scroll-me":E()}],"scroll-mbs":[{"scroll-mbs":E()}],"scroll-mbe":[{"scroll-mbe":E()}],"scroll-mt":[{"scroll-mt":E()}],"scroll-mr":[{"scroll-mr":E()}],"scroll-mb":[{"scroll-mb":E()}],"scroll-ml":[{"scroll-ml":E()}],"scroll-p":[{"scroll-p":E()}],"scroll-px":[{"scroll-px":E()}],"scroll-py":[{"scroll-py":E()}],"scroll-ps":[{"scroll-ps":E()}],"scroll-pe":[{"scroll-pe":E()}],"scroll-pbs":[{"scroll-pbs":E()}],"scroll-pbe":[{"scroll-pbe":E()}],"scroll-pt":[{"scroll-pt":E()}],"scroll-pr":[{"scroll-pr":E()}],"scroll-pb":[{"scroll-pb":E()}],"scroll-pl":[{"scroll-pl":E()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",V,H]}],fill:[{fill:["none",...U()]}],"stroke-w":[{stroke:[te,ra,Br,Ac]}],stroke:[{stroke:["none",...U()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{"container-named":["container-type"],overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},postfixLookupClassGroups:["container-type"],orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}},rh=Ag(th);function Yt(...i){return rh(Sc(i))}var nh=Ie($t(),1),vr=(0,dg.forwardRef)(({className:i,type:s,...c},p)=>(0,nh.jsx)("input",{type:s,className:Yt("flex h-11 w-full rounded-lg border-2 border-input bg-background px-3.5 py-2.5 text-base text-foreground leading-normal","placeholder:text-muted-foreground","focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 border-primary/50","disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted",i),ref:p,...c}));vr.displayName="Input";var Fi=Ie(At(),1),ah=Ie($t(),1),Ge=(0,Fi.forwardRef)(({className:i,autoResize:s=!0,onChange:c,...p},d)=>{let S=(0,Fi.useRef)(null),L=d||S;(0,Fi.useEffect)(()=>{s&&L.current&&(L.current.style.height="auto",L.current.style.height=L.current.scrollHeight+"px")},[p.value,s,L]);let C=R=>{s&&(R.target.style.height="auto",R.target.style.height=R.target.scrollHeight+"px"),c?.(R)};return(0,ah.jsx)("textarea",{ref:L,className:Yt("flex w-full rounded-lg border-2 border-input bg-background px-3.5 py-3 text-base text-foreground leading-[1.7]","placeholder:text-muted-foreground","focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 border-primary/50","disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted","resize-y min-h-[80px]",i),onChange:C,...p})});Ge.displayName="Textarea";var Vc=Ie($t(),1);function Ee({className:i,required:s,helperText:c,children:p,...d}){return(0,Vc.jsxs)("label",{className:Yt("block text-base font-semibold text-foreground uppercase tracking-[0.03em] mb-1.5",i),...d,children:[p,s&&(0,Vc.jsx)("span",{className:"text-destructive ml-1","aria-hidden":"true",children:"*"})]})}var ao=Ie($t(),1);function Qr({title:i,children:s,className:c}){return(0,ao.jsxs)("div",{className:Yt("bg-background border-2 border-border rounded-xl mb-4 overflow-hidden shadow-sm",c),children:[(0,ao.jsxs)("div",{className:"px-4 py-3 bg-primary/5 border-b border-primary/20 text-base font-bold text-primary flex items-center gap-2",children:[(0,ao.jsx)("span",{className:"text-base","aria-hidden":"true",children:"\u25CF"}),i]}),(0,ao.jsx)("div",{className:"p-4 space-y-4",children:s})]})}var qc=Ie($t(),1);function Ii({children:i,cols:s=2,className:c}){return(0,qc.jsx)("div",{className:Yt("grid gap-4",s===2&&"grid-cols-1 md:grid-cols-2",s===3&&"grid-cols-1 md:grid-cols-2 lg:grid-cols-3",c),children:i})}function Xt({children:i,className:s}){return(0,qc.jsx)("div",{className:Yt("col-span-full",s),children:i})}var oh=Ie(At(),1),Bc=Ie($t(),1),na=(0,oh.forwardRef)(({className:i,options:s,...c},p)=>(0,Bc.jsx)("select",{className:Yt("flex h-11 w-full rounded-lg border-2 border-input bg-background px-3.5 py-2.5 text-base text-foreground","focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 border-primary/50","disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted",i),ref:p,...c,children:s.map(d=>(0,Bc.jsx)("option",{value:d.value,children:d.label},d.value))}));na.displayName="SelectNative";var ih=Ie(At(),1),Wc=i=>typeof i=="boolean"?`${i}`:i===0?"0":i,Qc=Sc,lh=(i,s)=>c=>{var p;if(s?.variants==null)return Qc(i,c?.class,c?.className);let{variants:d,defaultVariants:S}=s,L=Object.keys(d).map(k=>{let z=c?.[k],N=S?.[k];if(z===null)return null;let O=Wc(z)||Wc(N);return d[k][O]}),C=c&&Object.entries(c).reduce((k,z)=>{let[N,O]=z;return O===void 0||(k[N]=O),k},{}),R=s==null||(p=s.compoundVariants)===null||p===void 0?void 0:p.reduce((k,z)=>{let{class:N,className:O,...re}=z;return Object.entries(re).every(se=>{let[K,G]=se;return Array.isArray(G)?G.includes({...S,...C}[K]):{...S,...C}[K]===G})?[...k,N,O]:k},[]);return Qc(i,L,R,c?.class,c?.className)},sh=Ie($t(),1),ch=lh("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-base font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-5 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground shadow-sm hover:bg-primary/90 active:bg-primary",destructive:"bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90 active:bg-destructive",outline:"border-2 border-border bg-background shadow-sm hover:bg-accent hover:text-accent-foreground active:bg-accent",secondary:"bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80 active:bg-secondary",success:"bg-green-600 text-green-50 shadow-sm hover:bg-green-600/90 active:bg-green-600",dark:"bg-neutral-950 text-white shadow-sm hover:bg-neutral-900 active:bg-neutral-950",ghost:"hover:bg-accent hover:text-accent-foreground active:bg-accent",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-11 px-5 min-w-[90px]",sm:"h-9 px-3.5 min-w-[80px]",xs:"h-7 px-2.5 min-w-0 gap-1.5 text-xs font-medium [&_svg]:size-3.5",lg:"h-12 px-6 text-base min-w-[100px]",xl:"h-13 px-7 text-lg min-w-[110px]",icon:"h-11 w-11"}},defaultVariants:{variant:"default",size:"default"}}),hn=(0,ih.forwardRef)(({className:i,variant:s,size:c,...p},d)=>(0,sh.jsx)("button",{className:Yt(ch({variant:s,size:c,className:i})),ref:d,...p}));hn.displayName="Button";var Kc=Ie(At(),1),Yc=(...i)=>i.filter((s,c,p)=>!!s&&s.trim()!==""&&p.indexOf(s)===c).join(" ").trim(),uh=i=>i.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),dh=i=>i.replace(/^([A-Z])|[\s-_]+(\w)/g,(s,c,p)=>p?p.toUpperCase():c.toLowerCase()),Xc=i=>{let s=dh(i);return s.charAt(0).toUpperCase()+s.slice(1)},Ui=Ie(At(),1),$i={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"},ph=i=>{for(let s in i)if(s.startsWith("aria-")||s==="role"||s==="title")return!0;return!1},Gc=Ie(At(),1),fh=(0,Gc.createContext)({}),mh=()=>(0,Gc.useContext)(fh),gh=(0,Ui.forwardRef)(({color:i,size:s,strokeWidth:c,absoluteStrokeWidth:p,className:d="",children:S,iconNode:L,...C},R)=>{let{size:k=24,strokeWidth:z=2,absoluteStrokeWidth:N=!1,color:O="currentColor",className:re=""}=mh()??{},se=p??N?Number(c??z)*24/Number(s??k):c??z;return(0,Ui.createElement)("svg",{ref:R,...$i,width:s??k??$i.width,height:s??k??$i.height,stroke:i??O,strokeWidth:se,className:Yc("lucide",re,d),...!S&&!ph(C)&&{"aria-hidden":"true"},...C},[...L.map(([K,G])=>(0,Ui.createElement)(K,G)),...Array.isArray(S)?S:[S]])}),oo=(i,s)=>{let c=(0,Kc.forwardRef)(({className:p,...d},S)=>(0,Kc.createElement)(gh,{ref:S,iconNode:s,className:Yc(`lucide-${uh(Xc(i))}`,`lucide-${i}`,p),...d}));return c.displayName=Xc(i),c},hh=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],bh=oo("check",hh),vh=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],yh=oo("info",vh),wh=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],xh=oo("triangle-alert",wh),kh=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Jc=oo("x",kh),io=Ie($t(),1),Sh={default:"bg-primary/10 text-primary border-primary/20",success:"bg-green-50 dark:bg-green-950/20 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800",warning:"bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800",danger:"bg-destructive/10 text-destructive border-destructive/20"},_h={default:yh,success:bh,warning:xh,danger:Jc};function Zc({variant:i="default",icon:s,children:c,className:p,onDismiss:d}){let S=_h[i];return(0,io.jsxs)("span",{className:Yt("inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-base font-semibold",Sh[i],p),children:[s&&(0,io.jsx)(S,{className:"size-3.5"}),c,d&&(0,io.jsx)("button",{onClick:d,className:"ml-1 hover:opacity-70 p-0.5","aria-label":"Dismiss",children:(0,io.jsx)(Jc,{className:"size-3.5"})})]})}var x=Ie($t(),1),zh=[{value:"",label:"Pilih jenis kasus"},{value:"203",label:"Jantung"},{value:"209",label:"Bedah Onkologi"},{value:"215",label:"Fisioterapi"},{value:"220",label:"Okupasi"},{value:"204",label:"Gigi"},{value:"206",label:"Jiwa"},{value:"207",label:"Mata"},{value:"211",label:"Paru"},{value:"212",label:"Syaraf"},{value:"214",label:"Urologi"},{value:"223",label:"Rehab Medis"},{value:"226",label:"Kulit Kelamin"},{value:"216",label:"Bedah Syaraf"},{value:"219",label:"Geriatri"},{value:"221",label:"Paru - Paru"},{value:"217",label:"Psikiatri"},{value:"181",label:"Kulit Kelamin"},{value:"205",label:"Non Bedah"},{value:"208",label:"Bedah"},{value:"218",label:"Orthopedi"},{value:"224",label:"Psikologi"},{value:"225",label:"Tht"},{value:"210",label:"Anak"},{value:"213",label:"Kebidanan dan Kandungan"},{value:"222",label:"Penyakit Dalam"},{value:"228",label:"Gigi"}],Ch=[{value:"",label:"Pilih keadaan keluar"},{value:"31",label:"Aps / Atas Permintaan Sendiri"},{value:"73",label:"Batal Rawat Inap"},{value:"30",label:"Belum Sembuh"},{value:"121",label:"Dirujuk Lebih Tinggi"},{value:"181",label:"Melarikan Diri"},{value:"32",label:"Meninggal < 48 Jam"},{value:"74",label:"Meninggal > 8 Jam"},{value:"33",label:"Meninggal >= 48 jam"},{value:"87",label:"Pulang Hidup"}],Eh=[{value:"",label:"Pilih cara keluar"},{value:"167",label:"APS/Paksa"},{value:"35",label:"Atas Permintaan Sendiri"},{value:"142",label:"Atas Persetujuan Dokter"},{value:"201",label:"Batal Rawat Inap"},{value:"141",label:"Di Rujuk"},{value:"51",label:"Diijinkan Pulang"},{value:"163",label:"Dirujuk"},{value:"164",label:"Dirujuk Lebih Rendah"},{value:"165",label:"Dirujuk Puskesmas"},{value:"162",label:"Dirujuk ke Dokter"},{value:"166",label:"Dirujuk ke Panti"},{value:"168",label:"Ke Rumah Sakit"},{value:"72",label:"Lain-lain"},{value:"169",label:"Masih Menginap"},{value:"57",label:"Masuk Rawat Inap"},{value:"58",label:"Melarikan Diri"},{value:"143",label:"Meninggal"},{value:"170",label:"Meninggal Kurang 48 Jam"},{value:"171",label:"Meninggal Lebih 48 Jam"},{value:"161",label:"Pulang Hidup"}],Nh=[{value:"",label:"Pilih pemeriksaan lanjut"},{value:"52",label:"Bangsal"},{value:"88",label:"Kontrol"},{value:"11",label:"Lainnya"},{value:"8",label:"Poliklinik RS"},{value:"10",label:"Puskesmas"},{value:"9",label:"RS Lain"},{value:"49",label:"Tidak Ada"}];function eu({kode:i,nama:s,icdType:c,onPick:p}){let[d,S]=(0,Qe.useState)([]),[L,C]=(0,Qe.useState)(!1),[R,k]=(0,Qe.useState)(i),[z,N]=(0,Qe.useState)(s);(0,Qe.useEffect)(()=>{k(i)},[i]),(0,Qe.useEffect)(()=>{N(s)},[s]);let[O,re]=(0,Qe.useState)(-1),se=(0,Qe.useRef)(void 0),K=(0,Qe.useRef)(null),G=(0,Qe.useRef)(null),[ze,pe]=(0,Qe.useState)({top:0,left:0,width:0});(0,Qe.useEffect)(()=>{G.current?.scrollIntoView({block:"nearest"})},[O]);let Ue=(0,Qe.useCallback)(async w=>{if(w.length<3){S([]),C(!1);return}let E=`/rekam-medik/search?opsi=${c==="icd9"?"clauseDiagnose_icd9":"kodeicd10"}&q=${encodeURIComponent(w)}${c==="icd9"?"&limit=10":""}`;try{let B=await(await fetch(E,{credentials:"same-origin"})).text(),Ne;try{Ne=JSON.parse(B)}catch{Ne=B.split(`
`).filter(Boolean).map(Ae=>{let Re=Ae.split("|");return{ID:Re[2]||"",KODE:Re[1]||"",NAMA:Re[0]||""}})}if(S(Ne),C(Ne.length>0),re(-1),K.current){let Ae=K.current.getBoundingClientRect();pe({top:Ae.top,left:Ae.left,width:Ae.width})}}catch{}},[c]),oe=w=>{k(w),clearTimeout(se.current),se.current=setTimeout(()=>Ue(w),300)},ye=w=>{k(w.KODE),N(w.NAMA),C(!1),p(w.KODE,w.NAMA,w.ID)};(0,Qe.useEffect)(()=>{let w=K.current?.getRootNode?.()??document,E=Ne=>{K.current&&!K.current.contains(Ne.target)&&C(!1)};w.addEventListener("mousedown",E);let B=Ne=>{let Ae=document.getElementById("morbis-manap-root");Ae&&(Ne.target===Ae||Ae.contains(Ne.target))||C(!1)};return document.addEventListener("mousedown",B),()=>{w.removeEventListener("mousedown",E),document.removeEventListener("mousedown",B)}},[]);let be=w=>{L&&(w.key==="ArrowDown"&&(w.preventDefault(),re(E=>Math.min(E+1,d.length-1))),w.key==="ArrowUp"&&(w.preventDefault(),re(E=>Math.max(E-1,0))),w.key==="Enter"&&O>=0&&(w.preventDefault(),ye(d[O])),w.key==="Escape"&&C(!1))};return(0,x.jsxs)("div",{ref:K,className:"relative flex-1 min-w-0",children:[(0,x.jsxs)("div",{className:"flex gap-2",children:[(0,x.jsx)("div",{className:"flex-1 min-w-0",children:(0,x.jsx)(vr,{value:z,onChange:w=>N(w.target.value),onKeyDown:be,placeholder:"Nama",className:"text-base font-medium","aria-label":"Nama diagnosis"})}),(0,x.jsx)("div",{className:"w-28 shrink-0",children:(0,x.jsx)(vr,{value:R,onChange:w=>oe(w.target.value),onKeyDown:be,placeholder:"Kode",className:"text-base font-mono font-semibold","aria-label":"Kode ICD"})})]}),L&&d.length>0&&(0,x.jsx)("div",{className:"fixed z-[2147483647] bg-popover border-2 border-border rounded-xl max-h-[280px] overflow-auto shadow-xl",style:{top:ze.top,left:ze.left,width:ze.width},role:"listbox",children:d.map((w,E)=>{let B=E===O;return(0,x.jsxs)("div",{ref:B?G:void 0,onClick:()=>ye(w),onMouseEnter:()=>re(E),role:"option","aria-selected":B,className:`px-4 py-3 text-base cursor-pointer border-b last:border-b-0 border-border transition-colors ${B?"bg-primary text-primary-foreground":"bg-popover hover:bg-accent"}`,children:[(0,x.jsxs)("div",{className:"flex items-center justify-between gap-2",children:[(0,x.jsx)("span",{className:`font-mono text-base font-bold ${B?"text-primary-foreground":"text-primary"}`,children:w.KODE}),B&&(0,x.jsx)("span",{className:"text-primary-foreground font-bold","aria-hidden":"true",children:"\u2713"})]}),(0,x.jsx)("div",{className:`${B?"text-primary-foreground":"text-foreground"} text-base font-medium leading-[1.6] mt-1`,children:w.NAMA})]},w.ID||`${w.KODE}-${ri}`)})})]})}function Hi({items:i,icdType:s,onChange:c,onAdd:p,onRemove:d,label:S,emptyText:L}){return(0,x.jsxs)("div",{className:i.length?"mb-3":"",children:[(0,x.jsxs)("div",{className:"flex items-center gap-2.5 mb-2",children:[(0,x.jsx)("span",{className:"text-base font-bold text-foreground tracking-tight",children:S}),(0,x.jsxs)("span",{className:"text-base text-muted-foreground",children:["(",i.length," item)"]})]}),i.length>0&&(0,x.jsxs)(x.Fragment,{children:[(0,x.jsxs)("div",{className:"flex gap-2 text-base font-bold text-muted-foreground px-1 mb-1",children:[(0,x.jsx)("span",{className:"flex-1",children:"Nama"}),(0,x.jsx)("span",{className:"w-28",children:"Kode ICD"}),(0,x.jsx)("span",{className:"w-[76px] text-right",children:"Aksi"})]}),(0,x.jsx)("div",{className:"flex flex-col gap-2",children:i.map((C,R)=>(0,x.jsxs)("div",{className:"flex gap-2 items-center",children:[(0,x.jsx)(eu,{kode:C.kode,nama:C.nama,icdType:s,onPick:(k,z,N)=>c(R,{...C,kode:k,nama:z,id:N})}),(0,x.jsx)(hn,{variant:"destructive",size:"default",type:"button",onClick:()=>d(R),"aria-label":`Hapus ${S} ${R+1}`,className:"w-[76px] shrink-0",children:"Hapus"})]},R))})]}),i.length===0&&(0,x.jsx)("div",{className:"border-2 border-dashed border-border rounded-xl py-6 text-center bg-background mb-2",children:(0,x.jsx)("p",{className:"text-base text-muted-foreground",children:L})}),(0,x.jsxs)(hn,{variant:"default",size:"default",type:"button",onClick:p,className:"gap-2 w-full mt-2",children:["\uFF0B Tambah"," ",S.includes("Sekunder")?"Diagnosa":S.includes("Tindakan")?"Tindakan":S.includes("Nosokomial")?"Nosokomial":"Item"]})]})}var tu={gcs_e:4,gcs_m:6,gcs_v:5},Ph={gcs_e:"1-4",gcs_m:"1-6",gcs_v:"1-5"},jh={tensi:"Tekanan Darah (TD)",nadi:"Nadi (N)",suhu:"Suhu Tubuh (S)",spo2:"Saturasi Oksigen (SpO2)",nafas:"Laju Napas (RR)",gcs_e:"GCS Mata (E)",gcs_m:"GCS Motorik (M)",gcs_v:"GCS Verbal (V)"},Lh={ku:"Keadaan Umum (KU)",kes:"Kesadaran",td_pulang:"Tekanan Darah (TD)",nadi_pulang:"Nadi (N)",suhu_pulang:"Suhu Tubuh (S)",rr_pulang:"Laju Napas (RR)",spo2_pulang:"Saturasi Oksigen (SpO2)"};function Th({data:i,onSave:s,onClose:c}){let[p,d]=(0,Qe.useState)(()=>structuredClone(i)),[S,L]=(0,Qe.useState)(!1),[C,R]=(0,Qe.useState)(""),[k,z]=(0,Qe.useState)(null),N=w=>d(E=>({...E,...w})),O=async w=>{w.preventDefault(),L(!0),R("");try{await s(p),z(new Date().toLocaleTimeString()),window.setTimeout(()=>window.location.reload(),900)}catch(E){R(E instanceof Error?E.message:"Gagal menyimpan")}finally{L(!1)}},re=(w,E)=>{let B=[...p.icd_sekunder];B[w]=E,N({icd_sekunder:B})},se=()=>N({icd_sekunder:[...p.icd_sekunder,{id:"",kode:"",nama:""}]}),K=w=>N({icd_sekunder:p.icd_sekunder.filter((E,B)=>B!==w)}),G=(w,E)=>{let B=[...p.icd_tindakan];B[w]=E,N({icd_tindakan:B})},ze=()=>N({icd_tindakan:[...p.icd_tindakan,{id:"",kode:"",nama:""}]}),pe=w=>N({icd_tindakan:p.icd_tindakan.filter((E,B)=>B!==w)}),Ue=(w,E)=>{let B=[...p.icd_nosokomial];B[w]=E,N({icd_nosokomial:B})},oe=()=>N({icd_nosokomial:[...p.icd_nosokomial,{id:"",kode:"",nama:""}]}),ye=w=>N({icd_nosokomial:p.icd_nosokomial.filter((E,B)=>B!==w)}),be=()=>{sg({idVisit:p.id_visit,tipe:"ranap",title:"Riwayat Resume Rawat Inap",zIndex:2147483647,onApply:w=>d(ug(w,p))})};return(0,x.jsxs)("form",{onSubmit:O,className:"ri-modal font-['Roboto','Segoe_UI',system-ui,sans-serif]",onClick:w=>w.stopPropagation(),children:[(0,x.jsxs)("div",{className:"flex items-center justify-between px-5 py-4 bg-primary text-white shrink-0",children:[(0,x.jsxs)("div",{className:"flex items-center gap-3 min-w-0",children:[(0,x.jsx)("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:(0,x.jsx)("path",{d:"M22 12h-4l-3 9L9 3l-3 9H2"})}),(0,x.jsxs)("div",{children:[(0,x.jsx)("span",{className:"text-base font-bold",children:"Resume Rawat Inap"}),(0,x.jsx)("p",{className:"text-base text-white/90",children:"Lengkapi ringkasan dan ICD rawat inap"})]})]}),(0,x.jsx)("button",{type:"button",onClick:c,className:"bg-white/15 hover:bg-white/25 border-none text-white w-12 h-12 rounded-lg text-base flex items-center justify-center cursor-pointer transition-colors flex-shrink-0","aria-label":"Tutup modal",children:"\u2715"})]}),(0,x.jsxs)("div",{className:"overflow-auto p-5 flex-1 bg-muted",children:[(0,x.jsxs)("div",{className:"flex gap-4 flex-wrap items-center mb-4 p-3 px-4 bg-card border border-border rounded-lg text-base shadow-sm",children:[(0,x.jsx)("span",{className:"text-base text-muted-foreground",children:"Field bertanda (*) wajib diisi."}),[{label:"RM",value:p.norm},{label:"Pasien",value:p.pasien},{label:"Reg",value:p.noreg},{label:"Unit",value:p.unit}].map(w=>(0,x.jsxs)("span",{className:"flex items-center gap-1.5",children:[(0,x.jsx)("span",{className:"font-bold text-primary text-base uppercase tracking-wide",children:w.label}),(0,x.jsx)("span",{className:"text-foreground text-base",children:w.value||"\u2014"})]},w.label))]}),(0,x.jsx)("p",{className:"text-base text-muted-foreground mb-4 text-center md:text-left",children:"Diagnosa utama dan ICD menunjukkan ringkasan utama. Gunakan Riwayat jika ingin memulihkan log terakhir."}),(0,x.jsx)(Qr,{title:"Ringkasan",children:(0,x.jsxs)(Ii,{cols:2,children:[(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Dokter Rawat Bersama"}),(0,x.jsx)(Ge,{value:p.dokter_bersama,onChange:w=>N({dokter_bersama:w.target.value}),rows:2})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Alasan / Indikasi Rawat"}),(0,x.jsx)(Ge,{value:p.alasan_rawat,onChange:w=>N({alasan_rawat:w.target.value}),rows:2})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Anamnesa"}),(0,x.jsx)(Ge,{value:p.anamnesa,onChange:w=>N({anamnesa:w.target.value}),rows:4})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Riwayat Penyakit"}),(0,x.jsx)(Ge,{value:p.riwayat_penyakit,onChange:w=>N({riwayat_penyakit:w.target.value}),rows:3})]})]})}),(0,x.jsx)(Qr,{title:"Vital Sign",children:(0,x.jsx)("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-2.5",children:["tensi","nadi","suhu","spo2","nafas","gcs_e","gcs_m","gcs_v"].map(w=>(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:jh[w]}),(0,x.jsx)(vr,{value:p[w],onChange:E=>{let B=tu[w];if(B===void 0){N({[w]:E.target.value});return}let Ne=E.target.value.replace(/\D/g,"").slice(0,String(B).length);if(!Ne){N({[w]:""});return}let Ae=Math.min(Math.max(parseInt(Ne,10),1),B);N({[w]:String(Ae)})},inputMode:tu[w]===void 0?void 0:"numeric",placeholder:Ph[w],className:"font-semibold"})]},w))})}),(0,x.jsx)(Qr,{title:"Pemeriksaan & Diagnosa",children:(0,x.jsxs)(Ii,{cols:2,children:[(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Pemeriksaan Fisik"}),(0,x.jsx)(Ge,{value:p.fisik_text,onChange:w=>N({fisik_text:w.target.value}),rows:5})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Hasil Pemeriksaan Diagnostik (Lab, Rontgen, dll)"}),(0,x.jsx)(Ge,{value:p.laborat,onChange:w=>N({laborat:w.target.value}),rows:4})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{required:!0,children:"Diagnosa Utama"}),(0,x.jsx)(Ge,{value:p.diagnosa_primary,onChange:w=>N({diagnosa_primary:w.target.value}),rows:2})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Diagnosa Sekunder"}),(0,x.jsx)(Ge,{value:p.diagnosa_skunder,onChange:w=>N({diagnosa_skunder:w.target.value}),rows:2})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Diagnosa Tindakan"}),(0,x.jsx)(Ge,{value:p.diagnosa_tindakan,onChange:w=>N({diagnosa_tindakan:w.target.value}),rows:2})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Prosedur / Operasi"}),(0,x.jsx)(Ge,{value:p.tindakan,onChange:w=>N({tindakan:w.target.value}),rows:2})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Pengobatan"}),(0,x.jsx)(Ge,{value:p.terapi_pengobatan,onChange:w=>N({terapi_pengobatan:w.target.value}),rows:4})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Obat Pulang"}),(0,x.jsx)(Ge,{value:p.obat_plg,onChange:w=>N({obat_plg:w.target.value}),rows:3})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Tindakan"}),(0,x.jsx)(Ge,{value:p.tindakan_dua,onChange:w=>N({tindakan_dua:w.target.value}),rows:4})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Jenis Kasus"}),(0,x.jsx)(na,{value:p.jenis_kasus,onChange:w=>N({jenis_kasus:w.target.value}),options:zh})]})]})}),(0,x.jsxs)(Qr,{title:"Diagnosa (ICD-10)",children:[(0,x.jsxs)("div",{className:"mb-3",children:[(0,x.jsx)(Ee,{required:!0,children:"Diagnosa Utama"}),(0,x.jsx)(eu,{kode:p.kode_diagnosa_utama,nama:p.diagnosa_utama_nama,icdType:"icd10",onPick:(w,E,B)=>N({kode_diagnosa_utama:w,diagnosa_utama_nama:E,id_diagnosa_utama:B})})]}),(0,x.jsx)(Hi,{items:p.icd_sekunder,icdType:"icd10",onChange:re,onAdd:se,onRemove:K,label:"Diagnosa Sekunder",emptyText:"Belum ada diagnosa sekunder"})]}),(0,x.jsxs)(Qr,{title:"Tindakan & Infeksi Nosokomial",children:[(0,x.jsx)(Hi,{items:p.icd_tindakan,icdType:"icd9",onChange:G,onAdd:ze,onRemove:pe,label:"Tindakan",emptyText:"Belum ada tindakan"}),(0,x.jsx)(Hi,{items:p.icd_nosokomial,icdType:"icd10",onChange:Ue,onAdd:oe,onRemove:ye,label:"Infeksi Nosokomial",emptyText:"Belum ada nosokomial"})]}),(0,x.jsxs)(Qr,{title:"Kondisi Pulang",children:[(0,x.jsx)("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-3",children:["ku","kes","td_pulang","nadi_pulang","suhu_pulang","rr_pulang","spo2_pulang"].map(w=>(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:Lh[w]}),(0,x.jsx)(vr,{value:p[w],onChange:E=>N({[w]:E.target.value}),className:"font-semibold"})]},w))}),(0,x.jsxs)("div",{className:"mt-3",children:[(0,x.jsx)(Ee,{children:"Catatan Kondisi Pulang"}),(0,x.jsx)(Ge,{value:p.catatan_keluar,onChange:w=>N({catatan_keluar:w.target.value}),rows:2})]})]}),(0,x.jsx)(Qr,{title:"Keluar",children:(0,x.jsxs)(Ii,{cols:2,children:[(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Keadaan Keluar"}),(0,x.jsx)(na,{value:p.keadaan_keluar,onChange:w=>N({keadaan_keluar:w.target.value}),options:Ch})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Cara Pulang"}),(0,x.jsx)(na,{value:p.cara_keluar,onChange:w=>N({cara_keluar:w.target.value}),options:Eh})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Tanggal Keluar"}),(0,x.jsx)(vr,{value:p.tgl_keluar,onChange:w=>N({tgl_keluar:w.target.value})})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Pemeriksaan Lanjutan"}),(0,x.jsx)(na,{value:p.pemeriksaan_lanjut,onChange:w=>N({pemeriksaan_lanjut:w.target.value}),options:Nh})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Jadwal Kontrol"}),(0,x.jsx)(vr,{value:p.jadwal_kontrol,onChange:w=>N({jadwal_kontrol:w.target.value})})]}),(0,x.jsxs)("div",{children:[(0,x.jsx)(Ee,{children:"Kelas"}),(0,x.jsx)(vr,{value:p.kelas,onChange:w=>N({kelas:w.target.value})})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Instruksi Pulang"}),(0,x.jsx)(Ge,{value:p.instruksi_pulang,onChange:w=>N({instruksi_pulang:w.target.value}),rows:3})]}),(0,x.jsxs)(Xt,{children:[(0,x.jsx)(Ee,{children:"Penyebab Kematian"}),(0,x.jsx)(Ge,{value:p.penyebab_kematian,onChange:w=>N({penyebab_kematian:w.target.value}),rows:2})]})]})})]}),(0,x.jsxs)("div",{className:"flex justify-end gap-2.5 py-3.5 px-5 border-t-2 border-border items-center shrink-0 bg-card sticky bottom-0 z-10 rounded-b-2xl",children:[C&&(0,x.jsx)(Zc,{variant:"danger",icon:!0,className:"mr-auto text-base",children:C}),k&&!C&&(0,x.jsxs)(Zc,{variant:"success",icon:!0,className:"mr-auto text-base",children:["Berhasil tersimpan ",k]}),(0,x.jsx)(hn,{type:"button",variant:"success",onClick:be,disabled:S,size:"default",children:"Riwayat"}),(0,x.jsx)(hn,{type:"button",variant:"dark",onClick:c,disabled:S,size:"default",children:"Batal"}),(0,x.jsxs)(hn,{type:"submit",variant:"default",disabled:S,size:"lg",className:"px-7",children:[" ",S?"Menyimpan...":"Simpan"," "]})]})]})}var Ah=Ie(At(),1),Rh=class extends Ah.Component{constructor(){super(...arguments),this.state={hasError:!1}}static getDerivedStateFromError(){return{hasError:!0}}componentDidCatch(i,s){console.error("[RI ErrorBoundary]",i,s.componentStack),this.props.onError()}render(){return this.state.hasError?null:this.props.children}},ru=Ie($t(),1),nu="/admisi/detail-rawat-inap/edit-resume-ri",Oh="/rekam-medik/control/edit-resume-rawat-inap",aa=null,nt=null,oa=null;function de(i,s){return i.querySelector(`[name="${s}"]`)?.value??""}function it(i,s){let c=i.querySelector(`textarea[name="${s}"]`);return c?.textContent?.trim()??c?.value?.trim()??""}function Vi(i,s){return Array.from(i.querySelectorAll(`[name="${s}"]`)).map(c=>c.value).filter(Boolean)}function qi(i,s,c){let p=[],d=1;for(;i.querySelector(`#${s}${d}`);){let S=i.querySelector(`#kode_${s}${d}`),L=i.querySelector(`#${s}${d}`);p.push({kode:S?.value??"",nama:L?.value??"",id:c[d-1]??""}),d++}return p}function Mh(i){let s=new DOMParser().parseFromString(i,"text/html"),c=Vi(s,"id_diagnosa_sekunder[]"),p=Vi(s,"id_tindakan[]"),d=Vi(s,"id_nosokomial[]");return{id_visit:de(s,"id_visit"),id_resume_inap:de(s,"id_resume_inap"),id_user:de(s,"id_user"),id_bed:de(s,"id_bed"),unit:de(s,"unit"),noreg:de(s,"noreg"),norm:de(s,"norm"),pasien:de(s,"pasien"),dokter_bersama:de(s,"dokter_bersama"),alasan_rawat:de(s,"alasan_rawat"),anamnesa:it(s,"anamnesa"),riwayat_penyakit:it(s,"riwayat_penyakit"),tensi:de(s,"tensi"),nadi:de(s,"nadi"),suhu:de(s,"suhu"),spo2:de(s,"spo2"),nafas:de(s,"nafas"),gcs_e:de(s,"gcs_e"),gcs_m:de(s,"gcs_m"),gcs_v:de(s,"gcs_v"),fisik_text:it(s,"fisik_text"),laborat:it(s,"laborat"),diagnosa_primary:it(s,"diagnosa_primary"),diagnosa_skunder:it(s,"diagnosa_skunder"),diagnosa_tindakan:it(s,"diagnosa_tindakan"),tindakan:it(s,"tindakan"),terapi_pengobatan:it(s,"terapi_pengobatan"),obat_plg:it(s,"obat_plg"),tindakan_dua:it(s,"tindakan_dua"),jenis_kasus:de(s,"jenis_kasus"),kode_diagnosa_utama:s.querySelector("#kode_diagnosa_utama")?.value??"",diagnosa_utama_nama:s.querySelector("#diagnosa_utama")?.value??"",id_diagnosa_utama:de(s,"id_diagnosa_utama"),icd_sekunder:qi(s,"diagnosa_sekunder",c),icd_tindakan:qi(s,"tindakan",p),icd_nosokomial:qi(s,"nosokomial",d),ku:de(s,"ku"),kes:de(s,"kes"),td_pulang:de(s,"td_pulang"),nadi_pulang:de(s,"nadi_pulang"),suhu_pulang:de(s,"suhu_pulang"),rr_pulang:de(s,"rr_pulang"),spo2_pulang:de(s,"spo2_pulang"),catatan_keluar:it(s,"catatan_keluar"),keadaan_keluar:de(s,"keadaan_keluar"),cara_keluar:de(s,"cara_keluar"),penyebab_kematian:it(s,"penyebab_kematian"),instruksi_pulang:it(s,"instruksi_pulang"),tgl_keluar:de(s,"tgl_keluar"),jadwal_kontrol:de(s,"jadwal_kontrol"),pemeriksaan_lanjut:de(s,"pemeriksaan_lanjut"),kelas:de(s,"kelas"),id_kelas:de(s,"id_kelas")}}async function Dh(){let i=new URLSearchParams(location.search).get("id_visit");if(!i)return null;try{let s=(await(await fetch(`/admisi/detail-rawat-inap/resume-ri?idVisit=${i}`,{credentials:"same-origin"})).text()).match(/edit\((\d+),/)?.[1]??"";s||console.warn("[RI] no existing resume found, using empty form");let c=s?`${nu}?idVisit=${i}&id=${s}`:`${nu}?idVisit=${i}`,p=await(await fetch(c,{credentials:"same-origin"})).text();return Mh(p)}catch(s){return console.error("[RI] fetch failed:",s),null}}function Fh(i){let s=[],c=(p,d)=>{d&&s.push([p,d])};return c("id_visit",i.id_visit),c("id_resume_inap",i.id_resume_inap),c("id_user",i.id_user),c("id_bed",i.id_bed),c("unit",i.unit),c("noreg",i.noreg),c("norm",i.norm),c("pasien",i.pasien),c("dokter_bersama",i.dokter_bersama),c("alasan_rawat",i.alasan_rawat),c("anamnesa",i.anamnesa),c("riwayat_penyakit",i.riwayat_penyakit),c("tensi",i.tensi),c("nadi",i.nadi),c("suhu",i.suhu),c("spo2",i.spo2),c("nafas",i.nafas),c("gcs_e",i.gcs_e),c("gcs_m",i.gcs_m),c("gcs_v",i.gcs_v),c("fisik_text",i.fisik_text),c("laborat",i.laborat),c("diagnosa_primary",i.diagnosa_primary),c("diagnosa_skunder",i.diagnosa_skunder),c("diagnosa_tindakan",i.diagnosa_tindakan),c("tindakan",i.tindakan),c("terapi_pengobatan",i.terapi_pengobatan),c("obat_plg",i.obat_plg),c("tindakan_dua",i.tindakan_dua),c("jenis_kasus",i.jenis_kasus),c("id_diagnosa_utama",i.id_diagnosa_utama),i.icd_sekunder.forEach(p=>c("id_diagnosa_sekunder[]",p.id)),i.icd_tindakan.forEach(p=>c("id_tindakan[]",p.id)),i.icd_nosokomial.forEach(p=>c("id_nosokomial[]",p.id)),c("ku",i.ku),c("kes",i.kes),c("td_pulang",i.td_pulang),c("nadi_pulang",i.nadi_pulang),c("suhu_pulang",i.suhu_pulang),c("rr_pulang",i.rr_pulang),c("spo2_pulang",i.spo2_pulang),c("catatan_keluar",i.catatan_keluar),c("keadaan_keluar",i.keadaan_keluar),c("cara_keluar",i.cara_keluar),c("penyebab_kematian",i.penyebab_kematian),c("instruksi_pulang",i.instruksi_pulang),c("tgl_keluar",i.tgl_keluar),c("jadwal_kontrol",i.jadwal_kontrol),c("pemeriksaan_lanjut",i.pemeriksaan_lanjut),c("kelas",i.kelas),c("id_kelas",i.id_kelas),c("save","Simpan"),s.map(([p,d])=>`${encodeURIComponent(p)}=${encodeURIComponent(d)}`).join("&")}function au(){if(aa){try{aa.unmount()}catch{}aa=null}let i=document.getElementById("ext-ri-container");i&&i.remove();let s=document.getElementById("morbis-manap-root")?.shadowRoot?.getElementById("ext-ri-shadow-container");if(s){try{s._reactRoot?.unmount?.()}catch{}s.remove()}document.body.classList.remove("ext-ri-open"),nt&&(nt.disabled=!1,nt.style.display="");let c=document.querySelector("[data-scroll-buttons]");c&&(c.style.display="")}function Ih(i){if(document.body.classList.add("ext-ri-open"),!document.getElementById("morbis-resume-fonts")){let C=document.createElement("link");C.id="morbis-resume-fonts",C.rel="stylesheet",C.href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400;1,700&family=Lexend:wght@400;500;600;700&family=Roboto:wght@400;500;600;700&display=swap",document.head.appendChild(C)}let s=document.getElementById("ext-ri-container");s||(s=document.createElement("div"),s.id="ext-ri-container",s.className="ri-modal",s.style.cssText="position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center",document.body.appendChild(s));let c=()=>{let C=document.getElementById("morbis-manap-root");if(C?.shadowRoot)return C.shadowRoot;if(C&&!C.shadowRoot)return null;C=document.createElement("div"),C.id="morbis-manap-root",C.style.cssText="position:fixed;inset:0;z-index:2147483647;pointer-events:none;display:block",document.body.appendChild(C);let R=C.attachShadow({mode:"open"}),k=document.createElement("div");k.id="app",R.appendChild(k);let z=document.createElement("style");z.id="morbis-shadow-reset",z.textContent=":host{display:block}#app{isolation:isolate;color-scheme:light}",R.appendChild(z);try{let N=`/* shadow-dom base */
*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
/* ! tailwindcss v3.4.19 | MIT License | https://tailwindcss.com *//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  /* ponytail: senior preset \u2014 :root for popup/sidepanel, :host+#app for Shadow DOM (resume modals).
     Keep in sync: edit :root. */
  :root,
  :host,
  #app {
    --background: 0 0% 100%;
    --foreground: 222.2 47% 11%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 47% 11%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 47% 11%;
    --primary: 221.2 83% 53%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 47% 11%;
    --muted: 210 40% 96%;
    --muted-foreground: 215 20% 35%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 47% 11%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 210 40% 98%;
    --border: 214 32% 72%;
    --input: 214 32% 72%;
    --ring: 221 83% 53%;
    --radius: 0.75rem;
    --warning: 38 92% 50%;
    --warning-foreground: 48 96% 12%;
  }

  /* ponytail: Shadow DOM needs its own color-scheme + base reset; :host isolates from page CSS */
  :host {
    all: initial;
  }
  #app {
    color-scheme: light;
    isolation: isolate;
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    box-sizing: border-box;
  }
  #app *,
  #app *::before,
  #app *::after {
    box-sizing: border-box;
  }

  @theme inline {
    --color-warning: var(--warning);
    --color-warning-foreground: var(--warning-foreground);
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 48%;
    --md-scrollbar: #484d54;
  }

  ::-moz-selection {
    background: #2469f0;
    color: white;
  }

  ::selection {
    background: #2469f0;
    color: white;
  }

  * {
    scrollbar-width: thin;
    scrollbar-color: #c9cdd4 transparent;
  }

  .dark * {
    scrollbar-color: var(--md-scrollbar) transparent;
  }

  *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  *::-webkit-scrollbar-track {
    background: transparent;
  }

  *::-webkit-scrollbar-thumb {
    background: #c9cdd4;
    border-radius: 3px;
  }

  .dark *::-webkit-scrollbar-thumb {
    background: var(--md-scrollbar);
  }

  *::-webkit-scrollbar-thumb:hover {
    background: #a4a9b3;
  }

  .dark *::-webkit-scrollbar-thumb:hover {
    background: #636971;
  }
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {
  .\\!container {
    max-width: 640px !important;
  }
  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {
  .\\!container {
    max-width: 768px !important;
  }
  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {
  .\\!container {
    max-width: 1024px !important;
  }
  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {
  .\\!container {
    max-width: 1280px !important;
  }
  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {
  .\\!container {
    max-width: 1536px !important;
  }
  .container {
    max-width: 1536px;
  }
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.pointer-events-none {
  pointer-events: none;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.collapse {
  visibility: collapse;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-4 {
  bottom: 1rem;
}
.left-1\\/2 {
  left: 50%;
}
.right-4 {
  right: 1rem;
}
.top-1\\/2 {
  top: 50%;
}
.z-10 {
  z-index: 10;
}
.z-50 {
  z-index: 50;
}
.z-\\[1\\] {
  z-index: 1;
}
.z-\\[2147483647\\] {
  z-index: 2147483647;
}
.col-span-full {
  grid-column: 1 / -1;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.-mb-\\[1px\\] {
  margin-bottom: -1px;
}
.mb-1 {
  margin-bottom: 0.25rem;
}
.mb-1\\.5 {
  margin-bottom: 0.375rem;
}
.mb-2 {
  margin-bottom: 0.5rem;
}
.mb-3 {
  margin-bottom: 0.75rem;
}
.mb-4 {
  margin-bottom: 1rem;
}
.ml-1 {
  margin-left: 0.25rem;
}
.mr-1 {
  margin-right: 0.25rem;
}
.mr-2 {
  margin-right: 0.5rem;
}
.mr-3 {
  margin-right: 0.75rem;
}
.mr-auto {
  margin-right: auto;
}
.mt-0\\.5 {
  margin-top: 0.125rem;
}
.mt-1 {
  margin-top: 0.25rem;
}
.mt-2 {
  margin-top: 0.5rem;
}
.mt-3 {
  margin-top: 0.75rem;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.\\!contents {
  display: contents !important;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-1\\.5 {
  width: 0.375rem;
  height: 0.375rem;
}
.size-10 {
  width: 2.5rem;
  height: 2.5rem;
}
.size-3 {
  width: 0.75rem;
  height: 0.75rem;
}
.size-3\\.5 {
  width: 0.875rem;
  height: 0.875rem;
}
.size-4 {
  width: 1rem;
  height: 1rem;
}
.size-5 {
  width: 1.25rem;
  height: 1.25rem;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.h-1 {
  height: 0.25rem;
}
.h-10 {
  height: 2.5rem;
}
.h-11 {
  height: 2.75rem;
}
.h-12 {
  height: 3rem;
}
.h-2 {
  height: 0.5rem;
}
.h-24 {
  height: 6rem;
}
.h-4 {
  height: 1rem;
}
.h-5 {
  height: 1.25rem;
}
.h-6 {
  height: 1.5rem;
}
.h-7 {
  height: 1.75rem;
}
.h-8 {
  height: 2rem;
}
.h-9 {
  height: 2.25rem;
}
.h-\\[300px\\] {
  height: 300px;
}
.h-\\[var\\(--radix-select-trigger-height\\)\\] {
  height: var(--radix-select-trigger-height);
}
.h-full {
  height: 100%;
}
.max-h-60 {
  max-height: 15rem;
}
.max-h-\\[220px\\] {
  max-height: 220px;
}
.max-h-\\[280px\\] {
  max-height: 280px;
}
.max-h-\\[360px\\] {
  max-height: 360px;
}
.max-h-\\[420px\\] {
  max-height: 420px;
}
.max-h-\\[600px\\] {
  max-height: 600px;
}
.min-h-11 {
  min-height: 2.75rem;
}
.min-h-\\[200px\\] {
  min-height: 200px;
}
.min-h-\\[80px\\] {
  min-height: 80px;
}
.w-10 {
  width: 2.5rem;
}
.w-11 {
  width: 2.75rem;
}
.w-12 {
  width: 3rem;
}
.w-2 {
  width: 0.5rem;
}
.w-28 {
  width: 7rem;
}
.w-4 {
  width: 1rem;
}
.w-5 {
  width: 1.25rem;
}
.w-6 {
  width: 1.5rem;
}
.w-7 {
  width: 1.75rem;
}
.w-9 {
  width: 2.25rem;
}
.w-\\[100px\\] {
  width: 100px;
}
.w-\\[120px\\] {
  width: 120px;
}
.w-\\[340px\\] {
  width: 340px;
}
.w-\\[76px\\] {
  width: 76px;
}
.w-\\[90px\\] {
  width: 90px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-0 {
  min-width: 0px;
}
.min-w-\\[100px\\] {
  min-width: 100px;
}
.min-w-\\[110px\\] {
  min-width: 110px;
}
.min-w-\\[12rem\\] {
  min-width: 12rem;
}
.min-w-\\[80px\\] {
  min-width: 80px;
}
.min-w-\\[90px\\] {
  min-width: 90px;
}
.min-w-\\[var\\(--radix-select-trigger-width\\)\\] {
  min-width: var(--radix-select-trigger-width);
}
.max-w-\\[120px\\] {
  max-width: 120px;
}
.max-w-\\[140px\\] {
  max-width: 140px;
}
.max-w-\\[200px\\] {
  max-width: 200px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-90 {
  --tw-scale-x: .9;
  --tw-scale-y: .9;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes pulse {
  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes slide-up {
  0% {
    opacity: 0;
    transform: translateY(8px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
.animate-slide-up {
  animation: slide-up 0.15s ease-out;
}
.cursor-default {
  cursor: default;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize-y {
  resize: vertical;
}
.resize {
  resize: both;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-center {
  align-items: center;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0 {
  gap: 0px;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-1\\.5 {
  gap: 0.375rem;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-2\\.5 {
  gap: 0.625rem;
}
.gap-3 {
  gap: 0.75rem;
}
.gap-4 {
  gap: 1rem;
}
.gap-x-8 {
  -moz-column-gap: 2rem;
       column-gap: 2rem;
}
.gap-y-3 {
  row-gap: 0.75rem;
}
.space-y-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.125rem * var(--tw-space-y-reverse));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}
.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.5rem * var(--tw-space-y-reverse));
}
.space-y-2\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.625rem * var(--tw-space-y-reverse));
}
.space-y-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}
.space-y-5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1.25rem * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.divide-border > :not([hidden]) ~ :not([hidden]) {
  border-color: hsl(var(--border));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-y-auto {
  overflow-y: auto;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.break-words {
  overflow-wrap: break-word;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 0.5rem;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.rounded-b-2xl {
  border-bottom-right-radius: 1rem;
  border-bottom-left-radius: 1rem;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l-2 {
  border-left-width: 2px;
}
.border-t {
  border-top-width: 1px;
}
.border-t-2 {
  border-top-width: 2px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-\\[\\#2469f0\\] {
  --tw-border-opacity: 1;
  border-color: rgb(36 105 240 / var(--tw-border-opacity, 1));
}
.border-amber-200 {
  --tw-border-opacity: 1;
  border-color: rgb(253 230 138 / var(--tw-border-opacity, 1));
}
.border-border {
  border-color: hsl(var(--border));
}
.border-destructive {
  border-color: hsl(var(--destructive));
}
.border-destructive\\/20 {
  border-color: hsl(var(--destructive) / 0.2);
}
.border-foreground {
  border-color: hsl(var(--foreground));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-input {
  border-color: hsl(var(--input));
}
.border-primary {
  border-color: hsl(var(--primary));
}
.border-primary\\/20 {
  border-color: hsl(var(--primary) / 0.2);
}
.border-primary\\/50 {
  border-color: hsl(var(--primary) / 0.5);
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.bg-\\[\\#2469f0\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(36 105 240 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  background-color: hsl(var(--accent));
}
.bg-accent\\/20 {
  background-color: hsl(var(--accent) / 0.2);
}
.bg-accent\\/40 {
  background-color: hsl(var(--accent) / 0.4);
}
.bg-accent\\/50 {
  background-color: hsl(var(--accent) / 0.5);
}
.bg-amber-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}
.bg-amber-50\\/50 {
  background-color: rgb(255 251 235 / 0.5);
}
.bg-background {
  background-color: hsl(var(--background));
}
.bg-background\\/60 {
  background-color: hsl(var(--background) / 0.6);
}
.bg-blue-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}
.bg-border {
  background-color: hsl(var(--border));
}
.bg-card {
  background-color: hsl(var(--card));
}
.bg-destructive {
  background-color: hsl(var(--destructive));
}
.bg-destructive\\/10 {
  background-color: hsl(var(--destructive) / 0.1);
}
.bg-destructive\\/5 {
  background-color: hsl(var(--destructive) / 0.05);
}
.bg-foreground {
  background-color: hsl(var(--foreground));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}
.bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}
.bg-green-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}
.bg-green-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));
}
.bg-green-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.bg-muted {
  background-color: hsl(var(--muted));
}
.bg-muted-foreground {
  background-color: hsl(var(--muted-foreground));
}
.bg-muted\\/40 {
  background-color: hsl(var(--muted) / 0.4);
}
.bg-neutral-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.bg-popover {
  background-color: hsl(var(--popover));
}
.bg-primary {
  background-color: hsl(var(--primary));
}
.bg-primary\\/10 {
  background-color: hsl(var(--primary) / 0.1);
}
.bg-primary\\/5 {
  background-color: hsl(var(--primary) / 0.05);
}
.bg-red-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}
.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}
.bg-red-500\\/5 {
  background-color: rgb(239 68 68 / 0.05);
}
.bg-red-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}
.bg-secondary {
  background-color: hsl(var(--secondary));
}
.bg-white\\/15 {
  background-color: rgb(255 255 255 / 0.15);
}
.bg-yellow-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}
.bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}
.from-muted {
  --tw-gradient-from: hsl(var(--muted)) var(--tw-gradient-from-position);
  --tw-gradient-to: hsl(var(--muted) / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.to-muted\\/50 {
  --tw-gradient-to: hsl(var(--muted) / 0.5) var(--tw-gradient-to-position);
}
.p-0\\.5 {
  padding: 0.125rem;
}
.p-1 {
  padding: 0.25rem;
}
.p-1\\.5 {
  padding: 0.375rem;
}
.p-2 {
  padding: 0.5rem;
}
.p-2\\.5 {
  padding: 0.625rem;
}
.p-3 {
  padding: 0.75rem;
}
.p-4 {
  padding: 1rem;
}
.p-5 {
  padding: 1.25rem;
}
.p-8 {
  padding: 2rem;
}
.px-1 {
  padding-left: 0.25rem;
  padding-right: 0.25rem;
}
.px-1\\.5 {
  padding-left: 0.375rem;
  padding-right: 0.375rem;
}
.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}
.px-2\\.5 {
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}
.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}
.px-3\\.5 {
  padding-left: 0.875rem;
  padding-right: 0.875rem;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-5 {
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}
.px-7 {
  padding-left: 1.75rem;
  padding-right: 1.75rem;
}
.py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}
.py-0\\.5 {
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
}
.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}
.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}
.py-12 {
  padding-top: 3rem;
  padding-bottom: 3rem;
}
.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
.py-2\\.5 {
  padding-top: 0.625rem;
  padding-bottom: 0.625rem;
}
.py-3 {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}
.py-3\\.5 {
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
}
.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}
.py-6 {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}
.pb-1\\.5 {
  padding-bottom: 0.375rem;
}
.pb-2 {
  padding-bottom: 0.5rem;
}
.pr-20 {
  padding-right: 5rem;
}
.pt-3 {
  padding-top: 0.75rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.font-\\[\\'Roboto\\'\\2c \\'Segoe_UI\\'\\2c system-ui\\2c sans-serif\\] {
  font-family: 'Roboto','Segoe UI',system-ui,sans-serif;
}
.font-mono {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace;
}
.text-\\[10px\\] {
  font-size: 10px;
}
.text-\\[11px\\] {
  font-size: 11px;
}
.text-\\[8px\\] {
  font-size: 8px;
}
.text-\\[9px\\] {
  font-size: 9px;
}
.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-md-sm {
  font-size: 12px;
  line-height: 18px;
}
.text-md-xs {
  font-size: 11px;
  line-height: 16px;
}
.text-xl {
  font-size: 1.25rem;
  line-height: 1.75rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.text-xxl {
  font-size: 22px;
  line-height: 28px;
}
.font-bold {
  font-weight: 700;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.italic {
  font-style: italic;
}
.leading-\\[1\\.6\\] {
  line-height: 1.6;
}
.leading-\\[1\\.7\\] {
  line-height: 1.7;
}
.leading-normal {
  line-height: 1.5;
}
.leading-relaxed {
  line-height: 1.625;
}
.leading-snug {
  line-height: 1.375;
}
.leading-tight {
  line-height: 1.25;
}
.tracking-\\[0\\.03em\\] {
  letter-spacing: 0.03em;
}
.tracking-tight {
  letter-spacing: -0.025em;
}
.tracking-wide {
  letter-spacing: 0.025em;
}
.tracking-wider {
  letter-spacing: 0.05em;
}
.text-\\[\\#2469f0\\] {
  --tw-text-opacity: 1;
  color: rgb(36 105 240 / var(--tw-text-opacity, 1));
}
.text-amber-700 {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}
.text-background {
  color: hsl(var(--background));
}
.text-blue-700 {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}
.text-card-foreground {
  color: hsl(var(--card-foreground));
}
.text-destructive {
  color: hsl(var(--destructive));
}
.text-destructive-foreground {
  color: hsl(var(--destructive-foreground));
}
.text-destructive\\/80 {
  color: hsl(var(--destructive) / 0.8);
}
.text-foreground {
  color: hsl(var(--foreground));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}
.text-green-50 {
  --tw-text-opacity: 1;
  color: rgb(240 253 244 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-700 {
  --tw-text-opacity: 1;
  color: rgb(21 128 61 / var(--tw-text-opacity, 1));
}
.text-muted-foreground {
  color: hsl(var(--muted-foreground));
}
.text-popover-foreground {
  color: hsl(var(--popover-foreground));
}
.text-primary {
  color: hsl(var(--primary));
}
.text-primary-foreground {
  color: hsl(var(--primary-foreground));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity, 1));
}
.text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity, 1));
}
.text-red-900 {
  --tw-text-opacity: 1;
  color: rgb(127 29 29 / var(--tw-text-opacity, 1));
}
.text-secondary-foreground {
  color: hsl(var(--secondary-foreground));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-white\\/80 {
  color: rgb(255 255 255 / 0.8);
}
.text-white\\/90 {
  color: rgb(255 255 255 / 0.9);
}
.text-yellow-600 {
  --tw-text-opacity: 1;
  color: rgb(202 138 4 / var(--tw-text-opacity, 1));
}
.text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity, 1));
}
.text-yellow-800 {
  --tw-text-opacity: 1;
  color: rgb(133 77 14 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.underline-offset-4 {
  text-underline-offset: 4px;
}
.antialiased {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.opacity-0 {
  opacity: 0;
}
.opacity-30 {
  opacity: 0.3;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-60 {
  opacity: 0.6;
}
.opacity-85 {
  opacity: 0.85;
}
.opacity-90 {
  opacity: 0.9;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.grayscale {
  --tw-grayscale: grayscale(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.duration-300 {
  transition-duration: 300ms;
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
@keyframes enter {
  from {
    opacity: var(--tw-enter-opacity, 1);
    transform: translate3d(var(--tw-enter-translate-x, 0), var(--tw-enter-translate-y, 0), 0) scale3d(var(--tw-enter-scale, 1), var(--tw-enter-scale, 1), var(--tw-enter-scale, 1)) rotate(var(--tw-enter-rotate, 0));
  }
}
@keyframes exit {
  to {
    opacity: var(--tw-exit-opacity, 1);
    transform: translate3d(var(--tw-exit-translate-x, 0), var(--tw-exit-translate-y, 0), 0) scale3d(var(--tw-exit-scale, 1), var(--tw-exit-scale, 1), var(--tw-exit-scale, 1)) rotate(var(--tw-exit-rotate, 0));
  }
}
.animate-in {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.fade-in {
  --tw-enter-opacity: 0;
}
.fade-out {
  --tw-exit-opacity: 0;
}
.duration-200 {
  animation-duration: 200ms;
}
.duration-300 {
  animation-duration: 300ms;
}
.ease-in-out {
  animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.running {
  animation-play-state: running;
}
.placeholder\\:text-muted-foreground::-moz-placeholder {
  color: hsl(var(--muted-foreground));
}
.placeholder\\:text-muted-foreground::placeholder {
  color: hsl(var(--muted-foreground));
}
.last\\:border-b-0:last-child {
  border-bottom-width: 0px;
}
.hover\\:bg-accent:hover {
  background-color: hsl(var(--accent));
}
.hover\\:bg-amber-100\\/50:hover {
  background-color: rgb(254 243 199 / 0.5);
}
.hover\\:bg-destructive\\/10:hover {
  background-color: hsl(var(--destructive) / 0.1);
}
.hover\\:bg-destructive\\/20:hover {
  background-color: hsl(var(--destructive) / 0.2);
}
.hover\\:bg-destructive\\/90:hover {
  background-color: hsl(var(--destructive) / 0.9);
}
.hover\\:bg-green-600\\/90:hover {
  background-color: rgb(22 163 74 / 0.9);
}
.hover\\:bg-green-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(21 128 61 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-neutral-900:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(23 23 23 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-primary\\/5:hover {
  background-color: hsl(var(--primary) / 0.05);
}
.hover\\:bg-primary\\/90:hover {
  background-color: hsl(var(--primary) / 0.9);
}
.hover\\:bg-red-500\\/10:hover {
  background-color: rgb(239 68 68 / 0.1);
}
.hover\\:bg-red-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-secondary\\/80:hover {
  background-color: hsl(var(--secondary) / 0.8);
}
.hover\\:bg-white\\/25:hover {
  background-color: rgb(255 255 255 / 0.25);
}
.hover\\:text-accent-foreground:hover {
  color: hsl(var(--accent-foreground));
}
.hover\\:text-destructive:hover {
  color: hsl(var(--destructive));
}
.hover\\:text-foreground:hover {
  color: hsl(var(--foreground));
}
.hover\\:text-red-600:hover {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.hover\\:underline:hover {
  text-decoration-line: underline;
}
.hover\\:opacity-70:hover {
  opacity: 0.7;
}
.focus\\:bg-accent:focus {
  background-color: hsl(var(--accent));
}
.focus\\:text-accent-foreground:focus {
  color: hsl(var(--accent-foreground));
}
.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-primary:focus {
  --tw-ring-color: hsl(var(--primary));
}
.focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity, 1));
}
.focus\\:ring-ring:focus {
  --tw-ring-color: hsl(var(--ring));
}
.focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}
.focus-visible\\:outline-none:focus-visible {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus-visible\\:ring-primary:focus-visible {
  --tw-ring-color: hsl(var(--primary));
}
.focus-visible\\:ring-ring:focus-visible {
  --tw-ring-color: hsl(var(--ring));
}
.focus-visible\\:ring-offset-1:focus-visible {
  --tw-ring-offset-width: 1px;
}
.focus-visible\\:ring-offset-2:focus-visible {
  --tw-ring-offset-width: 2px;
}
.active\\:bg-accent:active {
  background-color: hsl(var(--accent));
}
.active\\:bg-destructive:active {
  background-color: hsl(var(--destructive));
}
.active\\:bg-green-600:active {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.active\\:bg-neutral-950:active {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.active\\:bg-primary:active {
  background-color: hsl(var(--primary));
}
.active\\:bg-secondary:active {
  background-color: hsl(var(--secondary));
}
.disabled\\:pointer-events-none:disabled {
  pointer-events: none;
}
.disabled\\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}
.disabled\\:bg-muted:disabled {
  background-color: hsl(var(--muted));
}
.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}
.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}
.data-\\[disabled\\]\\:pointer-events-none[data-disabled] {
  pointer-events: none;
}
.data-\\[side\\=bottom\\]\\:translate-y-1[data-side="bottom"] {
  --tw-translate-y: 0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[side\\=top\\]\\:-translate-y-1[data-side="top"] {
  --tw-translate-y: -0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:translate-x-4[data-state="checked"] {
  --tw-translate-x: 1rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=unchecked\\]\\:translate-x-0[data-state="unchecked"] {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:bg-primary[data-state="checked"] {
  background-color: hsl(var(--primary));
}
.data-\\[state\\=unchecked\\]\\:bg-input[data-state="unchecked"] {
  background-color: hsl(var(--input));
}
.data-\\[disabled\\]\\:opacity-50[data-disabled] {
  opacity: 0.5;
}
.data-\\[state\\=open\\]\\:animate-in[data-state="open"] {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:animate-out[data-state="closed"] {
  animation-name: exit;
  animation-duration: 150ms;
  --tw-exit-opacity: initial;
  --tw-exit-scale: initial;
  --tw-exit-rotate: initial;
  --tw-exit-translate-x: initial;
  --tw-exit-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:fade-out-0[data-state="closed"] {
  --tw-exit-opacity: 0;
}
.data-\\[state\\=open\\]\\:fade-in-0[data-state="open"] {
  --tw-enter-opacity: 0;
}
.data-\\[state\\=closed\\]\\:zoom-out-95[data-state="closed"] {
  --tw-exit-scale: .95;
}
.data-\\[state\\=open\\]\\:zoom-in-95[data-state="open"] {
  --tw-enter-scale: .95;
}
@supports (backdrop-filter: var(--tw)) {
  .supports-\\[backdrop-filter\\]\\:bg-background\\/60 {
    background-color: hsl(var(--background) / 0.6);
  }
}
.dark\\:border-amber-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(146 64 14 / var(--tw-border-opacity, 1));
}
.dark\\:border-green-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 101 52 / var(--tw-border-opacity, 1));
}
.dark\\:border-red-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(127 29 29 / var(--tw-border-opacity, 1));
}
.dark\\:bg-amber-900\\/30:is(.dark *) {
  background-color: rgb(120 53 15 / 0.3);
}
.dark\\:bg-amber-950\\/20:is(.dark *) {
  background-color: rgb(69 26 3 / 0.2);
}
.dark\\:bg-blue-900\\/30:is(.dark *) {
  background-color: rgb(30 58 138 / 0.3);
}
.dark\\:bg-blue-950\\/20:is(.dark *) {
  background-color: rgb(23 37 84 / 0.2);
}
.dark\\:bg-green-950\\/20:is(.dark *) {
  background-color: rgb(5 46 22 / 0.2);
}
.dark\\:bg-red-950\\/20:is(.dark *) {
  background-color: rgb(69 10 10 / 0.2);
}
.dark\\:bg-yellow-950\\/30:is(.dark *) {
  background-color: rgb(66 32 6 / 0.3);
}
.dark\\:text-amber-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}
.dark\\:text-blue-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.dark\\:text-green-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 202 202 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
@media (min-width: 640px) {
  .sm\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
@media (min-width: 768px) {
  .md\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .md\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .md\\:text-left {
    text-align: left;
  }
}
@media (min-width: 1024px) {
  .lg\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
.\\[\\&\\>span\\]\\:line-clamp-1>span {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.\\[\\&\\>span\\]\\:h-3>span {
  height: 0.75rem;
}
.\\[\\&\\>span\\]\\:w-3>span {
  width: 0.75rem;
}
.data-\\[state\\=checked\\]\\:\\[\\&\\>span\\]\\:translate-x-3>span[data-state="checked"] {
  --tw-translate-x: 0.75rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.\\[\\&_svg\\]\\:pointer-events-none svg {
  pointer-events: none;
}
.\\[\\&_svg\\]\\:size-3\\.5 svg {
  width: 0.875rem;
  height: 0.875rem;
}
.\\[\\&_svg\\]\\:size-5 svg {
  width: 1.25rem;
  height: 1.25rem;
}
.\\[\\&_svg\\]\\:shrink-0 svg {
  flex-shrink: 0;
}
`;if(N=N.replace(/@import[^;]+;/g,""),N&&"adoptedStyleSheets"in R&&"CSSStyleSheet"in window)try{let O=new window.CSSStyleSheet;O.replaceSync(N),R.adoptedStyleSheets=[...R.adoptedStyleSheets,O]}catch{let O=document.createElement("style");O.textContent=N,R.appendChild(O)}else if(N){let O=document.createElement("style");O.textContent=N,R.appendChild(O)}}catch{}return R},p=c(),d=`/* shadow-dom base */
*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}
/* ! tailwindcss v3.4.19 | MIT License | https://tailwindcss.com *//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  /* ponytail: senior preset \u2014 :root for popup/sidepanel, :host+#app for Shadow DOM (resume modals).
     Keep in sync: edit :root. */
  :root,
  :host,
  #app {
    --background: 0 0% 100%;
    --foreground: 222.2 47% 11%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 47% 11%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 47% 11%;
    --primary: 221.2 83% 53%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 47% 11%;
    --muted: 210 40% 96%;
    --muted-foreground: 215 20% 35%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 47% 11%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 210 40% 98%;
    --border: 214 32% 72%;
    --input: 214 32% 72%;
    --ring: 221 83% 53%;
    --radius: 0.75rem;
    --warning: 38 92% 50%;
    --warning-foreground: 48 96% 12%;
  }

  /* ponytail: Shadow DOM needs its own color-scheme + base reset; :host isolates from page CSS */
  :host {
    all: initial;
  }
  #app {
    color-scheme: light;
    isolation: isolate;
    font-family:
      'Inter',
      -apple-system,
      BlinkMacSystemFont,
      'Segoe UI',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    box-sizing: border-box;
  }
  #app *,
  #app *::before,
  #app *::after {
    box-sizing: border-box;
  }

  @theme inline {
    --color-warning: var(--warning);
    --color-warning-foreground: var(--warning-foreground);
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 48%;
    --md-scrollbar: #484d54;
  }

  ::-moz-selection {
    background: #2469f0;
    color: white;
  }

  ::selection {
    background: #2469f0;
    color: white;
  }

  * {
    scrollbar-width: thin;
    scrollbar-color: #c9cdd4 transparent;
  }

  .dark * {
    scrollbar-color: var(--md-scrollbar) transparent;
  }

  *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  *::-webkit-scrollbar-track {
    background: transparent;
  }

  *::-webkit-scrollbar-thumb {
    background: #c9cdd4;
    border-radius: 3px;
  }

  .dark *::-webkit-scrollbar-thumb {
    background: var(--md-scrollbar);
  }

  *::-webkit-scrollbar-thumb:hover {
    background: #a4a9b3;
  }

  .dark *::-webkit-scrollbar-thumb:hover {
    background: #636971;
  }
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {
  .\\!container {
    max-width: 640px !important;
  }
  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {
  .\\!container {
    max-width: 768px !important;
  }
  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {
  .\\!container {
    max-width: 1024px !important;
  }
  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {
  .\\!container {
    max-width: 1280px !important;
  }
  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {
  .\\!container {
    max-width: 1536px !important;
  }
  .container {
    max-width: 1536px;
  }
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.pointer-events-none {
  pointer-events: none;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.collapse {
  visibility: collapse;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-4 {
  bottom: 1rem;
}
.left-1\\/2 {
  left: 50%;
}
.right-4 {
  right: 1rem;
}
.top-1\\/2 {
  top: 50%;
}
.z-10 {
  z-index: 10;
}
.z-50 {
  z-index: 50;
}
.z-\\[1\\] {
  z-index: 1;
}
.z-\\[2147483647\\] {
  z-index: 2147483647;
}
.col-span-full {
  grid-column: 1 / -1;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.-mb-\\[1px\\] {
  margin-bottom: -1px;
}
.mb-1 {
  margin-bottom: 0.25rem;
}
.mb-1\\.5 {
  margin-bottom: 0.375rem;
}
.mb-2 {
  margin-bottom: 0.5rem;
}
.mb-3 {
  margin-bottom: 0.75rem;
}
.mb-4 {
  margin-bottom: 1rem;
}
.ml-1 {
  margin-left: 0.25rem;
}
.mr-1 {
  margin-right: 0.25rem;
}
.mr-2 {
  margin-right: 0.5rem;
}
.mr-3 {
  margin-right: 0.75rem;
}
.mr-auto {
  margin-right: auto;
}
.mt-0\\.5 {
  margin-top: 0.125rem;
}
.mt-1 {
  margin-top: 0.25rem;
}
.mt-2 {
  margin-top: 0.5rem;
}
.mt-3 {
  margin-top: 0.75rem;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.\\!contents {
  display: contents !important;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-1\\.5 {
  width: 0.375rem;
  height: 0.375rem;
}
.size-10 {
  width: 2.5rem;
  height: 2.5rem;
}
.size-3 {
  width: 0.75rem;
  height: 0.75rem;
}
.size-3\\.5 {
  width: 0.875rem;
  height: 0.875rem;
}
.size-4 {
  width: 1rem;
  height: 1rem;
}
.size-5 {
  width: 1.25rem;
  height: 1.25rem;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.h-1 {
  height: 0.25rem;
}
.h-10 {
  height: 2.5rem;
}
.h-11 {
  height: 2.75rem;
}
.h-12 {
  height: 3rem;
}
.h-2 {
  height: 0.5rem;
}
.h-24 {
  height: 6rem;
}
.h-4 {
  height: 1rem;
}
.h-5 {
  height: 1.25rem;
}
.h-6 {
  height: 1.5rem;
}
.h-7 {
  height: 1.75rem;
}
.h-8 {
  height: 2rem;
}
.h-9 {
  height: 2.25rem;
}
.h-\\[300px\\] {
  height: 300px;
}
.h-\\[var\\(--radix-select-trigger-height\\)\\] {
  height: var(--radix-select-trigger-height);
}
.h-full {
  height: 100%;
}
.max-h-60 {
  max-height: 15rem;
}
.max-h-\\[220px\\] {
  max-height: 220px;
}
.max-h-\\[280px\\] {
  max-height: 280px;
}
.max-h-\\[360px\\] {
  max-height: 360px;
}
.max-h-\\[420px\\] {
  max-height: 420px;
}
.max-h-\\[600px\\] {
  max-height: 600px;
}
.min-h-11 {
  min-height: 2.75rem;
}
.min-h-\\[200px\\] {
  min-height: 200px;
}
.min-h-\\[80px\\] {
  min-height: 80px;
}
.w-10 {
  width: 2.5rem;
}
.w-11 {
  width: 2.75rem;
}
.w-12 {
  width: 3rem;
}
.w-2 {
  width: 0.5rem;
}
.w-28 {
  width: 7rem;
}
.w-4 {
  width: 1rem;
}
.w-5 {
  width: 1.25rem;
}
.w-6 {
  width: 1.5rem;
}
.w-7 {
  width: 1.75rem;
}
.w-9 {
  width: 2.25rem;
}
.w-\\[100px\\] {
  width: 100px;
}
.w-\\[120px\\] {
  width: 120px;
}
.w-\\[340px\\] {
  width: 340px;
}
.w-\\[76px\\] {
  width: 76px;
}
.w-\\[90px\\] {
  width: 90px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-0 {
  min-width: 0px;
}
.min-w-\\[100px\\] {
  min-width: 100px;
}
.min-w-\\[110px\\] {
  min-width: 110px;
}
.min-w-\\[12rem\\] {
  min-width: 12rem;
}
.min-w-\\[80px\\] {
  min-width: 80px;
}
.min-w-\\[90px\\] {
  min-width: 90px;
}
.min-w-\\[var\\(--radix-select-trigger-width\\)\\] {
  min-width: var(--radix-select-trigger-width);
}
.max-w-\\[120px\\] {
  max-width: 120px;
}
.max-w-\\[140px\\] {
  max-width: 140px;
}
.max-w-\\[200px\\] {
  max-width: 200px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-90 {
  --tw-scale-x: .9;
  --tw-scale-y: .9;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes pulse {
  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes slide-up {
  0% {
    opacity: 0;
    transform: translateY(8px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
.animate-slide-up {
  animation: slide-up 0.15s ease-out;
}
.cursor-default {
  cursor: default;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize-y {
  resize: vertical;
}
.resize {
  resize: both;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-center {
  align-items: center;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0 {
  gap: 0px;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-1\\.5 {
  gap: 0.375rem;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-2\\.5 {
  gap: 0.625rem;
}
.gap-3 {
  gap: 0.75rem;
}
.gap-4 {
  gap: 1rem;
}
.gap-x-8 {
  -moz-column-gap: 2rem;
       column-gap: 2rem;
}
.gap-y-3 {
  row-gap: 0.75rem;
}
.space-y-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.125rem * var(--tw-space-y-reverse));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}
.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.5rem * var(--tw-space-y-reverse));
}
.space-y-2\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.625rem * var(--tw-space-y-reverse));
}
.space-y-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}
.space-y-5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1.25rem * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.divide-border > :not([hidden]) ~ :not([hidden]) {
  border-color: hsl(var(--border));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-y-auto {
  overflow-y: auto;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.break-words {
  overflow-wrap: break-word;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 0.5rem;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.rounded-b-2xl {
  border-bottom-right-radius: 1rem;
  border-bottom-left-radius: 1rem;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l-2 {
  border-left-width: 2px;
}
.border-t {
  border-top-width: 1px;
}
.border-t-2 {
  border-top-width: 2px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-\\[\\#2469f0\\] {
  --tw-border-opacity: 1;
  border-color: rgb(36 105 240 / var(--tw-border-opacity, 1));
}
.border-amber-200 {
  --tw-border-opacity: 1;
  border-color: rgb(253 230 138 / var(--tw-border-opacity, 1));
}
.border-border {
  border-color: hsl(var(--border));
}
.border-destructive {
  border-color: hsl(var(--destructive));
}
.border-destructive\\/20 {
  border-color: hsl(var(--destructive) / 0.2);
}
.border-foreground {
  border-color: hsl(var(--foreground));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-input {
  border-color: hsl(var(--input));
}
.border-primary {
  border-color: hsl(var(--primary));
}
.border-primary\\/20 {
  border-color: hsl(var(--primary) / 0.2);
}
.border-primary\\/50 {
  border-color: hsl(var(--primary) / 0.5);
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.bg-\\[\\#2469f0\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(36 105 240 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  background-color: hsl(var(--accent));
}
.bg-accent\\/20 {
  background-color: hsl(var(--accent) / 0.2);
}
.bg-accent\\/40 {
  background-color: hsl(var(--accent) / 0.4);
}
.bg-accent\\/50 {
  background-color: hsl(var(--accent) / 0.5);
}
.bg-amber-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}
.bg-amber-50\\/50 {
  background-color: rgb(255 251 235 / 0.5);
}
.bg-background {
  background-color: hsl(var(--background));
}
.bg-background\\/60 {
  background-color: hsl(var(--background) / 0.6);
}
.bg-blue-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}
.bg-border {
  background-color: hsl(var(--border));
}
.bg-card {
  background-color: hsl(var(--card));
}
.bg-destructive {
  background-color: hsl(var(--destructive));
}
.bg-destructive\\/10 {
  background-color: hsl(var(--destructive) / 0.1);
}
.bg-destructive\\/5 {
  background-color: hsl(var(--destructive) / 0.05);
}
.bg-foreground {
  background-color: hsl(var(--foreground));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}
.bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}
.bg-green-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}
.bg-green-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));
}
.bg-green-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.bg-muted {
  background-color: hsl(var(--muted));
}
.bg-muted-foreground {
  background-color: hsl(var(--muted-foreground));
}
.bg-muted\\/40 {
  background-color: hsl(var(--muted) / 0.4);
}
.bg-neutral-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.bg-popover {
  background-color: hsl(var(--popover));
}
.bg-primary {
  background-color: hsl(var(--primary));
}
.bg-primary\\/10 {
  background-color: hsl(var(--primary) / 0.1);
}
.bg-primary\\/5 {
  background-color: hsl(var(--primary) / 0.05);
}
.bg-red-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}
.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}
.bg-red-500\\/5 {
  background-color: rgb(239 68 68 / 0.05);
}
.bg-red-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}
.bg-secondary {
  background-color: hsl(var(--secondary));
}
.bg-white\\/15 {
  background-color: rgb(255 255 255 / 0.15);
}
.bg-yellow-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}
.bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}
.from-muted {
  --tw-gradient-from: hsl(var(--muted)) var(--tw-gradient-from-position);
  --tw-gradient-to: hsl(var(--muted) / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.to-muted\\/50 {
  --tw-gradient-to: hsl(var(--muted) / 0.5) var(--tw-gradient-to-position);
}
.p-0\\.5 {
  padding: 0.125rem;
}
.p-1 {
  padding: 0.25rem;
}
.p-1\\.5 {
  padding: 0.375rem;
}
.p-2 {
  padding: 0.5rem;
}
.p-2\\.5 {
  padding: 0.625rem;
}
.p-3 {
  padding: 0.75rem;
}
.p-4 {
  padding: 1rem;
}
.p-5 {
  padding: 1.25rem;
}
.p-8 {
  padding: 2rem;
}
.px-1 {
  padding-left: 0.25rem;
  padding-right: 0.25rem;
}
.px-1\\.5 {
  padding-left: 0.375rem;
  padding-right: 0.375rem;
}
.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}
.px-2\\.5 {
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}
.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}
.px-3\\.5 {
  padding-left: 0.875rem;
  padding-right: 0.875rem;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-5 {
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}
.px-7 {
  padding-left: 1.75rem;
  padding-right: 1.75rem;
}
.py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}
.py-0\\.5 {
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
}
.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}
.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}
.py-12 {
  padding-top: 3rem;
  padding-bottom: 3rem;
}
.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
.py-2\\.5 {
  padding-top: 0.625rem;
  padding-bottom: 0.625rem;
}
.py-3 {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}
.py-3\\.5 {
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
}
.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}
.py-6 {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}
.pb-1\\.5 {
  padding-bottom: 0.375rem;
}
.pb-2 {
  padding-bottom: 0.5rem;
}
.pr-20 {
  padding-right: 5rem;
}
.pt-3 {
  padding-top: 0.75rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.font-\\[\\'Roboto\\'\\2c \\'Segoe_UI\\'\\2c system-ui\\2c sans-serif\\] {
  font-family: 'Roboto','Segoe UI',system-ui,sans-serif;
}
.font-mono {
  font-family: JetBrains Mono, Fira Code, Consolas, monospace;
}
.text-\\[10px\\] {
  font-size: 10px;
}
.text-\\[11px\\] {
  font-size: 11px;
}
.text-\\[8px\\] {
  font-size: 8px;
}
.text-\\[9px\\] {
  font-size: 9px;
}
.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-md-sm {
  font-size: 12px;
  line-height: 18px;
}
.text-md-xs {
  font-size: 11px;
  line-height: 16px;
}
.text-xl {
  font-size: 1.25rem;
  line-height: 1.75rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.text-xxl {
  font-size: 22px;
  line-height: 28px;
}
.font-bold {
  font-weight: 700;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.italic {
  font-style: italic;
}
.leading-\\[1\\.6\\] {
  line-height: 1.6;
}
.leading-\\[1\\.7\\] {
  line-height: 1.7;
}
.leading-normal {
  line-height: 1.5;
}
.leading-relaxed {
  line-height: 1.625;
}
.leading-snug {
  line-height: 1.375;
}
.leading-tight {
  line-height: 1.25;
}
.tracking-\\[0\\.03em\\] {
  letter-spacing: 0.03em;
}
.tracking-tight {
  letter-spacing: -0.025em;
}
.tracking-wide {
  letter-spacing: 0.025em;
}
.tracking-wider {
  letter-spacing: 0.05em;
}
.text-\\[\\#2469f0\\] {
  --tw-text-opacity: 1;
  color: rgb(36 105 240 / var(--tw-text-opacity, 1));
}
.text-amber-700 {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}
.text-background {
  color: hsl(var(--background));
}
.text-blue-700 {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}
.text-card-foreground {
  color: hsl(var(--card-foreground));
}
.text-destructive {
  color: hsl(var(--destructive));
}
.text-destructive-foreground {
  color: hsl(var(--destructive-foreground));
}
.text-destructive\\/80 {
  color: hsl(var(--destructive) / 0.8);
}
.text-foreground {
  color: hsl(var(--foreground));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}
.text-green-50 {
  --tw-text-opacity: 1;
  color: rgb(240 253 244 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-700 {
  --tw-text-opacity: 1;
  color: rgb(21 128 61 / var(--tw-text-opacity, 1));
}
.text-muted-foreground {
  color: hsl(var(--muted-foreground));
}
.text-popover-foreground {
  color: hsl(var(--popover-foreground));
}
.text-primary {
  color: hsl(var(--primary));
}
.text-primary-foreground {
  color: hsl(var(--primary-foreground));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity, 1));
}
.text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity, 1));
}
.text-red-900 {
  --tw-text-opacity: 1;
  color: rgb(127 29 29 / var(--tw-text-opacity, 1));
}
.text-secondary-foreground {
  color: hsl(var(--secondary-foreground));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-white\\/80 {
  color: rgb(255 255 255 / 0.8);
}
.text-white\\/90 {
  color: rgb(255 255 255 / 0.9);
}
.text-yellow-600 {
  --tw-text-opacity: 1;
  color: rgb(202 138 4 / var(--tw-text-opacity, 1));
}
.text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity, 1));
}
.text-yellow-800 {
  --tw-text-opacity: 1;
  color: rgb(133 77 14 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.underline-offset-4 {
  text-underline-offset: 4px;
}
.antialiased {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.opacity-0 {
  opacity: 0;
}
.opacity-30 {
  opacity: 0.3;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-60 {
  opacity: 0.6;
}
.opacity-85 {
  opacity: 0.85;
}
.opacity-90 {
  opacity: 0.9;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.grayscale {
  --tw-grayscale: grayscale(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.duration-300 {
  transition-duration: 300ms;
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
@keyframes enter {
  from {
    opacity: var(--tw-enter-opacity, 1);
    transform: translate3d(var(--tw-enter-translate-x, 0), var(--tw-enter-translate-y, 0), 0) scale3d(var(--tw-enter-scale, 1), var(--tw-enter-scale, 1), var(--tw-enter-scale, 1)) rotate(var(--tw-enter-rotate, 0));
  }
}
@keyframes exit {
  to {
    opacity: var(--tw-exit-opacity, 1);
    transform: translate3d(var(--tw-exit-translate-x, 0), var(--tw-exit-translate-y, 0), 0) scale3d(var(--tw-exit-scale, 1), var(--tw-exit-scale, 1), var(--tw-exit-scale, 1)) rotate(var(--tw-exit-rotate, 0));
  }
}
.animate-in {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.fade-in {
  --tw-enter-opacity: 0;
}
.fade-out {
  --tw-exit-opacity: 0;
}
.duration-200 {
  animation-duration: 200ms;
}
.duration-300 {
  animation-duration: 300ms;
}
.ease-in-out {
  animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.running {
  animation-play-state: running;
}
.placeholder\\:text-muted-foreground::-moz-placeholder {
  color: hsl(var(--muted-foreground));
}
.placeholder\\:text-muted-foreground::placeholder {
  color: hsl(var(--muted-foreground));
}
.last\\:border-b-0:last-child {
  border-bottom-width: 0px;
}
.hover\\:bg-accent:hover {
  background-color: hsl(var(--accent));
}
.hover\\:bg-amber-100\\/50:hover {
  background-color: rgb(254 243 199 / 0.5);
}
.hover\\:bg-destructive\\/10:hover {
  background-color: hsl(var(--destructive) / 0.1);
}
.hover\\:bg-destructive\\/20:hover {
  background-color: hsl(var(--destructive) / 0.2);
}
.hover\\:bg-destructive\\/90:hover {
  background-color: hsl(var(--destructive) / 0.9);
}
.hover\\:bg-green-600\\/90:hover {
  background-color: rgb(22 163 74 / 0.9);
}
.hover\\:bg-green-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(21 128 61 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-neutral-900:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(23 23 23 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-primary\\/5:hover {
  background-color: hsl(var(--primary) / 0.05);
}
.hover\\:bg-primary\\/90:hover {
  background-color: hsl(var(--primary) / 0.9);
}
.hover\\:bg-red-500\\/10:hover {
  background-color: rgb(239 68 68 / 0.1);
}
.hover\\:bg-red-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));
}
.hover\\:bg-secondary\\/80:hover {
  background-color: hsl(var(--secondary) / 0.8);
}
.hover\\:bg-white\\/25:hover {
  background-color: rgb(255 255 255 / 0.25);
}
.hover\\:text-accent-foreground:hover {
  color: hsl(var(--accent-foreground));
}
.hover\\:text-destructive:hover {
  color: hsl(var(--destructive));
}
.hover\\:text-foreground:hover {
  color: hsl(var(--foreground));
}
.hover\\:text-red-600:hover {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}
.hover\\:underline:hover {
  text-decoration-line: underline;
}
.hover\\:opacity-70:hover {
  opacity: 0.7;
}
.focus\\:bg-accent:focus {
  background-color: hsl(var(--accent));
}
.focus\\:text-accent-foreground:focus {
  color: hsl(var(--accent-foreground));
}
.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus\\:ring-primary:focus {
  --tw-ring-color: hsl(var(--primary));
}
.focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity, 1));
}
.focus\\:ring-ring:focus {
  --tw-ring-color: hsl(var(--ring));
}
.focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}
.focus-visible\\:outline-none:focus-visible {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.focus-visible\\:ring-primary:focus-visible {
  --tw-ring-color: hsl(var(--primary));
}
.focus-visible\\:ring-ring:focus-visible {
  --tw-ring-color: hsl(var(--ring));
}
.focus-visible\\:ring-offset-1:focus-visible {
  --tw-ring-offset-width: 1px;
}
.focus-visible\\:ring-offset-2:focus-visible {
  --tw-ring-offset-width: 2px;
}
.active\\:bg-accent:active {
  background-color: hsl(var(--accent));
}
.active\\:bg-destructive:active {
  background-color: hsl(var(--destructive));
}
.active\\:bg-green-600:active {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}
.active\\:bg-neutral-950:active {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.active\\:bg-primary:active {
  background-color: hsl(var(--primary));
}
.active\\:bg-secondary:active {
  background-color: hsl(var(--secondary));
}
.disabled\\:pointer-events-none:disabled {
  pointer-events: none;
}
.disabled\\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}
.disabled\\:bg-muted:disabled {
  background-color: hsl(var(--muted));
}
.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}
.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}
.data-\\[disabled\\]\\:pointer-events-none[data-disabled] {
  pointer-events: none;
}
.data-\\[side\\=bottom\\]\\:translate-y-1[data-side="bottom"] {
  --tw-translate-y: 0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[side\\=top\\]\\:-translate-y-1[data-side="top"] {
  --tw-translate-y: -0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:translate-x-4[data-state="checked"] {
  --tw-translate-x: 1rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=unchecked\\]\\:translate-x-0[data-state="unchecked"] {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.data-\\[state\\=checked\\]\\:bg-primary[data-state="checked"] {
  background-color: hsl(var(--primary));
}
.data-\\[state\\=unchecked\\]\\:bg-input[data-state="unchecked"] {
  background-color: hsl(var(--input));
}
.data-\\[disabled\\]\\:opacity-50[data-disabled] {
  opacity: 0.5;
}
.data-\\[state\\=open\\]\\:animate-in[data-state="open"] {
  animation-name: enter;
  animation-duration: 150ms;
  --tw-enter-opacity: initial;
  --tw-enter-scale: initial;
  --tw-enter-rotate: initial;
  --tw-enter-translate-x: initial;
  --tw-enter-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:animate-out[data-state="closed"] {
  animation-name: exit;
  animation-duration: 150ms;
  --tw-exit-opacity: initial;
  --tw-exit-scale: initial;
  --tw-exit-rotate: initial;
  --tw-exit-translate-x: initial;
  --tw-exit-translate-y: initial;
}
.data-\\[state\\=closed\\]\\:fade-out-0[data-state="closed"] {
  --tw-exit-opacity: 0;
}
.data-\\[state\\=open\\]\\:fade-in-0[data-state="open"] {
  --tw-enter-opacity: 0;
}
.data-\\[state\\=closed\\]\\:zoom-out-95[data-state="closed"] {
  --tw-exit-scale: .95;
}
.data-\\[state\\=open\\]\\:zoom-in-95[data-state="open"] {
  --tw-enter-scale: .95;
}
@supports (backdrop-filter: var(--tw)) {
  .supports-\\[backdrop-filter\\]\\:bg-background\\/60 {
    background-color: hsl(var(--background) / 0.6);
  }
}
.dark\\:border-amber-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(146 64 14 / var(--tw-border-opacity, 1));
}
.dark\\:border-green-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 101 52 / var(--tw-border-opacity, 1));
}
.dark\\:border-red-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(127 29 29 / var(--tw-border-opacity, 1));
}
.dark\\:bg-amber-900\\/30:is(.dark *) {
  background-color: rgb(120 53 15 / 0.3);
}
.dark\\:bg-amber-950\\/20:is(.dark *) {
  background-color: rgb(69 26 3 / 0.2);
}
.dark\\:bg-blue-900\\/30:is(.dark *) {
  background-color: rgb(30 58 138 / 0.3);
}
.dark\\:bg-blue-950\\/20:is(.dark *) {
  background-color: rgb(23 37 84 / 0.2);
}
.dark\\:bg-green-950\\/20:is(.dark *) {
  background-color: rgb(5 46 22 / 0.2);
}
.dark\\:bg-red-950\\/20:is(.dark *) {
  background-color: rgb(69 10 10 / 0.2);
}
.dark\\:bg-yellow-950\\/30:is(.dark *) {
  background-color: rgb(66 32 6 / 0.3);
}
.dark\\:text-amber-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}
.dark\\:text-blue-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.dark\\:text-green-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 202 202 / var(--tw-text-opacity, 1));
}
.dark\\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.dark\\:text-yellow-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
@media (min-width: 640px) {
  .sm\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
@media (min-width: 768px) {
  .md\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .md\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .md\\:text-left {
    text-align: left;
  }
}
@media (min-width: 1024px) {
  .lg\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
.\\[\\&\\>span\\]\\:line-clamp-1>span {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.\\[\\&\\>span\\]\\:h-3>span {
  height: 0.75rem;
}
.\\[\\&\\>span\\]\\:w-3>span {
  width: 0.75rem;
}
.data-\\[state\\=checked\\]\\:\\[\\&\\>span\\]\\:translate-x-3>span[data-state="checked"] {
  --tw-translate-x: 0.75rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.\\[\\&_svg\\]\\:pointer-events-none svg {
  pointer-events: none;
}
.\\[\\&_svg\\]\\:size-3\\.5 svg {
  width: 0.875rem;
  height: 0.875rem;
}
.\\[\\&_svg\\]\\:size-5 svg {
  width: 1.25rem;
  height: 1.25rem;
}
.\\[\\&_svg\\]\\:shrink-0 svg {
  flex-shrink: 0;
}
`.replace(/@import[^;]+;/g,"");if(p&&!p.getElementById("morbis-ri-shadow-css")){let C=document.createElement("style");C.id="morbis-ri-shadow-css",C.textContent=d+`
      .ri-modal {
        background: #f8f6f3;
        border-radius: 16px;
        box-shadow: 0 25px 60px rgba(0,0,0,.25);
        width: 96%;
        max-width: 1140px;
        max-height: 90vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: ri-up .25s ease;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.6;
        color: #1a1d23;
      }
      /* Paksa Roboto 16px/1.6 di atas CSS host (termasuk yang !important):
         menang di light-DOM fallback & elemen yang tidak inherit font
         (button native). Kode ICD (.font-mono) dikecualikan. */
      .ri-modal,
      .ri-modal *:not(.font-mono) {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
        line-height: 1.6 !important;
      }
      /* Dropdown bawaan browser (option/optgroup): render native, paksa eksplisit. */
      .ri-modal option,
      .ri-modal optgroup {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
      }
      .ri-modal *,
      .ri-modal *::before,
      .ri-modal *::after {
        box-sizing: border-box;
      }
      .ri-modal input,
      .ri-modal select,
      .ri-modal textarea {
        all: unset;
        box-sizing: border-box;
        font-family: inherit;
        font-size: inherit;
        color: inherit;
        cursor: default;
        height: auto;
        min-height: 32px;
        width: 100%;
        border: 1px solid hsl(214.3 31.8% 91.4%);
        border-radius: 6px;
        background: white;
        padding: 4px 10px;
        outline: none;
        transition: border-color 0.15s, box-shadow 0.15s;
      }
      .ri-modal input:focus,
      .ri-modal select:focus,
      .ri-modal textarea:focus {
        border-color: hsl(221.2 83.2% 53.3%);
        box-shadow: 0 0 0 2px hsl(221.2 83.2% 53.3% / 0.15);
      }
      .ri-modal textarea {
        resize: vertical;
        min-height: 80px;
        padding: 8px 10px;
      }
      .ri-modal select {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 8px center;
        padding-right: 28px;
      }
      .ri-modal h1,
      .ri-modal h2,
      .ri-modal h3 {
        font-family: 'Lexend', system-ui, sans-serif;
      }
    `,p.appendChild(C)}if(!document.getElementById("ext-ri-css")){let C=document.createElement("style");C.id="ext-ri-css",C.textContent=d+`
        .ri-modal {
        border-radius: 16px;
        box-shadow: 0 25px 60px rgba(0,0,0,.25);
        width: 96%;
        max-width: 1140px;
        max-height: 90vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: ri-up .25s ease;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.6;
        color: #1a1d23;
      }
      /* Paksa Roboto 16px/1.6 di atas CSS host (termasuk yang !important):
         menang di light-DOM fallback & elemen yang tidak inherit font
         (button native). Kode ICD (.font-mono) dikecualikan. */
      .ri-modal,
      .ri-modal *:not(.font-mono) {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
        line-height: 1.6 !important;
      }
      /* Dropdown bawaan browser (option/optgroup): render native, paksa eksplisit. */
      .ri-modal option,
      .ri-modal optgroup {
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif !important;
        font-size: 16px !important;
      }
      .ri-modal *,
      .ri-modal .ri-modal *::before,
      .ri-modal .ri-modal *::after {
        box-sizing: border-box;
      }
      /* Neutralize host page button/input/select/textarea defaults */
      .ri-modal .ri-modal button,
      .ri-modal .ri-modal input,
      .ri-modal .ri-modal select,
      .ri-modal .ri-modal textarea {
        all: unset;
        box-sizing: border-box;
        font-family: inherit;
        font-size: inherit;
        color: inherit;
        cursor: default;
      }
      .ri-modal .ri-modal button {
        cursor: pointer;
        min-height: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        white-space: nowrap;
        border-radius: 6px;
        font-weight: 500;
        font-size: 12px;
        line-height: 18px;
        padding: 4px 10px;
        transition: background-color 0.15s, color 0.15s;
      }
      .ri-modal .ri-modal button:disabled {
        pointer-events: none;
        opacity: 0.5;
      }
      .ri-modal .ri-modal input,
      .ri-modal .ri-modal select,
      .ri-modal .ri-modal textarea {
        height: auto;
        min-height: 32px;
        width: 100%;
        border: 1px solid hsl(214.3 31.8% 91.4%);
        border-radius: 6px;
        background: white;
        padding: 4px 10px;
        outline: none;
        transition: border-color 0.15s, box-shadow 0.15s;
      }
      .ri-modal .ri-modal input:focus,
      .ri-modal .ri-modal select:focus,
      .ri-modal .ri-modal textarea:focus {
        border-color: hsl(221.2 83.2% 53.3%);
        box-shadow: 0 0 0 2px hsl(221.2 83.2% 53.3% / 0.15);
      }
      .ri-modal .ri-modal textarea {
        resize: vertical;
        min-height: 80px;
        padding: 8px 10px;
      }
      .ri-modal .ri-modal select {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 8px center;
        padding-right: 28px;
      }
      .ri-modal .ri-modal h1,
      .ri-modal .ri-modal h2,
      .ri-modal .ri-modal h3 {
        font-family: 'Lexend', system-ui, sans-serif;
      }
      /* \u2500\u2500 Radix Select portal (renders outside .ri-modal) \u2500\u2500 */
      [data-radix-select-viewport] {
        padding: 4px;
      }
      [data-radix-select-viewport] [role="option"] {
        all: unset;
        display: flex;
        align-items: center;
        padding: 6px 8px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
        line-height: 18px;
        font-family: 'Roboto', 'Atkinson Hyperlegible', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
        color: #1a1d23;
      }
      [data-radix-select-viewport] [role="option"]:focus,
      [data-radix-select-viewport] [role="option"][data-highlighted] {
        background: hsl(210 40% 96.1%);
        color: hsl(222.2 47.4% 11.2%);
      }
      [data-radix-popper-content-wrapper] {
        z-index: 2147483646 !important;
      }
      @keyframes ri-up{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
    `,document.head.appendChild(C)}let S=(()=>{let C=p??c();if(!C)return s;s.style.display="none";let R=C.getElementById("app"),k=C.getElementById("ext-ri-shadow-container");k||(k=document.createElement("div"),k.id="ext-ri-shadow-container",k.style.cssText="position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;pointer-events:auto",(R??C).appendChild(k)),k.style.display="flex",nt&&(nt.style.display="none");let z=document.querySelector("[data-scroll-buttons]");return z&&(z.style.display="none"),k})();aa=(0,Sm.createRoot)(S);let L=async C=>{let R=Fh(C),k=await fetch(Oh,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:R,credentials:"same-origin"}),z=await k.text();if(!k.ok)throw new Error("HTTP "+k.status);if(/(?:Notice|Warning|Fatal error|Parse error)/i.test(z)&&z.length<300)throw new Error("PHP error");oa=null,ng({idVisit:C.id_visit,idResume:C.id_resume_inap,tipe:"ranap",aksi:C.id_resume_inap?"ubah":"buat",before:Ym(C.id_visit,"ranap")??{},after:cg(C)})};aa.render((0,ru.jsx)(Rh,{onError:()=>setTimeout(au,0),children:(0,ru.jsx)(Th,{data:i,onSave:L,onClose:au})})),setTimeout(()=>{(p?.getElementById("ext-ri-shadow-container")??s).querySelectorAll("textarea").forEach(C=>{let R=C;R.addEventListener("input",()=>{R.style.height="auto",R.style.height=R.scrollHeight+"px"}),R.dispatchEvent(new Event("input"))})},0)}function ou(){return document.documentElement.getAttribute("data-ext-resume-ranap")==="1"}function Uh(i=5e3){return ou()?Promise.resolve(!0):new Promise(s=>{let c=Date.now(),p=setInterval(()=>{ou()?(clearInterval(p),s(!0)):Date.now()-c>i&&(clearInterval(p),s(!1))},200)})}async function iu(){!location.href.startsWith(location.origin+"/v2/m-klaim/detail-v2-refaktor")||!await Uh()||["/login","/auth","/signin","/masuk","/keluar","/logout"].some(i=>location.pathname.toLowerCase().includes(i))||document.querySelectorAll('input[type="password"]').length>0||!new URLSearchParams(location.search).get("id_visit")||!(document.querySelector("input[name=jenis]")?.value??document.querySelector("select[name=jenis]")?.value??"").toUpperCase().includes("INAP")||document.getElementById("ext-ri-container")||(nt=document.createElement("button"),nt.id="ext-ri-float-btn",nt.textContent="RI",nt.title="Resume Rawat Inap",nt.style.cssText="position:fixed;right:16px;top:calc(50% + 52px);transform:translateY(-50%);z-index:2147483645;width:44px;height:44px;border-radius:10px;border:none;background:#059669;color:#fff;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.2)",nt.onclick=async()=>{if(!nt.disabled){nt.disabled=!0;try{if(oa||(oa=await Dh()),!oa){sc({title:"Gagal",message:"Gagal memuat data",variant:"danger",okLabel:"OK",hideCancel:!0}),nt.disabled=!1;return}Ih(oa)}catch(i){console.error("[RI] error:",i),sc({title:"Gagal",message:i instanceof Error?i.message:String(i),variant:"danger",okLabel:"OK",hideCancel:!0}),nt.disabled=!1}}},document.body.appendChild(nt))}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>iu()):iu().catch(i=>console.error("[RI] init error:",i))})();/*! Bundled license information:

scheduler/cjs/scheduler.production.js:
  (**
   * @license React
   * scheduler.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react.production.js:
  (**
   * @license React
   * react.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.js:
  (**
   * @license React
   * react-dom.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom-client.production.js:
  (**
   * @license React
   * react-dom-client.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react-jsx-runtime.production.js:
  (**
   * @license React
   * react-jsx-runtime.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs:
lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs:
lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs:
lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs:
lucide-react/dist/esm/defaultAttributes.mjs:
lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs:
lucide-react/dist/esm/context.mjs:
lucide-react/dist/esm/Icon.mjs:
lucide-react/dist/esm/createLucideIcon.mjs:
lucide-react/dist/esm/icons/check.mjs:
lucide-react/dist/esm/icons/info.mjs:
lucide-react/dist/esm/icons/triangle-alert.mjs:
lucide-react/dist/esm/icons/x.mjs:
lucide-react/dist/esm/lucide-react.mjs:
  (**
   * @license lucide-react v1.38.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
