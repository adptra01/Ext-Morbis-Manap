"use strict";var __morbis_feature=(()=>{var et="extensionConfig";function St(p,a,h){let g=a?.features?.[p];if(!g)return!0;if(g.enabled===!1)return!1;let k=h??a?.currentRole??"admin";if(k==="admin")return!0;let A=g.allowedRoles;return!Array.isArray(A)||A.length===0?!0:A.includes(k)}async function Et(p){try{let a=(await chrome.storage.sync.get(et))?.[et]??null;return St(p,a)}catch{return!0}}function Ct(p,a){Et(p).then(h=>{if(h)try{a()}catch(g){console.error(`[featureGate:${p}] gagal jalan:`,g)}})}var at="ext-free-text-noop",Lt='input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select{text-transform:none!important}';function It(p){try{let a=p.toUpper;if(typeof a=="function"&&a[at]===!0)return!0;let h=function(g){return g?.value??""};h[at]=!0;try{Object.defineProperty(p,"toUpper",{value:h,writable:!0,configurable:!0})}catch{p.toUpper=h}return!0}catch{return!1}}var _="ext-pa-typo",zt=[{key:"kop",label:"Kop Surat"},{key:"pasien",label:"Data Pasien"},{key:"judul",label:"Judul Bagian Isi"},{key:"isi",label:"Isi (termasuk ICD-O, Saran & Catatan)"},{key:"kesimpulan",label:"Kesimpulan"},{key:"ttd",label:"TTD"}],w={kop:{fs:16,lh:1.2},pasien:{fs:4,lh:1},judul:{fs:6,lh:1.2},isi:{fs:5,lh:1.25},kesimpulan:{fs:5,lh:1.25},icdo:{fs:6,lh:1.2},catatan:{fs:5,lh:1.25},ttd:{fs:6,lh:1.2}},it=4,nt=24,Rt=.5,Tt=2.5;function rt(p,a,h,g){let k=typeof p=="number"?p:Number(p);return Number.isFinite(k)?Math.min(g,Math.max(h,k)):a}function j(p,a){let h=p??{};return{fs:rt(h.fs,a.fs,it,nt),lh:rt(h.lh,a.lh,Rt,Tt)}}function F(p){let a=p??{};return{kop:j(a.kop,w.kop),pasien:j(a.pasien,w.pasien),judul:j(a.judul,w.judul),isi:j(a.isi,w.isi),kesimpulan:j(a.kesimpulan,w.kesimpulan),icdo:j(a.icdo,w.icdo),catatan:j(a.catatan,w.catatan),ttd:j(a.ttd,w.ttd)}}function G(){return F(null)}function ot(p){try{if(!p)return G();let a=p.getItem(_);return a?F(JSON.parse(a)):G()}catch{return G()}}function qt(p,a){try{return p?(p.setItem(_,JSON.stringify(F(a))),!0):!1}catch{return!1}}function Pt(p){try{p?.removeItem(_)}catch{}}function lt(p){let a=F(p),h=g=>Math.min(nt,Math.max(it,g));return{...a,alamatFs:h(a.kop.fs-8.5),judulLapFs:h(a.kop.fs-4)}}var b=p=>String(Math.round(p*100)/100);function Dt(p){let a=lt(p);return{"--pa-kop-fs":`${b(a.kop.fs)}pt`,"--pa-kop-lh":b(a.kop.lh),"--pa-alamat-fs":`${b(a.alamatFs)}pt`,"--pa-judul-lap-fs":`${b(a.judulLapFs)}pt`,"--pa-pasien-fs":`${b(a.pasien.fs)}pt`,"--pa-pasien-lh":b(a.pasien.lh),"--pa-judul-fs":`${b(a.judul.fs)}pt`,"--pa-judul-lh":b(a.judul.lh),"--pa-isi-fs":`${b(a.isi.fs)}pt`,"--pa-isi-lh":b(a.isi.lh),"--pa-kesimpulan-fs":`${b(a.kesimpulan.fs)}pt`,"--pa-kesimpulan-lh":b(a.kesimpulan.lh),"--pa-icdo-fs":`${b(a.icdo.fs)}pt`,"--pa-icdo-lh":b(a.icdo.lh),"--pa-catatan-fs":`${b(a.catatan.fs)}pt`,"--pa-catatan-lh":b(a.catatan.lh),"--pa-ttd-fs":`${b(a.ttd.fs)}pt`,"--pa-ttd-lh":b(a.ttd.lh)}}function Ft(p,a){if(p)try{for(let[h,g]of Object.entries(Dt(a)))p.setProperty(h,g)}catch{}}var Mt=/^(\(?[IVXLC]+[.)]|\d+[.)]|[-•–—*])\s+/;function st(p){let a=p??"",h=a.match(Mt);if(!h)return null;let g=a.slice(h[0].length).trim();return g===""?null:[h[1],g]}Ct("paLabPrint",function(){"use strict";function p(){try{It(window)}catch{}try{if(document.head&&!document.getElementById("ext-free-text-style")){let k=document.createElement("style");k.id="ext-free-text-style",k.textContent=Lt,document.head.appendChild(k)}}catch{}}if(p(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",p),window.setInterval(p,3e3),!window.location.pathname.includes("/laboratorium/print/"))return;async function a(){let k="ext-pa-print-proc";if(document.documentElement.getAttribute(k))return;document.documentElement.setAttribute(k,"1");let A=()=>{try{return window.localStorage??null}catch{return null}},S=ot(A()),J=()=>{try{Ft(document.documentElement.style,S)}catch{}};J();let v=t=>M(t?.textContent||"");function pt(t){return t.replace(/<[^>]+>/g," ")}function Ht(t){return t.replace(/\b(?:KH\.?|H\.)\s*(?=ABDUL\s+MANAP)/gi,"H. ")}function M(t){return Ht(t).replace(/\b(?:Notice|Warning|Fatal error|Parse error|Deprecated)\s*:[\s\S]*?\.php\s*on\s*line\s*\d+/gi," ").replace(/\b(?:Notice|Warning)\s*:\s*Undefined\s+(?:index|variable)\s*:.*$/gi," ").replace(/\s+/g," ").trim()}function d(t){return String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}let dt=document.querySelector("#logo img")?.getAttribute("src")||"/assets/images/logo/Kota Jambi.png",H=Array.from(document.querySelectorAll("h1.kop-atas")).map(t=>v(t)).filter(Boolean);for(;H.length<3;)H.push("");let q=[],ct=document.querySelector("#head-cetak-logo center, #head-cetak-logo");if(ct){let t=document.createElement("div");t.innerHTML=ct.innerHTML,t.querySelectorAll("h1").forEach(e=>e.remove()),q=(t.innerHTML||"").split(/<br\s*\/?>/gi).map(e=>t.textContent&&e.replace(/<[^>]+>/g,"").trim()).map(e=>String(e||"").trim()).filter(Boolean)}let U=q.join(" "),ut=t=>{let e=U.match(new RegExp(t+"\\s*:([\\d\\s().+-]+)","i"));return e?e[1].trim():""},mt=ut("telp"),ft=ut("fax"),$=(U.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/)||[""])[0],B=(U.match(/https?:\/\/[^\s;,]+/)||[""])[0],C=U.replace(/telp\s*:[\d\s().+-]+/gi,"").replace(/fax\s*:[\d\s().+-]+/gi,"").replace(/website\s*:?/gi,"").replace(/email\s*:?/gi,"");$&&(C=C.split($).join("")),B&&(C=C.split(B).join("")),C=C.split(/[;]+/).map(t=>t.replace(/\s+/g," ").trim()).filter(Boolean).join(", ").replace(/,\s*,+/g,",").replace(/^[,;\s]+|[,;\s]+$/g,"");let Ut=["Alamat: "+C,mt?"Telp: "+mt:"",ft?"Fax: "+ft:""].filter(Boolean).join(", "),$t=[$?"Email: "+$:"",B?"Website: "+B:""].filter(Boolean).join(", ");q=[Ut,$t].filter(Boolean);let Q=v(document.querySelector(".head-cetak-instansi"))||"LAPORAN HASIL PEMERIKSAAN",N=[];document.querySelectorAll(".table-outer tr").forEach(t=>{let e=t.querySelectorAll("td");if(e.length>=6){let r=v(e[0]),s=v(e[2]),o=v(e[3]),l=v(e[5]);r&&N.push([r,s]),o&&N.push([o,l])}});let I=["makroskopik","mikroskopik","kesimpulan","icdo","catatan","saran"],x=t=>t.toLowerCase().replace(/0/g,"o").replace(/[^a-z]/g,""),E=[];document.querySelectorAll(".contentlab td").forEach(t=>{let e="",r=!1,s=t.querySelector(".section-title");if(s)e=v(s),r=!0;else{let c=f=>f.split(":")[0].trim();for(let f of Array.from(t.children).slice(0,3)){let u=v(f);if(u&&u.length<=24&&I.includes(x(c(u)))){e=c(u);break}}if(!e){let f=(t.textContent||"").split(`
`).map(u=>u.trim()).find(Boolean)||"";f&&I.includes(x(c(f)))&&(e=c(f))}if(!e)return}let o=document.createElement("div");o.innerHTML=t.innerHTML,o.querySelector(".section-title")?.remove();let l=o.innerHTML.replace(/\r\n?/g,`
`).replace(/<br\s*\/?>[ \t]*\n?/gi,`
`).replace(/\n(?:[ \t]*\n)+/g,"\u2028").split("\u2028").map(c=>c.split(/<br\s*\/?>|\n/).map(f=>M(f.replace(/<[^>]+>/g," "))).filter(Boolean)).filter(c=>c.length),m=[],n=[];l.forEach((c,f)=>{c.forEach((u,L)=>{f>0&&L===0&&m.length&&n.push(m.length),m.push(u)})});let i=m;if(!r&&i.length&&x(i[0])===x(e)){i.shift();for(let c=0;c<n.length;c++)n[c]-=1;for(;n.length&&n[0]<=0;)n.shift()}i.length>1&&!/^[IVXLC]+\.\s/.test(i[0])&&i.slice(1).some(c=>/^II\.\s/.test(c))&&(i[0]="I. "+i[0]),e&&E.push({title:e,items:i,para:n})});let Bt=/^catatan\s*:?/i,Nt=/^icd[\s-]*o\b\s*:?/i,V=[];for(let t of E){let e=[{title:t.title,items:[],para:[]}],r=e[0],s=!1,o=(l,m)=>{r={title:l,items:[],para:[],bare:m},e.push(r),s=!0};if(t.items.forEach((l,m)=>{let n=l.match(Bt),i=n?null:l.match(Nt);if(n){x(r.title)!=="catatan"&&o("Catatan");let c=l.slice(n[0].length).trim();c&&(t.para.includes(m)&&r.para.push(r.items.length),r.items.push(c));return}if(i){x(r.title)!=="icdo"&&o("ICD-0",!0),t.para.includes(m)&&r.para.push(r.items.length),r.items.push(l);return}t.para.includes(m)&&r.para.push(r.items.length),r.items.push(l)}),s)for(let l of e)l.items.length&&V.push(l);else V.push(e[0])}E.length=0,E.push(...V),E.forEach((t,e)=>t._i=e),E.sort((t,e)=>{let r=t._i??0,s=e._i??0,o=I.indexOf(x(t.title)),l=I.indexOf(x(e.title)),m=o===-1?I.length:o,n=l===-1?I.length:l;return m!==n?m-n:r-s});function Ot(t){let e="";t instanceof HTMLSelectElement?e=((t.selectedIndex>=0?t.options[t.selectedIndex]:void 0)?.textContent||t.value||"").trim():(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&(e=(t.value||"").trim());let r=(t.getAttribute("name")||"")+" "+(t.getAttribute("id")||""),s=t.getAttribute("placeholder")||"",o=t.closest("tr, .form-group, .form-row, div")?.textContent||"";return{val:e,ctx:(r+" "+s+" "+o).slice(0,300)}}function Kt(t,e,r){let s=e.toLowerCase().split(/[^a-z0-9]+/).filter(n=>n.length>=4&&!/^(dokter|pengirim|rumah|sakit|klinik|tanpa|kelas|rsud|rs|sp|dr|dalam|luar)$/.test(n));if(!s.length)return"";let o=s.sort((n,i)=>i.length-n.length)[0],l="",m=-1;return t.querySelectorAll("input, textarea, select").forEach(n=>{let{val:i,ctx:c}=Ot(n);if(!i||i===e||!i.toLowerCase().includes(o))return;let f=r.test(c)?2:0;f>m&&(m=f,l=i)}),l}function _t(t,e){return(t.querySelector(e)?.value||"").trim()}async function Gt(t){let e=new URLSearchParams(window.location.search).get("id");if(!e)return;let r=n=>/ket\w*\s*klinis/i.test(n),s=n=>/^dokter/i.test(n)||/^rs\b/i.test(n),o=t.map(([n,i],c)=>({label:n,value:i,idx:c})).filter(n=>s(n.label)?!!n.value:r(n.label));if(!o.length)return;let l=new AbortController,m=window.setTimeout(()=>l.abort(),6e3);try{let n=new URL("/laboratorium/input-hasil/input-hasil-pa?id_lab="+encodeURIComponent(e),window.location.href),i=await fetch(n.toString(),{credentials:"same-origin",signal:l.signal});if(!i.ok){window.console.info("[paPrint] override: fetch input status "+i.status);return}let c=await i.text(),f=new DOMParser().parseFromString(c,"text/html");window.console.info('[paPrint] override: input title="'+(f.title||"").slice(0,60)+'" len='+c.length+" fields="+f.querySelectorAll("input, textarea, select").length);for(let u of o){if(r(u.label)){let tt=_t(f,'#keterangan_klinis, textarea[name="keterangan_klinis"], input[name="keterangan_klinis"]'),y=M(pt(tt));window.console.info("[paPrint] override: "+u.label+' cetak="'+u.value+'" input="'+y+'"'),y&&y!==u.value&&(t[u.idx][1]=y);continue}let L=/^dokter/i.test(u.label)?/dokter|pengirim|luar|dalam|rujuk/i:/rs\b|rumah\s*sakit|faskes|asal/i,Y=Kt(f,u.value,L),R=M(pt(Y||""));window.console.info("[paPrint] override: "+u.label+' cetak="'+u.value+'" input="'+R+'"'),R&&R!==u.value&&(t[u.idx][1]=R)}}catch{window.console.info("[paPrint] override: fetch gagal, pakai nilai server")}finally{window.clearTimeout(m)}}await Gt(N).catch(()=>{});let z=Array.from(document.querySelectorAll(".contentlab ~ div table td")).map(t=>v(t)).filter(Boolean),ht=z[0]||"",gt=z[1]||"",O=document.querySelector(".contentlab ~ div table img")?.getAttribute("src")||"",bt=z.find(t=>/^\(.*\)$/.test(t))||z[2]||"",xt=z.find(t=>/^nip\.?/i.test(t))||z[3]||"",yt=document.querySelector('a.tombol[href*="export"]')?.getAttribute("href")||window.location.href+"&export=word",Jt=Array.from(document.body.querySelectorAll("script")),Qt=t=>t.toLowerCase().split(/\s+/).map(e=>e&&e.charAt(0).toUpperCase()+e.slice(1)).join(" "),P=N.map(([t,e])=>{if(!/^ruang/i.test(t))return[t,e];let r=e.replace(/^poli\s+.+?-\s*(?=klinik)/i,"").trim()||e,s=r.replace(/^(\S+)\s+-\s*(?=\1\b)/i,"").trim()||r,o=s.split(/\s+-\s*/);if(o.length>=3&&/rawat\s+inap/i.test(o[1])){let l=Qt(o[1].trim()),m=o.slice(2).join(" - ").trim(),n=m?l+" - "+m:l;if(n)return[t,n]}return[t,s]}),Vt=P.map(([t,e])=>'<div class="info-item"><div class="info-label">'+d(t)+'</div><div class="info-colon">:</div><div class="info-value">'+d(e)+"</div></div>").join(""),W=t=>/^icd-?o\s*:/i.test(t)?"<strong>"+d(t)+"</strong>":d(t),Wt=t=>/^catatan/i.test(t.trim()),X=t=>/^saran/i.test(t.trim()),kt=t=>Wt(t)||X(t),Xt=t=>X(t)?"Saran:":"Catatan:",Z=t=>t.replace(/^(catatan|saran)\s*:?\s*/i,"").replace(/^[-•–—*]+\s*/,"").trim(),Zt=P.find(([t])=>/^no\.?pa/i.test(t))?.[1].replace(/[^a-zA-Z0-9]+/g,"-")||"tanpa-no";function vt(t){if(/^data:/i.test(t))return Promise.resolve(t);let e=new URL(t,window.location.href).href;return fetch(e,{signal:AbortSignal.timeout(8e3),credentials:"same-origin"}).then(r=>{if(!r.ok)throw new Error("img "+r.status);return r.blob()}).then(r=>new Promise((s,o)=>{let l=new FileReader;l.onload=()=>s(String(l.result)),l.onerror=()=>o(l.error),l.readAsDataURL(r)})).catch(()=>e)}async function Yt(){let t=lt(S),[e,r]=await Promise.all([vt(dt),O?vt(O):Promise.resolve("")]),s="";for(let i=0;i<P.length;i+=2){let c=P[i],f=P[i+1];s+="<tr><td>"+d(c[0])+"</td><td>:</td><td>"+d(c[1])+"</td>"+(f?"<td>"+d(f[0])+"</td><td>:</td><td>"+d(f[1])+"</td>":"<td></td><td></td><td></td>")+"</tr>"}let o="";for(let i of E){if(kt(i.title)){let y=i.items.length?i.items:["Tidak ada"],D=y.length>1,T=X(i.title)?"SARAN:":"CATATAN:";o+='<table border="0" cellspacing="0" cellpadding="2"><tr><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+T+'</b></td><td valign="top" style="font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';">'+y.map(K=>(D?"- ":"")+"<b>"+d(Z(K)||"Tidak ada")+"</b>").join("<br>")+"</td></tr></table>";continue}if(i.bare){i.items.forEach((y,D)=>{o+='<p style="margin:'+(D===0?"12pt":"0")+" 0 6pt 0;font-size:"+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><b>'+d(y.toUpperCase())+"</b></p>"});continue}let c=["makroskopik","mikroskopik","kesimpulan"].includes(x(i.title)),f=x(i.title)==="icdo";o+='<p style="margin:12pt 0 0 0;font-size:'+(f?t.isi.fs:t.judul.fs)+'pt;"><b>'+(c?"<u>":"")+d(i.title.toUpperCase())+(c?"</u>":"")+"</b></p>";let u=x(i.title)==="kesimpulan",L=x(i.title)==="icdo",Y=u||L||x(i.title)==="saran",R=u?t.kesimpulan.fs:t.isi.fs,tt=u?t.kesimpulan.lh:t.isi.lh;i.items.forEach((y,D)=>{let T=st(y),K=i.items.length===1&&T!==null&&/^[-•–—*]$/.test(T[0]),At=K?Z(y)||T[1]:y,ee=Y?"<b>"+d(At)+"</b>":W(At),ae=T&&!K?"margin-left:18pt;text-indent:-18pt;":"";o+='<p style="margin:'+(i.para.includes(D)?"14pt":"0")+" 0 6pt 0;font-size:"+R+"pt;line-height:"+tt+";text-align:justify;"+ae+'">'+ee+"</p>"})}let l='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+d(Q)+'</title></head><body style="font-family:Arial,sans-serif;font-size:'+t.isi.fs+"pt;line-height:"+t.isi.lh+';"><table border="0" width="100%" cellspacing="0" cellpadding="4"><tr><td width="110" valign="middle"><img src="'+e+'" width="90"></td><td align="center">'+H.slice(0,3).map(i=>'<b style="font-size:'+t.kop.fs+'pt;">'+d(i)+"</b>").join("<br>")+'<br><span style="font-size:'+t.alamatFs+'pt;">'+q.map(i=>d(i)).join("<br>")+'</span></td></tr></table><hr><p align="center" style="font-size:'+t.judulLapFs+'pt;"><b><u>'+d(Q.toUpperCase())+'</u></b></p><table border="0" cellspacing="0" cellpadding="2" style="font-size:'+t.pasien.fs+"pt;line-height:"+t.pasien.lh+';">'+s+"</table>"+o+'<table border="0" width="100%" cellspacing="0" cellpadding="0" style="font-size:'+t.ttd.fs+"pt;line-height:"+t.ttd.lh+';"><tr><td width="60%"></td><td align="center"><p style="margin:0 0 6pt 0;">'+d(ht)+'</p><p style="margin:0 0 6pt 0;">'+d(gt)+"</p>"+(r?'<p style="margin:0 0 6pt 0;"><img src="'+r+'" width="80" height="80"></p>':"")+'<p style="margin:0 0 6pt 0;"><b>'+d(bt)+'</b></p><p style="margin:0 0 6pt 0;">'+d(xt)+"</p></td></tr></table></body></html>",m=new Blob(["\uFEFF"+l],{type:"application/msword"}),n=document.createElement("a");n.href=URL.createObjectURL(m),n.download="Hasil-PA-"+Zt+".doc",document.body.appendChild(n),n.click(),window.setTimeout(()=>{URL.revokeObjectURL(n.href),n.remove()},4e3)}let te=E.map(t=>{if(kt(t.title)){let i=t.items.length?t.items:["Tidak ada"],c=i.length>1;return'<div class="section-catatan"><span class="catatan-label">'+Xt(t.title)+'</span><div class="catatan-list">'+i.map(f=>{let u="<span>"+d(Z(f)||"Tidak ada")+"</span>";return c?'<div class="catatan-item"><span class="catatan-dash">-</span>'+u+"</div>":'<div class="catatan-item">'+u+"</div>"}).join("")+"</div></div>"}let e=x(t.title)==="kesimpulan",r=x(t.title)==="icdo",s=e||r||x(t.title)==="saran",o='<div class="'+(t.bare?"section-isi section-isi-bare":"section-isi")+(e?" section-kesimpulan":"")+(r&&!t.bare?" section-icdo":"")+'">'+t.items.map((i,c)=>{let f=t.para.includes(c)?" item-para":"",u=st(i);if(u&&!(t.items.length===1&&/^[-•–—*]$/.test(u[0]))){let L=s?"<strong>"+d(u[1])+"</strong>":W(u[1]);return'<div class="item-list has-marker'+f+'"><span class="item-marker">'+d(u[0])+"</span><span>"+L+"</span></div>"}return'<div class="item-list'+f+'">'+(s?"<strong>"+d(i)+"</strong>":W(i))+"</div>"}).join("")+"</div>";if(t.bare)return o;let l=x(t.title),m=["makroskopik","mikroskopik","kesimpulan"].includes(l)?" u":"",n=l==="icdo"?" i":"";return'<div class="section-judul'+m+n+'">'+d(t.title)+"</div>"+o}).join("");document.body.innerHTML='<a href="'+d(yt)+'" class="btn-back" id="btn-word">Export Word</a><span id="SCETAK"><button onclick="cetak()" class="btn-print">Cetak Dokumen</button></span><button type="button" class="no-print" id="btn-typo" title="Atur font & spasi cetakan">\u2699\uFE0F Gaya</button><div class="t-typo no-print" id="ext-pa-typo" hidden></div><div class="page-a4"><div class="head-cetak"><div id="logo"><img src="'+d(dt)+'" alt="Logo"></div><div class="kop-text">'+H.slice(0,3).map(t=>'<h1 class="kop-atas">'+d(t)+"</h1>").join("")+'<div class="kop-alamat">'+q.map(t=>d(t)).join("<br>")+'</div></div></div><hr class="kop-hr"><div class="head-cetak-instansi">'+d(Q)+'</div><div class="patient-info-container">'+Vt+'</div><div class="hasil-pa">'+te+'</div><div class="ttd-container clearfix"><div class="ttd-box"><p>'+d(ht)+"</p><p>"+d(gt)+"</p>"+(O?'<img src="'+d(O)+'" alt="QR Code TTD">':"")+'<p style="font-weight: bold; margin-bottom: 0;">'+d(bt)+'</p><p style="margin-top: 2px;">'+d(xt)+"</p></div></div></div>",Jt.forEach(t=>document.body.appendChild(t)),document.querySelector("#btn-word")?.addEventListener("click",t=>{t.preventDefault(),Yt().catch(()=>{window.location.href=yt})});let wt=()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=(s,o,l,m,n,i,c,f)=>"<label>"+d(l)+'<input type="range" data-g="'+d(s)+'" data-f="'+o+'" min="'+m+'" max="'+n+'" step="'+i+'" value="'+c+'"><output data-o="'+d(s+"-"+o)+'">'+d(String(c)+f)+"</output></label>";t.innerHTML="<h4>Gaya Cetakan PA</h4>"+zt.map(s=>'<div class="t-typo-group"><strong>'+d(s.label)+'</strong><div class="t-typo-row">'+e(s.key,"fs","Font (pt)",4,20,.5,S[s.key].fs,"pt")+e(s.key,"lh","Spasi baris",.5,2.5,.05,S[s.key].lh,"")+"</div></div>").join("")+'<div class="t-typo-actions"><button type="button" data-act="save" class="primary">Simpan</button><button type="button" data-act="reset">Reset</button></div><div class="t-typo-note" data-note></div>',t.querySelectorAll('input[type="range"]').forEach(s=>{let o=s;o.addEventListener("input",()=>{let l=o.dataset.g,m=o.dataset.f;if(!l||!m||!S[l])return;S[l][m]=Number(o.value),J();let n=t.querySelector(`output[data-o="${l}-${m}"]`);n&&(n.textContent=o.value+(m==="fs"?"pt":""))})});let r=t.querySelector("[data-note]");t.querySelector('[data-act="save"]')?.addEventListener("click",()=>{let s=qt(A(),S);r&&(r.textContent=s?"Tersimpan \u2713":"Gagal menyimpan")}),t.querySelector('[data-act="reset"]')?.addEventListener("click",()=>{if(Pt(A()),S=ot(A()),J(),wt(),r){let s=t.querySelector("[data-note]");s&&(s.textContent="Kembali ke default \u2713")}})};document.querySelector("#btn-typo")?.addEventListener("click",()=>{let t=document.getElementById("ext-pa-typo");if(!t)return;let e=t.hidden;e&&wt(),t.hidden=!e}),document.head.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());let jt="ext-pa-print-style";if(!document.getElementById(jt)){let t=document.createElement("style");t.id=jt,t.textContent=`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

        /* Pengaturan Font dan Kertas untuk Cetak */
        body {
            font-family: 'Roboto', sans-serif;
            font-size: 6pt;
            color: #000;
            line-height: 1.2;
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
        }

        .page-a4 {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 20px auto;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            border-radius: 4px;
        }

        /* User Header Styles */
        .head-cetak {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            margin-bottom: 5px;
            width: 100%;
        }

        #logo img {
            height: 90px;
            width: auto;
        }

        .kop-text {
            text-align: center;
        }

        .kop-atas {
            font-size: var(--pa-kop-fs, 16pt);
            margin: 0;
            line-height: var(--pa-kop-lh, 1.2);
            font-weight: bold;
            color: #000;
        }

        .kop-alamat {
            font-size: var(--pa-alamat-fs, 7.5pt);
            margin-top: 5px;
            color: #334155;
            line-height: var(--pa-kop-lh, 1.3);
        }

        hr.kop-hr {
            border: none;
            border-top: 2px solid #000;
            margin: 10px 0;
            width: 100%;
        }

        .head-cetak-instansi {
            font-size: var(--pa-judul-lap-fs, 12pt);
            font-weight: bold;
            text-align: center;
            margin: 15px 0 20px 0;
            text-decoration: underline;
            text-transform: uppercase;
            line-height: var(--pa-kop-lh, 1.2);
        }

        /* Kontainer utama dengan 2 kolom */
        .patient-info-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 40px;
            font-family: Arial, sans-serif;
            max-width: 900px;
        }

        /* Tata letak untuk setiap baris data (Label : Nilai) */
        .info-item {
            display: grid;
            grid-template-columns: 110px 15px 1fr;
            align-items: start;
        }

        .info-label {
            font-weight: 500;
        }

        .info-colon {
            text-align: center;
        }

        /* Responsif: Ubah jadi 1 kolom di layar HP (lebar maksimal 768px) */
        @media (max-width: 768px) {
            .patient-info-container {
                grid-template-columns: 1fr;
            }
        }

        /* Result Sections */
        .hasil-pa {
            margin-top: 20px;
        }

        .hasil-title {
            text-align: center;
            font-weight: bold;
            font-size: 8pt;
            margin-bottom: 20px;
            text-decoration: underline;
        }

        .section-judul {
            font-weight: bold;
            margin-top: 12px;
            font-size: 6pt;
            text-transform: uppercase;
        }

        /* Garis bawah hanya untuk header Makroskopik/Mikroskopik/Kesimpulan
           (permintaan user 2026-11-06). */
        .section-judul.u {
            text-decoration: underline;
        }

        .section-isi {
            margin-top: 8px;
            text-align: justify;
            line-height: 1.25;
        }

        .item-list {
            margin-bottom: 12px;
        }

        .group-title {
            margin-bottom: 6px;
            font-weight: 500;
        }

        .empty-field {
            color: #9ca3af;
            font-style: italic;
        }

        /* Signature Section */
        .ttd-container {
            margin-top: 15px;
        }

        .ttd-box {
            float: right;
            width: 300px;
            text-align: center;
            font-size: var(--pa-ttd-fs, 6pt);
            line-height: var(--pa-ttd-lh, 1.2);
        }

        .ttd-box p {
            margin: 5px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        @media print {
            body {
                background-color: transparent;
                padding: 0;
            }

            .page-a4 {
                margin: 0;
                box-shadow: none;
                width: 100%;
                padding: 10mm;
            }

            .nav-container,
            .nav-button,
            .btn-print,
            .btn-back {
                display: none !important;
            }
        }

        /* Buttons */
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 20px;
            transition: background 0.2s;
        }

        .nav-button:hover {
            background-color: #475569;
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-print:hover {
            background: #0f172a;
        }

        .btn-back {
            position: fixed;
            top: 20px;
            right: 170px;
            background: #64748b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back:hover {
            background: #475569;
        }

        /* === OVERRIDE: QR sedang + info rapat + print 2 kolom ===
           Layout tetap prioritas; hanya: QR 80px, jarak baris info
           rapat, info pasien tetap grid 2 kolom saat cetak. */
        .ttd-box img {
            width: 80px;
            height: 80px;
        }

        .patient-info-container {
            font-size: var(--pa-pasien-fs, 4pt);
            line-height: var(--pa-pasien-lh, 1);
            gap: 4px 40px;
            border: 1px solid #000;
            padding: 10px 12px;
        }

        @media print {
            .patient-info-container {
                grid-template-columns: 1fr 1fr !important;
            }

            .section-judul {
                break-after: avoid;
            }
        }

        .section-judul {
            font-size: var(--pa-judul-fs, 6pt);
            line-height: var(--pa-judul-lh, 1.2);
        }

        .section-isi {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Isi Kesimpulan: grup gaya sendiri, terpisah dari Isi
           (permintaan user). Default sama dengan isi agar tampilan
           awal tidak berubah. */
        .section-kesimpulan {
            font-size: var(--pa-kesimpulan-fs, 5pt);
            line-height: var(--pa-kesimpulan-lh, 1.25);
        }

        /* Isi ICD-O yang dirender server DENGAN judul section sendiri:
           menyatu dengan Catatan/Saran \u2192 ikut grup Isi yang sama
           (user 2026-11-06), selalu bold.
           Varian tanpa judul memakai .section-isi-bare (grup Isi sama). */
        .section-icdo {
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Header ICD-O berjudul menyatu dengan isinya \u2192 grup Isi
           (bukan Judul), supaya header+isi sama besar. */
        .section-judul.i {
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
        }

        /* Hanging indent: baris bernomor/berpoin \u2014 penanda di kolom
           kiri tetap, teks lanjutan sejajar di bawah teks. */
        .item-list.has-marker {
            display: flex;
            gap: 6px;
        }

        .item-marker {
            flex-shrink: 0;
        }

        .item-list {
            margin-bottom: 6px;
        }

        /* Awal paragraf baru (baris kosong di input): gap ekstra. */
        .item-list.item-para {
            margin-top: 14px;
        }

        /* ICD-O tanpa judul (bare, id=154696): "ICD-O : \u2026" saja tanpa
           dobel judul "ICD-0" \u2014 font, margin & padding sama persis
           seperti section-judul (minus garis bawah), dan memakai grup
           Isi yang sama dengan Catatan/Saran (user 2026-11-06). */
        .section-isi-bare {
            margin: 12px 0 0;
            padding: 0;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .section-isi-bare .item-list {
            margin: 0;
            padding: 0;
        }

        /* CATATAN & SARAN: label + list gantung \u2014 baris lanjutan rata di bawah
           dash pertama ("Catatan: - \u2026" lalu "- \u2026" sejajar di bawahnya).
           Header dan isi menyatu dalam satu baris, jadi keduanya memakai
           grup Isi yang sama (\u2699\uFE0F Gaya \u2192 Isi), sama besar dengan isi \u2014
           sesuai permintaan user 2026-11-06. Seluruh isinya bold. */
        .section-catatan {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 12px;
            font-size: var(--pa-isi-fs, 5pt);
            font-weight: bold;
            line-height: var(--pa-isi-lh, 1.25);
            text-align: justify;
        }

        .catatan-label {
            flex-shrink: 0;
            font-weight: bold;
            font-size: var(--pa-isi-fs, 5pt);
            line-height: var(--pa-isi-lh, 1.25);
            text-transform: uppercase;
        }

        .catatan-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
            font-weight: bold;
        }

        .catatan-item {
            display: flex;
            gap: 6px;
        }

        .catatan-dash {
            flex-shrink: 0;
        }

        /* Panel pengaturan tipografi (tombol \u2699\uFE0F Gaya) \u2014 no-print. */
        #btn-typo {
            position: fixed;
            top: 70px;
            right: 20px;
            background: #1e293b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Roboto', sans-serif;
            font-weight: 500;
            z-index: 9999;
        }
        #btn-typo:hover { background: #0f172a; }
        .t-typo {
            position: fixed;
            top: 120px;
            right: 20px;
            width: 280px;
            max-height: 70vh;
            overflow-y: auto;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
            padding: 12px 14px;
            z-index: 9999;
            font-family: 'Roboto', sans-serif;
        }
        .t-typo h4 { margin: 0 0 8px; font-size: 13px; }
        .t-typo-group { margin-bottom: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
        .t-typo-group > strong { display: block; font-size: 12px; margin-bottom: 4px; }
        .t-typo-row { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
        .t-typo-row label { display: flex; flex-direction: column; font-size: 11px; color: #475569; gap: 2px; }
        .t-typo-row input[type="range"] { width: 100%; }
        .t-typo-row output { font-size: 11px; color: #0f172a; font-weight: 600; }
        .t-typo-actions { display: flex; gap: 8px; margin-top: 4px; }
        .t-typo-actions button {
            flex: 1;
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            border-radius: 6px;
            padding: 6px 0;
            font-size: 12px;
            cursor: pointer;
        }
        .t-typo-actions button.primary { background: #1e293b; color: white; border-color: #1e293b; }
        .t-typo-note { font-size: 11px; color: #15803d; min-height: 16px; margin-top: 6px; }
        @media print { .no-print { display: none !important; } }
      `,document.head.appendChild(t)}}let h=Date.now(),g=window.setInterval(()=>{document.documentElement.getAttribute("data-ext-pa-print")==="1"?(window.clearInterval(g),a().catch(()=>{})):Date.now()-h>5e3&&window.clearInterval(g)},200)})})();
